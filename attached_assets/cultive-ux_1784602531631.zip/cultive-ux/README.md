# CULTIVE UX Transitions & Animations — Replit Task

> Drop this file into your Replit project and work through each section in order.

---

## 0. Install Dependency

```bash
npm install motion
```

Motion is the animation library (formerly Framer Motion). Already in `package.json`? Skip.

---

## 1. Check/Fill `src/styles/animations.css`

Open the file. If it's empty or missing, paste this:

```css
/* ==============================
   CULTIVE Animation Utilities
   ============================== */

/* Entry animations */
@keyframes fade-in {
  from { opacity: 0; }
  to   { opacity: 1; }
}

@keyframes slide-up {
  from { opacity: 0; transform: translateY(12px); }
  to   { opacity: 1; transform: translateY(0); }
}

@keyframes scale-in {
  from { opacity: 0; transform: scale(0.95); }
  to   { opacity: 1; transform: scale(1); }
}

.animate-fade-in  { animation: fade-in  0.3s ease-out both; }
.animate-slide-up { animation: slide-up 0.4s ease-out both; }
.animate-scale-in { animation: scale-in 0.25s ease-out both; }

/* Hover lift */
.hover-lift {
  transition: transform 0.2s ease;
}
.hover-lift:hover {
  transform: translateY(-2px);
}

.hover-lift-lg {
  transition: transform 0.3s ease;
}
.hover-lift-lg:hover {
  transform: translateY(-4px);
}

/* Refined shadows */
.shadow-soft {
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.06), 0 1px 2px rgba(0, 0, 0, 0.04);
}

.shadow-soft-lg {
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08), 0 2px 4px rgba(0, 0, 0, 0.04);
}

/* Refined borders */
.border-refined {
  border: 1px solid rgba(255, 255, 255, 0.06);
}

.focus-refined:focus-visible {
  outline: 1.5px solid rgba(255, 255, 255, 0.3);
  outline-offset: 2px;
}

/* Glass morphism */
.glass {
  background: rgba(255, 255, 255, 0.04);
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
}

/* Card system */
.card-refined {
  background: rgba(255, 255, 255, 0.03);
  border: 1px solid rgba(255, 255, 255, 0.06);
  border-radius: 12px;
  overflow: hidden;
}

.card-padding        { padding: 16px; }
.card-header-spacing { margin-bottom: 12px; }

/* Layout spacing */
.app-container {
  max-width: 1400px;
  margin: 0 auto;
  padding: 0 20px;
}

.content-spacing  { margin-top: 24px; margin-bottom: 24px; }
.content-padding  { padding: 16px 20px; }
.section-spacing  { margin-bottom: 48px; }

/* Pulse dot */
.animate-presence-pulse {
  animation: presence-pulse 2s ease-in-out infinite;
}

@keyframes presence-pulse {
  0%, 100% { opacity: 0.3; transform: scale(1); }
  50%      { opacity: 1;   transform: scale(1.15); }
}

/* Reduced motion — respect user preference */
@media (prefers-reduced-motion: reduce) {
  *,
  *::before,
  *::after {
    animation-duration: 0.01ms !important;
    transition-duration: 0.01ms !important;
  }
}
```

**Confirm:** `src/styles/index.css` has this at the top:

```css
@import './animations.css';
```

---

## 2. Create `src/app/components/LazyImage.tsx`

Blur-up image loading. Shows a tiny blurred preview that fades into the full image.

```tsx
import { motion } from "motion/react";
import { useState } from "react";

interface LazyImageProps {
  src: string;
  alt: string;
  className?: string;
}

export function LazyImage({ src, alt, className = "" }: LazyImageProps) {
  const [loaded, setLoaded] = useState(false);

  return (
    <div className={`relative overflow-hidden ${className}`}>
      {/* Blur placeholder — scaled up so blur edges don't peek through */}
      <motion.img
        src={src}
        alt=""
        className="absolute inset-0 w-full h-full object-cover"
        style={{ filter: "blur(20px)", transform: "scale(1.1)" }}
        animate={loaded ? { opacity: 0 } : { opacity: 1 }}
        transition={{ duration: 0.15 }}
      />

      {/* Full image — fades in over the blur */}
      <motion.img
        src={src}
        alt={alt}
        className="relative w-full h-full object-cover"
        initial={{ opacity: 0 }}
        animate={loaded ? { opacity: 1 } : { opacity: 0 }}
        transition={{ duration: 0.4, ease: "easeOut" }}
        onLoad={() => setLoaded(true)}
      />
    </div>
  );
}
```

---

## 3. Create `src/app/components/SkeletonCard.tsx`

Animated placeholder cards shown while events load.

```tsx
import { motion } from "motion/react";

export function SkeletonCard() {
  return (
    <div className="overflow-hidden rounded-xl bg-neutral-900 border border-white/[0.06]">
      {/* Image skeleton */}
      <motion.div
        className="aspect-[4/3] bg-neutral-800"
        animate={{ opacity: [0.3, 0.6, 0.3] }}
        transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
      />

      {/* Text skeletons */}
      <div className="p-4 space-y-2">
        <motion.div
          className="h-4 bg-neutral-800 rounded w-3/4"
          animate={{ opacity: [0.3, 0.6, 0.3] }}
          transition={{
            duration: 1.5,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 0.1,
          }}
        />
        <motion.div
          className="h-3 bg-neutral-800 rounded w-1/2"
          animate={{ opacity: [0.3, 0.6, 0.3] }}
          transition={{
            duration: 1.5,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 0.2,
          }}
        />
        <div className="flex gap-2 pt-1">
          <motion.div
            className="h-6 w-16 bg-neutral-800 rounded-full"
            animate={{ opacity: [0.3, 0.6, 0.3] }}
            transition={{
              duration: 1.5,
              repeat: Infinity,
              ease: "easeInOut",
              delay: 0.3,
            }}
          />
          <motion.div
            className="h-6 w-20 bg-neutral-800 rounded-full"
            animate={{ opacity: [0.3, 0.6, 0.3] }}
            transition={{
              duration: 1.5,
              repeat: Infinity,
              ease: "easeInOut",
              delay: 0.35,
            }}
          />
        </div>
      </div>
    </div>
  );
}
```

---

## 4. Create `src/app/components/PageTransition.tsx`

Fade + slide wrapper for page-level transitions.

```tsx
import { motion } from "motion/react";
import type { ReactNode } from "react";

interface PageTransitionProps {
  children: ReactNode;
  className?: string;
}

export function PageTransition({ children, className = "" }: PageTransitionProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.25, ease: "easeInOut" }}
      className={className}
    >
      {children}
    </motion.div>
  );
}
```

---

## 5. Wrap Router/Tabs with `AnimatePresence` + `PageTransition`

### Option A — React Router

Go to wherever `<Routes>` is defined (usually `App.tsx`).

**Add import:**
```tsx
import { AnimatePresence } from "motion/react";
import { useLocation } from "react-router-dom";
import { PageTransition } from "./app/components/PageTransition";
```

**Wrap routes:**
```tsx
function App() {
  const location = useLocation();

  return (
    <AnimatePresence mode="wait">
      <Routes location={location} key={location.pathname}>
        <Route path="/" element={<PageTransition><Home /></PageTransition>} />
        <Route path="/events" element={<PageTransition><Events /></PageTransition>} />
        <Route path="/event/:id" element={<PageTransition><EventDetail /></PageTransition>} />
        {/* ... other routes */}
      </Routes>
    </AnimatePresence>
  );
}
```

> **Critical:** Both `<Routes>` and the inner `motion.div` inside `PageTransition` must receive `key` — otherwise exit animations won't fire. `AnimatePresence` uses the key to track which element is leaving.

---

### Option B — Tab-based navigation (no router)

If pages switch by tab state rather than URL:

```tsx
import { AnimatePresence } from "motion/react";
import { PageTransition } from "./app/components/PageTransition";

function MainView({ activeTab }: { activeTab: string }) {
  return (
    <AnimatePresence mode="wait">
      {activeTab === "events" && (
        <PageTransition key="events">
          <EventsGrid />
        </PageTransition>
      )}
      {activeTab === "collections" && (
        <PageTransition key="collections">
          <Collections />
        </PageTransition>
      )}
      {activeTab === "about" && (
        <PageTransition key="about">
          <About />
        </PageTransition>
      )}
    </AnimatePresence>
  );
}
```

> **Critical:** `key` must be unique and change with the tab. Use the tab name directly.

---

## 6. Add Staggered Entrance to Event Grids

Find your event card grid component. Replace the grid container with:

```tsx
import { motion } from "motion/react";
import { LazyImage } from "./app/components/LazyImage";

function EventsGrid({ events }: { events: Event[] }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
      {events.map((event, i) => (
        <motion.div
          key={event.id}
          layout
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{
            duration: 0.35,
            delay: i * 0.04,                // stagger: 40ms per card
            ease: [0.25, 0.1, 0.25, 1],     // custom cubic bezier
          }}
        >
          <EventCard event={event} />
        </motion.div>
      ))}
    </div>
  );
}
```

> **`layout` prop** enables automatic reorder animation when filters/sorts change. Motion handles the FLIP animation automatically.

---

## 7. Swap `<img>` → `<LazyImage>` in Event Cards

Find your event card component. Replace:

```tsx
<img
  src={event.image_url}
  alt={event.title}
  className="aspect-[4/3] object-cover ..."
/>
```

with:

```tsx
<LazyImage
  src={event.image_url}
  alt={event.title}
  className="aspect-[4/3]"
/>
```

Do this everywhere event images are rendered — grids, detail pages, featured sections.

---

## 8. Show Skeletons While Loading

Find where events are mapped to cards. Add a loading branch:

```tsx
import { SkeletonCard } from "./app/components/SkeletonCard";

// Inside your events section:
{isLoading
  ? Array.from({ length: 6 }).map((_, i) => (
      <SkeletonCard key={i} />
    ))
  : events.map((event, i) => (
      <motion.div key={event.id} layout ...>
        <EventCard event={event} />
      </motion.div>
    ))
}
```

For a grid, keep the grid wrapper and show skeletons inside it so the layout doesn't jump:

```tsx
<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
  {isLoading
    ? Array.from({ length: 6 }).map((_, i) => <SkeletonCard key={i} />)
    : events.map((event, i) => ( /* staggered motion.div */ ))
  }
</div>
```

---

## 9. Performance Audit (Run These)

After everything is wired up, check these numbers:

### Image sizes
```
Largest event image on the page: ___ KB
Goal: < 500KB. If over, resize to max 800px wide or use a CDN transform.
```

### Lazy loading
```
Are images below the fold using loading="lazy"? Yes / No
LazyImage already does this implicitly via the blur-up pattern.
```

### Bundle size
```bash
npm run build
# Check the output — is the main JS bundle > 500KB?
# If yes, look into code splitting (React.lazy + Suspense).
```

### API calls
```
How many events fetched per page load? ___
Goal: paginate at 20 per page, or infinite scroll with Intersection Observer.
```

### Font loading
```
Preload your main font: add this to index.html <head>:
<link rel="preload" href="/fonts/your-font.woff2" as="font" crossorigin>
```

---

## Summary — File Checklist

- [ ] `npm install motion`
- [ ] `src/styles/animations.css` — filled with CSS utilities
- [ ] `src/styles/index.css` — has `@import './animations.css';`
- [ ] `src/app/components/LazyImage.tsx` — created
- [ ] `src/app/components/SkeletonCard.tsx` — created
- [ ] `src/app/components/PageTransition.tsx` — created
- [ ] Router/tabs wrapped with `AnimatePresence` + `PageTransition`
- [ ] Event grid has staggered `motion.div` + `layout`
- [ ] `<img>` replaced with `<LazyImage>` in event cards
- [ ] Loading state shows `SkeletonCard` grid
- [ ] Performance audit numbers recorded

---

## No New Dependencies

Everything uses `motion` (already in your project or one `npm install` away). No other packages needed.
