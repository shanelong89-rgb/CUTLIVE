import { useEffect, useState, useMemo } from 'react';
import { listSiteImages, updateSiteImage, uploadFile } from '@/app/hooks/useAdminApi';
import { staticSiteImages } from '@/app/data/cms';
import { Upload, Save, Check, Loader2, AlertCircle, X, Image as ImageIcon, RotateCcw, ShieldAlert, Lock, Unlock } from 'lucide-react';

// Page display names for section headers
const pageLabels: Record<string, string> = {
  'home': 'Homepage',
  'about': 'About',
  'venture-studio': 'Venture Studio',
  'impact-themes': 'Impact Themes',
  'portfolio': 'Portfolio',
  'contact': 'Contact',
  'donate': 'Donate',
  'supporters': 'Supporters',
};

// IDs of protected hero/background images that should NOT be casually changed
const PROTECTED_IDS = new Set([
  'home-hero-bg',
  'about-team-photo',
  'venture-studio-hero',
  'impact-hero',
  'portfolio-hero',
  'contact-hero',
  'donate-hero',
  'supporters-hero',
]);

export function ImageManager() {
  const [overrides, setOverrides] = useState<Record<string, string>>({});
  const [editValues, setEditValues] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);
  const [saved, setSaved] = useState<string | null>(null);
  const [uploading, setUploading] = useState<string | null>(null);
  const [error, setError] = useState('');
  // Track which protected images have been unlocked this session
  const [unlockedIds, setUnlockedIds] = useState<Set<string>>(new Set());
  // Which image is showing the unlock confirmation dialog
  const [confirmUnlockId, setConfirmUnlockId] = useState<string | null>(null);

  useEffect(() => {
    listSiteImages()
      .then((data) => {
        setOverrides(data.overrides || {});
        setEditValues(data.overrides || {});
      })
      .catch((err) => {
        console.error('Error loading site images:', err);
        setError(err.message);
      })
      .finally(() => setLoading(false));
  }, []);

  // Group images by page
  const groupedImages = useMemo(() => {
    const groups: { page: string; label: string; images: typeof staticSiteImages }[] = [];
    const seen = new Set<string>();

    for (const si of staticSiteImages) {
      if (!seen.has(si.page)) {
        seen.add(si.page);
        groups.push({
          page: si.page,
          label: pageLabels[si.page] || si.page,
          images: staticSiteImages.filter((s) => s.page === si.page),
        });
      }
    }
    return groups;
  }, []);

  const handleSave = async (slotId: string) => {
    const url = editValues[slotId];
    if (url === undefined) return;
    setSaving(slotId);
    try {
      const si = staticSiteImages.find((s) => s.id === slotId);
      await updateSiteImage(slotId, url, si?.alt);
      setOverrides((prev) => ({ ...prev, [slotId]: url }));
      setSaved(slotId);
      setTimeout(() => setSaved(null), 2000);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSaving(null);
    }
  };

  const handleUpload = async (slotId: string, file: File) => {
    setUploading(slotId);
    try {
      const url = await uploadFile(file);
      setEditValues((prev) => ({ ...prev, [slotId]: url }));
      const si = staticSiteImages.find((s) => s.id === slotId);
      await updateSiteImage(slotId, url, si?.alt);
      setOverrides((prev) => ({ ...prev, [slotId]: url }));
      setSaved(slotId);
      setTimeout(() => setSaved(null), 2000);
    } catch (err: any) {
      setError(`Upload failed: ${err.message}`);
    } finally {
      setUploading(null);
    }
  };

  const handleResetToDefault = async (slotId: string) => {
    const si = staticSiteImages.find((s) => s.id === slotId);
    if (!si) return;
    setSaving(slotId);
    try {
      await updateSiteImage(slotId, '', si.alt);
      setOverrides((prev) => {
        const next = { ...prev };
        delete next[slotId];
        return next;
      });
      setEditValues((prev) => {
        const next = { ...prev };
        delete next[slotId];
        return next;
      });
      setSaved(slotId);
      setTimeout(() => setSaved(null), 2000);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSaving(null);
    }
  };

  const getDisplayUrl = (slotId: string) => {
    return editValues[slotId] || overrides[slotId] || staticSiteImages.find((s) => s.id === slotId)?.url || '';
  };

  const handleUnlockConfirm = (slotId: string) => {
    setUnlockedIds((prev) => new Set([...prev, slotId]));
    setConfirmUnlockId(null);
  };

  return (
    <div className="max-w-6xl">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-1">Hero & Section Images</h1>
        <p className="text-gray-500 text-sm">
          All images used across the site, grouped by page. Upload a new image or paste a URL to override the default.
        </p>
      </div>

      {error && (
        <div className="flex items-center gap-2 bg-red-50 border border-red-200 text-red-700 text-sm rounded-lg p-3 mb-4">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          {error}
          <button onClick={() => setError('')} className="ml-auto text-red-400 hover:text-red-600"><X className="w-4 h-4" /></button>
        </div>
      )}

      {/* Unlock confirmation modal */}
      {confirmUnlockId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full mx-4 overflow-hidden">
            {/* Warning header */}
            <div className="bg-amber-50 border-b border-amber-200 px-6 py-4 flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-amber-100 flex items-center justify-center flex-shrink-0">
                <ShieldAlert className="w-5 h-5 text-amber-600" />
              </div>
              <div>
                <h3 className="font-bold text-amber-900 text-sm">Protected Background Image</h3>
                <p className="text-amber-700 text-xs">This controls a page background gradient</p>
              </div>
            </div>

            {/* Warning body */}
            <div className="px-6 py-5 space-y-3">
              <p className="text-gray-700 text-sm leading-relaxed">
                This image is used as a <strong>full-page background or hero gradient</strong>. Changing it will affect the entire look and feel of the page.
              </p>
              <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                <p className="text-red-800 text-xs font-semibold leading-relaxed">
                  Do not change unless absolutely necessary. Changes to background images cannot be easily reverted and may break the page design.
                </p>
              </div>
              <p className="text-gray-500 text-xs">
                Slot: <code className="text-emerald-600 bg-emerald-50 px-1 py-0.5 rounded font-mono">{confirmUnlockId}</code>
              </p>
            </div>

            {/* Actions */}
            <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 flex items-center justify-end gap-3">
              <button
                onClick={() => setConfirmUnlockId(null)}
                className="px-4 py-2 text-sm font-medium text-gray-600 hover:text-gray-900 transition"
              >
                Cancel
              </button>
              <button
                onClick={() => handleUnlockConfirm(confirmUnlockId)}
                className="px-4 py-2 text-sm font-bold text-white bg-amber-500 hover:bg-amber-600 rounded-lg transition flex items-center gap-2"
              >
                <Unlock className="w-3.5 h-3.5" />
                I understand, proceed to edit
              </button>
            </div>
          </div>
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-6 h-6 text-emerald-500 animate-spin" />
        </div>
      ) : (
        <div className="space-y-8">
          {groupedImages.map((group) => (
            <section key={group.page}>
              {/* Page section header */}
              <div className="flex items-center gap-3 mb-4">
                <h2 className="text-lg font-bold text-gray-900">{group.label}</h2>
                <span className="text-xs text-gray-400 bg-gray-100 px-2 py-0.5 rounded-full">
                  {group.images.length} image{group.images.length !== 1 ? 's' : ''}
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {group.images.map((si) => {
                  const currentUrl = getDisplayUrl(si.id);
                  const isOverridden = !!overrides[si.id];
                  const isProtected = PROTECTED_IDS.has(si.id);
                  const isLocked = isProtected && !unlockedIds.has(si.id);
                  const hasDefault = !!staticSiteImages.find((s) => s.id === si.id)?.url;

                  return (
                    <div key={si.id} className={`bg-white border rounded-xl shadow-sm overflow-hidden ${isProtected ? 'border-amber-200' : 'border-gray-200'}`}>
                      {/* Preview */}
                      <div className="h-36 bg-gray-100 relative overflow-hidden flex items-center justify-center">
                        {currentUrl ? (
                          <img src={currentUrl} alt={si.alt} className="w-full h-full object-cover" />
                        ) : (
                          <div className="text-gray-300 flex flex-col items-center gap-1">
                            <ImageIcon className="w-10 h-10" />
                            <span className="text-xs text-gray-400">No image set</span>
                          </div>
                        )}
                        {/* Status badges */}
                        <div className="absolute top-2 right-2 flex gap-1">
                          {isProtected && (
                            <span className="px-1.5 py-0.5 bg-amber-500 text-white text-[10px] rounded font-bold shadow-sm flex items-center gap-1">
                              <Lock className="w-2.5 h-2.5" />
                              BACKGROUND
                            </span>
                          )}
                          {isOverridden && (
                            <span className="px-1.5 py-0.5 bg-blue-500 text-white text-[10px] rounded font-bold shadow-sm">
                              CUSTOM
                            </span>
                          )}
                          {!currentUrl && !isProtected && (
                            <span className="px-1.5 py-0.5 bg-amber-500 text-white text-[10px] rounded font-bold shadow-sm">
                              EMPTY
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Info + controls */}
                      <div className="p-4">
                        <h3 className="text-sm font-semibold text-gray-900 mb-0.5">{si.slot}</h3>
                        <code className="text-emerald-600 text-[10px] font-mono bg-emerald-50 px-1.5 py-0.5 rounded">{si.id}</code>

                        {isLocked ? (
                          /* ── Protected & locked: show lock overlay instead of edit controls ── */
                          <div className="mt-3">
                            <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-center">
                              <Lock className="w-4 h-4 text-amber-500 mx-auto mb-1.5" />
                              <p className="text-amber-800 text-[11px] font-semibold leading-snug mb-0.5">
                                Page background gradient image
                              </p>
                              <p className="text-amber-600 text-[10px] leading-snug mb-2.5">
                                Do not change unless necessary. Changes cannot be easily reverted.
                              </p>
                              <button
                                onClick={() => setConfirmUnlockId(si.id)}
                                className="px-3 py-1.5 text-[11px] font-semibold text-amber-700 bg-amber-100 hover:bg-amber-200 border border-amber-300 rounded-md transition flex items-center gap-1.5 mx-auto"
                              >
                                <Unlock className="w-3 h-3" />
                                Unlock to edit
                              </button>
                            </div>
                          </div>
                        ) : (
                          /* ── Unlocked: normal edit controls ── */
                          <>
                            {isProtected && !isLocked && (
                              <div className="flex items-center gap-1.5 mt-2 mb-1">
                                <ShieldAlert className="w-3 h-3 text-amber-500" />
                                <span className="text-amber-600 text-[10px] font-medium">
                                  Unlocked for this session — be careful
                                </span>
                              </div>
                            )}
                            <div className="flex items-center gap-1.5 mt-3">
                              <input
                                type="text"
                                value={editValues[si.id] ?? overrides[si.id] ?? si.url}
                                onChange={(e) => setEditValues((prev) => ({ ...prev, [si.id]: e.target.value }))}
                                placeholder={hasDefault ? 'Using default image' : 'Paste image URL...'}
                                className="flex-1 min-w-0 bg-gray-50 border border-gray-300 rounded px-2.5 py-1.5 text-gray-900 text-xs focus:outline-none focus:border-emerald-500 transition"
                              />
                              <label className="p-1.5 text-gray-400 hover:text-gray-700 cursor-pointer transition rounded hover:bg-gray-100" title="Upload image">
                                {uploading === si.id ? (
                                  <Loader2 className="w-4 h-4 animate-spin" />
                                ) : (
                                  <Upload className="w-4 h-4" />
                                )}
                                <input
                                  type="file"
                                  accept="image/*"
                                  className="hidden"
                                  onChange={(e) => {
                                    const file = e.target.files?.[0];
                                    if (file) handleUpload(si.id, file);
                                  }}
                                />
                              </label>
                              <button
                                onClick={() => handleSave(si.id)}
                                disabled={saving === si.id}
                                className="p-1.5 text-gray-400 hover:text-emerald-600 disabled:opacity-30 transition rounded hover:bg-emerald-50"
                                title="Save"
                              >
                                {saving === si.id ? (
                                  <Loader2 className="w-4 h-4 animate-spin" />
                                ) : saved === si.id ? (
                                  <Check className="w-4 h-4 text-emerald-600" />
                                ) : (
                                  <Save className="w-4 h-4" />
                                )}
                              </button>
                              {isOverridden && (
                                <button
                                  onClick={() => handleResetToDefault(si.id)}
                                  className="p-1.5 text-gray-400 hover:text-amber-600 transition rounded hover:bg-amber-50"
                                  title="Reset to default"
                                >
                                  <RotateCcw className="w-4 h-4" />
                                </button>
                              )}
                            </div>
                          </>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </section>
          ))}
        </div>
      )}
    </div>
  );
}
