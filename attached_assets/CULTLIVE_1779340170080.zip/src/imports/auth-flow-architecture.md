Welcome → Auth Flow Architecture
1. Screen routing (App.tsx — UnauthenticatedFlow)
A simple useState drives a 3-screen state machine:

"welcome" → "signin" | "signup"
AuthGate checks auth state (loading / unauthenticated / onboarding / tour / authenticated) and renders UnauthenticatedFlow when not logged in
UnauthenticatedFlow holds screen state: "welcome" renders WelcomeScreen, anything else renders AuthScreen with initialMode
WelcomeScreen has two callbacks: onSignIn → setScreen("signin") and onGetStarted → setScreen("signup")
AuthScreen receives initialMode ("signin" | "signup") and onBack → setScreen("welcome")
2. WelcomeScreen layout (rule of thirds)
The screen is a fixed inset-0 full-viewport container with three flex spacers creating a rule-of-thirds layout:

┌──────────────────────┐
│                      │  ← flex-[1] spacer (top third)
│     🔷 SF Logo       │  ← Brand group at 1/3 line
│   SnatchedFit        │
│   "your body, your   │
│      rules"          │
│                      │  ← flex-[1] spacer (middle third)
│  Track Smarter.      │  ← CTA group at 2/3 line
│  Get Snatched.       │
│  subtitle text       │
│  [Sign In] [Get Started] │
│                      │  ← flex-[1] spacer (bottom third)
└──────────────────────┘
Entrance animation sequence (all gated by a 200ms ready flag so blobs render first):

0.1s — Logo scales in (spring: stiffness 160, damping 16) from scale: 0.6, opacity: 0
0.4s — Logo's S path drops from top-left with rotation (x:-120, y:-80, rotate:-35), F path flies from bottom-right
0.8s — Wordmark fades up (y: 20 → 0), then runs a 2-phase animation:
Phase 1 "snatched" — typewriter effect: 8 letter paths appear sequentially (0.12s each) with a sliding cursor rect
Phase 2 "Fit" — F spins in (rotate -180°), i stem grows up (scaleY: 0→1), i dot drops from above, t flips in (scaleX: 0→1). All use bouncy easing [0.34, 1.56, 0.64, 1]
1.0s — CTA group slides up (spring: stiffness 140, damping 22) from y: 60
1.4s — Tagline fades in to opacity: 0.7
CTA buttons:

Sign In — glassmorphic outline: rgba(255,255,255,0.12) bg, blur(16px), 1px solid rgba(255,255,255,0.2) border, cream text
Get Started — solid gradient: linear-gradient(135deg, #3D8B7A, #4ECDB5), white text, teal box-shadow, ArrowRight icon
3. WelcomeBlobsBg — animated background
A pure CSS animation blob system (no Motion.js — runs on compositor thread for 60fps):

7 blobs generated from a seeded PRNG (seed: 42) for deterministic layout
Sizes: 45–75 vmin (elliptical, separate rx/ry)
Blur: 35–55px per blob
Colors: 4-color palette (teal #3D8B7A, steel-blue #2D5F8A, mint #4ECDB5, golden #F9D779) with OKLCH color space radial gradients (inner/mid/outer stops with hue/chroma/lightness jitter)
Background: #E8EBE9 (light warm gray)
Animation: CSS @keyframes blob-drift with --dx/--dy custom properties per blob, 18–30s durations, negative delays (start mid-animation)
Grain overlay: inline SVG feTurbulence noise at 12% opacity with mix-blend-mode: overlay
Container has pointer-events: none
4. AuthScreen layout
Dark themed (#1A1A2E background) with a simplified blob background (4 static positioned blobs — no CSS animation, just blurred radial gradients):

Teal blob top-left, steel-blue top-right, mint bottom-left, golden bottom-right
Same film grain overlay
Layout (top to bottom):

Back button — glassmorphic circle (top-left, rgba(255,255,255,0.10) + blur), ChevronLeft icon
Hero section — Logo in a rounded teal-to-mint gradient container (64×64px), wordmark below, subtitle, then 3 feature pills ("Smart Nutrition", "Workout Log", "TDEE Tracking") in glassmorphic capsules
Form card — glassmorphic container (rgba(255,255,255,0.07), blur(20px) saturate(140%), 0.5px white border):
Mode toggle — rgba(255,255,255,0.06) pill with two buttons, active state uses teal-to-mint gradient
Name field (signup only, AnimatePresence height animation)
Email field
Password field with show/hide toggle
Error banner — red-tinted glassmorphic alert
Submit button — teal-to-mint gradient, ArrowRight icon, Loader2 spinner when loading
Footer — "Terms of Service" at 10px, 30% opacity
Input styling: rgba(255,255,255,0.08) background, 1px solid rgba(255,255,255,0.12) border, cream text. Focus state: mint border color + 0 0 0 3px rgba(78,205,181,0.35) ring.

5. Color tokens used throughout
Token	Hex	Usage
Cream	#FFFCF5	All text on dark backgrounds
Teal (primary)	#3D8B7A	Gradient start, shadows
Mint	#4ECDB5	Gradient end, focus rings, accents
Golden	#F9D779	Gradient text ("Get Snatched."), blob
Steel Blue	#5B7B9A	Secondary blob
Dark bg	#1A1A2E	Auth screen background
Blob bg	#E8EBE9	Welcome screen background
6. Key dependencies
motion/react (Motion library) — spring animations, AnimatePresence
lucide-react — ArrowRight, ChevronLeft, Eye/EyeOff, Loader2, Dumbbell, Flame, Salad
Custom SnatchedLogo / SnatchedWordmark — SVG path-based, self-contained with spring physics
WelcomeBlobsBg — zero dependencies, pure CSS animations injected via document.createElement("style")
All four files are self-contained and portable — WelcomeScreen.tsx, WelcomeBlobsBg.tsx, SnatchedLogo.tsx, and AuthScreen.tsx. The only app-specific wiring is the useAuth() hook in AuthScreen (swap that for your own auth provider) and the UnauthenticatedFlow state machine pattern in your root component.