import { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useNavigate, useLocation } from 'react-router';
import { X, ArrowRight, Layers, ChevronUp, ChevronDown } from 'lucide-react';
import { modeConfig } from '../data/mock-data';
import { useMode } from '../context/ModeContext';
import type { UIMode } from '../context/ModeContext';
import { getDesignTokens, modeDesignTokens } from '../data/mode-styles';
import { CIcon } from './CIcon';
import { ImageWithFallback } from './figma/ImageWithFallback';

// Card data with unique background images per mode
const STACK_CARDS = [
  {
    key: 'degen' as const,
    label: 'Night',
    labelZh: '夜行者',
    tagline: 'Nightlife, parties & underground scenes',
    image: 'https://images.unsplash.com/photo-1616394158624-a2ba9cfe2994?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxIb25nJTIwS29uZyUyMG5lb24lMjBuaWdodGxpZmUlMjBzdHJlZXQlMjBkYXJrfGVufDF8fHx8MTc3MzA0NTM4MHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    gradient: 'linear-gradient(135deg, #EDFF00 0%, #D600FF 100%)',
    overlayColor: 'rgba(10,10,10,0.55)',
  },
  {
    key: 'family' as const,
    label: 'Family',
    labelZh: '親子',
    tagline: 'Kid-friendly adventures, parks & museums',
    image: 'https://images.unsplash.com/photo-1756657266978-c15f15bd3266?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxIb25nJTIwS29uZyUyMGZhbWlseSUyMGNoaWxkcmVuJTIwcGFyayUyMHBsYXlncm91bmR8ZW58MXx8fHwxNzczMDQ1Mzg0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    gradient: 'linear-gradient(135deg, #FF8C42 0%, #FFB347 100%)',
    overlayColor: 'rgba(45,42,50,0.45)',
  },
  {
    key: 'artsy' as const,
    label: 'Art & Design',
    labelZh: '藝術',
    tagline: 'Galleries, exhibitions & creative studios',
    image: 'https://images.unsplash.com/photo-1767294274414-5e1e6c3974e9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBhcnQlMjBnYWxsZXJ5JTIwd2hpdGUlMjBleGhpYml0aW9uJTIwc3BhY2V8ZW58MXx8fHwxNzczMDQ1Mzg3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    gradient: 'linear-gradient(135deg, #8338EC 0%, #3d2b7a 100%)',
    overlayColor: 'rgba(26,26,26,0.4)',
  },
  {
    key: 'foodie' as const,
    label: 'Food',
    labelZh: '美食',
    tagline: 'Restaurants, pop-ups & night markets',
    image: 'https://images.unsplash.com/photo-1746105866475-33b40bcc24d1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxIb25nJTIwS29uZyUyMGRpbSUyMHN1bSUyMGZvb2QlMjBtYXJrZXQlMjByZXN0YXVyYW50fGVufDF8fHx8MTc3MzA0NTM4OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    gradient: 'linear-gradient(135deg, #FB5607 0%, #1A1208 100%)',
    overlayColor: 'rgba(26,18,8,0.5)',
  },
  {
    key: 'lifestyle' as const,
    label: 'Lifestyle',
    labelZh: '生活',
    tagline: 'Run clubs, wellness & creative meetups',
    image: 'https://images.unsplash.com/photo-1760774714285-61ff516f86c5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvdXRkb29yJTIweW9nYSUyMHdlbGxuZXNzJTIwc3VucmlzZSUyMGdyb3VwfGVufDF8fHx8MTc3MzA0NTM5Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    gradient: 'linear-gradient(135deg, #A67BB8 0%, #7C5295 100%)',
    overlayColor: 'rgba(10,10,10,0.4)',
  },
];

const totalCards = STACK_CARDS.length;

// ─── Trigger Button (replaces ModeSelector compact in header) ───

export function ModeStackTrigger({ onClick }: { onClick: () => void }) {
  const { currentMode } = useMode();
  const config = currentMode ? (modeConfig as any)[currentMode] : null;
  const tokens = getDesignTokens(currentMode);

  return (
    <motion.button
      onClick={onClick}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      className="relative flex items-center gap-2 px-3 py-1.5 cursor-pointer transition-all"
      style={{
        borderRadius: '12px',
        backgroundColor: config ? `${config.color}15` : 'rgba(0,0,0,0.05)',
        border: `1px solid ${config ? `${config.color}25` : 'rgba(0,0,0,0.08)'}`,
      }}
    >
      {/* Stacked cards icon */}
      <div className="relative w-5 h-5 flex items-center justify-center">
        {config ? (
          <CIcon id={config.emoji} size={15} mode={currentMode as any} />
        ) : (
          <Layers size={15} style={{ color: tokens.textSecondary }} />
        )}
      </div>
      <span
        className="text-xs font-medium hidden sm:inline"
        style={{
          color: config ? config.color : tokens.textSecondary,
          fontFamily: tokens.headingFont,
        }}
      >
        {config ? config.label : 'Modes'}
      </span>
      {/* 3 mini stacked bars */}
      <div className="flex flex-col gap-[2px] ml-0.5">
        <div className="w-3 h-[2px] rounded-full" style={{ backgroundColor: config?.color || tokens.textMuted, opacity: 0.8 }} />
        <div className="w-2.5 h-[2px] rounded-full" style={{ backgroundColor: config?.color || tokens.textMuted, opacity: 0.5 }} />
        <div className="w-2 h-[2px] rounded-full" style={{ backgroundColor: config?.color || tokens.textMuted, opacity: 0.3 }} />
      </div>
    </motion.button>
  );
}

// ─── Full-Screen Stacked Card Overlay ───

interface ModeCardStackProps {
  isOpen: boolean;
  onClose: () => void;
}

export function ModeCardStack({ isOpen, onClose }: ModeCardStackProps) {
  const { currentMode, setMode } = useMode();
  const navigate = useNavigate();
  const location = useLocation();
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);
  // frontIndex tracks which card is on top — scroll to cycle
  const [frontIndex, setFrontIndex] = useState(totalCards - 1);
  const [isScrolling, setIsScrolling] = useState(false);

  const cycleNext = useCallback(() => {
    if (isScrolling) return;
    setIsScrolling(true);
    setFrontIndex((prev) => (prev + 1) % totalCards);
    setTimeout(() => setIsScrolling(false), 400);
  }, [isScrolling]);

  const cyclePrev = useCallback(() => {
    if (isScrolling) return;
    setIsScrolling(true);
    setFrontIndex((prev) => (prev - 1 + totalCards) % totalCards);
    setTimeout(() => setIsScrolling(false), 400);
  }, [isScrolling]);

  // Wheel handler for rolodex cycling
  const handleWheel = useCallback((e: React.WheelEvent) => {
    e.preventDefault();
    if (Math.abs(e.deltaY) < 15) return;
    if (e.deltaY > 0) {
      cycleNext();
    } else {
      cyclePrev();
    }
  }, [cycleNext, cyclePrev]);

  const handleSelect = useCallback((key: string) => {
    if (key === currentMode) {
      // Deactivate
      setMode(null);
      if (location.pathname === '/lifestyle') navigate('/');
      onClose();
      return;
    }
    setMode(key as UIMode);
    if (key === 'lifestyle') {
      navigate('/lifestyle');
    } else if (location.pathname === '/lifestyle') {
      navigate('/');
    }
    onClose();
  }, [currentMode, setMode, navigate, location, onClose]);

  // Compute depth of each card relative to frontIndex (circular)
  const getDepth = (i: number) => {
    // depth 0 = front card, depth 1 = one behind, etc.
    return (frontIndex - i + totalCards) % totalCards;
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="fixed inset-0 z-[1150] overflow-hidden"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          onWheel={handleWheel}
        >
          {/* Backdrop */}
          <motion.div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={onClose}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          />

          {/* Close button */}
          <motion.button
            className="absolute top-5 right-5 z-[1160] flex items-center justify-center w-11 h-11 rounded-full backdrop-blur-md border border-white/20 cursor-pointer"
            onClick={onClose}
            initial={{ opacity: 0, scale: 0.8, backgroundColor: 'rgba(255,255,255,0.1)' }}
            animate={{ opacity: 1, scale: 1, backgroundColor: 'rgba(255,255,255,0.1)' }}
            exit={{ opacity: 0, scale: 0.8 }}
            transition={{ delay: 0.15 }}
            whileHover={{ scale: 1.1, backgroundColor: 'rgba(255,255,255,0.2)' }}
          >
            <X size={20} color="#fff" />
          </motion.button>

          {/* CULTIVE branding */}
          <motion.div
            className="absolute top-5 left-5 z-[1160]"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ delay: 0.1 }}
          >
            <span
              style={{
                fontFamily: "'Archivo Black', sans-serif",
                fontSize: '1.1rem',
                color: '#fff',
                letterSpacing: '-0.03em',
              }}
            >
              CULTIVE
            </span>
            <span
              className="ml-2"
              style={{
                fontFamily: "'Noto Sans HK', sans-serif",
                fontSize: '0.55rem',
                color: 'rgba(255,255,255,0.5)',
                letterSpacing: '0.1em',
              }}
            >
              文化活
            </span>
          </motion.div>

          {/* "Choose your vibe" label */}
          <motion.div
            className="absolute top-5 left-1/2 -translate-x-1/2 z-[1160] hidden md:block"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ delay: 0.2 }}
          >
            <span
              style={{
                fontFamily: "'Inter', sans-serif",
                fontSize: '0.7rem',
                color: 'rgba(255,255,255,0.45)',
                letterSpacing: '0.15em',
                textTransform: 'uppercase',
                fontWeight: 500,
              }}
            >
              Choose your vibe
            </span>
          </motion.div>

          {/* Scroll hint */}
          <motion.div
            className="absolute bottom-6 left-1/2 -translate-x-1/2 z-[1160] hidden md:flex flex-col items-center gap-1"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            transition={{ delay: 0.5 }}
          >
            <button
              className="flex items-center justify-center w-8 h-8 rounded-full bg-white/10 backdrop-blur-md border border-white/20 cursor-pointer hover:bg-white/20 transition-colors"
              onClick={cyclePrev}
            >
              <ChevronUp size={16} color="#fff" />
            </button>
            {/* Dot indicators */}
            <div className="flex gap-1.5 py-1">
              {STACK_CARDS.map((card, i) => {
                const config = (modeConfig as any)[card.key];
                const isFront = i === frontIndex;
                return (
                  <button
                    key={card.key}
                    className="transition-all duration-300 cursor-pointer"
                    style={{
                      width: isFront ? 20 : 6,
                      height: 6,
                      borderRadius: 3,
                      backgroundColor: isFront ? config.color : 'rgba(255,255,255,0.3)',
                    }}
                    onClick={() => {
                      if (!isScrolling) {
                        setIsScrolling(true);
                        setFrontIndex(i);
                        setTimeout(() => setIsScrolling(false), 400);
                      }
                    }}
                  />
                );
              })}
            </div>
            <button
              className="flex items-center justify-center w-8 h-8 rounded-full bg-white/10 backdrop-blur-md border border-white/20 cursor-pointer hover:bg-white/20 transition-colors"
              onClick={cycleNext}
            >
              <ChevronDown size={16} color="#fff" />
            </button>
            <span
              style={{
                fontFamily: "'Inter', sans-serif",
                fontSize: '0.55rem',
                color: 'rgba(255,255,255,0.35)',
                letterSpacing: '0.1em',
                textTransform: 'uppercase',
                marginTop: '2px',
              }}
            >
              Scroll to browse
            </span>
          </motion.div>

          {/* Cards Container */}
          <div className="absolute inset-0 flex items-center justify-center">
            {/* Desktop: perspective fan layout with scroll cycling */}
            <div className="hidden md:block relative w-full max-w-[1100px] mx-auto px-8" style={{ perspective: '1200px' }}>
              <div className="relative" style={{ height: '75vh', maxHeight: '680px' }}>
                {STACK_CARDS.map((card, i) => {
                  const isActive = currentMode === card.key;
                  const isHovered = hoveredIndex === i;
                  const config = (modeConfig as any)[card.key];
                  const tokens = (modeDesignTokens as any)[card.key];

                  // Circular depth: 0 = front, 1 = one back, etc.
                  const depth = getDepth(i);
                  const isFront = depth === 0;

                  // Position based on depth — front card at 0, others stacked behind
                  const topPosition = depth * 48;
                  // Scale decreases with depth
                  const scale = 1 - depth * 0.02;
                  // Opacity dims for cards far back
                  const cardOpacity = depth <= 3 ? 1 - depth * 0.08 : 0.6;

                  return (
                    <motion.div
                      key={card.key}
                      className="absolute left-0 right-0 cursor-pointer overflow-hidden"
                      style={{
                        height: '100%',
                        borderRadius: '24px',
                        zIndex: totalCards - depth,
                        transformOrigin: 'center top',
                      }}
                      initial={{
                        y: '110vh',
                        scale: 0.85,
                        rotateX: 5,
                        opacity: 0,
                      }}
                      animate={{
                        y: topPosition,
                        scale: isHovered && isFront ? scale + 0.005 : scale,
                        rotateX: 0,
                        opacity: cardOpacity,
                      }}
                      exit={{
                        y: '110vh',
                        scale: 0.85,
                        rotateX: 5,
                        opacity: 0,
                      }}
                      transition={{
                        type: 'spring',
                        stiffness: 280,
                        damping: 30,
                        opacity: { duration: 0.3 },
                      }}
                      onHoverStart={() => setHoveredIndex(i)}
                      onHoverEnd={() => setHoveredIndex(null)}
                      onClick={() => handleSelect(card.key)}
                    >
                      {/* Background image */}
                      <div className="absolute inset-0">
                        <ImageWithFallback
                          src={card.image}
                          alt={card.label}
                          className="h-full w-full object-cover"
                          style={{ filter: 'brightness(0.7) saturate(1.15)' }}
                        />
                        {/* Color overlay */}
                        <div
                          className="absolute inset-0"
                          style={{
                            background: card.overlayColor,
                          }}
                        />
                        {/* Bottom gradient for text legibility */}
                        <div
                          className="absolute inset-0"
                          style={{
                            background: `linear-gradient(to top, rgba(0,0,0,0.8) 0%, rgba(0,0,0,0.2) 35%, transparent 60%)`,
                          }}
                        />
                        {/* Mode color accent strip at top */}
                        <div
                          className="absolute top-0 left-0 right-0 h-1"
                          style={{ background: card.gradient }}
                        />
                      </div>

                      {/* Content */}
                      <div className="relative h-full flex flex-col justify-end p-8 lg:p-10">
                        {/* Active indicator */}
                        {isActive && (
                          <motion.div
                            className="absolute top-6 right-6 px-3 py-1 flex items-center gap-1.5"
                            initial={{ opacity: 0, scale: 0.8 }}
                            animate={{ opacity: 1, scale: 1 }}
                            style={{
                              backgroundColor: config.color,
                              borderRadius: '9999px',
                            }}
                          >
                            <div className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                            <span style={{ fontSize: '0.65rem', color: '#fff', fontWeight: 600, letterSpacing: '0.05em' }}>
                              ACTIVE
                            </span>
                          </motion.div>
                        )}

                        {/* Mode icon + label badge */}
                        <div className="flex items-center gap-2 mb-3">
                          <div
                            className="flex items-center gap-1.5 px-3 py-1.5"
                            style={{
                              backgroundColor: `${config.color}30`,
                              backdropFilter: 'blur(12px)',
                              borderRadius: '10px',
                              border: `1px solid ${config.color}40`,
                            }}
                          >
                            <CIcon id={config.emoji} size={14} />
                            <span style={{ fontSize: '0.7rem', color: '#fff', fontWeight: 600, letterSpacing: '0.05em' }}>
                              {card.labelZh}
                            </span>
                          </div>
                        </div>

                        {/* Title */}
                        <h2
                          style={{
                            fontFamily: tokens.headingFont,
                            fontSize: 'clamp(2rem, 4vw, 3.5rem)',
                            fontWeight: 800,
                            color: '#ffffff',
                            letterSpacing: '-0.03em',
                            lineHeight: 1.05,
                            marginBottom: '0.5rem',
                          }}
                        >
                          {card.label}
                        </h2>

                        {/* Tagline */}
                        <p
                          style={{
                            fontFamily: "'Inter', sans-serif",
                            fontSize: '0.95rem',
                            color: 'rgba(255,255,255,0.6)',
                            lineHeight: 1.5,
                            maxWidth: '400px',
                            marginBottom: '1.25rem',
                          }}
                        >
                          {card.tagline}
                        </p>

                        {/* CTA */}
                        <motion.div
                          className="flex items-center gap-2"
                          initial={{ opacity: 0.7 }}
                          whileHover={{ opacity: 1 }}
                        >
                          <span
                            className="flex items-center gap-2 px-5 py-2.5"
                            style={{
                              backgroundColor: config.color,
                              borderRadius: '12px',
                              color: '#fff',
                              fontSize: '0.8rem',
                              fontWeight: 600,
                              fontFamily: "'Inter', sans-serif",
                            }}
                          >
                            {isActive ? 'Currently Active' : 'Explore'} <ArrowRight size={14} />
                          </span>
                        </motion.div>
                      </div>

                      {/* Hover glow effect */}
                      <AnimatePresence>
                        {isHovered && (
                          <motion.div
                            className="absolute inset-0 pointer-events-none"
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            style={{
                              boxShadow: `inset 0 0 80px ${config.color}15`,
                              borderRadius: '24px',
                            }}
                          />
                        )}
                      </AnimatePresence>
                    </motion.div>
                  );
                })}
              </div>
            </div>

            {/* Mobile: vertical scrollable stack */}
            <div className="md:hidden w-full h-full overflow-y-auto pt-16 pb-8 px-4">
              <div className="flex flex-col gap-3">
                {STACK_CARDS.map((card, i) => {
                  const isActive = currentMode === card.key;
                  const config = (modeConfig as any)[card.key];
                  const tokens = (modeDesignTokens as any)[card.key];

                  return (
                    <motion.div
                      key={card.key}
                      className="relative overflow-hidden cursor-pointer"
                      style={{ borderRadius: '20px', minHeight: '140px' }}
                      initial={{ opacity: 0, y: 40, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 40, scale: 0.95 }}
                      transition={{
                        type: 'spring',
                        stiffness: 250,
                        damping: 25,
                        delay: i * 0.07,
                      }}
                      whileTap={{ scale: 0.97 }}
                      onClick={() => handleSelect(card.key)}
                    >
                      {/* Background */}
                      <div className="absolute inset-0">
                        <ImageWithFallback
                          src={card.image}
                          alt={card.label}
                          className="h-full w-full object-cover"
                          style={{ filter: 'brightness(0.6) saturate(1.1)' }}
                        />
                        <div className="absolute inset-0" style={{ background: card.overlayColor }} />
                        <div
                          className="absolute inset-0"
                          style={{ background: 'linear-gradient(to right, rgba(0,0,0,0.6) 0%, rgba(0,0,0,0.2) 100%)' }}
                        />
                        <div className="absolute top-0 left-0 right-0 h-[3px]" style={{ background: card.gradient }} />
                      </div>

                      {/* Content */}
                      <div className="relative flex items-center justify-between p-5">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1.5">
                            <div
                              className="flex items-center gap-1 px-2 py-0.5"
                              style={{
                                backgroundColor: `${config.color}30`,
                                borderRadius: '6px',
                                border: `1px solid ${config.color}40`,
                              }}
                            >
                              <CIcon id={config.emoji} size={11} />
                              <span style={{ fontSize: '0.55rem', color: '#fff', fontWeight: 600 }}>{card.labelZh}</span>
                            </div>
                            {isActive && (
                              <div className="flex items-center gap-1 px-2 py-0.5" style={{ backgroundColor: config.color, borderRadius: '9999px' }}>
                                <div className="w-1 h-1 rounded-full bg-white animate-pulse" />
                                <span style={{ fontSize: '0.5rem', color: '#fff', fontWeight: 600 }}>ACTIVE</span>
                              </div>
                            )}
                          </div>
                          <h3
                            style={{
                              fontFamily: tokens.headingFont,
                              fontSize: '1.5rem',
                              fontWeight: 800,
                              color: '#fff',
                              letterSpacing: '-0.02em',
                              lineHeight: 1.1,
                              marginBottom: '0.25rem',
                            }}
                          >
                            {card.label}
                          </h3>
                          <p style={{ fontSize: '0.7rem', color: 'rgba(255,255,255,0.55)', lineHeight: 1.4 }}>
                            {card.tagline}
                          </p>
                        </div>
                        <ArrowRight size={20} color="rgba(255,255,255,0.5)" />
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

// ─── Inline version for HomePage (replaces DefaultModeCards grid) ───

export function ModeCardStackInline() {
  const { currentMode, setMode } = useMode();
  const navigate = useNavigate();
  const location = useLocation();
  const tokens = getDesignTokens(null);
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null);

  const handleSelect = useCallback((key: string) => {
    setMode(key as UIMode);
    if (key === 'lifestyle') {
      navigate('/lifestyle');
    } else if (location.pathname === '/lifestyle') {
      navigate('/');
    }
  }, [setMode, navigate, location]);

  return (
    <section className="px-4 sm:px-6 lg:px-8 py-6 sm:py-16 max-w-[1440px] mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
      >
        <div className="flex items-end justify-between mb-4 sm:mb-8">
          <div>
            <h2 style={{ fontFamily: "'Inter', sans-serif", fontSize: 'clamp(1.2rem, 2.5vw, 1.8rem)', color: tokens.textPrimary, fontWeight: 600, letterSpacing: '-0.02em' }}>
              Choose your vibe
            </h2>
            <p className="mt-1 sm:mt-1.5 hidden sm:block" style={{ fontSize: '0.875rem', color: tokens.textMuted }}>
              Switch modes to transform your entire experience
            </p>
          </div>
        </div>

        {/* Desktop: stacked cards with hover-expand */}
        <div className="hidden sm:block relative overflow-hidden transition-[height] duration-500 ease-out" style={{ height: `${56 * (totalCards - 1) + 300 + (hoveredIndex !== null ? 100 : 0)}px`, perspective: '1000px' }}>
          {STACK_CARDS.map((card, i) => {
            const config = (modeConfig as any)[card.key];
            const mTokens = (modeDesignTokens as any)[card.key];
            const isHovered = hoveredIndex === i;
            const isExpanded = expandedIndex === i;

            // Stacking: cards fan downward, later cards on top
            // When a card is hovered, cards above it (higher index / on top) spread apart
            const expandAmount = 100;
            let computedTop = i * 56;
            if (hoveredIndex !== null) {
              if (i === hoveredIndex) {
                // Hovered card lifts up slightly
                computedTop = computedTop - 6;
              } else if (i > hoveredIndex) {
                // Cards on top of the hovered one push down to reveal it
                computedTop = computedTop + expandAmount;
              }
            }
            const scale = 1 - (totalCards - 1 - i) * 0.015;

            return (
              <motion.div
                key={card.key}
                className="absolute left-0 right-0 cursor-pointer overflow-hidden group"
                style={{
                  height: '100%',
                  borderRadius: '20px',
                  zIndex: isHovered ? 20 : i + 1,
                  transformOrigin: 'center top',
                  boxShadow: isHovered
                    ? `0 20px 60px rgba(0,0,0,0.35), 0 0 0 1px ${config.color}30`
                    : '0 4px 20px rgba(0,0,0,0.15)',
                }}
                initial={{ opacity: 0, y: 60 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08, type: 'spring', stiffness: 300, damping: 30 }}
                animate={{
                  top: computedTop,
                  scale: isHovered ? 1.01 : scale,
                }}
                onHoverStart={() => {
                  setHoveredIndex(i);
                  setExpandedIndex(i);
                }}
                onHoverEnd={() => {
                  setHoveredIndex(null);
                  setExpandedIndex(null);
                }}
                onClick={() => handleSelect(card.key)}
              >
                {/* BG image */}
                <div className="absolute inset-0">
                  <ImageWithFallback
                    src={card.image}
                    alt={card.label}
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                    style={{ filter: 'brightness(0.55) saturate(1.2)' }}
                  />
                  <div className="absolute inset-0" style={{ background: card.overlayColor }} />
                  <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.75) 0%, rgba(0,0,0,0.15) 50%, transparent 100%)' }} />
                  <div className="absolute top-0 left-0 right-0 h-[3px]" style={{ background: card.gradient }} />
                </div>

                {/* Content */}
                <div className="relative h-full flex items-end p-6 lg:p-8">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <div
                        className="flex items-center gap-1.5 px-2.5 py-1"
                        style={{
                          backgroundColor: `${config.color}25`,
                          backdropFilter: 'blur(8px)',
                          borderRadius: '8px',
                          border: `1px solid ${config.color}35`,
                        }}
                      >
                        <CIcon id={config.emoji} size={12} />
                        <span style={{ fontSize: '0.6rem', color: '#fff', fontWeight: 600, letterSpacing: '0.05em' }}>
                          {card.labelZh}
                        </span>
                      </div>
                    </div>
                    <h3
                      style={{
                        fontFamily: mTokens.headingFont,
                        fontSize: 'clamp(1.5rem, 3vw, 2.5rem)',
                        fontWeight: 800,
                        color: '#fff',
                        letterSpacing: '-0.02em',
                        lineHeight: 1.05,
                        marginBottom: '0.35rem',
                      }}
                    >
                      {card.label}
                    </h3>
                    <p
                      className="transition-opacity duration-300"
                      style={{
                        fontSize: '0.85rem',
                        color: 'rgba(255,255,255,0.55)',
                        lineHeight: 1.5,
                        maxWidth: '350px',
                        opacity: isHovered ? 1 : 0.7,
                      }}
                    >
                      {card.tagline}
                    </p>
                  </div>

                  <motion.div
                    className="flex items-center gap-2"
                    animate={{ x: isHovered ? 0 : 10, opacity: isHovered ? 1 : 0 }}
                    transition={{ duration: 0.2 }}
                  >
                    <span
                      className="flex items-center gap-2 px-4 py-2 whitespace-nowrap"
                      style={{
                        backgroundColor: config.color,
                        borderRadius: '10px',
                        color: '#fff',
                        fontSize: '0.75rem',
                        fontWeight: 600,
                      }}
                    >
                      Explore <ArrowRight size={13} />
                    </span>
                  </motion.div>
                </div>

                {/* Hover glow border effect */}
                <AnimatePresence>
                  {isHovered && (
                    <motion.div
                      className="absolute inset-0 pointer-events-none"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      transition={{ duration: 0.25 }}
                      style={{
                        borderRadius: '20px',
                        boxShadow: `inset 0 0 60px ${config.color}12, 0 0 30px ${config.color}08`,
                        border: `1px solid ${config.color}30`,
                      }}
                    />
                  )}
                </AnimatePresence>
              </motion.div>
            );
          })}
        </div>

        {/* Mobile: vertical card list */}
        <div className="sm:hidden flex flex-col gap-3">
          {STACK_CARDS.map((card, i) => {
            const config = (modeConfig as any)[card.key];
            const mTokens = (modeDesignTokens as any)[card.key];

            return (
              <motion.div
                key={card.key}
                className="relative overflow-hidden cursor-pointer"
                style={{ borderRadius: '16px', minHeight: '120px' }}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.06 }}
                whileTap={{ scale: 0.97 }}
                onClick={() => handleSelect(card.key)}
              >
                <div className="absolute inset-0">
                  <ImageWithFallback
                    src={card.image}
                    alt={card.label}
                    className="h-full w-full object-cover"
                    style={{ filter: 'brightness(0.5) saturate(1.1)' }}
                  />
                  <div className="absolute inset-0" style={{ background: card.overlayColor }} />
                  <div className="absolute inset-0" style={{ background: 'linear-gradient(to right, rgba(0,0,0,0.5) 0%, transparent 100%)' }} />
                  <div className="absolute top-0 left-0 right-0 h-[2px]" style={{ background: card.gradient }} />
                </div>
                <div className="relative flex items-center justify-between p-4">
                  <div>
                    <div className="flex items-center gap-1.5 mb-1">
                      <CIcon id={config.emoji} size={12} />
                      <span style={{ fontSize: '0.5rem', color: 'rgba(255,255,255,0.6)', fontWeight: 600, letterSpacing: '0.05em' }}>{card.labelZh}</span>
                    </div>
                    <h3
                      style={{
                        fontFamily: mTokens.headingFont,
                        fontSize: '1.3rem',
                        fontWeight: 800,
                        color: '#fff',
                        letterSpacing: '-0.02em',
                        lineHeight: 1.1,
                      }}
                    >
                      {card.label}
                    </h3>
                    <p style={{ fontSize: '0.65rem', color: 'rgba(255,255,255,0.5)', lineHeight: 1.3, marginTop: '0.15rem' }}>
                      {card.tagline}
                    </p>
                  </div>
                  <ArrowRight size={18} color="rgba(255,255,255,0.4)" />
                </div>
              </motion.div>
            );
          })}
        </div>
      </motion.div>
    </section>
  );
}