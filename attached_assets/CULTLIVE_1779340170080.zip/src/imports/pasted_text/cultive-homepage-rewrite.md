The current cultive.city homepage has a clean but generic structure: hero banner with tagline, grid of event cards, features section, and footer CTA. Here's a full rewrite in the "good friend with taste" voice, plus a simple section-by-section wireframe spec you can copy-paste to Figma or a dev.

Rewritten Homepage Copy
Hero (above the fold):
“What’s actually worth doing in Hong Kong this week.”
(Small sub: Curated shortlist — art, music, gatherings. Updated Wednesdays.)

3 Event Picks:

“Late-night jazz in a Sheung Wan walk-up”
Feels like someone’s living room. Not LKF chaos.
Thu 7pm · Sheung Wan · [Details →]

“Indie print market under the flyover”
Young artists, cheap prints, good coffee nearby.
Sat 2-7pm · Mong Kok · [Details →]

“DJ set at hidden Central bar”
House vibes, no cover, locals only energy.
Fri 10pm · Central · [Details →]

Next Section – “If we had more time…”

Poetry reading in a Tai Hang bookshop

Flyer printing workshop in Kwun Tong

Silent disco on Cheung Chau ferry (weekend only)

Why Block:
Why this exists

HK event discovery is fragmented and exhausting.

We talk to curators, DJs, organizers — so you don’t have to.

IRL culture > endless scrolling.

CTA Block:
“Don’t fight social media algorithms.”
Get one shortlist each week. No spam.
[Email field] [Send me it →]

Footer:
cultive.city — your friend who knows what’s good
(Tiny social icons + “Made in Hong Kong”)

Wireframe Spec (Mobile-First)
text
[SECTION 1: HERO - Full viewport height]
Wordmark: cultive.city (top-left, 24px display font)
H1: "What’s actually worth doing in Hong Kong this week." (48px, centered)
Sub: "Curated shortlist — art, music, gatherings. Updated Wednesdays." (18px)
[Max 10px padding around]

[SECTION 2: 3 PICKS - Single column cards]
H2: "This weekend (3 picks)" (32px, dashed underline)
Card 1: [Tiny tag "Music"] Event title (24px) + 1-line why (16px) + "Thu 7pm · Sheung Wan" (14px) + [Details →]
Card 2: [80px space] Same format
Card 3: [80px space] Same format
[Cards: rounded corner top-left only, light off-white bg, generous whitespace]

[SECTION 3: MORE ENERGY - Text list]
H2: "If we had more energy..." (24px)
- "Poetry reading in Tai Hang" (16px, link)
- "Flyer workshop Kwun Tong" (16px, link)
- etc. [Single column, 24px line height, no bullets]

[SECTION 4: WHY - 3 bullets]
H2: "Why this exists" (24px)
• "Event discovery is fragmented" (16px)
• "We talk to curators so you don’t have to" (16px)
• "IRL culture > scrolling" (16px)

[SECTION 5: CTA - Full width block]
"Don't fight algorithms." (28px)
"Get one shortlist weekly." (16px)
[Email input 100% width] [Send → button accent color]
[48px bottom padding]

[FOOTER]
cultive.city — your friend who knows (14px)
[IG @cultivecity  WA channel  tiny icons]
Implementation Notes (for dev/designer)
Colors:

Bg: #FDFAF6 (warm off-white)

Text: #1A1A1A (dark ink)

Accent: #B2483A (brick red) or #1E3A8A (ink blue)

Borders: #E8E1D9 (90% white)

Type:

Display (headings): "Inter" or "Ginto" (or any imperfect grotesk)

Body: "SF Pro" or "Helvetica"

Sizes as noted above — BIG and friendly.

Spacing:

Sections: 80px vertical rhythm

Cards: 24px internal padding, 80px between

Mobile: 16px horizontal margins

Animations: None or micro (fade up on scroll, 0.2s). No parallax.

This goes from "AI template" to "weekly note from friend with connects" in ~2 hours of dev time. Test it — your 20-45yo culturally-minded locals/expats will instantly get it.