[
  {
    "id": "2361836",
    "title": "Zagareet: Black Merlin (BITTA/Jealous God, London) & Yadin Moha (Zagareet, Hong Kong)",
    "flyerFront": null,
    "flyerBack": null,
    "content": "Zagareet is an artist booking agency and club event series, named after the long, high-pitched wavering vocal made by women in celebration. Curated by Shereen Jolly and Nikola Skočajić, it explores where different heritages and musical preoccupations truly interlock - both between the curators themselves and the musicians and artists with whom Zagareet shares these connections.\n\nVoiced by moving the tongue rapidly while pushing air past the vocal cords to create a loud, trilling, rhythmic cry, Zagareet aims to discover where these varied backgrounds and musical interests intersect.\n\nOn March 13 at 宀 Club, Zagareet introduces the first two artists to the agency and launches the series with a party featuring those whose artistic stance and principles greatly influenced its vision: Black Merlin and Yadin Moha.\n\nMarking his long-awaited return from a DJing hiatus, Black Merlin makes his Hong Kong debut. Known as a “scholar of deep techno,” he has forged a uniquely hypnotic, textural strain of the genre, blending spectral atmospheres and ritualistic rhythm. He has also spent years on field recording expeditions in wild parts of Indonesia, building a relationship with the Kosua Tribe of Papua New Guinea. His recordings of daily life, ancient dance customs, and wildlife feature on albums like \"Hipnotik Tradisi\" and \"Kosua\". Born and raised in England, George Thompson (aka Black Merlin) does not approach this from an anthropological outsider’s perspective. Instead, mirroring Zagareet’s ethos, he seeks to listen, archive, and introduce these people and their music, weaving them into contemporary listening practices - including the nightclub.\n\nA highly respected DJ and producer, his discography spans numerous respected underground labels. He has performed throughout China, India, the US, Australia, and Europe, at venues like Berghain and Tresor, and festivals such as Japan’s Rural Festival. His releases include work on Andrew Weatherall’s Bird Scarer, Silent Servant’s Jealous God, DJ Nobu’s BITTA, as well as Berceuse Heroique, Island of the Gods, ESP Institute, and Mannequin Records—labels that have championed his dark, hypnotic, and atmospheric sound.\n\nYadin Moha has always been part of Zagareet through his ever-evolving efforts to connect contemporary electronic music with traditional motifs, subversive symbolism, and sweaty dancefloor energy. An early advocate of outsider dance music in Southeast Asia, he has pushed fringe sounds and ideas for the past fifteen years, winning over listeners one at a time at clubs like Mitsuki, Nyapi, 宀, and Golden Pudel, and festivals including Wonderfruit, Sunda, and Shi Fu Miz. He is also known for his deeply invested radio mixes on platforms such as NTS, Kiosk, Mutant, and Red Light Radio. His attention to music extends beyond the club, though the dancefloor remains central to his approach.\n\nAfter performing alongside artists like Interstellar Funk, Elena Colombi, Vladimir Ivković, and Phuong-Dan, this will be Yadin’s second time sharing the booth with Black Merlin - fittingly, nearly ten years after their previous meeting at Singapore’s seminal Headquarters club.\n\nBlack Merlin 以其獨特離幻、撲朔迷離嘅質感、充滿幽暗氛圍同祭典儀式節奏嘅 Techno 音樂見稱。多年嚟深入巴布亞新畿內亞荒野做田野錄音（field recording），同當地 Kosua 部落建立咗深厚嘅關係，記錄低佢哋嘅日常生活、古老習俗同原野生態。佢用呢段旅程嘅經驗轉化出兩張俱標誌性嘅專輯：《Hipnotik Tradisi》同埋《Kosua》。\n\n喺英國土生土長嘅 Black Merlin（原名 George Thompson）同 Zagareet 嘅理念方向一致，我哋純粹想聆聽、紀錄同埋將我哋日常遇到嘅人同音樂融入現代人嘅聆聽頻譜，喺獨立電子音樂場所中帶嚟唔同嘅聲音。\n\n佢作為一個備受尊崇嘅 DJ 同製作人，其作品常見於各大地下電子音樂廠牌如 Transmigration 入面嘅 Crystal Ceremony，佢嘅演出足跡遍佈亞洲、美洲、澳洲同歐洲，當中包括柏林著名夜店 Berghain、Tresor 同埋日本嘅 Rural Festival。\n\n除咗喺 Andrew Weatherall 嘅 Bird Scarer、Silent Servant 嘅 Jealous God 同埋 DJ Nobu 嘅 BITTA 廠牌產出過作品之外，佢嘅作品亦都出現於 Berceuse Heroique、Island of the Gods、ESP Institute、Mannequin Records 等多個推崇暗黑、迷幻同埋重氛圍感聲音嘅獨立廠牌。\n\n該晚將由 Zagareet 駐場成員 Yadin Moha 全力支援。",
    "minimumAge": 21,
    "cost": "150$ / 250$",
    "contentUrl": "/events/2361836",
    "embargoDate": null,
    "date": "2026-03-13T00:00:00.000",
    "startTime": "2026-03-13T23:00:00.000",
    "endTime": "2026-03-14T06:00:00.000",
    "interestedCount": 54,
    "lineup": "<artist id=\"65580\">Black Merlin</artist>\n<artist id=\"70850\">Yadin Moha</artist>",
    "isTicketed": true,
    "isFestival": false,
    "dateUpdated": "2026-03-11T12:54:39.927Z",
    "resaleActive": false,
    "datePosted": "2026-02-03T05:24:52.080Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2490257",
        "filename": "https://images.ra.co/d85b15667445da4475af191eb18d3b9d8fc34c44.jpg",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      },
      {
        "id": "2493235",
        "filename": "https://images.ra.co/a0f7ade0104fe7aeed15cc58a1d6cab64a744fa6.jpg",
        "alt": null,
        "type": "FLYERBACK",
        "crop": null
      }
    ],
    "venue": {
      "id": "152213",
      "name": "宀 Club",
      "address": "4F, 279 Des Voeux Road Central, Sheung Wan, Hong Kong",
      "contentUrl": "/clubs/152213",
      "live": true,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 22.286855,
        "longitude": 114.151679
      }
    },
    "promoters": [
      {
        "id": "84769",
        "name": "宀 Club",
        "contentUrl": "/promoters/84769",
        "live": true,
        "hasTicketAccess": true,
        "tracking": []
      }
    ],
    "artists": [
      {
        "id": "65580",
        "name": "Black Merlin",
        "contentUrl": "/dj/blackmerlin",
        "urlSafeName": "blackmerlin"
      },
      {
        "id": "70850",
        "name": "Yadin Moha",
        "contentUrl": "/dj/yadinmoha",
        "urlSafeName": "yadinmoha"
      }
    ],
    "pick": {
      "id": "52790",
      "blurb": "Deep techno scholar Black Merlin, back from a DJing hiatus, makes his Hong Kong debut.",
      "author": {
        "id": "757015",
        "name": "Carlos Hawthorn",
        "imageUrl": "https://static.ra.co/images/user/av/757015-carlos89.jpg",
        "username": "Carlos89",
        "contributor": true
      }
    },
    "promotionalLinks": [
      {
        "title": "Black Merlin IG",
        "url": "https://www.instagram.com/blackmerlin/"
      },
      {
        "title": "Yadin IG",
        "url": "https://www.instagram.com/yadin.moha/"
      }
    ],
    "tracking": [],
    "admin": {
      "id": "313005",
      "username": "jf.amadei"
    },
    "tickets": [
      {
        "id": "1247317",
        "title": "Advance ticket",
        "validType": "VALID",
        "onSaleFrom": "2026-02-03T05:00:00.000Z",
        "priceRetail": 22.6,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      }
    ],
    "standardTickets": [
      {
        "id": "1247317",
        "validType": "VALID"
      }
    ],
    "playerLinks": [
      {
        "id": "458766",
        "sourceId": "https://soundcloud.com/black-merlin/black-merlin-strangebrew-31st?in=black-merlin/sets/dj-mixes",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      },
      {
        "id": "458767",
        "sourceId": "https://soundcloud.com/black-merlin/rural-festival-japan-2019?in=black-merlin/sets/dj-mixes",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      },
      {
        "id": "458768",
        "sourceId": "https://soundcloud.com/428soundwave/yadin-moha-at-428-wonderfruit-2024?si=5f50dfdcde0540868d5d478a60e0c9d8&utm_source=clipboard&utm_medium=text&utm_campaign=social_sharing",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      }
    ],
    "childEvents": [],
    "genres": [
      {
        "id": "5",
        "name": "Techno",
        "slug": "techno"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2373521",
    "title": "0159 presents Estella Boersma",
    "flyerFront": null,
    "flyerBack": null,
    "content": "DATE\n\nMARCH 13 (2026) FRI\n\n\nSHOW TIME\n\n10:00 PM\n\n\nLOCATION\n\n3/F, 33 DES VOEUX ROAD WEST, SHEUNG WAN, HONG KONG\n\n\nTICKETS\n\n$300 / $400 / $500 / $300\n\n\nLINEUP\n\nESTELLA BOERSMA, YUEMING, NOSCOPE720, NEBULAE\n\n\nMORE INFO\n\nBerlin-based Dutch DJ and producer Estella Boersma has seamlessly transitioned from the international fashion runways to the underground club scene. Bringing the same effortless style to the decks, she has quickly become a sensation in the Techno world. After making her debut in 2021 with releases on the Unknown To The Unknown label and dropping hits like \"The Wave,\" \"Sweat,\" and the acid-techno track \"Glade,\" Estella took full control of her sound in 2024. She launched her own imprint, EB-REX, dedicated to high-energy, driving techno tracks designed strictly for the dancefloor. A proven crowd controller, Estella has performed at major festivals including Glastonbury, Awakenings, Time Warp, and Sziget, and played iconic clubs from Fabric (London) to Amnesia (Ibiza). With massive livestreams on Boiler Room and Mixmag Lab, she is a must-see talent delivering a high-octane experience.",
    "minimumAge": 18,
    "cost": "300",
    "contentUrl": "/events/2373521",
    "embargoDate": null,
    "date": "2026-03-13T00:00:00.000",
    "startTime": "2026-03-13T22:00:00.000",
    "endTime": "2026-03-14T03:00:00.000",
    "interestedCount": 6,
    "lineup": "<artist id=\"102468\">Estella Boersma</artist> \n<artist id=\"154433\">YUEMING</artist> \n<artist id=\"158793\">NOSCOPE720</artist> \n<artist id=\"158999\">NEBULAE (2)</artist>",
    "isTicketed": false,
    "isFestival": false,
    "dateUpdated": null,
    "resaleActive": false,
    "datePosted": "2026-02-17T18:51:04.577Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2474565",
        "filename": "https://images.ra.co/8ec138093598dd662e8d5dee0d792babc49c16db.jpg",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      }
    ],
    "venue": {
      "id": "259921",
      "name": "Soho House Hong Kong",
      "address": "33 Des Voeux Rd W, Sheung Wan",
      "contentUrl": "/clubs/259921",
      "live": true,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 22,
        "longitude": 114
      }
    },
    "promoters": [
      {
        "id": "159966",
        "name": "0159",
        "contentUrl": "/promoters/159966",
        "live": true,
        "hasTicketAccess": false,
        "tracking": []
      }
    ],
    "artists": [
      {
        "id": "102468",
        "name": "Estella Boersma",
        "contentUrl": "/dj/estellaboersma",
        "urlSafeName": "estellaboersma"
      },
      {
        "id": "154433",
        "name": "YUEMING",
        "contentUrl": "/dj/yueming",
        "urlSafeName": "yueming"
      },
      {
        "id": "158793",
        "name": "NOSCOPE720",
        "contentUrl": "/dj/noscope720",
        "urlSafeName": "noscope720"
      },
      {
        "id": "158999",
        "name": "NEBULAE (2)",
        "contentUrl": "/dj/nebulae-2",
        "urlSafeName": "nebulae-2"
      }
    ],
    "pick": null,
    "promotionalLinks": [
      {
        "title": "0159group",
        "url": "https://0159group.com"
      },
      {
        "title": "circleticket",
        "url": "https://circleticket.com"
      }
    ],
    "tracking": [],
    "admin": {
      "id": "10068510",
      "username": "0159group"
    },
    "tickets": [],
    "standardTickets": [],
    "playerLinks": [],
    "childEvents": [],
    "genres": [
      {
        "id": "5",
        "name": "Techno",
        "slug": "techno"
      },
      {
        "id": "6",
        "name": "House",
        "slug": "house"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2391311",
    "title": "Talal",
    "flyerFront": null,
    "flyerBack": null,
    "content": "DEEP HOUSE LONDON \"An artist who can boast support from heavy hitters like Adam Beyer, Maceo Plex, Sasha, and Solomun.\" THE RANSOM NOTE \"Talal has some rather fine abstract moments on his new LP \"Exhibition\"... The album covers a wide footprint of electronics and has picked up support from the likes of Laurent Garnier.\"\nCHARTED in 100 countries on apple music, 20+ releases into beatport top 10 editorial charts, 7+ million spotify playlist reach\nPARTIAL RELEASE HISTORY\n2025 / Dec / Talal - EP (White Rose) [Playlisted on John Digweed's Transitions, Dave Seaman's Radio Therapy]\n2025 / May / Booka Shade - Album Remix (Blaufield) [Charted in 45 countries Apple Music #2 in Germany #6 Switzerland #8 Austria]\n2025 / April / Talal - EP (Parquet) [Roster: Giu Boratto, Tim Engelhardt, Worakls] [Charted #3 itunes Brazil]\n2024 / Dec / Talal - EP (Beatfreak) [Roster: Petar Dundov, Rafael Cerato, Hannes Bieger, Stas Drive]\n2024 / Nov / Talal - Single (Enormous Tunes) [Roster: Nora En Pure, Jerome Isma Ae]\n2024 / Oct / Talal - VA (Mango Alley) [Roster: Hernan Cattaneo, Nick Warren, Th;en]\n2024 / June / Talal - VA (Blaufield Music) [Roster: Booka Shade, M.A.N.D.Y., Eli & Fur, Jan Blomqvist, Groove Armada, Adana Twins]\n2024 / May / Talal - EP (Big Bells) [Playlisted by Bicep]\n2024 / Jan / Talal - EP (Nomade) [Roster: Kygo, Xinobi, Moullinex]\n2023 / Dec / Talal - VA (Univack) [Roster: Hernan Cattaneo, Petar Dundov, Nick Muir]\n2023/ July / Talal - EP (Family Piknik) [France festival label roster includes Booka Shade, Marc Romboy, John Digweed]\n2023 / May / Talal - TBA (Beatfreak) [Roster: D-Formation, Betoko, Citizen Kain]\n2023 / March / Talal - EP (Where The Heart Is) [Roster: David Hohme, Jody Wisternoff, D-Nox, Gai Barone]\n2023 / February / Talal - EP (JOOF) [Roster: John 00 Fleming, Fuenka]\n2022 / October / Talal - Compilation (Sudbeat) [Roster: Hernan Cattaneo, Petar Dundov, Dmitry Molosh]\n2022 / June / Talal - EP (Family Piknik) [France festival label roster includes Booka Shade, Marc Romboy, John Digweed]\n2022 / June / Talal - Compilation (Black Hole Recordings) [Roster: Tiesto, BT, Way Out West, Sasha, Adriatique]\n2022 / March / Talal - Compilation (Future Romance/Parquet) [Roster: Fur Coat, Hunter/Game, Recondite]\n2021 / Dec / Talal - Compilation (Spectrum) [Roster: Joris Voorn, Monkey Safari] [playlisted by Hernan Cattaneo, Anthony Pappa]\n2021 / Sept / Talal - Compilation (Desert Hearts Black) [Roster: Township Rebellion, Damian Lazarus, Tim Engelhardt]\n2021 / Sept / Nihil Young, Talal, Amy Wawn - Be Strong My Heart EP (Nomade/Paperclip) [Roster: Kygo, Xinobi, Moullinex]\n2021 / Aug / Talal - Compilation (Renaissance) [Roster: Maceo Plex, Yotto, Solomun]\n2021 / July / Talal - Compilation (Bar 25) [Roster: Acid Pauli, Oliver Koletzki, Be Svendsen]\n2021 / April / Talal - Dawn/Night EP (Sound Avenue/3rd Avenue) [Roster: Eelke Kleijn, Petar Dundov]\n2021 / March / Nihil Young, Talal, Amy Wawn - Don't Give Up EP (Nomade/Paperclip) [Roster: Kygo, Xinobi, Moullinex]\n[DJ Mag LA 5/5, Spotify electronic rising and friday cratediggers, 4+ Million streams]\n2021 / Jan / Nihil Young, Talal, Amy Wawn - Touch EP (Aletheia/Eleatics) [Roster: OC & Verde, Bedouin, Tiefschwarz] [Beatport #24 on progressive charts, in Jerom Isma-Ae January Chart #7, Darin Epsilon February Chart #4]\n2020 / March / Talal - Eighties EP (FSOE UV) [Roster: D Nox & Beckers, Stereo Underground] [Beatport #35 on progressive charts]\n2020 / Jan / Mehmet Akar - So Corrupted (Nihil Young & Talal Remix) (Perspectives Digital) [Beatport #29 Melodic Techno charts, DJ Mag\nNorth America 10/10 Review, Proton Music Charts #8] [Roster: Sebastien Leger, Darin Epsilon]\n2019 / Sept / Talal, Nihil Young, Ewan Rill, Gleb Rubens - Haunted (Dear Deer Records) [Beatport #32 Progressive House, #45 Melodic Techno charts, #5 Beatports Best New Hype Progressive House: September', #15 Darin Epsilons 'October 2019 Chart]\n2019 / June / Talal, FREE.D, Nihil Young - Rotate (Hidden Vibes) [Beatport: #7 Melodic Techno charts, #12 'Closing Essentials: Melodic House & Techno'] [Roster: Death On the Balcony, Beatamines, Zoo Brazil, Powel]\n2016 / Jan / Talal - Eighties (Boulevard) - 2 Track EP [Vocal version for Robot Hearts Further Future Festival, Airplay on BBC Radio]\nTalal Hakim is a London based DJ, producer. Tours include sets at Family Piknik Festival France (w/ Hannes Bieger, Ben Bohmer), BEON1X Festival Cyprus (w/ Sasha, Digweed, Guy J) Robot Hearts Further Future Festival Nevada (w/ Dixon), Shipwrecked Festival New Zealand (w/ Nico Stojan), Cream Amnesia Ibiza. Airplay on BBC Sirius XM, Ibiza Global Radio, Radio FG, Kiss FM, RTÉ, Ibiza Sonica, Pioneer DJ Radio, Friskyradio, DI.FM.\nPlaylisted by Nora En Pure, Judge Jules, Eelke Kleijns, Hernan Cattaneo, Anthony Pappa, John 00 Fleming, Bicep.",
    "minimumAge": 18,
    "cost": "",
    "contentUrl": "/events/2391311",
    "embargoDate": null,
    "date": "2026-03-13T00:00:00.000",
    "startTime": "2026-03-13T23:00:00.000",
    "endTime": "2026-03-14T07:00:00.000",
    "interestedCount": 1,
    "lineup": "<artist id=\"21985\">Talal</artist> <artist id=\"2188\">DJ Anthony2</artist> <artist id=\"104285\">Milam</artist> @nepenthe",
    "isTicketed": false,
    "isFestival": false,
    "dateUpdated": null,
    "resaleActive": false,
    "datePosted": "2026-03-11T06:07:51.187Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2498276",
        "filename": "https://images.ra.co/3195136a70cbb0ddcd3f2547635320f7a15202a7.jpg",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      }
    ],
    "venue": {
      "id": "92517",
      "name": "OMA",
      "address": "Lower Basement, Harilela House, 79 Wyndham Street, Central District, Hong Kong",
      "contentUrl": "/clubs/92517",
      "live": true,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 22.281901,
        "longitude": 114.154671
      }
    },
    "promoters": [],
    "artists": [
      {
        "id": "21985",
        "name": "Talal",
        "contentUrl": "/dj/talal",
        "urlSafeName": "talal"
      },
      {
        "id": "2188",
        "name": "DJ Anthony2",
        "contentUrl": "/dj/djanthony2",
        "urlSafeName": "djanthony2"
      },
      {
        "id": "104285",
        "name": "Milam",
        "contentUrl": "/dj/milam",
        "urlSafeName": "milam"
      }
    ],
    "pick": null,
    "promotionalLinks": [],
    "tracking": [],
    "admin": {
      "id": "4793263",
      "username": "Anthony616"
    },
    "tickets": [],
    "standardTickets": [],
    "playerLinks": [],
    "childEvents": [],
    "genres": [
      {
        "id": "5",
        "name": "Techno",
        "slug": "techno"
      },
      {
        "id": "6",
        "name": "House",
        "slug": "house"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2383963",
    "title": "DJ Jovynn at Space Club",
    "flyerFront": null,
    "flyerBack": null,
    "content": "Space Club's Hong Kong stop on the world tour brings you one of the world's most viral and highly in-demand DJs: @itsjovynn! She has an insanely huge fanbase — over 10 million followers on TikTok alone, and more than 1 million on Instagram.\n\nHer productions have shocked the DJ world. She recreates the sounds in her head with music, resonating deeply with tons of young people. For example, her remix \"Voices in My Head\" didn't just go massively viral — it sparked a whole trend where other DJs rushed to make their own versions.\n\nHer outstanding achievements have been recognized by the industry: In 2022, she became the first Malaysian to perform at Dubai's famous music venue SUPERVERSE. She's collaborated with global brands like Serato, MTV Asia, and Warner Music, and has shared the stage with international superstar Paris Hilton. She's also been featured in top magazines such as ELLE, Harper's BAZAAR, and Lifestyle Asia.",
    "minimumAge": 18,
    "cost": "250",
    "contentUrl": "/events/2383963",
    "embargoDate": null,
    "date": "2026-03-13T00:00:00.000",
    "startTime": "2026-03-13T23:00:00.000",
    "endTime": "2026-03-14T05:00:00.000",
    "interestedCount": 0,
    "lineup": "Jovynn",
    "isTicketed": false,
    "isFestival": false,
    "dateUpdated": "2026-03-03T10:19:32.023Z",
    "resaleActive": false,
    "datePosted": "2026-03-03T10:19:32.023Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2488225",
        "filename": "https://images.ra.co/0f77d491c87183335b644cf5cfedfb9cef321dd1.jpg",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      }
    ],
    "venue": {
      "id": "286617",
      "name": "TBA - Space Club",
      "address": null,
      "contentUrl": null,
      "live": false,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 0,
        "longitude": 0
      }
    },
    "promoters": [],
    "artists": [],
    "pick": null,
    "promotionalLinks": [
      {
        "title": "Get tickets on PLVR",
        "url": "https://www.plvr.io/events/dj-jovynn-space-club-20260313-hk?aid=eventsharing-ra"
      }
    ],
    "tracking": [],
    "admin": {
      "id": "11445176",
      "username": "heidi.plvr"
    },
    "tickets": [],
    "standardTickets": [],
    "playerLinks": [],
    "childEvents": [],
    "genres": [
      {
        "id": "5",
        "name": "Techno",
        "slug": "techno"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2368883",
    "title": "Host with Youry (宀, Hong Kong) + Guido Balboa (Amore Astrale, Hong Kong)",
    "flyerFront": null,
    "flyerBack": null,
    "content": "Curtain calls!\n\nHost is a LGBTIQA+ massive monthly get-together, with an incredible run since 2018, it's self-made and continuously self-governed, premiering a new episode on a prophetically chosen Saturday each month.\n\nHost spring cleaning now booked for March 14, with Youry and Guido Balboa doing it for and with the boys one more time, soaked, in front of and behind the curtain.\n\nBorn in late-80s Antwerp amid Belgium's EBM and Big Beat scene, Youry grew up between worlds. The dancefloor obsession clicked after hearing Akufen at Montreal's Stereo in the early 90s, sparking a lifelong vinyl addiction and carefully catalogued collection. His DJ career took off in 2015 across Hong Kong's clubs and festivals including Shi Fu Miz, Sonar and Acadana. In 2018 he became a resident at 宀 Club, widely regarded as Hong Kong's first venue on par with the world's best.\n\nStarting his musical journey in Hong Kong, Guido Balboa brings a sound shaped by his Dolce Vita roots and deep dives into Italian dance music's celebrated and overlooked corners. As he carves his place in the city, his mission gets clearer with every record: Make Italo Disco Great Again. Bright, driving, unapologetically romantic grooves designed for hands-in-the-air moments and late-night singalongs.\n",
    "minimumAge": 21,
    "cost": "200$ / 300$",
    "contentUrl": "/events/2368883",
    "embargoDate": null,
    "date": "2026-03-14T00:00:00.000",
    "startTime": "2026-03-14T23:00:00.000",
    "endTime": "2026-03-15T06:00:00.000",
    "interestedCount": 27,
    "lineup": "<artist id=\"81066\">Youry</artist> (宀, Hong Kong)\n<artist id=\"92086\">Guido Balboa</artist> (Amore Astrale)",
    "isTicketed": true,
    "isFestival": false,
    "dateUpdated": "2026-03-05T08:19:32.107Z",
    "resaleActive": false,
    "datePosted": "2026-02-11T05:43:59.437Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2490706",
        "filename": "https://images.ra.co/a0c20ba6a1d88efb02d192a6ac43d0ac01d512d7.png",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      }
    ],
    "venue": {
      "id": "152213",
      "name": "宀 Club",
      "address": "4F, 279 Des Voeux Road Central, Sheung Wan, Hong Kong",
      "contentUrl": "/clubs/152213",
      "live": true,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 22.286855,
        "longitude": 114.151679
      }
    },
    "promoters": [
      {
        "id": "84769",
        "name": "宀 Club",
        "contentUrl": "/promoters/84769",
        "live": true,
        "hasTicketAccess": true,
        "tracking": []
      }
    ],
    "artists": [
      {
        "id": "81066",
        "name": "Youry",
        "contentUrl": "/dj/youry",
        "urlSafeName": "youry"
      },
      {
        "id": "92086",
        "name": "Guido Balboa",
        "contentUrl": "/dj/guidobalboa",
        "urlSafeName": "guidobalboa"
      }
    ],
    "pick": null,
    "promotionalLinks": [
      {
        "title": "Host IG",
        "url": "https://www.instagram.com/host_hkg/"
      }
    ],
    "tracking": [],
    "admin": {
      "id": "313005",
      "username": "jf.amadei"
    },
    "tickets": [
      {
        "id": "1254119",
        "title": "Advance ticket",
        "validType": "VALID",
        "onSaleFrom": "2026-02-11T05:30:00.000Z",
        "priceRetail": 28.25,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      }
    ],
    "standardTickets": [
      {
        "id": "1254119",
        "validType": "VALID"
      }
    ],
    "playerLinks": [],
    "childEvents": [],
    "genres": [
      {
        "id": "6",
        "name": "House",
        "slug": "house"
      },
      {
        "id": "48",
        "name": "Italo Disco",
        "slug": "italodisco"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2384888",
    "title": "Bad Times Disco presents: Scam City",
    "flyerFront": null,
    "flyerBack": null,
    "content": "Bad Times Disco (BTD) returns this March with Scam City— How are we coping in this age of deepfakes and bots?\n\nApart from bringing you 4 DJs and music in a brand new warehouse location, we are hoping to wink at the chaos that is unfolding in an unsettling speed. We invite you to ironically toy with the idea and come dress as your favourite identity thief. DANCING AND SINGING GUARANTEED SATISFACTION ~\n\n- Secret Location (Kowloon) sent by email to all ticketholders is MTR Accessible\n- BTD always provides quality and custom made set design \n- Two Best Looks and Best Dancers are rewarded for the energy and creativity they bring to our dancefloor with tickets to a future BTD (around the world) \n- There will be a special merch collaboration with HK brand Feaston (an extremely limited drop) only for this party  \n\nTICKETING SCHEDULE:\n\nRegular Prices:\nPhase I - 250 HKD (SOLDOUT)\nPhase II - 320 HKD (12 March 11:59 pm)\nPhase III - 380 HKD (14 March 7:00 pm)\nDOOR TICKETS: 420HKD",
    "minimumAge": 18,
    "cost": "320-420",
    "contentUrl": "/events/2384888",
    "embargoDate": null,
    "date": "2026-03-14T00:00:00.000",
    "startTime": "2026-03-14T22:00:00.000",
    "endTime": "2026-03-15T04:00:00.000",
    "interestedCount": 3,
    "lineup": "<artist id=\"92225\">Abhi Meer</artist> (The Vigilante)\nCosmo Webber (Set You Free, HK)\n<artist id=\"100596\">Ani Phoebe</artist> (BTD, HK)\nDMK (BTD, HK)",
    "isTicketed": true,
    "isFestival": false,
    "dateUpdated": "2026-03-04T17:32:24.593Z",
    "resaleActive": false,
    "datePosted": "2026-03-03T19:12:33.657Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2489455",
        "filename": "https://images.ra.co/682c3dd30b05c92a219f18edd4fb71919151631e.jpg",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      }
    ],
    "venue": {
      "id": "203234",
      "name": "TBA - Secret Location ",
      "address": null,
      "contentUrl": null,
      "live": false,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 0,
        "longitude": 0
      }
    },
    "promoters": [
      {
        "id": "114183",
        "name": "Bad Times Disco",
        "contentUrl": "/promoters/114183",
        "live": true,
        "hasTicketAccess": true,
        "tracking": []
      }
    ],
    "artists": [
      {
        "id": "92225",
        "name": "Abhi Meer",
        "contentUrl": "/dj/abhimeer",
        "urlSafeName": "abhimeer"
      },
      {
        "id": "100596",
        "name": "Ani Phoebe",
        "contentUrl": "/dj/aniphoebe",
        "urlSafeName": "aniphoebe"
      }
    ],
    "pick": null,
    "promotionalLinks": [
      {
        "title": "Instagram",
        "url": "https://www.instagram.com/badtimesdisco/?hl=en"
      }
    ],
    "tracking": [],
    "admin": {
      "id": "3675754",
      "username": "aniphoeby"
    },
    "tickets": [
      {
        "id": "1271925",
        "title": "1st release",
        "validType": "VALID",
        "onSaleFrom": "2026-03-04T16:00:00.000Z",
        "priceRetail": 46.35,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      },
      {
        "id": "1271928",
        "title": "2nd release",
        "validType": "VALID",
        "onSaleFrom": "2026-03-11T16:00:00.000Z",
        "priceRetail": 54.25,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      }
    ],
    "standardTickets": [
      {
        "id": "1271925",
        "validType": "VALID"
      },
      {
        "id": "1271928",
        "validType": "VALID"
      }
    ],
    "playerLinks": [],
    "childEvents": [],
    "genres": [
      {
        "id": "5",
        "name": "Techno",
        "slug": "techno"
      },
      {
        "id": "6",
        "name": "House",
        "slug": "house"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2389169",
    "title": "Gesamt Archive 呈現：通往自由之門 VSLORIA 策劃 - 個人展覽及視聽之旅",
    "flyerFront": null,
    "flyerBack": null,
    "content": "Gesamt Archive Presents: The Door to Freedom\nA Solo Exhibition & DJ Event Curated by VSLORIA\n\nReflecting the dark, atmospheric, and raw textures of her own aesthetic, VSLORIA invites and curates a night of music to translate the exhibition’s emotional depth into sound. \n\nThis curated sonic landscape guides you through the archive featuring: FAYE (Ecstatic Bass, MO), SHELF-INDEX (Cheaper Than Therapy, HK), JFÜNG (Dark Metaz, HK) and KOLAK (Circle, HK)\n\n(Atmospheric / Experimental / Deep / Techno / Bass)\n\nThis is a descent into the depths — a journey through overwhelming life lessons and the suffocating walls of a mental prison. These works were forged in the heat of that struggle, documented as a raw self-archive of a soul sinking into the abyss. Together with the music, this exhibition documents the process of crawling through hell to finally find the door to freedom.\n\n這是一趟深入內心的旅程 ─ 一段直面人生考驗、迷失方向、被困於精神牢籠，靈魂沉入深淵，情感和思緒不斷輪迴於黑暗之中。\n\n所有作品均創作於那段時期，並以個人檔案的形式記錄。展覽與音樂相伴，記錄了如何走出地獄，最終找到通往自由之門的歷程。\n\nDate: 14.03.2026 (Saturday)\nTime: 20:00 till late \nLocation: Ping Pong 129 \n129 Second Street, L/G Nam Cheong House, Sai Ying Pun, Hong Kong\n\nFREE ENTRY",
    "minimumAge": null,
    "cost": "0",
    "contentUrl": "/events/2389169",
    "embargoDate": null,
    "date": "2026-03-14T00:00:00.000",
    "startTime": "2026-03-14T20:00:00.000",
    "endTime": "2026-03-15T02:00:00.000",
    "interestedCount": 3,
    "lineup": "<artist id=\"163340\">VSLORIA</artist>, FAYE (Ecstatic Bass, MO), <artist id=\"124961\">Shelf-Index</artist> (Cheaper Than Therapy, HK), <artist id=\"127189\">JFÜNG</artist> (Dark Metaz, HK), KOLAK (Circle, HK)",
    "isTicketed": false,
    "isFestival": false,
    "dateUpdated": "2026-03-09T12:36:38.533Z",
    "resaleActive": false,
    "datePosted": "2026-03-09T12:16:56.447Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2495471",
        "filename": "https://images.ra.co/11ab3e949197856fb219f7026668b5135889bc8b.jpg",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      }
    ],
    "venue": {
      "id": "124612",
      "name": "Ping Pong 129",
      "address": "Second St. 129 L/G Nam Cheong House, Sai Ying Pun, Hong Kong",
      "contentUrl": "/clubs/124612",
      "live": true,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 22.28637,
        "longitude": 114.139694
      }
    },
    "promoters": [
      {
        "id": "35680",
        "name": "DSHK",
        "contentUrl": "/promoters/35680",
        "live": true,
        "hasTicketAccess": false,
        "tracking": []
      }
    ],
    "artists": [
      {
        "id": "163340",
        "name": "VSLORIA",
        "contentUrl": "/dj/vsloria",
        "urlSafeName": "vsloria"
      },
      {
        "id": "124961",
        "name": "Shelf-Index",
        "contentUrl": "/dj/shelf-index",
        "urlSafeName": "shelf-index"
      },
      {
        "id": "127189",
        "name": "JFÜNG",
        "contentUrl": "/dj/jfung",
        "urlSafeName": "jfung"
      }
    ],
    "pick": null,
    "promotionalLinks": [],
    "tracking": [],
    "admin": {
      "id": "182659",
      "username": "juanfrmg"
    },
    "tickets": [],
    "standardTickets": [],
    "playerLinks": [],
    "childEvents": [],
    "genres": [
      {
        "id": "41",
        "name": "Drone",
        "slug": "drone"
      },
      {
        "id": "46",
        "name": "IDM",
        "slug": "idm"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2389060",
    "title": "St Paddy's On AER",
    "flyerFront": null,
    "flyerBack": null,
    "content": "AER’s St Paddy's Day Day Party with a full day of proper Irish energy in SoHo.\n\nExpect:\nMusic all day\nAll-day happy hour\nSpecial Irish menu \nGuinness poured to perfection\n\nGood music, good drinks, good food, and good people.",
    "minimumAge": 18,
    "cost": "$50",
    "contentUrl": "/events/2389060",
    "embargoDate": null,
    "date": "2026-03-14T00:00:00.000",
    "startTime": "2026-03-14T16:00:00.000",
    "endTime": "2026-03-15T02:00:00.000",
    "interestedCount": 2,
    "lineup": "<artist id=\"166406\">GONG!</artist>\nCosmo Webber (Set You Free, HK) \nDJ Queenie (CN)",
    "isTicketed": true,
    "isFestival": false,
    "dateUpdated": "2026-03-10T09:30:14.107Z",
    "resaleActive": false,
    "datePosted": "2026-03-09T10:37:37.620Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2495310",
        "filename": "https://images.ra.co/54ea2288853303cb79d0b748e70585f82456f835.png",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      }
    ],
    "venue": {
      "id": "269820",
      "name": "AER (Aesthetic Radio)",
      "address": "Enter via Aberdeen St, UG/F, 52-56 Staunton St, Soho, Central, Hong Kong Island",
      "contentUrl": "/clubs/269820",
      "live": true,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 0,
        "longitude": 0
      }
    },
    "promoters": [
      {
        "id": "166775",
        "name": "AER (Aesthetic Radio)",
        "contentUrl": "/promoters/166775",
        "live": true,
        "hasTicketAccess": true,
        "tracking": []
      }
    ],
    "artists": [
      {
        "id": "166406",
        "name": "GONG!",
        "contentUrl": "/dj/gong!",
        "urlSafeName": "gong!"
      }
    ],
    "pick": null,
    "promotionalLinks": [
      {
        "title": "@AER_HKG",
        "url": "https://www.instagram.com/aer_hkg/"
      }
    ],
    "tracking": [],
    "admin": {
      "id": "10570500",
      "username": "AERHK"
    },
    "tickets": [
      {
        "id": "1276147",
        "title": "Admission + Free Flow between 4-7pm (No Guinness)",
        "validType": "VALID",
        "onSaleFrom": "2026-03-10T08:00:00.000Z",
        "priceRetail": 44.73,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      },
      {
        "id": "1276150",
        "title": "Admission + Free Flow between 4-7pm (With Guinness Included)",
        "validType": "VALID",
        "onSaleFrom": "2026-03-10T08:00:00.000Z",
        "priceRetail": 75.15,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      },
      {
        "id": "1276151",
        "title": "Admission + One Free Drink (Can be Guinness)",
        "validType": "VALID",
        "onSaleFrom": "2026-03-10T08:00:00.000Z",
        "priceRetail": 15.34,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      },
      {
        "id": "1276155",
        "title": "General admission",
        "validType": "VALID",
        "onSaleFrom": "2026-03-10T08:00:00.000Z",
        "priceRetail": 7.67,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      }
    ],
    "standardTickets": [
      {
        "id": "1276147",
        "validType": "VALID"
      },
      {
        "id": "1276150",
        "validType": "VALID"
      },
      {
        "id": "1276151",
        "validType": "VALID"
      },
      {
        "id": "1276155",
        "validType": "VALID"
      }
    ],
    "playerLinks": [],
    "childEvents": [],
    "genres": [
      {
        "id": "6",
        "name": "House",
        "slug": "house"
      },
      {
        "id": "13",
        "name": "Garage",
        "slug": "garage"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2383969",
    "title": "Sarah de Warren",
    "flyerFront": null,
    "flyerBack": null,
    "content": "Set to captivate Atmosphere Tsim Sha Tsui on March 14! Sarah de Warren — a UK-born, soul-stirring vocalist and atmospheric artist, bringing her lush, cinematic soundscapes and heartfelt performance to Hong Kong for a night of intimate, unforgettable music! As the iconic voice behind Eli Brown’s ‘Be The One’, techno/trance artist and DJ Sarah de Warren is widely recognised for her contribution to rave culture.\n\nShe has carved out a unique space for herself amongst the most pioneering artists in the scene. Hardwell, Hi-Lo, Maddix, Reinier Zonnevald, Danny Avila, and Kaskade are just a few of her recent collaborators, and her release with Layton Giordani, ‘Act Of God’ on Experts Only, has made waves all over US radio and Beatport charts.\n\n來自英國的靈魂女音”Sarah de Warren”憑着獨特嘅聲線在電音界嶄露頭角. 她不只是一位歌手,亦都係一位DJ同製作人.喜歡電音嘅朋友萬勿錯過佢既演出,各位到時見!!",
    "minimumAge": 18,
    "cost": "250",
    "contentUrl": "/events/2383969",
    "embargoDate": null,
    "date": "2026-03-14T00:00:00.000",
    "startTime": "2026-03-14T23:00:00.000",
    "endTime": "2026-03-15T05:00:00.000",
    "interestedCount": 0,
    "lineup": "Sarah de Warren \nChristiann Lau \nrase & Raymond Mak \nNicholas Yuen",
    "isTicketed": false,
    "isFestival": false,
    "dateUpdated": "2026-03-03T10:19:37.047Z",
    "resaleActive": false,
    "datePosted": "2026-03-03T10:19:37.063Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2488234",
        "filename": "https://images.ra.co/d6f8b32e9e1c43adc2abb010f0a0833350900319.png",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      }
    ],
    "venue": {
      "id": "286618",
      "name": "Atmosphere",
      "address": "2/F, 10 Knutsford Terrace, Tsim Sha Tsui, Kowloon, HK",
      "contentUrl": null,
      "live": false,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 0,
        "longitude": 0
      }
    },
    "promoters": [],
    "artists": [],
    "pick": null,
    "promotionalLinks": [
      {
        "title": "Get ticket on PLVR",
        "url": "https://www.plvr.io/events/sarah-de-warren-atmosphere-20260314-hk?aid=eventsharing-ra"
      }
    ],
    "tracking": [],
    "admin": {
      "id": "11527665",
      "username": "plvrio"
    },
    "tickets": [],
    "standardTickets": [],
    "playerLinks": [],
    "childEvents": [],
    "genres": [
      {
        "id": "5",
        "name": "Techno",
        "slug": "techno"
      },
      {
        "id": "15",
        "name": "Tech House",
        "slug": "techhouse"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2392351",
    "title": "IN CONVERSATION: DYSTOPIA///UTOPIA",
    "flyerFront": null,
    "flyerBack": null,
    "content": "Art Month in Hong Kong 2026\n\nDid you miss our pop-up at Immerse last month? Then, you’re in luck because we’re bringing it back again for a full screening of all the artists’ works including a special presentation by local and global artists discussing their process and inspiration!\n\nIN CONVERSATION: DYSTOPIA///UTOPIA\n\nPRESENTED BY:\nWE ARE THE FUTURE! (@wearethefutureparty)\nCritical Mass (@criticalmass.space)\n\nDate: March 18, 2026\nTime: 18:00 - midnight\nLocation: Immerse (90 Hoi Bun Road, Kwun Tong, Hong Kong)\n\nIn the year 2096, Hong Kong ripples like a bioluminescent circuit . Glass towers breathing with mycelial light find its way deep below the maglev arteries, where the undercity hums in ultraviolet rebellion. Artists hack the skyline with drones painted in quantum graffiti, their pigments responding to emotional frequency. Beneath neon cathedrals of commerce, artists convene under the Kwun Tong Bypass to share their latest inventions, sounds forged by code, and sculpted mythologies of visual dances.\n\nThis event brings together global artists to address the question, “What does “FUTURISM” mean in 2026?” through a series of immersive films, animated visuals, installations, poetry, open decks, and more.\n\nDYSTOPIA / UTOPIA is the first international exhibition hosted by WE ARE THE FUTURE! and draws on their monthly NYC art fair/art share, where artists come together to share their latest works-in-progress, and to discuss social-political issues.",
    "minimumAge": null,
    "cost": "",
    "contentUrl": "/events/2392351",
    "embargoDate": null,
    "date": "2026-03-18T00:00:00.000",
    "startTime": "2026-03-18T18:00:00.000",
    "endTime": "2026-03-18T23:59:00.000",
    "interestedCount": 0,
    "lineup": "Open Decks TBA",
    "isTicketed": false,
    "isFestival": false,
    "dateUpdated": "2026-03-12T10:50:34.590Z",
    "resaleActive": false,
    "datePosted": "2026-03-12T10:50:34.597Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2499646",
        "filename": "https://images.ra.co/c5313ff21bea4332158ede776da0a993618307c6.png",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      }
    ],
    "venue": {
      "id": "287386",
      "name": "Immerse",
      "address": "90 Hoi Bun Road, Kwun Tong, Hong Kong",
      "contentUrl": null,
      "live": false,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 0,
        "longitude": 0
      }
    },
    "promoters": [
      {
        "id": "123027",
        "name": "WE ARE THE FUTURE!",
        "contentUrl": "/promoters/123027",
        "live": true,
        "hasTicketAccess": false,
        "tracking": []
      }
    ],
    "artists": [],
    "pick": null,
    "promotionalLinks": [],
    "tracking": [],
    "admin": {
      "id": "6188853",
      "username": "shayyyyyy"
    },
    "tickets": [],
    "standardTickets": [],
    "playerLinks": [],
    "childEvents": [],
    "genres": [
      {
        "id": "5",
        "name": "Techno",
        "slug": "techno"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2387944",
    "title": "[Techno All Night Long] 100%Bakery invites Lorenzo Donato (Sintetica) // (Live)",
    "flyerFront": null,
    "flyerBack": null,
    "content": "100%Bakery invites Lorenzo Donato (Sintetica) (Live)\n\nLorenzo Donato is an Italian electronic musician and composer, founder of Sintetica Collective, working at the intersection of techno, sonic experimentation, and multimedia arts.\n\nHis sound builds on techno roots, blending detailed sound design, electronic psychedelia, broken beats, and heavy low-end, while parallel audiovisual projects create immersive, textural journeys between ambient and IDM.\n\nHe has performed at key Italian venues like Magik Bar, Brancaleone (Rome), Tempio del Futuro Perduto (Milan), and Bunker (Turin), sharing stages with artists including UF095, Rose, Anna Z., J. Manuel, and Abo Abo.\n\nLorenzo Donato , 意大利電子音樂家及作曲家，Sintetica Collective 創辦人，專注於 techno、聲響實驗與多媒體藝術的交匯。\n他的音樂以 techno 為根基，融合細膩音色設計、電子迷幻、broken beats 及沉重低頻；同時發展聲光並行的沉浸式項目，帶來 ambient 至 IDM 的質感旅程。\n他曾在意大利重要場地演出，如羅馬的 Magik Bar 及 Brancaleone、米蘭的 Tempio del Futuro Perduto、都靈的 Bunker，並與 UF095、Rose、Anna Z.、J. Manuel、Abo Abo 等藝術家同台演出。",
    "minimumAge": 18,
    "cost": "150-200",
    "contentUrl": "/events/2387944",
    "embargoDate": null,
    "date": "2026-03-20T00:00:00.000",
    "startTime": "2026-03-20T23:00:00.000",
    "endTime": "2026-03-21T05:00:00.000",
    "interestedCount": 13,
    "lineup": "<artist id=\"156560\">100%WONG</artist> \nAngel B\nHooyin B2B Danlee\n<artist id=\"170200\">Lorenzo Donato</artist> \n<artist id=\"158244\">Sonicmon</artist>",
    "isTicketed": true,
    "isFestival": false,
    "dateUpdated": "2026-03-08T18:24:56.957Z",
    "resaleActive": false,
    "datePosted": "2026-03-06T16:26:06.760Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2493780",
        "filename": "https://images.ra.co/3d4ec80391a762589a8e0b635006eeffd3ec33a5.jpg",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      }
    ],
    "venue": {
      "id": "104446",
      "name": "Social Room",
      "address": "74-78 Stanley Street; Won Hing Building, 3/F; Central, Hong Kong",
      "contentUrl": "/clubs/104446",
      "live": true,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 22.283418,
        "longitude": 114.154493
      }
    },
    "promoters": [
      {
        "id": "155728",
        "name": "100%Bakery",
        "contentUrl": "/promoters/155728",
        "live": true,
        "hasTicketAccess": true,
        "tracking": []
      }
    ],
    "artists": [
      {
        "id": "156560",
        "name": "100%WONG",
        "contentUrl": "/dj/100%wong",
        "urlSafeName": "100%wong"
      },
      {
        "id": "170200",
        "name": "Lorenzo Donato",
        "contentUrl": "/dj/lorenzodonato",
        "urlSafeName": "lorenzodonato"
      },
      {
        "id": "158244",
        "name": "Sonicmon",
        "contentUrl": "/dj/sonicmon",
        "urlSafeName": "sonicmon"
      }
    ],
    "pick": null,
    "promotionalLinks": [],
    "tracking": [],
    "admin": {
      "id": "5013473",
      "username": "100percentwong"
    },
    "tickets": [
      {
        "id": "1274368",
        "title": "Early bird",
        "validType": "VALID",
        "onSaleFrom": "2026-03-07T06:00:00.000Z",
        "priceRetail": 22.6,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      },
      {
        "id": "1274369",
        "title": "General admission",
        "validType": "VALID",
        "onSaleFrom": "2026-03-07T06:00:00.000Z",
        "priceRetail": 26,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      }
    ],
    "standardTickets": [
      {
        "id": "1274368",
        "validType": "VALID"
      },
      {
        "id": "1274369",
        "validType": "VALID"
      }
    ],
    "playerLinks": [],
    "childEvents": [],
    "genres": [
      {
        "id": "5",
        "name": "Techno",
        "slug": "techno"
      },
      {
        "id": "39",
        "name": "Club",
        "slug": "club"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2350992",
    "title": "VG+ with Hakim (Ring, Seoul) + maxi.milian (VG+, Hong Kong)",
    "flyerFront": null,
    "flyerBack": null,
    "content": "Hakim is a resident DJ and operator at Seoul’s underground club RING, and has been a key figure in shaping its identity since the early days.\n\nWorking in the club’s vinyl-only environment, his residency has sharpened an obsession with digging—letting records lead the narrative rather than genre labels. Raised in Seoul and shaped by years as a guitarist, Hakim brings a musician’s sensibility to the booth: attentive to tone, tension, and timing, with a natural feel for phrasing and release.\n\nHis sets are defined by unexpected cuts and witty, seamless transitions that add a quiet but palpable heat to the floor—always nudging dancers toward the next scene. From dubby, hypnotic late-night grooves to melodic edges that catch the first light of morning, his instinctive selections go wherever the moment points.\n\n\n\nHong Kong native maxi.milian is a rising force in the underground music scene. Known for his pinpoint digging, attention to detail and gem-filled record bags, his sound and musical interests pay tribute and affection to the past, despite an affinity for modern grinding electro basslines and the playful vocals of French touch. From 80s house origins and Italo, to 90s trance, electro and house classics, to their progressive descendants of mainly the 2000s and the 2020s, Max pulls together the musical elements that make him move, and finds complete fulfilment in introducing them to others.\n\nAfter 6 years developing his music taste between Edinburgh and London, and then launching Mail In A Mix*, he moved back to his hometown and became a key figure in the resurgence of vinyl DJing in Hong Kong. Having since played alongside Enrica Falqui, Dea Dvornik, DOTT, and Ryokei, today he splits his time between the vinyl night of 宀 Club, label and collective VG+ alongside founders Vence and Sunsiaré, and his duo enzyme with partner suz eq.",
    "minimumAge": 21,
    "cost": "150$ / 250$",
    "contentUrl": "/events/2350992",
    "embargoDate": null,
    "date": "2026-03-20T00:00:00.000",
    "startTime": "2026-03-20T23:00:00.000",
    "endTime": "2026-03-21T06:00:00.000",
    "interestedCount": 15,
    "lineup": "<artist id=\"130602\">Hakim.</artist> (Ring, Seoul)\n<artist id=\"139911\">maxi.milian</artist> (VG+, Hong Kong)",
    "isTicketed": true,
    "isFestival": false,
    "dateUpdated": "2026-03-11T02:39:00.860Z",
    "resaleActive": false,
    "datePosted": "2026-01-20T13:03:22.733Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2444980",
        "filename": "https://images.ra.co/2c2f641fd464596dc4c9b34bece825edd57ad45b.jpg",
        "alt": null,
        "type": "FLYERBACK",
        "crop": null
      },
      {
        "id": "2498196",
        "filename": "https://images.ra.co/3e1ddb845361f4431084d736ae203021315c23f7.jpg",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      }
    ],
    "venue": {
      "id": "152213",
      "name": "宀 Club",
      "address": "4F, 279 Des Voeux Road Central, Sheung Wan, Hong Kong",
      "contentUrl": "/clubs/152213",
      "live": true,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 22.286855,
        "longitude": 114.151679
      }
    },
    "promoters": [
      {
        "id": "84769",
        "name": "宀 Club",
        "contentUrl": "/promoters/84769",
        "live": true,
        "hasTicketAccess": true,
        "tracking": []
      }
    ],
    "artists": [
      {
        "id": "130602",
        "name": "Hakim.",
        "contentUrl": "/dj/hakim.",
        "urlSafeName": "hakim."
      },
      {
        "id": "139911",
        "name": "maxi.milian",
        "contentUrl": "/dj/maxi.milian",
        "urlSafeName": "maxi.milian"
      }
    ],
    "pick": null,
    "promotionalLinks": [
      {
        "title": "VG+ IG",
        "url": "https://www.instagram.com/vgplus__/"
      }
    ],
    "tracking": [],
    "admin": {
      "id": "313005",
      "username": "jf.amadei"
    },
    "tickets": [
      {
        "id": "1236359",
        "title": "Advance ticket",
        "validType": "NOLONGERONSALE",
        "onSaleFrom": "2026-01-20T13:00:00.000Z",
        "priceRetail": 22.6,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      }
    ],
    "standardTickets": [
      {
        "id": "1236359",
        "validType": "NOLONGERONSALE"
      }
    ],
    "playerLinks": [
      {
        "id": "458783",
        "sourceId": "https://www.youtube.com/watch?v=lS02bSgaX_8",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      }
    ],
    "childEvents": [],
    "genres": [
      {
        "id": "5",
        "name": "Techno",
        "slug": "techno"
      },
      {
        "id": "6",
        "name": "House",
        "slug": "house"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2379511",
    "title": "Distrikt 29 with Faxtory, Jordy Lee & Scott B",
    "flyerFront": null,
    "flyerBack": null,
    "content": "For the 29th chapter of Distrikt, the decision has been made to strip back the lineup and focus on the core essence of what makes this party one of Hong Kong’s most renowned techno institution. While Distrikt is known for hosting a mix of international and local guests, this edition sees the crew take full control of their home base at 宀 Club for a special 6-hour showcase. It is a night designed to demonstrate exactly why they are the city’s leading \"teaching party,\" educating the floor through pure selection and technique.\n\nLeading the charge is Jordy Lee, a Hong Kong native and Distrikt co-founder who has become a staple of the local circuit. With a residency at 宀 Club, Jordy has shared the booth with industry heavyweights like John Talabot, D.Dan, and Fadi Mohem. His sets are a distinctive exploration of groove, flow, and trippy psychedelia, bridging early rave culture with modern sonics.\n\nJoining him is fellow co-founder Faxtory (Justin). Passionate about pushing the sonic boundaries of the community, Faxtory has been instrumental in integrating international talent into the local scene, recently collaborating with veterans like DJ Nobu, Voiski, and Sedef Adasi.\n\nRounding out the trio is Scott B. After cutting his teeth in Nottingham’s underground scene and absorbing influences from the likes of Ben UFO and Helena Hauff, Scott spent time refining his sound in Berlin and Shanghai. He brings a keen ear for groovy, dark sounds to the mix.\n\nNo guests. No distractions. Just the residents proving why they define the local scene.",
    "minimumAge": 21,
    "cost": "150$ / 250$",
    "contentUrl": "/events/2379511",
    "embargoDate": null,
    "date": "2026-03-21T00:00:00.000",
    "startTime": "2026-03-21T23:00:00.000",
    "endTime": "2026-03-22T06:00:00.000",
    "interestedCount": 15,
    "lineup": "<artist id=\"104837\">Faxtory</artist> (Distrikt, Hong Kong)\n<artist id=\"120617\">Scott B</artist> (Distrikt, Hong Kong)\n<artist id=\"108715\">Jordy Lee</artist> (Distrikt, Hong Kong)",
    "isTicketed": true,
    "isFestival": false,
    "dateUpdated": "2026-03-11T02:38:23.917Z",
    "resaleActive": false,
    "datePosted": "2026-02-25T12:56:21.623Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2498195",
        "filename": "https://images.ra.co/d3c0ad9c413207b2547abf66892bb0e0a3e387dd.jpg",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      }
    ],
    "venue": {
      "id": "152213",
      "name": "宀 Club",
      "address": "4F, 279 Des Voeux Road Central, Sheung Wan, Hong Kong",
      "contentUrl": "/clubs/152213",
      "live": true,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 22.286855,
        "longitude": 114.151679
      }
    },
    "promoters": [
      {
        "id": "84769",
        "name": "宀 Club",
        "contentUrl": "/promoters/84769",
        "live": true,
        "hasTicketAccess": true,
        "tracking": []
      }
    ],
    "artists": [
      {
        "id": "104837",
        "name": "Faxtory",
        "contentUrl": "/dj/faxtory",
        "urlSafeName": "faxtory"
      },
      {
        "id": "120617",
        "name": "Scott B",
        "contentUrl": "/dj/scottb",
        "urlSafeName": "scottb"
      },
      {
        "id": "108715",
        "name": "Jordy Lee",
        "contentUrl": "/dj/jordylee",
        "urlSafeName": "jordylee"
      }
    ],
    "pick": null,
    "promotionalLinks": [
      {
        "title": "Distrikt IG",
        "url": "https://www.instagram.com/distrikt_hk/?hl=en"
      },
      {
        "title": "宀 IG",
        "url": "https://www.instagram.com/mihnclub/"
      }
    ],
    "tracking": [],
    "admin": {
      "id": "313005",
      "username": "jf.amadei"
    },
    "tickets": [
      {
        "id": "1265527",
        "title": "Advance ticket",
        "validType": "VALID",
        "onSaleFrom": "2026-02-25T12:30:00.000Z",
        "priceRetail": 22.6,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      }
    ],
    "standardTickets": [
      {
        "id": "1265527",
        "validType": "VALID"
      }
    ],
    "playerLinks": [
      {
        "id": "467590",
        "sourceId": "https://soundcloud.com/room303radio/faxtory-2025-10-25",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      },
      {
        "id": "467591",
        "sourceId": "https://soundcloud.com/mihnclub/mix082-jordy-lee-live-at",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      },
      {
        "id": "467592",
        "sourceId": "https://soundcloud.com/mihnclub/mix063-faxtory-live-at",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      }
    ],
    "childEvents": [],
    "genres": [
      {
        "id": "5",
        "name": "Techno",
        "slug": "techno"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2269942",
    "title": "Shi Fu Miz Festival 2026",
    "flyerFront": null,
    "flyerBack": null,
    "content": "—  Shi Fu Miz Festival 2026 — \nHK music and art festival created by Fufu and La Mamie's is back in a new venue in 2026 with a brand new 1-day format.\n\n\nFULL LINE-UP :\nInternational Talents:\nHiroko Yamamura (US)\nMamie's (FR) \nMinna-no-kimochi (JP)\nMr. Ho (HK) & Roza Terenzi (AUS)\nRoss from Friends (UK)\nRrose (US)\nRuby Savage (NL)\n\nHK Local Pionneers:\n0159 (Tuesday, Noscope720, Yueming)\nArthur Yeti \nCantomania (Fabsabs) \nChaotic Pavilion (Maximelah, Noctall & Saint Bernard)\nFeed the Dragon (Dj Fu, Hocknell, Mengzy & MMEE)\nHong Kong Analog Shopping Centre (o-mori & DMK) \nFuFu (MLCH) \nOIL Soundsystem (DJ 86 b2b Sirens)\nS2 (HORACIO, JOESNOTDEAD, 1908 & GONG!) \nUmami (Eugene & Whoseany)\n\n FESTIVAL TICKETS :\n• DAY PASS\n∼ Blind tickets: 488 HKD (+ fees) | SOLD OUT\n∼ Early Access tickets (entry before 2pm) : 488HKD (+ fees) | ON SALE\n∼ Student Access tickets / U-23  (entry before 2pm) : 488HKD (+ fees) | ON SALE\n∼ 1st Release tickets : 588 HKD (+ fees) | ON SALE\n∼ 2nd Release tickets : 688 HKD (+ fees) | (Sales begin 6pm January 5 2026 or 1st release sold out)\n∼ Last Release tickets : 788 HKD (+ fees) | (Sales begin 6pm February 15 2026 or 2nd release sold out)\n\n\n IMPORTANT INFORMATIONS\n• FREE for Kids under 12 y.o accompanied by an adult\n• Festival tickets are non refundable unless the event is canceled.\n\n\n FESTIVAL SCHEDULE\n∼ FRIDAY - OPENING NIGHT TBA\n∼ SATURDAY, MARCH 21ST - MAIN FESTIVAL / 12PM-12AM\n∼ SATURDAY, MARCH 21ST - AFTERPARTY TBA\n\n\nVENUE : TAI TONG ORGANIC ECOPARK, YUEN LONG\n\n\nHOW TO COME FROM CENTRAL/KOWLOON ?\nUBER/TAXI - MTR/MINIBUS / KMB BUS\n",
    "minimumAge": null,
    "cost": "488-788",
    "contentUrl": "/events/2269942",
    "embargoDate": null,
    "date": "2026-03-21T00:00:00.000",
    "startTime": "2026-03-21T12:00:00.000",
    "endTime": "2026-03-22T00:00:00.000",
    "interestedCount": 41,
    "lineup": "International Talents:\n<artist id=\"66118\">Elena Colombi</artist>  (IT)\n<artist id=\"55872\">Mamie's</artist> (FR) \n<artist id=\"144005\">Minna-no-Kimochi</artist> (JP)\n<artist id=\"20717\">Mr. Ho</artist> (HK) & <artist id=\"71637\">Roza Terenzi</artist>  (AUS)\n<artist id=\"55186\">Ross From Friends</artist> (UK)\n<artist id=\"28755\">Rrose</artist> (US)\n<artist id=\"81974\">Ruby Savage</artist> (NL)\n\nHK Local Pionneers:\n0159 (<artist id=\"159598\">TUESDAY</artist> , <artist id=\"158793\">NOSCOPE720</artist> , <artist id=\"154433\">YUEMING</artist> )\n<artist id=\"169688\">Arthur Yeti</artist>\nCantomania (Fabsabs) \nChaotic Pavilion (Maximelah, Noctall & <artist id=\"118796\">Saint Bernard</artist> )\nFeed the Dragon (Dj Fu, Hocknell, <artist id=\"140643\">Mengzy</artist> & MMEE)\nHong Kong Analog Shopping Centre (o-mori & DMK) \nFuFu (<artist id=\"54687\">MLCH</artist>) \nOIL Soundsystem (DJ 86 b2b Sirens)\nReach (<artist id=\"137135\">Andy-S</artist> & <artist id=\"156929\">The Heman</artist>)\nS2 (HORACIO, JOESNOTDEAD, 1908 & GONG!) \n<artist id=\"19060\">Umami</artist> (Eugene & Whoseany)",
    "isTicketed": true,
    "isFestival": false,
    "dateUpdated": "2026-03-03T13:29:13.917Z",
    "resaleActive": false,
    "datePosted": "2025-09-29T13:34:01.880Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2415517",
        "filename": "https://images.ra.co/4bd052b664c4ea1515e83b72bdda329eb5a9d4b7.png",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      },
      {
        "id": "2415518",
        "filename": "https://images.ra.co/7e7c4d07cdfcfd9c502db48874af1a5c793d02b3.png",
        "alt": null,
        "type": "FLYERBACK",
        "crop": null
      }
    ],
    "venue": {
      "id": "275720",
      "name": "TAI Tong Ecopark",
      "address": "Tai Tong Shan Rd, Yuen Long",
      "contentUrl": null,
      "live": false,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 0,
        "longitude": 0
      }
    },
    "promoters": [
      {
        "id": "82720",
        "name": "shifumiz",
        "contentUrl": "/promoters/82720",
        "live": true,
        "hasTicketAccess": true,
        "tracking": []
      }
    ],
    "artists": [
      {
        "id": "66118",
        "name": "Elena Colombi",
        "contentUrl": "/dj/elenacolombi",
        "urlSafeName": "elenacolombi"
      },
      {
        "id": "55872",
        "name": "Mamie's",
        "contentUrl": "/dj/lamamies",
        "urlSafeName": "lamamies"
      },
      {
        "id": "144005",
        "name": "Minna-no-Kimochi",
        "contentUrl": "/dj/minna-no-kimochi",
        "urlSafeName": "minna-no-kimochi"
      },
      {
        "id": "20717",
        "name": "Mr. Ho",
        "contentUrl": "/dj/mr.ho",
        "urlSafeName": "mr.ho"
      },
      {
        "id": "71637",
        "name": "Roza Terenzi",
        "contentUrl": "/dj/rozaterenzi",
        "urlSafeName": "rozaterenzi"
      },
      {
        "id": "55186",
        "name": "Ross From Friends",
        "contentUrl": "/dj/rossfromfriends-uk",
        "urlSafeName": "rossfromfriends-uk"
      },
      {
        "id": "28755",
        "name": "Rrose",
        "contentUrl": "/dj/rrose",
        "urlSafeName": "rrose"
      },
      {
        "id": "81974",
        "name": "Ruby Savage",
        "contentUrl": "/dj/rubysavage",
        "urlSafeName": "rubysavage"
      },
      {
        "id": "159598",
        "name": "TUESDAY",
        "contentUrl": "/dj/tuesday",
        "urlSafeName": "tuesday"
      },
      {
        "id": "158793",
        "name": "NOSCOPE720",
        "contentUrl": "/dj/noscope720",
        "urlSafeName": "noscope720"
      },
      {
        "id": "154433",
        "name": "YUEMING",
        "contentUrl": "/dj/yueming",
        "urlSafeName": "yueming"
      },
      {
        "id": "169688",
        "name": "Arthur Yeti",
        "contentUrl": "/dj/arthuryeti",
        "urlSafeName": "arthuryeti"
      },
      {
        "id": "118796",
        "name": "Saint Bernard",
        "contentUrl": "/dj/saintbernard",
        "urlSafeName": "saintbernard"
      },
      {
        "id": "140643",
        "name": "Mengzy",
        "contentUrl": "/dj/mengzy",
        "urlSafeName": "mengzy"
      },
      {
        "id": "54687",
        "name": "MLCH",
        "contentUrl": "/dj/mlch-cn",
        "urlSafeName": "mlch-cn"
      },
      {
        "id": "137135",
        "name": "Andy-S",
        "contentUrl": "/dj/andy-s",
        "urlSafeName": "andy-s"
      },
      {
        "id": "156929",
        "name": "The Heman",
        "contentUrl": "/dj/theheman",
        "urlSafeName": "theheman"
      },
      {
        "id": "19060",
        "name": "Umami",
        "contentUrl": "/dj/umami",
        "urlSafeName": "umami"
      }
    ],
    "pick": null,
    "promotionalLinks": [
      {
        "title": "WEBSITE",
        "url": "https://www.shifumiz.com/"
      },
      {
        "title": "INSTAGRAM",
        "url": "https://www.instagram.com/shifumiz"
      },
      {
        "title": "TICKETS",
        "url": "https://shop.tiks.asia/event/shi-fu-miz-festival-2026-gygsec"
      }
    ],
    "tracking": [],
    "admin": {
      "id": "2345939",
      "username": "ShiFuMiz"
    },
    "tickets": [
      {
        "id": "1248566",
        "title": "EARLY ACCESS / ENTRY BEFORE 2PM",
        "validType": "VALID",
        "onSaleFrom": "2026-02-04T05:00:00.000Z",
        "priceRetail": 73.45,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      },
      {
        "id": "1248568",
        "title": "STUDENT UP TO 23 & KIDS OVER 12",
        "validType": "VALID",
        "onSaleFrom": "2026-02-04T05:00:00.000Z",
        "priceRetail": 73.45,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      },
      {
        "id": "1248570",
        "title": "2nd release",
        "validType": "NOLONGERONSALE",
        "onSaleFrom": "2026-02-04T05:00:00.000Z",
        "priceRetail": 99.45,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      },
      {
        "id": "1248571",
        "title": "3rd release",
        "validType": "VALID",
        "onSaleFrom": "2026-02-04T05:00:00.000Z",
        "priceRetail": 113,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      }
    ],
    "standardTickets": [
      {
        "id": "1248566",
        "validType": "VALID"
      },
      {
        "id": "1248568",
        "validType": "VALID"
      },
      {
        "id": "1248570",
        "validType": "NOLONGERONSALE"
      },
      {
        "id": "1248571",
        "validType": "VALID"
      }
    ],
    "playerLinks": [
      {
        "id": "413389",
        "sourceId": "https://www.youtube.com/watch?v=fuUpgIMNzik&list=PLxfcn8ycY5T1XnA7qZ37kO_u5cl6ZF4uj",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      }
    ],
    "childEvents": [],
    "genres": [
      {
        "id": "5",
        "name": "Techno",
        "slug": "techno"
      },
      {
        "id": "6",
        "name": "House",
        "slug": "house"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2363126",
    "title": "Yung Singh B2B ryota - Hong Kong",
    "flyerFront": null,
    "flyerBack": null,
    "content": "A leading force within Japan’s underground music movement, ryota is the co-founder of Osaka’s influential FULLHOUSE collective, widely credited for shaping the city’s youth-driven club scene. Known for his genre-fluid blend of UK garage, bass music and breakbeats, he has gained international attention through standout appearances across major broadcast platforms and cultural collaborations, including NTS Radio, Rinse FM (London) and BBC Radio 6 Music.\n\nJoining him is Yung Singh, a DJ and curator whose rapid rise has been marked by viral club moments, a BBC Radio 1 residency, and DJ Mag’s Breakthrough DJ of the Year recognition. Fusing UK garage, bass, hip-hop and Punjabi influences, Yung Singh has become one of the defining voices in contemporary club culture, while playing a key role in re-energising British South Asian dance music.\n\nTogether, ryota and Yung Singh promise a high-energy exchange rooted in shared musical language and mutual respect - bridging underground scenes from Japan to the UK and beyond.",
    "minimumAge": 18,
    "cost": "",
    "contentUrl": "/events/2363126",
    "embargoDate": null,
    "date": "2026-03-21T00:00:00.000",
    "startTime": "2026-03-21T22:00:00.000",
    "endTime": "2026-03-22T05:00:00.000",
    "interestedCount": 6,
    "lineup": "<artist id=\"88121\">Yung Singh</artist> <artist id=\"129200\">ryota dj</artist>",
    "isTicketed": false,
    "isFestival": false,
    "dateUpdated": "2026-02-09T01:54:01.167Z",
    "resaleActive": false,
    "datePosted": "2026-02-04T08:47:29.833Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2460754",
        "filename": "https://images.ra.co/449db3a231f0183c3b7dd5a20d92bd677178a559.png",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      }
    ],
    "venue": {
      "id": "210117",
      "name": "Pier 1929",
      "address": "Hong Kong, Wan Chai, Wan Chai Ferry Pier, 2/F",
      "contentUrl": "/clubs/210117",
      "live": true,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 22,
        "longitude": 114
      }
    },
    "promoters": [
      {
        "id": "145725",
        "name": "Collective Minds",
        "contentUrl": "/promoters/145725",
        "live": true,
        "hasTicketAccess": false,
        "tracking": []
      }
    ],
    "artists": [
      {
        "id": "88121",
        "name": "Yung Singh",
        "contentUrl": "/dj/yungsingh",
        "urlSafeName": "yungsingh"
      },
      {
        "id": "129200",
        "name": "ryota dj",
        "contentUrl": "/dj/ryotadj",
        "urlSafeName": "ryotadj"
      }
    ],
    "pick": null,
    "promotionalLinks": [
      {
        "title": "Ticketing",
        "url": "https://megatix.asia/events/yung-singh-and-ryota-hk-2026"
      },
      {
        "title": "Instagram",
        "url": "https://www.instagram.com/collectivemindsasia/"
      }
    ],
    "tracking": [],
    "admin": {
      "id": "11251629",
      "username": "CMasia"
    },
    "tickets": [],
    "standardTickets": [],
    "playerLinks": [],
    "childEvents": [],
    "genres": [
      {
        "id": "4",
        "name": "Drum & Bass",
        "slug": "drumandbass"
      },
      {
        "id": "13",
        "name": "Garage",
        "slug": "garage"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2350877",
    "title": "Hex with Vlada (Spell, Berlin) + Xiaolin (宀, Hong Kong)",
    "flyerFront": null,
    "flyerBack": null,
    "content": "Vlada has rightfully earned her worldwide reputation as a master of musical finesse. Her diverse sonic palette of techno, house, trance and everything in between makes her an equally sought-after act both at sweaty dance floors of Panorama Bar and Multisex, where she effortlessly unleashes her mischievous and seductive selections, putting the crowds in states from frenzy to delirium and more intimate clubs and festivals like Houghton and Waking life whose dancers crave to get hypnotised by deep and obscure. Sleek yet raw, dark yet shimmering, playing out or curating her recent projects Spell and dreamslesssweet, Vlada keeps serving a dazzling DJ master-class of top-tier quality.\n\n\n\nXaolin is a DJ, producer, record collector and instrumentalist from Hong Kong.  Driven by a love for colourful emotions and contrasting textures, she is known for crafting patiently dynamic vinyl-led journeys filled with emotion and depth.  Drawing influence from the 80’s-early 00’s, the former concert violinist and now 宀 resident hosts her trippy club night “HEX”, with guests such as Peach, Vlada, Polygonia, Paquita Gordon and DJ Dustin.  With critically acclaimed releases on 宀 & Sound Metaphors, Xiaolin’s ethereal yet grounded sound has left lasting impressions at Lofi, Panorama Bar, Draaimolen and Monument Festival in 2025, and was recently listed on Mixmag’s “Artists to Watch in 2026”\n\n\n\n",
    "minimumAge": 21,
    "cost": "150$ / 250$ / 350$",
    "contentUrl": "/events/2350877",
    "embargoDate": null,
    "date": "2026-03-27T00:00:00.000",
    "startTime": "2026-03-27T23:00:00.000",
    "endTime": "2026-03-28T06:00:00.000",
    "interestedCount": 21,
    "lineup": "<artist id=\"18441\">Vlada</artist> (Spell, Berlin)\n<artist id=\"95879\">Xiaolin</artist> (宀, Hong Kong)",
    "isTicketed": true,
    "isFestival": false,
    "dateUpdated": "2026-01-20T11:22:26.423Z",
    "resaleActive": false,
    "datePosted": "2026-01-20T10:37:00.857Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2444799",
        "filename": "https://images.ra.co/8f813652433d689f49a9cbbe23ac3bc0c05717a4.jpg",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      },
      {
        "id": "2444800",
        "filename": "https://images.ra.co/5848cdf96eb37b6ad205bdfeb47bfdcfc07a2d42.jpg",
        "alt": null,
        "type": "FLYERBACK",
        "crop": null
      }
    ],
    "venue": {
      "id": "152213",
      "name": "宀 Club",
      "address": "4F, 279 Des Voeux Road Central, Sheung Wan, Hong Kong",
      "contentUrl": "/clubs/152213",
      "live": true,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 22.286855,
        "longitude": 114.151679
      }
    },
    "promoters": [
      {
        "id": "84769",
        "name": "宀 Club",
        "contentUrl": "/promoters/84769",
        "live": true,
        "hasTicketAccess": true,
        "tracking": []
      }
    ],
    "artists": [
      {
        "id": "18441",
        "name": "Vlada",
        "contentUrl": "/dj/vlada",
        "urlSafeName": "vlada"
      },
      {
        "id": "95879",
        "name": "Xiaolin",
        "contentUrl": "/dj/xiaolin",
        "urlSafeName": "xiaolin"
      }
    ],
    "pick": null,
    "promotionalLinks": [
      {
        "title": "Vlada IG",
        "url": "https://www.instagram.com/playvlada_/"
      },
      {
        "title": "Xiaolin IG",
        "url": "https://www.instagram.com/oliviaxiaolin/"
      },
      {
        "title": "宀 IG",
        "url": "https://www.instagram.com/mihnclub/"
      }
    ],
    "tracking": [],
    "admin": {
      "id": "313005",
      "username": "jf.amadei"
    },
    "tickets": [
      {
        "id": "1236205",
        "title": "Early bird",
        "validType": "VALID",
        "onSaleFrom": "2026-01-20T10:30:00.000Z",
        "priceRetail": 22.6,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      },
      {
        "id": "1236210",
        "title": "1st release",
        "validType": "VALID",
        "onSaleFrom": "2026-01-20T10:30:00.000Z",
        "priceRetail": 36.15,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      }
    ],
    "standardTickets": [
      {
        "id": "1236205",
        "validType": "VALID"
      },
      {
        "id": "1236210",
        "validType": "VALID"
      }
    ],
    "playerLinks": [
      {
        "id": "453442",
        "sourceId": "https://soundcloud.com/iremtourfm/iremtourfm-2-erensu-invites-vlada-transcendence-2025",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      },
      {
        "id": "453443",
        "sourceId": "https://soundcloud.com/dkmntl/dekmantel-podcast-453-vlada",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      },
      {
        "id": "453444",
        "sourceId": "https://soundcloud.com/mihnclub/mix099-xiaolin-live-at-coda-by-ratherlost-pax-romana",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      }
    ],
    "childEvents": [],
    "genres": [
      {
        "id": "5",
        "name": "Techno",
        "slug": "techno"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2391737",
    "title": "𝐜𝐢𝐩𝐡𝐞𝐫 𝐩𝐫𝐞𝐬. 𝐋𝐚𝐢𝐦𝐚 𝐀𝐝𝐞𝐥𝐚𝐢𝐝𝐞",
    "flyerFront": null,
    "flyerBack": null,
    "content": "𝐜𝐢𝐩𝐡𝐞𝐫 𝐩𝐫𝐞𝐬. 𝐋𝐚𝐢𝐦𝐚 𝐀𝐝𝐞𝐥𝐚𝐢𝐝𝐞\n\n𝐝𝐚𝐭𝐞: 𝟐𝟕/𝟑/𝟐𝟔 (𝐅𝐫𝐢)\n𝐭𝐢𝐦𝐞: 𝟐𝟐𝟎𝟎 - 𝐥𝐚𝐭𝐞\n𝐥𝐨𝐜𝐚𝐭𝐢𝐨𝐧: 𝐬𝐞𝐜𝐫𝐞𝐭 𝐯𝐞𝐧𝐮𝐞 \n𝐟𝐞𝐞: 𝟏𝟓𝟎 (𝐞𝐚𝐫𝐥𝐲𝐛𝐢𝐫𝐝 𝐭𝐢𝐥𝐥 𝟏𝟖/𝟑 𝟐𝟑:𝟓𝟗); 𝟐𝟓𝟎 (𝐚𝐝𝐯 𝐭𝐢𝐥𝐥 𝟐𝟓/𝟑 𝟐𝟑:𝟓𝟗); 𝟑𝟎𝟎 𝐚𝐭 𝐝𝐨𝐨𝐫\n- 𝐏𝐚𝐲𝐦𝐞𝐧𝐭 𝐦𝐞𝐭𝐡𝐨𝐝𝐬:(𝟔𝟎𝟏𝟏𝟕𝟓𝟎𝟏 [𝐅𝐏𝐒]/𝟔𝟑𝟗𝟒𝟗𝟕𝟒𝟏 [𝐏𝐚𝐲𝐌𝐞]) \n- 𝐏𝐥𝐞𝐚𝐬𝐞 𝐃𝐌 𝐮𝐬 𝐛𝐚𝐜𝐤 𝐲𝐨𝐮𝐫 𝐩𝐚𝐲𝐦𝐞𝐧𝐭 𝐬𝐥𝐢𝐩 𝐰𝐢𝐭𝐡 𝐲𝐨𝐮𝐫 𝐧𝐚𝐦𝐞//付款後請截圖連名一併𝐃𝐌給我們 \n- 𝐍𝐨 𝐑𝐒𝐕𝐏 𝐍𝐨 𝐄𝐧𝐭𝐫𝐲\n-\n\nLineup:\n\nLaima Adelaide - hybrid DJ set -\n(DE, Predawn Records)\nBambi (CN, Riff)\nFinsent C\nDan-neo\nSEIRYŪ\nPierre Életrique\n\n-\nTo carry on the immersive live experience from CNY, this time, we have invited the prolific DJ/producer, Laima Adelaide, who has shaped the new realm of deep hypnotic techno soundscape, to perform a hybrid DJ set. This cipher will be the first stop in Asia to showcase her latest sound development.\n\nThroughout the night, we have two solid b2b DJ sets, comprising with cipher’s residents, to warm things up - first with Dan-neo b2b Pierre Életrique, then Finsent C b2b SEIRYŪ. Each of these eccentric pairings will guide us into the darkest hours of the night.\n\nTo close the night, we will have Bambi from the Changsha underground scene. Bambi is the mastermind behind Riff - a club space that provides a carefully curated lineup every weekends.\n\nThis will be an unusual Friday night with a 1-room setting. We wish everyone gets locked in for this 8-hours+ musical journey.\n\n延續初二拉闊體驗，是次cipher特邀產出不斷的德國製作人Laima Adelaide，來一場hybrid DJ演出。她常突破深沉催眠Techno的界限，而香港將會是她亞洲巡演中，首站展現她最近期的音樂創作成果。\n\n整晚陣容，先由兩組b2b sets，來奠定基調——首場Dan-neo b2b Pierre Életrique，再緊接Finsent C b2b SEIRYŪ。兩組風格鮮明的搭檔，將慢慢拉開這夜的帷幔，徐徐引領我們，在未知的漆黑中潛行。\n\n最後，來自長沙地下場景的Bambi，去為該晚劃上句號。作為長沙俱樂部Riff的靈魂人物，Bambi每個週末均致力地為當地銳舞文化，建構精緻音樂體驗。\n\n3月27日，星期五，僅開大房，凝聚舞池，來一場長達八小時的音樂旅程。",
    "minimumAge": 18,
    "cost": "150/250/300",
    "contentUrl": "/events/2391737",
    "embargoDate": null,
    "date": "2026-03-27T00:00:00.000",
    "startTime": "2026-03-27T22:00:00.000",
    "endTime": "2026-03-28T06:00:00.000",
    "interestedCount": 3,
    "lineup": "<artist id=\"114424\">Laima Adelaide</artist> \nBambi\n<artist id=\"65154\">Finsent C</artist> \n<artist id=\"85495\">Dan-neo</artist> \nSEIRYŪ \nPierre Électrique",
    "isTicketed": false,
    "isFestival": false,
    "dateUpdated": "2026-03-11T16:24:56.200Z",
    "resaleActive": false,
    "datePosted": "2026-03-11T16:24:56.213Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2498820",
        "filename": "https://images.ra.co/144881bbe9cfa1a81348cf8b2f111281bc5ef9a8.png",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      }
    ],
    "venue": {
      "id": "197603",
      "name": "TBA",
      "address": null,
      "contentUrl": null,
      "live": false,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 0,
        "longitude": 0
      }
    },
    "promoters": [],
    "artists": [
      {
        "id": "114424",
        "name": "Laima Adelaide",
        "contentUrl": "/dj/laimaadelaide",
        "urlSafeName": "laimaadelaide"
      },
      {
        "id": "65154",
        "name": "Finsent C",
        "contentUrl": "/dj/finsentc",
        "urlSafeName": "finsentc"
      },
      {
        "id": "85495",
        "name": "Dan-neo",
        "contentUrl": "/dj/dan-neo",
        "urlSafeName": "dan-neo"
      }
    ],
    "pick": null,
    "promotionalLinks": [
      {
        "title": "Laima Adelaide live at Draaimolen Festival 2025",
        "url": "https://soundcloud.com/draaimolen/laima-adelaide-live-at-draaimolen-festival-2025?si=254c84e1f07441c7a872bed1f28f601d&utm_source=clipboard&utm_medium=text&utm_campaign=social_sharing"
      },
      {
        "title": "Laima Adelaide - Opening Set New Faces @Tresor Berlin, 4.9.24",
        "url": "https://soundcloud.com/amlia/laima-adelaide-opening-set-new-faces-tresor-berlin-4924?si=a624b36576b643609754119e9e601ce6&utm_source=clipboard&utm_medium=text&utm_campaign=social_sharing"
      }
    ],
    "tracking": [],
    "admin": {
      "id": "3501954",
      "username": "danneo"
    },
    "tickets": [],
    "standardTickets": [],
    "playerLinks": [],
    "childEvents": [],
    "genres": [
      {
        "id": "5",
        "name": "Techno",
        "slug": "techno"
      },
      {
        "id": "15",
        "name": "Tech House",
        "slug": "techhouse"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2386471",
    "title": "Cakeshop x Yeti Out rave in the sky",
    "flyerFront": null,
    "flyerBack": null,
    "content": "March 27th Hong Kong Art week, iconic Hong Kong collective of taste makers Yeti Out teams up with infamous Korean night club and cultural hub Cakeshop Seoul to bring you your favorite rave of the year, a match made in heaven. Bringing together some of the most forward talents from Asia and the world.\nAs well as breakthrough international headliners who are pushing forward multi-genred lanes., this year we expect a melting pot of sounds that redefine sound and expression, east meets the rest. Join us for another round of Cakeshop x Yeti Out’s Hong Kong Art Basel “rave in the sky.”\nStay tuned for more information:\n\nTicket tiers\n\n+RA link w/ Blind Ticket: HKD: 150 // Early Bird: HKD: 200 // second Tier: 300 // Door TBA\n\nMORE details @cakeshopseoul @yetiout\nLocation will be dropped to ticket holders mid-week event week.\nRsvp@cakeshopseoul.com for up to date event details.\n",
    "minimumAge": 19,
    "cost": "150 200 300",
    "contentUrl": "/events/2386471",
    "embargoDate": null,
    "date": "2026-03-27T00:00:00.000",
    "startTime": "2026-03-27T22:00:00.000",
    "endTime": "2026-03-28T06:00:00.000",
    "interestedCount": 10,
    "lineup": "YETI OUT x CAKESHOP\n27.03.2026\nWAREHOUSE LOCATION TBA\n22:00 - 06:00 \n\n__ (KR)\n__(KR)\n___ (HK)\n__ (VN)\n___ (JP)\n____ (CN) \n___ (KR) \n___ (HK)\n\nART WEEK HONG KONG \n‘RAVE IN THE SKY’ \nEST. 2016",
    "isTicketed": true,
    "isFestival": false,
    "dateUpdated": "2026-03-09T12:10:02.127Z",
    "resaleActive": false,
    "datePosted": "2026-03-05T09:44:00.693Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [],
    "venue": {
      "id": "197603",
      "name": "TBA",
      "address": null,
      "contentUrl": null,
      "live": false,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 0,
        "longitude": 0
      }
    },
    "promoters": [
      {
        "id": "56272",
        "name": "Yeti Out",
        "contentUrl": "/promoters/56272",
        "live": true,
        "hasTicketAccess": false,
        "tracking": []
      },
      {
        "id": "115351",
        "name": "Cakeshop seoul",
        "contentUrl": "/promoters/115351",
        "live": true,
        "hasTicketAccess": true,
        "tracking": []
      }
    ],
    "artists": [],
    "pick": null,
    "promotionalLinks": [],
    "tracking": [],
    "admin": {
      "id": "701680",
      "username": "cakeshopseoul"
    },
    "tickets": [
      {
        "id": "1272640",
        "title": "Early bird",
        "validType": "VALID",
        "onSaleFrom": "2026-03-05T06:00:00.000Z",
        "priceRetail": 20,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      }
    ],
    "standardTickets": [
      {
        "id": "1272640",
        "validType": "VALID"
      }
    ],
    "playerLinks": [],
    "childEvents": [],
    "genres": [
      {
        "id": "12",
        "name": "Bass",
        "slug": "bass"
      },
      {
        "id": "39",
        "name": "Club",
        "slug": "club"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2392457",
    "title": "Howie B live at Salon 10",
    "flyerFront": null,
    "flyerBack": null,
    "content": "Salon 10 proudly presents Howie B live on Friday 27 March as part of the Spectrum Live electronic music series, with support from Paul Bph, Mr. Sit and K Melo.\n\nA true pioneer of electronic music, Howie B has shaped the sound of modern production through collaborations with icons like U2, Björk, Tricky, Brian Eno, and Massive Attack. Known for his fearless experimentation and signature sonic warmth, Howie’s work bridges club culture, studio innovation, and raw musical emotion.\nFrom founding his influential label Pussyfoot to co-producing U2’s Pop album and composing for Wim Wenders, his creative reach knows no bounds.\n\nExperience an unforgettable night of genre-bending beats and pure creative energy—only at Salon 10.",
    "minimumAge": 21,
    "cost": "300",
    "contentUrl": "/events/2392457",
    "embargoDate": null,
    "date": "2026-03-27T00:00:00.000",
    "startTime": "2026-03-27T21:00:00.000",
    "endTime": "2026-03-28T00:00:00.000",
    "interestedCount": 0,
    "lineup": "Paul Bph\nK-Melo\nMr. Sit",
    "isTicketed": false,
    "isFestival": false,
    "dateUpdated": "2026-03-12T10:45:37.803Z",
    "resaleActive": false,
    "datePosted": "2026-03-12T10:45:37.820Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2499826",
        "filename": "https://images.ra.co/2a9e59863e43de401cdcf92a9d0491823685375a.jpg",
        "alt": "Howie B live at Salon 10",
        "type": "FLYERFRONT",
        "crop": null
      }
    ],
    "venue": {
      "id": "81921",
      "name": "Salon Number 10",
      "address": "10 Arbuthnot Road, Hong Kong",
      "contentUrl": "/clubs/81921",
      "live": true,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 22.279982,
        "longitude": 114.154755
      }
    },
    "promoters": [
      {
        "id": "155217",
        "name": "Ahlaiya ",
        "contentUrl": "/promoters/155217",
        "live": false,
        "hasTicketAccess": true,
        "tracking": []
      }
    ],
    "artists": [],
    "pick": null,
    "promotionalLinks": [
      {
        "title": "Salon 10 ticket link",
        "url": "https://salon10.club/collections/events/products/howie-b"
      }
    ],
    "tracking": [],
    "admin": {
      "id": "3017366",
      "username": "ivansit"
    },
    "tickets": [],
    "standardTickets": [],
    "playerLinks": [],
    "childEvents": [],
    "genres": [
      {
        "id": "25",
        "name": "Experimental",
        "slug": "experimental"
      },
      {
        "id": "75",
        "name": "Electronica",
        "slug": "electronica"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2350936",
    "title": "The Sound of 宀 with Jordy Lee + Scott B (Distrikt, HK), Anyss + Sunsiaré (VG+, HK)",
    "flyerFront": null,
    "flyerBack": null,
    "content": "Scott B \nAfter growing up in Hong Kong, Scott left the city to study in Nottingham, where he got a quick introduction to the underground music scene. With DJs Like Ben UFO, Midland and Helena Hauff regularly playing in local venues, he was able to rapidly develop his music taste and become immersed in the culture. In his time away from Hong Kong Scott also spent time in Berlin and Shanghai, where he further developed a keen ear for groovy dark sounds. Whilst in Shanghai he would play at local bars, clubs and outdoor parties, honing his skills\n\n\n\nSunsiaré\nBest known as the musical director of Hong Kong institution 宀 but real heads know him for his obsession with rare records. A devoted collector at heart, he throws himself into electronic music with a scholar's discipline. Known as JF to friends, his sharp ear and interest in history informs his various pursuits–curation, DJing, digging and productions, not to mention his technical audio explorations and label management. \n\nHis sets are raw and driving–think deep basslines, freaky 909s and broken drums over shadowy techno, interstellar electro and lithe breaks. Influenced by legendary label Transmigration and '90s trio Sabres of Paradise, selections fuse '90s grit with heady melodies for an all-killer-no-filler effect. He's played at Pawnshop, Mitsuki and Zhao Dai, sharing the decks alongside Barker, Wada Yosuke and Nd_Baumecker. His holistic approach to building energy in a room means he's always thinking about where to go and the best way to take dancers there. \n\nHis love for adventurous club tunes is best displayed at 宀 where his bookings have grealty helped shaping the musical knowledge of Hong Kongers. Committed to challenging perceptions of what a club floor should sound like, Sunsiaré encourages talents to express the full range of their creative practice. He's brought envelope-pushing acts like Jane Fitz and Lena Willikens to the East Asian metropolis while his vinyl-only party \"VG+\" celebrates exploration and knowledge sharing through workshops, conferences and a group vinyl purchase programme to reduce shipping costs. Recent guests have included Nosedrip, S.O.N.S and Carl H, among others. \n\nA longtime Hong Kong resident, Sunsiaré consistently platforms emerging local acts in his quest to strengthen the local scene. His guidance and support are invaluable to the city's next generation of artists, many who come to him for help on setting up their first turntables and home sound systems. A champion of the pan-Asian underground, he's played a critical role in expanding Asia-Pacific's dance music footprint. From cofounding Hong Kong labels Fragrant Harbour, Homesick and Cliché Records to helping kickstart Hanoi’s esteemed Savage club, his close communication with promoters, bookers and venues have helped form a cohesive regional identity. Now an art gallery, label and venue, 宀 is a home for pan-Asian talents to expand their own subcultures and transcend Eurocentrism in dance music. \n\nWhen he's not playing, in the studio or discussing politics, the self-described Mandarin addict is usually deep in a Reddit discussion over rare analog gear or researching the latest reissue of an obscure techno record. Sunsiaré is pure passion through and through.\\\n\n\nAnyss \nHailing from the vibrant club culture of Paris, Anyss has carved out a name for himself in Hong Kong’s dynamic electronic music scene. After an extended hiatus, he’s thrilled to return to the decks at 宀 Club, this time supporting the immensely talented Roza Terenzi. Renowned for his eclectic sound, Anyss is set to deliver a hybrid set that seamlessly weaves together progressive techno, acid house, and trance. With an unwavering passion for music and an electric stage presence, he’s ready to craft an unforgettable journey on the dancefloor—one filled with energy, emotion, and connection. Don’t miss this special night as Anyss brings his unique style and vibrant energy back to life, reigniting the rhythm and magic that make his sets so memorable.\n\n\n\nJordy Lee\nHong Kong native Jordy Lee is no stranger to the underground music scene. As a co-founder of the music collective and club night Distrikt, Jordy has made his mark on the local circuit through pushing innovative soundscapes and crafting parties that champion the deeper and groovier sides of techno.\n\nWith a residency at Hong Kong’s 宀 Club, Jordy has gone on to collaborate with essential voices of the industry including Berghain’s Fadi Mohem, Animalia’s Kia, Mala Junta’s D.Dan, and the inimitable John Talabot, just to name a few. \n\nGalvanised by the intersection of early rave culture and modern sonics, Jordy’s understated versatility traverses through a distinctive exploration of groove, flow and trippy psychedelia – all firmly rooted in driving dance floor energy. ",
    "minimumAge": 21,
    "cost": "150$ / 200$ / 300$",
    "contentUrl": "/events/2350936",
    "embargoDate": null,
    "date": "2026-03-28T00:00:00.000",
    "startTime": "2026-03-28T23:00:00.000",
    "endTime": "2026-03-29T06:00:00.000",
    "interestedCount": 12,
    "lineup": "<artist id=\"64239\">Sunsiaré</artist> (宀, Hong Kong)\n<artist id=\"108715\">Jordy Lee</artist> (Distrikt, Hong Kong)\n<artist id=\"114918\">Anyss</artist> (VG+, Hong Kong)\n<artist id=\"120617\">Scott B</artist> (Distrik, Hong Kong)",
    "isTicketed": true,
    "isFestival": false,
    "dateUpdated": null,
    "resaleActive": false,
    "datePosted": "2026-01-20T11:41:36.553Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2444891",
        "filename": "https://images.ra.co/c97ae0fd03551b2b74623448a0d3eaea24a20e8c.jpg",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      }
    ],
    "venue": {
      "id": "152213",
      "name": "宀 Club",
      "address": "4F, 279 Des Voeux Road Central, Sheung Wan, Hong Kong",
      "contentUrl": "/clubs/152213",
      "live": true,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 22.286855,
        "longitude": 114.151679
      }
    },
    "promoters": [
      {
        "id": "84769",
        "name": "宀 Club",
        "contentUrl": "/promoters/84769",
        "live": true,
        "hasTicketAccess": true,
        "tracking": []
      }
    ],
    "artists": [
      {
        "id": "64239",
        "name": "Sunsiaré",
        "contentUrl": "/dj/sunsiare",
        "urlSafeName": "sunsiare"
      },
      {
        "id": "108715",
        "name": "Jordy Lee",
        "contentUrl": "/dj/jordylee",
        "urlSafeName": "jordylee"
      },
      {
        "id": "114918",
        "name": "Anyss",
        "contentUrl": "/dj/anyss",
        "urlSafeName": "anyss"
      },
      {
        "id": "120617",
        "name": "Scott B",
        "contentUrl": "/dj/scottb",
        "urlSafeName": "scottb"
      }
    ],
    "pick": null,
    "promotionalLinks": [
      {
        "title": "Distrikt IG",
        "url": "https://www.instagram.com/distrikt_hk/?hl=en"
      },
      {
        "title": "VG+ IG",
        "url": "https://www.instagram.com/vgplus__/?hl=en"
      },
      {
        "title": "宀 IG",
        "url": "https://www.instagram.com/mihnclub/"
      }
    ],
    "tracking": [],
    "admin": {
      "id": "313005",
      "username": "jf.amadei"
    },
    "tickets": [
      {
        "id": "1236279",
        "title": "Early bird",
        "validType": "VALID",
        "onSaleFrom": "2026-01-20T11:30:00.000Z",
        "priceRetail": 22.6,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      },
      {
        "id": "1236281",
        "title": "1st release",
        "validType": "VALID",
        "onSaleFrom": "2026-01-20T11:30:00.000Z",
        "priceRetail": 28.25,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      },
      {
        "id": "1236283",
        "title": "Advance ticket",
        "validType": "VALID",
        "onSaleFrom": "2026-01-20T11:30:00.000Z",
        "priceRetail": 36.15,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      }
    ],
    "standardTickets": [
      {
        "id": "1236279",
        "validType": "VALID"
      },
      {
        "id": "1236281",
        "validType": "VALID"
      },
      {
        "id": "1236283",
        "validType": "VALID"
      }
    ],
    "playerLinks": [
      {
        "id": "453474",
        "sourceId": "https://soundcloud.com/mihnclub/mix082-jordy-lee-live-at",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      }
    ],
    "childEvents": [],
    "genres": [
      {
        "id": "2",
        "name": "Trance",
        "slug": "trance"
      },
      {
        "id": "5",
        "name": "Techno",
        "slug": "techno"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2375028",
    "title": "Magic Room — Hong Kong — AIA Vitality Park",
    "flyerFront": null,
    "flyerBack": null,
    "content": "Magic Room — Hong Kong — AIA Vitality Park\n\nSome places become a consistent part of the story, not by chance, but by choice. AIA Vitality Park is one of them.\n\nOn March 28, 2026, Magic Room returns to Hong Kong for our 5 Year Anniversary Celebration, to this open-air space. Community first, the skyline behind us, boats moving through the harbor, and the city lights flickering in the distance. This is Hong Kong.\n\nLeading the experience is Musumeci and Lehar, a rare meeting of two defining forces in melodic and house music, merging Italian depth with cinematic energy for a special back-to-back set.\n\nThey’re joined by Copenhagen-based DJ & producer Radeckt, alongside our Nodes Crew — Leon (FR), Mo-Shi, and Milam, with Nat Dunn completing the circle.\n\nThank you to everyone who’s been part of the road that led us back here, and to those about to step into it for the first time, we welcome you with open arms.\n\nSee you under the neon lights.\n\n28.03.2026\nAIA Vitality Park, Hong Kong\n\n@musumecirules\n@leharmusic\n@radeckt\n@leon_nds\n@moshi_nds\n@milam.music\n@naaatdunn",
    "minimumAge": 20,
    "cost": "",
    "contentUrl": "/events/2375028",
    "embargoDate": null,
    "date": "2026-03-28T00:00:00.000",
    "startTime": "2026-03-28T15:00:00.000",
    "endTime": "2026-03-28T22:30:00.000",
    "interestedCount": 2,
    "lineup": "<artist id=\"43481\">Musumeci</artist> \n<artist id=\"48367\">Lehar</artist> \n<artist id=\"61771\">Radeckt</artist> \n<artist id=\"100584\">Leon (FR)</artist> \n<artist id=\"100585\">Mo-Shi</artist> \n<artist id=\"104285\">Milam</artist> \nNat Dunn",
    "isTicketed": false,
    "isFestival": false,
    "dateUpdated": "2026-02-23T03:53:20.767Z",
    "resaleActive": false,
    "datePosted": "2026-02-19T10:37:19.150Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2477577",
        "filename": "https://images.ra.co/727cd80684d25e4d8dbceb26acca273a4d4a0f6a.png",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      }
    ],
    "venue": {
      "id": "232143",
      "name": "TBA - AIA Vitality Park",
      "address": null,
      "contentUrl": null,
      "live": false,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 0,
        "longitude": 0
      }
    },
    "promoters": [
      {
        "id": "99262",
        "name": "Magic Room",
        "contentUrl": "/promoters/99262",
        "live": true,
        "hasTicketAccess": true,
        "tracking": []
      }
    ],
    "artists": [
      {
        "id": "43481",
        "name": "Musumeci",
        "contentUrl": "/dj/musumeci",
        "urlSafeName": "musumeci"
      },
      {
        "id": "48367",
        "name": "Lehar",
        "contentUrl": "/dj/lehar",
        "urlSafeName": "lehar"
      },
      {
        "id": "61771",
        "name": "Radeckt",
        "contentUrl": "/dj/radeckt",
        "urlSafeName": "radeckt"
      },
      {
        "id": "100584",
        "name": "Leon (FR)",
        "contentUrl": "/dj/leon-fr",
        "urlSafeName": "leon-fr"
      },
      {
        "id": "100585",
        "name": "Mo-Shi",
        "contentUrl": "/dj/mo-shi",
        "urlSafeName": "mo-shi"
      },
      {
        "id": "104285",
        "name": "Milam",
        "contentUrl": "/dj/milam",
        "urlSafeName": "milam"
      }
    ],
    "pick": null,
    "promotionalLinks": [
      {
        "title": "Tickets",
        "url": "https://www.zicket.co/events/magic-room-season-50-anniversary-1983242679241"
      }
    ],
    "tracking": [],
    "admin": {
      "id": "4959840",
      "username": "LeoA852"
    },
    "tickets": [],
    "standardTickets": [],
    "playerLinks": [],
    "childEvents": [],
    "genres": [
      {
        "id": "6",
        "name": "House",
        "slug": "house"
      },
      {
        "id": "20",
        "name": "Deep House",
        "slug": "deephouse"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2350836",
    "title": "Reach Invites moe. (Endless Groove, Berlin) + JayMe + The Heman + Andy-S (Reach, Hong Kong)",
    "flyerFront": null,
    "flyerBack": null,
    "content": "moe.\nAs a party lover, dancer, DJ, radio host, and community organiser, I am forever inspired by and in love with music and dance floors: the communal love, joy, and togetherness that beam from shared moments within them.\n\nA globetrotter at heart, having lived in Dubai, New Orleans, Kuala Lumpur, Stockholm, and Berlin, I have traveled the world pursuing the magical feeling dance floors can exude. This search proved to me that, regardless of location, genres do not matter. What matters is the feeling the music gives, the soul you put into it, and the space you hold as a participant in the collective experience, whether as a dancer, DJ, or organiser.\n\nThis philosophy heavily informs both my musical taste and the projects I explore, organise, and curate. I am a resident of The Breakfast Show on Berlin’s online radio station Refuge Worldwide, co-host of Endless Groove, a non-profit Loft-inspired community party in Stockholm and Berlin, initiator of Black Is..., a gender-inclusive platform supporting BIPOC voices in Berlin and Amsterdam, founder of Wild Combination, a Berlin-based multi-collective showcase benefiting essential causes, and curator of the VIBRATIO)))NS mix series.\n\nAndy-S\nAndy-S has a massive drive to bring back a purer form of partying to modern times—where people feel truly connected, open, and free; where they can dance without inhibition and express their emotions without worry. He has been the driving force and main organiser behind Reach (Reach4luvHK) and its events, with a clear motivation to unite Hong Kong’s house music community while introducing legendary artists such as Tama Sumo & Lakuti, Fred P, musclecars, and Masalo to local audiences.\n\nGrowing up in early 1980s UK in a musical household, Andy-S began playing trumpet and percussion from a young age. His journey into electronic music began in the mid-1990s, when he witnessed first-hand the raves and free parties that defined the UK underground, as well as the evolving club scene in London. His passion for DJing soon followed, leading him to build a collection of over 2,000 house, disco, and techno records—many of them rare and obscure.\nOver the years, while balancing a demanding career in motor sports, Andy-S has played at notable clubs and warehouse venues across London, Brighton, and Berlin. He also co-organised the Square Root warehouse parties in London with two friends, and launched a music production project, L.U.E, alongside his longtime friend and studio partner Udo Scharfenberg (Angel D) in Berlin.\n\nSince relocating to Hong Kong, Andy-S has been able to dedicate more time to his passion for music. He has DJed at many of the city’s top venues, including Mihn, Salon 10, BTD, Pier 1929, and Acadana. Looking ahead, exciting things are on the horizon for Reach and L.U.E, with the focus shifting toward a new production and DJ partnership with Cortecx, and new tracks ready for imminent release. You can be sure that Andy-S will continue to be one of the driving forces behind it all.\n\nJayMe\nJayMe is one of the most respected figures in Hong Kong’s local music scene. He is the founder of Acadana, a unique venture that operates both as an underground club in the New Territories and as a music collective. Acadana has hosted nights alongside international heavyweights such as Colleen \"Cosmo\" Murphy, Palms Trax, and Hunee, with a program dedicated to music in its purest form and the most heartfelt clubbing experiences. JayMe is also a key member of Reach, further cementing his influence in the city’s underground community.\n\nA true music enthusiast, JayMe holds an impressive collection of over 4,000 vinyl records and is celebrated for his versatility behind the decks — one of the rare DJs capable of seamlessly blending across genres.\n\nHaving grown up in the 1970s, witnessing the disco boom first-hand, he has spent more than three decades collecting records and immersing himself in nightlife culture. Since beginning his DJ career in 2013, alongside his work in medicine, he has earned the affectionate nickname “The Disco Doctor.”\n\nIn recent years, JayMe has continued to expand his artistic expression. His latest project included his debut live performance at the Art Basel Hong Kong Artist Showcase at Tai Kwun, as part of the yisekai duo. During the performance, he played keyboards and lead vocals alongside Woonji, blending ambient, drone, and distorted textures inspired by ’80s synthpop, nu‑disco, and his beloved cat, Sindy.\n\nThe Heman\nThe Heman is an entrepreneur, musician, DJ, and party organizer based in Hong Kong.\nHe began his DJ career at the age of 18 and launched his first label, Care3, in 2012 — hosting vibrant disco and house music events across clubhouses and private venues. Within a few years, his growing influence led him to become club manager at Acadana, one of Hong Kong’s well‑known underground clubs, he later co‑founded the creative collective HKCR and the future funk / vaporwave label Neoncity Records. \n\nHe has curated countless DJ radio shows and has been instrumental in bringing international artists such as Yung Bae, Night Tempo, Macross 82‑99, Vantage, and others to perform in Hong Kong. Beyond his work as a DJ and promoter, he also performs violin with the local folk ensemble New Youth Barber Shop, appearing at Clockenflap 2017 and touring the East Sea Festival in 2018.\n\nWhen clubs and venues closed during the pandemic, Heman shifted his focus toward music education and community building through his institution Millzik. There, he works to spread awareness and appreciation for DJ culture by developing educational programs in schools and collaborating with NGOs and churches.\n\nToday, Heman continues to be an active force in Hong Kong’s electronic music scene as a core member of local DJ collectives Reach and ABYSS, staying true to his passion for nurturing and contributing to the city’s vibrant sonic landscape.",
    "minimumAge": 21,
    "cost": "150$ / 250$",
    "contentUrl": "/events/2350836",
    "embargoDate": null,
    "date": "2026-04-02T00:00:00.000",
    "startTime": "2026-04-02T23:00:00.000",
    "endTime": "2026-04-03T06:00:00.000",
    "interestedCount": 10,
    "lineup": "<artist id=\"117863\">moe.</artist> (Endless Groove, Berlin)\n<artist id=\"137135\">Andy-S</artist> (Reach, Hong Kong)\n<artist id=\"82180\">JayMe</artist> (Reach, Hong Kong)\n<artist id=\"156929\">The Heman</artist> (Reach, Hong Kong)",
    "isTicketed": true,
    "isFestival": false,
    "dateUpdated": null,
    "resaleActive": false,
    "datePosted": "2026-01-20T09:52:37.880Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2444741",
        "filename": "https://images.ra.co/7c8cbe34e6af79a9b6381fe2c6f17c773bbfd8ae.jpg",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      },
      {
        "id": "2444742",
        "filename": "https://images.ra.co/0b0b4fd4e86b78fb50986072bab26619f38663a7.jpg",
        "alt": null,
        "type": "FLYERBACK",
        "crop": null
      }
    ],
    "venue": {
      "id": "152213",
      "name": "宀 Club",
      "address": "4F, 279 Des Voeux Road Central, Sheung Wan, Hong Kong",
      "contentUrl": "/clubs/152213",
      "live": true,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 22.286855,
        "longitude": 114.151679
      }
    },
    "promoters": [
      {
        "id": "84769",
        "name": "宀 Club",
        "contentUrl": "/promoters/84769",
        "live": true,
        "hasTicketAccess": true,
        "tracking": []
      },
      {
        "id": "136860",
        "name": "Reach 4 luv hk",
        "contentUrl": "/promoters/136860",
        "live": true,
        "hasTicketAccess": false,
        "tracking": []
      }
    ],
    "artists": [
      {
        "id": "117863",
        "name": "moe.",
        "contentUrl": "/dj/moe.",
        "urlSafeName": "moe."
      },
      {
        "id": "137135",
        "name": "Andy-S",
        "contentUrl": "/dj/andy-s",
        "urlSafeName": "andy-s"
      },
      {
        "id": "82180",
        "name": "JayMe",
        "contentUrl": "/dj/jayme",
        "urlSafeName": "jayme"
      },
      {
        "id": "156929",
        "name": "The Heman",
        "contentUrl": "/dj/theheman",
        "urlSafeName": "theheman"
      }
    ],
    "pick": null,
    "promotionalLinks": [
      {
        "title": "moe. IG",
        "url": "https://www.instagram.com/moe.elamin/"
      },
      {
        "title": "Reach IG",
        "url": "https://www.instagram.com/reach4luvhk/"
      },
      {
        "title": "宀 IG",
        "url": "https://www.instagram.com/mihnclub/"
      }
    ],
    "tracking": [],
    "admin": {
      "id": "313005",
      "username": "jf.amadei"
    },
    "tickets": [
      {
        "id": "1236165",
        "title": "Advance ticket",
        "validType": "VALID",
        "onSaleFrom": "2026-01-20T09:30:00.000Z",
        "priceRetail": 22.6,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      }
    ],
    "standardTickets": [
      {
        "id": "1236165",
        "validType": "VALID"
      }
    ],
    "playerLinks": [
      {
        "id": "453414",
        "sourceId": "https://soundcloud.com/refugeworldwide/the-breakfast-show-moe-hunee",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      },
      {
        "id": "453415",
        "sourceId": "https://soundcloud.com/marcelvogel/lumberjacks-tapes-040-moe-endless-groove",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      }
    ],
    "childEvents": [],
    "genres": [
      {
        "id": "6",
        "name": "House",
        "slug": "house"
      },
      {
        "id": "21",
        "name": "Disco",
        "slug": "disco"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2361911",
    "title": "rural at 宀 with Atsushi Maeda + Nao (Rural, Tokyo) & Yadin Moha (Zagareet, Hong Kong)",
    "flyerFront": null,
    "flyerBack": null,
    "content": "宀 is thrilled to welcome the visionary team behind Japan’s revered open-air electronic music festival, rural. Known for cultivating deep, avant-garde, and uncompromising soundscapes, the rural crew is bringing the distinct spirit of their celebrated festival to Hong Kong for an unforgettable night of boundary-pushing electronic music.\n\nLeading the charge is Atsushi Maeda, the founder and driving force behind rural. Always stepping into the booth with the intent to “leave the floor astonished,” Atsushi’s DJ style is dedicated to guiding audiences into uncharted sonic territories. Recently returning to an active DJ role, he has been captivating dance floors across the globe—from Organik Festival and his curated 428 Stage at Wonderfruit, to iconic techno institutions like Basement (New York), Bassiani (Tbilisi), and Ankali (Prague). Expect a masterclass in the kind of relentless, forward-thinking techno that rural stands for.\n\nJoining him is long-standing rural resident Nao. A vital pillar of the festival and a promoter with a taste for the unique (having brought acts like Cut Hands and Dolphins Into The Future to Japan), Nao traverses a wide spectrum of genres anchored in techno. Her distinct, groovy, and deeply hypnotic style has earned her a dedicated global following. Fresh off her 2024 tours across Europe and the Americas, Nao brings her signature sound to 宀, carrying the energy that has lit up legendary rooms like Tresor, Bassiani, and Basement.\n\nRounding out the lineup is Yadin Moha, an artist who plays music that is as much for the dance floor as it is for staring at the ceiling. Representing the Zagareet collective, Yadin will weave a diverse sonic tapestry, wading in and out of experimental electronics, psychedelia, wave, post-punk, electro, and techno. He provides the perfect eclectic counterpoint, steadily pushing fringe sounds to the forefront.\n\nPrepare for a night of deep, hypnotic, and mind-expanding frequencies as the essence of Japan's underground open-air scene descends upon 宀.",
    "minimumAge": 21,
    "cost": "150$ / 250$",
    "contentUrl": "/events/2361911",
    "embargoDate": null,
    "date": "2026-04-03T00:00:00.000",
    "startTime": "2026-04-03T23:00:00.000",
    "endTime": "2026-04-04T06:00:00.000",
    "interestedCount": 11,
    "lineup": "<artist id=\"117140\">Atsushi Maeda</artist> (rural, Tokyo)\n<artist id=\"70850\">Yadin Moha</artist> (Zagareet, Hong Kong)\n<artist id=\"84497\">Nao(rural)</artist> (rural, Tokyo)",
    "isTicketed": true,
    "isFestival": false,
    "dateUpdated": "2026-03-11T12:13:20.113Z",
    "resaleActive": false,
    "datePosted": "2026-02-03T07:55:08.903Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2459084",
        "filename": "https://images.ra.co/9a7c0a01b93f159a83180d693363102ece6fc1c7.jpg",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      }
    ],
    "venue": {
      "id": "152213",
      "name": "宀 Club",
      "address": "4F, 279 Des Voeux Road Central, Sheung Wan, Hong Kong",
      "contentUrl": "/clubs/152213",
      "live": true,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 22.286855,
        "longitude": 114.151679
      }
    },
    "promoters": [
      {
        "id": "84769",
        "name": "宀 Club",
        "contentUrl": "/promoters/84769",
        "live": true,
        "hasTicketAccess": true,
        "tracking": []
      }
    ],
    "artists": [
      {
        "id": "117140",
        "name": "Atsushi Maeda",
        "contentUrl": "/dj/atsushimaeda",
        "urlSafeName": "atsushimaeda"
      },
      {
        "id": "70850",
        "name": "Yadin Moha",
        "contentUrl": "/dj/yadinmoha",
        "urlSafeName": "yadinmoha"
      },
      {
        "id": "84497",
        "name": "Nao(rural)",
        "contentUrl": "/dj/naorural",
        "urlSafeName": "naorural"
      }
    ],
    "pick": null,
    "promotionalLinks": [
      {
        "title": "Rural IG",
        "url": "https://www.instagram.com/rural.jp/"
      },
      {
        "title": "Atsushi Maeda IG",
        "url": "https://www.instagram.com/ruralatsushi/"
      },
      {
        "title": "Nao IG",
        "url": "https://www.instagram.com/naomyan610/"
      }
    ],
    "tracking": [],
    "admin": {
      "id": "313005",
      "username": "jf.amadei"
    },
    "tickets": [
      {
        "id": "1247359",
        "title": "Advance ticket",
        "validType": "VALID",
        "onSaleFrom": "2026-02-03T07:30:00.000Z",
        "priceRetail": 22.6,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      }
    ],
    "standardTickets": [
      {
        "id": "1247359",
        "validType": "VALID"
      }
    ],
    "playerLinks": [
      {
        "id": "458805",
        "sourceId": "https://soundcloud.com/rural_jp/atsushi-maeda-at-rural-2024",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      },
      {
        "id": "458807",
        "sourceId": "https://soundcloud.com/428soundwave/yadin-moha-at-428-wonderfruit-2024",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      },
      {
        "id": "473779",
        "sourceId": "https://soundcloud.com/narr-radio/nao-21-02-26",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      }
    ],
    "childEvents": [],
    "genres": [
      {
        "id": "5",
        "name": "Techno",
        "slug": "techno"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2324876",
    "title": "House of Ho with Vass (Cartulis, London) + Mr. Ho (Klasse Wrecks, Hong Kong)",
    "flyerFront": null,
    "flyerBack": null,
    "content": "Vass delivers a distinct strain of avant‑garde, acid‑tinged melodic trip music, spanning all areas of intelligent, emotive, groovy, and hypnotic sounds from past and present.\n\nA passionate and relentless digger with the technical skill to shape sophisticated narratives, he has carved out a unique take on trance‑inducing late‑night club music. His obsessive devotion and rare talent for threading together bold and intoxicating underground records give his sets a signature charm.\n\nBorn in Transylvania to a Hungarian family and long established in London’s underground scene—where he has lived for over a decade—he is now a resident of the renowned collective Cartulis and founder of The Comfort record label.\n\nHis dedicated, distinctive nature and stand‑out, club‑melting performances have rightfully taken him around the world. With a genre‑defying record bag full of hazy rhythms and stylish electro futurism that push the boundaries of raw and classic dancefloor sounds, he is the perfect fit for both clubs and intimate after‑hours alike.\n\n\nMR. HO\nMR. HO is a music collector, DJ, Producer and Label Owner. Born and based in Hong Kong, Mr. Ho has been involved in electronic dance music for over decade, and is regarded as a key figure in the contemporary scene in Asia. Alongside Luca Lozano, Mr. Ho runs and curates Klasse Wrecks, the label that has been consistently responsible for some of the most highly anticipated and desired records in electronic music in recent years. As a producer, Mr Ho has made music for Klasse Wrecks, Cabaret Recordings, Clone Records, Permanent Vacation, Gudu and a few select others. \n\nEvery creation my Mr. Ho has a strong personal identity and an irresistible charm for the dancefloor, which explains why so much of Mr Ho’s music are considered staples in the record crates of many. Take for example, his crossover hit “Bail-E” - a record made during the Covid pandemic that is not only a hit across dancefloors over the globe, and became the soundtrack to major festivals from Sunwaves to Dekmantel. Coming up to four years since its original release, this record is still currently still in playlists and remains a highly desirable record amongst djs. \n\nMuch like his production, Mr. Ho’s dj sets cross diverse genres and time, spanning from decades of music from diverse House, Techno and Electro. Having started out as a battle dj on the international circuit already in his teens, Mr. Ho has developed an easy and natural ability on the turntables. Be it a festival slot or a an extend nightclub set, Mr. Ho dj sets always bring an almost bottomless sense of ecstatic energy and total immersion.",
    "minimumAge": 21,
    "cost": "150$ / 250$",
    "contentUrl": "/events/2324876",
    "embargoDate": null,
    "date": "2026-04-04T00:00:00.000",
    "startTime": "2026-04-04T23:00:00.000",
    "endTime": "2026-04-05T06:00:00.000",
    "interestedCount": 17,
    "lineup": "<artist id=\"82421\">Vass</artist> (Cartulis, London)\n<artist id=\"20717\">Mr. Ho</artist> (Klasse Wrecks)",
    "isTicketed": true,
    "isFestival": false,
    "dateUpdated": "2026-01-20T11:57:27.043Z",
    "resaleActive": false,
    "datePosted": "2025-12-11T06:59:11.683Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2410311",
        "filename": "https://images.ra.co/610becc60e1b2f67df697c80273abd227c9008d5.jpg",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      },
      {
        "id": "2444908",
        "filename": "https://images.ra.co/854c1d8e8e43370a5bb994c8f14b8e5b51f4daa3.jpg",
        "alt": null,
        "type": "FLYERBACK",
        "crop": null
      }
    ],
    "venue": {
      "id": "152213",
      "name": "宀 Club",
      "address": "4F, 279 Des Voeux Road Central, Sheung Wan, Hong Kong",
      "contentUrl": "/clubs/152213",
      "live": true,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 22.286855,
        "longitude": 114.151679
      }
    },
    "promoters": [
      {
        "id": "84769",
        "name": "宀 Club",
        "contentUrl": "/promoters/84769",
        "live": true,
        "hasTicketAccess": true,
        "tracking": []
      }
    ],
    "artists": [
      {
        "id": "82421",
        "name": "Vass",
        "contentUrl": "/dj/vass",
        "urlSafeName": "vass"
      },
      {
        "id": "20717",
        "name": "Mr. Ho",
        "contentUrl": "/dj/mr.ho",
        "urlSafeName": "mr.ho"
      }
    ],
    "pick": null,
    "promotionalLinks": [
      {
        "title": "VASS IG",
        "url": "https://www.instagram.com/vass_vass_vass/"
      },
      {
        "title": "Cartulis IG",
        "url": "https://www.instagram.com/cartulismusic/"
      },
      {
        "title": "Mr. Ho IG",
        "url": "https://www.instagram.com/mrhodj/?hl=en"
      }
    ],
    "tracking": [],
    "admin": {
      "id": "313005",
      "username": "jf.amadei"
    },
    "tickets": [
      {
        "id": "1231665",
        "title": "Advance ticket",
        "validType": "VALID",
        "onSaleFrom": "2026-01-14T03:30:00.000Z",
        "priceRetail": 22.6,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      }
    ],
    "standardTickets": [
      {
        "id": "1231665",
        "validType": "VALID"
      }
    ],
    "playerLinks": [
      {
        "id": "441006",
        "sourceId": "https://soundcloud.com/kalaharioystercult/the-sizeable-mix-vol-31-vass",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      },
      {
        "id": "441007",
        "sourceId": "https://soundcloud.com/dimensionsfestival/vass",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      },
      {
        "id": "453480",
        "sourceId": "https://soundcloud.com/dkmntl/luca-lozano-mr-ho-at-dekmantel-ten",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      }
    ],
    "childEvents": [],
    "genres": [
      {
        "id": "5",
        "name": "Techno",
        "slug": "techno"
      },
      {
        "id": "6",
        "name": "House",
        "slug": "house"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2384104",
    "title": "Monolink 2026 Live Asia Tour - Hong Kong",
    "flyerFront": null,
    "flyerBack": null,
    "content": "Monolink is one of the most compelling live electronic artists in the world today. Blurring intimate songwriting with cinematic melodic techno, his performances have captivated global audiences, with his iconic CERCLE set surpassing 30 million views and his music amassing hundreds of millions of streams worldwide.\n\nHe’s headlined major festivals and stages across Europe, the Americas, and Asia, bringing his signature fusion of live vocals, guitar, and driving electronic production to some of the world’s most respected venues.\n\nKnown for his emotional intensity, hypnotic builds, and powerful storytelling, Monolink’s live shows aren’t just DJ sets - they’re immersive journeys that move between raw vulnerability and euphoric release.\n\nThis is the artist redefining live melodic techno - and he’s bringing his full live show to Hong Kong for one night only.",
    "minimumAge": 18,
    "cost": "",
    "contentUrl": "/events/2384104",
    "embargoDate": null,
    "date": "2026-04-04T00:00:00.000",
    "startTime": "2026-04-04T20:00:00.000",
    "endTime": "2026-04-04T23:00:00.000",
    "interestedCount": 3,
    "lineup": "<artist id=\"57373\">Monolink</artist>",
    "isTicketed": false,
    "isFestival": false,
    "dateUpdated": "2026-03-11T10:16:09.990Z",
    "resaleActive": false,
    "datePosted": "2026-03-03T09:21:17.957Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2488412",
        "filename": "https://images.ra.co/9340fd81a0df4bec13fdd944809d4eac4c4150f4.png",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      }
    ],
    "venue": {
      "id": "287283",
      "name": "Tides",
      "address": "Hong Kong, Hung Hom, Tak On St, 1號Whampoa GardenSite 6",
      "contentUrl": null,
      "live": false,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 0,
        "longitude": 0
      }
    },
    "promoters": [
      {
        "id": "145725",
        "name": "Collective Minds",
        "contentUrl": "/promoters/145725",
        "live": true,
        "hasTicketAccess": false,
        "tracking": []
      }
    ],
    "artists": [
      {
        "id": "57373",
        "name": "Monolink",
        "contentUrl": "/dj/monolink",
        "urlSafeName": "monolink"
      }
    ],
    "pick": null,
    "promotionalLinks": [
      {
        "title": "Get Tickets",
        "url": "http://ticketflap.com/monolink-2026-asia-tour-hk"
      },
      {
        "title": "Instagram",
        "url": "https://www.instagram.com/collectivemindsasia/"
      }
    ],
    "tracking": [],
    "admin": {
      "id": "11251629",
      "username": "CMasia"
    },
    "tickets": [],
    "standardTickets": [],
    "playerLinks": [],
    "childEvents": [],
    "genres": [
      {
        "id": "5",
        "name": "Techno",
        "slug": "techno"
      },
      {
        "id": "75",
        "name": "Electronica",
        "slug": "electronica"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2319865",
    "title": "Keinemusik Hong Kong",
    "flyerFront": null,
    "flyerBack": null,
    "content": "The wait is over — Keinemusik arrives in Hong Kong for the first time \n\nKeinemusik is making the trio's long-anticipated East Asia debut in the heart of Hong Kong, Get ready for a night of dance and dream by the water at AXA Wonderland on 5 April 2026. \n\nFounded in 2009 in Berlin, Keinemusik is a collective and electronic music label consisting of DJs and producers Adam Port, &ME, Rampa, and Reznik.\n\nOver the years, they’ve carved out a space of their own in the music world, shaping an instantly recognisable sound that moves between techno, deep house, and global rhythms. \n\nEven their name plays by its own rules, cheekily translating to ‘no music’ in German.\n\nToday, Keinemusik has grown into a global movement, captivating music lovers across the world with tracks like Move, their 2023 release with Stryv featuring Malachiii and Orso, and Adam Port’s You Are Safe, produced with the crew.\n\nThey have also teamed up with major names, including house icon Black Coffee, with whom they released The Rapture Pt.III in 2017, a track that electrified both the internet and the global music stage.\n\nFuelled by their infectious energy, Keinemusik comes alive on stage beneath their iconic giant Kloud, uniting a global community of electronic music fans. The collective has played hundreds of sold out shows in over 60 countries. One of the biggest being their homecoming event at Tempelhofer Feld in Berlin in August 2025 that drew over 65,000 fans in attendance.\n\nThey’ve lit up the stages of Coachella, Tomorrowland, and delivered unforgettable moments at landmark locations like the Giza Pyramids in Egypt, with their upcoming show at the Abu Dhabi Grand Prix, all set to bring that same level of musical mastery.\n",
    "minimumAge": 18,
    "cost": "880",
    "contentUrl": "/events/2319865",
    "embargoDate": null,
    "date": "2026-04-05T00:00:00.000",
    "startTime": "2026-04-05T16:00:00.000",
    "endTime": "2026-04-05T22:00:00.000",
    "interestedCount": 23,
    "lineup": "Adam Port\n&Me\nRampa",
    "isTicketed": false,
    "isFestival": false,
    "dateUpdated": "2025-12-04T09:46:03.733Z",
    "resaleActive": false,
    "datePosted": "2025-12-04T09:46:03.753Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2403392",
        "filename": "https://images.ra.co/3545489f36e38732de49a8306885e5bfed2fa1b9.png",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      }
    ],
    "venue": {
      "id": "97916",
      "name": "West Kowloon Waterfront Promenade",
      "address": "西九龍海濱長廊 West Kowloon Waterfront Promenade Tsim Sha Tsui, Hong Kong",
      "contentUrl": "/clubs/97916",
      "live": true,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 22.302636,
        "longitude": 114.165206
      }
    },
    "promoters": [
      {
        "id": "177409",
        "name": "Live Nation Electronic Asia",
        "contentUrl": "/promoters/177409",
        "live": false,
        "hasTicketAccess": true,
        "tracking": []
      }
    ],
    "artists": [],
    "pick": null,
    "promotionalLinks": [
      {
        "title": "Tickets",
        "url": "https://www.klook.com/zh-HK/event-detail/102000771-keinemusikhk/"
      }
    ],
    "tracking": [],
    "admin": {
      "id": "11535733",
      "username": "lnea"
    },
    "tickets": [],
    "standardTickets": [],
    "playerLinks": [
      {
        "id": "438455",
        "sourceId": "https://youtu.be/5vX5XUGDEKY?si=mTg3lcUNXaxc6QpE",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      },
      {
        "id": "438456",
        "sourceId": "https://youtu.be/95dB-ObZ7Ho?si=sQomStX5nAzGuNRK",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      },
      {
        "id": "438457",
        "sourceId": "https://youtu.be/eEobh8iCbIE?si=Crfv6afxxiompQ-T",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      }
    ],
    "childEvents": [],
    "genres": [
      {
        "id": "72",
        "name": "Afro House",
        "slug": "afrohouse"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2380389",
    "title": "UNDER THE KT-BRIDGE 2.0",
    "flyerFront": null,
    "flyerBack": null,
    "content": "The sensation is back. BOOMERANG X RaveDAO returns to the Kwun Tong Promenade on April 7th for UNDER THE KT-BRIDGE 2.0.\n\nMore than a party, this is a Melodic Techno awakening. We’ve leveled up the production and the roster. While the lineup is still under wraps, expect: 3 International Headliners, top-tier label artists, and industry legends.\n\nExperience raw underground energy in our signature industrial space. ",
    "minimumAge": 18,
    "cost": "440",
    "contentUrl": "/events/2380389",
    "embargoDate": null,
    "date": "2026-04-07T00:00:00.000",
    "startTime": "2026-04-07T15:00:00.000",
    "endTime": "2026-04-07T21:00:00.000",
    "interestedCount": 2,
    "lineup": "<artist id=\"137846\">Product Of Us</artist> \n<artist id=\"149347\">Son of Son</artist>",
    "isTicketed": false,
    "isFestival": false,
    "dateUpdated": "2026-03-11T02:34:44.397Z",
    "resaleActive": false,
    "datePosted": "2026-02-26T08:39:07.663Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2488231",
        "filename": "https://images.ra.co/85cc73cd26bff31ec2a16941076d552409fca2df.png",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      }
    ],
    "venue": {
      "id": "286247",
      "name": "Aquabeat 03",
      "address": "86 Hoi Bun Road, Kwun Tong, Kowloon, Hong Kong",
      "contentUrl": null,
      "live": false,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 0,
        "longitude": 0
      }
    },
    "promoters": [
      {
        "id": "170049",
        "name": "RaveDAO",
        "contentUrl": "/promoters/170049",
        "live": true,
        "hasTicketAccess": false,
        "tracking": []
      }
    ],
    "artists": [
      {
        "id": "137846",
        "name": "Product Of Us",
        "contentUrl": "/dj/productofus",
        "urlSafeName": "productofus"
      },
      {
        "id": "149347",
        "name": "Son of Son",
        "contentUrl": "/dj/sonofson",
        "urlSafeName": "sonofson"
      }
    ],
    "pick": null,
    "promotionalLinks": [
      {
        "title": "Get tickets on PLVR",
        "url": "https://www.plvr.io/events/underthektbridge2-07apr?aid=eventsharing-hkclubbing?aid=eventsharing-ra"
      }
    ],
    "tracking": [],
    "admin": {
      "id": "11445176",
      "username": "heidi.plvr"
    },
    "tickets": [],
    "standardTickets": [],
    "playerLinks": [],
    "childEvents": [],
    "genres": [
      {
        "id": "5",
        "name": "Techno",
        "slug": "techno"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2379648",
    "title": "Entropy 熵 invites Velvet May (Tears of Waves, Berlin) + Byrne (Disco for The Damned) + Nanogram",
    "flyerFront": null,
    "flyerBack": null,
    "content": "For almost a decade, Entropy 熵 has carved its name into Hong Kong’s underground as a sanctuary for the raw, the relentless, and the ritualistic. This month, they summon three artists whose sonic alchemy thrives at the intersection of industrial grit, hypnotic techno, and the unyielding pulse of EBM—each a force of friction, propulsion, and catharsis.\n\nVelvet May (Tears On Waves / Veyl Records) descends upon 宀 with a live performance that is as visceral as it is visionary. A master of meticulous sound design and off-kilter rhythms, his sets are a collision of percussive techno, fractured breakbeats, and cinematic industrial, where euphoria and alienation coexist. From the infernal narratives of Unknown Bodies to the primal courage of Ritualistic Psalm of Bravery, Velvet May transforms sound into a ritual of confrontation—each beat a mantra, each distortion a release. His music is unfiltered drama: the tension between beauty and decay, order and chaos, channelled through the raw energy of punk, the melancholy of cold wave, and the physical drive of body music. Expect a journey through shifting moods and atmospheres, where rhythm becomes a force of both urgency and transcendence.\n\nByrne (Disco for the Damned / FM Belowground) brings a decade of dark electronic exploration to the decks. As a fixture of Hong Kong’s nightlife, his selections traverse the shadows—from the hypnotic depths of techno to the haunting edges of EBM. A curator of the city’s most compelling underground sounds, Byrne’s sets are a testament to the power of the unseen, drawing from his residencies at Drop, Midnight & Co., and Oma, as well as his own Disco for the Damned label and radio show. Tonight, he weaves a narrative of unsettling groove and atmospheric intensity, a sonic expedition into the heart of the unknown.\n\nNanogram (Entropy 熵 / 宀 Club) completes the trifecta as the architect of this very night. A pioneer of Hong Kong’s industrial/techno scene, his DJ sets are a driving, enigmatic journey through the darker corners of electronic music. As the founder of Entropy 熵 and a resident of 宀, Nanogram has spent years blurring the lines between techno, industrial, and experimental, hosting legends like Phase Fatale and Samuel Kerridge. His sound is uncompromising and immersive, a fusion of mechanical precision and emotional rawness that mirrors the entropy of the dancefloor itself.\n\nTogether, they converge to ignite 宀—where the walls pulse with the energy of transition, friction, and reinvention. This is not just a party; it’s a sonic exorcism, a celebration of the chaos that gives birth to creation.\n",
    "minimumAge": 21,
    "cost": "150$ / 250$",
    "contentUrl": "/events/2379648",
    "embargoDate": null,
    "date": "2026-04-10T00:00:00.000",
    "startTime": "2026-04-10T23:00:00.000",
    "endTime": "2026-04-11T06:00:00.000",
    "interestedCount": 4,
    "lineup": "<artist id=\"87842\">Velvet May</artist> (Tears of Waves, Berlin)\n<artist id=\"80880\">Nanogram</artist> (Entropy 熵, Berlin)\nByrne (Disco For The Damned, Hong Kong)",
    "isTicketed": true,
    "isFestival": false,
    "dateUpdated": "2026-03-10T05:27:17.973Z",
    "resaleActive": false,
    "datePosted": "2026-02-25T15:07:11.787Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2482631",
        "filename": "https://images.ra.co/04039b51ea5a261f1f5d6de89cc06ca9dec4ba9a.jpg",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      },
      {
        "id": "2496600",
        "filename": "https://images.ra.co/00a3f9bcd443940fc9ec0a1c38aae81c8d15c6ed.jpg",
        "alt": null,
        "type": "FLYERBACK",
        "crop": null
      }
    ],
    "venue": {
      "id": "152213",
      "name": "宀 Club",
      "address": "4F, 279 Des Voeux Road Central, Sheung Wan, Hong Kong",
      "contentUrl": "/clubs/152213",
      "live": true,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 22.286855,
        "longitude": 114.151679
      }
    },
    "promoters": [
      {
        "id": "84769",
        "name": "宀 Club",
        "contentUrl": "/promoters/84769",
        "live": true,
        "hasTicketAccess": true,
        "tracking": []
      }
    ],
    "artists": [
      {
        "id": "87842",
        "name": "Velvet May",
        "contentUrl": "/dj/velvetmay",
        "urlSafeName": "velvetmay"
      },
      {
        "id": "80880",
        "name": "Nanogram",
        "contentUrl": "/dj/nanogram",
        "urlSafeName": "nanogram"
      }
    ],
    "pick": null,
    "promotionalLinks": [
      {
        "title": "Entropy 熵 IG",
        "url": "https://www.instagram.com/entropy_disorder/?hl=en"
      },
      {
        "title": "Velvet May IG",
        "url": "https://www.instagram.com/velvetxmay/"
      }
    ],
    "tracking": [],
    "admin": {
      "id": "313005",
      "username": "jf.amadei"
    },
    "tickets": [
      {
        "id": "1265723",
        "title": "Advance ticket",
        "validType": "VALID",
        "onSaleFrom": "2026-02-25T15:00:00.000Z",
        "priceRetail": 22.6,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      }
    ],
    "standardTickets": [
      {
        "id": "1265723",
        "validType": "VALID"
      }
    ],
    "playerLinks": [
      {
        "id": "467664",
        "sourceId": "https://soundcloud.com/entropy_disorder/entropy32-velvet-may?in=velvetxmay/ sets/ mixes&si=c033977c006a4cd699b61019346ﬀda9&utm_source=clipboard&utm_me dium=text&utm_campaign=social_sharing",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      },
      {
        "id": "467665",
        "sourceId": "https://soundcloud.com/khidi/podcast-127-velvet-may",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      },
      {
        "id": "473018",
        "sourceId": "https://soundcloud.com/disco_for_the_damned/mssnldn2025?in=disco_for_the_damned%2Fsets%2Fbyrne",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      }
    ],
    "childEvents": [],
    "genres": [
      {
        "id": "5",
        "name": "Techno",
        "slug": "techno"
      },
      {
        "id": "43",
        "name": "EBM",
        "slug": "ebm"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2325594",
    "title": "Distrikt with Andy Martin (Diaspora Echoes, Mexico), Faxtory (Distrikt) + Zarah (TAG., Macau)",
    "flyerFront": null,
    "flyerBack": null,
    "content": "Distrikt returns to 宀 with an another night rooted in forward-thinking club music, bringing together international and regional selectors who move fluidly across techno, bass, dub, and experimental dancefloor sounds.\n\nHeading the bill is Andy Martin, the Mexican–Jamaican electronic artist known for fusing sci-fi techno with Latin Caribbean influences and a distinctly futuristic edge. His recent album Antiguos Astronautas explores techno through the lens of Native American futurism, earning support from artists including DVS1, Ben UFO, Blawan, Daniel Avery, Richie Hawtin, DJ Bone, Objekt, and many more, with tracks played in institutions such as Berghain, Tresor, Fabric, Bassiani, and De School. His latest release on Mole Audio, a collaboration with Jamaican dub pioneer Lee “Scratch” Perry, further reflects the breadth of his sonic vision.\n\nAlso joining the lineup is Zarah, whose sound moves between deep techno and bass-driven experimentation. Psychedelic, grooving, and richly textural, his sets draw from breaks, garage, electro, and house, balancing depth with unpredictability. A resident at .TAG Chengdu and member of both asylum and Ecstatic Bass Macau, Zarah has become a vital presence across dancefloors in Beijing, Shanghai, Shenzhen, Hong Kong, and Macau.\n\nRepresenting the local force behind the night is Faxtory, Distrikt co-founder and a key figure in Hong Kong’s community-led underground. Through Distrikt and his 宀 Club residency, he has helped shape a platform connecting local talent with international artists, sharing booths with names such as Sedef Adasi, Sansibar, CEM, Voiski, and DJ Nobu.\n\nExpect a night of deep frequencies, percussive pressure, and immersive energy from three artists united by a taste for adventurous, boundary-pushing sound.",
    "minimumAge": 21,
    "cost": "150$ / 250$",
    "contentUrl": "/events/2325594",
    "embargoDate": null,
    "date": "2026-04-11T00:00:00.000",
    "startTime": "2026-04-11T23:00:00.000",
    "endTime": "2026-04-12T06:00:00.000",
    "interestedCount": 18,
    "lineup": "<artist id=\"9004\">Andy Martin</artist> (Diaspora Echoes, Mexico)\n<artist id=\"104837\">Faxtory</artist> (Distrikt, Hong Kong)\n<artist id=\"99850\">Zarah</artist> (TAG., Macau)",
    "isTicketed": true,
    "isFestival": false,
    "dateUpdated": "2026-03-11T11:43:13.190Z",
    "resaleActive": false,
    "datePosted": "2025-12-12T04:24:26.207Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2411339",
        "filename": "https://images.ra.co/4e82bf4670a9922f7191dc6aa5f1b01fec1b43f8.jpg",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      },
      {
        "id": "2498525",
        "filename": "https://images.ra.co/2162a04fad085a2e30bdd6a1dd3e8f9dbb67a496.jpg",
        "alt": null,
        "type": "FLYERBACK",
        "crop": null
      }
    ],
    "venue": {
      "id": "152213",
      "name": "宀 Club",
      "address": "4F, 279 Des Voeux Road Central, Sheung Wan, Hong Kong",
      "contentUrl": "/clubs/152213",
      "live": true,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 22.286855,
        "longitude": 114.151679
      }
    },
    "promoters": [
      {
        "id": "84769",
        "name": "宀 Club",
        "contentUrl": "/promoters/84769",
        "live": true,
        "hasTicketAccess": true,
        "tracking": []
      },
      {
        "id": "137733",
        "name": "Distrikt",
        "contentUrl": "/promoters/137733",
        "live": true,
        "hasTicketAccess": false,
        "tracking": []
      }
    ],
    "artists": [
      {
        "id": "9004",
        "name": "Andy Martin",
        "contentUrl": "/dj/andymartin",
        "urlSafeName": "andymartin"
      },
      {
        "id": "104837",
        "name": "Faxtory",
        "contentUrl": "/dj/faxtory",
        "urlSafeName": "faxtory"
      },
      {
        "id": "99850",
        "name": "Zarah",
        "contentUrl": "/dj/zarah",
        "urlSafeName": "zarah"
      }
    ],
    "pick": null,
    "promotionalLinks": [
      {
        "title": "Andy Martin IG",
        "url": "https://www.instagram.com/4ndym4rtin/"
      },
      {
        "title": "Distrikt IG",
        "url": "https://www.instagram.com/distrikt_hk/"
      }
    ],
    "tracking": [],
    "admin": {
      "id": "313005",
      "username": "jf.amadei"
    },
    "tickets": [
      {
        "id": "1210693",
        "title": "Advance ticket",
        "validType": "VALID",
        "onSaleFrom": "2025-12-12T04:00:00.000Z",
        "priceRetail": 23.75,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      }
    ],
    "standardTickets": [
      {
        "id": "1210693",
        "validType": "VALID"
      }
    ],
    "playerLinks": [
      {
        "id": "441334",
        "sourceId": "https://soundcloud.com/animalia-label/animix-one-hundred-sixty-two-andy-martin?in=andy-martin/sets/podcast&si=61af1028bcf34fb49978491b66465f49&utm_source=clipboard&utm_medium=text&utm_campaign=social_sharing",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      },
      {
        "id": "441335",
        "sourceId": "https://soundcloud.com/monument-podcast/mnmt-488-andy-martin?in=andy-martin/sets/podcast&si=e224fbd9d98042dcb7ea2a03bb05752e&utm_source=clipboard&utm_medium=text&utm_campaign=social_sharing",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      },
      {
        "id": "441336",
        "sourceId": "https://soundcloud.com/hate_music/andy-martin-hate-podcast-446?in=andy-martin/sets/podcast&si=c1333792d77443d897fe696b6d58bd1d&utm_source=clipboard&utm_medium=text&utm_campaign=social_sharing",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      }
    ],
    "childEvents": [],
    "genres": [
      {
        "id": "5",
        "name": "Techno",
        "slug": "techno"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2324883",
    "title": "宀 Invites Ekkel (UTE.Rec, Oslo) [All Night Long]",
    "flyerFront": null,
    "flyerBack": null,
    "content": "Ekkel is the co-founder of Norway’s Ute crew that grew quickly from\nsmoke filled mornings on the Norwegian forest floor to showcases\nat Bassiani and the bush parties of Australia. Founded in 2017, the\nUte label boasts a cult-like following for its approach to psychedelic\ntrance music as well as long form downtempo and chill out sounds\npresented on sub labels Sinensis and Translusid. From the studio he\nemits a modern take on Nordic electronic of the ‘90s that is as mental\nas it is progressive, diving head first into breaks and percussive trips\nas Ekkel. Together with Mikkel Rev and Oprofressionell he is Solar\nAlliance, a live project that unfurls extended trance journeys recorded\nand arranged in a matter of days. Consistently pushing mind melting\nsounds through his involvement in groups like Ipeo and The Dosadi\nExperiments and an ever evolving style in newer projects like Alvar\nand H25, Ekkel sits firmly at the forefront of the underground. In the\nbooth Teo has developed a reputation as a marathon DJ, often with\nMarius Bø as Accelerationsim, regularly playing for hours on end and\nturning dance floors into states of mass euphoria. From an infamous\n18 hour closing at Outsider Festival with Ute he is trusted for skilled,\non the spot selections.",
    "minimumAge": 21,
    "cost": "150$ / 250$",
    "contentUrl": "/events/2324883",
    "embargoDate": null,
    "date": "2026-04-17T00:00:00.000",
    "startTime": "2026-04-17T23:00:00.000",
    "endTime": "2026-04-18T06:00:00.000",
    "interestedCount": 13,
    "lineup": "<artist id=\"118426\">Ekkel</artist> (UTE.Rec, Oslo) [All Night Long]",
    "isTicketed": true,
    "isFestival": false,
    "dateUpdated": null,
    "resaleActive": false,
    "datePosted": "2025-12-11T07:54:29.447Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2410327",
        "filename": "https://images.ra.co/eccab9d069b37ce38cad5f077b031816964912f3.jpg",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      }
    ],
    "venue": {
      "id": "152213",
      "name": "宀 Club",
      "address": "4F, 279 Des Voeux Road Central, Sheung Wan, Hong Kong",
      "contentUrl": "/clubs/152213",
      "live": true,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 22.286855,
        "longitude": 114.151679
      }
    },
    "promoters": [
      {
        "id": "84769",
        "name": "宀 Club",
        "contentUrl": "/promoters/84769",
        "live": true,
        "hasTicketAccess": true,
        "tracking": []
      }
    ],
    "artists": [
      {
        "id": "118426",
        "name": "Ekkel",
        "contentUrl": "/dj/ekkel",
        "urlSafeName": "ekkel"
      }
    ],
    "pick": null,
    "promotionalLinks": [
      {
        "title": "Ekkel IG",
        "url": "https://www.instagram.com/ekkel__/"
      },
      {
        "title": "UTE.Rec IG",
        "url": "https://www.instagram.com/ute.rec/"
      }
    ],
    "tracking": [],
    "admin": {
      "id": "313005",
      "username": "jf.amadei"
    },
    "tickets": [
      {
        "id": "1231664",
        "title": "Advance ticket",
        "validType": "VALID",
        "onSaleFrom": "2026-01-14T03:30:00.000Z",
        "priceRetail": 22.6,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      }
    ],
    "standardTickets": [
      {
        "id": "1231664",
        "validType": "VALID"
      }
    ],
    "playerLinks": [
      {
        "id": "441021",
        "sourceId": "https://soundcloud.com/ute-rec/ute-mix-series-100-ekkel",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      },
      {
        "id": "441022",
        "sourceId": "https://soundcloud.com/bassiani/bassiani-invites-ekkel-podcast-229",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      }
    ],
    "childEvents": [],
    "genres": [
      {
        "id": "2",
        "name": "Trance",
        "slug": "trance"
      },
      {
        "id": "5",
        "name": "Techno",
        "slug": "techno"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2375059",
    "title": "Host with Knopha (Mood Hut, Xiamen) [All Night Long]",
    "flyerFront": null,
    "flyerBack": null,
    "content": "Knopha is the alias of Noah Li, a DJ, music producer, and sound designer based in Shanghai.\n\nDeeply involved in China’s underground club circuit, his distinctive take on ambient and left-field electronic music—combined with his genre-fluid DJ sets—has become an integral part of the community for artists and audiences across Asia. Guest mixes for leading platforms such as Rinse FM, NTS, and FBi Radio—at the invitation of DJs including Ben UFO, Peach, and Ciel—have further solidified his status as a favorite in the Asian underground, alongside performances at major festivals such as Wonderfruit (Thailand), Rainbow Disco Club (Korea), and FFKT (Japan).\n\nSince his well-received debut Nothing Nil on Shanghai’s Eating Music, Knopha’s music has found a home on esteemed international labels including Canada’s Mood Hut, the UK’s Pressure Dome, Peach Discs, and Japan’s Mule Musiq. His growing discography also includes a notable remix for Japanese superstar Fujii Kaze on the single “Kiari.”",
    "minimumAge": 21,
    "cost": "200$ / 300$",
    "contentUrl": "/events/2375059",
    "embargoDate": null,
    "date": "2026-04-18T00:00:00.000",
    "startTime": "2026-04-18T23:00:00.000",
    "endTime": "2026-04-19T06:00:00.000",
    "interestedCount": 5,
    "lineup": "<artist id=\"79163\">Knopha</artist> (Mood Hut, Xiamen) [All Night Long]",
    "isTicketed": true,
    "isFestival": false,
    "dateUpdated": null,
    "resaleActive": false,
    "datePosted": "2026-02-19T11:04:06.183Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2476571",
        "filename": "https://images.ra.co/688438f8a464bbe337dce215ab774fc70f5c36f0.jpg",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      }
    ],
    "venue": {
      "id": "152213",
      "name": "宀 Club",
      "address": "4F, 279 Des Voeux Road Central, Sheung Wan, Hong Kong",
      "contentUrl": "/clubs/152213",
      "live": true,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 22.286855,
        "longitude": 114.151679
      }
    },
    "promoters": [
      {
        "id": "84769",
        "name": "宀 Club",
        "contentUrl": "/promoters/84769",
        "live": true,
        "hasTicketAccess": true,
        "tracking": []
      }
    ],
    "artists": [
      {
        "id": "79163",
        "name": "Knopha",
        "contentUrl": "/dj/knopha",
        "urlSafeName": "knopha"
      }
    ],
    "pick": null,
    "promotionalLinks": [
      {
        "title": "Host IG",
        "url": "https://www.instagram.com/host_hkg/"
      }
    ],
    "tracking": [],
    "admin": {
      "id": "313005",
      "username": "jf.amadei"
    },
    "tickets": [
      {
        "id": "1260612",
        "title": "Advance ticket",
        "validType": "VALID",
        "onSaleFrom": "2026-02-19T11:00:00.000Z",
        "priceRetail": 28.25,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      }
    ],
    "standardTickets": [
      {
        "id": "1260612",
        "validType": "VALID"
      }
    ],
    "playerLinks": [
      {
        "id": "465403",
        "sourceId": "https://soundcloud.com/knophasound/knopha-at-chunyou-festival-25",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      },
      {
        "id": "465404",
        "sourceId": "https://soundcloud.com/ohpeach/sixth-sense-002-knopha?si=0e39643711ea4e768872b8f5c90a83dd&utm_source=clipboard&utm_medium=text&utm_campaign=social_sharing",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      },
      {
        "id": "465405",
        "sourceId": "https://soundcloud.com/mihnclub/mix053-mr-ho-b2b-knopha-live-at",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      }
    ],
    "childEvents": [],
    "genres": [
      {
        "id": "5",
        "name": "Techno",
        "slug": "techno"
      },
      {
        "id": "6",
        "name": "House",
        "slug": "house"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2379529",
    "title": "Liminal Space with Yogg (Polarized Future, Brussels) + seko & Konnection (Liminal Space, HK)",
    "flyerFront": null,
    "flyerBack": null,
    "content": "For this special edition, we dive deep into the meditative and the razor-sharp with Brussels-based electronic artist Yogg.\n\nA master of sculpting immersive soundscapes, Yogg fuses deep minimalism with the weight of dub and the precision of minimal D&B. His productions on labels like Non Series, 30D Records, and his own Polarized Future imprint have built a reputation for tense, hypnotic environments. Having taken his dense, multilayered sets to institutions like Berghain, Tresor, and Contact Tokyo, Yogg brings a pointillistic attention to detail that is haunting, fizzing, and built strictly for the soundsystem.\n\nSupport comes from the Liminal Space crew, representing the forefront of Hong Kong’s atmospheric underground.\n\nLabel founder Konnection (Fung) will guide the floor with his signature blend of techno, broken beat, and halftime. Known for locked-in sonic journeys and long-form mixing, he has shared stages with the likes of D.Dan, DJ Maria, and Priori, while pushing a vision of cinematic, boundary-less electronic music.\n\nRounding out the lineup is seko, a rising force in the local scene whose sound explores ever-evolving soundscapes and fragmented basslines. Together, they promise a night of shifting textures and deep, driving energy.",
    "minimumAge": 21,
    "cost": "150$ / 250$",
    "contentUrl": "/events/2379529",
    "embargoDate": null,
    "date": "2026-04-24T00:00:00.000",
    "startTime": "2026-04-24T23:00:00.000",
    "endTime": "2026-04-25T06:00:00.000",
    "interestedCount": 6,
    "lineup": "<artist id=\"47143\">Yogg</artist> (Polarized Future, Brussels)\n<artist id=\"159916\">seko (HK)</artist> (Liminal Space, Hong Kong)\n<artist id=\"103827\">Konnection</artist> (Liminal Space, Hong Kong)",
    "isTicketed": true,
    "isFestival": false,
    "dateUpdated": "2026-02-25T13:19:34.120Z",
    "resaleActive": false,
    "datePosted": "2026-02-25T13:17:57.797Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2482483",
        "filename": "https://images.ra.co/b94ca86fcd50e96114b78b133204714fa7e11e39.jpg",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      },
      {
        "id": "2482484",
        "filename": "https://images.ra.co/4ff37c7a58d6951ea5763ad864ceb3fa6ffa228c.jpg",
        "alt": null,
        "type": "FLYERBACK",
        "crop": null
      }
    ],
    "venue": {
      "id": "152213",
      "name": "宀 Club",
      "address": "4F, 279 Des Voeux Road Central, Sheung Wan, Hong Kong",
      "contentUrl": "/clubs/152213",
      "live": true,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 22.286855,
        "longitude": 114.151679
      }
    },
    "promoters": [
      {
        "id": "84769",
        "name": "宀 Club",
        "contentUrl": "/promoters/84769",
        "live": true,
        "hasTicketAccess": true,
        "tracking": []
      }
    ],
    "artists": [
      {
        "id": "47143",
        "name": "Yogg",
        "contentUrl": "/dj/yogg",
        "urlSafeName": "yogg"
      },
      {
        "id": "159916",
        "name": "seko (HK)",
        "contentUrl": "/dj/sekohk",
        "urlSafeName": "sekohk"
      },
      {
        "id": "103827",
        "name": "Konnection",
        "contentUrl": "/dj/konnection",
        "urlSafeName": "konnection"
      }
    ],
    "pick": null,
    "promotionalLinks": [
      {
        "title": "Yogg IG",
        "url": "https://www.instagram.com/yoggisadj/"
      },
      {
        "title": "Konnection IG",
        "url": "https://www.instagram.com/fungicf/"
      },
      {
        "title": "Seko IG",
        "url": "https://www.instagram.com/sekopatata/"
      }
    ],
    "tracking": [],
    "admin": {
      "id": "313005",
      "username": "jf.amadei"
    },
    "tickets": [
      {
        "id": "1265544",
        "title": "Advance ticket",
        "validType": "VALID",
        "onSaleFrom": "2026-02-25T13:00:00.000Z",
        "priceRetail": 22.6,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      }
    ],
    "standardTickets": [
      {
        "id": "1265544",
        "validType": "VALID"
      }
    ],
    "playerLinks": [
      {
        "id": "467604",
        "sourceId": "https://soundcloud.com/yoggisadj/yogg-dommune-141223?p=i&c=1&si=6FB9E27B2FF243D5BB0FA1321DC29AFD",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      },
      {
        "id": "467605",
        "sourceId": "https://soundcloud.com/yoggisadj/yogg-at-acquario-milan-30112024?p=i&c=1&si=6BF9799CF11741BA9B42C528AB20CC23",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      },
      {
        "id": "467606",
        "sourceId": "https://soundcloud.com/mihnclub/mix071-konnection-live-for-liminal-space",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      }
    ],
    "childEvents": [],
    "genres": [
      {
        "id": "5",
        "name": "Techno",
        "slug": "techno"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2375903",
    "title": "The Sound Of 宀 with David Fogarty (Transmigration, Berlin), Xiaolin + Sunsiaré (宀, Hong Kong))",
    "flyerFront": null,
    "flyerBack": null,
    "content": "David Fogarty is a pivotal figure in the Berlin underground electronic music landscape, celebrated not just for his technical prowess behind the decks but for his deep archival work within the industry. He is best known as the founder and curator of Transmigration, a reissue label dedicated to unearthing and remastering obscure gems from the realms of trance, techno, and downtempo. Through Transmigration, Fogarty has been instrumental in reviving the sounds of the 90s and early 2000s, bringing forgotten classics to a new generation of listeners.\n\nBeyond his label work, Fogarty is a key operator at Sound Metaphors, one of Berlin’s most respected record stores and distribution centers. As a manager, he plays a crucial role in the day-to-day operations of a hub that supplies vinyl to DJs across the globe. His position there places him at the intersection of music discovery and distribution, giving him a unique vantage point on the evolution of club culture.\n\nAs a DJ, Fogarty is often described as a \"surgical\" selector. His sets are praised for their narrative arc and precision. Rather than sticking to a single genre, he is known for traversing decades of music history, weaving together a tapestry of deep, psychedelic, and hypnotic sounds. Whether playing an extended closing set or a peak-time slot, his style is characterized by a sophisticated understanding of mood and atmosphere, earning him a reputation as a \"DJ's DJ\" and a true gentleman of the scene.\n\n\nXaolin is a DJ, producer, record collector and instrumentalist from Hong Kong.  Driven by a love for colourful emotions and contrasting textures, she is known for crafting patiently dynamic vinyl-led journeys filled with emotion and depth.  Drawing influence from the 80’s-early 00’s, the former concert violinist and now 宀 resident hosts her trippy club night “HEX”, with guests such as Peach, Vlada, Polygonia, Paquita Gordon and DJ Dustin.  With critically acclaimed releases on 宀 & Sound Metaphors, Xiaolin’s ethereal yet grounded sound has left lasting impressions at Lofi, Panorama Bar, Draaimolen and Monument Festival in 2025, and was recently listed on Mixmag’s “Artists to Watch in 2026”\n\n\nBest known as the musical director of Hong Kong institution 宀 but real heads know him for his obsession with rare records. A devoted collector at heart, he throws himself into electronic music with a scholar's discipline. Known as JF to friends, his sharp ear and interest in history informs his various pursuits–curation, DJing, digging and productions, not to mention his technical audio explorations and label management. \n\nHis sets are raw and driving–think deep basslines, freaky 909s and broken drums over shadowy techno, interstellar electro and lithe breaks. Influenced by legendary label Transmigration and '90s trio Sabres of Paradise, selections fuse '90s grit with heady melodies for an all-killer-no-filler effect. He's played at Pawnshop, Mitsuki and Zhao Dai, sharing the decks alongside Barker, Wada Yosuke and Nd_Baumecker. His holistic approach to building energy in a room means he's always thinking about where to go and the best way to take dancers there. \n\nHis love for adventurous club tunes is best displayed at 宀 where his bookings have grealty helped shaping the musical knowledge of Hong Kongers. Committed to challenging perceptions of what a club floor should sound like, Sunsiaré encourages talents to express the full range of their creative practice. He's brought envelope-pushing acts like Jane Fitz and Lena Willikens to the East Asian metropolis while his vinyl-only party \"VG+\" celebrates exploration and knowledge sharing through workshops, conferences and a group vinyl purchase programme to reduce shipping costs. Recent guests have included Nosedrip, S.O.N.S and Carl H, among others. \n\nA longtime Hong Kong resident, Sunsiaré consistently platforms emerging local acts in his quest to strengthen the local scene. His guidance and support are invaluable to the city's next generation of artists, many who come to him for help on setting up their first turntables and home sound systems. A champion of the pan-Asian underground, he's played a critical role in expanding Asia-Pacific's dance music footprint. From cofounding Hong Kong labels Fragrant Harbour, Homesick and Cliché Records to helping kickstart Hanoi’s esteemed Savage club, his close communication with promoters, bookers and venues have helped form a cohesive regional identity. Now an art gallery, label and venue, 宀 is a home for pan-Asian talents to expand their own subcultures and transcend Eurocentrism in dance music. \n\nWhen he's not playing, in the studio or discussing politics, the self-described Mandarin addict is usually deep in a Reddit discussion over rare analog gear or researching the latest reissue of an obscure techno record. Sunsiaré is pure passion through and through.",
    "minimumAge": 21,
    "cost": "150$ / 250$",
    "contentUrl": "/events/2375903",
    "embargoDate": null,
    "date": "2026-04-25T00:00:00.000",
    "startTime": "2026-04-25T23:00:00.000",
    "endTime": "2026-04-26T06:00:00.000",
    "interestedCount": 10,
    "lineup": "<artist id=\"122850\">David Fogarty</artist> (Transmigration, Berlin)\n<artist id=\"95879\">Xiaolin</artist> (宀, Hong Kong)\n<artist id=\"64239\">Sunsiaré</artist> (宀, Hong Kong)",
    "isTicketed": true,
    "isFestival": false,
    "dateUpdated": null,
    "resaleActive": false,
    "datePosted": "2026-02-20T10:25:50.233Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2477742",
        "filename": "https://images.ra.co/b2226dc4d82afaf3ac2c47a0c675be8d5a8e27e5.jpg",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      },
      {
        "id": "2477743",
        "filename": "https://images.ra.co/718a0f1e58f5e19226485f427b8c9468c8a1706d.jpg",
        "alt": null,
        "type": "FLYERBACK",
        "crop": null
      }
    ],
    "venue": {
      "id": "152213",
      "name": "宀 Club",
      "address": "4F, 279 Des Voeux Road Central, Sheung Wan, Hong Kong",
      "contentUrl": "/clubs/152213",
      "live": true,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 22.286855,
        "longitude": 114.151679
      }
    },
    "promoters": [
      {
        "id": "84769",
        "name": "宀 Club",
        "contentUrl": "/promoters/84769",
        "live": true,
        "hasTicketAccess": true,
        "tracking": []
      }
    ],
    "artists": [
      {
        "id": "122850",
        "name": "David Fogarty",
        "contentUrl": "/dj/davidfogarty",
        "urlSafeName": "davidfogarty"
      },
      {
        "id": "95879",
        "name": "Xiaolin",
        "contentUrl": "/dj/xiaolin",
        "urlSafeName": "xiaolin"
      },
      {
        "id": "64239",
        "name": "Sunsiaré",
        "contentUrl": "/dj/sunsiare",
        "urlSafeName": "sunsiare"
      }
    ],
    "pick": null,
    "promotionalLinks": [
      {
        "title": "Transmigration IG",
        "url": "https://www.instagram.com/transmigration.berlin/?hl=en"
      },
      {
        "title": "Xiaolin IG",
        "url": "https://www.instagram.com/oliviaxiaolin/"
      },
      {
        "title": "Sunsiare IG",
        "url": "https://www.instagram.com/sunsiare_/"
      }
    ],
    "tracking": [],
    "admin": {
      "id": "313005",
      "username": "jf.amadei"
    },
    "tickets": [
      {
        "id": "1261552",
        "title": "Advance ticket",
        "validType": "VALID",
        "onSaleFrom": "2026-02-20T10:00:00.000Z",
        "priceRetail": 22.6,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      }
    ],
    "standardTickets": [
      {
        "id": "1261552",
        "validType": "VALID"
      }
    ],
    "playerLinks": [
      {
        "id": "465830",
        "sourceId": "https://soundcloud.com/sound-metaphors/david-fogarty-sound-metaphors-tv-january-8-2026",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      },
      {
        "id": "465831",
        "sourceId": "https://soundcloud.com/mihnclub/mix099-xiaolin-live-at-coda-by-ratherlost-pax-romana",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      },
      {
        "id": "465832",
        "sourceId": "https://soundcloud.com/transmigration_records/transmigration-mix-02",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      }
    ],
    "childEvents": [],
    "genres": [
      {
        "id": "1",
        "name": "Progressive House",
        "slug": "progressivehouse"
      },
      {
        "id": "2",
        "name": "Trance",
        "slug": "trance"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2379627",
    "title": "Snug in Hong Kong with Ouissam (Snug, Hanoi) B2B Emel (UNKNWN, Manila) [All Night Long]",
    "flyerFront": null,
    "flyerBack": null,
    "content": "For one special night, the vibrant energy of Hanoi’s most essential LGBTQ+ party, Snug, descends upon 宀 Club. Known as the beating heart of Savage—Hanoi’s premier underground institution—Snug has built a legendary reputation across Asia for its hedonistic atmosphere, radical inclusivity, and impeccable music. It is a space where the \"Red Cube\" room comes alive with freedom and flair.\n\nBringing this spirit to Hong Kong are two of the region's most influential figures for an All Night Long session.\n\nFirst is Ouissam, a name that needs little introduction in this city. As the founder of Hong Kong’s Cliché Records, Homesick, and Fragrant Harbor, he helped cultivate the city's disco-house-techno synthesis before establishing Savage in Vietnam. Now a \"regional entity\" and the curator of Equation Festival, Ouissam’s approach is intuitive and elegant. Whether it’s long-lost gems or cutting-edge grooves, his sets are built on a simple premise: if it makes the room shudder with joy, it belongs in the mix.\n\nJoining him is the Filipino-Australian \"vibe manager,\" Emel Rowe. A co-founder of UNKNWN and Manila Community Radio, Emel has become a key figure in Asia’s cultural renaissance. His pedigree is undeniable, with sets clocking in at Berghain/Panorama Bar, Wonderfruit, and Zhao Dai. Emel brings rhythm without ego and precision without pretense, digging deep to tell a story that connects the floor.\n\nTogether, they bring the Snug ethos to 宀: a safe space for expression, a celebration of the queer community, and a musical journey that refuses to be categorized.",
    "minimumAge": 21,
    "cost": "150$ / 250$ / 300$",
    "contentUrl": "/events/2379627",
    "embargoDate": null,
    "date": "2026-04-30T00:00:00.000",
    "startTime": "2026-04-30T23:00:00.000",
    "endTime": "2026-05-01T06:00:00.000",
    "interestedCount": 5,
    "lineup": "<artist id=\"65242\">Ouissam</artist> (Savage, Hanoi)\n<artist id=\"45647\">Emel</artist> (UNKWN, Manila)",
    "isTicketed": true,
    "isFestival": false,
    "dateUpdated": "2026-02-25T17:02:51.587Z",
    "resaleActive": false,
    "datePosted": "2026-02-25T14:54:14.643Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2482605",
        "filename": "https://images.ra.co/505133da781b8733fd70a6d4555849a7a398fd20.jpg",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      },
      {
        "id": "2482606",
        "filename": "https://images.ra.co/e13f954f8e74aa032615268ac0aba52db1c321c5.jpg",
        "alt": null,
        "type": "FLYERBACK",
        "crop": null
      }
    ],
    "venue": {
      "id": "152213",
      "name": "宀 Club",
      "address": "4F, 279 Des Voeux Road Central, Sheung Wan, Hong Kong",
      "contentUrl": "/clubs/152213",
      "live": true,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 22.286855,
        "longitude": 114.151679
      }
    },
    "promoters": [
      {
        "id": "84769",
        "name": "宀 Club",
        "contentUrl": "/promoters/84769",
        "live": true,
        "hasTicketAccess": true,
        "tracking": []
      }
    ],
    "artists": [
      {
        "id": "65242",
        "name": "Ouissam",
        "contentUrl": "/dj/ouissam",
        "urlSafeName": "ouissam"
      },
      {
        "id": "45647",
        "name": "Emel",
        "contentUrl": "/dj/emel-ph",
        "urlSafeName": "emel-ph"
      }
    ],
    "pick": null,
    "promotionalLinks": [
      {
        "title": "Ouissam IG",
        "url": "https://www.instagram.com/ouissam.jpeg/"
      },
      {
        "title": "EMEL IG",
        "url": "https://www.instagram.com/emel.onlyjams/"
      },
      {
        "title": "SNUG IG",
        "url": "https://www.instagram.com/snug.vn/"
      }
    ],
    "tracking": [],
    "admin": {
      "id": "313005",
      "username": "jf.amadei"
    },
    "tickets": [
      {
        "id": "1265687",
        "title": "Early bird",
        "validType": "VALID",
        "onSaleFrom": "2026-02-25T14:30:00.000Z",
        "priceRetail": 22.6,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      },
      {
        "id": "1265691",
        "title": "1st release",
        "validType": "VALID",
        "onSaleFrom": "2026-02-25T14:30:00.000Z",
        "priceRetail": 28.25,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      }
    ],
    "standardTickets": [
      {
        "id": "1265687",
        "validType": "VALID"
      },
      {
        "id": "1265691",
        "validType": "VALID"
      }
    ],
    "playerLinks": [
      {
        "id": "467659",
        "sourceId": "https://soundcloud.com/rainbowdiscoclub/rdc-091-ouissam",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      },
      {
        "id": "467660",
        "sourceId": "https://soundcloud.com/bassiani/bassiani-invites-ouissam-podcast-216",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      },
      {
        "id": "467661",
        "sourceId": "https://soundcloud.com/karmakliqueofficial/ouissam-at-karma-kastle-30",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      }
    ],
    "childEvents": [],
    "genres": [
      {
        "id": "6",
        "name": "House",
        "slug": "house"
      },
      {
        "id": "21",
        "name": "Disco",
        "slug": "disco"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2324871",
    "title": "VG+ with Jane Fitz (宀, Hong Kong) [All Night Long Vinyl Set]",
    "flyerFront": null,
    "flyerBack": null,
    "content": "Your favorite DJs' favorite DJ",
    "minimumAge": 21,
    "cost": "150$ / 200$ / 300$ / 350$",
    "contentUrl": "/events/2324871",
    "embargoDate": null,
    "date": "2026-05-02T00:00:00.000",
    "startTime": "2026-05-02T23:00:00.000",
    "endTime": "2026-05-03T06:00:00.000",
    "interestedCount": 98,
    "lineup": "<artist id=\"3481\">Jane Fitz</artist> (宀, London)",
    "isTicketed": true,
    "isFestival": false,
    "dateUpdated": "2025-12-17T02:18:13.890Z",
    "resaleActive": false,
    "datePosted": "2025-12-11T06:21:36.863Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2410304",
        "filename": "https://images.ra.co/b70e1c06d9623b060672e4ab09f43144e23f6c2c.jpg",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      }
    ],
    "venue": {
      "id": "152213",
      "name": "宀 Club",
      "address": "4F, 279 Des Voeux Road Central, Sheung Wan, Hong Kong",
      "contentUrl": "/clubs/152213",
      "live": true,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 22.286855,
        "longitude": 114.151679
      }
    },
    "promoters": [
      {
        "id": "84769",
        "name": "宀 Club",
        "contentUrl": "/promoters/84769",
        "live": true,
        "hasTicketAccess": true,
        "tracking": []
      }
    ],
    "artists": [
      {
        "id": "3481",
        "name": "Jane Fitz",
        "contentUrl": "/dj/janefitz",
        "urlSafeName": "janefitz"
      }
    ],
    "pick": null,
    "promotionalLinks": [
      {
        "title": "Jane Fitz IG",
        "url": "https://www.instagram.com/janefitzislost/?hl=en"
      },
      {
        "title": "VG+ IG",
        "url": "https://www.instagram.com/vgplus__/?hl=en"
      }
    ],
    "tracking": [],
    "admin": {
      "id": "313005",
      "username": "jf.amadei"
    },
    "tickets": [
      {
        "id": "1213852",
        "title": "Early bird",
        "validType": "SOLDOUT",
        "onSaleFrom": "2025-12-17T02:00:00.000Z",
        "priceRetail": 23.75,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      },
      {
        "id": "1213853",
        "title": "1st release",
        "validType": "SOLDOUT",
        "onSaleFrom": "2025-12-17T02:00:00.000Z",
        "priceRetail": 29.4,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      },
      {
        "id": "1213856",
        "title": "Advance ticket",
        "validType": "VALID",
        "onSaleFrom": "2025-12-17T02:00:00.000Z",
        "priceRetail": 45.2,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      }
    ],
    "standardTickets": [
      {
        "id": "1213852",
        "validType": "SOLDOUT"
      },
      {
        "id": "1213853",
        "validType": "SOLDOUT"
      },
      {
        "id": "1213856",
        "validType": "VALID"
      }
    ],
    "playerLinks": [
      {
        "id": "441001",
        "sourceId": "https://soundcloud.com/mihnclub/mix066-jane-fitz-live-at-april-2023",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      },
      {
        "id": "441002",
        "sourceId": "https://soundcloud.com/mixmagasia/mixmagasiaradio165-ruralfestival-janefitz",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      },
      {
        "id": "441003",
        "sourceId": "https://soundcloud.com/transmissions_music/janefitzb2bcarlh",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      }
    ],
    "childEvents": [],
    "genres": [
      {
        "id": "2",
        "name": "Trance",
        "slug": "trance"
      },
      {
        "id": "5",
        "name": "Techno",
        "slug": "techno"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2337314",
    "title": "宀 Invites Garçon (Amenthia, Basel) [All Night Long]",
    "flyerFront": null,
    "flyerBack": null,
    "content": "Garçon’s DJ sets are all about the slow burn. He teases music gradually and deliberately, layering hypnotic grooves atop one another and subtly modulating the mood of the night, with this delayed gratification leading to a far greater payoff. Although he pulls from across the electronic music spectrum, Garçon’s interests are primarily in techno, with a particular fondness for rhythmically adventurous sounds from the outer edges of the genre. \n\nGarçon was born and raised in Basel, Switzerland, where he’s still based today. He’s been an important figure in the city’s techno scene for some time. He started DJing in Basel when he was just 14 years old, then quickly started throwing parties, first at the since-shuttered clubbing institution Hinterhof, and later at Elysia. Amenthia Recordings, the label that he co- runs with Agonis, has been a vital showcase for talent from within his creative community and beyond. \n\nUnlike many of his producer peers, Garçon is strictly a DJ. But he approaches his work with a true artist’s discipline. From the moment he started going to nightclubs, he would watch DJs up close and observe their technique, and would learn his records inside out to develop his unique precision mixing style. Still, for all this sense of control, Garçon is also very adaptable, as happy playing to 200 people in Basel’s Lady Bar as he is to big crowds in Berghain or at festivals like The Labyrinth in Japan, Organik in Taiwan, Waking Life in Portugal, or Parallel in Barcelona.",
    "minimumAge": 21,
    "cost": "150$ / 250$",
    "contentUrl": "/events/2337314",
    "embargoDate": null,
    "date": "2026-05-15T00:00:00.000",
    "startTime": "2026-05-15T23:00:00.000",
    "endTime": "2026-05-16T06:00:00.000",
    "interestedCount": 9,
    "lineup": "<artist id=\"7770\">Garçon</artist> (Amenthia, Basel) [All Night Long]",
    "isTicketed": true,
    "isFestival": false,
    "dateUpdated": "2026-02-13T14:40:25.200Z",
    "resaleActive": false,
    "datePosted": "2026-01-03T10:34:25.077Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2426726",
        "filename": "https://images.ra.co/ebb748b197540033cce082bcc38cf8650802a028.jpg",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      }
    ],
    "venue": {
      "id": "152213",
      "name": "宀 Club",
      "address": "4F, 279 Des Voeux Road Central, Sheung Wan, Hong Kong",
      "contentUrl": "/clubs/152213",
      "live": true,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 22.286855,
        "longitude": 114.151679
      }
    },
    "promoters": [
      {
        "id": "84769",
        "name": "宀 Club",
        "contentUrl": "/promoters/84769",
        "live": true,
        "hasTicketAccess": true,
        "tracking": []
      }
    ],
    "artists": [
      {
        "id": "7770",
        "name": "Garçon",
        "contentUrl": "/dj/garcon",
        "urlSafeName": "garcon"
      }
    ],
    "pick": null,
    "promotionalLinks": [
      {
        "title": "Garçon IG",
        "url": "https://www.instagram.com/garcon_amenthia/?hl=en"
      },
      {
        "title": "Amenthia Bandcamp",
        "url": "https://amenthia.bandcamp.com"
      }
    ],
    "tracking": [],
    "admin": {
      "id": "313005",
      "username": "jf.amadei"
    },
    "tickets": [
      {
        "id": "1223023",
        "title": "Advance ticket",
        "validType": "VALID",
        "onSaleFrom": "2026-01-03T10:30:00.000Z",
        "priceRetail": 22.6,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      }
    ],
    "standardTickets": [
      {
        "id": "1223023",
        "validType": "VALID"
      }
    ],
    "playerLinks": [
      {
        "id": "446700",
        "sourceId": "https://soundcloud.com/vinculumpt/vinculum-festival-2025-garcon",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      },
      {
        "id": "446701",
        "sourceId": "https://soundcloud.com/spell_spell/spell-garcon-agonis",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      },
      {
        "id": "446702",
        "sourceId": "https://soundcloud.com/animalia-label/anilive-sixty-seven-garcon-waking-life",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      }
    ],
    "childEvents": [],
    "genres": [
      {
        "id": "5",
        "name": "Techno",
        "slug": "techno"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2385758",
    "title": "Host with Yadin Moha (Zagareet, Hong Kong) [All Night Long]",
    "flyerFront": null,
    "flyerBack": null,
    "content": "Yadin Moha, a boundary-pushing selector whose sets oscillate between dancefloor energy and ceiling-gazing introspection. From experimental electronics and noise on radio to _wave, post-punk, dub, electro, and techno in clubs, Yadin’s sound is a bridge between contemporary electronic music, deconstructed traditions, and subversive symbolism. A pioneer of outsider dance music in Southeast Asia, he’s spent over 15 years converting listeners one track at a time.",
    "minimumAge": 21,
    "cost": "200$ / 300$",
    "contentUrl": "/events/2385758",
    "embargoDate": null,
    "date": "2026-05-16T00:00:00.000",
    "startTime": "2026-05-16T23:00:00.000",
    "endTime": "2026-05-17T06:00:00.000",
    "interestedCount": 2,
    "lineup": "<artist id=\"70850\">Yadin Moha</artist> (Zagareet, Hong Kong)",
    "isTicketed": true,
    "isFestival": false,
    "dateUpdated": null,
    "resaleActive": false,
    "datePosted": "2026-03-04T14:25:50.810Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2490687",
        "filename": "https://images.ra.co/60ccd2065e5eb441fe1e9a20ecf11cceb39c8fbb.jpg",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      }
    ],
    "venue": {
      "id": "152213",
      "name": "宀 Club",
      "address": "4F, 279 Des Voeux Road Central, Sheung Wan, Hong Kong",
      "contentUrl": "/clubs/152213",
      "live": true,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 22.286855,
        "longitude": 114.151679
      }
    },
    "promoters": [
      {
        "id": "84769",
        "name": "宀 Club",
        "contentUrl": "/promoters/84769",
        "live": true,
        "hasTicketAccess": true,
        "tracking": []
      }
    ],
    "artists": [
      {
        "id": "70850",
        "name": "Yadin Moha",
        "contentUrl": "/dj/yadinmoha",
        "urlSafeName": "yadinmoha"
      }
    ],
    "pick": null,
    "promotionalLinks": [
      {
        "title": "Host IG",
        "url": "https://www.instagram.com/host_hkg/"
      },
      {
        "title": "Yadin Moha IG",
        "url": "https://www.instagram.com/yadin.moha/"
      }
    ],
    "tracking": [],
    "admin": {
      "id": "313005",
      "username": "jf.amadei"
    },
    "tickets": [
      {
        "id": "1271761",
        "title": "Advance ticket",
        "validType": "VALID",
        "onSaleFrom": "2026-03-04T14:00:00.000Z",
        "priceRetail": 28.25,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      }
    ],
    "standardTickets": [
      {
        "id": "1271761",
        "validType": "VALID"
      }
    ],
    "playerLinks": [
      {
        "id": "470755",
        "sourceId": "https://soundcloud.com/428soundwave/yadin-moha-at-428-wonderfruit-2024",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      }
    ],
    "childEvents": [],
    "genres": [
      {
        "id": "6",
        "name": "House",
        "slug": "house"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2330574",
    "title": "House of Ho with Binh (Time Passages, Berlin) + Mr. Ho (Klasse Wrecks, Hong Kong)",
    "flyerFront": null,
    "flyerBack": null,
    "content": "BINH\n\nBorn in Düsseldorf and now based in Berlin, Binh has been digging deep into music for over two decades. Starting his career in Düsseldorf as a resident at Tribehouse , he later moved to Berlin—before steadily expanding his reach across the globe. His obsession with under-the-radar records—spanning house, techno, and electro—defines a DJ style that’s both unique and widely respected. A key figure in the scene, Binh has stayed true to the roots of DJ culture while steadily gaining recognition around the world. Once known primarily within a close-knit community, he is now widely regarded and sought-after worldwide—playing regularly in some of the best and most renowned clubs, yet remaining grounded in his purist ethos: putting music first. Binh runs the Time Passages label, founded in 2014. It showcases stripped-back, trippy house and techno with a focus on sonic clarity and character. In 2024, he introduced Time Passages X, a sublabel dedicated to one limited-edition release per year—pushing exclusivity and curation even further. Both labels mirror Binh’s approach: understated, immersive, and deeply personal. With releases on his own imprint Time Passages, Cabaret Records, Perlon, My Own Jupiter, and as part of the Treatment project, Binh remains a quietly formidable presence—dedicated to the craft, the culture, and the music, right to the last beat.\n\n\nMR. HO\n\nMR. HO is a music collector, DJ, Producer and Label Owner. Born and based in Hong Kong, Mr. Ho has been involved in electronic dance music for over decade, and is regarded as a key figure in the contemporary scene in Asia. Alongside Luca Lozano, Mr. Ho runs and curates Klasse Wrecks, the label that has been consistently responsible for some of the most highly anticipated and desired records in electronic music in recent years. As a producer, Mr Ho has made music for Klasse Wrecks, Cabaret Recordings, Clone Records, Permanent Vacation, Gudu and a few select others. \n\nEvery creation my Mr. Ho has a strong personal identity and an irresistible charm for the dancefloor, which explains why so much of Mr Ho’s music are considered staples in the record crates of many. Take for example, his crossover hit “Bail-E” - a record made during the Covid pandemic that is not only a hit across dancefloors over the globe, and became the soundtrack to major festivals from Sunwaves to Dekmantel. Coming up to four years since its original release, this record is still currently still in playlists and remains a highly desirable record amongst djs. \n\nMuch like his production, Mr. Ho’s dj sets cross diverse genres and time, spanning from decades of music from diverse House, Techno and Electro. Having started out as a battle dj on the international circuit already in his teens, Mr. Ho has developed an easy and natural ability on the turntables. Be it a festival slot or a an extend nightclub set, Mr. Ho dj sets always bring an almost bottomless sense of ecstatic energy and total immersion.",
    "minimumAge": 21,
    "cost": "200$ / 300$",
    "contentUrl": "/events/2330574",
    "embargoDate": null,
    "date": "2026-05-23T00:00:00.000",
    "startTime": "2026-05-23T23:00:00.000",
    "endTime": "2026-05-24T06:00:00.000",
    "interestedCount": 21,
    "lineup": "<artist id=\"14812\">Binh</artist> (Time Passages, Berlin)\n<artist id=\"20717\">Mr. Ho</artist> (Klasse Wrecks, Hong Kong",
    "isTicketed": true,
    "isFestival": false,
    "dateUpdated": null,
    "resaleActive": false,
    "datePosted": "2025-12-19T09:27:48.873Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2417894",
        "filename": "https://images.ra.co/e9b8577f542ee33aebb6cc2d98f494a80be3caf9.jpg",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      },
      {
        "id": "2417895",
        "filename": "https://images.ra.co/9d16505b8d56e0793c84e02def87d0d4704da578.jpg",
        "alt": null,
        "type": "FLYERBACK",
        "crop": null
      }
    ],
    "venue": {
      "id": "152213",
      "name": "宀 Club",
      "address": "4F, 279 Des Voeux Road Central, Sheung Wan, Hong Kong",
      "contentUrl": "/clubs/152213",
      "live": true,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 22.286855,
        "longitude": 114.151679
      }
    },
    "promoters": [
      {
        "id": "84769",
        "name": "宀 Club",
        "contentUrl": "/promoters/84769",
        "live": true,
        "hasTicketAccess": true,
        "tracking": []
      }
    ],
    "artists": [
      {
        "id": "14812",
        "name": "Binh",
        "contentUrl": "/dj/binh",
        "urlSafeName": "binh"
      },
      {
        "id": "20717",
        "name": "Mr. Ho",
        "contentUrl": "/dj/mr.ho",
        "urlSafeName": "mr.ho"
      }
    ],
    "pick": null,
    "promotionalLinks": [
      {
        "title": "BIHN IG",
        "url": "https://www.instagram.com/timepassagesrecordings/"
      },
      {
        "title": "Mr. Ho IG",
        "url": "https://www.instagram.com/mrhodj/"
      }
    ],
    "tracking": [],
    "admin": {
      "id": "313005",
      "username": "jf.amadei"
    },
    "tickets": [
      {
        "id": "1215808",
        "title": "Advance ticket",
        "validType": "VALID",
        "onSaleFrom": "2025-12-19T09:00:00.000Z",
        "priceRetail": 28.25,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      }
    ],
    "standardTickets": [
      {
        "id": "1215808",
        "validType": "VALID"
      }
    ],
    "playerLinks": [
      {
        "id": "443551",
        "sourceId": "https://www.youtube.com/watch?v=cBaNbUQOaIU",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      },
      {
        "id": "443552",
        "sourceId": "https://soundcloud.com/resident-advisor/ra-989-binh",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      },
      {
        "id": "443553",
        "sourceId": "https://soundcloud.com/mihnclub/mix053-mr-ho-b2b-knopha-live-at",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      }
    ],
    "childEvents": [],
    "genres": [
      {
        "id": "5",
        "name": "Techno",
        "slug": "techno"
      },
      {
        "id": "6",
        "name": "House",
        "slug": "house"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2385774",
    "title": "宀 8th Anniversary Celebration",
    "flyerFront": null,
    "flyerBack": null,
    "content": "MAY 29TH AND 30th 宀 8TH XXL ANNIVERSARY𓍯𓂃\n\nClub turns seven, and it's still just as much of a passion project it was in 2018 — as remembered by vending machines, new paths taken within Hong Kong's underground, and a clear eyed sense of camaraderie — which hopefully still prevails\n\nWith that camaraderie in mind, and a hearty pan-Asian sentiment - shoulder to shoulder with our own residents - we're inviting friends that feel like family, from and cult favourite clubs like HCMC's The Observatory, Seoul's Volnost and Tokyo's Mitsuki \n\n7th XXL Anniversary on May 29th & 30th is a two day festival affair, pulling out the extraodinary from the well known heroes of the club, in an extended series of fantasy back to back sets, BRACE BRACE\n\nNO PRESALE\nHK$150 BEFORE 00:00 - HK$250 AFTER 00:00\n•SATURDAY FREE • WITH FRIDAY ATTENDANCE",
    "minimumAge": 21,
    "cost": "150$ / 250$",
    "contentUrl": "/events/2385774",
    "embargoDate": null,
    "date": "2026-05-29T00:00:00.000",
    "startTime": "2026-05-29T23:00:00.000",
    "endTime": "2026-05-31T06:00:00.000",
    "interestedCount": 6,
    "lineup": "<artist id=\"154764\">xylon</artist> (Cheaper Than Therapy, Hong Kong) b2b <artist id=\"125120\">HRD.ept</artist> (Slimefest, Hong Kong)\n<artist id=\"120617\">Scott B</artist> (Distrikt, Hong Kong) b2b <artist id=\"111899\">Shinsuke Goto</artist> (Mitsuki, Tokyo)\n<artist id=\"80880\">Nanogram</artist> (Entropy 熵, Hong Kong) b2b <artist id=\"61688\">ComaRobot</artist> (Volnost, Seoul)\n<artist id=\"64239\">Sunsiaré</artist> (宀, Hong Kong) b2b <artist id=\"72506\">S.O.N.S</artist> (Junction Forest, Seoul)\n<artist id=\"41730\">Hibiya Line</artist> (The Observatory, Saigon) b2b <artist id=\"82217\">Shhhhh</artist> (El Folklore Paradox, Tokyo)\n<artist id=\"4897\">Gonno</artist> (Ostgut Ton, Tokyo) b2b <artist id=\"95879\">Xiaolin</artist> (宀, Hong Kong)",
    "isTicketed": false,
    "isFestival": false,
    "dateUpdated": "2026-03-10T05:00:53.713Z",
    "resaleActive": false,
    "datePosted": "2026-03-04T14:40:18.147Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2490710",
        "filename": "https://images.ra.co/bc80a15037c2c34f5372b569a8050065bb8aa9c4.jpg",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      }
    ],
    "venue": {
      "id": "152213",
      "name": "宀 Club",
      "address": "4F, 279 Des Voeux Road Central, Sheung Wan, Hong Kong",
      "contentUrl": "/clubs/152213",
      "live": true,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 22.286855,
        "longitude": 114.151679
      }
    },
    "promoters": [],
    "artists": [
      {
        "id": "154764",
        "name": "xylon",
        "contentUrl": "/dj/xylon",
        "urlSafeName": "xylon"
      },
      {
        "id": "125120",
        "name": "HRD.ept",
        "contentUrl": "/dj/hrd.ept",
        "urlSafeName": "hrd.ept"
      },
      {
        "id": "120617",
        "name": "Scott B",
        "contentUrl": "/dj/scottb",
        "urlSafeName": "scottb"
      },
      {
        "id": "111899",
        "name": "Shinsuke Goto",
        "contentUrl": "/dj/shinsukegoto",
        "urlSafeName": "shinsukegoto"
      },
      {
        "id": "80880",
        "name": "Nanogram",
        "contentUrl": "/dj/nanogram",
        "urlSafeName": "nanogram"
      },
      {
        "id": "61688",
        "name": "ComaRobot",
        "contentUrl": "/dj/comarobot",
        "urlSafeName": "comarobot"
      },
      {
        "id": "64239",
        "name": "Sunsiaré",
        "contentUrl": "/dj/sunsiare",
        "urlSafeName": "sunsiare"
      },
      {
        "id": "72506",
        "name": "S.O.N.S",
        "contentUrl": "/dj/sons",
        "urlSafeName": "sons"
      },
      {
        "id": "41730",
        "name": "Hibiya Line",
        "contentUrl": "/dj/hibiyaline",
        "urlSafeName": "hibiyaline"
      },
      {
        "id": "82217",
        "name": "Shhhhh",
        "contentUrl": "/dj/shhhhh",
        "urlSafeName": "shhhhh"
      },
      {
        "id": "4897",
        "name": "Gonno",
        "contentUrl": "/dj/gonno",
        "urlSafeName": "gonno"
      },
      {
        "id": "95879",
        "name": "Xiaolin",
        "contentUrl": "/dj/xiaolin",
        "urlSafeName": "xiaolin"
      }
    ],
    "pick": null,
    "promotionalLinks": [
      {
        "title": "宀 Instagram",
        "url": "https://www.instagram.com/mihnclub/?hl=en"
      }
    ],
    "tracking": [],
    "admin": {
      "id": "313005",
      "username": "jf.amadei"
    },
    "tickets": [],
    "standardTickets": [],
    "playerLinks": [
      {
        "id": "470761",
        "sourceId": "https://soundcloud.com/riohostel/rio-021-sons-recorded-live-at-bonanza-2025",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      },
      {
        "id": "470762",
        "sourceId": "https://soundcloud.com/trommelmusic/trommel-238-gonno",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      },
      {
        "id": "470763",
        "sourceId": "https://soundcloud.com/428soundwave/shinsukegoto?in=shinsuke-goto-788359775/sets/dj-mixes-pod-cast&si=4d5c5d90b41849ef97ccaa2a540acde5&utm_source=clipboard&utm_medium=text&utm_campaign=social_sharing",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      }
    ],
    "childEvents": [],
    "genres": [
      {
        "id": "5",
        "name": "Techno",
        "slug": "techno"
      },
      {
        "id": "6",
        "name": "House",
        "slug": "house"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2385747",
    "title": "宀 Invites YELLOWUHURU (FLATTOP, Tokyo) + Yadin Moha (Zagareet, Hong Kong)",
    "flyerFront": null,
    "flyerBack": null,
    "content": "Step into the sonic universe where YELLOWUHURU, South African-born, Tokyo-based founder of FLATTOP, weaves house and jazz into a tapestry of musical experimentation. With a daily practice of blending \"conflicting elements and a sense of commonality,\" his sets are a journey through rhythm, harmony, and the unexpected.\n\nJoining him is Yadin Moha, a boundary-pushing selector whose sets oscillate between dancefloor energy and ceiling-gazing introspection. From experimental electronics and noise on radio to _wave, post-punk, dub, electro, and techno in clubs, Yadin’s sound is a bridge between contemporary electronic music, deconstructed traditions, and subversive symbolism. A pioneer of outsider dance music in Southeast Asia, he’s spent over 15 years converting listeners one track at a time.\n\nExpect a night where genres collide, traditions are reimagined, and the dancefloor becomes a playground for the curious and the bold. See you there.",
    "minimumAge": 21,
    "cost": "150$ / 250$",
    "contentUrl": "/events/2385747",
    "embargoDate": null,
    "date": "2026-06-12T00:00:00.000",
    "startTime": "2026-06-12T23:00:00.000",
    "endTime": "2026-06-13T06:00:00.000",
    "interestedCount": 2,
    "lineup": "<artist id=\"90614\">YELLOWUHURU</artist> (FLATTOP, Tokyo)\n<artist id=\"70850\">Yadin Moha</artist> (Zagareet, Hong Kong)",
    "isTicketed": true,
    "isFestival": false,
    "dateUpdated": null,
    "resaleActive": false,
    "datePosted": "2026-03-04T14:19:15.307Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2490669",
        "filename": "https://images.ra.co/ef77f62b1e2fc5990ea4ad6cbb2eb849c75e6cb3.jpg",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      },
      {
        "id": "2490670",
        "filename": "https://images.ra.co/0c4844208895262575b5f439d20137474ea58326.jpg",
        "alt": null,
        "type": "FLYERBACK",
        "crop": null
      }
    ],
    "venue": {
      "id": "152213",
      "name": "宀 Club",
      "address": "4F, 279 Des Voeux Road Central, Sheung Wan, Hong Kong",
      "contentUrl": "/clubs/152213",
      "live": true,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 22.286855,
        "longitude": 114.151679
      }
    },
    "promoters": [
      {
        "id": "84769",
        "name": "宀 Club",
        "contentUrl": "/promoters/84769",
        "live": true,
        "hasTicketAccess": true,
        "tracking": []
      }
    ],
    "artists": [
      {
        "id": "90614",
        "name": "YELLOWUHURU",
        "contentUrl": "/dj/yellowuhuru",
        "urlSafeName": "yellowuhuru"
      },
      {
        "id": "70850",
        "name": "Yadin Moha",
        "contentUrl": "/dj/yadinmoha",
        "urlSafeName": "yadinmoha"
      }
    ],
    "pick": null,
    "promotionalLinks": [
      {
        "title": "YELLOWUHURU IG",
        "url": "https://www.instagram.com/yellowuhuru/"
      },
      {
        "title": "Yadin Moha IG",
        "url": "https://www.instagram.com/yadin.moha/"
      },
      {
        "title": "Zagareet IG",
        "url": "https://www.instagram.com/zagareet__/"
      }
    ],
    "tracking": [],
    "admin": {
      "id": "313005",
      "username": "jf.amadei"
    },
    "tickets": [
      {
        "id": "1271743",
        "title": "Advance ticket",
        "validType": "VALID",
        "onSaleFrom": "2026-03-04T14:00:00.000Z",
        "priceRetail": 22.6,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      }
    ],
    "standardTickets": [
      {
        "id": "1271743",
        "validType": "VALID"
      }
    ],
    "playerLinks": [
      {
        "id": "470748",
        "sourceId": "https://soundcloud.com/pacific-mode/mix003-yellowuhuru",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      },
      {
        "id": "470749",
        "sourceId": "https://soundcloud.com/428soundwave/yadin-moha-at-428-wonderfruit-2024",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      },
      {
        "id": "470750",
        "sourceId": "https://soundcloud.com/flattopflattop/flattop-10th-body-mix-art-work-by-caroline",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      }
    ],
    "childEvents": [],
    "genres": [
      {
        "id": "6",
        "name": "House",
        "slug": "house"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2384155",
    "title": "A State of Trance",
    "flyerFront": null,
    "flyerBack": null,
    "content": "The wait is finally over - A State of Trance in Hong Kong\n\nThe legendary Armin Van Buuren is bringing a very special edition of A State of Trance for the FIRST TIME in East Asia to celebrate their 25th anniversary.\n\nA State of Trance is one of the world’s biggest and most popular dance music brands. Built from the ground up since the first episode in 2001, Armin van Buuren’s radio show has given rise to a globally acclaimed label and a premier event series, connecting fans from all over the globe.\n\nNow, A State of Trance has become the biggest indoor and outdoor event series in the world; the annual A State of Trance event in Utrecht, for instance, consistently treats tens of thousands of visitors to mind-blowing performances from leading DJs in trance and progressive and beyond. \n\nDrawing hundreds of thousands of dedicated fans every year. The event series has brought unforgettable moments to countless world cities, from Rotterdam to Sydney, Mumbai, Miami, Mexico City and now finally, HONG KONG \n\nThis will be one for the books, don’t miss their only show in East Asia!\n\nDate: 12 June 2026 7PM - 3AM\nVenue: AsiaWorld-Expo, Hall 3\n\n",
    "minimumAge": 18,
    "cost": "880",
    "contentUrl": "/events/2384155",
    "embargoDate": null,
    "date": "2026-06-12T00:00:00.000",
    "startTime": "2026-06-12T19:00:00.000",
    "endTime": "2026-06-13T03:00:00.000",
    "interestedCount": 1,
    "lineup": "Armin Van Buuren",
    "isTicketed": false,
    "isFestival": false,
    "dateUpdated": "2026-03-03T10:25:53.033Z",
    "resaleActive": false,
    "datePosted": "2026-03-03T10:25:53.033Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2488476",
        "filename": "https://images.ra.co/39daca939b76b495ed44423b5af1be04588189b8.png",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      }
    ],
    "venue": {
      "id": "21522",
      "name": "Asiaworld-Expo Hall",
      "address": "AsiaWorld-Expo, Hong Kong International Airport; Lantau, Hong Kong, China",
      "contentUrl": "/clubs/21522",
      "live": true,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 22.321812,
        "longitude": 113.941218
      }
    },
    "promoters": [
      {
        "id": "177474",
        "name": "Live Nation Electronic Asia",
        "contentUrl": "/promoters/177474",
        "live": false,
        "hasTicketAccess": false,
        "tracking": []
      }
    ],
    "artists": [],
    "pick": null,
    "promotionalLinks": [
      {
        "title": "Tickets",
        "url": "https://asiaworld-expo.kktix.cc/events/astateoftrancehongkong"
      }
    ],
    "tracking": [],
    "admin": {
      "id": "11535733",
      "username": "lnea"
    },
    "tickets": [],
    "standardTickets": [],
    "playerLinks": [
      {
        "id": "470025",
        "sourceId": "https://www.youtube.com/live/yaXiKZE5FeU?si=tzMYpzrYrk-iitab",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      },
      {
        "id": "470026",
        "sourceId": "https://youtu.be/-9L9hAecRgg?si=Mm-n0kHQzKt-J5Sr",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      },
      {
        "id": "470027",
        "sourceId": "https://youtu.be/k32Cc4koohY?si=SyiPA2B2WfNYSq4W",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      }
    ],
    "childEvents": [],
    "genres": [
      {
        "id": "2",
        "name": "Trance",
        "slug": "trance"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2391544",
    "title": "Host with Ouissam (Savage, Hanoi) [All Night Long]",
    "flyerFront": null,
    "flyerBack": null,
    "content": "It would be wrong to start talking about where Ouissam Mokretar comes from – after a decade in Asia, he’s now something of a regional entity that has managed to change the dance music scene wherever he has laid down roots. His approach to a dance floor is as simple as it is intuitive and elegant: nothing that can make a room shudder with joy is barred from his selections.\n\nAs the founder of Hong Kong’s Cliche Records, he was one of the first in that city to cultivate a disco-house-techno synthesis that shifted the understanding of what could be danced to there. He went on to create the magnetic Homesick and Fragrant Harbor labels, before suddenly setting his sights on Hanoi in Vietnam, where he has established the dance mecca Savage where he runs the monthly queer night Snug. And on top of all that, he found time to join the Wonderfruit team as a music director in 2023 and curate the coveted Equation festival.\n\nBut beyond his achievements, you find a DJ with a pure love and appreciation for the power of music, and one that has learnt how to harness this love into something that can be transmitted to his dance floors. Moving effortlessly between disco, house and techno, long-lost gems collide with cutting-edge groove to produce a sonic aesthetic that is simply irresistible.",
    "minimumAge": 21,
    "cost": "200$ / 300$",
    "contentUrl": "/events/2391544",
    "embargoDate": null,
    "date": "2026-06-13T00:00:00.000",
    "startTime": "2026-06-13T23:00:00.000",
    "endTime": "2026-06-14T06:00:00.000",
    "interestedCount": 0,
    "lineup": "<artist id=\"65242\">Ouissam</artist> (Savage, Hanoi) [All Night Long]",
    "isTicketed": true,
    "isFestival": false,
    "dateUpdated": "2026-03-11T12:15:18.400Z",
    "resaleActive": false,
    "datePosted": "2026-03-11T12:14:05.227Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2498561",
        "filename": "https://images.ra.co/940b4fe75ebed2509e911cd9bb7aaf9d6a9b7151.jpg",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      }
    ],
    "venue": {
      "id": "152213",
      "name": "宀 Club",
      "address": "4F, 279 Des Voeux Road Central, Sheung Wan, Hong Kong",
      "contentUrl": "/clubs/152213",
      "live": true,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 22.286855,
        "longitude": 114.151679
      }
    },
    "promoters": [
      {
        "id": "84769",
        "name": "宀 Club",
        "contentUrl": "/promoters/84769",
        "live": true,
        "hasTicketAccess": true,
        "tracking": []
      }
    ],
    "artists": [
      {
        "id": "65242",
        "name": "Ouissam",
        "contentUrl": "/dj/ouissam",
        "urlSafeName": "ouissam"
      }
    ],
    "pick": null,
    "promotionalLinks": [
      {
        "title": "Ouissam IG",
        "url": "https://www.instagram.com/ouissam.jpeg/"
      },
      {
        "title": "Host IG",
        "url": "https://www.instagram.com/host_hkg/?hl=en"
      }
    ],
    "tracking": [],
    "admin": {
      "id": "313005",
      "username": "jf.amadei"
    },
    "tickets": [
      {
        "id": "1277800",
        "title": "Advance ticket",
        "validType": "VALID",
        "onSaleFrom": "2026-03-11T12:00:00.000Z",
        "priceRetail": 28.25,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      }
    ],
    "standardTickets": [
      {
        "id": "1277800",
        "validType": "VALID"
      }
    ],
    "playerLinks": [
      {
        "id": "473781",
        "sourceId": "https://soundcloud.com/rainbowdiscoclub/rdc-091-ouissam",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      }
    ],
    "childEvents": [],
    "genres": [
      {
        "id": "6",
        "name": "House",
        "slug": "house"
      },
      {
        "id": "21",
        "name": "Disco",
        "slug": "disco"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  },
  {
    "id": "2375077",
    "title": "Cantomania Vol. 9 with DJ Fabsabs",
    "flyerFront": null,
    "flyerBack": null,
    "content": "首場《Cantomania》舉辦至今五年有多，承蒙大家嘅愛戴越搞越旺場。今次《Cantomania》回到原點 宀 Club，為大家帶來精彩表演。由 NYPD、Serrini、JB 等近期獨立音樂同 hip hop 樂曲，到伊健、Sammi、祖兒、黎明、Kelly 同郭富城首首千禧年經典，加埋哥哥同梅姐等八、九十年代金曲都會登場。唔少得嘅當然仲有電影電視劇主題曲、廣告歌、卡通主題曲，同埋網上面搵唔到嘅特別版 DJ remix。最後仲有 Eason、學友、王菲同 Beyond 等首首經典歌曲，包你聽到之後忍唔住舉高雙手一齊 high。門票快將售罄，想嚟就趁手啦！舞池上見\n\nCantomania has been growing in popularity since its establishment more than five years ago. For this addition, the party goes back to 宀 Club, where it all began. Bask in modern indie and hip hop classics from NYPD, Serrini, to JB, Y2K bangers from Ekin Cheng, Sammi, Joey, Leon, Kelly and Aaron, along with the golden tunes of the 80s and 90s such as Leslie and Anita. Expect twists and turns with movie and Tv themes, adverts, cartoons and special dj only edits not  available online, in addition to your favorite hands in air anthems from the likes of Eason, Jacky, Faye Wong and Beyond. \n\nTickets sell FAST! Don’t miss out! See you on the floor",
    "minimumAge": 18,
    "cost": "200$ / 250$ / 300$",
    "contentUrl": "/events/2375077",
    "embargoDate": null,
    "date": "2026-06-18T00:00:00.000",
    "startTime": "2026-06-18T22:00:00.000",
    "endTime": "2026-06-19T04:00:00.000",
    "interestedCount": 2,
    "lineup": "DJ Fabsabs",
    "isTicketed": true,
    "isFestival": false,
    "dateUpdated": "2026-03-04T14:52:45.710Z",
    "resaleActive": false,
    "datePosted": "2026-02-19T12:39:42.143Z",
    "hasSecretVenue": false,
    "live": true,
    "images": [
      {
        "id": "2490722",
        "filename": "https://images.ra.co/874638dd52cd5daea19a330bb035d77d584eb4a6.jpg",
        "alt": null,
        "type": "FLYERFRONT",
        "crop": null
      }
    ],
    "venue": {
      "id": "152213",
      "name": "宀 Club",
      "address": "4F, 279 Des Voeux Road Central, Sheung Wan, Hong Kong",
      "contentUrl": "/clubs/152213",
      "live": true,
      "area": {
        "id": "71",
        "name": "Hong Kong",
        "urlName": "hongkong",
        "country": {
          "id": "30",
          "name": "China",
          "urlCode": "CN",
          "isoCode": "CHN"
        }
      },
      "location": {
        "latitude": 22.286855,
        "longitude": 114.151679
      }
    },
    "promoters": [
      {
        "id": "84769",
        "name": "宀 Club",
        "contentUrl": "/promoters/84769",
        "live": true,
        "hasTicketAccess": true,
        "tracking": []
      }
    ],
    "artists": [],
    "pick": null,
    "promotionalLinks": [
      {
        "title": "Cantomania Interviewx",
        "url": "https://www.scmp.com/postmag/culture/article/3339157/cantomania-dj-night-driving-hong-kongs-cantopop-comeback"
      },
      {
        "title": "Cantomania IG",
        "url": "https://www.instagram.com/cantomania_official/?hl=en"
      }
    ],
    "tracking": [],
    "admin": {
      "id": "313005",
      "username": "jf.amadei"
    },
    "tickets": [
      {
        "id": "1260621",
        "title": "Early bird",
        "validType": "VALID",
        "onSaleFrom": "2026-02-19T11:00:00.000Z",
        "priceRetail": 22.6,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      },
      {
        "id": "1260624",
        "title": "1st release",
        "validType": "VALID",
        "onSaleFrom": "2026-02-19T11:00:00.000Z",
        "priceRetail": 28.25,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      },
      {
        "id": "1260625",
        "title": "Advance ticket",
        "validType": "VALID",
        "onSaleFrom": "2026-02-19T11:00:00.000Z",
        "priceRetail": 36.15,
        "isAddOn": false,
        "currency": {
          "id": "2",
          "code": "USD"
        }
      }
    ],
    "standardTickets": [
      {
        "id": "1260621",
        "validType": "VALID"
      },
      {
        "id": "1260624",
        "validType": "VALID"
      },
      {
        "id": "1260625",
        "validType": "VALID"
      }
    ],
    "playerLinks": [
      {
        "id": "465412",
        "sourceId": "https://www.youtube.com/watch?v=c1dRblXSjiU",
        "audioService": {
          "id": "8",
          "name": "Full Media Url"
        }
      }
    ],
    "childEvents": [],
    "genres": [
      {
        "id": "30",
        "name": "Pop",
        "slug": "pop"
      }
    ],
    "setTimes": {
      "id": null,
      "lineup": null,
      "status": "NONE"
    },
    "area": {
      "ianaTimeZone": "Asia/Shanghai"
    },
    "ticketingSystem": "LEGACY",
    "presaleStatus": null
  }
]