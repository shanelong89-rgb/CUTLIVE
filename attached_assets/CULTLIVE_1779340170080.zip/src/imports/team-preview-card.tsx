import { Eye, Smartphone, Monitor, Languages } from 'lucide-react';
import { useState } from 'react';
import type { ContentType } from './contentTypes';

interface ContentPreviewProps {
  contentType: ContentType;
  data: Record<string, any>;
}

// ── Shared LinkedIn Icon ─────────────────────────────────────────────────────

function LinkedInIcon({ className = 'w-3.5 h-3.5' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
    </svg>
  );
}

// ── Individual Preview Cards ─────────────────────────────────────────────────

function TeamPreview({ data, lang = 'en' }: { data: Record<string, any>; lang?: 'en' | 'zh' }) {
  const [isActive, setIsActive] = useState(true);
  const isZh = lang === 'zh';

  const displayName = isZh && data.nameZh ? data.nameZh : (data.name || 'Name');
  const displayRole = isZh && data.roleZh ? data.roleZh : (data.role || '');
  const displayContribution = isZh && data.contributionZh ? data.contributionZh : (data.contribution || '');
  const displayBio = isZh && data.bioZh ? data.bioZh : (data.bio || '');

  return (
    <div className="flex flex-col items-center text-center">
      {/* ── Exact copy of AboutPage team card ── */}
      <div
        onClick={() => setIsActive(prev => !prev)}
        className="relative w-full max-w-[340px] h-[380px] rounded-[1.5rem] overflow-hidden group cursor-pointer active:scale-[0.98] transition-transform"
      >
        {/* Photo background */}
        <div className="absolute inset-0 bg-navy/10">
          {data.photoUrl ? (
            <img
              src={data.photoUrl}
              alt={displayName}
              className={`w-full h-full object-cover transition-all duration-700 group-hover:scale-105 group-hover:grayscale-0 ${isActive ? 'scale-105 grayscale-0' : 'grayscale'}`}
              onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
            />
          ) : (
            <div className="w-full h-full bg-navy/10 flex items-center justify-center">
              <span className="text-navy/20 font-bold text-4xl">{(data.name || '?')[0]?.toUpperCase()}</span>
            </div>
          )}
        </div>

        {/* Gradient overlay */}
        <div className={`absolute inset-0 bg-gradient-to-t from-navy via-navy/40 to-transparent transition-opacity duration-500 group-hover:opacity-100 ${isActive ? 'opacity-100' : 'opacity-90'}`} />

        {/* Draft badge */}
        {data.status === 'draft' && (
          <div className="absolute top-3 left-3 z-20 px-2 py-0.5 bg-yellow-400 text-yellow-900 text-[10px] font-bold rounded-full uppercase">
            Draft
          </div>
        )}

        {/* LinkedIn icon */}
        {data.linkedinUrl && (
          <div className={`absolute top-4 right-4 z-20 w-8 h-8 rounded-full bg-white/90 backdrop-blur-md border border-white/50 shadow-lg flex items-center justify-center text-[#0077B5] transition-all duration-300 group-hover:opacity-100 ${isActive ? 'opacity-100' : 'opacity-0'}`}>
            <LinkedInIcon className="w-4 h-4" />
          </div>
        )}

        {/* Bottom content overlay — exact site structure */}
        <div className={`absolute bottom-0 left-0 right-0 p-6 transform transition-transform duration-300 group-hover:translate-y-0 ${isActive ? 'translate-y-0' : 'translate-y-2'}`}>
          <div className="flex flex-col gap-1 mb-1">
            <span className="text-gold font-bold uppercase tracking-wider text-[10px]">{displayRole}</span>
            <h3 className="text-xl font-bold !text-white leading-tight drop-shadow-md">{displayName}</h3>
          </div>

          {/* Expandable detail card */}
          <div className={`overflow-hidden transition-all duration-300 group-hover:h-auto group-hover:opacity-100 ${isActive ? 'h-auto opacity-100' : 'h-0 opacity-0'}`}>
            <div className="pt-3 mt-3 bg-white/90 backdrop-blur-md rounded-lg p-3 border border-white/50 shadow-lg max-h-none overflow-y-visible">
              {displayContribution && (
                <p className="text-navy/80 text-xs leading-relaxed mb-1 font-bold">{displayContribution}</p>
              )}
              {displayBio && (
                <p className="text-navy/60 text-[10px] leading-relaxed">{displayBio}</p>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Click hint */}
      <p className="text-gray-400 text-[10px] mt-2">Click card to {isActive ? 'collapse' : 'expand'} details</p>
    </div>
  );
}

function AdvisorPreview({ data, lang = 'en' }: { data: Record<string, any>; lang?: 'en' | 'zh' }) {
  const isZh = lang === 'zh';

  const displayName = isZh && data.nameZh ? data.nameZh : (data.name || 'Name');
  const displayTitle = isZh && data.titleZh ? data.titleZh : (data.title || '');

  return (
    <div className="flex flex-col items-center text-center py-6">
      {/* ── Exact match of AboutPage advisor layout (desktop) ── */}
      {data.status === 'draft' && (
        <span className="mb-3 px-2 py-0.5 bg-yellow-100 text-yellow-700 text-[10px] font-bold rounded-full uppercase">
          Draft
        </span>
      )}

      {data.linkedinUrl ? (
        <a href={data.linkedinUrl} target="_blank" rel="noopener noreferrer" className="group/name">
          <h3 className="text-2xl font-bold text-navy mb-2 whitespace-normal text-center leading-tight group-hover/name:text-[#0077B5] transition-colors duration-200 decoration-[#0077B5]/30 group-hover/name:underline underline-offset-4">{displayName}</h3>
        </a>
      ) : (
        <h3 className="text-2xl font-bold text-navy mb-2 whitespace-normal text-center leading-tight">{displayName}</h3>
      )}

      {displayTitle && (
        <span className="font-bold uppercase tracking-widest text-[10px] text-center leading-snug" style={{ color: '#5CACDE' }}>{displayTitle}</span>
      )}
    </div>
  );
}

function PartnerPreview({ data }: { data: Record<string, any> }) {
  const logoH = data.logoHeight || 40;

  return (
    <div className="space-y-4">
      {/* Logo card */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 flex flex-col items-center gap-4">
        {data.logoUrl ? (
          <div className="w-full flex items-center justify-center"
            style={{ minHeight: `${Math.max(logoH, 48)}px` }}
          >
            <img
              src={data.logoUrl}
              alt={data.name || 'Partner'}
              style={{ height: `${logoH}px`, width: 'auto' }}
              className="object-contain"
              onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
            />
          </div>
        ) : (
          <div className="w-20 h-20 rounded-xl bg-gray-100 flex items-center justify-center">
            <span className="text-xl font-bold text-gray-300">LOGO</span>
          </div>
        )}
        <div className="text-center">
          <h3 className="text-gray-900 font-bold text-sm">{data.name || 'Partner Name'}</h3>
          <div className="flex items-center gap-2 mt-1 justify-center">
            {data.type && (
              <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-600 text-[10px] font-bold uppercase">
                {data.type}
              </span>
            )}
            {data.tier && (
              <span className="px-2 py-0.5 rounded-full bg-blue-50 text-blue-600 text-[10px] font-bold uppercase">
                {data.tier}
              </span>
            )}
          </div>
        </div>
        {/* Display size badge */}
        {data.logoUrl && (
          <div className="text-[10px] text-gray-400 font-mono bg-gray-50 px-2 py-0.5 rounded">
            Display height: {logoH}px
          </div>
        )}
      </div>

      {/* How it looks in partner strip */}
      <div>
        <p className="text-gray-400 text-[10px] font-bold uppercase tracking-wider mb-2 text-center">
          Partner Strip Preview
        </p>
        <div className="bg-slate-50 rounded-xl p-6 flex items-center justify-center">
          {data.logoUrl ? (
            <img
              src={data.logoUrl}
              alt={data.name}
              style={{ height: `${logoH}px`, width: 'auto' }}
              className="object-contain grayscale opacity-60 hover:grayscale-0 hover:opacity-100 transition-all duration-500"
            />
          ) : (
            <div className="h-10 w-24 bg-gray-200 rounded flex items-center justify-center text-[10px] text-gray-400">
              No logo
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function VenturePreview({ data }: { data: Record<string, any> }) {
  const stageColor: Record<string, string> = {
    active: 'bg-pink-500/10 text-pink-500 border-pink-500/20',
    pilot: 'bg-sky-500/10 text-sky-500 border-sky-500/20',
    alumni: 'bg-white/20 text-white/70 border-white/30',
  };

  const themeColor: Record<string, string> = {
    'Longevity & Aging': 'text-sky-400',
    'Circular Economy': 'text-pink-400',
    'Financial Inclusion': 'text-purple-400',
    'Youth & Future Skills': 'text-gray-300',
    'Biotechnology & Wellbeing': 'text-green-400',
  };

  return (
    <div className="space-y-4">
      {/* Portfolio card — dark theme like the actual site */}
      <div className="bg-[#1a2332] rounded-2xl border border-white/10 p-5 max-w-[320px] mx-auto">
        <div className="flex items-start gap-3 mb-3">
          {data.logo ? (
            <img
              src={data.logo}
              alt={data.name}
              className="w-10 h-10 rounded-lg object-contain bg-white p-1 flex-shrink-0"
              onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
            />
          ) : (
            <div className="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center flex-shrink-0">
              <span className="text-sm font-bold text-white/40">
                {(data.name || '?')[0]?.toUpperCase()}
              </span>
            </div>
          )}
          <div className="min-w-0 flex-1">
            <h3 className="text-white font-bold text-sm truncate mb-1">
              {data.name || 'Venture Name'}
            </h3>
            <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider border ${stageColor[data.stage] || stageColor.active}`}>
              {data.ventureStatus || data.stage || 'Active'}
            </span>
          </div>
        </div>

        <p className="text-white/50 text-xs leading-relaxed line-clamp-2 mb-3">
          {data.description || 'Venture description will appear here...'}
        </p>

        <div className="flex items-center gap-2 flex-wrap">
          <span className={`text-[10px] font-medium uppercase tracking-wider bg-white/5 px-2 py-0.5 rounded-full ${themeColor[data.theme] || 'text-white/40'}`}>
            {data.theme || 'Theme'}
          </span>
          {data.year && (
            <span className="text-[10px] text-white/30">{data.year}</span>
          )}
        </div>

        {data.impact && (
          <div className="mt-3 pt-3 border-t border-white/10">
            <p className="text-white/30 text-[10px] font-bold uppercase tracking-wider mb-1">Impact</p>
            <p className="text-white/60 text-[11px] leading-relaxed line-clamp-2">{data.impact}</p>
          </div>
        )}
      </div>
    </div>
  );
}

function MetricPreview({ data }: { data: Record<string, any> }) {
  const colorMap: Record<string, string> = {
    jade: 'text-emerald-500',
    navy: 'text-slate-800',
    gold: 'text-amber-500',
    pink: 'text-pink-500',
  };

  return (
    <div className="space-y-4">
      {/* Stat card — like the stats bar on portfolio page */}
      <div className="bg-[#1a2332] rounded-2xl border border-white/10 p-6 text-center max-w-[200px] mx-auto">
        <div className={`text-4xl font-bold mb-1 ${colorMap[data.color] || 'text-white'}`}>
          {data.prefix}{data.value || 0}{data.suffix}
        </div>
        <div className="text-white/50 text-xs font-medium uppercase tracking-wider">
          {data.label || 'Label'}
        </div>
        {data.context && (
          <p className="text-white/30 text-[10px] mt-2">{data.context}</p>
        )}
      </div>

      {/* Light variant */}
      <div>
        <p className="text-gray-400 text-[10px] font-bold uppercase tracking-wider mb-2 text-center">
          Light Background
        </p>
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 text-center max-w-[200px] mx-auto">
          <div className={`text-4xl font-bold mb-1 ${colorMap[data.color] || 'text-gray-900'}`}>
            {data.prefix}{data.value || 0}{data.suffix}
          </div>
          <div className="text-gray-400 text-xs font-medium uppercase tracking-wider">
            {data.label || 'Label'}
          </div>
        </div>
      </div>
    </div>
  );
}

function SiteImagePreview({ data }: { data: Record<string, any> }) {
  return (
    <div className="space-y-4">
      {data.url ? (
        <div className="relative rounded-2xl overflow-hidden border border-gray-200 shadow-sm">
          <img
            src={data.url}
            alt={data.alt || data.slot || 'Site image'}
            className="w-full h-48 object-cover"
            onError={(e) => {
              (e.target as HTMLImageElement).style.display = 'none';
            }}
          />
          {data.alt && (
            <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/60 to-transparent p-3">
              <p className="text-white text-xs">{data.alt}</p>
            </div>
          )}
        </div>
      ) : (
        <div className="w-full h-48 rounded-2xl bg-gray-100 border-2 border-dashed border-gray-300 flex flex-col items-center justify-center gap-2">
          <div className="w-12 h-12 rounded-xl bg-gray-200 flex items-center justify-center">
            <svg className="w-6 h-6 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
              <path d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.41a2.25 2.25 0 013.182 0l2.909 2.91m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
            </svg>
          </div>
          <p className="text-gray-400 text-xs">No image set</p>
        </div>
      )}

      {(data.page || data.slot) && (
        <div className="flex items-center gap-2 justify-center">
          {data.page && (
            <span className="px-2 py-0.5 rounded-full bg-blue-50 text-blue-600 text-[10px] font-bold uppercase">
              {data.page}
            </span>
          )}
          {data.slot && (
            <span className="text-gray-500 text-xs">{data.slot}</span>
          )}
        </div>
      )}
    </div>
  );
}

function CatalystPreview({ data, lang = 'en' }: { data: Record<string, any>; lang?: 'en' | 'zh' }) {
  const isZh = lang === 'zh';
  const displayName = isZh && data.nameZh ? data.nameZh : (data.name || 'Catalyst Name');
  const displayFocus = isZh && data.focusZh ? data.focusZh : (data.focus || 'Focus Area');

  return (
    <div className="space-y-4">
      {/* Card — matches DonatePage supporter card */}
      <div className="bg-white border border-gray-100 rounded-[2rem] p-8 hover:border-amber-300 transition-all duration-300 group text-left shadow-sm max-w-[320px] mx-auto">
        <div className="flex items-start justify-between mb-8">
          <div className="w-14 h-14 rounded-2xl bg-amber-50 border border-amber-100 flex items-center justify-center overflow-hidden">
            {data.logo ? (
              <img
                src={data.logo}
                alt={displayName}
                className="w-full h-full object-contain p-1"
                onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
              />
            ) : (
              <span className="text-lg font-bold text-amber-400">
                {(data.name || '?')[0]?.toUpperCase()}
              </span>
            )}
          </div>
          <span className="px-3 py-1 bg-gray-50 text-gray-400 text-xs font-bold rounded-full border border-gray-100">
            {data.year || '—'}
          </span>
        </div>

        <div className="mb-6">
          <h3 className="text-xl font-bold text-gray-900 mb-2 leading-tight">{displayName}</h3>
          <p className="text-emerald-600 font-medium text-sm tracking-wide leading-tight">{displayFocus}</p>
        </div>

        {data.status === 'draft' && (
          <span className="px-2 py-0.5 bg-yellow-100 text-yellow-700 text-[10px] font-bold rounded-full uppercase">
            Draft
          </span>
        )}
      </div>
    </div>
  );
}

// ── Preview Router ───────────────────────────────────────────────────────────

// Components that support language switching
const langAwarePreviewMap: Record<string, React.ComponentType<{ data: Record<string, any>; lang?: 'en' | 'zh' }>> = {
  team: TeamPreview,
  advisor: AdvisorPreview,
  catalyst: CatalystPreview,
};

// Components without language switching
const basicPreviewMap: Record<string, React.ComponentType<{ data: Record<string, any> }>> = {
  partner: PartnerPreview,
  metric: MetricPreview,
  venture: VenturePreview,
};

// Content types that support language preview
const supportsLang = new Set(Object.keys(langAwarePreviewMap));

// ── Main Preview Component ───────────────────────────────────────────────────

export function ContentPreview({ contentType, data }: ContentPreviewProps) {
  const [viewMode, setViewMode] = useState<'desktop' | 'mobile'>('desktop');
  const [previewLang, setPreviewLang] = useState<'en' | 'zh'>('en');

  const LangPreview = langAwarePreviewMap[contentType.key];
  const BasicPreview = basicPreviewMap[contentType.key];
  const hasLangSupport = supportsLang.has(contentType.key);

  if (!LangPreview && !BasicPreview) {
    return (
      <div className="h-full flex items-center justify-center text-gray-400 text-sm">
        No preview available for this content type
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      {/* Preview Header */}
      <div className="flex items-center justify-between pb-3 mb-3 border-b border-gray-200">
        <div className="flex items-center gap-2">
          <Eye className="w-3.5 h-3.5 text-emerald-500" />
          <span className="text-gray-600 text-xs font-semibold uppercase tracking-wider">
            Live Preview
          </span>
        </div>
        <div className="flex items-center gap-2">
          {/* Language toggle — only for content types with ZH fields */}
          {hasLangSupport && (
            <div className="flex items-center gap-1 bg-gray-100 rounded-lg p-0.5">
              <button
                onClick={() => setPreviewLang('en')}
                className={`px-2 py-1 rounded-md text-[10px] font-bold transition ${
                  previewLang === 'en'
                    ? 'bg-white shadow-sm text-gray-900'
                    : 'text-gray-400 hover:text-gray-600'
                }`}
                title="English preview"
              >
                EN
              </button>
              <button
                onClick={() => setPreviewLang('zh')}
                className={`px-2 py-1 rounded-md text-[10px] font-bold transition ${
                  previewLang === 'zh'
                    ? 'bg-emerald-600 shadow-sm text-white'
                    : 'text-gray-400 hover:text-gray-600'
                }`}
                title="Chinese preview"
              >
                ZH
              </button>
            </div>
          )}
          {/* Desktop / Mobile toggle */}
          <div className="flex items-center gap-1 bg-gray-100 rounded-lg p-0.5">
            <button
              onClick={() => setViewMode('desktop')}
              className={`p-1.5 rounded-md transition ${
                viewMode === 'desktop'
                  ? 'bg-white shadow-sm text-gray-900'
                  : 'text-gray-400 hover:text-gray-600'
              }`}
              title="Desktop"
            >
              <Monitor className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setViewMode('mobile')}
              className={`p-1.5 rounded-md transition ${
                viewMode === 'mobile'
                  ? 'bg-white shadow-sm text-gray-900'
                  : 'text-gray-400 hover:text-gray-600'
              }`}
              title="Mobile"
            >
              <Smartphone className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Preview Canvas */}
      <div className="flex-1 overflow-y-auto">
        <div
          className={`mx-auto transition-all duration-300 ${
            viewMode === 'mobile' ? 'max-w-[320px]' : 'max-w-full'
          }`}
        >
          {LangPreview ? (
            <LangPreview data={data} lang={previewLang} />
          ) : BasicPreview ? (
            <BasicPreview data={data} />
          ) : null}
        </div>
      </div>

      {/* Preview Footer */}
      <div className="pt-3 mt-3 border-t border-gray-200">
        <p className="text-gray-400 text-[10px] text-center">
          Preview updates as you type{hasLangSupport ? ' · Toggle EN/ZH to preview translations' : ' · Shows how this item appears on the site'}
        </p>
      </div>
    </div>
  );
}

// ── List Item Thumbnail ──────────────────────────────────────────────────────
// Small visual badge shown in the item list for visual recognition

export function ItemThumbnail({
  contentType,
  item,
}: {
  contentType: ContentType;
  item: Record<string, any>;
}) {
  switch (contentType.key) {
    case 'team':
    case 'advisor':
      return item.photoUrl ? (
        <img
          src={item.photoUrl}
          alt={item.name}
          className="w-9 h-9 rounded-full object-cover border border-gray-200 flex-shrink-0"
        />
      ) : (
        <div className="w-9 h-9 rounded-full bg-gradient-to-br from-emerald-100 to-emerald-200 flex items-center justify-center flex-shrink-0">
          <span className="text-sm font-bold text-emerald-600">
            {(item.name || '?')[0]?.toUpperCase()}
          </span>
        </div>
      );

    case 'partner':
      return item.logoUrl ? (
        <div className="w-9 h-9 rounded-lg bg-white border border-gray-200 p-1 flex items-center justify-center flex-shrink-0">
          <img src={item.logoUrl} alt={item.name} className="max-w-full max-h-full object-contain" />
        </div>
      ) : (
        <div className="w-9 h-9 rounded-lg bg-gray-100 flex items-center justify-center flex-shrink-0">
          <span className="text-[10px] font-bold text-gray-400">LOGO</span>
        </div>
      );

    case 'venture':
      return item.logo ? (
        <div className="w-9 h-9 rounded-lg bg-white border border-gray-200 p-1 flex items-center justify-center flex-shrink-0">
          <img src={item.logo} alt={item.name} className="max-w-full max-h-full object-contain" />
        </div>
      ) : (
        <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-slate-700 to-slate-800 flex items-center justify-center flex-shrink-0">
          <span className="text-sm font-bold text-white/40">
            {(item.name || '?')[0]?.toUpperCase()}
          </span>
        </div>
      );

    case 'catalyst':
      return item.logo ? (
        <div className="w-9 h-9 rounded-lg bg-white border border-gray-200 p-1 flex items-center justify-center flex-shrink-0">
          <img src={item.logo} alt={item.name} className="max-w-full max-h-full object-contain" />
        </div>
      ) : (
        <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-amber-100 to-amber-200 flex items-center justify-center flex-shrink-0">
          <span className="text-sm font-bold text-amber-700">
            {(item.name || '?')[0]?.toUpperCase()}
          </span>
        </div>
      );

    case 'metric': {
      const colorBg: Record<string, string> = {
        jade: 'from-emerald-100 to-emerald-200 text-emerald-700',
        navy: 'from-slate-100 to-slate-200 text-slate-700',
        gold: 'from-amber-100 to-amber-200 text-amber-700',
        pink: 'from-pink-100 to-pink-200 text-pink-700',
      };
      return (
        <div className={`w-9 h-9 rounded-lg bg-gradient-to-br ${colorBg[item.color] || 'from-gray-100 to-gray-200 text-gray-700'} flex items-center justify-center flex-shrink-0`}>
          <span className="text-xs font-bold">{item.prefix}{item.value}{item.suffix}</span>
        </div>
      );
    }

    case 'siteimage':
      return item.url ? (
        <img
          src={item.url}
          alt={item.alt || item.slot}
          className="w-9 h-9 rounded-lg object-cover border border-gray-200 flex-shrink-0"
        />
      ) : (
        <div className="w-9 h-9 rounded-lg bg-gray-100 flex items-center justify-center flex-shrink-0">
          <svg className="w-4 h-4 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
            <path d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.41a2.25 2.25 0 013.182 0l2.909 2.91m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
          </svg>
        </div>
      );

    default:
      return null;
  }
}

// ── Venture Stage Badge (for list view) ──────────────────────────────────────

export function StageBadge({ stage }: { stage: string }) {
  const colors: Record<string, string> = {
    active: 'bg-pink-50 text-pink-600',
    pilot: 'bg-sky-50 text-sky-600',
    alumni: 'bg-gray-100 text-gray-500',
  };

  return (
    <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold uppercase ${colors[stage] || 'bg-gray-100 text-gray-500'}`}>
      {stage}
    </span>
  );
}