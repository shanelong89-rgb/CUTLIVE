# CMS UX Reference Guide

> Reference doc for replicating the SOW Asia admin CMS UX patterns in new projects.
> This documents what works well, the architecture decisions, and how to adapt it for a contributor-submission-based site.

---

## 1. Architecture Overview

### Stack

| Layer | Tech | Role |
|-------|------|------|
| Frontend | React + Tailwind CSS + Motion | Admin panel UI at `/admin` |
| Auth | Supabase Auth (email/password) | Admin login, session JWT |
| API | Supabase Edge Function (Hono) | Single serverless endpoint for all CRUD |
| Storage | Supabase KV Store (single `kv_store` table) | All CMS data stored as JSON blobs |
| File Storage | Supabase Storage bucket | Image/media uploads |
| AI | Google Gemini (via Edge Function) | Translation, could extend to moderation |

### Key Principle: KV-Store CMS

Instead of a traditional relational schema, all content lives in a **single KV table** (`kv_store`):

```
key: "content:team:john-doe"     value: { name: "John", role: "CEO", ... }
key: "content:partner:google"    value: { name: "Google", logoUrl: "...", ... }
key: "siteimage:home-hero-bg"    value: { url: "...", alt: "..." }
key: "copy:nav.about"            value: { value: "About Us" }
```

**Why this works:**
- Zero schema migrations -- add a new content type by editing a single TypeScript file
- Everything is JSON, so fields are flexible
- Static fallback data ships with the build, so the site works even if the API is down
- CMS overrides layer on top of static defaults -- you only store what's been changed

---

## 2. Content Type Registry (`contentTypes.ts`)

This is the heart of the CMS. A single TypeScript array defines every content type:

```ts
export interface ContentType {
  key: string;           // URL slug & KV prefix: "team", "partner", etc.
  label: string;         // Singular: "Team Member"
  labelPlural: string;   // Plural: "Team Members"
  icon: string;          // Lucide icon name
  idField: string;       // Which field is the unique ID
  titleField: string;    // Which field shows as the item title in lists
  subtitleField: string; // Secondary info in list view
  fields: FieldDef[];    // Schema definition
  defaultValues: Record<string, any>;  // New item defaults
  page?: string;         // Which site page this belongs to (for sidebar grouping)
  pageHint?: string;     // Short description
}

export interface FieldDef {
  key: string;
  label: string;
  type: 'text' | 'textarea' | 'number' | 'select' | 'toggle' | 'image' | 'json' | 'tags' | 'color';
  options?: { label: string; value: string }[];
  placeholder?: string;
  required?: boolean;
}
```

**To add a new content type:** Add one object to the `contentTypes` array. The ContentManager, sidebar, dashboard, API, and preview all auto-discover it. Zero other files to touch.

### Adaptation for Contributor Site

For a submission-based system, you'd add content types like:

```ts
{
  key: 'submission',
  label: 'Submission',
  labelPlural: 'Submissions',
  fields: [
    { key: 'source', type: 'select', options: [
      { label: 'Instagram', value: 'instagram' },
      { label: 'Google Maps', value: 'google-maps' },
      { label: 'Manual Upload', value: 'manual' },
    ]},
    { key: 'sourceUrl', type: 'text', label: 'Source URL' },
    { key: 'images', type: 'json', label: 'Images (array)' },
    { key: 'caption', type: 'textarea' },
    { key: 'contributorName', type: 'text' },
    { key: 'aiScore', type: 'number', label: 'AI Viability Score' },
    { key: 'aiNotes', type: 'textarea', label: 'AI Review Notes' },
    { key: 'moderationStatus', type: 'select', options: [
      { label: 'Pending Review', value: 'pending' },
      { label: 'AI Approved', value: 'ai-approved' },
      { label: 'AI Flagged', value: 'ai-flagged' },
      { label: 'Admin Approved', value: 'approved' },
      { label: 'Rejected', value: 'rejected' },
    ]},
  ],
}
```

---

## 3. Admin Layout & Sidebar UX

### Structure

```
/admin              -> Dashboard (overview cards with item counts)
/admin/content/:type -> ContentManager (dynamic, driven by contentTypes.ts)
/admin/copy         -> Copy Editor (i18n key editor)
/admin/images       -> ImageManager (hero/background images)
/admin/media-library -> Media Library (file browser)
/admin/translation-hub -> Translation Hub (AI translate tools)
```

### Sidebar Grouping

Content types are grouped by **which site page they appear on**, not by data type. This is key UX -- admins think in terms of "I need to update the About page" not "I need to find the advisor table."

```ts
const pageGroups = [
  { page: 'home', label: 'Homepage', icon: Home },
  { page: 'about', label: 'About', icon: Info },
  { page: 'portfolio', label: 'Portfolio', icon: Briefcase },
];
```

Each content type has a `page` field that determines which group it appears under. Section headers use the page icon + label. A divider separates content types from tools.

**Collapsible sidebar:** Desktop sidebar collapses to icon-only mode. Mobile has a slide-out overlay.

---

## 4. ContentManager (The Universal CRUD UI)

This is a single component that handles ALL content types. It reads the `ContentType` definition and auto-generates the entire form UI.

### Layout: Three-Panel Design

```
[ Item List (left) ] [ Edit Form (center) ] [ Live Preview (right) ]
```

- **Item List:** Searchable, sortable. Each item shows a thumbnail (via `ItemThumbnail`), title, subtitle, and status badge. Supports list view and grid view.
- **Edit Form:** Auto-generated from `fields[]`. Each field type maps to the appropriate input: text input, textarea, number spinner, select dropdown, image uploader, etc.
- **Live Preview:** Real-time preview showing exactly how the item will look on the front-end. Updates as you type.

### Key UX Patterns

1. **Search bar** at the top of the item list -- instant filtering across all text fields
2. **Visual thumbnails** in the list view (photos for team, logos for partners, color chips for metrics)
3. **Inline AI translation** -- Chinese fields have a sparkle button that auto-translates from the English counterpart
4. **Bulk AI translate** -- "Translate All Empty" button fills in all empty Chinese fields at once
5. **Status badges** -- Draft/Published shown as colored pills
6. **Seed from static** -- Database icon to bulk-import from the static fallback data (first-time setup)
7. **Delete confirmation** -- Inline red confirmation bar, not a modal (less disruptive)
8. **Image upload** -- Click the image field to either paste a URL or upload a file (drag-drop or file picker). Preview shows immediately.
9. **Grid view** for visual content types (team photos, partner logos, metrics cards)
10. **View mode toggle** (list/grid) persists per content type

### What Makes It "Don't Touch It" Friendly

The CMS is designed so admins **rarely need to visit it**:

- Static fallback data ships with the build, so the site looks complete on day zero
- CMS overrides only store deltas -- you change one partner logo, only that one record exists in KV
- The `useCmsContent` hook on the front-end merges static + CMS data automatically
- `status: 'draft'` items are suppressed from the public site without deleting them

---

## 5. Image Manager (Protected Slots)

### Slot-Based System

Instead of a generic media library, images are organized into **named slots** grouped by page:

```ts
export const staticSiteImages = [
  { id: 'program-founders', page: 'venture-studio', slot: 'Founders With Purpose card image', alt: '...', url: 'https://...', status: 'published' },
  { id: 'theme-longevity', page: 'impact-themes', slot: 'Longevity & Urban Health theme image', alt: '...', url: 'https://...', status: 'published' },
  // ...
];
```

Each slot has:
- **A default URL** baked into the build
- **An override URL** stored in KV (takes precedence)
- **A page group** for sidebar organization
- **A human-readable slot name** so admins know exactly what this image controls

### Protection Gate

Hero/background images are **locked by default** with a confirmation gate:

1. Card shows a lock icon + amber "BACKGROUND" badge
2. Instead of edit controls, shows a warning: *"Page background gradient image. Do not change unless necessary. Changes cannot be easily reverted."*
3. "Unlock to edit" button opens a modal requiring explicit confirmation
4. Unlock is **session-only** -- refreshing re-locks
5. Even after unlocking, a persistent amber warning stays visible

**Why:** The people updating the website day-to-day shouldn't be making design decisions about page backgrounds. This separates "content operations" (update a partner logo) from "design decisions" (change a page hero gradient).

### Frontend Consumption

```ts
const { img } = useSiteImages(staticSiteImages);

// Returns CMS override if set, falls back to static default
<img src={img('program-founders')} alt="..." />
```

---

## 6. Copy Editor (i18n Key Management)

### How It Works

1. Flattens the entire locale JSON into dot-notation keys: `nav.about`, `home.hero.title`, etc.
2. Groups keys by **page section** (Navigation, Footer, Home, About, etc.)
3. Shows English and Chinese values side-by-side
4. Inline edit any value, save to KV override
5. AI translate button on each Chinese field (sparkle icon)
6. Bulk "Translate Missing" to fill all empty Chinese keys for a section

### Key UX

- **Section collapse/expand** -- don't show 500 keys at once
- **Search** across all keys and values
- **Modified indicator** -- blue dot on keys that have CMS overrides
- **Preview mode** -- see the translated value in context

---

## 7. API Layer (Dual-Header Auth)

### Auth Pattern

All admin API calls use two headers:

```ts
headers: {
  'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,  // RLS passthrough
  'X-Auth-Token': sessionJWT,                       // User identity
}
```

- `Authorization` with the anon key lets the request pass through Supabase's API gateway
- `X-Auth-Token` carries the user's session JWT, validated server-side via `supabase.auth.getUser(token)`
- Public endpoints (reading content for the front-end) only need the `Authorization` header

### API Routes

```
GET  /api/content/:type/public    -> Public read (filtered, no drafts)
GET  /api/content/:type           -> Admin list all (includes drafts)
POST /api/content/:type           -> Create item
PUT  /api/content/:type/:id       -> Update item
DEL  /api/content/:type/:id       -> Delete item
POST /api/content/:type/seed      -> Bulk seed from static data

GET  /api/copy                    -> List copy overrides
PUT  /api/copy/:key               -> Update copy override

GET  /api/site-images             -> List image overrides (public)
PUT  /api/site-images/:slotId     -> Update image override

POST /api/upload                  -> Upload file to storage
GET  /api/media                   -> List uploaded files
DEL  /api/media                   -> Delete uploaded files

POST /api/translate               -> Single text translation (AI)
POST /api/translate/batch         -> Batch translation (AI)
```

---

## 8. Frontend Data Flow (Static + CMS Merge)

### Three-Layer Data Model

```
Layer 1: Static Fallback (ships with build)
  ↓ overridden by
Layer 2: CMS KV Overrides (from Supabase)
  ↓ filtered by
Layer 3: Status Filter (drafts suppressed)
```

### `useCmsContent` Hook

```ts
const { data: partners } = useCmsContent<CMSPartner>('partner', staticPartners, {
  filterFn: (p) => p.tier === 'principal',
  sortField: 'sortOrder',
});
```

1. Starts with static fallback data (instant render, no loading state)
2. Fetches CMS data in background
3. Merges: CMS items override matching static items by ID
4. Suppresses static items that have been set to `draft` in CMS
5. Adds CMS-only items (new items created in admin that aren't in static)
6. Applies filter and sort options

### `useSiteImages` Hook

```ts
const { img } = useSiteImages(staticSiteImages);
// img('slot-id') returns override URL or static default
```

### `useCmsCopy` Hook

```ts
const { t } = useCmsCopy(enLocale);
// t('nav.about') returns override or static translation
```

---

## 9. Adaptation Checklist for Contributor-Submission Site

### What to Keep

- [ ] **KV-store architecture** -- still the best fit. Key pattern: `submission:<uuid>`, `contributor:<id>`
- [ ] **Content type registry** -- define submission, contributor, event content types the same way
- [ ] **Auto-generated CRUD forms** -- ContentManager works for any shape of data
- [ ] **Static fallback + CMS override** pattern for site content
- [ ] **Image slot system** for page backgrounds
- [ ] **Dual-header auth pattern** for API security
- [ ] **Sidebar grouped by context** (Submissions, Contributors, Site Content, Tools)

### What to Add

- [ ] **Submission pipeline UI** -- new admin view replacing the generic list:
  - Kanban columns: Pending -> AI Reviewed -> Approved -> Published -> Rejected
  - Click to approve/reject with one tap
  - Bulk approve/reject selected items
  - Filter by source (Instagram, Google Maps, Manual)

- [ ] **AI Moderation layer** -- new Edge Function:
  - On submission ingest, run through Gemini/Claude:
    - Is this a branded/sponsored event? (score 0-100)
    - Does it match content requirements? (checklist)
    - Image quality check (resolution, aspect ratio)
    - Spam/duplicate detection
  - Auto-approve above threshold, auto-reject below threshold, queue middle for human review
  - Store AI score + reasoning on the submission record

- [ ] **Contributor portal** -- separate from admin:
  - Simple form: paste Instagram URL, or upload images
  - Instagram URL scraper (Edge Function with Apify or similar)
  - Google Maps link parser
  - Progress indicator: "Submitted -> Under Review -> Approved / Not Selected"
  - No login required (or simple magic link)

- [ ] **Auto-generation pipeline**:
  - Approved submissions auto-generate front-end cards
  - Use content type field mapping to build the card data
  - Admin just clicks "Approve" and it appears on site

- [ ] **Rejection bin** -- items marked rejected are hidden from admin's default view but retrievable:
  - "Show rejected" toggle
  - Rejection reason (auto-filled by AI, editable)
  - Contributor notification (optional)

### Sidebar Structure for New Site

```
SUBMISSIONS
  Pending Review          (badge: count)
  AI Flagged              (badge: count)
  Approved
  Published
  Rejected (hidden)

CONTRIBUTORS
  Contributors

SITE CONTENT
  [whatever static content types]

TOOLS
  Media Library
  AI Settings (thresholds, requirements)
  Import History
```

### Admin "Don't Touch It" Design

The whole point is admin does minimal work:

1. **Contributor uploads** (Instagram scrape or manual) -> auto-ingested
2. **AI scans and scores** -> auto-sorts into approved/flagged/rejected
3. **Admin opens "Pending Review"** -> sees only flagged items that need human judgment
4. **One-click approve/reject** -> item moves to approved list
5. **Approved items auto-publish** -> front-end renders them
6. **Admin's daily workflow:** Open CMS -> glance at pending count -> tap through 3-5 flagged items -> done

---

## 10. File Structure Reference

```
src/
  app/
    pages/admin/
      AdminLayout.tsx        -- Sidebar + auth guard + outlet
      AdminDashboard.tsx     -- Overview cards with counts
      AdminLogin.tsx         -- Email/password login
      ContentManager.tsx     -- Universal CRUD UI (auto-generated from contentTypes)
      ContentPreview.tsx     -- Live preview components per content type
      CopyEditor.tsx         -- i18n key editor with AI translate
      ImageManager.tsx       -- Hero/background image slot manager
      MediaLibrary.tsx       -- File browser for uploaded media
      TranslationHub.tsx     -- Translation memory & AI tools
      contentTypes.ts        -- THE REGISTRY -- defines all content types
    hooks/
      useAdminApi.ts         -- Auth + all admin API calls
      useCmsData.ts          -- Frontend hooks (useCmsContent, useCmsCopy)
      useSiteImages.ts       -- Frontend hook for image slot overrides
    data/
      cms.ts                 -- Static fallback data + type definitions
  lib/
    supabase.ts              -- Project ID + anon key exports
supabase/
  functions/server/
    index.tsx                -- All API routes (Hono on Edge Function)
```

---

## 11. Quick Reference: Adding a New Content Type

1. **Define it** in `contentTypes.ts`:
   ```ts
   { key: 'event', label: 'Event', labelPlural: 'Events', icon: 'Calendar', page: 'events', ... }
   ```

2. **Add static fallback** in `cms.ts`:
   ```ts
   export const staticEvents: CMSEvent[] = [ ... ];
   ```

3. **Add to sidebar** in `AdminLayout.tsx`:
   ```ts
   pageGroups.push({ page: 'events', label: 'Events', icon: Calendar });
   ```

4. **Add to fallback map** in `ContentManager.tsx`:
   ```ts
   staticFallbackMap['event'] = staticEvents;
   ```

5. **Add preview** in `ContentPreview.tsx`:
   ```ts
   function EventPreview({ data }) { ... }
   previewMap['event'] = EventPreview;
   ```

6. **Consume on front-end**:
   ```ts
   const { data: events } = useCmsContent<CMSEvent>('event', staticEvents);
   ```

That's it. No API changes, no database migrations, no new routes.
