CULTIVE (文化活) — Complete Technical Architecture
Executive Summary
CULTIVE is a hyper-local cultural events platform that combines mode-aware map discovery with venue-centric immersive recaps. Users experience Hong Kong's cultural scene through contextual lenses (Degen/Family/Artsy modes) that persist from map exploration through venue details to past-event viewing.

🏗️ System Architecture Overview
text
┌─────────────────────────────────────────────────────────────────────┐
│                         CLIENT LAYERS                                │
├─────────────────────────────────────────────────────────────────────┤
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐     │
│  │   React Web     │  │  React Native   │  │   PWA Mobile    │     │
│  │   (Desktop)     │  │  (iOS/Android)  │  │   (Mobile Web)  │     │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘     │
│                                                                     │
│  Core Client Features:                                              │
│  • Mode persistence across navigation                               │
│  • Real-time map rendering                                          │
│  • Immersive venue views                                            │
│  • Offline capability for saved venues                              │
└─────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────┐
│                      API GATEWAY (GraphQL)                          │
├─────────────────────────────────────────────────────────────────────┤
│  • Authentication (JWT/OAuth)        • Rate limiting               │
│  • Query optimization                • Response caching            │
│  • Request validation                • Analytics tracking          │
│  • Mode context propagation          • Error handling              │
└─────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────┐
│                         MICROSERVICES LAYER                         │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                 CORE DOMAIN SERVICES                         │   │
│  ├───────────────────┬───────────────────┬─────────────────────┤   │
│  │  Venue Service    │  Event Service    │  User Service       │   │
│  │  • CRUD operations│  • Event mgmt     │  • Profiles         │   │
│  │  • Geo-indexing   │  • Scheduling     │  • Preferences      │   │
│  │  • Mode profiles  │  • Ticketing      │  • Mode history     │   │
│  └───────────────────┴───────────────────┴─────────────────────┘   │
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                 EXPERIENCE SERVICES                          │   │
│  ├───────────────────┬───────────────────┬─────────────────────┤   │
│  │  Map Service      │  Recap Service    │  Mode Service       │   │
│  │  • Tile rendering │  • UGC aggregation│  • Mode definitions │   │
│  │  • Icon injection│  • Mode filtering │  • Visual themes    │   │
│  │  • Clustering    │  • Immersive view │  • State management │   │
│  └───────────────────┴───────────────────┴─────────────────────┘   │
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                 INTELLIGENCE SERVICES                         │   │
│  ├───────────────────┬───────────────────┬─────────────────────┤   │
│  │  Scraper Service  │  AI Service       │  Search Service     │   │
│  │  • Instagram      │  • Vibe tagging   │  • Vector search    │   │
│  │  • TikTok         │  • Mode scoring   │  • NLP queries      │   │
│  │  • Google Maps    │  • Content QA     │  • Recommendations  │   │
│  └───────────────────┴───────────────────┴─────────────────────┘   │
└─────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────┐
│                           DATA LAYER                                │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                     PRIMARY DATABASES                         │   │
│  ├───────────────────┬───────────────────┬─────────────────────┤   │
│  │  PostgreSQL       │  MongoDB          │  Redis              │   │
│  │  • Venues         │  • Recaps         │  • Sessions         │   │
│  │  • Events         │  • UGC content    │  • Cache            │   │
│  │  • Users          │  • Media refs     │  • Rate limits      │   │
│  │  • Transactions   │  • Scraped data   │  • Mode state       │   │
│  └───────────────────┴───────────────────┴─────────────────────┘   │
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                    SPECIALIZED STORES                         │   │
│  ├───────────────────┬───────────────────┬─────────────────────┤   │
│  │  ElasticSearch    │  Neo4j            │  S3/CloudFront      │   │
│  │  • Full-text      │  • Venue graph    │  • Images           │   │
│  │  • Geo-search     │  • Recommendations│  • Videos           │   │
│  │  • Analytics      │  • Social graph   │  • 3D assets        │   │
│  └───────────────────┴───────────────────┴─────────────────────┘   │
└─────────────────────────────────────────────────────────────────────┘
🗺️ Map Engine & Visualization Layer
Core Philosophy: GTA-Style Visual Categorization
The map uses icon-based differentiation rather than color-coding alone, making it accessible and intuitively scannable.

text
┌─────────────────────────────────────────────────────────────────┐
│                         MAP COMPONENT                            │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                    MODE SELECTOR                         │   │
│  ├─────────────────────────────────────────────────────────┤   │
│  │  [DEGEN] 🕺  [FAMILY] 🧸  [ARTSY] 🎨  [FOODIE] 🍜      │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                    MAP CANVAS                            │   │
│  │                                                          │   │
│  │     🕺(24)          🍸(12)          🌙(8)              │   │
│  │                                                          │   │
│  │            🏛️(5)          🖼️(15)                      │   │
│  │                                                          │   │
│  │     🎨(9)          📦(3)           🧸(7)              │   │
│  │                                                          │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                    FILTER LAYER                          │   │
│  ├─────────────────────────────────────────────────────────┤   │
│  │  [Neon Glow]    [Pastel]    [Monochrome]    [Warm]     │   │
│  └─────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
Technical Implementation
typescript
// Map Configuration
interface MapConfig {
  baseStyle: 'light' | 'dark' | 'satellite' | 'street';
  mode: Mode;
  filters: FilterStack;
  clustering: ClusterConfig;
}

// Mode Definitions
type Mode = 'degen' | 'family' | 'artsy' | 'foodie';

interface ModeConfig {
  degen: {
    iconSet: 'nightlife';
    baseFilter: 'neon';
    markerAnimation: 'pulse';
    venueTypes: ['nightclub', 'bar', 'afterparty', 'speakeasy'];
    clusterStyle: 'energetic';
  };
  family: {
    iconSet: 'family';
    baseFilter: 'pastel';
    markerAnimation: 'gentle';
    venueTypes: ['park', 'museum', 'cafe', 'kid-friendly'];
    clusterStyle: 'soft';
  };
  artsy: {
    iconSet: 'cultural';
    baseFilter: 'monochrome';
    markerAnimation: 'fade';
    venueTypes: ['gallery', 'exhibition', 'studio', 'theater'];
    clusterStyle: 'minimal';
  };
  foodie: {
    iconSet: 'culinary';
    baseFilter: 'warm';
    markerAnimation: 'bounce';
    venueTypes: ['restaurant', 'popup', 'market', 'bakery'];
    clusterStyle: 'appetizing';
  };
}

// Icon Library (SVG)
const iconLibrary = {
  nightlife: {
    nightclub: '🕺',
    bar: '🍸',
    afterparty: '🌙',
    speakeasy: '🥃',
    lounge: '🛋️'
  },
  family: {
    park: '🧸',
    museum: '🏛️',
    cafe: '🍪',
    playground: '🎠',
    library: '📚'
  },
  artsy: {
    gallery: '🖼️',
    exhibition: '📦',
    studio: '🎨',
    theater: '🎭',
    cinema: '🎬'
  },
  culinary: {
    restaurant: '🍽️',
    popup: '📍',
    market: '🛒',
    bakery: '🥖',
    bar: '🍷'
  }
};

// Clustering Logic
function clusterVenues(venues: Venue[], zoomLevel: number, mode: Mode) {
  const clusterRadius = zoomLevel < 14 ? 50 : 20;
  const clusters = new Map();
  
  venues.forEach(venue => {
    const clusterKey = getClusterKey(venue.coordinates, clusterRadius);
    if (!clusters.has(clusterKey)) {
      clusters.set(clusterKey, {
        position: clusterKey.center,
        venues: [],
        icon: getClusterIcon(venue.type, mode)
      });
    }
    clusters.get(clusterKey).venues.push(venue);
  });
  
  return Array.from(clusters.values()).map(cluster => ({
    ...cluster,
    count: cluster.venues.length,
    displayIcon: cluster.count > 5 ? '🔴' : cluster.icon
  }));
}
🏢 Venue Detail & Mode-Persistent Experience
Architecture: Mode Context Propagation
text
┌─────────────────────────────────────────────────────────────────┐
│                    MODE CONTEXT PROVIDER                         │
├─────────────────────────────────────────────────────────────────┤
│  • Current mode (degen/family/artsy/foodie)                     │
│  • Mode history                                                  │
│  • Visual theme                                                  │
│  • Filter preferences                                            │
│  • User's mode affinity                                          │
└─────────────────────────────────────────────────────────────────┘
                              │
            ┌─────────────────┴─────────────────┐
            ▼                                   ▼
┌───────────────────────┐              ┌───────────────────────┐
│     MAP VIEW          │              │    VENUE DETAIL       │
│  • Icons by mode      │              │  • Mode persists      │
│  • Filter by mode     │─────────────▶│  • Recaps filtered    │
│  • Clustering by mode │              │  • Visual theme       │
└───────────────────────┘              └───────────────────────┘
                                                  │
                                                  ▼
                                      ┌───────────────────────┐
                                      │   IMMERSIVE VIEW      │
                                      │  • 3D venue context   │
                                      │  • Mode ambience      │
                                      │  • Floating recaps    │
                                      └───────────────────────┘
Venue Detail Component
jsx
<VenueDetail 
  venueId={venue.id}
  mode={currentMode} // Persisted from map
>
  {/* Mode-aware header */}
  <VenueHeader 
    theme={modeThemes[currentMode]}
    coverImage={venue.coverImage}
    badge={<ModeBadge mode={currentMode} />}
  />
  
  {/* Mode-aware navigation tabs */}
  <ModeTabs mode={currentMode}>
    <Tab label="Upcoming" />
    <Tab label="Past Events" active />
    <Tab label="About" />
  </ModeTabs>
  
  {/* Past events gallery - filtered by mode */}
  <RecapGallery 
    venueId={venue.id}
    mode={currentMode}
    layout={modeLayouts[currentMode]}
    filter={(recap) => recap.modeScore[currentMode] > 0.7}
  >
    {recaps.map(recap => (
      <RecapCard
        key={recap.id}
        recap={recap}
        style={modeCardStyles[currentMode]}
        onClick={() => openImmersiveView(recap)}
      />
    ))}
  </RecapGallery>
</VenueDetail>
Mode-Aware Recap Filtering
javascript
// Backend: Mode-suitable recap query
async function getVenueRecapsByMode(venueId, mode, timeframe = '30d') {
  const query = `
    SELECT r.*, 
           e.title as event_title,
           e.start_time,
           v.name as venue_name,
           v.coordinates,
           (r.mode_scores->>$1) as mode_score,
           r.engagement_score,
           EXTRACT(EPOCH FROM (NOW() - r.captured_at))/86400 as days_old
    FROM recaps r
    JOIN events e ON r.event_id = e.id
    JOIN venues v ON e.venue_id = v.id
    WHERE v.id = $2
      AND e.start_time >= NOW() - INTERVAL '30 days'
      AND (r.mode_scores->>$1)::float > 0.6
    ORDER BY 
      ((r.mode_scores->>$1)::float * 0.6) + 
      (r.engagement_score * 0.3) + 
      (1.0 / (EXTRACT(EPOCH FROM (NOW() - r.captured_at))/86400 + 1) * 0.1) DESC
    LIMIT 50
  `;
  
  return await db.query(query, [mode, venueId]);
}
🎬 Immersive Venue Recap View
The Experience
When a user taps a recap, they enter a full-screen immersive view that:

Preserves the mode (Degen/Family/Artsy)

Creates a 3D venue backdrop (stylized, not photorealistic)

Floats the recap video in context

Shows related recaps from the same venue/event

Plays mode-appropriate ambient audio

text
┌─────────────────────────────────────────────────────────────────┐
│                    IMMERSIVE VENUE VIEW                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                                                          │   │
│  │    3D VENUE BACKDROP (stylized)                         │   │
│  │                                                          │   │
│  │        ┌───────────────────────┐                        │   │
│  │        │                       │                        │   │
│  │        │   FLOATING RECAP      │                        │   │
│  │        │      VIDEO            │                        │   │
│  │        │                       │                        │   │
│  │        │  [PLAYING] 0:42/2:30  │                        │   │
│  │        └───────────────────────┘                        │   │
│  │                                                          │   │
│  │                                                          │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  RELATED RECAPS                        [MODE: DEGEN]   │   │
│  ├─────────────────────────────────────────────────────────┤   │
│  │  ▷ Crowd shot    45 engagements     🕺                 │   │
│  │  ▷ DJ set       128 engagements     🔥                 │   │
│  │  ▷ Bar tenders  23 engagements      🍸                 │   │
│  └─────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
Technical Implementation
jsx
<ImmersiveVenueView
  venue={venue}
  mode={currentMode}
  initialRecap={selectedRecap}
  onClose={() => navigateBack()}
>
  {/* 3D Scene Generator */}
  <VenueScene3D
    venueId={venue.id}
    mode={currentMode}
    style={modeSceneStyles[currentMode]}
  >
    {/* Stylized venue geometry */}
    <VenueGeometry 
      type={venue.category}
      scale="stylized"
      material={modeMaterials[currentMode]}
    />
    
    {/* Ambient particles/effects */}
    {currentMode === 'degen' && <NeonParticles count={100} />}
    {currentMode === 'family' && <FloatingBubbles count={50} />}
    {currentMode === 'artsy' && <CanvasSplatter />}
    
    {/* Lighting by mode */}
    <LightingPreset 
      type={modeLighting[currentMode]}
      intensity={1.2}
      castShadows
    />
  </VenueScene3D>
  
  {/* Floating video player */}
  <FloatingVideoPlayer
    src={selectedRecap.mediaUrl}
    position={[0, 1.5, -2]} // 3D coordinates
    scale={[2, 1.2, 0.1]}
    autoPlay
    controls="minimal"
    onEnd={() => playNextRecap()}
  >
    {/* Caption overlay */}
    <VideoCaption text={selectedRecap.caption} />
  </FloatingVideoPlayer>
  
  {/* Related recaps sidebar */}
  <RelatedRecapsSidebar
    recaps={relatedRecaps}
    mode={currentMode}
    onSelect={(recap) => setSelectedRecap(recap)}
    position="right"
  />
  
  {/* Mode ambient audio */}
  <AmbientAudio 
    src={modeAudio[currentMode]}
    loop
    volume={0.3}
  />
</ImmersiveVenueView>
Scene Generation by Mode
javascript
const modeSceneConfig = {
  degen: {
    geometry: 'abstract-club',
    materials: 'neon-emissive',
    lighting: 'colored-spotlights',
    particles: 'glitter',
    camera: 'dynamic-drunk',
    audio: 'house-techno-ambient'
  },
  family: {
    geometry: 'soft-organic',
    materials: 'pastel-plastic',
    lighting: 'warm-soft',
    particles: 'bubbles',
    camera: 'steady-gentle',
    audio: 'acoustic-ambient'
  },
  artsy: {
    geometry: 'geometric-minimal',
    materials: 'matte-monochrome',
    lighting: 'gallery-spots',
    particles: 'dust-motes',
    camera: 'slow-dolly',
    audio: 'ambient-drone'
  },
  foodie: {
    geometry: 'warm-kitchen',
    materials: 'textured-organic',
    lighting: 'warm-candle',
    particles: 'steam',
    camera: 'table-level',
    audio: 'lounge-jazz'
  }
};
🤖 Scraper & Content Pipeline
Hybrid Approach: 60% Scraped / 35% Submitted / 5% Curated
text
┌─────────────────────────────────────────────────────────────────┐
│                      CONTENT SOURCES                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                    SCRAPED (60%)                         │   │
│  ├─────────────────────────────────────────────────────────┤   │
│  │  • Instagram location pages (HK venues)                 │   │
│  │  • TikTok geotagged videos                              │   │
│  │  • Venue hashtags (#VenueName)                          │   │
│  │  • Event hashtags (#EventName)                          │   │
│  │  • Influencer posts at venues                            │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                   SUBMITTED (35%)                        │   │
│  ├─────────────────────────────────────────────────────────┤   │
│  │  • Google Maps link share → auto-populate               │   │
│  │  • Organizer web form                                    │   │
│  │  • WhatsApp bot (#CULTIVE + link)                       │   │
│  │  • QR check-in uploads                                   │   │
│  │  • Email to events@cultive.hk                           │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                    CURATED (5%)                          │   │
│  ├─────────────────────────────────────────────────────────┤   │
│  │  • Editor's picks                                        │   │
│  │  • Brand partnerships                                    │   │
│  │  • Exclusive previews                                    │   │
│  │  • Hidden gems                                           │   │
│  └─────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                      SCRAPER INFRASTRUCTURE                      │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                   SCHEDULER                              │   │
│  │  • Bull/RabbitMQ job queue                              │   │
│  │  • Priority: #CULTIVEhk > location > venue              │   │
│  │  • Rate limiting per source                              │   │
│  │  • Proxy rotation for Instagram                          │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                   SCRAPER WORKERS                        │   │
│  ├─────────────────────────────────────────────────────────┤   │
│  │  InstagramScraper:                                       │   │
│  │    - Puppeteer/Playwright                               │   │
│  │    - Location: "hong kong"                              │   │
│  │    - Hashtag: #CULTIVEhk (5min)                         │   │
│  │    - Venue accounts (60min)                              │   │
│  │                                                          │   │
│  │  TikTokScraper:                                          │   │
│  │    - Unofficial API                                      │   │
│  │    - Geotag: "Hong Kong" (30min)                        │   │
│  │    - Hashtag: #CULTIVEhk (15min)                         │   │
│  │                                                          │   │
│  │  GoogleMapsParser:                                       │   │
│  │    - Trigger: user submission                            │   │
│  │    - Extract place ID                                    │   │
│  │    - Fetch details + photos                              │   │
│  │    - Create/update venue                                 │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                   PROCESSING PIPELINE                    │   │
│  ├─────────────────────────────────────────────────────────┤   │
│  │  1. Media download & optimization                       │   │
│  │     - Sharp for images                                   │   │
│  │     - FFmpeg for video thumbnails                        │   │
│  │     - Upload to S3 + CloudFront                          │   │
│  │                                                          │   │
│  │  2. Deduplication                                        │   │
│  │     - Perceptual hashing (images)                        │   │
│  │     - URL fingerprinting (videos)                        │   │
│  │     - Caption similarity (NLP)                           │   │
│  │                                                          │   │
│  │  3. AI Classification                                    │   │
│  │     - Spam score (0-1)                                   │   │
│  │     - Quality score (0-1)                                │   │
│  │     - Vibe tags (ML model)                               │   │
│  │     - Mode suitability scoring                           │   │
│  │     - Category assignment                                │   │
│  │                                                          │   │
│  │  4. Routing                                              │   │
│  │     - Score >0.8 → Auto-publish                          │   │
│  │     - Score 0.6-0.8 → Editorial review                   │   │
│  │     - Score <0.6 → Archive (training)                    │   │
│  │     - Spam → Block + flag source                         │   │
│  └─────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
AI Mode Suitability Scoring
javascript
// ML Model: Predict which modes a recap fits
async function calculateModeScores(recap) {
  const features = {
    caption: recap.caption,
    imageAnalysis: await analyzeImage(recap.mediaUrl),
    audioProfile: recap.hasAudio ? await analyzeAudio(recap.mediaUrl) : null,
    venueType: recap.venue.category,
    timeOfDay: recap.capturedAt.getHours(),
    dayOfWeek: recap.capturedAt.getDay(),
    engagement: recap.engagementMetrics
  };
  
  // Mode scoring model (simplified)
  const scores = {
    degen: calculateDegenScore(features),
    family: calculateFamilyScore(features),
    artsy: calculateArtsyScore(features),
    foodie: calculateFoodieScore(features)
  };
  
  // Normalize to 0-1
  return normalizeScores(scores);
}

function calculateDegenScore(features) {
  let score = 0.5; // Base
  
  // Time bias: late night = more degen
  if (features.timeOfDay >= 22 || features.timeOfDay <= 4) {
    score += 0.3;
  }
  
  // Caption keywords
  const degenKeywords = ['party', 'drinks', 'night', 'club', 'dance', 'vibes'];
  degenKeywords.forEach(word => {
    if (features.caption.toLowerCase().includes(word)) score += 0.05;
  });
  
  // Image analysis: dark, neon, crowds
  if (features.imageAnalysis.brightness < 0.3) score += 0.1;
  if (features.imageAnalysis.hasNeon) score += 0.15;
  if (features.imageAnalysis.crowdDensity > 0.7) score += 0.1;
  
  return Math.min(score, 1.0);
}

// Similar functions for family, artsy, foodie...
📱 Mobile App Architecture (React Native)
App Structure
text
cultive-mobile/
├── src/
│   ├── navigation/
│   │   ├── RootNavigator.tsx
│   │   ├── TabNavigator.tsx
│   │   │   ├── MapTab
│   │   │   ├── SearchTab
│   │   │   ├── SavedTab
│   │   │   └── ProfileTab
│   │   └── ModeNavigator.tsx  # Mode-aware routing
│   │
│   ├── screens/
│   │   ├── MapScreen/
│   │   │   ├── MapView.tsx
│   │   │   ├── ModeSelector.tsx
│   │   │   ├── VenueMarkers.tsx
│   │   │   └── VenueCluster.tsx
│   │   │
│   │   ├── VenueScreen/
│   │   │   ├── VenueDetail.tsx
│   │   │   ├── RecapGallery.tsx
│   │   │   ├── ModeToggle.tsx
│   │   │   └── UpcomingEvents.tsx
│   │   │
│   │   ├── ImmersiveScreen/
│   │   │   ├── ImmersiveView.tsx
│   │   │   ├── Scene3D.tsx
│   │   │   ├── FloatingPlayer.tsx
│   │   │   └── RelatedRecaps.tsx
│   │   │
│   │   └── SubmissionScreen/
│   │       ├── GoogleMapsLink.tsx
│   │       ├── PhotoUpload.tsx
│   │       └── AutoFillPreview.tsx
│   │
│   ├── components/
│   │   ├── mode/
│   │   │   ├── ModeContext.tsx
│   │   │   ├── ModeBadge.tsx
│   │   │   └── ModeThemes.ts
│   │   │
│   │   ├── map/
│   │   │   ├── IconLibrary.ts
│   │   │   └── Clustering.ts
│   │   │
│   │   └── recap/
│   │       ├── RecapCard.tsx
│   │       ├── ModeFilter.tsx
│   │       └── EngagementBadge.tsx
│   │
│   ├── services/
│   │   ├── api/
│   │   │   ├── graphql.ts
│   │   │   └── rest.ts
│   │   │
│   │   ├── scraper/
│   │   │   └── clientScanner.ts  # Light client-side detection
│   │   │
│   │   └── storage/
│   │       ├── offlineQueue.ts
│   │       └── savedVenues.ts
│   │
│   └── utils/
│       ├── geo.ts
│       ├── modeHelpers.ts
│       └── analytics.ts
│
├── assets/
│   ├── icons/
│   │   ├── degen/
│   │   ├── family/
│   │   └── artsy/
│   │
│   └── 3d/
│       ├── venue-templates/
│       └── mode-environments/
│
└── package.json
Native Modules Required
json
{
  "dependencies": {
    "react-native-maps": "^1.7.0",
    "react-native-video": "^5.2.1",
    "react-native-qrcode-scanner": "^1.5.5",
    "@react-native-community/geolocation": "^3.0.6",
    "react-native-camera": "^4.2.1",
    "react-native-fs": "^2.20.0",
    "@react-native-community/netinfo": "^9.3.7",
    "react-native-push-notification": "^8.1.1",
    "react-native-three": "^1.0.0",
    "react-native-gesture-handler": "^2.12.0",
    "react-native-reanimated": "^3.3.0"
  }
}
🗄️ Database Schema (Detailed)
PostgreSQL (Relational Data)
sql
-- Venues table
CREATE TABLE venues (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    name_zh TEXT,
    description TEXT,
    description_zh TEXT,
    category VARCHAR(50),
    subcategory VARCHAR(50),
    coordinates GEOGRAPHY(POINT),
    address TEXT,
    address_zh TEXT,
    district VARCHAR(50),
    google_place_id TEXT UNIQUE,
    instagram_handle TEXT,
    tiktok_handle TEXT,
    website TEXT,
    phone TEXT,
    email TEXT,
    opening_hours JSONB,
    price_range INT CHECK (price_range BETWEEN 1 AND 4),
    mode_profiles JSONB, -- {degen: {...}, family: {...}, artsy: {...}}
    vibe_tags TEXT[],
    verified BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Events table
CREATE TABLE events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    venue_id UUID REFERENCES venues(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    title_zh TEXT,
    description TEXT,
    description_zh TEXT,
    start_time TIMESTAMP NOT NULL,
    end_time TIMESTAMP,
    mode_tags TEXT[], -- ['degen', 'family', 'artsy', 'foodie']
    vibe_scores JSONB, -- {degen: 0.9, family: 0.1, artsy: 0.3}
    category VARCHAR(50),
    ticket_url TEXT,
    price DECIMAL(10,2),
    capacity INT,
    status VARCHAR(20) DEFAULT 'upcoming', -- upcoming, ongoing, past, cancelled
    created_by UUID REFERENCES users(id),
    curated BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Recaps table
CREATE TABLE recaps (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    event_id UUID REFERENCES events(id) ON DELETE CASCADE,
    source VARCHAR(20), -- instagram, tiktok, upload, checkin
    source_url TEXT,
    source_id TEXT, -- Original post ID
    media_type VARCHAR(10), -- image, video, carousel
    media_urls TEXT[],
    thumbnail_url TEXT,
    caption TEXT,
    caption_zh TEXT,
    captured_at TIMESTAMP,
    engagement_score FLOAT,
    mode_scores JSONB, -- {degen: 0.95, family: 0.2, artsy: 0.4, foodie: 0.1}
    quality_score FLOAT,
    spam_score FLOAT,
    duplicate_hash TEXT,
    user_id UUID REFERENCES users(id),
    curated BOOLEAN DEFAULT false,
    status VARCHAR(20) DEFAULT 'pending', -- pending, approved, rejected, featured
    created_at TIMESTAMP DEFAULT NOW()
);

-- Users table
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email TEXT UNIQUE,
    phone TEXT UNIQUE,
    name TEXT,
    avatar_url TEXT,
    preferred_mode VARCHAR(20) DEFAULT 'balanced',
    membership_tier VARCHAR(20) DEFAULT 'free', -- free, explorer, culturalist, insider
    membership_expiry TIMESTAMP,
    reputation_score FLOAT DEFAULT 0,
    verified_attendances INT DEFAULT 0,
    recaps_submitted INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT NOW(),
    last_active TIMESTAMP
);

-- Attendance verification
CREATE TABLE attendances (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id),
    event_id UUID REFERENCES events(id),
    check_in_method VARCHAR(20), -- qr, rfid, location, manual
    check_in_time TIMESTAMP DEFAULT NOW(),
    verified BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(user_id, event_id)
);

-- Organizer tiers (for reputation system)
CREATE TABLE organizers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) UNIQUE,
    venue_ids UUID[],
    tier VARCHAR(20) DEFAULT 'newcomer', -- newcomer, regular, established, premier
    event_count INT DEFAULT 0,
    avg_rating FLOAT,
    verified BOOLEAN DEFAULT false,
    joined_at TIMESTAMP DEFAULT NOW()
);

-- Feedback/reviews
CREATE TABLE feedback (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id),
    event_id UUID REFERENCES events(id),
    organizer_rating INT CHECK (organizer_rating BETWEEN 1 AND 5),
    venue_rating INT CHECK (venue_rating BETWEEN 1 AND 5),
    comment TEXT,
    verified_attendance BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT NOW()
);
MongoDB (UGC & Content)
javascript
// Recaps collection (detailed)
const recapSchema = {
  _id: ObjectId,
  eventId: UUID,
  sourceData: {
    platform: String,
    postId: String,
    author: String,
    authorHandle: String,
    authorAvatar: String,
    permalink: String
  },
  media: [{
    url: String,
    type: String,
    width: Number,
    height: Number,
    duration: Number,
    thumbnail: String
  }],
  caption: String,
  captionZh: String,
  hashtags: [String],
  mentions: [String],
  locationData: {
    venueId: UUID,
    venueName: String,
    coordinates: [Number, Number],
    placeId: String
  },
  engagement: {
    likes: Number,
    comments: Number,
    shares: Number,
    views: Number
  },
  aiAnalysis: {
    modeScores: Object,
    vibeTags: [String],
    quality: Number,
    spam: Number,
    nsfw: Boolean,
    topics: [String]
  },
  processedAt: Date,
  publishedAt: Date
};

// User activity feed
const userFeedSchema = {
  _id: ObjectId,
  userId: UUID,
  items: [{
    type: String, // recap, event, venue
    itemId: UUID,
    score: Number,
    reason: String,
    expiresAt: Date
  }],
  lastUpdated: Date
};
Redis Cache
text
# Key patterns
venue:{id}:details
venue:{id}:recaps:{mode}:{page}
user:{id}:session
user:{id}:preferences
map:tiles:{z}:{x}:{y}:{mode}
trending:venues:{mode}:{timeframe}
ElasticSearch Indices
json
{
  "venues": {
    "properties": {
      "name": { "type": "text", "analyzer": "ik_max_word" },
      "name_zh": { "type": "text", "analyzer": "ik_max_word" },
      "description": { "type": "text" },
      "category": { "type": "keyword" },
      "district": { "type": "keyword" },
      "vibe_tags": { "type": "keyword" },
      "location": { "type": "geo_point" }
    }
  },
  "events": {
    "properties": {
      "title": { "type": "text" },
      "start_time": { "type": "date" },
      "mode_tags": { "type": "keyword" },
      "venue_id": { "type": "keyword" }
    }
  }
}
Neo4j Graph (Recommendations)
cypher
// Venue similarity graph
(:Venue)-[:SIMILAR_TO {score: 0.85}]->(:Venue)

// User preference graph
(:User)-[:LIKES {weight: 0.9}]->(:Mode {name: 'degen'})
(:User)-[:VISITED]->(:Venue)
(:User)-[:WATCHED]->(:Recap)

// Social graph
(:User)-[:FOLLOWS]->(:User)
(:User)-[:CURATED_BY]->(:Organizer)
🚀 Deployment & Infrastructure
AWS Architecture
text
┌─────────────────────────────────────────────────────────────────┐
│                        CLOUDFRONT CDN                            │
│                    (Static assets, images, videos)              │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    APPLICATION LOAD BALANCER                     │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                      ECS FARGATE CLUSTER                         │
├─────────────────────────────────────────────────────────────────┤
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │  API Service │  │  Web Service │  │  Scraper     │          │
│  │  (GraphQL)   │  │  (React)     │  │  Service     │          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │  AI Service  │  │  Map Service │  │  Worker      │          │
│  │  (ML)        │  │  (Tile Gen)  │  │  Queue       │          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                         DATA LAYER                               │
├─────────────────────────────────────────────────────────────────┤
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │  RDS Aurora  │  │  ElastiCache │  │  OpenSearch  │          │
│  │  (PostgreSQL)│  │  (Redis)     │  │  (ES)        │          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │  DocumentDB  │  │  Neptune     │  │  S3          │          │
│  │  (MongoDB)   │  │  (Neo4j)     │  │  (Media)     │          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
└─────────────────────────────────────────────────────────────────┘
Scaling Strategy
yaml
# Auto-scaling rules
api-service:
  min: 2
  max: 10
  metric: CPU > 70% for 5min
  
scraper-service:
  min: 1
  max: 5
  metric: Queue length > 1000
  
ai-service:
  min: 1
  max: 3
  metric: GPU utilization > 80%

# Database scaling
postgresql:
  read-replicas: 2 (for map queries)
  sharding: by district
  
mongodb:
  sharding: by date (recaps partitioned monthly)
  
redis:
  cluster-mode: enabled
  replica-count: 2
📊 Performance Requirements
Metric	Target	Measurement
Map load time	< 2s	Lighthouse
Venue page load	< 1.5s	Real user monitoring
Recap gallery filter	< 300ms	API response time
Immersive view load	< 3s	With progress indicator
Scraper processing	< 5min per post	From capture to publish
Concurrent users	10,000	Load test
Uptime	99.9%	Status monitoring
🔐 Security Considerations
yaml
authentication:
  - JWT with refresh tokens
  - OAuth2 (Google, Facebook, Apple)
  - Phone OTP for quick signup

authorization:
  - Role-based: user, organizer, curator, admin
  - Mode-based content access
  - Venue ownership verification

data-protection:
  - Encryption at rest (AES-256)
  - TLS 1.3 in transit
  - PII anonymization for analytics

api-security:
  - Rate limiting per IP/user
  - GraphQL depth limiting
  - SQL injection prevention
  - XSS protection headers

scraper-ethics:
  - Respect robots.txt
  - Rate limiting per source
  - User-agent identification
  - Opt-out mechanism for venues
🧪 Testing Strategy
text
Unit Tests (Jest)
├── Components
├── Services
├── Utils
└── Database queries

Integration Tests
├── API endpoints
├── Scraper pipeline
├── AI model inference
└── Map rendering

E2E Tests (Cypress)
├── User flows (all modes)
├── Venue discovery
├── Recap viewing
└── Submission process

Load Tests (K6)
├── Map tile serving
├── Recap filtering
├── Concurrent users
└── Scraper throughput
📈 Monitoring & Analytics
javascript
// Key metrics to track
const metrics = {
  user: {
    activeDaily: 'count',
    modeDistribution: {degen: 0.4, family: 0.3, artsy: 0.2, foodie: 0.1},
    sessionDuration: 'avg seconds',
    retention: 'D1, D7, D30'
  },
  
  content: {
    recapsPerEvent: 'avg',
    scrapedVsSubmitted: 'ratio 60/35/5',
    modeSuitabilityAccuracy: 'user feedback',
    spamRate: '%'
  },
  
  performance: {
    mapLoadTime: 'p95',
    apiResponseTime: 'p99',
    scraperLag: 'minutes from post to publish'
  },
  
  business: {
    premiumConversion: '%',
    adImpressions: 'count',
    featuredListings: 'count',
    partnerVenues: 'count'
  }
};
✅ Summary: Architecture Alignment
Your Vision	Technical Implementation	Status
GTA-style map (icons, not colors)	SVG icon library + mode filters	✅
Mode persistence map → venue → recap	React Context + URL params	✅
Venue past events filtered by mode	Mode scoring + dynamic queries	✅
Immersive venue view with 3D backdrop	Three.js + React Three Fiber	✅
Floating recap player	Custom video component	✅
Scraper-first (60% automated)	Puppeteer + AI pipeline	✅
Easy submission (Google Maps link)	Place ID parser + auto-fill	✅
Organizer reputation	PostgreSQL tier system	✅
Editorial dashboard	Review queue + approval flows	✅
🚀 Development Roadmap (Updated)
Phase 1: Foundation (Months 1-4)
Basic map with mode toggles (icon-based)

Venue pages with mode persistence

Simple recap grid (filtered by mode)

Instagram scraper (#CULTIVEhk)

Google Maps link parser

50 curated venues

Phase 2: Immersive (Months 5-8)
Mode-specific visual treatments

Venue 3D backdrops (basic)

Floating video player

TikTok integration

QR check-in system

Organizer dashboard v1

Phase 3: Intelligence (Months 9-12)
AI mode suitability scoring

Automated vibe tagging

Related recap suggestions

Ambient audio by mode

Community voting

Ad integration in immersive view

Phase 4: Scale (Months 13-18)
Regional expansion (Macau, Shenzhen)

Event management tools

Predictive recommendations

AR overlay experiments

Series A preparation

This architecture transforms CULTIVE (文化活) from a standard events platform into an immersive, mode-aware cultural discovery engine that feels different for every type of user. The same city, the same venues — but experienced through your chosen lens.