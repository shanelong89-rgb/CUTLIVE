import { useCallback, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, ArrowRight, Layers, ChevronDown, Check } from 'lucide-react';
import { modeConfig } from '../data/mock-data';
import { useMode } from '../context/ModeContext';
import type { UIMode } from '../context/ModeContext';
import { getDesignTokens, modeDesignTokens } from '../data/mode-styles';
import { CIcon } from './CIcon';
import { ImageWithFallback } from './figma/ImageWithFallback';

// ─── Mode card data (matches ModeBoxGrid / MobileModeCards) ───

const MODE_CARDS = [
  {
    key: 'degen' as const,
    label: 'Night',
    labelZh: '夜行者',
    color: '#EDFF00',
    bgDark: '#0A0A0A',
    tagline: 'Nightlife & underground culture',
    image:
      'https://images.unsplash.com/photo-1754837954336-fe727b1134b9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxIb25nJTIwS29uZyUyMG5lb24lMjBuaWdodGxpZmUlMjBkYXJrJTIwc3RyZWV0fGVufDF8fHx8MTc3MzA1NjExNHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    gradient: 'linear-gradient(135deg, #EDFF00 0%, #D600FF 100%)',
  },
  {
    key: 'family' as const,
    label: 'Family',
    labelZh: '親子',
    color: '#FF8C42',
    bgDark: '#3D2510',
    tagline: 'Kid-friendly adventures',
    image:
      'https://images.unsplash.com/photo-1756657266978-c15f15bd3266?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxIb25nJTIwS29uZyUyMGZhbWlseSUyMGNoaWxkcmVuJTIwcGFyayUyMHBsYXlncm91bmR8ZW58MXx8fHwxNzczMDQ1Mzg0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    gradient: 'linear-gradient(135deg, #FF8C42 0%, #FFB347 100%)',
  },
  {
    key: 'artsy' as const,
    label: 'Art & Design',
    labelZh: '藝術',
    color: '#8338EC',
    bgDark: '#1A1030',
    tagline: 'Galleries & exhibitions',
    image:
      'https://images.unsplash.com/photo-1767294274414-5e1e6c3974e9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBhcnQlMjBnYWxsZXJ5JTIwd2hpdGUlMjBleGhpYml0aW9uJTIwc3BhY2V8ZW58MXx8fHwxNzczMDQ1Mzg3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    gradient: 'linear-gradient(135deg, #8338EC 0%, #3d2b7a 100%)',
  },
  {
    key: 'foodie' as const,
    label: 'Food',
    labelZh: '美食',
    color: '#2563EB',
    bgDark: '#0A1628',
    tagline: 'Restaurants & markets',
    image:
      'https://images.unsplash.com/photo-1746105866475-33b40bcc24d1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxIb25nJTIwS29uZyUyMGRpbSUyMHN1bSUyMGZvb2QlMjBtYXJrZXQlMjByZXN0YXVyYW50fGVufDF8fHx8MTc3MzA0NTM4OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    gradient: 'linear-gradient(135deg, #2563EB 0%, #0A1628 100%)',
  },
  {
    key: 'lifestyle' as const,
    label: 'Lifestyle',
    labelZh: '生活',
    color: '#2D6A4F',
    bgDark: '#0A1F15',
    tagline: 'Wellness & community',
    image:
      'https://images.unsplash.com/photo-1760774714285-61ff516f86c5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvdXRkb29yJTIweW9nYSUyMHdlbGxuZXNzJTIwc3VucmlzZSUyMGdyb3VwfGVufDF8fHx8MTc3MzA0NTM5Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    gradient: 'linear-gradient(135deg, #2D6A4F 0%, #40916C 100%)',
  },
];

// ═══════════════════════════════════════════════════════════════
// ModeStackTrigger — compact nav-bar button
// ═══════════════════════════════════════════════════════════════

export function ModeStackTrigger({ onClick }: { onClick: () => void }) {
  const { currentMode } = useMode();
  const tokens = getDesignTokens(currentMode);
  const activeCard = MODE_CARDS.find(c => c.key === currentMode);

  // Mode-adaptive border-radius mirrors the active mode's UI language
  const borderRadius = currentMode === 'degen'
    ? '4px'
    : currentMode === 'foodie'
      ? '24px'
      : currentMode === 'artsy'
        ? '0px'
        : '10px';

  return (
    <button
      onClick={onClick}
      className="flex items-center gap-2 px-3 py-1.5 text-xs transition-all duration-300 cursor-pointer group"
      style={{
        backgroundColor: activeCard ? `${activeCard.color}12` : 'rgba(0,0,0,0.04)',
        border: `1px solid ${activeCard ? `${activeCard.color}25` : 'rgba(0,0,0,0.06)'}`,
        borderRadius,
        color: activeCard ? activeCard.color : tokens.textSecondary,
        fontFamily: tokens.bodyFont,
        fontWeight: currentMode === 'degen' ? 700 : 500,
        textTransform: currentMode === 'degen' ? 'uppercase' : undefined,
        letterSpacing: currentMode === 'degen' ? '0.05em' : currentMode === 'artsy' ? '0.08em' : '-0.01em',
      }}
    >
      <Layers size={14} className="transition-transform duration-300 group-hover:rotate-12" />
      <span className="hidden lg:inline">
        {activeCard ? activeCard.label : 'Modes'}
      </span>
      <ChevronDown
        size={12}
        className="opacity-50 transition-transform duration-300 group-hover:translate-y-0.5"
      />
    </button>
  );
}

// ═══════════════════════════════════════════════════════════════
// ModeCardStack — full-screen overlay with animated cards
// ═══════════════════════════════════════════════════════════════

export function ModeCardStack({
  isOpen,
  onClose,
}: {
  isOpen: boolean;
  onClose: () => void;
}) {
  const { currentMode, setMode } = useMode();

  const handleSelect = useCallback(
    (key: string) => {
      if (currentMode === key) {
        setMode(null); // tap active → deselect
      } else {
        setMode(key as UIMode);
      }
      onClose();
    },
    [currentMode, setMode, onClose],
  );

  // Close on Escape
  useEffect(() => {
    if (!isOpen) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [isOpen, onClose]);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="fixed inset-0 z-[100] flex items-center justify-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25 }}
        >
          {/* ── Backdrop ── */}
          <motion.div
            className="absolute inset-0 backdrop-blur-md"
            style={{ backgroundColor: 'rgba(0,0,0,0.65)' }}
            onClick={onClose}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          />

          {/* ── Content panel ── */}
          <motion.div
            className="relative z-10 w-full max-w-[420px] mx-4"
            initial={{ opacity: 0, y: 50, scale: 0.92 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 50, scale: 0.92 }}
            transition={{ type: 'spring', stiffness: 280, damping: 26 }}
          >
            {/* Header */}
            <div className="flex items-center justify-between mb-4 px-1">
              <div>
                <h2
                  style={{
                    fontFamily: "'Inter', sans-serif",
                    fontSize: '1.15rem',
                    fontWeight: 600,
                    color: '#fff',
                    letterSpacing: '-0.02em',
                  }}
                >
                  Choose your vibe
                </h2>
                <p
                  style={{
                    fontFamily: "'Inter', sans-serif",
                    fontSize: '0.72rem',
                    color: 'rgba(255,255,255,0.4)',
                    marginTop: '2px',
                  }}
                >
                  Each mode transforms the entire experience
                </p>
              </div>
              <button
                onClick={onClose}
                className="flex items-center justify-center w-8 h-8 cursor-pointer transition-all hover:scale-110 hover:bg-white/15"
                style={{
                  backgroundColor: 'rgba(255,255,255,0.08)',
                  borderRadius: '8px',
                }}
              >
                <X size={16} color="#fff" />
              </button>
            </div>

            {/* ── Card list ── */}
            <div className="space-y-2.5">
              {MODE_CARDS.map((card, i) => {
                const config = (modeConfig as any)[card.key];
                const mTokens = (modeDesignTokens as any)[card.key];
                const isActive = currentMode === card.key;

                return (
                  <motion.button
                    key={card.key}
                    className="relative w-full overflow-hidden cursor-pointer group text-left"
                    style={{
                      borderRadius: '16px',
                      height: '76px',
                      border: isActive
                        ? `2px solid ${card.color}`
                        : '2px solid transparent',
                      boxShadow: isActive
                        ? `0 0 24px ${card.color}30, 0 4px 16px rgba(0,0,0,0.3)`
                        : '0 2px 8px rgba(0,0,0,0.2)',
                    }}
                    initial={{ opacity: 0, y: 24 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{
                      delay: i * 0.06,
                      type: 'spring',
                      stiffness: 300,
                      damping: 25,
                    }}
                    whileHover={{ scale: 1.02, y: -2 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => handleSelect(card.key)}
                  >
                    {/* Background image */}
                    <div className="absolute inset-0">
                      <ImageWithFallback
                        src={card.image}
                        alt={card.label}
                        className="h-full w-full object-cover"
                        style={{
                          filter: isActive
                            ? 'brightness(0.5) saturate(1.2)'
                            : 'brightness(0.35) saturate(1.1)',
                        }}
                      />
                      {/* Gradient overlay for legibility */}
                      <div
                        className="absolute inset-0"
                        style={{
                          background:
                            'linear-gradient(to right, rgba(0,0,0,0.6) 0%, rgba(0,0,0,0.15) 100%)',
                        }}
                      />
                      {/* Top accent strip */}
                      <div
                        className="absolute top-0 left-0 right-0 h-[3px]"
                        style={{ background: card.gradient }}
                      />
                    </div>

                    {/* Content row */}
                    <div className="relative h-full flex items-center justify-between px-4">
                      <div className="flex items-center gap-3.5 min-w-0">
                        {/* Mode icon */}
                        <div
                          className="flex-shrink-0 flex items-center justify-center transition-transform duration-300 group-hover:scale-110"
                          style={{
                            width: 42,
                            height: 42,
                            borderRadius: '12px',
                            backgroundColor: `${card.color}20`,
                            border: `1px solid ${card.color}30`,
                          }}
                        >
                          <CIcon
                            id={config?.emoji || card.key}
                            size={18}
                            mode={card.key as any}
                          />
                        </div>

                        {/* Labels */}
                        <div className="min-w-0">
                          <div className="flex items-center gap-2">
                            <h3
                              style={{
                                fontFamily:
                                  mTokens?.headingFont || "'Inter', sans-serif",
                                fontSize: '1rem',
                                fontWeight: 700,
                                color: '#fff',
                                letterSpacing: '-0.01em',
                                lineHeight: 1.2,
                              }}
                            >
                              {card.label}
                            </h3>
                            <span
                              style={{
                                fontSize: '0.6rem',
                                color: `${card.color}80`,
                                fontWeight: 500,
                                letterSpacing: '0.04em',
                              }}
                            >
                              {card.labelZh}
                            </span>
                          </div>
                          <p
                            style={{
                              fontSize: '0.72rem',
                              color: 'rgba(255,255,255,0.45)',
                              fontFamily: "'Inter', sans-serif",
                              marginTop: '2px',
                              lineHeight: 1.3,
                            }}
                          >
                            {card.tagline}
                          </p>
                        </div>
                      </div>

                      {/* Right side — active badge or arrow */}
                      <div className="flex-shrink-0 ml-2">
                        {isActive ? (
                          <motion.div
                            className="flex items-center gap-1 px-2.5 py-1"
                            style={{
                              backgroundColor: card.color,
                              borderRadius: '8px',
                            }}
                            initial={{ scale: 0.8 }}
                            animate={{ scale: 1 }}
                            transition={{
                              type: 'spring',
                              stiffness: 400,
                              damping: 15,
                            }}
                          >
                            <Check
                              size={12}
                              color={card.bgDark}
                              strokeWidth={3}
                            />
                            <span
                              style={{
                                fontSize: '0.55rem',
                                color: card.bgDark,
                                fontWeight: 700,
                                letterSpacing: '0.05em',
                              }}
                            >
                              ON
                            </span>
                          </motion.div>
                        ) : (
                          <ArrowRight
                            size={16}
                            className="opacity-0 group-hover:opacity-100 transition-all duration-200 group-hover:translate-x-0.5"
                            style={{ color: card.color }}
                          />
                        )}
                      </div>
                    </div>

                    {/* Hover glow */}
                    <div
                      className="absolute inset-0 pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                      style={{
                        boxShadow: `inset 0 0 50px ${card.color}10`,
                      }}
                    />
                  </motion.button>
                );
              })}
            </div>

            {/* Reset hint when a mode is active */}
            {currentMode && (
              <motion.p
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.35 }}
                className="text-center mt-4"
                style={{
                  fontSize: '0.7rem',
                  color: 'rgba(255,255,255,0.3)',
                  fontFamily: "'Inter', sans-serif",
                  letterSpacing: '0.02em',
                }}
              >
                Tap the active mode to reset to neutral
              </motion.p>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}