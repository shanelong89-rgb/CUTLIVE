import { useEffect, useState, useCallback } from 'react';
import { useParams } from 'react-router';
import { getContentType } from './contentTypes';
import type { FieldDef } from './contentTypes';
import {
  listContent, createContent, updateContent, deleteContent,
  seedContent, uploadFile, translateText, translateBatch
} from '@/app/hooks/useAdminApi';
import {
  staticTeam, staticAdvisors, staticPartners,
  staticMetrics, staticVentures, staticCatalysts
} from '@/app/data/cms';
import {
  Plus, Search, Trash2, Save, X, Upload, Database,
  ChevronDown, AlertCircle, Check, Loader2, Eye, EyeOff,
  LayoutGrid, List, Languages, Sparkles, Maximize2
} from 'lucide-react';
import { ContentPreview, ItemThumbnail, StageBadge } from './ContentPreview';

const staticFallbackMap: Record<string, any[]> = {
  team: staticTeam,
  advisor: staticAdvisors,
  partner: staticPartners,
  metric: staticMetrics,
  venture: staticVentures,
  catalyst: staticCatalysts,
};

// Generate a URL-safe slug from a string
function generateSlug(text: string): string {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, '')   // remove non-word chars (except spaces & hyphens)
    .replace(/[\s_]+/g, '-')     // spaces/underscores → hyphens
    .replace(/-+/g, '-')         // collapse multiple hyphens
    .replace(/^-+|-+$/g, '');    // trim leading/trailing hyphens
}

// Ensure slug is unique among existing items
function ensureUniqueSlug(slug: string, existingItems: any[]): string {
  const existingIds = new Set(existingItems.map(i => i.id));
  if (!existingIds.has(slug)) return slug;
  let counter = 2;
  while (existingIds.has(`${slug}-${counter}`)) counter++;
  return `${slug}-${counter}`;
}

export function ContentManager() {
  const { type } = useParams<{ type: string }>();
  const ct = type ? getContentType(type) : undefined;

  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [editingItem, setEditingItem] = useState<any | null>(null);
  const [isNew, setIsNew] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [showPreview, setShowPreview] = useState(true);
  const [viewMode, setViewMode] = useState<'list' | 'grid'>('grid');

  const fetchItems = useCallback(async () => {
    if (!type) return;
    setLoading(true);
    try {
      const result = await listContent(type);
      setItems(result.items || []);
    } catch (err: any) {
      console.error('Error loading items:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [type]);

  useEffect(() => {
    fetchItems();
    setEditingItem(null);
    setSearch('');
    setError('');
    setSuccess('');
  }, [type, fetchItems]);

  if (!ct) {
    return <div className="text-gray-500">Content type not found.</div>;
  }

  const filtered = items.filter((item) => {
    if (!search) return true;
    const s = search.toLowerCase();
    return Object.values(item).some(
      (v) => typeof v === 'string' && v.toLowerCase().includes(s)
    );
  });

  const handleNew = () => {
    setEditingItem({ ...ct.defaultValues });
    setIsNew(true);
    setError('');
    setSuccess('');
  };

  const handleEdit = (item: any) => {
    setEditingItem({ ...item });
    setIsNew(false);
    setError('');
    setSuccess('');
  };

  const handleSave = async () => {
    if (!editingItem || !type) return;
    setSaving(true);
    setError('');
    try {
      if (isNew) {
        // Auto-generate ID slug from the title field
        const titleValue = editingItem[ct.titleField];
        if (!titleValue?.trim()) {
          setError(`Please fill in the ${ct.fields.find(f => f.key === ct.titleField)?.label || ct.titleField} field`);
          setSaving(false);
          return;
        }
        const slug = generateSlug(titleValue);
        if (!slug) {
          setError('Could not generate a valid ID from the name. Please use alphanumeric characters.');
          setSaving(false);
          return;
        }
        const uniqueSlug = ensureUniqueSlug(slug, items);
        const itemToSave = { ...editingItem, id: uniqueSlug };
        await createContent(type, itemToSave);
        setSuccess(`Created successfully (ID: ${uniqueSlug})`);
      } else {
        await updateContent(type, editingItem.id, editingItem);
        setSuccess('Updated successfully');
      }
      await fetchItems();
      setEditingItem(null);
      setIsNew(false);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!type) return;
    try {
      await deleteContent(type, id);
      setSuccess('Deleted successfully');
      setDeleteConfirm(null);
      await fetchItems();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleSeed = async () => {
    if (!type) return;
    const staticData = staticFallbackMap[type];
    if (!staticData) {
      setError('No static data available for this type');
      return;
    }
    setSaving(true);
    try {
      await seedContent(type, staticData);
      setSuccess(`Seeded ${staticData.length} items from static data`);
      await fetchItems();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleFileUpload = async (field: string, file: File) => {
    try {
      const url = await uploadFile(file);
      setEditingItem((prev: any) => ({ ...prev, [field]: url }));
    } catch (err: any) {
      setError(`Upload failed: ${err.message}`);
    }
  };

  // Check if this content type supports visual grid view
  const supportsGrid = ['team', 'advisor', 'partner', 'venture', 'metric', 'catalyst'].includes(ct.key);

  // ── Translation helpers ──────────────────────────────────────────────
  // Detect translatable field pairs: fields ending in Zh have a source field without the Zh suffix
  const [translating, setTranslating] = useState<Record<string, boolean>>({});
  const [translatingAll, setTranslatingAll] = useState(false);

  const getSourceFieldKey = (zhFieldKey: string): string | null => {
    if (!zhFieldKey.endsWith('Zh')) return null;
    const sourceKey = zhFieldKey.slice(0, -2);
    const exists = ct.fields.some(f => f.key === sourceKey);
    return exists ? sourceKey : null;
  };

  const translatableFields = ct.fields.filter(f => getSourceFieldKey(f.key) !== null);
  const hasTranslatableFields = translatableFields.length > 0;

  const handleTranslateField = async (zhFieldKey: string) => {
    if (!editingItem) return;
    const sourceKey = getSourceFieldKey(zhFieldKey);
    if (!sourceKey) return;
    const sourceText = editingItem[sourceKey];
    if (!sourceText?.trim()) return;

    setTranslating(prev => ({ ...prev, [zhFieldKey]: true }));
    try {
      const result = await translateText(sourceText, 'en', 'zh', sourceKey);
      setEditingItem((prev: any) => ({ ...prev, [zhFieldKey]: result.translation }));
    } catch (err: any) {
      setError(`Translation failed for ${zhFieldKey}: ${err.message}`);
    } finally {
      setTranslating(prev => ({ ...prev, [zhFieldKey]: false }));
    }
  };

  const handleTranslateAll = async () => {
    if (!editingItem || !type) return;
    // Collect all Zh fields whose source has content and target is empty
    const fieldsToTranslate = translatableFields
      .map(f => {
        const sourceKey = getSourceFieldKey(f.key)!;
        return { key: f.key, sourceKey, sourceValue: editingItem[sourceKey] };
      })
      .filter(f => f.sourceValue?.trim() && !editingItem[f.key]?.trim());

    if (fieldsToTranslate.length === 0) {
      setSuccess('All Chinese fields already have content');
      setTimeout(() => setSuccess(''), 2000);
      return;
    }

    setTranslatingAll(true);
    const markTranslating: Record<string, boolean> = {};
    fieldsToTranslate.forEach(f => { markTranslating[f.key] = true; });
    setTranslating(markTranslating);

    try {
      const batchFields = fieldsToTranslate.map(f => ({
        key: f.sourceKey,
        value: f.sourceValue,
      }));
      const result = await translateBatch(batchFields, 'en', 'zh', ct.label);
      const updates: Record<string, string> = {};
      fieldsToTranslate.forEach(f => {
        const translation = result.translations[f.sourceKey];
        if (translation) updates[f.key] = translation;
      });
      setEditingItem((prev: any) => ({ ...prev, ...updates }));
      setSuccess(`Translated ${Object.keys(updates).length} field${Object.keys(updates).length > 1 ? 's' : ''} to Chinese`);
      setTimeout(() => setSuccess(''), 3000);
    } catch (err: any) {
      setError(`Batch translation failed: ${err.message}`);
    } finally {
      setTranslating({});
      setTranslatingAll(false);
    }
  };

  return (
    <div className="max-w-7xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">{ct.labelPlural}</h1>
          <p className="text-gray-500 text-sm">{items.length} items in CMS</p>
        </div>
        <div className="flex items-center gap-2">
          {/* View toggle */}
          {supportsGrid && !editingItem && (
            <div className="flex items-center gap-0.5 bg-gray-100 rounded-lg p-0.5 mr-1">
              <button
                onClick={() => setViewMode('list')}
                className={`p-1.5 rounded-md transition ${viewMode === 'list' ? 'bg-white shadow-sm text-gray-900' : 'text-gray-400 hover:text-gray-600'}`}
                title="List view"
              >
                <List className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setViewMode('grid')}
                className={`p-1.5 rounded-md transition ${viewMode === 'grid' ? 'bg-white shadow-sm text-gray-900' : 'text-gray-400 hover:text-gray-600'}`}
                title="Grid view"
              >
                <LayoutGrid className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
          <button
            onClick={handleSeed}
            disabled={saving}
            className="flex items-center gap-2 px-3 py-2 bg-white border border-gray-300 text-gray-600 rounded-lg text-xs hover:bg-gray-50 transition"
          >
            <Database className="w-3.5 h-3.5" />
            Seed Static Data
          </button>
          <button
            onClick={handleNew}
            className="flex items-center gap-2 px-3 py-2 bg-emerald-600 text-white rounded-lg text-xs hover:bg-emerald-700 transition"
          >
            <Plus className="w-3.5 h-3.5" />
            New {ct.label}
          </button>
        </div>
      </div>

      {/* Status messages */}
      {error && (
        <div className="flex items-center gap-2 bg-red-50 border border-red-200 text-red-700 text-sm rounded-lg p-3 mb-4">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          {error}
          <button onClick={() => setError('')} className="ml-auto text-red-400 hover:text-red-600"><X className="w-4 h-4" /></button>
        </div>
      )}
      {success && (
        <div className="flex items-center gap-2 bg-emerald-50 border border-emerald-200 text-emerald-700 text-sm rounded-lg p-3 mb-4">
          <Check className="w-4 h-4 flex-shrink-0" />
          {success}
          <button onClick={() => setSuccess('')} className="ml-auto text-emerald-400 hover:text-emerald-600"><X className="w-4 h-4" /></button>
        </div>
      )}

      {/* ─── Edit Form + Preview ──────────────────────────────────────────── */}
      {editingItem && (
        <div className="bg-white border border-gray-200 rounded-xl shadow-sm mb-6 overflow-hidden">
          {/* Editor toolbar */}
          <div className="flex items-center justify-between px-5 py-3 bg-gray-50 border-b border-gray-200">
            <h3 className="text-gray-900 font-semibold text-sm">
              {isNew ? `New ${ct.label}` : `Edit: ${editingItem[ct.titleField] || editingItem.id}`}
            </h3>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowPreview(!showPreview)}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium transition ${
                  showPreview
                    ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                    : 'bg-gray-100 text-gray-500 border border-gray-200 hover:text-gray-700'
                }`}
                title={showPreview ? 'Hide preview' : 'Show preview'}
              >
                {showPreview ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                Preview
              </button>
              <button onClick={() => { setEditingItem(null); setIsNew(false); }} className="text-gray-400 hover:text-gray-600">
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Split pane: Form + Preview */}
          <div className={`${showPreview ? 'lg:grid lg:grid-cols-[1fr,380px]' : ''}`}>
            {/* Form fields */}
            <div className="p-5">
              {/* Auto-generated ID notice for new items / read-only ID for existing */}
              {isNew ? (
                <div className="flex items-center gap-2 mb-4 px-3 py-2 bg-blue-50 border border-blue-200 rounded-lg">
                  <AlertCircle className="w-3.5 h-3.5 text-blue-500 flex-shrink-0" />
                  <span className="text-blue-700 text-xs">
                    ID will be auto-generated from <span className="font-semibold">{ct.fields.find(f => f.key === ct.titleField)?.label || ct.titleField}</span> when you save.
                    {editingItem[ct.titleField]?.trim() && (
                      <> Preview: <code className="bg-blue-100 px-1.5 py-0.5 rounded font-mono text-[11px]">{generateSlug(editingItem[ct.titleField])}</code></>
                    )}
                  </span>
                </div>
              ) : editingItem?.id && (
                <div className="flex items-center gap-2 mb-4 px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg">
                  <span className="text-gray-400 text-xs">ID:</span>
                  <code className="text-gray-600 text-xs font-mono bg-gray-100 px-1.5 py-0.5 rounded">{editingItem.id}</code>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {ct.fields.map((field) => {
                  // For logoHeight field on partner type, skip — it's rendered inline with the image field
                  if (field.key === 'logoHeight' && ct.key === 'partner') return null;
                  // Hide ID field — it's auto-generated for new items and shown read-only above for existing
                  if (field.key === 'id') return null;
                  
                  return (
                    <FieldInput
                      key={field.key}
                      field={field}
                      value={editingItem[field.key]}
                      onChange={(v) => setEditingItem((prev: any) => ({ ...prev, [field.key]: v }))}
                      onFileUpload={(file) => handleFileUpload(field.key, file)}
                      disabled={!isNew && field.key === 'id'}
                      onTranslate={getSourceFieldKey(field.key) ? () => handleTranslateField(field.key) : undefined}
                      isTranslating={!!translating[field.key]}
                      sourceValue={getSourceFieldKey(field.key) ? editingItem[getSourceFieldKey(field.key)!] : undefined}
                      // Logo size control for partner logos
                      logoHeight={field.key === 'logoUrl' && ct.key === 'partner' ? (editingItem.logoHeight || 40) : undefined}
                      onLogoHeightChange={field.key === 'logoUrl' && ct.key === 'partner' ? (h: number) => setEditingItem((prev: any) => ({ ...prev, logoHeight: h })) : undefined}
                    />
                  );
                })}
              </div>

              {/* Translation controls */}
              {hasTranslatableFields && (
                <div className="flex items-center gap-2 mt-4">
                  <Languages className="w-4 h-4 text-gray-500" />
                  <button
                    onClick={handleTranslateAll}
                    disabled={translatingAll}
                    className="text-sm text-gray-500 hover:text-gray-700 transition"
                  >
                    {translatingAll ? 'Translating...' : 'Translate All to Chinese'}
                  </button>
                </div>
              )}

              {/* Save bar */}
              <div className="flex items-center gap-3 mt-5 pt-4 border-t border-gray-200">
                <button
                  onClick={handleSave}
                  disabled={saving}
                  className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-lg text-sm hover:bg-emerald-700 disabled:opacity-50 transition"
                >
                  {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                  {saving ? 'Saving...' : 'Save'}
                </button>
                <button
                  onClick={() => { setEditingItem(null); setIsNew(false); }}
                  className="px-4 py-2 text-gray-500 hover:text-gray-700 text-sm transition"
                >
                  Cancel
                </button>
              </div>
            </div>

            {/* Preview panel */}
            {showPreview && (
              <div className="border-t lg:border-t-0 lg:border-l border-gray-200 bg-gradient-to-b from-gray-50 to-gray-100/50 p-5">
                <ContentPreview contentType={ct} data={editingItem} />
              </div>
            )}
          </div>
        </div>
      )}

      {/* Search */}
      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder={`Search ${ct.labelPlural.toLowerCase()}...`}
          className="w-full bg-white border border-gray-300 rounded-lg pl-9 pr-4 py-2 text-gray-900 text-sm placeholder-gray-400 focus:outline-none focus:border-emerald-500 transition"
        />
      </div>

      {/* Items */}
      {loading ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-6 h-6 text-emerald-500 animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-gray-500 text-sm">No items found. Create one or seed from static data.</p>
        </div>
      ) : viewMode === 'grid' && supportsGrid ? (
        /* ─── Grid View ─────────────────────────────────────────────────── */
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {filtered.map((item) => (
            <div
              key={item.id}
              onClick={() => handleEdit(item)}
              className="group cursor-pointer bg-white border border-gray-200 rounded-xl overflow-hidden hover:border-emerald-300 hover:shadow-md transition"
            >
              {/* Visual card top */}
              <GridItemVisual contentType={ct} item={item} />

              {/* Card info */}
              <div className="p-3">
                <div className="flex items-center gap-1.5 mb-0.5">
                  <span className="text-gray-900 text-xs font-semibold truncate flex-1">
                    {item[ct.titleField] || item.id}
                  </span>
                  <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase ${
                    item.status === 'draft'
                      ? 'bg-yellow-100 text-yellow-700'
                      : 'bg-emerald-100 text-emerald-700'
                  }`}>
                    {item.status || 'published'}
                  </span>
                </div>
                {ct.subtitleField && item[ct.subtitleField] && (
                  <p className="text-gray-400 text-[11px] truncate">{item[ct.subtitleField]}</p>
                )}
              </div>

              {/* Hover actions */}
              <div className="px-3 pb-3 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition">
                <button
                  onClick={(e) => { e.stopPropagation(); handleEdit(item); }}
                  className="flex-1 py-1.5 text-center text-emerald-600 text-[11px] font-medium bg-emerald-50 rounded-lg hover:bg-emerald-100 transition"
                >
                  Edit
                </button>
                {deleteConfirm === item.id ? (
                  <div className="flex items-center gap-1">
                    <button
                      onClick={(e) => { e.stopPropagation(); handleDelete(item.id); }}
                      className="px-2 py-1.5 text-[11px] bg-red-600 text-white rounded-lg hover:bg-red-700 transition"
                    >
                      Confirm
                    </button>
                    <button
                      onClick={(e) => { e.stopPropagation(); setDeleteConfirm(null); }}
                      className="p-1 text-gray-400"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={(e) => { e.stopPropagation(); setDeleteConfirm(item.id); }}
                    className="p-1.5 text-gray-300 hover:text-red-500 transition"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* ─── List View (enhanced with thumbnails) ──────────────────────── */
        <div className="space-y-2">
          {filtered.map((item) => (
            <div
              key={item.id}
              className="bg-white border border-gray-200 rounded-lg p-3 flex items-center gap-3 hover:border-gray-300 hover:shadow-sm transition group"
            >
              {/* Thumbnail */}
              <ItemThumbnail contentType={ct} item={item} />

              {/* Info */}
              <div className="flex-1 min-w-0 cursor-pointer" onClick={() => handleEdit(item)}>
                <div className="flex items-center gap-2">
                  <span className="text-gray-900 text-sm font-medium truncate">
                    {item[ct.titleField] || item.id}
                  </span>
                  {ct.key === 'venture' && item.stage && (
                    <StageBadge stage={item.stage} />
                  )}
                  <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold uppercase ${
                    item.status === 'draft'
                      ? 'bg-yellow-100 text-yellow-700'
                      : 'bg-emerald-100 text-emerald-700'
                  }`}>
                    {item.status || 'published'}
                  </span>
                </div>
                {ct.subtitleField && item[ct.subtitleField] && (
                  <p className="text-gray-500 text-xs truncate mt-0.5">{item[ct.subtitleField]}</p>
                )}
              </div>

              {/* Actions */}
              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition">
                <button
                  onClick={() => handleEdit(item)}
                  className="p-1.5 text-gray-400 hover:text-gray-700 rounded transition"
                >
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7" />
                    <path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z" />
                  </svg>
                </button>
                {deleteConfirm === item.id ? (
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleDelete(item.id)}
                      className="px-2 py-1 text-xs bg-red-600 text-white rounded hover:bg-red-700 transition"
                    >
                      Confirm
                    </button>
                    <button
                      onClick={() => setDeleteConfirm(null)}
                      className="p-1 text-gray-400 hover:text-gray-600"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setDeleteConfirm(item.id)}
                    className="p-1.5 text-gray-400 hover:text-red-500 rounded transition"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Grid Item Visual ─────────────────────────────────────────────────────────
// The visual top section of a grid card

function GridItemVisual({
  contentType,
  item,
}: {
  contentType: { key: string };
  item: Record<string, any>;
}) {
  switch (contentType.key) {
    case 'team':
    case 'advisor':
      return (
        <div className="aspect-[4/3] bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center overflow-hidden">
          {item.photoUrl ? (
            <img src={item.photoUrl} alt={item.name} className="w-full h-full object-cover" />
          ) : (
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-emerald-100 to-emerald-200 flex items-center justify-center">
              <span className="text-2xl font-bold text-emerald-600">
                {(item.name || '?')[0]?.toUpperCase()}
              </span>
            </div>
          )}
        </div>
      );

    case 'partner':
      return (
        <div className="aspect-[4/3] bg-white flex items-center justify-center p-6">
          {item.logoUrl ? (
            <img src={item.logoUrl} alt={item.name} className="max-w-full max-h-full object-contain" />
          ) : (
            <span className="text-lg font-bold text-gray-200">LOGO</span>
          )}
        </div>
      );

    case 'catalyst':
      return (
        <div className="aspect-[4/3] bg-white flex items-center justify-center p-6">
          {item.logo ? (
            <img src={item.logo} alt={item.name} className="max-w-full max-h-full object-contain" />
          ) : (
            <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-purple-100 to-purple-200 flex items-center justify-center">
              <span className="text-2xl font-bold text-purple-600">
                {(item.name || '?')[0]?.toUpperCase()}
              </span>
            </div>
          )}
        </div>
      );

    case 'venture':
      return (
        <div className="aspect-[4/3] bg-gradient-to-br from-[#1a2332] to-[#243347] flex items-center justify-center p-4">
          {item.logo ? (
            <div className="w-16 h-16 rounded-xl bg-white p-2 flex items-center justify-center shadow-lg">
              <img src={item.logo} alt={item.name} className="max-w-full max-h-full object-contain" />
            </div>
          ) : (
            <div className="w-16 h-16 rounded-xl bg-white/10 flex items-center justify-center">
              <span className="text-2xl font-bold text-white/30">
                {(item.name || '?')[0]?.toUpperCase()}
              </span>
            </div>
          )}
        </div>
      );

    case 'metric': {
      const colorMap: Record<string, string> = {
        jade: 'text-emerald-400',
        navy: 'text-slate-200',
        gold: 'text-amber-400',
        pink: 'text-pink-400',
        white: 'text-white/80',
      };
      return (
        <div className="aspect-[4/3] bg-gradient-to-br from-[#1a2332] to-[#243347] flex flex-col items-center justify-center p-4">
          <span className={`text-2xl font-bold ${colorMap[item.color] || 'text-white'}`}>
            {item.prefix}{item.value || 0}{item.suffix}
          </span>
          <span className="text-white/40 text-[10px] font-medium uppercase tracking-wider mt-1 text-center truncate max-w-full px-2">
            {item.label || 'Metric'}
          </span>
        </div>
      );
    }

    default:
      return (
        <div className="aspect-[4/3] bg-gray-50 flex items-center justify-center">
          <span className="text-gray-300 text-sm">Preview</span>
        </div>
      );
  }
}

// ── Field Input Component ────────────────────────────────────────────────────

function FieldInput({
  field,
  value,
  onChange,
  onFileUpload,
  disabled,
  onTranslate,
  isTranslating,
  sourceValue,
  logoHeight,
  onLogoHeightChange,
}: {
  field: FieldDef;
  value: any;
  onChange: (v: any) => void;
  onFileUpload: (file: File) => void;
  disabled?: boolean;
  onTranslate?: () => void;
  isTranslating?: boolean;
  sourceValue?: string;
  logoHeight?: number;
  onLogoHeightChange?: (h: number) => void;
}) {
  const baseClass = "w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2 text-gray-900 text-sm placeholder-gray-400 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition disabled:opacity-50 disabled:bg-gray-100";

  const renderField = () => {
    switch (field.type) {
      case 'textarea':
        return (
          <textarea
            value={value || ''}
            onChange={(e) => onChange(e.target.value)}
            className={`${baseClass} min-h-[80px] resize-y`}
            placeholder={field.placeholder}
            disabled={disabled}
          />
        );

      case 'number':
        return (
          <input
            type="number"
            value={value ?? ''}
            onChange={(e) => onChange(e.target.value ? Number(e.target.value) : 0)}
            className={baseClass}
            placeholder={field.placeholder}
            disabled={disabled}
          />
        );

      case 'select':
        return (
          <div className="relative">
            <select
              value={value || ''}
              onChange={(e) => onChange(e.target.value)}
              className={`${baseClass} appearance-none pr-8`}
              disabled={disabled}
            >
              <option value="">Select...</option>
              {field.options?.map((opt) => (
                <option key={opt.value} value={opt.value}>{opt.label}</option>
              ))}
            </select>
            <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
          </div>
        );

      case 'toggle':
        return (
          <button
            type="button"
            onClick={() => onChange(!value)}
            className={`w-10 h-6 rounded-full transition relative ${
              value ? 'bg-emerald-600' : 'bg-gray-300'
            }`}
            disabled={disabled}
          >
            <div className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-transform shadow-sm ${
              value ? 'translate-x-5' : 'translate-x-1'
            }`} />
          </button>
        );

      case 'image':
        return (
          <div className="space-y-2">
            <input
              type="text"
              value={value || ''}
              onChange={(e) => onChange(e.target.value)}
              className={baseClass}
              placeholder="Image URL"
              disabled={disabled}
            />
            <div className="flex items-center gap-2">
              <label className="flex items-center gap-1.5 px-3 py-1.5 bg-gray-100 text-gray-600 rounded text-xs hover:bg-gray-200 cursor-pointer transition border border-gray-300">
                <Upload className="w-3 h-3" />
                Upload
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) onFileUpload(file);
                  }}
                />
              </label>
              {value && (
                <img src={value} alt="preview" className="h-8 w-8 rounded object-cover border border-gray-200" />
              )}
            </div>
            {/* Logo size slider — only shown when logoHeight prop is provided */}
            {value && logoHeight !== undefined && onLogoHeightChange && (
              <ImageSizeControl
                src={value}
                height={logoHeight}
                onHeightChange={onLogoHeightChange}
              />
            )}
          </div>
        );

      case 'json':
        return (
          <textarea
            value={typeof value === 'string' ? value : JSON.stringify(value || [], null, 2)}
            onChange={(e) => {
              try {
                onChange(JSON.parse(e.target.value));
              } catch {
                onChange(e.target.value);
              }
            }}
            className={`${baseClass} min-h-[60px] font-mono text-xs resize-y`}
            placeholder={field.placeholder || '["item1", "item2"]'}
            disabled={disabled}
          />
        );

      case 'color':
        return (
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={value || ''}
              onChange={(e) => onChange(e.target.value)}
              className={baseClass}
              placeholder={field.placeholder || '#000000'}
              disabled={disabled}
            />
            {value && (
              <div
                className="w-8 h-8 rounded border border-gray-300 flex-shrink-0"
                style={{ backgroundColor: value }}
              />
            )}
          </div>
        );

      default: // text
        return (
          <input
            type="text"
            value={value || ''}
            onChange={(e) => onChange(e.target.value)}
            className={baseClass}
            placeholder={field.placeholder}
            disabled={disabled}
          />
        );
    }
  };

  return (
    <div className={field.type === 'textarea' || field.type === 'json' ? 'md:col-span-2' : ''}>
      <div className="flex items-center justify-between mb-1.5">
        <label className="block text-gray-700 text-xs font-medium">
          {field.label}
          {field.required && <span className="text-red-500 ml-0.5">*</span>}
        </label>
        {onTranslate && (
          <button
            onClick={onTranslate}
            disabled={isTranslating || !sourceValue?.trim()}
            className={`flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-medium transition ${
              isTranslating
                ? 'text-blue-500 bg-blue-50'
                : sourceValue?.trim()
                ? 'text-blue-600 hover:text-blue-700 hover:bg-blue-50 cursor-pointer'
                : 'text-gray-300 cursor-not-allowed'
            }`}
            title={sourceValue?.trim() ? `Auto-translate from English` : 'Fill the English field first'}
          >
            {isTranslating ? (
              <Loader2 className="w-3 h-3 animate-spin" />
            ) : (
              <Sparkles className="w-3 h-3" />
            )}
            {isTranslating ? 'Translating...' : 'AI Translate'}
          </button>
        )}
      </div>
      {renderField()}
      {onTranslate && sourceValue?.trim() && !value?.trim() && (
        <p className="text-gray-400 text-[10px] mt-1 italic">
          EN: {sourceValue.length > 60 ? sourceValue.slice(0, 60) + '...' : sourceValue}
        </p>
      )}
    </div>
  );
}

// ── Image Size Control Component ────────────────────────────────────────────
// Shows uploaded image at the controlled display height, with a slider + dimension readout

function ImageSizeControl({
  src,
  height,
  onHeightChange,
}: {
  src: string;
  height: number;
  onHeightChange: (h: number) => void;
}) {
  const [naturalW, setNaturalW] = useState(0);
  const [naturalH, setNaturalH] = useState(0);

  // Compute aspect-ratio–preserving display width
  const displayH = height || 40;
  const displayW = naturalW && naturalH ? Math.round((displayH / naturalH) * naturalW) : 0;

  return (
    <div className="mt-2 p-3 bg-gray-50 border border-gray-200 rounded-lg space-y-3">
      {/* Dimension info bar */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <Maximize2 className="w-3 h-3 text-gray-400" />
          <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">Display Size</span>
        </div>
        <div className="flex items-center gap-2">
          {naturalW > 0 && (
            <span className="text-[10px] text-gray-400">
              Original: {naturalW} × {naturalH}px
            </span>
          )}
          <span className="text-[10px] font-mono font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">
            {displayW > 0 ? `${displayW} × ${displayH}px` : `h: ${displayH}px`}
          </span>
        </div>
      </div>

      {/* Live preview at controlled size — checkerboard background */}
      <div
        className="relative rounded-lg border border-gray-200 overflow-hidden flex items-center justify-center py-4"
        style={{
          backgroundImage: 'linear-gradient(45deg, #f0f0f0 25%, transparent 25%), linear-gradient(-45deg, #f0f0f0 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #f0f0f0 75%), linear-gradient(-45deg, transparent 75%, #f0f0f0 75%)',
          backgroundSize: '16px 16px',
          backgroundPosition: '0 0, 0 8px, 8px -8px, -8px 0px',
        }}
      >
        <img
          src={src}
          alt="Size preview"
          style={{ height: `${displayH}px`, width: 'auto' }}
          className="object-contain"
          onLoad={(e) => {
            const img = e.target as HTMLImageElement;
            setNaturalW(img.naturalWidth);
            setNaturalH(img.naturalHeight);
          }}
        />
      </div>

      {/* Slider */}
      <div className="space-y-1">
        <div className="flex items-center gap-3">
          <span className="text-[10px] text-gray-400 w-6 text-right">16</span>
          <input
            type="range"
            min={16}
            max={120}
            step={2}
            value={displayH}
            onChange={(e) => onHeightChange(Number(e.target.value))}
            className="flex-1 h-1.5 bg-gray-200 rounded-full appearance-none cursor-pointer accent-emerald-500
              [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-4 [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-emerald-500 [&::-webkit-slider-thumb]:shadow-md [&::-webkit-slider-thumb]:cursor-pointer
              [&::-moz-range-thumb]:w-4 [&::-moz-range-thumb]:h-4 [&::-moz-range-thumb]:rounded-full [&::-moz-range-thumb]:bg-emerald-500 [&::-moz-range-thumb]:border-0 [&::-moz-range-thumb]:shadow-md [&::-moz-range-thumb]:cursor-pointer"
          />
          <span className="text-[10px] text-gray-400 w-8">120</span>
        </div>
        <div className="flex items-center gap-2 justify-center">
          <input
            type="number"
            min={16}
            max={200}
            value={displayH}
            onChange={(e) => onHeightChange(Math.max(16, Math.min(200, Number(e.target.value))))}
            className="w-14 text-center bg-white border border-gray-300 rounded px-1 py-0.5 text-xs text-gray-700 focus:outline-none focus:border-emerald-500"
          />
          <span className="text-[10px] text-gray-400">px height</span>
        </div>
      </div>
    </div>
  );
}