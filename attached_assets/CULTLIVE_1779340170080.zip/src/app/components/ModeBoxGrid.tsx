import { motion } from 'motion/react';
import { ArrowRight } from 'lucide-react';
import { modeConfig } from '../data/mock-data';
import { useMode } from '../context/ModeContext';
import type { UIMode } from '../context/ModeContext';
import { getDesignTokens, modeDesignTokens } from '../data/mode-styles';
import { CIcon } from './CIcon';
import { useCallback } from 'react';

const MODE_BOXES = [
  { key: 'degen' as const, label: 'Night', labelZh: '夜行者', color: '#EDFF00', bgDark: '#0A0A0A' },
  { key: 'family' as const, label: 'Family', labelZh: '親子', color: '#FF8C42', bgDark: '#3D2510' },
  { key: 'artsy' as const, label: 'Art & Design', labelZh: '藝術', color: '#8338EC', bgDark: '#1A1030' },
  { key: 'foodie' as const, label: 'Food', labelZh: '美食', color: '#2563EB', bgDark: '#0A1628' },
  { key: 'lifestyle' as const, label: 'Lifestyle', labelZh: '生活', color: '#2D6A4F', bgDark: '#0A1F15' },
];

export function ModeBoxGrid() {
  const { currentMode, setMode } = useMode();
  const tokens = getDesignTokens(null);

  const handleSelect = useCallback((key: string) => {
    setMode(key as UIMode);
  }, [setMode]);

  return (
    <section className="px-4 sm:px-6 lg:px-8 py-6 sm:py-10 max-w-[1440px] mx-auto">
      <div className="flex items-end justify-between mb-4 sm:mb-5">
        <div>
          <h2
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: 'clamp(1.1rem, 2vw, 1.4rem)',
              color: tokens.textPrimary,
              fontWeight: 600,
              letterSpacing: '-0.02em',
            }}
          >
            Choose your vibe
          </h2>
          <p
            className="mt-1 hidden sm:block"
            style={{ fontSize: '0.8rem', color: tokens.textMuted }}
          >
            Switch modes to transform your experience
          </p>
        </div>
      </div>

      {/* Desktop: 5-column grid */}
      <div className="hidden sm:grid grid-cols-5 gap-3">
        {MODE_BOXES.map((box, i) => {
          const config = (modeConfig as any)[box.key];
          const mTokens = (modeDesignTokens as any)[box.key];

          return (
            <motion.button
              key={box.key}
              className="relative overflow-hidden cursor-pointer group text-left"
              style={{
                borderRadius: '16px',
                backgroundColor: box.bgDark,
                border: `1px solid ${box.color}20`,
              }}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.06, type: 'spring', stiffness: 300, damping: 25 }}
              whileHover={{ scale: 1.03, y: -4 }}
              whileTap={{ scale: 0.97 }}
              onClick={() => handleSelect(box.key)}
            >
              {/* Gradient accent at top */}
              <div
                className="h-[3px] w-full"
                style={{
                  background: `linear-gradient(90deg, ${box.color}, ${box.color}80)`,
                }}
              />

              <div className="p-4 flex flex-col gap-3">
                {/* Icon */}
                <div
                  className="flex items-center justify-center w-10 h-10 transition-transform duration-300 group-hover:scale-110"
                  style={{
                    borderRadius: '12px',
                    backgroundColor: `${box.color}18`,
                    border: `1px solid ${box.color}25`,
                  }}
                >
                  <CIcon id={config.emoji} size={18} mode={box.key as any} />
                </div>

                {/* Label */}
                <div>
                  <h3
                    style={{
                      fontFamily: mTokens.headingFont,
                      fontSize: '1rem',
                      fontWeight: 700,
                      color: '#fff',
                      letterSpacing: '-0.01em',
                      lineHeight: 1.2,
                    }}
                  >
                    {box.label}
                  </h3>
                  <span
                    style={{
                      fontSize: '0.55rem',
                      color: `${box.color}90`,
                      fontWeight: 500,
                      letterSpacing: '0.05em',
                    }}
                  >
                    {box.labelZh}
                  </span>
                </div>

                {/* Arrow hint */}
                <div
                  className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity duration-200"
                >
                  <span
                    style={{
                      fontSize: '0.6rem',
                      color: box.color,
                      fontWeight: 600,
                    }}
                  >
                    Explore
                  </span>
                  <ArrowRight size={10} color={box.color} />
                </div>
              </div>

              {/* Hover glow */}
              <div
                className="absolute inset-0 pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                style={{
                  boxShadow: `inset 0 0 40px ${box.color}10`,
                  borderRadius: '16px',
                }}
              />
            </motion.button>
          );
        })}
      </div>

      {/* Mobile: horizontal scroll */}
      <div className="sm:hidden flex gap-2.5 overflow-x-auto scrollbar-hide pb-1" style={{ WebkitOverflowScrolling: 'touch' }}>
        {MODE_BOXES.map((box, i) => {
          const config = (modeConfig as any)[box.key];
          const mTokens = (modeDesignTokens as any)[box.key];

          return (
            <motion.button
              key={box.key}
              className="relative overflow-hidden cursor-pointer flex-shrink-0 text-left"
              style={{
                borderRadius: '14px',
                backgroundColor: box.bgDark,
                border: `1px solid ${box.color}20`,
                width: '130px',
              }}
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => handleSelect(box.key)}
            >
              <div
                className="h-[2px] w-full"
                style={{
                  background: `linear-gradient(90deg, ${box.color}, ${box.color}80)`,
                }}
              />
              <div className="p-3 flex flex-col gap-2">
                <div
                  className="flex items-center justify-center w-8 h-8"
                  style={{
                    borderRadius: '10px',
                    backgroundColor: `${box.color}18`,
                    border: `1px solid ${box.color}25`,
                  }}
                >
                  <CIcon id={config.emoji} size={14} mode={box.key as any} />
                </div>
                <div>
                  <h3
                    style={{
                      fontFamily: mTokens.headingFont,
                      fontSize: '0.85rem',
                      fontWeight: 700,
                      color: '#fff',
                      letterSpacing: '-0.01em',
                      lineHeight: 1.2,
                    }}
                  >
                    {box.label}
                  </h3>
                  <span
                    style={{
                      fontSize: '0.5rem',
                      color: `${box.color}90`,
                      fontWeight: 500,
                    }}
                  >
                    {box.labelZh}
                  </span>
                </div>
              </div>
            </motion.button>
          );
        })}
      </div>
    </section>
  );
}