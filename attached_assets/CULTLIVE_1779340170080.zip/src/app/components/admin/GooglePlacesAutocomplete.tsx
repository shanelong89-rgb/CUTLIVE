/**
 * GooglePlacesAutocomplete — Google Maps-style address dropdown
 * Uses server-side proxy to keep API key secure.
 * Returns full place details (name, lat, lng, district, address) on selection.
 */
import { useState, useRef, useEffect, useCallback } from 'react';
import { MapPin, Loader2, Search, X, Navigation, Building2, CheckCircle2 } from 'lucide-react';
import { projectId, publicAnonKey } from '../../config/supabase';

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-d507b98c`;

export interface PlaceResult {
  name: string;
  formattedAddress: string;
  lat: number;
  lng: number;
  district: string;
  placeId: string;
}

interface Prediction {
  place_id: string;
  description: string;
  structured_formatting?: {
    main_text: string;
    secondary_text: string;
  };
}

// HK district detection from address components
const HK_DISTRICTS = [
  'Central', 'Wan Chai', 'Causeway Bay', 'Sheung Wan', 'Sai Ying Pun',
  'Kennedy Town', 'Tsim Sha Tsui', 'Mong Kok', 'Sham Shui Po',
  'West Kowloon', 'Wong Chuk Hang', 'Stanley', 'Sha Tin', 'Tai Po',
  'Sai Kung', 'Lantau', 'Aberdeen', 'Happy Valley', 'Mid-Levels',
  'Quarry Bay', 'Tai Koo', 'North Point', 'Fortress Hill', 'Tin Hau',
  'Admiralty', 'Soho', 'LKF', 'Tai Hang', 'Repulse Bay', 'Deep Water Bay',
  'Pok Fu Lam', 'Chai Wan', 'Shau Kei Wan', 'Yau Ma Tei', 'Jordan',
  'Hung Hom', 'To Kwa Wan', 'Kowloon City', 'Kowloon Tong',
  'Diamond Hill', 'Wong Tai Sin', 'Kwun Tong', 'Tseung Kwan O',
  'Tsuen Wan', 'Kwai Chung', 'Tuen Mun', 'Yuen Long', 'Fanling',
];

function detectDistrict(addressComponents: any[], formattedAddress: string): string {
  // Try address components first
  if (addressComponents) {
    for (const comp of addressComponents) {
      const name = comp.long_name || comp.short_name || '';
      for (const d of HK_DISTRICTS) {
        if (name.toLowerCase().includes(d.toLowerCase())) return d;
      }
      // Check for sublocality
      if (comp.types?.includes('sublocality') || comp.types?.includes('neighborhood')) {
        return name;
      }
    }
  }
  // Fallback: check formatted address
  for (const d of HK_DISTRICTS) {
    if (formattedAddress.toLowerCase().includes(d.toLowerCase())) return d;
  }
  return '';
}

const N = {
  surface: '#FFFFFF',
  surfaceMuted: '#F3F3F0',
  border: 'rgba(0,0,0,0.06)',
  borderFocus: 'rgba(0,0,0,0.15)',
  text: '#1A1A1A',
  textSecondary: '#5A5A5A',
  textMuted: '#9A9A9A',
  green: '#16A34A',
  greenBg: 'rgba(22,163,74,0.06)',
  blue: '#2563EB',
  blueBg: 'rgba(37,99,235,0.05)',
  font: "'Inter', 'Noto Sans HK', system-ui, sans-serif",
};

interface Props {
  value?: string; // Current venue name / address display
  onSelect: (place: PlaceResult) => void;
  placeholder?: string;
  compact?: boolean; // For inline use in EventManager
  selectedPlace?: PlaceResult | null; // Currently selected place for display
}

export function GooglePlacesAutocomplete({ value, onSelect, placeholder, compact, selectedPlace }: Props) {
  const [query, setQuery] = useState(value || '');
  const [predictions, setPredictions] = useState<Prediction[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [selecting, setSelecting] = useState(false);
  const [confirmed, setConfirmed] = useState(!!selectedPlace);
  const inputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const debounceRef = useRef<ReturnType<typeof setTimeout>>();

  // Update query when value prop changes
  useEffect(() => {
    if (value && !open) setQuery(value);
  }, [value, open]);

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const searchPlaces = useCallback(async (q: string) => {
    if (q.length < 2) {
      setPredictions([]);
      return;
    }
    setLoading(true);
    try {
      const res = await fetch(
        `${API_BASE}/places/autocomplete?q=${encodeURIComponent(q)}`,
        { headers: { 'Authorization': `Bearer ${publicAnonKey}` } }
      );
      const data = await res.json();
      setPredictions(data.predictions || []);
      if (data.predictions?.length > 0) setOpen(true);
    } catch (err) {
      console.error('Places autocomplete error:', err);
      setPredictions([]);
    }
    setLoading(false);
  }, []);

  const handleInputChange = (val: string) => {
    setQuery(val);
    setConfirmed(false);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => searchPlaces(val), 300);
  };

  const handleSelect = async (prediction: Prediction) => {
    setSelecting(true);
    setOpen(false);
    setQuery(prediction.structured_formatting?.main_text || prediction.description);
    
    try {
      const res = await fetch(
        `${API_BASE}/places/details?place_id=${encodeURIComponent(prediction.place_id)}`,
        { headers: { 'Authorization': `Bearer ${publicAnonKey}` } }
      );
      const data = await res.json();
      
      if (data.lat && data.lng) {
        const district = detectDistrict(data.addressComponents || [], data.formattedAddress || '');
        const result: PlaceResult = {
          name: data.name || prediction.structured_formatting?.main_text || '',
          formattedAddress: data.formattedAddress || prediction.description,
          lat: data.lat,
          lng: data.lng,
          district,
          placeId: prediction.place_id,
        };
        onSelect(result);
        setConfirmed(true);
      }
    } catch (err) {
      console.error('Place details error:', err);
    }
    setSelecting(false);
  };

  const handleClear = () => {
    setQuery('');
    setPredictions([]);
    setConfirmed(false);
    inputRef.current?.focus();
  };

  const inputStyle: React.CSSProperties = compact ? {
    border: `1px solid ${confirmed ? `${N.green}40` : N.border}`,
    borderRadius: '6px',
    color: N.text,
    fontFamily: N.font,
    backgroundColor: confirmed ? N.greenBg : N.surface,
    transition: 'all 0.15s ease',
  } : {
    border: `1.5px solid ${confirmed ? `${N.green}40` : N.border}`,
    borderRadius: '10px',
    color: N.text,
    fontFamily: N.font,
    backgroundColor: confirmed ? N.greenBg : N.surface,
    transition: 'all 0.15s ease',
  };

  return (
    <div ref={containerRef} className="relative">
      {/* Input with icon */}
      <div className="relative">
        <div className="absolute left-0 top-0 bottom-0 flex items-center pl-3 pointer-events-none">
          {selecting ? (
            <Loader2 size={compact ? 13 : 15} className="animate-spin" style={{ color: N.blue }} />
          ) : confirmed ? (
            <CheckCircle2 size={compact ? 13 : 15} style={{ color: N.green }} />
          ) : (
            <Search size={compact ? 13 : 15} style={{ color: N.textMuted }} />
          )}
        </div>
        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={e => handleInputChange(e.target.value)}
          onFocus={() => {
            // If there's a query but no confirmed place, auto-trigger search on focus
            if (query.length >= 2 && !confirmed && predictions.length === 0) {
              searchPlaces(query);
            } else if (predictions.length > 0) {
              setOpen(true);
            }
          }}
          placeholder={placeholder || 'Search address or venue...'}
          className={`w-full ${compact ? 'pl-8 pr-8 py-1.5 text-xs' : 'pl-9 pr-9 py-2.5 text-[13px]'} outline-none`}
          style={inputStyle}
        />
        {query && (
          <button
            onClick={handleClear}
            className="absolute right-0 top-0 bottom-0 flex items-center pr-3 cursor-pointer"
            style={{ color: N.textMuted }}
          >
            <X size={compact ? 12 : 14} />
          </button>
        )}
      </div>

      {/* Loading indicator */}
      {loading && (
        <div className="absolute right-8 top-0 bottom-0 flex items-center">
          <Loader2 size={12} className="animate-spin" style={{ color: N.textMuted }} />
        </div>
      )}

      {/* Dropdown */}
      {open && predictions.length > 0 && (
        <div
          className="absolute z-50 w-full mt-1 overflow-hidden shadow-lg"
          style={{
            backgroundColor: N.surface,
            border: `1.5px solid ${N.border}`,
            borderRadius: compact ? '8px' : '12px',
            boxShadow: '0 8px 30px rgba(0,0,0,0.12)',
            maxHeight: '280px',
            overflowY: 'auto',
          }}
        >
          <div className="px-3 py-1.5" style={{ borderBottom: `1px solid ${N.border}` }}>
            <span className="text-[10px] font-medium uppercase tracking-wider" style={{ color: N.textMuted }}>
              Google Places Results
            </span>
          </div>
          {predictions.map((p) => (
            <button
              key={p.place_id}
              onClick={() => handleSelect(p)}
              className="w-full text-left px-3 py-2.5 flex items-start gap-2.5 transition-colors cursor-pointer hover:bg-gray-50"
              style={{ borderBottom: `1px solid ${N.border}` }}
            >
              <MapPin size={14} className="flex-shrink-0 mt-0.5" style={{ color: N.blue }} />
              <div className="min-w-0 flex-1">
                <p className="text-[13px] font-medium truncate" style={{ color: N.text }}>
                  {p.structured_formatting?.main_text || p.description}
                </p>
                {p.structured_formatting?.secondary_text && (
                  <p className="text-[11px] truncate mt-0.5" style={{ color: N.textMuted }}>
                    {p.structured_formatting.secondary_text}
                  </p>
                )}
              </div>
              <Navigation size={11} className="flex-shrink-0 mt-1 opacity-0 group-hover:opacity-100" style={{ color: N.textMuted }} />
            </button>
          ))}
          <div className="px-3 py-1.5 flex items-center gap-1" style={{ backgroundColor: N.surfaceMuted }}>
            <img src="https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png" alt="Google" className="h-3 opacity-50" />
            <span className="text-[9px]" style={{ color: N.textMuted }}>Powered by Google</span>
          </div>
        </div>
      )}

      {/* Confirmed place info */}
      {confirmed && selectedPlace && (
        <div
          className={`flex items-center gap-2 ${compact ? 'mt-1.5 px-2 py-1.5' : 'mt-2 px-3 py-2'}`}
          style={{
            backgroundColor: N.greenBg,
            border: `1px solid ${N.green}20`,
            borderRadius: compact ? '6px' : '10px',
          }}
        >
          <MapPin size={12} style={{ color: N.green }} />
          <div className="flex-1 min-w-0">
            <p className="text-[11px] font-medium" style={{ color: N.green }}>
              {selectedPlace.lat.toFixed(5)}, {selectedPlace.lng.toFixed(5)}
            </p>
            <p className="text-[10px] truncate" style={{ color: N.textMuted }}>
              {selectedPlace.formattedAddress}
            </p>
          </div>
          {selectedPlace.district && (
            <span
              className="text-[10px] px-1.5 py-0.5 font-medium rounded flex-shrink-0"
              style={{ backgroundColor: `${N.blue}10`, color: N.blue }}
            >
              {selectedPlace.district}
            </span>
          )}
        </div>
      )}
    </div>
  );
}