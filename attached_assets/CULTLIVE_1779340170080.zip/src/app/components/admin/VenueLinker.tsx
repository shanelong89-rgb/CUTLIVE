/**
 * VenueLinker — Link existing venue or create new with duplicate detection
 * Fetches all venues (seed + CMS), provides search, detects duplicates by name/proximity.
 */
import { useState, useEffect, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Search, Link2, MapPin, Building2, AlertTriangle, Check, X,
  Loader2, ChevronDown, ChevronUp, Navigation, Unlink,
} from 'lucide-react';
import { projectId, publicAnonKey } from '../../config/supabase';

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-d507b98c`;

// Design tokens (neutral palette matching admin panels)
const T = {
  surface: '#FFFFFF',
  surfaceMuted: '#F3F3F0',
  border: 'rgba(0,0,0,0.06)',
  text: '#1A1A1A',
  textSecondary: '#5A5A5A',
  textMuted: '#9A9A9A',
  green: '#16A34A',
  greenBg: 'rgba(22,163,74,0.06)',
  amber: '#D97706',
  amberBg: 'rgba(217,119,6,0.06)',
  blue: '#2563EB',
  blueBg: 'rgba(37,99,235,0.05)',
  red: '#DC2626',
  redBg: 'rgba(220,38,38,0.05)',
  font: "'Inter', 'Noto Sans HK', system-ui, sans-serif",
};

export interface VenueRecord {
  id: string;
  name: string;
  district?: string;
  address?: string;
  lat?: number;
  lng?: number;
  category?: string;
  image?: string;
  _source?: string; // 'seed' | 'cms'
}

interface DuplicateMatch {
  venue: VenueRecord;
  reason: string; // e.g. 'name match', '45m away'
  score: number;  // 0-1 relevance
}

// Haversine distance in metres
function haversineMetres(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371000;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

// Normalise name for comparison
function normaliseName(n: string): string {
  return n.toLowerCase().replace(/[''`]/g, "'").replace(/[^a-z0-9\u4e00-\u9fff ]/g, '').trim();
}

// Fuzzy name similarity (Dice coefficient on bigrams)
function nameSimilarity(a: string, b: string): number {
  const na = normaliseName(a);
  const nb = normaliseName(b);
  if (na === nb) return 1;
  if (na.includes(nb) || nb.includes(na)) return 0.85;
  const bigramsA = new Set<string>();
  const bigramsB = new Set<string>();
  for (let i = 0; i < na.length - 1; i++) bigramsA.add(na.slice(i, i + 2));
  for (let i = 0; i < nb.length - 1; i++) bigramsB.add(nb.slice(i, i + 2));
  if (bigramsA.size === 0 || bigramsB.size === 0) return 0;
  let intersection = 0;
  bigramsA.forEach(bg => { if (bigramsB.has(bg)) intersection++; });
  return (2 * intersection) / (bigramsA.size + bigramsB.size);
}

// ─── Shared venue cache ───
let venueCache: VenueRecord[] | null = null;
let venueCacheTimestamp = 0;
const CACHE_TTL = 60_000; // 1 min

async function fetchAllVenues(): Promise<VenueRecord[]> {
  if (venueCache && Date.now() - venueCacheTimestamp < CACHE_TTL) {
    return venueCache;
  }

  const headers = { Authorization: `Bearer ${publicAnonKey}` };

  const [seedRes, cmsRes] = await Promise.all([
    fetch(`${API_BASE}/venues`, { headers }).then(r => r.json()).catch(() => ({ venues: [] })),
    fetch(`${API_BASE}/cms/content/venue/public`, { headers }).then(r => r.json()).catch(() => ({ items: [] })),
  ]);

  const seedVenues: VenueRecord[] = (seedRes.venues || []).map((v: any) => ({
    ...v,
    _source: 'seed',
  }));
  const cmsVenues: VenueRecord[] = (cmsRes.items || []).map((v: any) => ({
    ...v,
    _source: 'cms',
  }));

  // Merge (CMS overrides seed if same ID)
  const byId = new Map<string, VenueRecord>();
  for (const v of seedVenues) byId.set(v.id, v);
  for (const v of cmsVenues) byId.set(v.id, v);
  const merged = Array.from(byId.values());

  venueCache = merged;
  venueCacheTimestamp = Date.now();
  return merged;
}

// Force-refresh cache after venue creation
export function invalidateVenueCache() {
  venueCache = null;
  venueCacheTimestamp = 0;
}

// ─── Find duplicate venues ───
function findDuplicates(
  name: string,
  lat: number | undefined,
  lng: number | undefined,
  venues: VenueRecord[],
  excludeId?: string,
): DuplicateMatch[] {
  const matches: DuplicateMatch[] = [];

  for (const v of venues) {
    if (excludeId && v.id === excludeId) continue;

    let bestReason = '';
    let bestScore = 0;

    // Name similarity
    if (name && v.name) {
      const sim = nameSimilarity(name, v.name);
      if (sim >= 0.6) {
        const pct = Math.round(sim * 100);
        bestReason = sim >= 0.95 ? 'Exact name match' : `Name ${pct}% similar`;
        bestScore = sim;
      }
    }

    // Coordinate proximity
    if (lat && lng && v.lat && v.lng) {
      const dist = haversineMetres(lat, lng, v.lat, v.lng);
      if (dist < 150) {
        const distStr = dist < 1 ? '<1m' : `${Math.round(dist)}m`;
        const proxScore = 1 - (dist / 150); // 1.0 at 0m, 0.0 at 150m
        if (proxScore > bestScore) {
          bestReason = `${distStr} away`;
          bestScore = Math.max(bestScore, proxScore);
        } else if (bestScore > 0) {
          bestReason += ` · ${distStr} away`;
        }
      }
    }

    if (bestScore >= 0.5) {
      matches.push({ venue: v, reason: bestReason, score: bestScore });
    }
  }

  return matches.sort((a, b) => b.score - a.score).slice(0, 5);
}


// ═══════════════════════════════════════════════════════
//  VenueLinker — Embeddable component
// ═══════════════════════════════════════════════════════

interface VenueLinkerProps {
  /** Current venue name (for search pre-fill & duplicate detection) */
  venueName?: string;
  /** Current coordinates (for proximity-based duplicate detection) */
  lat?: number;
  lng?: number;
  /** Currently linked venueId */
  venueId?: string;
  /** Called when user links an existing venue */
  onLink: (venue: VenueRecord) => void;
  /** Called when user unlinks */
  onUnlink: () => void;
  /** Compact mode for inline use (EventManager) */
  compact?: boolean;
}

export function VenueLinker({ venueName, lat, lng, venueId, onLink, onUnlink, compact }: VenueLinkerProps) {
  const [venues, setVenues] = useState<VenueRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearch, setShowSearch] = useState(false);
  const [linkedVenue, setLinkedVenue] = useState<VenueRecord | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Load venues
  useEffect(() => {
    setLoading(true);
    fetchAllVenues()
      .then(v => setVenues(v))
      .catch(err => console.error('Failed to fetch venues for linker:', err))
      .finally(() => setLoading(false));
  }, []);

  // Resolve linked venue from venueId
  useEffect(() => {
    if (venueId && venues.length > 0) {
      const found = venues.find(v => v.id === venueId);
      setLinkedVenue(found || null);
    } else {
      setLinkedVenue(null);
    }
  }, [venueId, venues]);

  // Close search on outside click
  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setShowSearch(false);
      }
    }
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  // Search results
  const searchResults = useMemo(() => {
    if (!searchQuery.trim() && !showSearch) return [];
    const q = searchQuery.toLowerCase().trim();
    let results = venues;
    if (q) {
      results = venues.filter(v =>
        v.name?.toLowerCase().includes(q) ||
        v.district?.toLowerCase().includes(q) ||
        v.address?.toLowerCase().includes(q) ||
        v.id?.toLowerCase().includes(q)
      );
    }
    return results.slice(0, 8);
  }, [venues, searchQuery, showSearch]);

  const handleLink = (venue: VenueRecord) => {
    onLink(venue);
    setShowSearch(false);
    setSearchQuery('');
  };

  const handleUnlink = () => {
    onUnlink();
    setLinkedVenue(null);
  };

  // Currently linked venue display
  if (linkedVenue) {
    return (
      <div
        className={compact ? 'mt-1.5' : 'mt-3'}
        style={{ fontFamily: T.font }}
      >
        <motion.div
          initial={{ opacity: 0, y: -4 }}
          animate={{ opacity: 1, y: 0 }}
          className={`flex items-center gap-2.5 ${compact ? 'px-2.5 py-2' : 'px-3.5 py-3'}`}
          style={{
            backgroundColor: T.greenBg,
            border: `1px solid ${T.green}25`,
            borderRadius: compact ? '8px' : '12px',
          }}
        >
          <div className="flex items-center justify-center flex-shrink-0" style={{
            width: compact ? 22 : 28, height: compact ? 22 : 28,
            backgroundColor: `${T.green}15`, borderRadius: compact ? '5px' : '7px',
          }}>
            <Link2 size={compact ? 10 : 13} style={{ color: T.green }} />
          </div>
          <div className="flex-1 min-w-0">
            <p className={`${compact ? 'text-[11px]' : 'text-[12px]'} font-semibold`} style={{ color: T.green }}>
              Linked to venue
            </p>
            <p className={`${compact ? 'text-[10px]' : 'text-[11px]'} truncate`} style={{ color: T.textSecondary }}>
              {linkedVenue.name}
              {linkedVenue.district && <span style={{ color: T.textMuted }}> · {linkedVenue.district}</span>}
            </p>
            <p className="text-[9px] font-mono" style={{ color: T.textMuted }}>{linkedVenue.id}</p>
          </div>
          <div className="flex items-center gap-1 flex-shrink-0">
            {linkedVenue._source && (
              <span className="text-[9px] font-bold px-1.5 py-0.5 rounded" style={{
                backgroundColor: linkedVenue._source === 'cms' ? '#D1FAE5' : '#FEF3C7',
                color: linkedVenue._source === 'cms' ? '#065F46' : '#92400E',
              }}>
                {linkedVenue._source.toUpperCase()}
              </span>
            )}
            <button
              onClick={handleUnlink}
              className="p-1 rounded cursor-pointer transition-colors hover:bg-red-50"
              title="Unlink venue"
            >
              <Unlink size={compact ? 10 : 12} style={{ color: T.red }} />
            </button>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div ref={containerRef} className={compact ? 'mt-1.5' : 'mt-3'} style={{ fontFamily: T.font }}>
      {/* Section header */}
      <div className="flex items-center justify-between mb-1.5">
        <div className="flex items-center gap-1.5">
          <Link2 size={compact ? 10 : 12} style={{ color: T.blue }} />
          <span className={`${compact ? 'text-[10px]' : 'text-[11px]'} uppercase tracking-wider font-semibold`} style={{ color: T.blue }}>
            Link Existing Venue
          </span>
        </div>
        {loading && <Loader2 size={10} className="animate-spin" style={{ color: T.textMuted }} />}
        {!loading && (
          <span className="text-[10px]" style={{ color: T.textMuted }}>
            {venues.length} venue{venues.length !== 1 ? 's' : ''} available
          </span>
        )}
      </div>

      {/* Search input */}
      <div className="relative">
        <div className="absolute left-0 top-0 bottom-0 flex items-center pl-2.5 pointer-events-none">
          <Search size={compact ? 11 : 13} style={{ color: T.textMuted }} />
        </div>
        <input
          ref={inputRef}
          type="text"
          value={searchQuery}
          onChange={e => { setSearchQuery(e.target.value); setShowSearch(true); }}
          onFocus={() => setShowSearch(true)}
          placeholder="Search venues by name, district, or ID…"
          className={`w-full ${compact ? 'pl-7 pr-7 py-1.5 text-[11px]' : 'pl-8 pr-8 py-2 text-[12px]'} outline-none`}
          style={{
            border: `1px solid ${showSearch ? T.blue + '40' : T.border}`,
            borderRadius: compact ? '6px' : '8px',
            color: T.text,
            fontFamily: T.font,
            backgroundColor: T.surface,
            transition: 'border-color 0.15s ease',
          }}
        />
        {searchQuery && (
          <button
            onClick={() => { setSearchQuery(''); inputRef.current?.focus(); }}
            className="absolute right-0 top-0 bottom-0 flex items-center pr-2.5 cursor-pointer"
          >
            <X size={compact ? 10 : 12} style={{ color: T.textMuted }} />
          </button>
        )}
      </div>

      {/* Search results dropdown */}
      <AnimatePresence>
        {showSearch && (searchResults.length > 0 || searchQuery) && (
          <motion.div
            initial={{ opacity: 0, y: -4, height: 0 }}
            animate={{ opacity: 1, y: 0, height: 'auto' }}
            exit={{ opacity: 0, y: -4, height: 0 }}
            className="mt-1 overflow-hidden"
            style={{
              border: `1.5px solid ${T.border}`,
              borderRadius: compact ? '8px' : '10px',
              backgroundColor: T.surface,
              boxShadow: '0 6px 24px rgba(0,0,0,0.08)',
              maxHeight: '240px',
              overflowY: 'auto',
            }}
          >
            {searchResults.length === 0 ? (
              <div className="px-3 py-4 text-center">
                <p className="text-[11px]" style={{ color: T.textMuted }}>
                  No venues match "{searchQuery}"
                </p>
              </div>
            ) : (
              searchResults.map(v => {
                const hasCoords = typeof v.lat === 'number' && typeof v.lng === 'number';
                return (
                  <button
                    key={v.id}
                    onClick={() => handleLink(v)}
                    className="w-full text-left px-3 py-2.5 flex items-center gap-2.5 transition-colors cursor-pointer hover:bg-gray-50"
                    style={{ borderBottom: `1px solid ${T.border}` }}
                  >
                    <Building2 size={13} className="flex-shrink-0" style={{ color: T.blue }} />
                    <div className="flex-1 min-w-0">
                      <p className="text-[12px] font-medium truncate" style={{ color: T.text }}>
                        {v.name}
                      </p>
                      <p className="text-[10px] truncate" style={{ color: T.textMuted }}>
                        {v.district || 'No district'}
                        {v.address && ` · ${v.address}`}
                      </p>
                    </div>
                    <div className="flex items-center gap-1.5 flex-shrink-0">
                      {hasCoords && (
                        <Navigation size={9} style={{ color: T.green }} />
                      )}
                      {v._source && (
                        <span className="text-[8px] font-bold px-1 py-0.5 rounded" style={{
                          backgroundColor: v._source === 'cms' ? '#D1FAE5' : '#FEF3C7',
                          color: v._source === 'cms' ? '#065F46' : '#92400E',
                        }}>
                          {v._source.toUpperCase()}
                        </span>
                      )}
                      <Link2 size={10} style={{ color: T.blue }} />
                    </div>
                  </button>
                );
              })
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}


// ═══════════════════════════════════════════════════════
//  DuplicateWarning — Shown before venue creation
// ═══════════════════════════════════════════════════════

interface DuplicateWarningProps {
  venueName: string;
  lat?: number;
  lng?: number;
  /** Called when user chooses to link an existing duplicate instead */
  onLinkExisting: (venue: VenueRecord) => void;
  /** Called when user confirms they want to create anyway */
  onCreateAnyway: () => void;
  /** Called to cancel */
  onCancel: () => void;
  compact?: boolean;
}

export function DuplicateWarning({ venueName, lat, lng, onLinkExisting, onCreateAnyway, onCancel, compact }: DuplicateWarningProps) {
  const [duplicates, setDuplicates] = useState<DuplicateMatch[]>([]);
  const [loading, setLoading] = useState(true);
  const [checked, setChecked] = useState(false);
  const onCreateAnywayRef = useRef(onCreateAnyway);
  onCreateAnywayRef.current = onCreateAnyway;

  useEffect(() => {
    setLoading(true);
    fetchAllVenues()
      .then(venues => {
        const matches = findDuplicates(venueName, lat, lng, venues);
        setDuplicates(matches);
        setChecked(true);
      })
      .catch(err => {
        console.error('Duplicate check error:', err);
        setChecked(true);
      })
      .finally(() => setLoading(false));
  }, [venueName, lat, lng]);

  // Auto-proceed if no duplicates found
  useEffect(() => {
    if (checked && !loading && duplicates.length === 0) {
      onCreateAnywayRef.current();
    }
  }, [checked, loading, duplicates.length]);

  if (loading) {
    return (
      <motion.div
        initial={{ opacity: 0, y: -4 }}
        animate={{ opacity: 1, y: 0 }}
        className={`flex items-center gap-2 ${compact ? 'px-2.5 py-2' : 'px-3.5 py-3'}`}
        style={{
          backgroundColor: T.amberBg,
          border: `1px solid ${T.amber}30`,
          borderRadius: compact ? '6px' : '10px',
        }}
      >
        <Loader2 size={14} className="animate-spin" style={{ color: T.amber }} />
        <span className="text-[12px]" style={{ color: T.amber }}>Checking for duplicate venues…</span>
      </motion.div>
    );
  }

  // No duplicates → component auto-proceeds via useEffect (renders nothing briefly)
  if (duplicates.length === 0) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: -8 }}
      animate={{ opacity: 1, y: 0 }}
      className={compact ? 'space-y-2' : 'space-y-3'}
      style={{ fontFamily: T.font }}
    >
      {/* Warning header */}
      <div
        className={`flex items-start gap-2.5 ${compact ? 'px-3 py-2.5' : 'px-4 py-3.5'}`}
        style={{
          backgroundColor: T.amberBg,
          border: `1.5px solid ${T.amber}30`,
          borderRadius: compact ? '8px' : '12px',
        }}
      >
        <AlertTriangle size={compact ? 14 : 16} className="flex-shrink-0 mt-0.5" style={{ color: T.amber }} />
        <div>
          <p className={`${compact ? 'text-[11px]' : 'text-[13px]'} font-semibold`} style={{ color: T.amber }}>
            Possible duplicate{duplicates.length > 1 ? 's' : ''} found
          </p>
          <p className={`${compact ? 'text-[10px]' : 'text-[11px]'} mt-0.5`} style={{ color: T.textSecondary }}>
            {duplicates.length} existing venue{duplicates.length > 1 ? 's match' : ' matches'} "{venueName}".
            You can link one instead of creating a duplicate.
          </p>
        </div>
      </div>

      {/* Duplicate list */}
      <div
        className="overflow-hidden"
        style={{
          border: `1.5px solid ${T.border}`,
          borderRadius: compact ? '8px' : '10px',
          backgroundColor: T.surface,
        }}
      >
        {duplicates.map((d, i) => (
          <button
            key={d.venue.id}
            onClick={() => onLinkExisting(d.venue)}
            className="w-full text-left px-3 py-2.5 flex items-center gap-2.5 transition-colors cursor-pointer hover:bg-gray-50"
            style={{ borderBottom: i < duplicates.length - 1 ? `1px solid ${T.border}` : undefined }}
          >
            <Building2 size={13} className="flex-shrink-0" style={{ color: T.amber }} />
            <div className="flex-1 min-w-0">
              <p className="text-[12px] font-medium truncate" style={{ color: T.text }}>
                {d.venue.name}
              </p>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="text-[10px]" style={{ color: T.textMuted }}>
                  {d.venue.district || 'No district'}
                </span>
                <span className="text-[9px] px-1.5 py-0.5 rounded font-medium" style={{
                  backgroundColor: d.score >= 0.85 ? T.redBg : T.amberBg,
                  color: d.score >= 0.85 ? T.red : T.amber,
                }}>
                  {d.reason}
                </span>
              </div>
              {d.venue.lat && d.venue.lng && (
                <p className="text-[9px] font-mono mt-0.5" style={{ color: T.textMuted }}>
                  {d.venue.lat.toFixed(5)}, {d.venue.lng.toFixed(5)}
                </p>
              )}
            </div>
            <div className="flex items-center gap-1 flex-shrink-0">
              {d.venue._source && (
                <span className="text-[8px] font-bold px-1 py-0.5 rounded" style={{
                  backgroundColor: d.venue._source === 'cms' ? '#D1FAE5' : '#FEF3C7',
                  color: d.venue._source === 'cms' ? '#065F46' : '#92400E',
                }}>
                  {d.venue._source.toUpperCase()}
                </span>
              )}
              <Link2 size={11} style={{ color: T.blue }} />
            </div>
          </button>
        ))}
      </div>

      {/* Action buttons */}
      <div className="flex items-center gap-2">
        <button
          onClick={onCreateAnyway}
          className={`flex items-center gap-1.5 ${compact ? 'px-2.5 py-1.5 text-[10px]' : 'px-3.5 py-2 text-[11px]'} font-medium cursor-pointer transition-all hover:opacity-80`}
          style={{
            backgroundColor: T.text,
            color: '#fff',
            borderRadius: compact ? '6px' : '8px',
          }}
        >
          <Building2 size={compact ? 10 : 12} /> Create anyway
        </button>
        <button
          onClick={onCancel}
          className={`flex items-center gap-1.5 ${compact ? 'px-2.5 py-1.5 text-[10px]' : 'px-3.5 py-2 text-[11px]'} font-medium cursor-pointer transition-all hover:opacity-80`}
          style={{
            backgroundColor: T.surfaceMuted,
            color: T.textSecondary,
            borderRadius: compact ? '6px' : '8px',
            border: `1px solid ${T.border}`,
          }}
        >
          <X size={compact ? 10 : 12} /> Cancel
        </button>
      </div>
    </motion.div>
  );
}