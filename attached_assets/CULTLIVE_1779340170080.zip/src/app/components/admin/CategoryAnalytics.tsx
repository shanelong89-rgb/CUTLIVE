/**
 * CategoryAnalytics — cross-mode submission distribution charts
 * Shows category breakdown, mode distribution, and cross-category overlap.
 */
import { useMemo } from 'react';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell,
  PieChart, Pie, Legend,
} from 'recharts';
import { modeConfig, type Mode } from '../../data/mock-data';
import { resolveCategories, getCategoryLabel, getCategoryColor } from '../CategoryPills';
import { TrendingUp, Layers, Grid3X3 } from 'lucide-react';

const N = {
  surface: '#FFFFFF',
  border: 'rgba(0,0,0,0.06)',
  text: '#1A1A1A',
  textSecondary: '#5A5A5A',
  textMuted: '#9A9A9A',
};

const CATEGORY_MODE_MAP: Record<string, Mode> = {
  'nightlife': 'degen',
  'art': 'artsy',
  'workshops': 'artsy',
  'food': 'foodie',
  'family': 'family',
  'run-clubs': 'lifestyle',
  'wellness': 'lifestyle',
  'hikes': 'lifestyle',
  'coffee-raves': 'lifestyle',
  'meetups': 'lifestyle',
  'other': 'lifestyle',
};

interface Props {
  submissions: any[];
}

export function CategoryAnalytics({ submissions }: Props) {
  const analytics = useMemo(() => {
    // Count per category
    const catCounts: Record<string, number> = {};
    // Count per mode
    const modeCounts: Record<Mode, number> = {
      degen: 0, family: 0, artsy: 0, foodie: 0, lifestyle: 0,
    };
    // Cross-category pairs
    const pairCounts: Record<string, number> = {};
    // Multi-category vs single
    let multiCatCount = 0;
    let singleCatCount = 0;

    submissions.forEach(sub => {
      const cats = resolveCategories(sub);
      if (cats.length === 0) return;

      if (cats.length > 1) multiCatCount++;
      else singleCatCount++;

      const uniqueCats = [...new Set(cats)].filter(c => c && c.trim() !== '');
      uniqueCats.forEach(cat => {
        catCounts[cat] = (catCounts[cat] || 0) + 1;
        const mode = CATEGORY_MODE_MAP[cat] || 'lifestyle';
        modeCounts[mode]++;
      });

      // Count category pairs for overlap analysis
      if (cats.length > 1) {
        const sorted = [...cats].sort();
        for (let i = 0; i < sorted.length; i++) {
          for (let j = i + 1; j < sorted.length; j++) {
            const key = `${sorted[i]}+${sorted[j]}`;
            pairCounts[key] = (pairCounts[key] || 0) + 1;
          }
        }
      }
    });

    // Category bar chart data – filter empty/null keys and dedupe
    const categoryData = Object.entries(catCounts)
      .filter(([cat]) => cat && cat.trim() !== '')
      .map(([cat, count]) => ({
        name: getCategoryLabel(cat),
        category: cat,
        count,
        color: getCategoryColor(cat),
      }))
      .sort((a, b) => b.count - a.count);

    // Mode pie chart data
    const modeData = (Object.entries(modeCounts) as [Mode, number][])
      .filter(([, count]) => count > 0)
      .map(([mode, count]) => ({
        name: modeConfig[mode].label,
        mode,
        value: count,
        color: modeConfig[mode].color,
      }))
      .sort((a, b) => b.value - a.value);

    // Top cross-category pairs
    const topPairs = Object.entries(pairCounts)
      .map(([key, count]) => {
        const [a, b] = key.split('+');
        return { pair: `${getCategoryLabel(a)} × ${getCategoryLabel(b)}`, count, cats: [a, b] };
      })
      .sort((a, b) => b.count - a.count)
      .slice(0, 6);

    return { categoryData, modeData, topPairs, multiCatCount, singleCatCount };
  }, [submissions]);

  const totalTagged = analytics.multiCatCount + analytics.singleCatCount;
  const multiPct = totalTagged > 0 ? Math.round((analytics.multiCatCount / totalTagged) * 100) : 0;

  if (totalTagged === 0) {
    return (
      <div className="p-5" style={{ backgroundColor: N.surface, border: `1px solid ${N.border}`, borderRadius: '16px' }}>
        <p className="text-[11px] font-medium uppercase tracking-wider mb-3" style={{ color: N.textMuted }}>
          Category Analytics
        </p>
        <p className="text-[13px] text-center py-8" style={{ color: N.textMuted }}>
          No categorized submissions yet
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Summary row */}
      <div className="grid grid-cols-3 gap-3">
        <SummaryCard
          icon={<Layers size={14} />}
          label="Categories Used"
          value={analytics.categoryData.length}
          color="#8338EC"
        />
        <SummaryCard
          icon={<Grid3X3 size={14} />}
          label="Multi-Category"
          value={`${multiPct}%`}
          sublabel={`${analytics.multiCatCount} of ${totalTagged}`}
          color="#2563EB"
        />
        <SummaryCard
          icon={<TrendingUp size={14} />}
          label="Top Category"
          value={analytics.categoryData[0]?.name || '—'}
          sublabel={analytics.categoryData[0] ? `${analytics.categoryData[0].count} submissions` : ''}
          color={analytics.categoryData[0]?.color || '#9A9A9A'}
        />
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Category Distribution Bar Chart */}
        <div className="p-5" style={{ backgroundColor: N.surface, border: `1px solid ${N.border}`, borderRadius: '16px' }}>
          <p className="text-[11px] font-medium uppercase tracking-wider mb-4"
            style={{ color: N.textMuted }}>Category Distribution</p>
          <div style={{ height: Math.max(180, analytics.categoryData.length * 32) }}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={analytics.categoryData} layout="vertical" margin={{ left: 8, right: 16, top: 0, bottom: 0 }}>
                <XAxis type="number" tick={{ fontSize: 11, fill: N.textMuted }} axisLine={false} tickLine={false} />
                <YAxis type="category" dataKey="category" width={80}
                  tick={{ fontSize: 11, fill: N.textSecondary }} axisLine={false} tickLine={false}
                  tickFormatter={(cat: string) => getCategoryLabel(cat)} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#fff', border: `1px solid ${N.border}`,
                    borderRadius: '10px', fontSize: '12px', padding: '8px 12px',
                    boxShadow: '0 4px 12px rgba(0,0,0,0.08)',
                  }}
                  formatter={(value: number) => [`${value} submissions`, 'Count']}
                  cursor={{ fill: 'rgba(0,0,0,0.02)' }}
                />
                <Bar dataKey="count" radius={[0, 6, 6, 0]} barSize={20}>
                  {analytics.categoryData.map((entry, i) => (
                    <Cell key={`cat-${i}-${entry.category}`} fill={entry.color} fillOpacity={0.85} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Mode Distribution Pie Chart */}
        <div className="p-5" style={{ backgroundColor: N.surface, border: `1px solid ${N.border}`, borderRadius: '16px' }}>
          <p className="text-[11px] font-medium uppercase tracking-wider mb-4"
            style={{ color: N.textMuted }}>Mode Distribution</p>
          <div style={{ height: 240 }}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={analytics.modeData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={80}
                  paddingAngle={3}
                  dataKey="value"
                  stroke="none"
                >
                  {analytics.modeData.map((entry, i) => (
                    <Cell key={`mode-${i}-${entry.mode}`} fill={entry.color} fillOpacity={0.85} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#fff', border: `1px solid ${N.border}`,
                    borderRadius: '10px', fontSize: '12px', padding: '8px 12px',
                    boxShadow: '0 4px 12px rgba(0,0,0,0.08)',
                  }}
                  formatter={(value: number) => [`${value} tags`, 'Count']}
                />
                <Legend
                  iconType="circle"
                  iconSize={8}
                  formatter={(value: string) => (
                    <span style={{ fontSize: '12px', color: N.textSecondary }}>{value}</span>
                  )}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Cross-category overlap */}
      {analytics.topPairs.length > 0 && (
        <div className="p-5" style={{ backgroundColor: N.surface, border: `1px solid ${N.border}`, borderRadius: '16px' }}>
          <p className="text-[11px] font-medium uppercase tracking-wider mb-4"
            style={{ color: N.textMuted }}>Cross-Category Overlap</p>
          <p className="text-[12px] mb-3" style={{ color: N.textMuted }}>
            Most common category combinations across multi-tagged submissions
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
            {analytics.topPairs.map(({ pair, count, cats }) => (
              <div key={pair}
                className="flex items-center justify-between p-3"
                style={{ backgroundColor: 'rgba(0,0,0,0.015)', borderRadius: '10px' }}>
                <div className="flex items-center gap-2 min-w-0">
                  <div className="flex -space-x-1">
                    {cats.map(c => (
                      <div key={c} className="w-3 h-3 rounded-full border border-white"
                        style={{ backgroundColor: getCategoryColor(c) }} />
                    ))}
                  </div>
                  <span className="text-[12px] font-medium truncate" style={{ color: N.text }}>
                    {pair}
                  </span>
                </div>
                <span className="text-[12px] font-semibold flex-shrink-0 ml-2" style={{ color: N.textSecondary }}>
                  {count}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function SummaryCard({ icon, label, value, sublabel, color }: {
  icon: React.ReactNode; label: string; value: string | number;
  sublabel?: string; color: string;
}) {
  return (
    <div className="p-4" style={{ backgroundColor: N.surface, border: `1px solid ${N.border}`, borderRadius: '16px' }}>
      <div className="w-7 h-7 flex items-center justify-center mb-2.5"
        style={{ backgroundColor: `${color}10`, borderRadius: '8px', color }}>
        {icon}
      </div>
      <p className="text-lg font-semibold" style={{ color: N.text }}>{value}</p>
      <p className="text-[12px] mt-0.5" style={{ color: N.textMuted }}>{label}</p>
      {sublabel && <p className="text-[11px]" style={{ color: N.textMuted }}>{sublabel}</p>}
    </div>
  );
}