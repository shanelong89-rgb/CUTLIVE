import { useTranslation } from 'react-i18next';
import { motion } from 'motion/react';

/**
 * EN | 繁 language toggle — compact pill for nav bar.
 * Persists choice via i18n (backed by localStorage).
 */
export function LanguageToggle({
  navBtnBg,
  textColor,
  activeColor,
  borderRadius = '9999px',
}: {
  navBtnBg: string;
  textColor: string;
  activeColor: string;
  borderRadius?: string;
}) {
  const { i18n } = useTranslation();
  const isZh = i18n.language === 'zh-Hant';

  const toggle = () => {
    i18n.changeLanguage(isZh ? 'en' : 'zh-Hant');
  };

  return (
    <button
      onClick={toggle}
      className="relative flex items-center gap-0 px-0.5 py-0.5 text-[11px] transition-all duration-300 cursor-pointer"
      style={{
        backgroundColor: navBtnBg,
        borderRadius,
        fontFamily: "'Inter', 'Noto Sans HK', system-ui, sans-serif",
      }}
      aria-label={isZh ? 'Switch to English' : '切換至繁體中文'}
      title={isZh ? 'Switch to English' : '切換至繁體中文'}
    >
      <span
        className="relative z-10 px-2 py-1 transition-colors duration-200"
        style={{
          color: !isZh ? activeColor : textColor,
          fontWeight: !isZh ? 600 : 400,
          borderRadius,
        }}
      >
        EN
      </span>
      <span
        className="relative z-10 px-2 py-1 transition-colors duration-200"
        style={{
          color: isZh ? activeColor : textColor,
          fontWeight: isZh ? 600 : 400,
          borderRadius,
        }}
      >
        繁
      </span>
      {/* Sliding active indicator */}
      <motion.div
        className="absolute top-0.5 bottom-0.5"
        style={{
          backgroundColor: `${activeColor}15`,
          border: `1px solid ${activeColor}25`,
          borderRadius,
          width: 'calc(50% - 2px)',
        }}
        animate={{
          left: isZh ? 'calc(50% + 1px)' : '2px',
        }}
        transition={{ type: 'spring', stiffness: 400, damping: 30 }}
      />
    </button>
  );
}
