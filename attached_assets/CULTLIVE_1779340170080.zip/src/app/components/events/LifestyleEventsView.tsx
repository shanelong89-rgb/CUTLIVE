/**
 * LifestyleEventsView — complete lifestyle mode events page
 */
import { useState } from 'react';
import { Link } from 'react-router';
import { useTranslation } from 'react-i18next';
import { motion, AnimatePresence } from 'motion/react';
import { Search, X, MapPin, ArrowRight, Leaf, Users, Mountain, Coffee, BookOpen, Heart, Sparkles, Calendar, Clock, Share2, ExternalLink, History, ChevronRight } from 'lucide-react';
import { ModeSelector } from '../ModeSelector';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { LC, LF, PAPER_TEXTURE_URL, lifestyleCategories, formatLifestyleDate, culturalEventToLifestyle, type LifestyleCategory, type LifestyleEvent } from '../../data/lifestyle-data';
import { formatPrice, getEventLink } from '../../utils/event-helpers';
import { useData } from '../../context/DataContext';
import { computeEventStatus, parseEventDate } from '../../utils/date-helpers';
import { getBilingualField } from '../../utils/bilingual';
import { ShareMenu } from '../ShareMenu';

function getDifficultyColor(d?: string) {
  switch (d) {
    case 'easy': return LC.sage;
    case 'moderate': return '#E8744F';
    case 'challenging': return '#C4653A';
    default: return LC.textMuted;
  }
}

function isLifestyleEventPast(event: LifestyleEvent): boolean {
  const status = computeEventStatus(event.date, (event as any).endDate);
  return status === 'past';
}

const PAST_BADGE_AMBER = '#F59E0B';
function PastBadge({ variant = 'overlay', t }: { variant?: 'overlay' | 'inline'; t?: (key: string) => string }) {
  const label = t || ((k: string) => k === 'lifestyle.past' ? 'Past' : k === 'lifestyle.ended' ? 'Ended' : k);
  if (variant === 'inline') {
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 text-[9px] uppercase tracking-wider font-semibold"
        style={{ color: PAST_BADGE_AMBER, backgroundColor: `${PAST_BADGE_AMBER}18`, borderRadius: '6px', fontFamily: LF.mono }}>
        <History size={9} /> {label('lifestyle.past')}
      </span>
    );
  }
  return (
    <span className="text-[10px] uppercase tracking-wider px-2 py-1 backdrop-blur-xl inline-flex items-center gap-1"
      style={{ color: PAST_BADGE_AMBER, backgroundColor: `${PAST_BADGE_AMBER}20`, borderRadius: '6px', fontFamily: LF.mono, fontWeight: 600 }}>
      <History size={10} /> {label('lifestyle.ended')}
    </span>
  );
}

export function LifestyleEventsView() {
  const { events, allEvents, hidePastEvents } = useData();
  const { t, i18n } = useTranslation();
  const lang = i18n.language;

  // Filter main events tagged with 'lifestyle' modeTag
  const allLifestyleEvents = events
    .filter(e => e.modeTags?.includes('lifestyle'))
    .map(culturalEventToLifestyle);

  const [lifestyleCategoryFilter, setLifestyleCategoryFilter] = useState<LifestyleCategory>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLifestyleEvent, setSelectedLifestyleEvent] = useState<LifestyleEvent | null>(null);

  const categoryIcons: Record<string, typeof Leaf> = {
    'all': Sparkles, 'run-clubs': Users, 'wellness': Leaf, 'hikes': Mountain,
    'coffee-raves': Coffee, 'workshops': BookOpen, 'meetups': Heart,
  };

  const filteredLifestyleEvents = lifestyleCategoryFilter === 'all'
    ? allLifestyleEvents.filter(e => !searchQuery || e.title.toLowerCase().includes(searchQuery.toLowerCase()))
    : allLifestyleEvents.filter(e => e.category === lifestyleCategoryFilter && (!searchQuery || e.title.toLowerCase().includes(searchQuery.toLowerCase())));

  const featuredEvent = filteredLifestyleEvents.find(e => e.featured) || filteredLifestyleEvents[0];
  const remainingEvents = filteredLifestyleEvents.filter(e => e.id !== featuredEvent?.id);

  return (
    <div className="min-h-screen relative" data-nav-theme="dark" style={{ backgroundColor: LC.offWhite }}>
      {/* Paper texture */}
      <div className="fixed inset-0 pointer-events-none z-0" style={{
        backgroundImage: `url("${PAPER_TEXTURE_URL}")`,
        backgroundSize: 'cover', backgroundPosition: 'center',
        opacity: 0.06, mixBlendMode: 'multiply',
      }} />
      <div className="relative z-[1]">

      {/* ═══ Header — cream section ═══ */}
      <div className="relative py-8 sm:py-14 px-4 sm:px-6 lg:px-8" style={{ backgroundColor: LC.offWhite }}>
        <div className="max-w-[1200px] mx-auto">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <div className="flex items-center gap-2 mb-3">
              <Leaf size={14} style={{ color: LC.forest }} />
              <span className="text-[11px] uppercase tracking-[0.2em]" style={{ color: LC.forest, fontFamily: LF.mono, fontWeight: 500 }}>
                {t('lifestyle.header')}
              </span>
            </div>
            <h1 style={{ fontFamily: LF.heading, fontWeight: 900, letterSpacing: '-0.02em', fontSize: 'clamp(1.8rem, 5vw, 3.5rem)', color: LC.black, lineHeight: 1.05 }}>
              {t('lifestyle.heading')} <span style={{ fontStyle: 'italic', fontWeight: 400, color: LC.forest }}>{t('lifestyle.headingAccent')}</span>.
            </h1>
            <p className="max-w-lg text-sm mt-3 hidden sm:block" style={{ color: LC.textMuted, fontFamily: LF.body, lineHeight: 1.7 }}>
              {t('lifestyle.subtitle')}
            </p>
          </motion.div>

          {/* Controls row */}
          <div className="mt-6 sm:mt-8 flex flex-col sm:flex-row gap-3 sm:gap-4 items-start sm:items-center justify-between">
            <ModeSelector compact />
            <div className="relative w-full sm:w-auto">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: LC.textMuted }} />
              <input type="text" placeholder={t('lifestyle.searchPlaceholder')} value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 pr-4 py-2.5 text-sm w-full sm:w-52 focus:outline-none"
                style={{ backgroundColor: 'rgba(45,106,79,0.04)', border: `1.5px solid ${LC.deepForestBorder}`, borderRadius: '12px', color: LC.black, fontFamily: LF.body }}
              />
            </div>
          </div>

          {/* Category pills */}
          <div className="mt-5 flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
            {lifestyleCategories.map((cat) => {
              const Icon = categoryIcons[cat.key] || Sparkles;
              const isActive = lifestyleCategoryFilter === cat.key;
              return (
                <button key={cat.key} onClick={() => setLifestyleCategoryFilter(cat.key)}
                  className="flex items-center gap-1.5 px-4 py-2 text-xs whitespace-nowrap transition-all cursor-pointer flex-shrink-0"
                  style={{ borderRadius: '9999px', backgroundColor: isActive ? LC.forest : 'rgba(45,106,79,0.06)', color: isActive ? LC.white : LC.forest, border: isActive ? 'none' : `1.5px solid ${LC.deepForestBorder}`, fontFamily: LF.body, fontWeight: isActive ? 600 : 400 }}>
                  <Icon size={13} />
                  {t(`categories.${cat.key}`, cat.label)}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* ═══ Featured hero event — editorial full-width ═══ */}
      {featuredEvent && (
        <div className="px-4 sm:px-6 lg:px-8 pb-6 sm:pb-10" style={{ backgroundColor: LC.offWhite }}>
          <div className="max-w-[1200px] mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="group cursor-pointer"
              onClick={() => setSelectedLifestyleEvent(featuredEvent)}
            >
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-0 overflow-hidden" style={{ borderRadius: '24px', border: `1px solid ${LC.deepForestBorder}` }}>
                <div className="lg:col-span-7 relative overflow-hidden aspect-[16/10] lg:aspect-auto lg:min-h-[380px]">
                  <ImageWithFallback src={featuredEvent.image} alt={featuredEvent.title}
                    className="absolute inset-0 h-full w-full object-cover transition-transform duration-1000 group-hover:scale-[1.03]" />
                  <div className="absolute inset-0" style={{ background: 'linear-gradient(135deg, rgba(18,42,32,0.3) 0%, transparent 60%)' }} />
                  <div className="absolute top-4 left-4 flex gap-2">
                    <span className="text-[10px] uppercase tracking-wider px-3 py-1.5 backdrop-blur-xl" style={{ color: LC.white, backgroundColor: 'rgba(45,106,79,0.7)', borderRadius: '10px', fontFamily: LF.mono, fontWeight: 600 }}>{t('lifestyle.featured')}</span>
                    <span className="text-[10px] uppercase tracking-wider px-3 py-1.5 backdrop-blur-xl" style={{ color: LC.sage, backgroundColor: 'rgba(149,213,178,0.15)', borderRadius: '10px', fontFamily: LF.mono, fontWeight: 600 }}>
                      {lifestyleCategories.find(c => c.key === featuredEvent.category)?.boldLabel}
                    </span>
                    {isLifestyleEventPast(featuredEvent) && <PastBadge t={t} />}
                  </div>
                </div>
                <div className="lg:col-span-5 flex flex-col justify-center p-6 sm:p-8 lg:p-10" style={{ backgroundColor: LC.deepForest }}>
                  <div className="flex items-center gap-2 mb-3 text-[11px]" style={{ color: LC.deepForestTextLight, fontFamily: LF.body }}>
                    <Calendar size={12} /> <span>{formatLifestyleDate(featuredEvent.date)}</span>
                    <span>&middot;</span>
                    <Clock size={12} /> <span>{featuredEvent.time}</span>
                  </div>
                  <h2 className="mb-2" style={{ fontFamily: LF.heading, fontWeight: 900, fontSize: 'clamp(1.4rem, 3vw, 2rem)', color: LC.white, lineHeight: 1.1, letterSpacing: '-0.02em' }}>
                    {featuredEvent.title}
                  </h2>
                  <p className="text-sm italic mb-4" style={{ color: LC.sage, fontFamily: LF.body }}>{featuredEvent.subtitle}</p>
                  <p className="text-sm mb-5 hidden sm:block" style={{ color: 'rgba(149,213,178,0.6)', fontFamily: LF.body, lineHeight: 1.7 }}>
                    {featuredEvent.description && featuredEvent.description.length > 200
                      ? featuredEvent.description.slice(0, 200).trimEnd() + '…'
                      : featuredEvent.description}
                  </p>
                  <div className="flex items-center gap-3 mb-5">
                    <div className="flex items-center gap-1.5 text-[11px]" style={{ color: LC.sage, fontFamily: LF.body }}>
                      <MapPin size={11} /> {featuredEvent.location}
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-2 px-4 py-2.5 text-sm transition-all group-hover:opacity-90"
                      style={{ backgroundColor: LC.forest, color: LC.white, borderRadius: '12px', fontFamily: LF.body, fontWeight: 600 }}>
                      <span>{t('lifestyle.viewDetails')}</span> <ArrowRight size={14} />
                    </div>
                    <span className="text-sm font-semibold" style={{ color: formatPrice(featuredEvent.price) === 'Free' ? LC.sage : '#E8744F', fontFamily: LF.mono }}>
                      {formatPrice(featuredEvent.price)}
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      )}

      {/* ═══ Events grid — deep forest section ═══ */}
      <div className="relative" style={{ backgroundColor: LC.deepForest }}>
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16">
          <div className="flex items-center justify-between mb-6 sm:mb-8">
            <div>
              <span className="text-[10px] uppercase tracking-[0.2em] block mb-1" style={{ color: LC.deepForestTextLight, fontFamily: LF.mono }}>
                {lifestyleCategoryFilter === 'all' ? t('lifestyle.allEvents') : t(`categories.${lifestyleCategoryFilter}`, lifestyleCategories.find(c => c.key === lifestyleCategoryFilter)?.label)}
              </span>
              <span className="text-xs" style={{ color: LC.deepForestTextLight, fontFamily: LF.body }}>
                {t('lifestyle.eventCount', { count: remainingEvents.length })}
              </span>
            </div>
          </div>

          {remainingEvents.length === 0 ? (
            <div className="text-center py-16">
              <Leaf size={32} style={{ color: LC.sage }} className="mx-auto mb-4 opacity-50" />
              <p style={{ fontFamily: LF.heading, color: LC.sage, fontSize: '1.2rem', fontWeight: 700 }}>{t('lifestyle.noMoreEvents')}</p>
              <p className="text-sm mt-2" style={{ color: LC.deepForestTextLight, fontFamily: LF.body }}>{t('lifestyle.adjustFilters')}</p>
            </div>
          ) : (
            <AnimatePresence mode="wait">
              <motion.div key={lifestyleCategoryFilter + searchQuery} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -12 }} transition={{ duration: 0.3 }}>
                <div className="space-y-4 sm:space-y-5">
                  {remainingEvents.map((event, i) => {
                    const isWide = i % 3 === 0;
                    if (isWide && remainingEvents[i + 1]) {
                      const nextEvent = remainingEvents[i + 1];
                      return (
                        <div key={event.id} className="grid grid-cols-1 sm:grid-cols-12 gap-4 sm:gap-5">
                          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}
                            onClick={() => setSelectedLifestyleEvent(event)}
                            className="sm:col-span-8 group cursor-pointer overflow-hidden"
                            style={{ borderRadius: '20px', backgroundColor: LC.deepForestCard, border: `1px solid ${LC.deepForestBorder}` }}>
                            <div className="relative aspect-[16/9] overflow-hidden">
                              <ImageWithFallback src={event.image} alt={event.title} className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
                              <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(18,42,32,0.7) 0%, transparent 50%)' }} />
                              <div className="absolute top-3 left-3 flex gap-2">
                                <span className="text-[10px] uppercase tracking-wider px-2 py-1" style={{ color: LC.sage, backgroundColor: 'rgba(149,213,178,0.15)', borderRadius: '6px', fontFamily: LF.mono, fontWeight: 600, backdropFilter: 'blur(8px)' }}>
                                  {lifestyleCategories.find(c => c.key === event.category)?.boldLabel}
                                </span>
                                {event.difficulty && (
                                  <span className="text-[10px] uppercase tracking-wider px-2 py-1" style={{ color: getDifficultyColor(event.difficulty), backgroundColor: `${getDifficultyColor(event.difficulty)}20`, borderRadius: '6px', fontFamily: LF.mono, fontWeight: 600, backdropFilter: 'blur(8px)' }}>
                                    {event.difficulty}
                                  </span>
                                )}
                                {isLifestyleEventPast(event) && <PastBadge t={t} />}
                              </div>
                              <div className="absolute bottom-4 left-4 right-4">
                                <div className="flex items-center gap-2 mb-2 text-[11px]" style={{ color: 'rgba(255,255,255,0.6)', fontFamily: LF.body }}>
                                  <Calendar size={11} /> {formatLifestyleDate(event.date)} &middot; {event.time}
                                </div>
                                <h3 style={{ fontFamily: LF.heading, fontWeight: 900, fontSize: 'clamp(1.1rem, 2.5vw, 1.6rem)', color: LC.white, lineHeight: 1.15 }}>
                                  {event.title}
                                </h3>
                                <p className="text-xs mt-1 hidden sm:block" style={{ color: 'rgba(255,255,255,0.5)', fontFamily: LF.body }}>{event.subtitle}</p>
                              </div>
                            </div>
                            <div className="p-4 sm:p-5 flex items-center justify-between">
                              <div className="flex items-center gap-3">
                                <div className="flex items-center gap-1.5 text-[11px]" style={{ color: LC.sage, fontFamily: LF.body }}><MapPin size={10} />{event.district}</div>
                                <div className="flex items-center gap-1.5 text-[11px]" style={{ color: LC.deepForestTextLight, fontFamily: LF.body }}><Users size={10} />{event.spotsLeft} spots left</div>
                              </div>
                              <span className="text-xs font-semibold" style={{ color: formatPrice(event.price) === 'Free' ? LC.sage : '#E8744F', fontFamily: LF.mono }}>{formatPrice(event.price)}</span>
                            </div>
                          </motion.div>
                          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: (i + 1) * 0.04 }}
                            onClick={() => setSelectedLifestyleEvent(nextEvent)}
                            className="sm:col-span-4 group cursor-pointer overflow-hidden flex flex-col"
                            style={{ borderRadius: '20px', backgroundColor: LC.deepForestCard, border: `1px solid ${LC.deepForestBorder}` }}>
                            <div className="relative aspect-[4/3] sm:aspect-[3/2] overflow-hidden">
                              <ImageWithFallback src={nextEvent.image} alt={nextEvent.title} className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
                              <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(18,42,32,0.6) 0%, transparent 50%)' }} />
                              <div className="absolute top-3 left-3">
                                <span className="text-[10px] uppercase tracking-wider px-2 py-1" style={{ color: LC.sage, backgroundColor: 'rgba(149,213,178,0.15)', borderRadius: '6px', fontFamily: LF.mono, fontWeight: 600, backdropFilter: 'blur(8px)' }}>
                                  {lifestyleCategories.find(c => c.key === nextEvent.category)?.boldLabel}
                                </span>
                                {isLifestyleEventPast(nextEvent) && <PastBadge t={t} />}
                              </div>
                            </div>
                            <div className="p-4 flex-1 flex flex-col">
                              <div className="flex items-center gap-2 mb-1.5 text-[10px]" style={{ color: LC.deepForestTextLight, fontFamily: LF.body }}>
                                <span>{formatLifestyleDate(nextEvent.date)}</span><span>&middot;</span><span>{nextEvent.time}</span>
                              </div>
                              <h3 className="mb-1 line-clamp-2 group-hover:opacity-70 transition-opacity" style={{ fontFamily: LF.heading, fontWeight: 800, fontSize: '0.95rem', color: LC.white, lineHeight: 1.2 }}>
                                {nextEvent.title}
                              </h3>
                              <p className="text-xs line-clamp-1 mb-auto hidden sm:block" style={{ color: LC.deepForestTextLight, fontFamily: LF.body, fontStyle: 'italic' }}>{nextEvent.subtitle}</p>
                              <div className="flex items-center justify-between mt-3 pt-3" style={{ borderTop: `1px solid ${LC.deepForestBorder}` }}>
                                <div className="flex items-center gap-1.5 text-[10px]" style={{ color: LC.sage, fontFamily: LF.body }}><MapPin size={10} />{nextEvent.district}</div>
                                <span className="text-[11px] font-semibold" style={{ color: formatPrice(nextEvent.price) === 'Free' ? LC.sage : '#E8744F', fontFamily: LF.mono }}>{formatPrice(nextEvent.price)}</span>
                              </div>
                            </div>
                          </motion.div>
                        </div>
                      );
                    } else if (i % 3 === 1) {
                      return null;
                    } else {
                      return (
                        <motion.div key={event.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}
                          onClick={() => setSelectedLifestyleEvent(event)}
                          className="group cursor-pointer overflow-hidden"
                          style={{ borderRadius: '20px', backgroundColor: LC.deepForestCard, border: `1px solid ${LC.deepForestBorder}` }}>
                          <div className="grid grid-cols-1 sm:grid-cols-12 gap-0">
                            <div className="sm:col-span-5 relative aspect-[16/10] sm:aspect-auto sm:min-h-[200px] overflow-hidden">
                              <ImageWithFallback src={event.image} alt={event.title} className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
                              <div className="absolute top-3 left-3">
                                <span className="text-[10px] uppercase tracking-wider px-2 py-1" style={{ color: LC.sage, backgroundColor: 'rgba(149,213,178,0.15)', borderRadius: '6px', fontFamily: LF.mono, fontWeight: 600, backdropFilter: 'blur(8px)' }}>
                                  {lifestyleCategories.find(c => c.key === event.category)?.boldLabel}
                                </span>
                                {isLifestyleEventPast(event) && <PastBadge t={t} />}
                              </div>
                            </div>
                            <div className="sm:col-span-7 p-5 sm:p-6 flex flex-col justify-center">
                              <div className="flex items-center gap-2 mb-2 text-[11px]" style={{ color: LC.deepForestTextLight, fontFamily: LF.body }}>
                                <Calendar size={11} /> {formatLifestyleDate(event.date)} &middot; {event.time}
                              </div>
                              <h3 className="mb-1 group-hover:opacity-70 transition-opacity" style={{ fontFamily: LF.heading, fontWeight: 900, fontSize: '1.15rem', color: LC.white, lineHeight: 1.2 }}>
                                {event.title}
                              </h3>
                              <p className="text-xs mb-3" style={{ color: LC.sage, fontFamily: LF.body, fontStyle: 'italic' }}>{event.subtitle}</p>
                              <div className="flex items-center gap-4">
                                <div className="flex items-center gap-1.5 text-[11px]" style={{ color: LC.sage, fontFamily: LF.body }}><MapPin size={10} />{event.district}</div>
                                <div className="flex items-center gap-1.5 text-[11px]" style={{ color: LC.deepForestTextLight, fontFamily: LF.body }}><Users size={10} />{event.spotsLeft} left</div>
                                <span className="text-xs font-semibold" style={{ color: formatPrice(event.price) === 'Free' ? LC.sage : '#E8744F', fontFamily: LF.mono }}>{formatPrice(event.price)}</span>
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      );
                    }
                  })}
                </div>
              </motion.div>
            </AnimatePresence>
          )}
        </div>
      </div>

      {/* ═══ Event Detail Modal ═══ */}
      <AnimatePresence>
        {selectedLifestyleEvent && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[9999] flex items-end sm:items-center justify-center">
            <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setSelectedLifestyleEvent(null)} />
            <motion.div initial={{ y: '100%', opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: '100%', opacity: 0 }}
              transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              className="relative w-full sm:max-w-lg max-h-[90vh] overflow-y-auto sm:rounded-3xl rounded-t-3xl" style={{ backgroundColor: LC.offWhite }}>
              <button onClick={() => setSelectedLifestyleEvent(null)} className="absolute top-4 right-4 z-10 p-2.5 cursor-pointer"
                style={{ backgroundColor: 'rgba(255,255,255,0.85)', borderRadius: '50%', backdropFilter: 'blur(8px)', boxShadow: '0 2px 8px rgba(0,0,0,0.1)' }}>
                <X size={16} style={{ color: LC.black }} />
              </button>
              <div className="relative h-56 sm:h-64 overflow-hidden rounded-t-3xl">
                <ImageWithFallback src={selectedLifestyleEvent.image} alt={selectedLifestyleEvent.title} className="h-full w-full object-cover" />
                <div className="absolute inset-0" style={{ background: `linear-gradient(to top, ${LC.offWhite}, transparent 60%)` }} />
              </div>
              <div className="px-6 pb-8 -mt-8 relative">
                <div className="flex items-center gap-2 mb-3 flex-wrap">
                  <span className="px-3 py-1 text-[10px] uppercase tracking-wider" style={{ color: LC.forestLight, backgroundColor: 'rgba(45,106,79,0.1)', borderRadius: '8px', fontFamily: LF.mono, fontWeight: 600 }}>
                    {lifestyleCategories.find(c => c.key === selectedLifestyleEvent.category)?.boldLabel}
                  </span>
                  {selectedLifestyleEvent.difficulty && (
                    <span className="px-2.5 py-1 text-[10px] uppercase tracking-wider" style={{ color: getDifficultyColor(selectedLifestyleEvent.difficulty), backgroundColor: `${getDifficultyColor(selectedLifestyleEvent.difficulty)}15`, borderRadius: '8px', fontFamily: LF.mono, fontWeight: 600 }}>
                      {selectedLifestyleEvent.difficulty}
                    </span>
                  )}
                  {selectedLifestyleEvent.recurring && (
                    <span className="px-2.5 py-1 text-[10px] uppercase tracking-wider" style={{ color: LC.textMuted, backgroundColor: 'rgba(0,0,0,0.04)', borderRadius: '8px', fontFamily: LF.mono }}>{t('lifestyle.recurring')}</span>
                  )}
                  {isLifestyleEventPast(selectedLifestyleEvent) && <PastBadge variant="inline" t={t} />}
                </div>
                <h2 style={{ fontFamily: LF.heading, fontSize: '1.7rem', fontWeight: 900, color: LC.black, marginBottom: '4px', letterSpacing: '-0.02em' }}>
                  {selectedLifestyleEvent.title}
                </h2>
                <p className="text-sm mb-5" style={{ color: LC.textMuted, fontFamily: LF.body, fontStyle: 'italic' }}>{selectedLifestyleEvent.subtitle}</p>
                <p className="text-sm mb-6" style={{ color: '#5A5A5A', fontFamily: LF.body, lineHeight: 1.7 }}>
                  {selectedLifestyleEvent.description && selectedLifestyleEvent.description.length > 300
                    ? <>{selectedLifestyleEvent.description.slice(0, 300).trimEnd()}… <Link to={getEventLink(selectedLifestyleEvent)} className="inline" style={{ color: LC.forest, fontWeight: 600 }}>Read more</Link></>
                    : selectedLifestyleEvent.description}
                </p>
                <div className="grid grid-cols-2 gap-3 mb-6">
                  {[
                    { icon: Calendar, label: t('lifestyle.date'), value: formatLifestyleDate(selectedLifestyleEvent.date) },
                    { icon: Clock, label: t('lifestyle.time'), value: selectedLifestyleEvent.time },
                    { icon: MapPin, label: t('lifestyle.location'), value: selectedLifestyleEvent.location },
                    { icon: Users, label: t('lifestyle.spotsLeftLabel'), value: t('lifestyle.spotsLeftValue', { left: selectedLifestyleEvent.spotsLeft, total: selectedLifestyleEvent.capacity }) },
                  ].map((item) => (
                    <div key={item.label} className="p-3" style={{ borderRadius: '14px', backgroundColor: 'rgba(45,106,79,0.06)' }}>
                      <div className="flex items-center gap-1.5 mb-1">
                        <item.icon size={12} style={{ color: LC.forest }} />
                        <span className="text-[10px] uppercase tracking-wider" style={{ color: LC.textMuted, fontFamily: LF.mono }}>{item.label}</span>
                      </div>
                      <span className="text-sm" style={{ color: LC.black, fontFamily: LF.body, fontWeight: 500 }}>{item.value}</span>
                    </div>
                  ))}
                </div>
                <div className="flex items-center justify-between mb-6 p-3" style={{ borderRadius: '14px', backgroundColor: 'rgba(45,106,79,0.06)' }}>
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 flex items-center justify-center" style={{ borderRadius: '12px', backgroundColor: 'rgba(45,106,79,0.1)' }}>
                      <Heart size={16} style={{ color: LC.forestLight }} />
                    </div>
                    <div>
                      <span className="text-sm block" style={{ color: LC.black, fontFamily: LF.body, fontWeight: 600 }}>{selectedLifestyleEvent.organizer}</span>
                      <span className="text-[11px]" style={{ color: LC.textMuted, fontFamily: LF.body }}>{t('lifestyle.organizer')}</span>
                    </div>
                  </div>
                  <button className="text-xs flex items-center gap-1 cursor-pointer" style={{ color: LC.forestLight, fontFamily: LF.body, fontWeight: 500 }}>
                    {t('lifestyle.follow')} <ExternalLink size={10} />
                  </button>
                </div>
                <div className="flex flex-wrap gap-2 mb-6">
                  {selectedLifestyleEvent.tags.map((tag) => (
                    <span key={tag} className="px-3 py-1 text-[11px]" style={{ color: LC.textMuted, backgroundColor: 'rgba(0,0,0,0.04)', borderRadius: '9999px', fontFamily: LF.body }}>#{tag}</span>
                  ))}
                </div>
                <div className="mb-6">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs" style={{ color: LC.textMuted, fontFamily: LF.body }}>{t('lifestyle.joined', { count: selectedLifestyleEvent.capacity - selectedLifestyleEvent.spotsLeft })}</span>
                    <span className="text-xs" style={{ color: selectedLifestyleEvent.spotsLeft <= 3 ? '#C4653A' : LC.textMuted, fontFamily: LF.body, fontWeight: selectedLifestyleEvent.spotsLeft <= 3 ? 700 : 400 }}>
                      {selectedLifestyleEvent.spotsLeft <= 3 ? t('lifestyle.almostFull') : t('lifestyle.spotsLeft', { count: selectedLifestyleEvent.spotsLeft })}
                    </span>
                  </div>
                  <div className="h-2 overflow-hidden" style={{ borderRadius: '9999px', backgroundColor: 'rgba(0,0,0,0.06)' }}>
                    <motion.div initial={{ width: 0 }} animate={{ width: `${((selectedLifestyleEvent.capacity - selectedLifestyleEvent.spotsLeft) / selectedLifestyleEvent.capacity) * 100}%` }}
                      transition={{ duration: 0.8, ease: 'easeOut' }} className="h-full"
                      style={{ borderRadius: '9999px', backgroundColor: selectedLifestyleEvent.spotsLeft <= 3 ? '#E8744F' : LC.forest }} />
                  </div>
                </div>
                <div className="flex gap-3">
                  {isLifestyleEventPast(selectedLifestyleEvent) ? (
                    <div className="flex-1 flex items-center justify-center gap-2 py-3.5 text-sm"
                      style={{ backgroundColor: `${PAST_BADGE_AMBER}10`, color: PAST_BADGE_AMBER, borderRadius: '14px', fontFamily: LF.body, fontWeight: 600, border: `1.5px solid ${PAST_BADGE_AMBER}30` }}>
                      <History size={14} /> {t('lifestyle.eventEnded')}
                    </div>
                  ) : (
                    <a
                      href={selectedLifestyleEvent.ticketUrl || selectedLifestyleEvent.sourceUrl || '#'}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 flex items-center justify-center gap-2 py-3.5 text-sm transition-all hover:opacity-90 cursor-pointer no-underline"
                      style={{ backgroundColor: LC.forest, color: LC.white, borderRadius: '14px', fontFamily: LF.body, fontWeight: 700 }}>
                      {t('lifestyle.joinEvent')} &mdash; {formatPrice(selectedLifestyleEvent.price)}
                      <ExternalLink size={14} />
                    </a>
                  )}
                  <ShareMenu
                    url={typeof window !== 'undefined' ? `${window.location.origin}${getEventLink(selectedLifestyleEvent)}` : getEventLink(selectedLifestyleEvent)}
                    title={selectedLifestyleEvent.title}
                    description={selectedLifestyleEvent.description}
                    eventId={selectedLifestyleEvent.id}
                  >
                    {({ onClick, ref }) => (
                      <button ref={ref} onClick={onClick} className="p-3.5 cursor-pointer transition-all hover:opacity-70"
                        style={{ border: '1.5px solid rgba(0,0,0,0.1)', borderRadius: '14px', color: LC.textMuted }}>
                        <Share2 size={16} />
                      </button>
                    )}
                  </ShareMenu>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ═══ Past Events Section ═══ */}
      {hidePastEvents && <LifestylePastEvents allEvents={allEvents} searchQuery={searchQuery} />}

      </div>

      <style>{`
        .scrollbar-hide::-webkit-scrollbar { display: none; }
        .scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
      `}</style>
    </div>
  );
}

// ── Lifestyle Past Events Collapsible Section ──
function LifestylePastEvents({ allEvents, searchQuery }: { allEvents: any[]; searchQuery: string }) {
  const { t } = useTranslation();
  const [showPast, setShowPast] = useState(false);
  const [showAll, setShowAll] = useState(false);
  const amberColor = '#F59E0B';

  const pastEvents = allEvents.filter((e) => {
    const status = computeEventStatus(e.date, e.endDate);
    if (status !== 'past') return false;
    // Must be lifestyle-tagged
    const modeTags = e.modeTags || [];
    const modeScores = e.modeScores || {};
    if (!modeTags.includes('lifestyle') && !(modeScores['lifestyle'] >= 0.3)) return false;
    // Search filter
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      const searchableText = [
        e.title, e.venueName || '', e.district || '', e.description || '',
        ...(e.artists || []), ...(e.categories || []), ...(e.vibes || []),
      ].join(' ').toLowerCase();
      if (!searchableText.includes(q)) return false;
    }
    return true;
  }).sort((a, b) => {
    const da = parseEventDate(a.date);
    const db = parseEventDate(b.date);
    if (!da && !db) return 0;
    if (!da) return 1;
    if (!db) return -1;
    return db.getTime() - da.getTime();
  });

  if (pastEvents.length === 0) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
      className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 pb-12"
      style={{ backgroundColor: LC.deepForest }}
    >
      <button
        onClick={() => setShowPast(!showPast)}
        className="flex items-center gap-2 mb-4 pt-6 cursor-pointer group transition-all hover:opacity-80"
        style={{ background: 'none', border: 'none', padding: 0, paddingTop: '1.5rem' }}
      >
        <History size={16} style={{ color: amberColor }} />
        <h2 style={{
          fontSize: '1rem',
          color: LC.white,
          fontFamily: LF.heading,
          fontWeight: 700,
          margin: 0,
        }}>
          {t('lifestyle.pastEvents')}
        </h2>
        <span className="px-2 py-0.5 text-[10px] font-semibold" style={{
          backgroundColor: `${amberColor}15`,
          color: amberColor,
          borderRadius: '9999px',
        }}>
          {pastEvents.length}
        </span>
        <ChevronRight
          size={14}
          style={{
            color: LC.deepForestTextLight,
            transform: showPast ? 'rotate(90deg)' : 'rotate(0deg)',
            transition: 'transform 0.2s ease',
          }}
        />
      </button>
      {showPast && (
        <div className="space-y-2" style={{ opacity: 0.75 }}>
          {pastEvents.slice(0, showAll ? pastEvents.length : 20).map((event: any) => (
            <Link
              key={event.id}
              to={getEventLink(event)}
              className="flex gap-3 p-3 transition-all no-underline hover:opacity-80"
              style={{
                borderRadius: '16px',
                backgroundColor: LC.deepForestCard,
                border: `1px solid ${LC.deepForestBorder}`,
              }}
            >
              <div className="h-14 w-14 overflow-hidden flex-shrink-0" style={{
                borderRadius: '12px',
                filter: 'grayscale(40%)',
              }}>
                <ImageWithFallback src={event.image} alt={event.title} className="h-full w-full object-cover" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <h3 className="text-sm truncate" style={{
                    color: LC.white,
                    fontWeight: 600,
                    fontFamily: LF.heading,
                  }}>{event.title}</h3>
                  <span className="flex-shrink-0 px-1.5 py-0.5 text-[9px] font-semibold uppercase" style={{
                    backgroundColor: `${amberColor}15`,
                    color: amberColor,
                    borderRadius: '6px',
                  }}>
                    Past
                  </span>
                </div>
                <div className="flex items-center gap-2 mt-0.5">
                  <Clock size={11} style={{ color: LC.deepForestTextLight }} />
                  <span className="text-xs" style={{ color: LC.deepForestTextLight, fontFamily: LF.body }}>{event.date}{event.time ? ` · ${event.time}` : ''}</span>
                </div>
                {event.venueName && (
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <MapPin size={10} style={{ color: LC.deepForestTextLight }} />
                    <span className="text-xs" style={{ color: LC.deepForestTextLight, fontFamily: LF.body }}>{event.venueName}</span>
                  </div>
                )}
              </div>
            </Link>
          ))}
          {pastEvents.length > 20 && !showAll && (
            <button
              onClick={() => setShowAll(true)}
              className="w-full flex items-center justify-center gap-2 py-3 text-xs font-semibold transition-all hover:opacity-80 cursor-pointer"
              style={{
                color: amberColor,
                backgroundColor: `${amberColor}08`,
                borderRadius: '16px',
                border: `1px dashed ${amberColor}40`,
              }}
            >
              <History size={12} />
              {t('lifestyle.viewAllPast', { count: pastEvents.length })}
              <ChevronRight size={12} />
            </button>
          )}
          {showAll && pastEvents.length > 20 && (
            <button
              onClick={() => setShowAll(false)}
              className="w-full flex items-center justify-center gap-2 py-2 text-xs transition-all hover:opacity-80 cursor-pointer"
              style={{ color: LC.deepForestTextLight }}
            >
              {t('lifestyle.showLess')}
            </button>
          )}
        </div>
      )}
    </motion.div>
  );
}