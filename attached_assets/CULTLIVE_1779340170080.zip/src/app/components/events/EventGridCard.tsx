/**
 * EventGridCard — shared event card used by foodie, family, and default modes
 */
import { Link } from 'react-router';
import { useTranslation } from 'react-i18next';
import { motion } from 'motion/react';
import { MapPin, Clock, Users, Eye } from 'lucide-react';
import { modeConfig, type CulturalEvent } from '../../data/mock-data';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { CIcon } from '../CIcon';
import { getEventLink, formatPrice } from '../../utils/event-helpers';
import { CategoryPills, resolveCategories } from '../CategoryPills';
import { BookmarkHeart } from '../BookmarkHeart';
import { getBilingualField } from '../../utils/bilingual';
import { useEventStats } from '../../context/EventStatsContext';

/** Map category slugs to human-readable labels & colors based on mode system */
const CATEGORY_DISPLAY: Record<string, { label: string; color: string }> = {
  // Mode-based
  nightlife: { label: 'Nightlife', color: '#D600FF' },
  degen: { label: 'Nightlife', color: '#D600FF' },
  family: { label: 'Family', color: '#FF8C42' },
  artsy: { label: 'Art', color: '#8338EC' },
  art: { label: 'Art', color: '#8338EC' },
  foodie: { label: 'Food', color: '#2563EB' },
  food: { label: 'Food', color: '#2563EB' },
  lifestyle: { label: 'Lifestyle', color: '#2D6A4F' },
  // Category-based fallbacks
  music: { label: 'Music', color: '#D600FF' },
  'food-drink': { label: 'Food', color: '#2563EB' },
  'food & drink': { label: 'Food', color: '#2563EB' },
  workshop: { label: 'Workshop', color: '#8338EC' },
  exhibition: { label: 'Art', color: '#8338EC' },
  culture: { label: 'Culture', color: '#8338EC' },
  theatre: { label: 'Theatre', color: '#8338EC' },
  community: { label: 'Community', color: '#2D6A4F' },
  wellness: { label: 'Wellness', color: '#2D6A4F' },
  sports: { label: 'Sports', color: '#2D6A4F' },
  other: { label: 'Events', color: '#64748B' },
};

/** Get primary category badge for an event (uses modeTags > category > fallback) */
function getEventCategoryBadge(event: CulturalEvent): { label: string; color: string }[] {
  const badges: { label: string; color: string }[] = [];

  // Use all modeTags if available
  if (event.modeTags?.length) {
    for (const tag of event.modeTags) {
      const cfg = CATEGORY_DISPLAY[tag];
      if (cfg && !badges.some(b => b.label === cfg.label)) badges.push(cfg);
    }
  }

  // If no modeTags matched, try category string
  if (!badges.length && event.category) {
    const cat = event.category.toLowerCase().trim();
    const cfg = CATEGORY_DISPLAY[cat];
    if (cfg) {
      badges.push(cfg);
    } else {
      for (const [key, val] of Object.entries(CATEGORY_DISPLAY)) {
        if (cat.includes(key) || key.includes(cat)) { badges.push(val); break; }
      }
    }
  }

  return badges.length ? badges : [{ label: 'Events', color: '#64748B' }];
}

export function EventGridCard({
  event,
  index,
  modeColor,
  tokens,
}: {
  event: CulturalEvent;
  index: number;
  modeColor: string;
  tokens: {
    imageRadius: string;
    textMuted: string;
  };
}) {
  const { i18n } = useTranslation();
  const lang = i18n.language;
  const title = getBilingualField(event, 'title', lang);
  const venueName = getBilingualField(event, 'venueName', lang);
  const { getStats } = useEventStats();
  const stats = getStats(event.id);
  const goingCount = stats?.saves || 0;
  const viewCount = stats?.views || 0;

  return (
    <motion.div
      key={event.id}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.06 }}
    >
      <Link to={getEventLink(event)} className="group block">
        <div
          className="relative overflow-hidden aspect-[3/4] mb-3"
          style={{ borderRadius: tokens.imageRadius }}
        >
          <ImageWithFallback
            src={event.image}
            alt={title}
            className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />

          {event.status === 'ongoing' && (
            <div className="absolute top-3 left-3">
              <span className="flex items-center gap-1 rounded-full bg-green-500/90 px-2.5 py-1 text-xs text-white">
                <span className="h-1.5 w-1.5 rounded-full bg-white animate-pulse" />
                Now
              </span>
            </div>
          )}

          {event.featured && (
            <div className="absolute top-3 left-3">
              <span className="flex items-center gap-1 rounded-full px-2.5 py-1 text-xs text-white backdrop-blur-sm" style={{ backgroundColor: `${modeColor}60` }}>
                Featured
              </span>
            </div>
          )}

          {/* Category badge */}
          {!event.featured && !event.status?.includes('ongoing') && (() => {
            const badges = getEventCategoryBadge(event);
            return (
              <div className="absolute top-3 left-3 flex flex-wrap gap-1">
                {badges.map((badge) => (
                  <span key={badge.label} className="flex items-center gap-1 rounded-full px-2.5 py-1 text-[10px] font-semibold text-white backdrop-blur-sm" style={{ backgroundColor: `${badge.color}cc` }}>
                    {badge.label}
                  </span>
                ))}
              </div>
            );
          })()}

          <div className="absolute top-3 right-3 z-10 flex items-center gap-1.5">
            {viewCount > 0 && (
              <span
                className="flex items-center gap-1 px-1.5 py-1 text-[10px] font-medium text-white"
                style={{ backgroundColor: 'rgba(0,0,0,0.35)', borderRadius: '6px', backdropFilter: 'blur(4px)' }}
              >
                <Eye size={10} /> {viewCount > 999 ? `${(viewCount / 1000).toFixed(1)}k` : viewCount}
              </span>
            )}
            <BookmarkHeart eventId={event.id} />
          </div>

          <div className="absolute bottom-3 left-3 right-3">
            {/* Multi-category pills for community events, single text for mock */}
            {resolveCategories(event).length > 1 ? (
              <CategoryPills categories={resolveCategories(event)} size="xs" overlay showPrimary maxVisible={3} className="mb-1" />
            ) : (
              <span className="text-xs text-white/50 hidden sm:inline">{event.category}</span>
            )}
            <h3 className="text-white mt-1 text-sm sm:text-base line-clamp-2">{title}</h3>
            <div className="hidden sm:flex items-center gap-3 mt-2">
              <span className="flex items-center gap-1 text-xs text-white/40">
                <MapPin size={11} /> {venueName}
              </span>
              <span className="flex items-center gap-1 text-xs text-white/40">
                <Clock size={11} /> {event.time}
              </span>
              {goingCount > 0 && (
                <span className="flex items-center gap-1 text-xs text-white/50">
                  <Users size={11} /> {goingCount} going
                </span>
              )}
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs" style={{ color: tokens.textMuted }}>{event.date}</span>
            {goingCount > 0 && (
              <span className="flex items-center gap-1 text-[10px] font-medium" style={{ color: `${modeColor}aa` }}>
                <Users size={9} /> {goingCount}
              </span>
            )}
          </div>
          <span
            className="rounded-full px-2.5 py-0.5 text-xs"
            style={{ backgroundColor: `${modeColor}12`, color: `${modeColor}aa` }}
          >
            {formatPrice(event.price)}
          </span>
        </div>
      </Link>
    </motion.div>
  );
}