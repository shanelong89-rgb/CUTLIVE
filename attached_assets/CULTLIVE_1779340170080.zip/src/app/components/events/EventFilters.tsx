import { useState } from 'react';
import { X, ChevronDown, Calendar, DollarSign, Tag, SlidersHorizontal } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useTranslation } from 'react-i18next';
import { useMode } from '../../context/ModeContext';
import { getDesignTokens } from '../../data/mode-styles';
import { modeConfig, type Mode } from '../../data/mock-data';

interface EventFiltersProps {
  categories: string[];
  selectedCategory: string | null;
  onCategoryChange: (category: string | null) => void;
  dateRange: { start: Date | null; end: Date | null };
  onDateRangeChange: (range: { start: Date | null; end: Date | null }) => void;
  priceRange: { min: number; max: number };
  onPriceRangeChange: (range: { min: number; max: number }) => void;
  sortBy: 'date' | 'price' | 'popularity';
  onSortChange: (sort: 'date' | 'price' | 'popularity') => void;
  onReset: () => void;
}

export function EventFilters({
  categories,
  selectedCategory,
  onCategoryChange,
  dateRange,
  onDateRangeChange,
  priceRange,
  onPriceRangeChange,
  sortBy,
  onSortChange,
  onReset,
}: EventFiltersProps) {
  const { t } = useTranslation();
  const { currentMode } = useMode();
  const tokens = getDesignTokens(currentMode);
  const modeColor = currentMode && currentMode !== 'lifestyle' ? modeConfig[currentMode].color : currentMode === 'lifestyle' ? '#2D6A4F' : '#1A1A1A';
  
  const [filtersOpen, setFiltersOpen] = useState(false);

  const hasActiveFilters =
    selectedCategory ||
    dateRange.start ||
    dateRange.end ||
    priceRange.min > 0 ||
    priceRange.max < 500 ||
    sortBy !== 'date';

  const sortOptions: { key: 'date' | 'price' | 'popularity'; label: string }[] = [
    { key: 'date', label: t('filters.sortDate') },
    { key: 'price', label: t('filters.sortPrice') },
    { key: 'popularity', label: t('filters.sortPopularity') },
  ];

  return (
    <div className="space-y-3">
      {/* Filter Toggle Button */}
      <div className="flex items-center gap-3 flex-wrap">
        <button
          onClick={() => setFiltersOpen(!filtersOpen)}
          className="flex items-center gap-2 px-4 py-2.5 text-sm transition-all duration-300 rounded-xl relative"
          style={{
            backgroundColor: filtersOpen ? `${modeColor}15` : tokens.surfaceBg,
            color: filtersOpen ? modeColor : tokens.textPrimary,
            border: `1px solid ${filtersOpen ? `${modeColor}30` : tokens.cardBorder}`,
          }}
        >
          <SlidersHorizontal size={16} />
          <span className="font-medium">{t('filters.filters')}</span>
          {hasActiveFilters && (
            <span
              className="w-2 h-2 rounded-full"
              style={{ backgroundColor: modeColor }}
            />
          )}
          <ChevronDown
            size={14}
            style={{
              transform: filtersOpen ? 'rotate(180deg)' : 'rotate(0deg)',
              transition: 'transform 0.3s ease',
            }}
          />
        </button>

        {/* Active filters summary */}
        {hasActiveFilters && (
          <div className="flex items-center gap-2 flex-wrap">
            {selectedCategory && (
              <span
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-lg"
                style={{
                  backgroundColor: `${modeColor}12`,
                  color: modeColor,
                }}
              >
                <Tag size={12} />
                {selectedCategory}
                <button onClick={() => onCategoryChange(null)} className="hover:opacity-70">
                  <X size={12} />
                </button>
              </span>
            )}
            {(dateRange.start || dateRange.end) && (
              <span
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-lg"
                style={{
                  backgroundColor: `${modeColor}12`,
                  color: modeColor,
                }}
              >
                <Calendar size={12} />
                {t('filters.dateRange')}
                <button onClick={() => onDateRangeChange({ start: null, end: null })} className="hover:opacity-70">
                  <X size={12} />
                </button>
              </span>
            )}
            {(priceRange.min > 0 || priceRange.max < 500) && (
              <span
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-lg"
                style={{
                  backgroundColor: `${modeColor}12`,
                  color: modeColor,
                }}
              >
                <DollarSign size={12} />
                ${priceRange.min}-${priceRange.max}
                <button onClick={() => onPriceRangeChange({ min: 0, max: 500 })} className="hover:opacity-70">
                  <X size={12} />
                </button>
              </span>
            )}
            <button
              onClick={onReset}
              className="text-xs px-3 py-1.5 rounded-lg hover:opacity-70 transition-opacity"
              style={{ color: tokens.textMuted }}
            >
              {t('filters.resetAll')}
            </button>
          </div>
        )}
      </div>

      {/* Expanded Filters Panel */}
      <AnimatePresence>
        {filtersOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: 'easeInOut' }}
            className="overflow-hidden"
          >
            <div
              className="p-5 rounded-2xl space-y-4"
              style={{
                backgroundColor: tokens.surfaceBg,
                border: `1px solid ${tokens.cardBorder}`,
              }}
            >
              {/* Categories */}
              <div>
                <label className="text-xs font-medium uppercase tracking-wider mb-2 block" style={{ color: tokens.textMuted }}>
                  {t('filters.category')}
                </label>
                <div className="flex flex-wrap gap-2">
                  {categories.map((cat) => (
                    <button
                      key={cat}
                      onClick={() => onCategoryChange(selectedCategory === cat ? null : cat)}
                      className="px-4 py-2 text-sm rounded-xl transition-all duration-300"
                      style={{
                        backgroundColor: selectedCategory === cat ? `${modeColor}20` : 'transparent',
                        color: selectedCategory === cat ? modeColor : tokens.textSecondary,
                        border: `1px solid ${selectedCategory === cat ? `${modeColor}40` : tokens.cardBorder}`,
                      }}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              {/* Date Range */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-medium uppercase tracking-wider mb-2 block" style={{ color: tokens.textMuted }}>
                    {t('filters.fromDate')}
                  </label>
                  <input
                    type="date"
                    value={dateRange.start ? dateRange.start.toISOString().split('T')[0] : ''}
                    onChange={(e) => {
                      const date = e.target.value ? new Date(e.target.value) : null;
                      onDateRangeChange({ ...dateRange, start: date });
                    }}
                    className="w-full px-4 py-2.5 rounded-xl text-sm transition-all"
                    style={{
                      backgroundColor: tokens.pageBg,
                      color: tokens.textPrimary,
                      border: `1px solid ${tokens.cardBorder}`,
                    }}
                  />
                </div>
                <div>
                  <label className="text-xs font-medium uppercase tracking-wider mb-2 block" style={{ color: tokens.textMuted }}>
                    {t('filters.toDate')}
                  </label>
                  <input
                    type="date"
                    value={dateRange.end ? dateRange.end.toISOString().split('T')[0] : ''}
                    onChange={(e) => {
                      const date = e.target.value ? new Date(e.target.value) : null;
                      onDateRangeChange({ ...dateRange, end: date });
                    }}
                    className="w-full px-4 py-2.5 rounded-xl text-sm transition-all"
                    style={{
                      backgroundColor: tokens.pageBg,
                      color: tokens.textPrimary,
                      border: `1px solid ${tokens.cardBorder}`,
                    }}
                  />
                </div>
              </div>

              {/* Price Range */}
              <div>
                <label className="text-xs font-medium uppercase tracking-wider mb-2 block" style={{ color: tokens.textMuted }}>
                  {t('filters.priceRange')}: ${priceRange.min} - ${priceRange.max === 500 ? '500+' : priceRange.max}
                </label>
                <div className="flex gap-4 items-center">
                  <input
                    type="range"
                    min="0"
                    max="500"
                    step="10"
                    value={priceRange.min}
                    onChange={(e) => onPriceRangeChange({ ...priceRange, min: parseInt(e.target.value) })}
                    className="flex-1"
                    style={{
                      accentColor: modeColor,
                    }}
                  />
                  <input
                    type="range"
                    min="0"
                    max="500"
                    step="10"
                    value={priceRange.max}
                    onChange={(e) => onPriceRangeChange({ ...priceRange, max: parseInt(e.target.value) })}
                    className="flex-1"
                    style={{
                      accentColor: modeColor,
                    }}
                  />
                </div>
              </div>

              {/* Sort By */}
              <div>
                <label className="text-xs font-medium uppercase tracking-wider mb-2 block" style={{ color: tokens.textMuted }}>
                  {t('filters.sortBy')}
                </label>
                <div className="flex gap-2">
                  {sortOptions.map((opt) => (
                    <button
                      key={opt.key}
                      onClick={() => onSortChange(opt.key)}
                      className="flex-1 px-4 py-2.5 text-sm rounded-xl transition-all duration-300"
                      style={{
                        backgroundColor: sortBy === opt.key ? `${modeColor}20` : 'transparent',
                        color: sortBy === opt.key ? modeColor : tokens.textSecondary,
                        border: `1px solid ${sortBy === opt.key ? `${modeColor}40` : tokens.cardBorder}`,
                      }}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}