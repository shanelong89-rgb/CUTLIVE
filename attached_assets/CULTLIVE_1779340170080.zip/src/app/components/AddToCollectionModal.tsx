/**
 * AddToCollectionModal — slide-up modal to add an event/venue to a collection
 */
import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, FolderPlus, Check, Plus, Loader2, Lock, Globe, Heart } from 'lucide-react';
import { useCollections } from '../context/CollectionsContext';
import { useMode } from '../context/ModeContext';
import { useAuth } from '../context/AuthContext';
import { getDesignTokens } from '../data/mode-styles';
import { toast } from 'sonner';
import { modeConfig } from '../data/mock-data';

interface AddToCollectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  itemId: string;
  itemType: 'event' | 'venue';
  itemName?: string;
}

export function AddToCollectionModal({ isOpen, onClose, itemId, itemType, itemName }: AddToCollectionModalProps) {
  const { collections, addToCollection, removeFromCollection, isInCollection, createCollection, toggleQuickSave, isQuickSaved } = useCollections();
  const { currentMode } = useMode();
  const { user } = useAuth();
  const tokens = getDesignTokens(currentMode);
  const modeColor = currentMode && currentMode !== 'lifestyle'
    ? modeConfig[currentMode].color
    : currentMode === 'lifestyle' ? '#2D6A4F' : '#8338EC';

  const [creating, setCreating] = useState(false);
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newPublic, setNewPublic] = useState(false);
  const [loadingId, setLoadingId] = useState<string | null>(null);
  const [quickSaving, setQuickSaving] = useState(false);
  const [savingNew, setSavingNew] = useState(false);
  const [error, setError] = useState('');
  const quickSaved = isQuickSaved(itemId);

  const handleToggle = async (collectionId: string) => {
    setLoadingId(collectionId);
    setError('');
    try {
      if (isInCollection(collectionId, itemId)) {
        await removeFromCollection(collectionId, itemId);
      } else {
        await addToCollection(collectionId, itemId, itemType);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to update collection');
    } finally {
      setLoadingId(null);
    }
  };

  const handleCreateAndAdd = async () => {
    if (!newName.trim()) return;
    setSavingNew(true);
    setError('');
    try {
      const collection = await createCollection(newName.trim(), newDesc.trim(), newPublic);
      await addToCollection(collection.id, itemId, itemType);
      setCreating(false);
      setNewName('');
      setNewDesc('');
      setNewPublic(false);
    } catch (err: any) {
      setError(err.message || 'Failed to create collection');
    } finally {
      setSavingNew(false);
    }
  };

  const handleQuickSave = async () => {
    setQuickSaving(true);
    setError('');
    try {
      await toggleQuickSave(itemId, itemType);
      toast(quickSaved ? 'Removed from Quick Saves' : '❤️ Saved to Quick Saves', {
        description: itemName,
      });
    } catch (err: any) {
      setError(err.message || 'Failed to quick save');
    } finally {
      setQuickSaving(false);
    }
  };

  const handleClose = () => {
    setCreating(false);
    setNewName('');
    setNewDesc('');
    setError('');
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[3000]"
            style={{ backgroundColor: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(4px)' }}
            onClick={handleClose}
          />

          {/* Modal panel */}
          <motion.div
            initial={{ opacity: 0, y: 40, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 40, scale: 0.97 }}
            transition={{ type: 'spring', damping: 28, stiffness: 340 }}
            className="fixed bottom-0 left-0 right-0 sm:bottom-auto sm:top-1/2 sm:left-1/2 sm:-translate-x-1/2 sm:-translate-y-1/2 sm:w-full sm:max-w-md z-[3001]"
            style={{
              backgroundColor: tokens.pageBg,
              borderRadius: '24px 24px 0 0',
              ...(typeof window !== 'undefined' && window.innerWidth >= 640 ? { borderRadius: '20px' } : {}),
              boxShadow: '0 -8px 40px rgba(0,0,0,0.15), 0 0 0 1px rgba(0,0,0,0.05)',
            }}
            onClick={e => e.stopPropagation()}
          >
            {/* Handle bar (mobile) */}
            <div className="sm:hidden flex justify-center pt-3 pb-1">
              <div className="w-10 h-1 rounded-full" style={{ backgroundColor: tokens.cardBorder }} />
            </div>

            {/* Header */}
            <div
              className="flex items-center justify-between px-5 py-4"
              style={{ borderBottom: `1px solid ${tokens.cardBorder}` }}
            >
              <div>
                <h3 className="text-base font-semibold" style={{ color: tokens.textPrimary }}>
                  Save to Collection
                </h3>
                {itemName && (
                  <p className="text-xs mt-0.5 truncate max-w-[240px]" style={{ color: tokens.textMuted }}>
                    {itemName}
                  </p>
                )}
              </div>
              <button
                onClick={handleClose}
                className="p-2 rounded-full cursor-pointer hover:opacity-70"
                style={{ color: tokens.textMuted, backgroundColor: tokens.surfaceBg }}
              >
                <X size={16} />
              </button>
            </div>

            {/* Body */}
            <div className="px-5 py-4 max-h-[55vh] overflow-y-auto">
              {!user ? (
                <div className="text-center py-8">
                  <p className="text-sm" style={{ color: tokens.textMuted }}>
                    Sign in to save to collections
                  </p>
                </div>
              ) : (
                <>
                  {error && (
                    <div className="mb-3 px-3 py-2 rounded-lg text-xs" style={{ backgroundColor: 'rgba(239,68,68,0.08)', color: '#EF4444' }}>
                      {error}
                    </div>
                  )}

                  {/* Quick save */}
                  <button
                    onClick={handleQuickSave}
                    disabled={quickSaving}
                    className="w-full flex items-center gap-3 px-3 py-3 rounded-xl text-left transition-all cursor-pointer hover:opacity-80 disabled:opacity-50 mb-3"
                    style={{
                      backgroundColor: quickSaved ? `${modeColor}10` : tokens.surfaceBg,
                      border: `1px solid ${quickSaved ? modeColor + '30' : tokens.cardBorder}`,
                    }}
                  >
                    <div
                      className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0"
                      style={{ backgroundColor: quickSaved ? `${modeColor}15` : tokens.cardBorder + '50' }}
                    >
                      {quickSaving ? (
                        <Loader2 size={16} className="animate-spin" style={{ color: modeColor }} />
                      ) : quickSaved ? (
                        <Check size={16} style={{ color: modeColor }} />
                      ) : (
                        <Heart size={16} style={{ color: tokens.textMuted }} />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate" style={{ color: tokens.textPrimary }}>
                        Quick Save
                      </p>
                      <p className="text-[11px]" style={{ color: tokens.textMuted }}>
                        Save this {itemType} to your quick saves
                      </p>
                    </div>
                    {quickSaved && (
                      <span
                        className="text-[10px] font-medium px-2 py-0.5 rounded-full"
                        style={{ backgroundColor: `${modeColor}15`, color: modeColor }}
                      >
                        Saved
                      </span>
                    )}
                  </button>

                  {/* Existing collections */}
                  {collections.length > 0 && (
                    <div className="space-y-2 mb-4">
                      {collections.map(col => {
                        const saved = isInCollection(col.id, itemId);
                        const isLoading = loadingId === col.id;
                        return (
                          <button
                            key={col.id}
                            onClick={() => handleToggle(col.id)}
                            disabled={isLoading}
                            className="w-full flex items-center gap-3 px-3 py-3 rounded-xl text-left transition-all cursor-pointer hover:opacity-80 disabled:opacity-50"
                            style={{
                              backgroundColor: saved ? `${modeColor}10` : tokens.surfaceBg,
                              border: `1px solid ${saved ? modeColor + '30' : tokens.cardBorder}`,
                            }}
                          >
                            <div
                              className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0"
                              style={{ backgroundColor: saved ? `${modeColor}15` : tokens.cardBorder + '50' }}
                            >
                              {isLoading ? (
                                <Loader2 size={16} className="animate-spin" style={{ color: modeColor }} />
                              ) : saved ? (
                                <Check size={16} style={{ color: modeColor }} />
                              ) : (
                                <FolderPlus size={16} style={{ color: tokens.textMuted }} />
                              )}
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium truncate" style={{ color: tokens.textPrimary }}>
                                {col.name}
                              </p>
                              <p className="text-[11px]" style={{ color: tokens.textMuted }}>
                                {col.items.length} item{col.items.length !== 1 ? 's' : ''} · {col.isPublic ? 'Public' : 'Private'}
                              </p>
                            </div>
                            {saved && (
                              <span
                                className="text-[10px] font-medium px-2 py-0.5 rounded-full"
                                style={{ backgroundColor: `${modeColor}15`, color: modeColor }}
                              >
                                Saved
                              </span>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  )}

                  {/* Create new collection */}
                  {creating ? (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      className="rounded-xl overflow-hidden"
                      style={{ border: `1px solid ${modeColor}30`, backgroundColor: `${modeColor}05` }}
                    >
                      <div className="p-4 space-y-3">
                        <p className="text-sm font-medium" style={{ color: tokens.textPrimary }}>
                          New Collection
                        </p>
                        <input
                          type="text"
                          placeholder="Collection name"
                          value={newName}
                          onChange={e => setNewName(e.target.value)}
                          autoFocus
                          className="w-full text-sm px-3 py-2 rounded-lg outline-none transition-all"
                          style={{
                            backgroundColor: tokens.pageBg,
                            border: `1px solid ${tokens.cardBorder}`,
                            color: tokens.textPrimary,
                          }}
                          onKeyDown={e => { if (e.key === 'Enter') handleCreateAndAdd(); }}
                        />
                        <input
                          type="text"
                          placeholder="Description (optional)"
                          value={newDesc}
                          onChange={e => setNewDesc(e.target.value)}
                          className="w-full text-sm px-3 py-2 rounded-lg outline-none transition-all"
                          style={{
                            backgroundColor: tokens.pageBg,
                            border: `1px solid ${tokens.cardBorder}`,
                            color: tokens.textPrimary,
                          }}
                        />
                        <button
                          onClick={() => setNewPublic(!newPublic)}
                          className="flex items-center gap-2 text-xs cursor-pointer"
                          style={{ color: tokens.textMuted }}
                        >
                          {newPublic ? <Globe size={13} style={{ color: modeColor }} /> : <Lock size={13} />}
                          <span>{newPublic ? 'Public collection' : 'Private collection'}</span>
                        </button>
                        <div className="flex gap-2">
                          <button
                            onClick={() => setCreating(false)}
                            className="flex-1 py-2 text-sm rounded-xl cursor-pointer hover:opacity-70 transition-opacity"
                            style={{ backgroundColor: tokens.surfaceBg, color: tokens.textMuted }}
                          >
                            Cancel
                          </button>
                          <button
                            onClick={handleCreateAndAdd}
                            disabled={!newName.trim() || savingNew}
                            className="flex-1 py-2 text-sm font-medium rounded-xl cursor-pointer hover:opacity-80 transition-opacity disabled:opacity-40 flex items-center justify-center gap-1.5"
                            style={{ backgroundColor: modeColor, color: '#fff' }}
                          >
                            {savingNew ? <Loader2 size={14} className="animate-spin" /> : <Check size={14} />}
                            Create & Save
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  ) : (
                    <button
                      onClick={() => setCreating(true)}
                      className="w-full flex items-center gap-3 px-3 py-3 rounded-xl text-left transition-all cursor-pointer hover:opacity-80"
                      style={{
                        border: `1.5px dashed ${tokens.cardBorder}`,
                        backgroundColor: 'transparent',
                      }}
                    >
                      <div
                        className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0"
                        style={{ backgroundColor: `${modeColor}10` }}
                      >
                        <Plus size={16} style={{ color: modeColor }} />
                      </div>
                      <p className="text-sm font-medium" style={{ color: modeColor }}>
                        New collection
                      </p>
                    </button>
                  )}
                </>
              )}
            </div>

            {/* Footer */}
            <div
              className="px-5 py-3 flex justify-end"
              style={{ borderTop: `1px solid ${tokens.cardBorder}` }}
            >
              <button
                onClick={handleClose}
                className="px-5 py-2 text-sm font-medium rounded-xl cursor-pointer hover:opacity-80 transition-opacity"
                style={{ backgroundColor: tokens.surfaceBg, color: tokens.textPrimary }}
              >
                Done
              </button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}