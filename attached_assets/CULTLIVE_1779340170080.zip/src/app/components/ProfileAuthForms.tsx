/**
 * ProfileAuthForms — Guest / Sign-in / Sign-up views for the profile drawer.
 * Adapts to neutral editorial design when no mode is selected.
 */
import { useState } from 'react';
import { motion } from 'motion/react';
import { Eye, EyeOff, Loader2, AlertCircle, ArrowLeft, CheckCircle2, Plus } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useMode } from '../context/ModeContext';
import { useTranslation } from 'react-i18next';
import { Link } from 'react-router';

type AuthView = 'guest' | 'signin' | 'signup';

interface ProfileAuthFormsProps {
  onClose: () => void;
  tokens: {
    surfaceBg: string;
    textPrimary: string;
    textMuted: string;
    cardBorder: string;
  };
  modeColor?: string;
}

// ── Neutral editorial palette (inline for independence) ──
const NP = {
  bg: '#FAFAF8',
  bgAlt: '#F5F3F0',
  text: '#1A1A1A',
  textMuted: '#B5B0A8',
  border: '#E8E4DE',
  borderSubtle: '#F0EDE8',
  accent: '#1A1A1A',
  accentText: '#FAFAF8',
};

export function ProfileAuthForms({ onClose, tokens, modeColor }: ProfileAuthFormsProps) {
  const { signIn, signUp } = useAuth();
  const { currentMode } = useMode();
  const { i18n } = useTranslation();
  const isZh = i18n.language?.startsWith('zh');
  const isNeutral = !currentMode;

  const [authView, setAuthView] = useState<AuthView>('guest');

  // Sign-in state
  const [signInEmail, setSignInEmail] = useState('');
  const [signInPassword, setSignInPassword] = useState('');
  const [showSignInPassword, setShowSignInPassword] = useState(false);
  const [signInLoading, setSignInLoading] = useState(false);
  const [signInError, setSignInError] = useState('');

  // Sign-up state
  const [signUpName, setSignUpName] = useState('');
  const [signUpEmail, setSignUpEmail] = useState('');
  const [signUpPassword, setSignUpPassword] = useState('');
  const [showSignUpPassword, setShowSignUpPassword] = useState(false);
  const [signUpLoading, setSignUpLoading] = useState(false);
  const [signUpError, setSignUpError] = useState('');

  const passwordChecks = [
    { label: isZh ? '至少6個字元' : 'At least 6 characters', valid: signUpPassword.length >= 6 },
    { label: isZh ? '包含數字' : 'Contains a number', valid: /\d/.test(signUpPassword) },
  ];

  const allValid = passwordChecks.every((c) => c.valid);

  // ── Derived design values ──
  const accent = isNeutral ? NP.accent : (modeColor || '#8338EC');
  const accentText = isNeutral ? NP.accentText : '#FFFFFF';
  const textPrimary = isNeutral ? NP.text : tokens.textPrimary;
  const textMuted = isNeutral ? NP.textMuted : tokens.textMuted;
  const surfaceBg = isNeutral ? NP.bgAlt : tokens.surfaceBg;
  const borderColor = isNeutral ? NP.border : tokens.cardBorder;
  const radius = isNeutral ? '4px' : '12px';
  const radiusInput = isNeutral ? '4px' : '8px';
  const checkColor = isNeutral ? NP.accent : '#22C55E';
  const checkColorMuted = isNeutral ? NP.border : '#D1D5DB';

  // Micro-label for neutral editorial
  const micro: React.CSSProperties = isNeutral
    ? { fontSize: '0.55rem', fontWeight: 600, letterSpacing: '0.18em', textTransform: 'uppercase', fontFamily: "'Inter', sans-serif" }
    : {};

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!signInEmail || !signInPassword) {
      setSignInError(isZh ? '請輸入電子郵件和密碼。' : 'Please enter your email and password.');
      return;
    }
    setSignInError('');
    setSignInLoading(true);
    try {
      await signIn(signInEmail, signInPassword);
      onClose();
    } catch (err: any) {
      console.log('Login error:', err);
      setSignInError(err.message || (isZh ? '電子郵件或密碼無效。' : 'Invalid email or password.'));
    } finally {
      setSignInLoading(false);
    }
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!signUpEmail || !signUpPassword) {
      setSignUpError(isZh ? '請填寫所有必填欄位。' : 'Please fill in all required fields.');
      return;
    }
    if (!allValid) {
      setSignUpError(isZh ? '請符合所有密碼要求。' : 'Please meet all password requirements.');
      return;
    }
    setSignUpError('');
    setSignUpLoading(true);
    try {
      await signUp(signUpEmail, signUpPassword, signUpName || signUpEmail.split('@')[0]);
      onClose();
    } catch (err: any) {
      console.log('Signup error:', err);
      setSignUpError(err.message || (isZh ? '建立帳號失敗。' : 'Failed to create account.'));
    } finally {
      setSignUpLoading(false);
    }
  };

  // ── Error banner ──
  const ErrorBanner = ({ message }: { message: string }) => (
    <motion.div
      initial={{ opacity: 0, y: -8 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex items-center gap-2 p-3 mb-4 text-xs"
      style={{
        backgroundColor: 'rgba(220,38,38,0.06)',
        color: '#DC2626',
        border: '1px solid rgba(220,38,38,0.1)',
        borderRadius: radius,
      }}
    >
      <AlertCircle size={14} />
      <span>{message}</span>
    </motion.div>
  );

  // ── Input field ──
  const inputStyle: React.CSSProperties = {
    backgroundColor: surfaceBg,
    border: `1px solid ${borderColor}`,
    color: textPrimary,
    borderRadius: radiusInput,
  };

  const labelStyle: React.CSSProperties = isNeutral
    ? { ...micro, display: 'block', marginBottom: '0.5rem', color: textMuted }
    : { display: 'block', fontSize: '0.75rem', fontWeight: 500, marginBottom: '0.375rem', color: textMuted };

  // ═══════════════════════════════════════════════════════════
  // Guest view
  // ═══════════════════════════════════════════════════════════
  if (authView === 'guest') {
    return (
      <div className="flex-1 flex flex-col justify-center px-6 pb-6 overflow-y-auto">
        <div className="text-center">
          {/* Branding */}
          {isNeutral ? (
            <>
              <p style={{ fontFamily: "'Archivo Black', sans-serif", fontSize: '1.1rem', color: NP.text, marginBottom: '0.25rem', letterSpacing: '-0.01em' }}>
                CULTIVE
              </p>
              <p style={{ ...micro, color: NP.textMuted, marginBottom: '1.5rem', fontSize: '0.5rem' }}>
                {isZh ? '文化活 — 登入以儲存活動' : 'SIGN IN TO SAVE EVENTS & PREFERENCES'}
              </p>
            </>
          ) : (
            <>
              <p className="text-sm font-medium mb-1" style={{ color: textPrimary }}>
                {isZh ? '歡迎來到 CULTIVE' : 'Welcome to CULTIVE'}
              </p>
              <p className="text-xs mb-6" style={{ color: textMuted }}>
                {isZh ? '登入以儲存活動和偏好設定' : 'Sign in to save events and preferences'}
              </p>
            </>
          )}

          <div className="flex flex-col gap-2.5 w-full">
            <button
              onClick={() => setAuthView('signin')}
              className="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-medium transition-opacity hover:opacity-80 cursor-pointer"
              style={{
                backgroundColor: accent,
                color: accentText,
                borderRadius: radius,
                ...(isNeutral ? { ...micro, fontSize: '0.6rem', padding: '0.75rem 1.25rem' } : {}),
              }}
            >
              {isZh ? '登入' : isNeutral ? 'SIGN IN' : 'Sign in'}
            </button>
            <button
              onClick={() => setAuthView('signup')}
              className="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-medium transition-opacity hover:opacity-80 cursor-pointer"
              style={{
                backgroundColor: isNeutral ? 'transparent' : surfaceBg,
                color: textPrimary,
                border: `1px solid ${borderColor}`,
                borderRadius: radius,
                ...(isNeutral ? { ...micro, fontSize: '0.6rem', padding: '0.75rem 1.25rem' } : {}),
              }}
            >
              {isZh ? '建立帳號' : isNeutral ? 'CREATE ACCOUNT' : 'Create account'}
            </button>
          </div>

          <div className="mt-6" style={{ height: 1, backgroundColor: borderColor, width: '100%' }} />
          <Link to="/contribute" onClick={onClose}
            className="mt-4 inline-flex items-center gap-2 transition-opacity hover:opacity-70"
            style={{
              color: textMuted,
              textDecoration: 'none',
              ...(isNeutral ? { ...micro, fontSize: '0.5rem' } : { fontSize: '0.75rem' }),
            }}>
            <Plus size={14} />
            {isZh ? '提交活動' : isNeutral ? 'SUBMIT AN EVENT' : 'Submit an Event'}
          </Link>
        </div>
      </div>
    );
  }

  // ═══════════════════════════════════════════════════════════
  // Sign-in view
  // ═══════════════════════════════════════════════════════════
  if (authView === 'signin') {
    return (
      <div className="flex-1 flex flex-col px-5 py-5 overflow-y-auto">
        <button
          onClick={() => setAuthView('guest')}
          className="flex items-center gap-1.5 mb-4 transition-opacity hover:opacity-70 cursor-pointer"
          style={{
            color: textMuted,
            ...(isNeutral ? { ...micro, fontSize: '0.5rem' } : { fontSize: '0.75rem' }),
          }}
        >
          <ArrowLeft size={14} />
          {isZh ? '返回' : isNeutral ? 'BACK' : 'Back'}
        </button>

        <div className="mb-6 text-center">
          {isNeutral ? (
            <>
              <h2 style={{ fontFamily: "'Archivo Black', sans-serif", fontSize: '1rem', color: NP.text, marginBottom: '0.25rem' }}>
                {isZh ? '歡迎回來' : 'WELCOME BACK'}
              </h2>
              <p style={{ ...micro, color: NP.textMuted, fontSize: '0.5rem' }}>
                {isZh ? '登入你的帳號' : 'SIGN IN TO YOUR ACCOUNT'}
              </p>
            </>
          ) : (
            <>
              <h2 className="text-lg font-semibold" style={{ color: textPrimary }}>
                {isZh ? '歡迎回來' : 'Welcome back'}
              </h2>
              <p className="mt-1 text-xs" style={{ color: textMuted }}>
                {isZh ? '登入你的帳號' : 'Sign in to your account'}
              </p>
            </>
          )}
        </div>

        {signInError && <ErrorBanner message={signInError} />}

        <form onSubmit={handleSignIn} className="space-y-4">
          <div>
            <label style={labelStyle}>
              {isZh ? '電子郵件' : isNeutral ? 'EMAIL' : 'Email'}
            </label>
            <input
              type="email"
              value={signInEmail}
              onChange={(e) => setSignInEmail(e.target.value)}
              placeholder={isZh ? '你的電子郵件' : 'you@example.com'}
              className="w-full px-3 py-2.5 text-sm outline-none transition-all"
              style={inputStyle}
            />
          </div>

          <div>
            <label style={labelStyle}>
              {isZh ? '密碼' : isNeutral ? 'PASSWORD' : 'Password'}
            </label>
            <div className="relative">
              <input
                type={showSignInPassword ? 'text' : 'password'}
                value={signInPassword}
                onChange={(e) => setSignInPassword(e.target.value)}
                placeholder={isZh ? '輸入你的密碼' : 'Enter your password'}
                className="w-full px-3 py-2.5 pr-10 text-sm outline-none transition-all"
                style={inputStyle}
              />
              <button
                type="button"
                onClick={() => setShowSignInPassword(!showSignInPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 p-1 cursor-pointer"
                style={{ color: textMuted }}
              >
                {showSignInPassword ? <EyeOff size={14} /> : <Eye size={14} />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={signInLoading}
            className="w-full flex items-center justify-center gap-2 py-3 font-semibold transition-all cursor-pointer"
            style={{
              backgroundColor: accent,
              color: accentText,
              opacity: signInLoading ? 0.7 : 1,
              borderRadius: radius,
              ...(isNeutral ? { ...micro, fontSize: '0.6rem' } : { fontSize: '0.875rem' }),
            }}
          >
            {signInLoading ? (
              <>
                <Loader2 size={14} className="animate-spin" />
                {isZh ? '登入中…' : isNeutral ? 'SIGNING IN…' : 'Signing in...'}
              </>
            ) : (
              isZh ? '登入' : isNeutral ? 'SIGN IN' : 'Sign in'
            )}
          </button>
        </form>

        <div className="mt-4 text-center">
          <p style={{ color: textMuted, fontSize: isNeutral ? '0.7rem' : '0.75rem' }}>
            {isZh ? '沒有帳號？' : "Don't have an account?"}{' '}
            <button
              onClick={() => setAuthView('signup')}
              className="font-medium transition-opacity hover:opacity-70 cursor-pointer"
              style={{ color: accent, ...(isNeutral ? { ...micro, fontSize: '0.55rem' } : {}) }}
            >
              {isZh ? '註冊' : isNeutral ? 'SIGN UP' : 'Sign up'}
            </button>
          </p>
        </div>
      </div>
    );
  }

  // ═══════════════════════════════════════════════════════════
  // Sign-up view
  // ═══════════════════════════════════════════════════════════
  return (
    <div className="flex-1 flex flex-col px-5 py-5 overflow-y-auto">
      <button
        onClick={() => setAuthView('guest')}
        className="flex items-center gap-1.5 mb-4 transition-opacity hover:opacity-70 cursor-pointer"
        style={{
          color: textMuted,
          ...(isNeutral ? { ...micro, fontSize: '0.5rem' } : { fontSize: '0.75rem' }),
        }}
      >
        <ArrowLeft size={14} />
        {isZh ? '返回' : isNeutral ? 'BACK' : 'Back'}
      </button>

      <div className="mb-6 text-center">
        {isNeutral ? (
          <>
            <h2 style={{ fontFamily: "'Archivo Black', sans-serif", fontSize: '1rem', color: NP.text, marginBottom: '0.25rem' }}>
              {isZh ? '建立帳號' : 'CREATE ACCOUNT'}
            </h2>
            <p style={{ ...micro, color: NP.textMuted, fontSize: '0.5rem' }}>
              {isZh ? '加入社群，儲存活動' : 'JOIN THE COMMUNITY & SAVE EVENTS'}
            </p>
          </>
        ) : (
          <>
            <h2 className="text-lg font-semibold" style={{ color: textPrimary }}>
              {isZh ? '建立帳號' : 'Create your account'}
            </h2>
            <p className="mt-1 text-xs" style={{ color: textMuted }}>
              {isZh ? '加入社群，儲存活動' : 'Join the community and save events'}
            </p>
          </>
        )}
      </div>

      {signUpError && <ErrorBanner message={signUpError} />}

      <form onSubmit={handleSignUp} className="space-y-4">
        <div>
          <label style={labelStyle}>
            {isZh ? '名稱' : isNeutral ? 'NAME' : 'Name'}{' '}
            <span style={{ fontWeight: 400, opacity: 0.7 }}>
              ({isZh ? '選填' : isNeutral ? 'OPTIONAL' : 'optional'})
            </span>
          </label>
          <input
            type="text"
            value={signUpName}
            onChange={(e) => setSignUpName(e.target.value)}
            placeholder={isZh ? '你的名稱' : 'Your name'}
            className="w-full px-3 py-2.5 text-sm outline-none transition-all"
            style={inputStyle}
          />
        </div>

        <div>
          <label style={labelStyle}>
            {isZh ? '電子郵件' : isNeutral ? 'EMAIL' : 'Email'}
          </label>
          <input
            type="email"
            value={signUpEmail}
            onChange={(e) => setSignUpEmail(e.target.value)}
            placeholder={isZh ? '你的電子郵件' : 'you@example.com'}
            className="w-full px-3 py-2.5 text-sm outline-none transition-all"
            style={inputStyle}
          />
        </div>

        <div>
          <label style={labelStyle}>
            {isZh ? '密碼' : isNeutral ? 'PASSWORD' : 'Password'}
          </label>
          <div className="relative">
            <input
              type={showSignUpPassword ? 'text' : 'password'}
              value={signUpPassword}
              onChange={(e) => setSignUpPassword(e.target.value)}
              placeholder={isZh ? '建立密碼' : 'Create a password'}
              className="w-full px-3 py-2.5 pr-10 text-sm outline-none transition-all"
              style={inputStyle}
            />
            <button
              type="button"
              onClick={() => setShowSignUpPassword(!showSignUpPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-1 cursor-pointer"
              style={{ color: textMuted }}
            >
              {showSignUpPassword ? <EyeOff size={14} /> : <Eye size={14} />}
            </button>
          </div>

          {signUpPassword.length > 0 && (
            <div className="mt-2 space-y-1">
              {passwordChecks.map((check) => (
                <div key={check.label} className="flex items-center gap-1.5">
                  <CheckCircle2
                    size={11}
                    style={{ color: check.valid ? checkColor : checkColorMuted }}
                  />
                  <span
                    className="text-[10px]"
                    style={{ color: check.valid ? checkColor : textMuted }}
                  >
                    {check.label}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        <button
          type="submit"
          disabled={signUpLoading}
          className="w-full flex items-center justify-center gap-2 py-3 font-semibold transition-all cursor-pointer"
          style={{
            backgroundColor: accent,
            color: accentText,
            opacity: signUpLoading ? 0.7 : 1,
            borderRadius: radius,
            ...(isNeutral ? { ...micro, fontSize: '0.6rem' } : { fontSize: '0.875rem' }),
          }}
        >
          {signUpLoading ? (
            <>
              <Loader2 size={14} className="animate-spin" />
              {isZh ? '建立中…' : isNeutral ? 'CREATING ACCOUNT…' : 'Creating account...'}
            </>
          ) : (
            isZh ? '建立帳號' : isNeutral ? 'CREATE ACCOUNT' : 'Create account'
          )}
        </button>
      </form>

      <div className="mt-4 text-center">
        <p style={{ color: textMuted, fontSize: isNeutral ? '0.7rem' : '0.75rem' }}>
          {isZh ? '已有帳號？' : 'Already have an account?'}{' '}
          <button
            onClick={() => setAuthView('signin')}
            className="font-medium transition-opacity hover:opacity-70 cursor-pointer"
            style={{ color: accent, ...(isNeutral ? { ...micro, fontSize: '0.55rem' } : {}) }}
          >
            {isZh ? '登入' : isNeutral ? 'SIGN IN' : 'Sign in'}
          </button>
        </p>
      </div>
    </div>
  );
}
