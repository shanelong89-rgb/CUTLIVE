/**
 * NotificationBell — nav bell icon with unread badge + dropdown panel
 * Adapts to neutral editorial design when no mode is selected.
 */
import { useState, useRef, useEffect } from 'react';
import { Bell, X, Check, CheckCheck, Calendar, Sparkles, FolderOpen, Info, Trash2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Link } from 'react-router';
import { useTranslation } from 'react-i18next';
import { useNotifications, type Notification } from '../context/NotificationsContext';
import { useMode } from '../context/ModeContext';
import { useAuth } from '../context/AuthContext';
import { getDesignTokens } from '../data/mode-styles';
import { modeConfig } from '../data/mock-data';
import { useNeutralTheme, type NeutralPalette } from '../context/NeutralThemeContext';

const notifIcon = (type: Notification['type']) => {
  switch (type) {
    case 'event_reminder': return Calendar;
    case 'new_event': return Sparkles;
    case 'collection_shared': return FolderOpen;
    default: return Info;
  }
};

const notifColor = (type: Notification['type'], modeColor: string) => {
  switch (type) {
    case 'event_reminder': return '#F59E0B';
    case 'new_event': return modeColor;
    case 'collection_shared': return '#3B82F6';
    default: return '#6B7280';
  }
};

function timeAgo(iso: string, isZh: boolean): string {
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return isZh ? '剛剛' : 'Just now';
  if (m < 60) return isZh ? `${m}分鐘前` : `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return isZh ? `${h}小時前` : `${h}h ago`;
  const d = Math.floor(h / 24);
  return isZh ? `${d}天前` : `${d}d ago`;
}

interface NotificationBellProps {
  navBtnBg: string;
  navTextSecondaryColor: string;
  tokens: ReturnType<typeof getDesignTokens>;
  isDegen?: boolean;
  isFoodie?: boolean;
}

export function NotificationBell({ navBtnBg, navTextSecondaryColor, tokens, isDegen, isFoodie }: NotificationBellProps) {
  const [open, setOpen] = useState(false);
  const { notifications, unreadCount, markAsRead, deleteNotification } = useNotifications();
  const { currentMode } = useMode();
  const { user } = useAuth();
  const { i18n } = useTranslation();
  const isZh = i18n.language?.startsWith('zh');
  const panelRef = useRef<HTMLDivElement>(null);

  const isNeutral = !currentMode;
  let np: NeutralPalette | null = null;
  try { const ctx = useNeutralTheme(); np = ctx.palette; } catch { /* outside provider */ }

  const modeColor = isNeutral
    ? '#1A1A1A'
    : currentMode !== 'lifestyle'
      ? modeConfig[currentMode!].color
      : '#2D6A4F';

  // Derive panel colors — neutral uses editorial palette
  const panelBg = isNeutral && np ? np.bg : tokens.pageBg;
  const panelBorder = isNeutral && np ? np.border : tokens.cardBorder;
  const panelBorderSubtle = isNeutral && np ? np.borderSubtle : tokens.cardBorder;
  const textPrimary = isNeutral && np ? np.text : tokens.textPrimary;
  const textMuted = isNeutral && np ? np.textMuted : tokens.textMuted;
  const surfaceBg = isNeutral && np ? np.bgAlt : tokens.surfaceBg;
  const accentBg = isNeutral ? 'rgba(26,26,26,0.06)' : `${modeColor}12`;
  const accentBgLight = isNeutral ? 'rgba(26,26,26,0.04)' : `${modeColor}06`;
  const radius = isNeutral ? '4px' : '16px';
  const radiusSm = isNeutral ? '2px' : '9999px';
  const radiusBtn = isNeutral ? '4px' : isDegen ? '4px' : isFoodie ? '24px' : '9999px';

  // Close on outside click
  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (panelRef.current && !panelRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open]);

  // Mark all unread as read when opening
  const handleOpen = () => {
    setOpen(prev => {
      const next = !prev;
      if (next && unreadCount > 0) {
        const unreadIds = notifications.filter(n => !n.read).map(n => n.id);
        markAsRead(unreadIds);
      }
      return next;
    });
  };

  if (!user) return null;

  const recent = notifications.slice(0, 8);

  // ── Micro-label style for neutral editorial ──
  const microLabel: React.CSSProperties = isNeutral
    ? { fontSize: '0.55rem', fontWeight: 600, letterSpacing: '0.18em', textTransform: 'uppercase', fontFamily: "'Inter', sans-serif" }
    : {};

  return (
    <div className="relative" ref={panelRef}>
      <button
        onClick={handleOpen}
        className="relative flex items-center gap-1.5 px-3 py-1.5 text-xs transition-all duration-300 cursor-pointer"
        style={{
          backgroundColor: navBtnBg,
          color: navTextSecondaryColor,
          borderRadius: radiusBtn,
        }}
        aria-label={isZh ? '通知' : 'Notifications'}
      >
        <Bell size={13} />
        {unreadCount > 0 && (
          <motion.span
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="absolute -top-1 -right-1 min-w-[16px] h-4 flex items-center justify-center text-[9px] font-bold"
            style={{
              backgroundColor: isNeutral ? '#1A1A1A' : modeColor,
              color: isNeutral ? '#FAFAF8' : '#fff',
              padding: '0 3px',
              borderRadius: isNeutral ? '2px' : '9999px',
            }}
          >
            {unreadCount > 9 ? '9+' : unreadCount}
          </motion.span>
        )}
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -8, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.97 }}
            transition={{ duration: 0.15, ease: 'easeOut' }}
            className="absolute right-0 top-full mt-2 w-80 sm:w-[340px] z-[2000] overflow-hidden"
            style={{
              backgroundColor: panelBg,
              border: `1px solid ${panelBorder}`,
              borderRadius: radius,
              boxShadow: isNeutral
                ? '0 4px 20px rgba(0,0,0,0.08)'
                : '0 8px 32px rgba(0,0,0,0.12), 0 2px 8px rgba(0,0,0,0.06)',
            }}
          >
            {/* Header */}
            <div
              className="flex items-center justify-between px-4 py-3"
              style={{ borderBottom: `1px solid ${panelBorder}` }}
            >
              <div className="flex items-center gap-2">
                {!isNeutral && <Bell size={14} style={{ color: modeColor }} />}
                <span
                  style={{
                    color: textPrimary,
                    ...(isNeutral
                      ? { ...microLabel, fontSize: '0.6rem' }
                      : { fontSize: '0.875rem', fontWeight: 600 }),
                  }}
                >
                  {isZh ? '通知' : isNeutral ? 'NOTIFICATIONS' : 'Notifications'}
                </span>
              </div>
              <div className="flex items-center gap-2">
                {notifications.length > 0 && (
                  <button
                    onClick={() => markAsRead(notifications.map(n => n.id))}
                    className="flex items-center gap-1 text-[10px] px-2 py-1 cursor-pointer transition-opacity hover:opacity-70"
                    style={{
                      backgroundColor: accentBg,
                      color: isNeutral ? '#1A1A1A' : modeColor,
                      borderRadius: radiusSm,
                      ...(isNeutral ? { ...microLabel, fontSize: '0.5rem' } : {}),
                    }}
                  >
                    <CheckCheck size={10} />
                    {isZh ? '全部已讀' : isNeutral ? 'ALL READ' : 'All read'}
                  </button>
                )}
                <button
                  onClick={() => setOpen(false)}
                  className="p-1 cursor-pointer hover:opacity-70"
                  style={{ color: textMuted, borderRadius: isNeutral ? '2px' : '9999px' }}
                >
                  <X size={14} />
                </button>
              </div>
            </div>

            {/* Notification list */}
            <div className="max-h-80 overflow-y-auto">
              {recent.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-10 px-4 text-center">
                  <div
                    className="w-10 h-10 flex items-center justify-center mb-3"
                    style={{
                      backgroundColor: accentBg,
                      borderRadius: isNeutral ? '4px' : '9999px',
                    }}
                  >
                    <Bell size={18} style={{ color: isNeutral ? '#1A1A1A' : modeColor, opacity: 0.5 }} />
                  </div>
                  <p
                    style={{
                      color: textPrimary,
                      ...(isNeutral
                        ? { ...microLabel, fontSize: '0.6rem', marginBottom: '0.25rem' }
                        : { fontSize: '0.875rem', fontWeight: 500 }),
                    }}
                  >
                    {isZh ? '暫無通知' : isNeutral ? 'NO NOTIFICATIONS YET' : 'No notifications yet'}
                  </p>
                  <p className="text-xs mt-1" style={{ color: textMuted, fontSize: isNeutral ? '0.7rem' : undefined }}>
                    {isZh ? '我們會通知你即將舉行的活動' : "We'll let you know about upcoming events"}
                  </p>
                </div>
              ) : (
                recent.map((notif, i) => {
                  const Icon = notifIcon(notif.type);
                  const color = notifColor(notif.type, modeColor);
                  return (
                    <motion.div
                      key={notif.id}
                      initial={{ opacity: 0, x: -8 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.04 }}
                      className="group flex items-start gap-3 px-4 py-3 transition-colors hover:opacity-90"
                      style={{
                        borderBottom: i < recent.length - 1 ? `1px solid ${panelBorderSubtle}` : undefined,
                        backgroundColor: !notif.read ? accentBgLight : 'transparent',
                      }}
                    >
                      <div
                        className="flex-shrink-0 w-8 h-8 flex items-center justify-center mt-0.5"
                        style={{
                          backgroundColor: `${color}15`,
                          borderRadius: isNeutral ? '4px' : '9999px',
                        }}
                      >
                        <Icon size={14} style={{ color }} />
                      </div>
                      <div className="flex-1 min-w-0">
                        {notif.actionUrl ? (
                          <Link
                            to={notif.actionUrl}
                            onClick={() => setOpen(false)}
                            className="block"
                          >
                            <p className="text-[13px] font-medium leading-snug" style={{ color: textPrimary }}>
                              {notif.title}
                            </p>
                            <p className="text-[11px] mt-0.5 leading-snug line-clamp-2" style={{ color: textMuted }}>
                              {notif.message}
                            </p>
                          </Link>
                        ) : (
                          <>
                            <p className="text-[13px] font-medium leading-snug" style={{ color: textPrimary }}>
                              {notif.title}
                            </p>
                            <p className="text-[11px] mt-0.5 leading-snug line-clamp-2" style={{ color: textMuted }}>
                              {notif.message}
                            </p>
                          </>
                        )}
                        <p className="text-[10px] mt-1" style={{ color: textMuted, opacity: 0.6 }}>
                          {timeAgo(notif.createdAt, !!isZh)}
                        </p>
                      </div>
                      <div className="flex flex-col items-end gap-1.5 flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                        {!notif.read && (
                          <button
                            onClick={() => markAsRead([notif.id])}
                            className="p-1 cursor-pointer hover:opacity-70"
                            title={isZh ? '標記已讀' : 'Mark as read'}
                            style={{ color: isNeutral ? '#1A1A1A' : modeColor, borderRadius: isNeutral ? '2px' : '9999px' }}
                          >
                            <Check size={11} />
                          </button>
                        )}
                        <button
                          onClick={() => deleteNotification(notif.id)}
                          className="p-1 cursor-pointer hover:opacity-70"
                          title={isZh ? '刪除' : 'Delete'}
                          style={{ color: textMuted, borderRadius: isNeutral ? '2px' : '9999px' }}
                        >
                          <Trash2 size={11} />
                        </button>
                      </div>
                    </motion.div>
                  );
                })
              )}
            </div>

            {/* Footer */}
            <div
              className="px-4 py-2.5 flex items-center justify-between"
              style={{ borderTop: `1px solid ${panelBorder}` }}
            >
              <Link
                to="/profile?tab=notifications"
                onClick={() => setOpen(false)}
                className="transition-opacity hover:opacity-70"
                style={{
                  color: isNeutral ? '#1A1A1A' : modeColor,
                  textDecoration: 'none',
                  ...(isNeutral ? { ...microLabel, fontSize: '0.5rem' } : { fontSize: '0.6875rem' }),
                }}
              >
                {isZh ? '通知設定' : isNeutral ? 'NOTIFICATION SETTINGS' : 'Notification Settings'}
              </Link>
              <span
                style={{
                  color: textMuted,
                  ...(isNeutral ? { ...microLabel, fontSize: '0.5rem' } : { fontSize: '0.625rem' }),
                }}
              >
                {notifications.length} {isZh ? '則' : 'total'}
              </span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
