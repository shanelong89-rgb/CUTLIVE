/**
 * CategoryEditor — inline category tag editor for moderators in SubmissionPipeline.
 * Allows adding/removing category tags and saving to backend.
 */
import { useState, useCallback } from 'react';
import { Tag, Plus, X, Loader2, Check } from 'lucide-react';
import { resolveCategories, getCategoryLabel, getCategoryColor } from './CategoryPills';
import { updateSubmissionFields } from '../hooks/useAdminApi';

const ALL_CATEGORIES = [
  'run-clubs', 'wellness', 'hikes', 'coffee-raves', 'workshops',
  'meetups', 'nightlife', 'art', 'food', 'family', 'other',
];

const N = {
  text: '#1A1A1A',
  textMuted: '#9A9A9A',
  border: 'rgba(0,0,0,0.06)',
  surface: '#FFFFFF',
  surfaceMuted: '#F3F3F0',
  green: '#16A34A',
  greenBg: 'rgba(22,163,74,0.06)',
};

interface Props {
  submission: any;
  accessToken: string;
  onUpdate: () => Promise<void>;
  onToast: (msg: string, type?: 'ok' | 'err') => void;
}

export function CategoryEditor({ submission, accessToken, onUpdate, onToast }: Props) {
  const current = resolveCategories(submission);
  const [editing, setEditing] = useState(false);
  const [selected, setSelected] = useState<string[]>(current);
  const [saving, setSaving] = useState(false);
  const [showPicker, setShowPicker] = useState(false);

  const toggle = useCallback((cat: string) => {
    setSelected(prev =>
      prev.includes(cat) ? prev.filter(c => c !== cat) : [...prev, cat]
    );
  }, []);

  const handleSave = useCallback(async () => {
    setSaving(true);
    try {
      await updateSubmissionFields(accessToken, submission.id, {
        categories: selected,
        category: selected[0] || '',
      });
      await onUpdate();
      onToast('Categories updated');
      setEditing(false);
      setShowPicker(false);
    } catch (err) {
      console.log('Category update failed:', err);
      onToast(`Failed to update categories: ${err}`, 'err');
    }
    setSaving(false);
  }, [accessToken, submission.id, selected, onUpdate, onToast]);

  const handleCancel = useCallback(() => {
    setSelected(current);
    setEditing(false);
    setShowPicker(false);
  }, [current]);

  const hasChanges = JSON.stringify(selected.sort()) !== JSON.stringify([...current].sort());
  const available = ALL_CATEGORIES.filter(c => !selected.includes(c));

  if (!editing) {
    return (
      <div className="flex items-center gap-2 mt-3 mb-1">
        <Tag size={12} style={{ color: N.textMuted }} />
        <span className="text-[10px] font-medium uppercase tracking-wider" style={{ color: N.textMuted }}>
          Categories
        </span>
        {current.length > 0 ? (
          <div className="flex flex-wrap gap-1 ml-1">
            {current.map(cat => {
              const color = getCategoryColor(cat);
              return (
                <span
                  key={cat}
                  className="inline-flex items-center px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider"
                  style={{
                    backgroundColor: `${color}14`,
                    color,
                    borderRadius: '4px',
                  }}
                >
                  {getCategoryLabel(cat)}
                </span>
              );
            })}
          </div>
        ) : (
          <span className="text-[11px] italic" style={{ color: N.textMuted }}>None assigned</span>
        )}
        <button
          onClick={() => setEditing(true)}
          className="ml-auto text-[11px] font-medium cursor-pointer hover:underline"
          style={{ color: '#2563EB' }}
        >
          Edit
        </button>
      </div>
    );
  }

  return (
    <div className="mt-3 mb-1 p-3" style={{
      backgroundColor: N.surfaceMuted,
      borderRadius: '10px',
      border: `1px solid ${N.border}`,
    }}>
      <div className="flex items-center justify-between mb-2.5">
        <div className="flex items-center gap-1.5">
          <Tag size={12} style={{ color: N.text }} />
          <span className="text-[10px] font-medium uppercase tracking-wider" style={{ color: N.text }}>
            Edit Categories
          </span>
        </div>
        <div className="flex items-center gap-1.5">
          {hasChanges && (
            <button
              onClick={handleSave}
              disabled={saving}
              className="flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium cursor-pointer transition-opacity hover:opacity-80"
              style={{ backgroundColor: N.green, color: '#fff', borderRadius: '6px' }}
            >
              {saving ? <Loader2 size={10} className="animate-spin" /> : <Check size={10} />}
              Save
            </button>
          )}
          <button
            onClick={handleCancel}
            className="px-2 py-1 text-[11px] font-medium cursor-pointer"
            style={{ color: N.textMuted, borderRadius: '6px' }}
          >
            Cancel
          </button>
        </div>
      </div>

      {/* Selected categories */}
      <div className="flex flex-wrap gap-1.5 mb-2">
        {selected.map(cat => {
          const color = getCategoryColor(cat);
          return (
            <button
              key={cat}
              onClick={() => toggle(cat)}
              className="inline-flex items-center gap-1 px-2 py-1 text-[10px] font-semibold uppercase tracking-wider cursor-pointer transition-all hover:opacity-70"
              style={{
                backgroundColor: `${color}20`,
                color,
                borderRadius: '5px',
                border: `1px solid ${color}30`,
              }}
            >
              {getCategoryLabel(cat)}
              <X size={9} />
            </button>
          );
        })}
        {selected.length === 0 && (
          <span className="text-[11px] italic py-1" style={{ color: N.textMuted }}>
            Click below to add categories
          </span>
        )}
      </div>

      {/* Available categories to add */}
      {available.length > 0 && (
        <>
          {!showPicker ? (
            <button
              onClick={() => setShowPicker(true)}
              className="flex items-center gap-1 text-[11px] font-medium cursor-pointer hover:underline"
              style={{ color: '#2563EB' }}
            >
              <Plus size={10} /> Add category
            </button>
          ) : (
            <div className="flex flex-wrap gap-1 pt-1" style={{ borderTop: `1px solid ${N.border}` }}>
              {available.map(cat => {
                const color = getCategoryColor(cat);
                return (
                  <button
                    key={cat}
                    onClick={() => toggle(cat)}
                    className="inline-flex items-center gap-1 px-2 py-1 text-[10px] font-medium uppercase tracking-wider cursor-pointer transition-all hover:scale-105"
                    style={{
                      backgroundColor: 'rgba(0,0,0,0.03)',
                      color: N.textMuted,
                      borderRadius: '5px',
                      border: `1px dashed rgba(0,0,0,0.1)`,
                    }}
                  >
                    <Plus size={8} style={{ color }} />
                    {getCategoryLabel(cat)}
                  </button>
                );
              })}
            </div>
          )}
        </>
      )}
    </div>
  );
}
