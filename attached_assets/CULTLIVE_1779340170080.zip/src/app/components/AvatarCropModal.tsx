/**
 * AvatarCropModal — client-side image crop & resize before upload.
 * Uses a canvas-based circular crop preview with drag-to-pan and zoom slider.
 */
import { useState, useRef, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, ZoomIn, ZoomOut, Loader2, RotateCcw } from 'lucide-react';

interface Props {
  file: File;
  isOpen: boolean;
  onClose: () => void;
  onCrop: (croppedBlob: Blob) => void;
  uploading?: boolean;
  accentColor: string;
  pageBg: string;
  surfaceBg: string;
  textPrimary: string;
  textMuted: string;
  cardBorder: string;
  borderRadius: string;
}

const OUTPUT_SIZE = 400; // px, final avatar resolution

export function AvatarCropModal({
  file, isOpen, onClose, onCrop, uploading,
  accentColor, pageBg, surfaceBg, textPrimary, textMuted, cardBorder, borderRadius,
}: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imgRef = useRef<HTMLImageElement | null>(null);
  const [imgLoaded, setImgLoaded] = useState(false);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const dragRef = useRef<{ startX: number; startY: number; startPanX: number; startPanY: number } | null>(null);

  // Load image from file
  useEffect(() => {
    if (!file) return;
    setImgLoaded(false);
    setZoom(1);
    setPan({ x: 0, y: 0 });
    const img = new Image();
    img.onload = () => {
      imgRef.current = img;
      setImgLoaded(true);
    };
    img.src = URL.createObjectURL(file);
    return () => URL.revokeObjectURL(img.src);
  }, [file]);

  // Draw preview
  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    const img = imgRef.current;
    if (!canvas || !img || !imgLoaded) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const size = canvas.width;
    const scale = zoom * Math.max(size / img.width, size / img.height);
    const drawW = img.width * scale;
    const drawH = img.height * scale;
    const dx = (size - drawW) / 2 + pan.x;
    const dy = (size - drawH) / 2 + pan.y;

    // Clear
    ctx.clearRect(0, 0, size, size);

    // Draw image
    ctx.save();
    ctx.beginPath();
    ctx.arc(size / 2, size / 2, size / 2, 0, Math.PI * 2);
    ctx.clip();
    ctx.drawImage(img, dx, dy, drawW, drawH);
    ctx.restore();

    // Overlay ring
    ctx.beginPath();
    ctx.arc(size / 2, size / 2, size / 2 - 2, 0, Math.PI * 2);
    ctx.strokeStyle = accentColor;
    ctx.lineWidth = 3;
    ctx.stroke();
  }, [imgLoaded, zoom, pan, accentColor]);

  useEffect(() => {
    draw();
  }, [draw]);

  // Mouse/touch drag
  const handlePointerDown = (e: React.PointerEvent) => {
    dragRef.current = { startX: e.clientX, startY: e.clientY, startPanX: pan.x, startPanY: pan.y };
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };
  const handlePointerMove = (e: React.PointerEvent) => {
    if (!dragRef.current) return;
    const dx = e.clientX - dragRef.current.startX;
    const dy = e.clientY - dragRef.current.startY;
    setPan({ x: dragRef.current.startPanX + dx, y: dragRef.current.startPanY + dy });
  };
  const handlePointerUp = () => { dragRef.current = null; };

  // Export cropped image
  const handleCrop = () => {
    const img = imgRef.current;
    if (!img) return;

    const outCanvas = document.createElement('canvas');
    outCanvas.width = OUTPUT_SIZE;
    outCanvas.height = OUTPUT_SIZE;
    const ctx = outCanvas.getContext('2d');
    if (!ctx) return;

    const previewSize = canvasRef.current?.width || 280;
    const ratio = OUTPUT_SIZE / previewSize;

    const scale = zoom * Math.max(previewSize / img.width, previewSize / img.height);
    const drawW = img.width * scale * ratio;
    const drawH = img.height * scale * ratio;
    const dx = (OUTPUT_SIZE - drawW) / 2 + pan.x * ratio;
    const dy = (OUTPUT_SIZE - drawH) / 2 + pan.y * ratio;

    ctx.beginPath();
    ctx.arc(OUTPUT_SIZE / 2, OUTPUT_SIZE / 2, OUTPUT_SIZE / 2, 0, Math.PI * 2);
    ctx.clip();
    ctx.drawImage(img, dx, dy, drawW, drawH);

    outCanvas.toBlob(blob => {
      if (blob) onCrop(blob);
    }, 'image/jpeg', 0.92);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
        className="fixed inset-0 z-[2000] flex items-center justify-center p-4"
        style={{ backgroundColor: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(8px)' }}
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }}
          className="w-full max-w-sm p-6"
          style={{ backgroundColor: pageBg, borderRadius: '16px', border: `1px solid ${cardBorder}` }}
          onClick={e => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold" style={{ color: textPrimary }}>Crop Profile Photo</h3>
            <button onClick={onClose} className="p-1 cursor-pointer hover:opacity-70 transition-opacity" style={{ color: textMuted }}>
              <X size={18} />
            </button>
          </div>

          {/* Canvas preview */}
          <div className="flex justify-center mb-4">
            <canvas
              ref={canvasRef}
              width={280}
              height={280}
              className="cursor-grab active:cursor-grabbing"
              style={{ borderRadius: '50%', backgroundColor: surfaceBg }}
              onPointerDown={handlePointerDown}
              onPointerMove={handlePointerMove}
              onPointerUp={handlePointerUp}
              onPointerCancel={handlePointerUp}
            />
          </div>

          {/* Zoom controls */}
          <div className="flex items-center gap-3 mb-5 px-2">
            <ZoomOut size={14} style={{ color: textMuted }} />
            <input
              type="range"
              min={1}
              max={3}
              step={0.05}
              value={zoom}
              onChange={e => setZoom(parseFloat(e.target.value))}
              className="flex-1 h-1.5 rounded-full appearance-none cursor-pointer"
              style={{ accentColor }}
            />
            <ZoomIn size={14} style={{ color: textMuted }} />
            <button
              onClick={() => { setZoom(1); setPan({ x: 0, y: 0 }); }}
              className="p-1.5 cursor-pointer hover:opacity-70 transition-opacity"
              style={{ color: textMuted, backgroundColor: surfaceBg, borderRadius: '6px' }}
              title="Reset"
            >
              <RotateCcw size={13} />
            </button>
          </div>

          {/* Actions */}
          <div className="flex gap-2">
            <button
              onClick={onClose}
              className="flex-1 px-4 py-2.5 text-sm font-medium cursor-pointer hover:opacity-80 transition-opacity"
              style={{ backgroundColor: surfaceBg, color: textPrimary, border: `1px solid ${cardBorder}`, borderRadius }}
            >
              Cancel
            </button>
            <button
              onClick={handleCrop}
              disabled={uploading || !imgLoaded}
              className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium cursor-pointer hover:opacity-80 transition-opacity disabled:opacity-50"
              style={{ backgroundColor: accentColor, color: '#fff', borderRadius }}
            >
              {uploading ? <Loader2 size={14} className="animate-spin" /> : null}
              {uploading ? 'Uploading...' : 'Save Photo'}
            </button>
          </div>

          <p className="text-[10px] text-center mt-3" style={{ color: textMuted }}>
            Drag to reposition, zoom to resize
          </p>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
