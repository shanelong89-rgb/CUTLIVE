import { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { useNavigate } from 'react-router';
import { motion, AnimatePresence } from 'motion/react';
import { Search, X, MapPin, Clock, ArrowUpRight, ArrowRight, ChevronDown, Minus, Sparkles, Loader2, TrendingUp, Building2, Calendar, Navigation, Tag, Flame, Map as MapIcon } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { useData } from '../context/DataContext';
import { useMode } from '../context/ModeContext';
import { getDesignTokens } from '../data/mode-styles';
import { modeConfig, type Venue, type CulturalEvent } from '../data/mock-data';
import { projectId, publicAnonKey } from '../config/supabase';

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-d507b98c`;

const RECENT_SEARCHES_KEY = 'cultive:recent-searches';
const MAX_RECENT = 8;

// ─── Levenshtein Distance for fuzzy matching ───
function levenshtein(a: string, b: string): number {
  const al = a.length, bl = b.length;
  if (al === 0) return bl;
  if (bl === 0) return al;

  // Use two rows instead of full matrix for memory efficiency
  let prev = Array.from({ length: bl + 1 }, (_, i) => i);
  let curr = new Array(bl + 1);

  for (let i = 1; i <= al; i++) {
    curr[0] = i;
    for (let j = 1; j <= bl; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      curr[j] = Math.min(
        prev[j] + 1,      // deletion
        curr[j - 1] + 1,  // insertion
        prev[j - 1] + cost // substitution
      );
    }
    [prev, curr] = [curr, prev];
  }
  return prev[bl];
}

// Fuzzy match: returns a relevance score (0 = no match, higher = better)
function fuzzyScore(text: string, query: string): number {
  const t = text.toLowerCase();
  const q = query.toLowerCase();

  // Exact match
  if (t === q) return 100;

  // Starts with query
  if (t.startsWith(q)) return 90;

  // Contains query as substring
  if (t.includes(q)) return 70;

  // Word-boundary prefix match (any word starts with query)
  const words = t.split(/[\s\-_/,·]+/);
  if (words.some(w => w.startsWith(q))) return 65;

  // For short queries, require lower edit distance threshold
  if (q.length < 3) return 0;

  // Levenshtein on whole string (only useful for short strings)
  const dist = levenshtein(t, q);
  const maxLen = Math.max(t.length, q.length);
  const ratio = 1 - dist / maxLen;
  if (ratio > 0.6) return Math.round(ratio * 50);

  // Levenshtein per word — find best matching word
  let bestWordScore = 0;
  for (const word of words) {
    if (word.length < 2) continue;
    const wDist = levenshtein(word, q);
    const wRatio = 1 - wDist / Math.max(word.length, q.length);
    if (wRatio > 0.55) {
      bestWordScore = Math.max(bestWordScore, Math.round(wRatio * 45));
    }
  }

  return bestWordScore;
}

// Score a venue against a query across all fields
function scoreVenue(venue: Venue, query: string): number {
  const fields = [
    venue.name,
    venue.nameZh || '',
    venue.category || '',
    venue.subcategory || '',
    venue.district || '',
    ...(venue.vibeTags || []),
  ];

  let best = 0;
  for (const field of fields) {
    if (!field) continue;
    const s = fuzzyScore(field, query);
    if (s > best) best = s;
  }

  // Description: only exact contains (don't fuzzy-match long text)
  if (venue.description?.toLowerCase().includes(query.toLowerCase())) {
    best = Math.max(best, 40);
  }

  return best;
}

function scoreEvent(event: CulturalEvent, query: string): number {
  const fields = [
    event.title,
    event.venueName || '',
    event.category || '',
    event.district || '',
  ];

  let best = 0;
  for (const field of fields) {
    if (!field) continue;
    const s = fuzzyScore(field, query);
    if (s > best) best = s;
  }

  if (event.description?.toLowerCase().includes(query.toLowerCase())) {
    best = Math.max(best, 40);
  }

  return best;
}

interface SearchResult {
  type: 'venue' | 'event' | 'district' | 'category' | 'vibe' | 'ai';
  id: string;
  title: string;
  subtitle?: string;
  icon?: React.ReactNode;
  path?: string;
  count?: number;
  score?: number;
  fuzzy?: boolean; // true if matched via fuzzy (not exact)
  data?: any;
}

interface TrendingItem {
  query: string;
  count: number;
  trend: 'up' | 'stable' | 'down';
}

function getRecentSearches(): string[] {
  try {
    const raw = localStorage.getItem(RECENT_SEARCHES_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
}

function saveRecentSearch(query: string) {
  const recent = getRecentSearches().filter(s => s !== query);
  recent.unshift(query);
  localStorage.setItem(RECENT_SEARCHES_KEY, JSON.stringify(recent.slice(0, MAX_RECENT)));
}

function clearRecentSearches() {
  localStorage.removeItem(RECENT_SEARCHES_KEY);
}

function highlightMatch(text: string, query: string): React.ReactNode {
  if (!query.trim()) return text;
  const idx = text.toLowerCase().indexOf(query.toLowerCase());
  if (idx === -1) return text;
  return (
    <>
      {text.slice(0, idx)}
      <span className="font-semibold" style={{ textDecoration: 'underline', textDecorationColor: 'currentColor', textUnderlineOffset: '2px' }}>
        {text.slice(idx, idx + query.length)}
      </span>
      {text.slice(idx + query.length)}
    </>
  );
}

const TrendIcon = ({ trend, color }: { trend: string; color: string }) => {
  if (trend === 'up') return <ArrowUpRight size={10} style={{ color }} />;
  if (trend === 'down') return <ChevronDown size={10} style={{ color: '#999' }} />;
  return <Minus size={9} style={{ color: '#999' }} />;
};

export function SearchOverlay({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const { venues, events } = useData();
  const { currentMode } = useMode();
  const tokens = getDesignTokens(currentMode);
  const modeColor = currentMode && currentMode !== 'lifestyle'
    ? modeConfig[currentMode].color
    : currentMode === 'lifestyle' ? '#2D6A4F' : '#8338EC';

  const [query, setQuery] = useState('');
  const [activeIndex, setActiveIndex] = useState(-1);
  const [recentSearches, setRecentSearches] = useState<string[]>([]);
  const [aiSuggestions, setAiSuggestions] = useState<string[]>([]);
  const [aiLoading, setAiLoading] = useState(false);
  const [trending, setTrending] = useState<TrendingItem[]>([]);
  const [trendingLoading, setTrendingLoading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const aiTimeoutRef = useRef<any>(null);

  // Focus input + fetch trending when overlay opens
  useEffect(() => {
    if (isOpen) {
      setQuery('');
      setActiveIndex(-1);
      setAiSuggestions([]);
      setRecentSearches(getRecentSearches());
      setTimeout(() => inputRef.current?.focus(), 100);

      // Fetch trending
      setTrendingLoading(true);
      fetch(`${API_BASE}/search/trending${currentMode ? `?mode=${currentMode}` : ''}`, {
        headers: { Authorization: `Bearer ${publicAnonKey}` },
      })
        .then(r => r.json())
        .then(data => setTrending(data.trending || []))
        .catch(() => setTrending([]))
        .finally(() => setTrendingLoading(false));
    }
  }, [isOpen, currentMode]);

  // Track search on submit
  const trackSearch = useCallback((q: string, resultCount: number) => {
    fetch(`${API_BASE}/search/track`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${publicAnonKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ query: q, mode: currentMode, resultCount }),
    }).catch(() => {}); // Fire-and-forget
  }, [currentMode]);

  // Debounced AI suggestions
  useEffect(() => {
    if (aiTimeoutRef.current) clearTimeout(aiTimeoutRef.current);
    if (query.length < 2) {
      setAiSuggestions([]);
      return;
    }
    aiTimeoutRef.current = setTimeout(async () => {
      try {
        setAiLoading(true);
        const res = await fetch(`${API_BASE}/search/ai-suggest`, {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${publicAnonKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ query, mode: currentMode }),
        });
        if (res.ok) {
          const data = await res.json();
          setAiSuggestions(data.suggestions || []);
        }
      } catch (err) {
        console.log('[Search] AI suggestions unavailable:', err);
      } finally {
        setAiLoading(false);
      }
    }, 500);
    return () => { if (aiTimeoutRef.current) clearTimeout(aiTimeoutRef.current); };
  }, [query, currentMode]);

  // Build search results with fuzzy matching
  const results = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase().trim();
    const out: SearchResult[] = [];
    const MIN_FUZZY_SCORE = 35;

    // Score and sort venues
    const scoredVenues = venues
      .map(v => ({ venue: v, score: scoreVenue(v, q) }))
      .filter(sv => sv.score >= MIN_FUZZY_SCORE)
      .sort((a, b) => b.score - a.score)
      .slice(0, 6);

    scoredVenues.forEach(({ venue: v, score }) => {
      const isExactMatch = v.name.toLowerCase().includes(q) || v.nameZh?.includes(q);
      out.push({
        type: 'venue',
        id: v.id,
        title: v.name,
        subtitle: `${v.nameZh ? v.nameZh + ' · ' : ''}${v.district}${v.category ? ' · ' + v.category : ''}`,
        icon: <Building2 size={14} />,
        path: `/venue/${v.id}`,
        score,
        fuzzy: !isExactMatch,
        data: v,
      });
    });

    // Score and sort events
    const scoredEvents = events
      .map(e => ({ event: e, score: scoreEvent(e, q) }))
      .filter(se => se.score >= MIN_FUZZY_SCORE)
      .sort((a, b) => b.score - a.score)
      .slice(0, 5);

    scoredEvents.forEach(({ event: e, score }) => {
      const isExactMatch = e.title.toLowerCase().includes(q);
      out.push({
        type: 'event',
        id: e.id,
        title: e.title,
        subtitle: `${e.venueName} · ${e.date}`,
        icon: <Calendar size={14} />,
        path: `/event/${e.id}`,
        score,
        fuzzy: !isExactMatch,
        data: e,
      });
    });

    // Aggregate districts (exact + fuzzy)
    const districtCounts = new Map<string, { count: number; score: number }>();
    venues.forEach(v => {
      if (!v.district) return;
      const s = fuzzyScore(v.district, q);
      if (s >= MIN_FUZZY_SCORE) {
        const existing = districtCounts.get(v.district);
        if (existing) {
          existing.count += 1;
          existing.score = Math.max(existing.score, s);
        } else {
          districtCounts.set(v.district, { count: 1, score: s });
        }
      }
    });
    [...districtCounts.entries()]
      .sort((a, b) => b[1].score - a[1].score || b[1].count - a[1].count)
      .slice(0, 3)
      .forEach(([district, { count, score }]) => {
        out.push({
          type: 'district',
          id: `district-${district}`,
          title: district,
          subtitle: `${count} venue${count > 1 ? 's' : ''}`,
          icon: <Navigation size={14} />,
          path: `/map?search=${encodeURIComponent(district)}`,
          count,
          score,
          fuzzy: !district.toLowerCase().includes(q),
        });
      });

    // Aggregate categories (exact + fuzzy)
    const catCounts = new Map<string, { count: number; score: number }>();
    [...venues.map(v => v.category), ...events.map(e => e.category)]
      .filter(Boolean)
      .forEach(cat => {
        const s = fuzzyScore(cat, q);
        if (s >= MIN_FUZZY_SCORE) {
          const existing = catCounts.get(cat);
          if (existing) {
            existing.count += 1;
            existing.score = Math.max(existing.score, s);
          } else {
            catCounts.set(cat, { count: 1, score: s });
          }
        }
      });
    [...catCounts.entries()]
      .sort((a, b) => b[1].score - a[1].score || b[1].count - a[1].count)
      .slice(0, 3)
      .forEach(([cat, { count, score }]) => {
        out.push({
          type: 'category',
          id: `cat-${cat}`,
          title: cat.charAt(0).toUpperCase() + cat.slice(1),
          subtitle: `${count} result${count > 1 ? 's' : ''}`,
          icon: <Tag size={14} />,
          path: `/map?search=${encodeURIComponent(cat)}`,
          count,
          score,
          fuzzy: !cat.toLowerCase().includes(q),
        });
      });

    // Vibe tags (exact + fuzzy)
    const vibeCounts = new Map<string, { count: number; score: number }>();
    venues.forEach(v => {
      v.vibeTags?.forEach(t => {
        const s = fuzzyScore(t, q);
        if (s >= MIN_FUZZY_SCORE) {
          const existing = vibeCounts.get(t);
          if (existing) {
            existing.count += 1;
            existing.score = Math.max(existing.score, s);
          } else {
            vibeCounts.set(t, { count: 1, score: s });
          }
        }
      });
    });
    [...vibeCounts.entries()]
      .sort((a, b) => b[1].score - a[1].score || b[1].count - a[1].count)
      .slice(0, 3)
      .forEach(([tag, { count, score }]) => {
        out.push({
          type: 'vibe',
          id: `vibe-${tag}`,
          title: `#${tag}`,
          subtitle: `${count} venue${count > 1 ? 's' : ''}`,
          icon: <TrendingUp size={14} />,
          path: `/map?search=${encodeURIComponent(tag)}`,
          count,
          score,
          fuzzy: !tag.toLowerCase().includes(q),
        });
      });

    return out;
  }, [query, venues, events]);

  // Add AI results
  const allResults = useMemo(() => {
    const out = [...results];
    aiSuggestions.forEach((s, i) => {
      out.push({
        type: 'ai',
        id: `ai-${i}`,
        title: s,
        icon: <Sparkles size={14} />,
      });
    });
    return out;
  }, [results, aiSuggestions]);

  const handleSelect = useCallback((result: SearchResult) => {
    const searchTerm = query.trim() || result.title;
    if (result.type === 'ai') {
      // AI suggestions navigate directly to map search
      saveRecentSearch(result.title);
      trackSearch(result.title, allResults.length);
      navigate(`/map?search=${encodeURIComponent(result.title)}`);
      onClose();
      return;
    }
    saveRecentSearch(searchTerm);
    trackSearch(searchTerm, allResults.length);
    if (result.path) {
      navigate(result.path);
    }
    onClose();
  }, [query, navigate, onClose, trackSearch, allResults.length]);

  const handleRecentClick = useCallback((term: string) => {
    setQuery(term);
    inputRef.current?.focus();
  }, []);

  const handleTrendingClick = useCallback((term: string) => {
    setQuery(term);
    inputRef.current?.focus();
  }, []);

  const handleSubmit = useCallback(() => {
    if (query.trim()) {
      saveRecentSearch(query.trim());
      trackSearch(query.trim(), allResults.length);
      navigate(`/map?search=${encodeURIComponent(query.trim())}`);
      onClose();
    }
  }, [query, navigate, onClose, trackSearch, allResults.length]);

  // Keyboard navigation
  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    const total = allResults.length;
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setActiveIndex(prev => (prev + 1) % Math.max(total, 1));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setActiveIndex(prev => prev <= 0 ? total - 1 : prev - 1);
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (activeIndex >= 0 && activeIndex < total) {
        handleSelect(allResults[activeIndex]);
      } else {
        handleSubmit();
      }
    } else if (e.key === 'Escape') {
      onClose();
    }
  }, [activeIndex, allResults, handleSelect, handleSubmit, onClose]);

  // Scroll active item into view
  useEffect(() => {
    if (activeIndex >= 0 && listRef.current) {
      const items = listRef.current.querySelectorAll('[data-search-item]');
      items[activeIndex]?.scrollIntoView({ block: 'nearest' });
    }
  }, [activeIndex]);

  // Reset active index when results change
  useEffect(() => { setActiveIndex(-1); }, [allResults.length]);

  // Group results
  const grouped = useMemo(() => {
    const groups: { label: string; items: (SearchResult & { globalIndex: number })[] }[] = [];
    const typeOrder: [string, string][] = [
      ['venue', 'Venues'],
      ['event', 'Events'],
      ['district', 'Districts'],
      ['category', 'Categories'],
      ['vibe', 'Vibe Tags'],
      ['ai', 'AI Suggestions'],
    ];
    let idx = 0;
    for (const [type, label] of typeOrder) {
      const items = allResults
        .filter(r => r.type === type)
        .map(r => ({ ...r, globalIndex: idx++ }));
      if (items.length > 0) groups.push({ label, items });
    }
    return groups;
  }, [allResults]);

  // Count fuzzy-only matches
  const fuzzyCount = results.filter(r => r.fuzzy).length;

  const hasContent = query.trim()
    ? allResults.length > 0
    : recentSearches.length > 0 || trending.length > 0;

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
            className="fixed inset-0 z-[10000]"
            style={{ backgroundColor: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(8px)' }}
            onClick={onClose}
          />

          {/* Search panel */}
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.98 }}
            transition={{ type: 'spring', damping: 30, stiffness: 400 }}
            className="fixed top-0 left-0 right-0 z-[10001] mx-auto"
            style={{ maxWidth: 640, padding: '12px 16px' }}
          >
            <div
              className="overflow-hidden"
              style={{
                borderRadius: 20,
                backgroundColor: tokens.cardBg,
                border: `1px solid ${tokens.cardBorder}`,
                boxShadow: '0 24px 80px rgba(0,0,0,0.25), 0 8px 32px rgba(0,0,0,0.12)',
              }}
            >
              {/* Input row */}
              <div
                className="flex items-center gap-3 px-5 py-3.5"
                style={{ borderBottom: hasContent || aiLoading ? `1px solid ${tokens.cardBorder}` : 'none' }}
              >
                <Search size={18} style={{ color: tokens.textMuted, flexShrink: 0 }} />
                <input
                  ref={inputRef}
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder={t('search.placeholder')}
                  className="flex-1 text-[15px] bg-transparent outline-none placeholder:opacity-40"
                  style={{
                    color: tokens.textPrimary,
                    fontFamily: tokens.bodyFont,
                    caretColor: modeColor,
                  }}
                />
                {query && (
                  <button
                    onClick={() => { setQuery(''); inputRef.current?.focus(); }}
                    className="p-1 rounded-full hover:opacity-70 cursor-pointer transition-opacity"
                    style={{ color: tokens.textMuted }}
                  >
                    <X size={15} />
                  </button>
                )}
                <kbd
                  className="hidden sm:inline-flex items-center gap-0.5 px-1.5 py-0.5 text-[10px] rounded"
                  style={{
                    backgroundColor: tokens.surfaceBg,
                    color: tokens.textMuted,
                    border: `1px solid ${tokens.cardBorder}`,
                    fontFamily: 'monospace',
                  }}
                >
                  <span style={{ fontSize: '11px' }}>⌘</span>K
                </kbd>
              </div>

              {/* Results area */}
              <div
                ref={listRef}
                className="overflow-y-auto"
                style={{ maxHeight: 'min(65vh, 520px)' }}
              >
                {/* ─── No query: Trending + Recents ─── */}
                {!query.trim() && (
                  <>
                    {/* Trending searches */}
                    {trending.length > 0 && (
                      <div className="px-4 py-3">
                        <div className="flex items-center gap-1.5 mb-2.5 px-1">
                          <Flame size={12} style={{ color: modeColor }} />
                          <span className="text-[11px] font-medium uppercase tracking-wider" style={{ color: modeColor }}>
                            {t('search.trending')}
                          </span>
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {trending.slice(0, 8).map((item, i) => (
                            <button
                              key={`trend-${i}`}
                              onClick={() => handleTrendingClick(item.query)}
                              className="flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-full cursor-pointer transition-all hover:scale-[1.02] active:scale-[0.98]"
                              style={{
                                backgroundColor: `${modeColor}08`,
                                color: tokens.textSecondary,
                                border: `1px solid ${modeColor}18`,
                              }}
                            >
                              <TrendIcon trend={item.trend} color={modeColor} />
                              <span>{item.query}</span>
                              <span
                                className="text-[9px] px-1 py-px rounded-full"
                                style={{ backgroundColor: `${modeColor}12`, color: modeColor, fontWeight: 600 }}
                              >
                                {item.count}
                              </span>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Recent searches */}
                    {recentSearches.length > 0 && (
                      <div className="px-4 py-3" style={{ borderTop: trending.length > 0 ? `1px solid ${tokens.cardBorder}` : 'none' }}>
                        <div className="flex items-center justify-between mb-2 px-1">
                          <span className="text-[11px] font-medium uppercase tracking-wider" style={{ color: tokens.textMuted }}>
                            {t('search.recentSearches')}
                          </span>
                          <button
                            onClick={() => { clearRecentSearches(); setRecentSearches([]); }}
                            className="text-[11px] cursor-pointer hover:opacity-70 transition-opacity"
                            style={{ color: tokens.textMuted }}
                          >
                            {t('search.clearRecent')}
                          </button>
                        </div>
                        {recentSearches.map((term, i) => (
                          <button
                            key={`recent-${i}`}
                            onClick={() => handleRecentClick(term)}
                            className="flex items-center gap-3 w-full px-3 py-2 rounded-xl text-left transition-all hover:opacity-80 cursor-pointer"
                            style={{ color: tokens.textSecondary, backgroundColor: 'transparent' }}
                            onMouseEnter={e => (e.currentTarget.style.backgroundColor = tokens.surfaceBg)}
                            onMouseLeave={e => (e.currentTarget.style.backgroundColor = 'transparent')}
                          >
                            <Clock size={13} style={{ color: tokens.textMuted, flexShrink: 0 }} />
                            <span className="text-sm truncate">{term}</span>
                            <ArrowRight size={12} className="ml-auto" style={{ color: tokens.textMuted, flexShrink: 0, opacity: 0.5 }} />
                          </button>
                        ))}
                      </div>
                    )}

                    {/* Empty state: no trending, no recents */}
                    {recentSearches.length === 0 && trending.length === 0 && !trendingLoading && (
                      <div className="px-5 py-6 text-center">
                        <Search size={28} style={{ color: tokens.textMuted, opacity: 0.3, margin: '0 auto 8px' }} />
                        <p className="text-sm" style={{ color: tokens.textMuted }}>
                          {t('search.placeholder')}
                        </p>
                        <div className="flex flex-wrap justify-center gap-2 mt-4">
                          {['Central', 'gallery', 'rooftop', 'live music', 'family-friendly'].map(tag => (
                            <button
                              key={tag}
                              onClick={() => setQuery(tag)}
                              className="px-3 py-1.5 text-xs rounded-full cursor-pointer transition-all hover:opacity-80"
                              style={{
                                backgroundColor: tokens.surfaceBg,
                                color: tokens.textSecondary,
                                border: `1px solid ${tokens.cardBorder}`,
                              }}
                            >
                              {tag}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </>
                )}

                {/* ─── Grouped results ─── */}
                {query.trim() && grouped.length > 0 && (
                  <div className="py-2">
                    {/* "Search map for X" action row — always at top when typing */}
                    <button
                      data-search-item
                      onClick={handleSubmit}
                      className="flex items-center gap-3 w-full px-5 py-3 text-left transition-all cursor-pointer border-b"
                      style={{
                        borderColor: tokens.cardBorder,
                        backgroundColor: activeIndex === -1 ? `${modeColor}08` : 'transparent',
                        color: tokens.textPrimary,
                      }}
                      onMouseEnter={e => { e.currentTarget.style.backgroundColor = `${modeColor}08`; }}
                      onMouseLeave={e => { e.currentTarget.style.backgroundColor = activeIndex === -1 ? `${modeColor}08` : 'transparent'; }}
                    >
                      <div
                        className="flex items-center justify-center w-7 h-7 rounded-lg flex-shrink-0"
                        style={{ backgroundColor: `${modeColor}15`, color: modeColor }}
                      >
                        <MapIcon size={14} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium" style={{ color: tokens.textPrimary }}>
                          Search map for <span style={{ color: modeColor }}>"{query}"</span>
                        </p>
                        <p className="text-[11px]" style={{ color: tokens.textMuted }}>
                          Filter map pins to matching venues
                        </p>
                      </div>
                      <ArrowRight size={14} style={{ color: modeColor, flexShrink: 0 }} />
                    </button>

                    {grouped.map((group) => (
                      <div key={group.label}>
                        <div className="px-5 pt-3 pb-1 flex items-center gap-1.5">
                          <span
                            className="text-[11px] font-medium uppercase tracking-wider"
                            style={{
                              color: group.label === 'AI Suggestions' ? modeColor : tokens.textMuted,
                            }}
                          >
                            {group.label === 'AI Suggestions' && <Sparkles size={10} className="inline mr-1 -mt-0.5" />}
                            {group.label}
                          </span>
                        </div>
                        {group.items.map((result) => (
                          <button
                            key={result.id}
                            data-search-item
                            onClick={() => handleSelect(result)}
                            className="flex items-center gap-3 w-full px-5 py-2.5 text-left transition-all cursor-pointer"
                            style={{
                              backgroundColor: result.globalIndex === activeIndex ? tokens.surfaceBg : 'transparent',
                              color: tokens.textPrimary,
                            }}
                            onMouseEnter={(e) => {
                              setActiveIndex(result.globalIndex);
                              e.currentTarget.style.backgroundColor = tokens.surfaceBg;
                            }}
                            onMouseLeave={(e) => {
                              if (result.globalIndex !== activeIndex) {
                                e.currentTarget.style.backgroundColor = 'transparent';
                              }
                            }}
                          >
                            <div
                              className="flex items-center justify-center w-7 h-7 rounded-lg flex-shrink-0"
                              style={{
                                backgroundColor: result.type === 'ai'
                                  ? `${modeColor}15`
                                  : tokens.surfaceBg,
                                color: result.type === 'ai' ? modeColor : tokens.textMuted,
                              }}
                            >
                              {result.icon}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-1.5">
                                <p className="text-sm truncate">
                                  {highlightMatch(result.title, query)}
                                </p>
                                {result.fuzzy && (
                                  <span
                                    className="text-[9px] px-1 py-px rounded flex-shrink-0"
                                    style={{
                                      backgroundColor: `${modeColor}12`,
                                      color: modeColor,
                                      fontWeight: 500,
                                    }}
                                  >
                                    ~
                                  </span>
                                )}
                              </div>
                              {result.subtitle && (
                                <p className="text-[11px] truncate" style={{ color: tokens.textMuted }}>
                                  {result.subtitle}
                                </p>
                              )}
                            </div>
                            {result.count && (
                              <span
                                className="text-[10px] px-1.5 py-0.5 rounded-full flex-shrink-0"
                                style={{
                                  backgroundColor: `${modeColor}15`,
                                  color: modeColor,
                                  fontWeight: 600,
                                }}
                              >
                                {result.count}
                              </span>
                            )}
                            {result.type === 'ai' && (
                              <ArrowRight size={12} style={{ color: tokens.textMuted, flexShrink: 0, opacity: 0.5 }} />
                            )}
                          </button>
                        ))}
                      </div>
                    ))}
                  </div>
                )}

                {/* No results — still show "Search map" action */}
                {query.trim() && allResults.length === 0 && !aiLoading && (
                  <div className="py-2">
                    <button
                      onClick={handleSubmit}
                      className="flex items-center gap-3 w-full px-5 py-3 text-left transition-all cursor-pointer"
                      style={{ color: tokens.textPrimary }}
                      onMouseEnter={e => { e.currentTarget.style.backgroundColor = tokens.surfaceBg; }}
                      onMouseLeave={e => { e.currentTarget.style.backgroundColor = 'transparent'; }}
                    >
                      <div
                        className="flex items-center justify-center w-7 h-7 rounded-lg flex-shrink-0"
                        style={{ backgroundColor: `${modeColor}15`, color: modeColor }}
                      >
                        <MapIcon size={14} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium" style={{ color: tokens.textPrimary }}>
                          Search map for <span style={{ color: modeColor }}>"{query}"</span>
                        </p>
                        <p className="text-[11px]" style={{ color: tokens.textMuted }}>
                          {t('search.noResults')}
                        </p>
                      </div>
                      <ArrowRight size={14} style={{ color: modeColor, flexShrink: 0 }} />
                    </button>
                  </div>
                )}

                {/* AI loading indicator */}
                {aiLoading && (
                  <div className="flex items-center gap-2 px-5 py-3" style={{ borderTop: `1px solid ${tokens.cardBorder}` }}>
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ repeat: Infinity, duration: 1.5, ease: 'linear' }}
                    >
                      <Sparkles size={13} style={{ color: modeColor }} />
                    </motion.div>
                    <span className="text-xs" style={{ color: tokens.textMuted }}>
                      Getting AI suggestions...
                    </span>
                  </div>
                )}
              </div>

              {/* Footer */}
              {query.trim() && (
                <div
                  className="flex items-center justify-between px-5 py-2.5"
                  style={{ borderTop: `1px solid ${tokens.cardBorder}` }}
                >
                  <div className="flex items-center gap-3">
                    <span className="text-[11px]" style={{ color: tokens.textMuted }}>
                      <kbd className="px-1 py-0.5 rounded text-[10px]" style={{ backgroundColor: tokens.surfaceBg, border: `1px solid ${tokens.cardBorder}`, fontFamily: 'monospace' }}>↑↓</kbd>
                      {' '}navigate
                    </span>
                    <span className="text-[11px]" style={{ color: tokens.textMuted }}>
                      <kbd className="px-1 py-0.5 rounded text-[10px]" style={{ backgroundColor: tokens.surfaceBg, border: `1px solid ${tokens.cardBorder}`, fontFamily: 'monospace' }}>↵</kbd>
                      {' '}select
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    {fuzzyCount > 0 && (
                      <span className="text-[10px] flex items-center gap-1" style={{ color: modeColor }}>
                        <span className="px-1 py-px rounded" style={{ backgroundColor: `${modeColor}12` }}>~</span>
                        {fuzzyCount} fuzzy
                      </span>
                    )}
                    <span className="text-[11px]" style={{ color: tokens.textMuted }}>
                      {allResults.length} result{allResults.length !== 1 ? 's' : ''}
                    </span>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}