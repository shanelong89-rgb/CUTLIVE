import { useMode } from '../context/ModeContext';
import { useTimePeriod, type TimePeriod } from '../context/TimePeriodContext';
import { modeConfig } from '../data/mock-data';
import { getDesignTokens, isLightMode } from '../data/mode-styles';
import { getTimePeriodTabs } from '../utils/time-filter';
import { useTranslation } from 'react-i18next';

interface TimePeriodFilterProps {
  /** Override style variant; defaults to mode-derived */
  variant?: 'overlay' | 'inline';
  className?: string;
}

export function TimePeriodFilter({ variant = 'inline', className = '' }: TimePeriodFilterProps) {
  useTranslation(); // triggers re-render on language change for i18n-aware tab labels
  const { currentMode } = useMode();
  const { timePeriod, setTimePeriod } = useTimePeriod();
  const tokens = getDesignTokens(currentMode);
  const light = isLightMode(currentMode);
  const modeColor = currentMode && currentMode !== 'lifestyle' ? modeConfig[currentMode].color : currentMode === 'lifestyle' ? '#2D6A4F' : '#8338EC';
  const tabs = getTimePeriodTabs(currentMode);

  const isDegen = currentMode === 'degen';
  const isArtsy = currentMode === 'artsy';
  const isFamily = currentMode === 'family';
  const isFoodie = currentMode === 'foodie';

  // ── Degen: brutalist square buttons ──
  if (isDegen) {
    return (
      <div className={`flex gap-1.5 overflow-x-auto ${className}`}>
        {tabs.map((tab) => (
          <button
            key={tab.key}
            onClick={() => setTimePeriod(tab.key)}
            className="flex-shrink-0 px-4 py-2 text-[11px] transition-all cursor-pointer"
            style={{
              backgroundColor: timePeriod === tab.key ? (variant === 'overlay' ? '#0A0A0A' : '#D600FF') : 'transparent',
              color: timePeriod === tab.key ? (variant === 'overlay' ? '#EDFF00' : '#fff') : (variant === 'overlay' ? '#0A0A0A' : '#0A0A0A'),
              border: `2px solid ${timePeriod === tab.key ? (variant === 'overlay' ? '#0A0A0A' : '#D600FF') : (variant === 'overlay' ? 'rgba(0,0,0,0.15)' : 'rgba(0,0,0,0.1)')}`,
              borderRadius: '4px',
              fontFamily: tokens.headingFont,
              fontWeight: 700,
              letterSpacing: '0.03em',
              textTransform: 'uppercase',
            }}
          >
            {tab.label}
          </button>
        ))}
      </div>
    );
  }

  // ── Artsy: minimal underline tabs ──
  if (isArtsy) {
    return (
      <div className={`flex gap-6 ${className}`}>
        {tabs.map((tab) => (
          <button
            key={tab.key}
            onClick={() => setTimePeriod(tab.key)}
            className="pb-2 transition-all cursor-pointer bg-transparent"
            style={{
              fontSize: '0.65rem',
              letterSpacing: '0.2em',
              color: timePeriod === tab.key ? tokens.textPrimary : tokens.textMuted,
              borderBottom: timePeriod === tab.key ? `1px solid ${tokens.textPrimary}` : '1px solid transparent',
              fontFamily: tokens.bodyFont,
            }}
          >
            {tab.label}
          </button>
        ))}
      </div>
    );
  }

  // ── Foodie: warm rounded pills ──
  if (isFoodie) {
    return (
      <div className={`flex gap-2 overflow-x-auto ${className}`}>
        {tabs.map((tab) => (
          <button
            key={tab.key}
            onClick={() => setTimePeriod(tab.key)}
            className="flex-shrink-0 px-4 py-2 text-xs transition-all cursor-pointer"
            style={{
              backgroundColor: timePeriod === tab.key ? modeColor : (variant === 'overlay' ? 'rgba(255,255,255,0.15)' : tokens.cardBg),
              color: timePeriod === tab.key ? '#fff' : (variant === 'overlay' ? 'rgba(255,255,255,0.5)' : tokens.textSecondary),
              borderRadius: '20px',
              fontFamily: tokens.headingFont,
              fontWeight: 600,
              border: `1px solid ${timePeriod === tab.key ? modeColor : (variant === 'overlay' ? 'rgba(255,255,255,0.1)' : tokens.cardBorder)}`,
            }}
          >
            {tab.label}
          </button>
        ))}
      </div>
    );
  }

  // ── Family: playful bouncy pills ──
  if (isFamily) {
    return (
      <div className={`flex gap-2 overflow-x-auto ${className}`}>
        {tabs.map((tab) => (
          <button
            key={tab.key}
            onClick={() => setTimePeriod(tab.key)}
            className="flex-shrink-0 px-4 py-2.5 text-xs transition-all cursor-pointer hover:scale-105"
            style={{
              backgroundColor: timePeriod === tab.key ? '#FF8C42' : '#fff',
              color: timePeriod === tab.key ? '#fff' : tokens.textSecondary,
              borderRadius: '9999px',
              fontFamily: tokens.headingFont,
              fontWeight: 700,
              boxShadow: timePeriod === tab.key ? '0 4px 16px rgba(255,140,66,0.35)' : '0 2px 8px rgba(0,0,0,0.06)',
              border: timePeriod === tab.key ? 'none' : '1px solid rgba(0,0,0,0.04)',
            }}
          >
            {tab.label}
          </button>
        ))}
      </div>
    );
  }

  // ── Default: capsule pill group ──
  const isNeutral = !currentMode;
  const overlayNeutral = variant === 'overlay' && isNeutral;

  // Neutral mode uses editorial dark style instead of purple
  if (isNeutral) {
    return (
      <div
        className={`flex gap-1.5 overflow-x-auto ${className}`}
      >
        {tabs.map((tab) => (
          <button
            key={tab.key}
            onClick={() => setTimePeriod(tab.key)}
            className="flex-shrink-0 px-4 py-2 text-xs transition-all cursor-pointer"
            style={{
              backgroundColor: timePeriod === tab.key ? '#1A1A1A' : 'transparent',
              color: timePeriod === tab.key ? '#fff' : '#A09B93',
              borderRadius: '8px',
              fontWeight: timePeriod === tab.key ? 600 : 500,
              border: timePeriod === tab.key ? 'none' : '1px solid #E8E4DE',
            }}
          >
            {tab.label}
          </button>
        ))}
      </div>
    );
  }

  return (
    <div
      className={`flex gap-1 p-1 rounded-full ${className}`}
      style={{
        backgroundColor: overlayNeutral
          ? 'rgba(0,0,0,0.05)'
          : variant === 'overlay'
            ? 'rgba(255,255,255,0.08)'
            : `${modeColor}10`,
        border: `1px solid ${overlayNeutral ? 'rgba(0,0,0,0.08)' : variant === 'overlay' ? 'rgba(255,255,255,0.08)' : `${modeColor}15`}`,
      }}
    >
      {tabs.map((tab) => (
        <button
          key={tab.key}
          onClick={() => setTimePeriod(tab.key)}
          className="flex items-center gap-1.5 px-4 py-2 text-xs transition-all rounded-full cursor-pointer"
          style={{
            backgroundColor: timePeriod === tab.key ? modeColor : 'transparent',
            color: timePeriod === tab.key ? '#fff' : (overlayNeutral ? 'rgba(0,0,0,0.5)' : tokens.textMuted),
            fontWeight: timePeriod === tab.key ? 600 : 400,
          }}
        >
          {tab.label}
        </button>
      ))}
    </div>
  );
}