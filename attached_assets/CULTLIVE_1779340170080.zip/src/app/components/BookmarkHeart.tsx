/**
 * BookmarkHeart — small heart/bookmark button overlay for event cards.
 * Prevents click from bubbling to parent Link.
 */
import { Heart } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useEventStats } from '../context/EventStatsContext';

export function BookmarkHeart({
  eventId,
  size = 14,
  className = '',
}: {
  eventId: string;
  size?: number;
  className?: string;
}) {
  const { isEventSaved, toggleSaveEvent } = useAuth();
  const { trackSave, trackUnsave } = useEventStats();
  const saved = isEventSaved(eventId);

  return (
    <button
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        // Track save/unsave before toggling
        if (saved) {
          trackUnsave(eventId);
        } else {
          trackSave(eventId);
        }
        toggleSaveEvent(eventId);
      }}
      className={`p-1.5 cursor-pointer transition-all hover:scale-110 ${className}`}
      style={{
        backgroundColor: 'rgba(0,0,0,0.35)',
        borderRadius: '6px',
        backdropFilter: 'blur(4px)',
      }}
      title={saved ? 'Remove from saved' : 'Save event'}
    >
      <Heart
        size={size}
        fill={saved ? '#EF4444' : 'none'}
        color={saved ? '#EF4444' : '#fff'}
      />
    </button>
  );
}