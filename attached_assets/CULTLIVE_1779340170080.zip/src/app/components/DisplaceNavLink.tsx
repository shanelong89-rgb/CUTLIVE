import { useState, useRef, useCallback } from 'react';
import { Link } from 'react-router';

/**
 * Nav link with SplittingJS-style character displacement on hover.
 * Layer A (Inter) rotates out → Layer B cycles through all mode fonts on each hover.
 * Only used in neutral mode nav.
 */

// Each entry represents a mode's typographic voice
const MODE_FONTS = [
  { family: "'Playfair Display', serif", italic: true, weight: 500, spacing: '0.01em', label: 'artsy' },
  { family: "'Space Grotesk', sans-serif", italic: false, weight: 600, spacing: '0.02em', label: 'night' },
  { family: "'Nunito', sans-serif", italic: false, weight: 700, spacing: '0.01em', label: 'family' },
  { family: "'DM Sans', sans-serif", italic: false, weight: 500, spacing: '0em', label: 'foodie' },
  { family: "'Cormorant Garamond', serif", italic: true, weight: 500, spacing: '0.02em', label: 'lifestyle' },
];

function SplitChars({ text, style }: { text: string; style?: React.CSSProperties }) {
  return (
    <span style={style}>
      {text.split('').map((char, i) => (
        <span
          key={`${char}-${i}`}
          className="dn-char"
          style={{ '--ci': i } as React.CSSProperties}
        >
          {char === ' ' ? '\u00A0' : char}
        </span>
      ))}
    </span>
  );
}

interface DisplaceNavLinkProps {
  to: string;
  label: string;
  isActive: boolean;
  textColor: string;
  activeColor: string;
}

export function DisplaceNavLink({ to, label, isActive, textColor, activeColor }: DisplaceNavLinkProps) {
  const [hovered, setHovered] = useState(false);
  const fontIndexRef = useRef(0);
  const [currentFont, setCurrentFont] = useState(MODE_FONTS[0]);

  const handleMouseEnter = useCallback(() => {
    setCurrentFont(MODE_FONTS[fontIndexRef.current]);
    fontIndexRef.current = (fontIndexRef.current + 1) % MODE_FONTS.length;
    setHovered(true);
  }, []);

  return (
    <Link
      to={to}
      className="relative px-4 py-2 block"
      style={{ textDecoration: 'none' }}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={() => setHovered(false)}
    >
      <div className={`dn-grid ${hovered ? 'dn-active' : ''}`}>
        {/* Layer A: Inter – default */}
        <div className="dn-layer dn-layer-a">
          <SplitChars
            text={label}
            style={{
              fontFamily: "'Inter', sans-serif",
              fontWeight: isActive ? 500 : 400,
              fontSize: '0.875rem',
              color: isActive ? activeColor : textColor,
              letterSpacing: '-0.01em',
              lineHeight: 1,
              transition: 'color 0.3s ease',
            }}
          />
        </div>

        {/* Layer B: cycles through mode fonts on each hover */}
        <div className="dn-layer dn-layer-b">
          <SplitChars
            text={label}
            style={{
              fontFamily: currentFont.family,
              fontStyle: currentFont.italic ? 'italic' : 'normal',
              fontWeight: currentFont.weight,
              fontSize: '0.875rem',
              color: activeColor,
              letterSpacing: currentFont.spacing,
              lineHeight: 1,
              transition: 'color 0.3s ease',
            }}
          />
        </div>
      </div>

      {/* Active underline */}
      {isActive && (
        <div
          className="absolute bottom-0 left-3 right-3 h-[2px] rounded-full"
          style={{ backgroundColor: activeColor, transition: 'background-color 0.3s ease' }}
        />
      )}
    </Link>
  );
}

/** Inject once at the top of Layout — the CSS for displacement nav links */
export function DisplaceNavStyles() {
  return (
    <style>{`
      .dn-char {
        display: inline-block;
        transform-origin: 50% 100% 0.4em;
        transition: transform 0.45s cubic-bezier(0.22, 1, 0.36, 1);
        transition-delay: calc(var(--ci, 0) * 22ms);
        backface-visibility: hidden;
        will-change: transform;
      }

      .dn-grid {
        display: grid;
        perspective: 800px;
        cursor: pointer;
      }

      .dn-layer {
        grid-area: 1 / 1;
        transition: opacity 0.35s cubic-bezier(0.4, 0, 0.2, 1);
        white-space: nowrap;
      }

      /* Layer A – visible by default */
      .dn-layer-a { opacity: 1; }
      .dn-layer-a .dn-char { transform: rotate3d(0, 0, 0, 0deg); }

      /* Layer B – hidden, rotated away */
      .dn-layer-b { opacity: 0; }
      .dn-layer-b .dn-char { transform: rotate3d(1, -0.3, 0, 90deg); }

      /* Hovered: swap */
      .dn-grid.dn-active .dn-layer-a { opacity: 0; }
      .dn-grid.dn-active .dn-layer-a .dn-char {
        transform: rotate3d(1, 0.2, 0, -90deg);
      }
      .dn-grid.dn-active .dn-layer-b { opacity: 1; }
      .dn-grid.dn-active .dn-layer-b .dn-char {
        transform: rotate3d(0, 0, 0, 0deg);
      }
    `}</style>
  );
}