/**
 * ShareMenu — universal share dropdown supporting Instagram, Telegram, X, Facebook, WhatsApp, WeChat
 * Adapts styling to current mode via design tokens.
 */
import { useState, useRef, useEffect, useCallback } from 'react';
import { Share2, Link2, Check, X, QrCode } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useMode } from '../context/ModeContext';
import { getDesignTokens } from '../data/mode-styles';
import { modeConfig } from '../data/mock-data';
import { useEventStats } from '../context/EventStatsContext';

// ─── Platform definitions ───
interface SharePlatform {
  key: string;
  label: string;
  labelZh: string;
  icon: React.ReactNode;
  color: string;
  getUrl: (url: string, title: string, description: string) => string | null;
  note?: string;
  noteZh?: string;
}

const platforms: SharePlatform[] = [
  {
    key: 'whatsapp',
    label: 'WhatsApp',
    labelZh: 'WhatsApp',
    icon: (
      <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor">
        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
      </svg>
    ),
    color: '#25D366',
    getUrl: (url, title) => `https://wa.me/?text=${encodeURIComponent(`${title}\n${url}`)}`,
  },
  {
    key: 'telegram',
    label: 'Telegram',
    labelZh: 'Telegram',
    icon: (
      <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor">
        <path d="M11.944 0A12 12 0 000 12a12 12 0 0012 12 12 12 0 0012-12A12 12 0 0012 0a12 12 0 00-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 01.171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.479.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/>
      </svg>
    ),
    color: '#0088cc',
    getUrl: (url, title) => `https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(title)}`,
  },
  {
    key: 'twitter',
    label: 'X (Twitter)',
    labelZh: 'X (Twitter)',
    icon: (
      <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor">
        <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
      </svg>
    ),
    color: '#000000',
    getUrl: (url, title) => `https://twitter.com/intent/tweet?text=${encodeURIComponent(title)}&url=${encodeURIComponent(url)}`,
  },
  {
    key: 'facebook',
    label: 'Facebook',
    labelZh: 'Facebook',
    icon: (
      <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor">
        <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
      </svg>
    ),
    color: '#1877F2',
    getUrl: (url) => `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`,
  },
  {
    key: 'instagram',
    label: 'Instagram',
    labelZh: 'Instagram',
    icon: (
      <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor">
        <path d="M12 0C8.74 0 8.333.015 7.053.072 5.775.132 4.905.333 4.14.63c-.789.306-1.459.717-2.126 1.384S.935 3.35.63 4.14C.333 4.905.131 5.775.072 7.053.012 8.333 0 8.74 0 12s.015 3.667.072 4.947c.06 1.277.261 2.148.558 2.913.306.788.717 1.459 1.384 2.126.667.666 1.336 1.079 2.126 1.384.766.296 1.636.499 2.913.558C8.333 23.988 8.74 24 12 24s3.667-.015 4.947-.072c1.277-.06 2.148-.262 2.913-.558.788-.306 1.459-.718 2.126-1.384.666-.667 1.079-1.335 1.384-2.126.296-.765.499-1.636.558-2.913.06-1.28.072-1.687.072-4.947s-.015-3.667-.072-4.947c-.06-1.277-.262-2.149-.558-2.913-.306-.789-.718-1.459-1.384-2.126C21.319 1.347 20.651.935 19.86.63c-.765-.297-1.636-.499-2.913-.558C15.667.012 15.26 0 12 0zm0 2.16c3.203 0 3.585.016 4.85.071 1.17.055 1.805.249 2.227.415.562.217.96.477 1.382.896.419.42.679.819.896 1.381.164.422.36 1.057.413 2.227.057 1.266.07 1.646.07 4.85s-.015 3.585-.074 4.85c-.061 1.17-.256 1.805-.421 2.227-.224.562-.479.96-.899 1.382-.419.419-.824.679-1.38.896-.42.164-1.065.36-2.235.413-1.274.057-1.649.07-4.859.07-3.211 0-3.586-.015-4.859-.074-1.171-.061-1.816-.256-2.236-.421-.569-.224-.96-.479-1.379-.899-.421-.419-.69-.824-.9-1.38-.165-.42-.359-1.065-.42-2.235-.045-1.26-.061-1.649-.061-4.844 0-3.196.016-3.586.061-4.861.061-1.17.255-1.814.42-2.234.21-.57.479-.96.9-1.381.419-.419.81-.689 1.379-.898.42-.166 1.051-.361 2.221-.421 1.275-.045 1.65-.06 4.859-.06l.045.03zm0 3.678a6.162 6.162 0 100 12.324 6.162 6.162 0 100-12.324zM12 16c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4zm7.846-10.405a1.441 1.441 0 11-2.882 0 1.441 1.441 0 012.882 0z"/>
      </svg>
    ),
    color: '#E4405F',
    getUrl: () => null, // Instagram doesn't support URL sharing — copy link instead
    note: 'Link copied! Paste in Stories or DMs',
    noteZh: '連結已複製！貼到限時動態或私訊',
  },
  {
    key: 'wechat',
    label: 'WeChat',
    labelZh: '微信',
    icon: (
      <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor">
        <path d="M8.691 2.188C3.891 2.188 0 5.476 0 9.53c0 2.212 1.17 4.203 3.002 5.55a.59.59 0 01.213.665l-.39 1.48c-.019.07-.048.141-.048.213 0 .163.13.295.29.295a.326.326 0 00.167-.054l1.903-1.114a.864.864 0 01.717-.098 10.16 10.16 0 002.837.403c.276 0 .543-.027.811-.05-.857-2.578.157-4.972 1.932-6.446 1.703-1.415 3.882-1.98 5.853-1.838-.576-3.583-4.196-6.348-8.596-6.348zM5.785 5.991c.642 0 1.162.529 1.162 1.18a1.17 1.17 0 01-1.162 1.178A1.17 1.17 0 014.623 7.17c0-.651.52-1.18 1.162-1.18zm5.813 0c.642 0 1.162.529 1.162 1.18a1.17 1.17 0 01-1.162 1.178 1.17 1.17 0 01-1.162-1.178c0-.651.52-1.18 1.162-1.18zm5.34 2.867c-1.797-.052-3.746.512-5.28 1.786-1.72 1.428-2.687 3.72-1.78 6.22.942 2.453 3.666 4.229 6.884 4.229.826 0 1.622-.12 2.361-.336a.722.722 0 01.598.082l1.584.926a.272.272 0 00.14.047c.134 0 .24-.111.24-.247 0-.06-.023-.12-.038-.177l-.327-1.233a.582.582 0 01-.023-.156.49.49 0 01.201-.398C23.024 18.48 24 16.82 24 14.98c0-3.21-2.931-5.837-7.062-6.122zM14.53 13.39c.535 0 .969.44.969.982a.976.976 0 01-.969.983.976.976 0 01-.969-.983c0-.542.434-.982.97-.982zm4.844 0c.535 0 .969.44.969.982a.976.976 0 01-.969.983.976.976 0 01-.969-.983c0-.542.434-.982.97-.982z"/>
      </svg>
    ),
    color: '#07C160',
    getUrl: () => null, // WeChat requires QR or in-app sharing
    note: 'Link copied! Open WeChat to share',
    noteZh: '連結已複製！打開微信分享',
  },
];

interface ShareMenuProps {
  /** The title of the content being shared */
  title: string;
  /** Optional description */
  description?: string;
  /** URL to share — defaults to current page */
  url?: string;
  /** Render trigger — receives onClick and ref */
  children?: (props: { onClick: () => void; ref: React.RefObject<HTMLButtonElement | null> }) => React.ReactNode;
  /** Compact mode (icon only trigger) */
  compact?: boolean;
  /** Override accent color */
  accentColor?: string;
  /** Event ID for tracking shares (optional) */
  eventId?: string;
}

export function ShareMenu({ title, description = '', url, children, compact, accentColor, eventId }: ShareMenuProps) {
  const [open, setOpen] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);
  const triggerRef = useRef<HTMLButtonElement | null>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const { currentMode } = useMode();
  const tokens = getDesignTokens(currentMode);
  const modeColor = accentColor || modeConfig[currentMode]?.color || '#1a1a1a';
  const { trackShare } = useEventStats();

  const shareUrl = url || (typeof window !== 'undefined' ? window.location.href : '');

  // Close on outside click
  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node) &&
          triggerRef.current && !triggerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open]);

  // Close on Escape
  useEffect(() => {
    if (!open) return;
    const handler = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    document.addEventListener('keydown', handler);
    return () => document.removeEventListener('keydown', handler);
  }, [open]);

  const copyLink = useCallback(async (platformKey?: string) => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(platformKey || 'link');
      setTimeout(() => setCopied(null), 2500);
    } catch {
      // Fallback
      const ta = document.createElement('textarea');
      ta.value = shareUrl;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
      setCopied(platformKey || 'link');
      setTimeout(() => setCopied(null), 2500);
    }
  }, [shareUrl]);

  const handlePlatformClick = (platform: SharePlatform) => {
    const shareUrlFull = platform.getUrl(shareUrl, title, description);
    if (shareUrlFull) {
      window.open(shareUrlFull, '_blank', 'noopener,noreferrer,width=600,height=500');
      setOpen(false);
    } else {
      // Instagram / WeChat — copy link
      copyLink(platform.key);
    }
    if (eventId) {
      trackShare(eventId, platform.key);
    }
  };

  // Mode-aware styling
  const isDegen = currentMode === 'degen';
  const isLifestyle = currentMode === 'lifestyle';
  const isArtsy = currentMode === 'artsy';
  const isFamily = currentMode === 'family';
  const isFoodie = currentMode === 'foodie';

  const menuBg = isDegen ? 'rgba(10,10,10,0.97)' : isLifestyle ? 'rgba(18,42,32,0.97)' : isArtsy ? 'rgba(255,255,255,0.98)' : isFamily ? 'rgba(255,255,255,0.98)' : isFoodie ? 'rgba(15,23,42,0.97)' : 'rgba(255,255,255,0.98)';
  const menuBorder = isDegen ? 'rgba(237,255,0,0.15)' : isLifestyle ? 'rgba(45,106,79,0.3)' : isArtsy ? 'rgba(0,0,0,0.08)' : isFamily ? 'rgba(0,0,0,0.06)' : isFoodie ? 'rgba(37,99,235,0.15)' : 'rgba(0,0,0,0.08)';
  const menuRadius = isDegen ? '6px' : isLifestyle ? '16px' : isArtsy ? '2px' : isFamily ? '20px' : isFoodie ? '14px' : '8px';
  const textPrimary = isDegen ? '#EDFF00' : isLifestyle ? '#FFFFFF' : isArtsy ? '#1a1a1a' : isFamily ? '#2D2A32' : isFoodie ? '#E8F0FF' : '#1a1a1a';
  const textSecondary = isDegen ? 'rgba(237,255,0,0.5)' : isLifestyle ? 'rgba(149,213,178,0.6)' : isArtsy ? '#888' : isFamily ? '#A39DAE' : isFoodie ? 'rgba(232,240,255,0.5)' : '#888';
  const hoverBg = isDegen ? 'rgba(237,255,0,0.08)' : isLifestyle ? 'rgba(45,106,79,0.15)' : isArtsy ? 'rgba(0,0,0,0.03)' : isFamily ? 'rgba(255,140,66,0.06)' : isFoodie ? 'rgba(37,99,235,0.08)' : 'rgba(0,0,0,0.03)';
  const itemRadius = isDegen ? '4px' : isLifestyle ? '12px' : isArtsy ? '2px' : isFamily ? '14px' : isFoodie ? '10px' : '6px';
  const headingFont = tokens.headingFont;
  const bodyFont = tokens.bodyFont;

  return (
    <div className="relative inline-block">
      {children ? (
        children({ onClick: () => setOpen(!open), ref: triggerRef })
      ) : (
        <button
          ref={triggerRef}
          onClick={() => setOpen(!open)}
          className="flex items-center gap-2 cursor-pointer transition-all hover:opacity-80"
          style={{
            padding: compact ? '8px' : '8px 14px',
            backgroundColor: tokens.surfaceBg || 'transparent',
            border: `1px solid ${tokens.cardBorder || 'rgba(0,0,0,0.1)'}`,
            borderRadius: tokens.aesthetic === 'degen' ? '4px' : tokens.aesthetic === 'artsy' ? '2px' : '8px',
            color: tokens.textSecondary || '#888',
            fontSize: '0.8rem',
            fontFamily: headingFont,
          }}
        >
          <Share2 size={14} />
          {!compact && <span>Share</span>}
        </button>
      )}

      <AnimatePresence>
        {open && (
          <>
            {/* Backdrop for mobile */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[9998] sm:hidden"
              style={{ background: 'rgba(0,0,0,0.4)' }}
              onClick={() => setOpen(false)}
            />
            <motion.div
              ref={menuRef}
              initial={{ opacity: 0, y: 8, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 8, scale: 0.95 }}
              transition={{ duration: 0.15 }}
              className="fixed sm:absolute bottom-0 left-0 right-0 sm:bottom-auto sm:left-auto sm:right-0 sm:top-full sm:mt-2 z-[9999] backdrop-blur-xl overflow-hidden"
              style={{
                background: menuBg,
                border: `1px solid ${menuBorder}`,
                borderRadius: typeof window !== 'undefined' && window.innerWidth < 640 ? '20px 20px 0 0' : menuRadius,
                boxShadow: '0 8px 40px rgba(0,0,0,0.2)',
                minWidth: '260px',
                maxWidth: '320px',
              }}
            >
              {/* Header */}
              <div className="flex items-center justify-between px-4 pt-4 pb-2">
                <span style={{ fontSize: '0.7rem', fontFamily: headingFont, fontWeight: 700, color: textSecondary, letterSpacing: '0.12em', textTransform: 'uppercase' }}>
                  Share
                </span>
                <button onClick={() => setOpen(false)} className="p-1 cursor-pointer hover:opacity-60 transition-opacity sm:hidden" style={{ color: textSecondary }}>
                  <X size={16} />
                </button>
              </div>

              {/* Platform list */}
              <div className="px-2 pb-2 space-y-0.5">
                {platforms.map((platform) => {
                  const isCopied = copied === platform.key;
                  return (
                    <button
                      key={platform.key}
                      onClick={() => handlePlatformClick(platform)}
                      className="w-full flex items-center gap-3 px-3 py-2.5 cursor-pointer transition-all group text-left"
                      style={{
                        borderRadius: itemRadius,
                        backgroundColor: isCopied ? `${platform.color}15` : 'transparent',
                      }}
                      onMouseEnter={(e) => { if (!isCopied) (e.currentTarget.style.backgroundColor = hoverBg); }}
                      onMouseLeave={(e) => { if (!isCopied) (e.currentTarget.style.backgroundColor = 'transparent'); }}
                    >
                      <div
                        className="flex items-center justify-center flex-shrink-0 transition-transform group-hover:scale-110"
                        style={{
                          width: 34, height: 34, borderRadius: '10px',
                          backgroundColor: `${platform.color}15`,
                          color: platform.color,
                        }}
                      >
                        {isCopied ? <Check size={16} /> : platform.icon}
                      </div>
                      <div className="flex-1 min-w-0">
                        <span className="block text-sm" style={{ color: textPrimary, fontFamily: bodyFont, fontWeight: 600 }}>
                          {platform.label}
                        </span>
                        {isCopied && platform.note && (
                          <motion.span
                            initial={{ opacity: 0, y: -4 }}
                            animate={{ opacity: 1, y: 0 }}
                            className="block text-[10px] mt-0.5"
                            style={{ color: platform.color, fontFamily: bodyFont }}
                          >
                            {platform.note}
                          </motion.span>
                        )}
                      </div>
                      {!platform.getUrl('', '', '') && !isCopied && (
                        <Link2 size={12} style={{ color: textSecondary, flexShrink: 0 }} />
                      )}
                    </button>
                  );
                })}

                {/* Divider */}
                <div className="mx-3 my-1" style={{ height: 1, background: menuBorder }} />

                {/* Copy link */}
                <button
                  onClick={() => copyLink()}
                  className="w-full flex items-center gap-3 px-3 py-2.5 cursor-pointer transition-all text-left"
                  style={{ borderRadius: itemRadius }}
                  onMouseEnter={(e) => { if (copied !== 'link') (e.currentTarget.style.backgroundColor = hoverBg); }}
                  onMouseLeave={(e) => { (e.currentTarget.style.backgroundColor = 'transparent'); }}
                >
                  <div
                    className="flex items-center justify-center flex-shrink-0"
                    style={{
                      width: 34, height: 34, borderRadius: '10px',
                      backgroundColor: `${modeColor}15`,
                      color: copied === 'link' ? '#10B981' : modeColor,
                    }}
                  >
                    {copied === 'link' ? <Check size={16} /> : <Link2 size={16} />}
                  </div>
                  <span className="text-sm" style={{ color: textPrimary, fontFamily: bodyFont, fontWeight: 600 }}>
                    {copied === 'link' ? 'Copied!' : 'Copy Link'}
                  </span>
                </button>
              </div>

              {/* Mobile safe area */}
              <div className="h-2 sm:hidden" />
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}