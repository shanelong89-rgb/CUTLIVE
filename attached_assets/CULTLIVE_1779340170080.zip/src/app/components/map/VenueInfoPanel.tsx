/**
 * VenueInfoPanel — mode-aware venue detail slide-over panel
 */
import { Link } from 'react-router';
import { motion } from 'motion/react';
import { X, Navigation, PersonStanding, ChevronRight, Heart } from 'lucide-react';
import { useState, useMemo } from 'react';
import { useMode } from '../../context/ModeContext';
import { modeConfig, type Mode, type Venue } from '../../data/mock-data';
import { getDesignTokens, isLightMode } from '../../data/mode-styles';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { CIcon } from '../CIcon';
import { getVenueLink } from '../../utils/event-helpers';
import { CategoryPills } from '../CategoryPills';
import { useData } from '../../context/DataContext';
import { useCollections } from '../../context/CollectionsContext';
import { useAuth } from '../../context/AuthContext';
import { toast } from 'sonner';

export function VenueInfoPanel({
  venue,
  onClose,
  onStreetView,
}: {
  venue: Venue;
  onClose: () => void;
  onStreetView: () => void;
}) {
  const { currentMode } = useMode();
  const modeColor = currentMode && currentMode !== 'lifestyle' ? modeConfig[currentMode].color : currentMode === 'lifestyle' ? '#2D6A4F' : '#1A1A1A';
  const tokens = getDesignTokens(currentMode);
  const light = isLightMode(currentMode);

  const isDegen = currentMode === 'degen';
  const { recaps, allEvents } = useData();
  const venueRecapCount = useMemo(() => {
    return recaps.filter(r => {
      if (r.venueId === venue.id) return true;
      if (r.eventId) {
        const ev = allEvents.find(e => e.id === r.eventId);
        if (ev && ev.venueId === venue.id) return true;
      }
      return false;
    }).length;
  }, [recaps, allEvents, venue.id]);
  const isArtsy = currentMode === 'artsy';
  const isFamily = currentMode === 'family';
  const isFoodie = currentMode === 'foodie';

  const isLifestyle = currentMode === 'lifestyle';
  const panelBg = isDegen ? 'rgba(10, 10, 10, 0.96)' : isArtsy ? 'rgba(245, 241, 235, 0.96)' : isFamily ? 'rgba(255, 248, 240, 0.96)' : isFoodie ? 'rgba(10, 18, 40, 0.96)' : isLifestyle ? 'rgba(18, 42, 32, 0.96)' : 'rgba(250, 250, 248, 0.97)';
  const panelBorder = isDegen ? '#EDFF00' : isArtsy ? 'rgba(0,0,0,0.08)' : isFamily ? 'rgba(0,0,0,0.06)' : isFoodie ? 'rgba(37,99,235,0.12)' : isLifestyle ? 'rgba(45,106,79,0.2)' : 'rgba(0,0,0,0.08)';
  const textMain = isDegen ? '#EDFF00' : isArtsy ? '#1a1a1a' : isFamily ? '#2D2A32' : isFoodie ? tokens.textPrimary : isLifestyle ? '#FFFFFF' : '#1a1a1a';
  const textSub = isDegen ? 'rgba(255,255,255,0.5)' : isArtsy ? '#8a8a8a' : isFamily ? '#6B6574' : isFoodie ? tokens.textSecondary : isLifestyle ? 'rgba(149,213,178,0.7)' : '#555';
  const textMuted = isDegen ? 'rgba(255,255,255,0.3)' : isArtsy ? '#bbb' : isFamily ? '#A39DAE' : isFoodie ? tokens.textMuted : isLifestyle ? 'rgba(149,213,178,0.5)' : '#999';
  const cardRadius = isDegen ? '4px' : isArtsy ? '0px' : isFamily ? '24px' : isFoodie ? '20px' : isLifestyle ? '16px' : '12px';
  const surfaceBg = isDegen ? 'rgba(237,255,0,0.06)' : isArtsy ? 'rgba(0,0,0,0.03)' : isFamily ? 'rgba(255,140,66,0.06)' : isFoodie ? 'rgba(37,99,235,0.06)' : isLifestyle ? 'rgba(45,106,79,0.1)' : 'rgba(0,0,0,0.03)';
  const closeBtnBg = isDegen ? 'rgba(237,255,0,0.1)' : isArtsy ? 'rgba(0,0,0,0.06)' : isFamily ? 'rgba(255,140,66,0.1)' : isFoodie ? 'rgba(255,255,255,0.1)' : isLifestyle ? 'rgba(149,213,178,0.15)' : 'rgba(0,0,0,0.06)';

  const { toggleQuickSave, isQuickSaved } = useCollections();
  const { user } = useAuth();
  const [saving, setSaving] = useState(false);
  const saved = isQuickSaved(venue.id);

  const handleQuickSave = async (e: { stopPropagation: () => void }) => {
    e.stopPropagation();
    if (!user) return;
    setSaving(true);
    try {
      await toggleQuickSave(venue.id, 'venue');
      toast(saved ? 'Removed from Quick Saves' : '❤️ Saved to Quick Saves', {
        description: venue.name,
      });
    } catch {}
    setSaving(false);
  };

  return (
    <motion.div
      initial={{ x: '100%', opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      exit={{ x: '100%', opacity: 0 }}
      transition={{ type: 'spring', stiffness: 300, damping: 30 }}
      className="absolute top-0 right-0 bottom-0 w-full sm:w-[380px] z-[1000] backdrop-blur-xl border-l overflow-y-auto"
      style={{ background: panelBg, borderColor: panelBorder }}
    >
      <button
        onClick={onClose}
        className="absolute top-4 right-4 z-10 p-1.5 transition-all"
        style={{ borderRadius: isDegen ? '4px' : isArtsy ? '2px' : '9999px', background: closeBtnBg, color: textSub }}
      >
        <X size={16} />
      </button>

      <div className="relative h-56 overflow-hidden">
        <ImageWithFallback src={venue.image} alt={venue.name} className="h-full w-full object-cover" />
        <div
          className="absolute inset-0"
          style={{ background: `linear-gradient(to top, ${isDegen ? '#0A0A0A' : isArtsy ? '#F5F1EB' : isFamily ? '#FFF8F0' : isFoodie ? '#0A1220' : isLifestyle ? '#122A20' : '#ffffff'}, transparent)` }}
        />
        {!venue.id?.startsWith('sub_') && !venue.id?.startsWith('ra_') && (
          <button
            onClick={onStreetView}
            className="absolute bottom-4 right-4 flex items-center gap-1.5 px-3 py-1.5 text-xs backdrop-blur-sm transition-all hover:scale-105"
            style={{
              backgroundColor: isDegen ? '#EDFF00' : `${modeColor}30`,
              color: isDegen ? '#0A0A0A' : modeColor,
              border: isDegen ? 'none' : `1px solid ${modeColor}40`,
              borderRadius: cardRadius,
              fontFamily: tokens.headingFont,
              fontWeight: isDegen ? 700 : 500,
              textTransform: isDegen ? 'uppercase' : 'none',
            }}
          >
            <PersonStanding size={13} /> Street View
          </button>
        )}
      </div>

      <div className="p-5 space-y-4">
        <div>
          {venue.id?.startsWith('sub_') && (
            <span className="inline-block mb-2 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider" style={{ backgroundColor: `${modeColor}15`, color: modeColor, borderRadius: '4px' }}>
              Community Event {venue.subcategory === 'geocoded' ? '📍' : '· Approx. location'}
            </span>
          )}
          {venue.id?.startsWith('ra_') && (
            <span className="inline-block mb-2 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider" style={{ backgroundColor: `${modeColor}15`, color: modeColor, borderRadius: '4px' }}>
              RA Event {venue.subcategory === 'geocoded' ? '📍' : '· Approx. location'}
            </span>
          )}
          <div className="flex items-center gap-2 mb-1">
            <CIcon id={venue.category} size={20} mode="auto" glow animated />
            <h3 style={{ fontSize: '1.3rem', color: textMain, fontFamily: tokens.headingFont, fontWeight: isDegen ? 700 : isArtsy ? 400 : 600, textTransform: isDegen ? 'uppercase' : 'none', letterSpacing: isDegen ? '-0.02em' : 'normal' }}>{venue.name}</h3>
          </div>
          {venue.nameZh && <p className="text-sm" style={{ color: textMuted, fontFamily: tokens.bodyFont }}>{venue.nameZh}</p>}
          {venue.categories && venue.categories.length > 1 && (
            <div className="mt-2">
              <CategoryPills categories={venue.categories} size="sm" showPrimary maxVisible={5} />
            </div>
          )}
        </div>

        <p className="text-sm" style={{ color: textSub, fontFamily: tokens.bodyFont, lineHeight: isArtsy ? '1.8' : '1.6' }}>
          {venue.description && venue.description.length > 250 ? (
            <DescriptionClamp text={venue.description} limit={250} color={textSub} accentColor={modeColor} font={tokens.bodyFont} />
          ) : venue.description}
        </p>

        {!venue.id?.startsWith('sub_') && !venue.id?.startsWith('ra_') && <div className="space-y-2">
          <span className="text-xs tracking-widest uppercase" style={{ color: textMuted, fontFamily: tokens.headingFont }}>Mode Scores</span>
          <div className="grid grid-cols-2 gap-2">
            {(Object.entries(venue.modeScores || {}) as [Mode, number][]).map(([mode, score]) => (
              <div
                key={mode}
                className="flex items-center gap-2 p-2"
                style={{
                  borderRadius: cardRadius,
                  backgroundColor: currentMode === mode ? `${modeConfig[mode].color}15` : surfaceBg,
                  border: currentMode === mode ? `1px solid ${modeConfig[mode].color}30` : '1px solid transparent',
                }}
              >
                <CIcon id={mode} size={14} mode={mode} glow={currentMode === mode} />
                <div className="flex-1">
                  <div className="h-1 overflow-hidden" style={{ borderRadius: '2px', backgroundColor: isDegen ? 'rgba(255,255,255,0.08)' : light ? 'rgba(0,0,0,0.06)' : 'rgba(255,255,255,0.1)' }}>
                    <div
                      className="h-full transition-all duration-500"
                      style={{ width: `${score * 100}%`, backgroundColor: modeConfig[mode].color, borderRadius: '2px' }}
                    />
                  </div>
                </div>
                <span className="text-[10px]" style={{ color: textMuted }}>{Math.round(score * 100)}</span>
              </div>
            ))}
          </div>
        </div>}

        <div className="flex flex-wrap gap-1.5">
          {(venue.vibeTags || []).map((tag) => (
            <span
              key={tag}
              className="px-2.5 py-1 text-[11px]"
              style={{ backgroundColor: `${modeColor}15`, color: `${modeColor}aa`, borderRadius: isDegen ? '2px' : isArtsy ? '0' : '9999px', fontFamily: isDegen ? tokens.headingFont : tokens.bodyFont, textTransform: isDegen ? 'uppercase' : 'none', fontWeight: isDegen ? 700 : 400, fontSize: isDegen ? '0.6rem' : '0.68rem' }}
            >
              #{tag}
            </span>
          ))}
        </div>

        {!venue.id?.startsWith('sub_') && !venue.id?.startsWith('ra_') && (
          <div className="grid grid-cols-3 gap-3">
            {[
              { value: venue.upcomingEvents, label: 'Upcoming' },
              { value: venueRecapCount, label: 'Recaps' },
              { value: '$'.repeat(venue.priceRange), label: 'Price' },
            ].map((stat) => (
              <div key={stat.label} className="p-3 text-center" style={{ borderRadius: cardRadius, backgroundColor: surfaceBg }}>
                <div style={{ fontSize: '1.1rem', color: textMain, fontFamily: tokens.headingFont, fontWeight: isDegen ? 700 : 500 }}>{stat.value}</div>
                <div className="text-[10px]" style={{ color: textMuted, fontFamily: tokens.bodyFont }}>{stat.label}</div>
              </div>
            ))}
          </div>
        )}

        <div className="p-3" style={{ borderRadius: cardRadius, backgroundColor: surfaceBg }}>
          <div className="flex items-center gap-2 mb-1">
            <Navigation size={12} style={{ color: textMuted }} />
            <span className="text-xs" style={{ color: textSub, fontFamily: tokens.bodyFont }}>{venue.address}</span>
          </div>
          <span className="text-xs" style={{ color: textMuted, fontFamily: tokens.bodyFont }}>{venue.district}</span>
        </div>

        <div className="flex gap-2">
          <Link
            to={getVenueLink(venue)}
            className="flex flex-1 items-center justify-center gap-2 py-3 text-sm transition-all hover:opacity-90"
            style={{
              backgroundColor: isDegen ? '#EDFF00' : modeColor,
              color: isDegen ? '#0A0A0A' : '#fff',
              borderRadius: cardRadius,
              fontFamily: tokens.headingFont,
              fontWeight: isDegen ? 700 : isArtsy ? 400 : 600,
              textTransform: isDegen ? 'uppercase' : 'none',
              letterSpacing: isDegen ? '0.05em' : isArtsy ? '0.15em' : 'normal',
              fontSize: isDegen || isArtsy ? '0.75rem' : '0.875rem',
            }}
          >
            {(venue.id?.startsWith('sub_') || venue.id?.startsWith('ra_')) ? 'View Event' : isArtsy ? 'Details' : 'View Full Details'} <ChevronRight size={16} />
          </Link>
          {user && (
            <button
              onClick={handleQuickSave}
              className="flex items-center justify-center py-3 px-4 text-sm transition-all hover:scale-105 cursor-pointer"
              style={{
                backgroundColor: saved ? `${modeColor}15` : surfaceBg,
                color: saved ? modeColor : textMuted,
                borderRadius: cardRadius,
                border: saved ? `1px solid ${modeColor}30` : `1px solid ${panelBorder}`,
              }}
            >
              <Heart size={18} fill={saved ? modeColor : 'none'} />
            </button>
          )}
        </div>
      </div>
    </motion.div>
  );
}

const DESC_LIMIT = 180;

function DescriptionClamp({ text, limit, color, accentColor, font }: { text: string; limit: number; color: string; accentColor: string; font: string }) {
  const [expanded, setExpanded] = useState(false);
  if (text.length <= limit) return <>{text}</>;
  return (
    <>
      {expanded ? text : text.slice(0, limit).replace(/\s+\S*$/, '') + '…'}
      <button
        onClick={() => setExpanded(!expanded)}
        className="ml-1 font-medium cursor-pointer hover:underline"
        style={{ color: accentColor, fontFamily: font, fontSize: 'inherit' }}
      >
        {expanded ? 'Show less' : 'Read more'}
      </button>
    </>
  );
}