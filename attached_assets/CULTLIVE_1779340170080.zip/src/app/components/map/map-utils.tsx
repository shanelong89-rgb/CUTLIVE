/**
 * Shared map utilities — marker icons, coordinate helpers, Leaflet sub-components
 */
import { useEffect } from 'react';
import L from 'leaflet';
import { useMap, useMapEvents } from './LeafletWrapper';
import { getMarkerSvg } from '../CIcon';
import type { Venue, CulturalEvent, Mode } from '../../data/mock-data';

// ─── District → approximate coordinates for mapping submitted events ───
export const DISTRICT_COORDS: Record<string, [number, number]> = {
  'Central': [22.2810, 114.1585],
  'Wan Chai': [22.2783, 114.1747],
  'Causeway Bay': [22.2800, 114.1840],
  'Tsim Sha Tsui': [22.2988, 114.1722],
  'Mong Kok': [22.3193, 114.1694],
  'Sham Shui Po': [22.3303, 114.1622],
  'West Kowloon': [22.3050, 114.1600],
  'Sheung Wan': [22.2870, 114.1500],
  'Quarry Bay': [22.2880, 114.2120],
  'Kennedy Town': [22.2815, 114.1280],
  'Tai Kwun': [22.2815, 114.1540],
  'Wong Chuk Hang': [22.2480, 114.1690],
  'Aberdeen': [22.2480, 114.1560],
  'Stanley': [22.2190, 114.2115],
  'Sai Kung': [22.3815, 114.2710],
  'Tai Po': [22.4510, 114.1690],
  'Sha Tin': [22.3870, 114.1950],
  'Tuen Mun': [22.3900, 113.9730],
  'Yuen Long': [22.4450, 114.0220],
  'Lantau': [22.2660, 113.9460],
  'Discovery Bay': [22.2930, 114.0150],
  'Admiralty': [22.2790, 114.1650],
  'North Point': [22.2910, 114.2000],
  'Taikoo': [22.2870, 114.2180],
  'Kwun Tong': [22.3120, 114.2260],
  'Hung Hom': [22.3050, 114.1830],
  'Jordan': [22.3050, 114.1710],
  'Yau Ma Tei': [22.3130, 114.1705],
};

/** Convert a published submission event into a Venue-like object for the map */
export function submissionToVenue(event: CulturalEvent): Venue | null {
  if (!event.id?.startsWith('sub_')) return null;

  // Use real geocoded coordinates if available, otherwise fall back to district approximation
  let lat: number, lng: number;
  let isGeocoded = false;
  if (event.lat && event.lng) {
    lat = event.lat;
    lng = event.lng;
    isGeocoded = true;
  } else {
    const coords = DISTRICT_COORDS[event.district] || DISTRICT_COORDS['Central'];
    let hash = 0;
    for (let i = 0; i < event.id.length; i++) hash = ((hash << 5) - hash + event.id.charCodeAt(i)) | 0;
    const jitter = (seed: number) => ((((seed * 9301 + 49297) % 233280) / 233280) - 0.5) * 0.004;
    lat = coords[0] + jitter(hash);
    lng = coords[1] + jitter(hash + 1);
  }

  const categoryModeMap: Record<string, Partial<Record<Mode, number>>> = {
    'nightlife': { degen: 0.9 },
    'art': { artsy: 0.9 },
    'workshops': { artsy: 0.7, lifestyle: 0.5 },
    'food': { foodie: 0.9 },
    'family': { family: 0.9 },
    'run-clubs': { lifestyle: 0.9 },
    'wellness': { lifestyle: 0.8 },
    'hikes': { lifestyle: 0.8 },
    'coffee-raves': { lifestyle: 0.7, foodie: 0.5 },
    'meetups': { lifestyle: 0.7 },
    'other': { lifestyle: 0.5 },
  };
  return {
    id: event.id,
    name: event.title,
    nameZh: '',
    description: event.description,
    category: event.category || 'other',
    categories: event.categories?.length ? event.categories : (event.category ? [event.category] : []),
    subcategory: isGeocoded ? 'geocoded' : 'approximate',
    lat,
    lng,
    district: event.district || '',
    address: event.venueName || event.district || '',
    image: event.image || '',
    modeScores: (() => {
      const cats = event.categories?.length ? event.categories : [event.category || 'other'];
      const merged: Partial<Record<Mode, number>> = {};
      cats.forEach((c: string) => {
        const scores = categoryModeMap[c] || { lifestyle: 0.5 };
        Object.entries(scores).forEach(([m, s]) => {
          merged[m as Mode] = Math.max(merged[m as Mode] || 0, s);
        });
      });
      return merged;
    })(),
    vibeTags: event.modeTags || [],
    priceRange: 1,
    upcomingEvents: 1,
    pastRecaps: 0,
  };
}

/** Convert an RA-imported event into a Venue-like object for the map */
export function raEventToVenue(event: CulturalEvent, existingVenueIds?: Set<string>): Venue | null {
  if (!event.id?.startsWith('ra_') && !event.id?.startsWith('lsa_') && !event.id?.startsWith('apify_')) return null;

  // Skip if this event already has a real venue linked AND that venue exists in the current venue list
  // (If the venue doesn't exist in the list — e.g. filtered out by mode — we still show the event as a pin)
  if (event.venueId && event.venueId.startsWith('venue_') && existingVenueIds?.has(event.venueId)) return null;

  // RA events need lat/lng — skip if missing
  let lat: number | undefined, lng: number | undefined;
  if (event.lat && event.lng && !isNaN(event.lat) && !isNaN(event.lng) && event.lat !== 0 && event.lng !== 0) {
    lat = event.lat;
    lng = event.lng;
  } else if (event.district) {
    // Fall back to district approximation
    const coords = DISTRICT_COORDS[event.district] || DISTRICT_COORDS['Central'];
    let hash = 0;
    for (let i = 0; i < event.id.length; i++) hash = ((hash << 5) - hash + event.id.charCodeAt(i)) | 0;
    const jitter = (seed: number) => ((((seed * 9301 + 49297) % 233280) / 233280) - 0.5) * 0.004;
    lat = coords[0] + jitter(hash);
    lng = coords[1] + jitter(hash + 1);
  } else {
    return null; // No location data at all
  }

  const categoryModeMap: Record<string, Partial<Record<Mode, number>>> = {
    'nightlife': { degen: 0.9 },
    'music': { degen: 0.85 },
    'art': { artsy: 0.9 },
    'exhibition': { artsy: 0.85 },
    'workshop': { artsy: 0.7, lifestyle: 0.5 },
    'film': { artsy: 0.7 },
    'theatre': { artsy: 0.8 },
    'food': { foodie: 0.9 },
    'dining': { foodie: 0.85 },
    'family': { family: 0.9 },
    'wellness': { lifestyle: 0.8 },
    'festival': { degen: 0.7, lifestyle: 0.5 },
    'other': { lifestyle: 0.5 },
  };

  const cats = event.categories?.length ? event.categories : [event.category || 'nightlife'];
  const merged: Partial<Record<Mode, number>> = {};
  cats.forEach((c: string) => {
    const scores = categoryModeMap[c] || { lifestyle: 0.5 };
    Object.entries(scores).forEach(([m, s]) => {
      merged[m as Mode] = Math.max(merged[m as Mode] || 0, s);
    });
  });
  // Also include modeTags / modes from the event itself
  const modeTags = event.modeTags || (event as any).modes || [];
  modeTags.forEach((m: string) => {
    if (['degen', 'artsy', 'foodie', 'family', 'lifestyle'].includes(m)) {
      merged[m as Mode] = Math.max(merged[m as Mode] || 0, 0.8);
    }
  });

  return {
    id: event.id,
    name: event.title,
    nameZh: '',
    description: event.description || '',
    category: cats[0] || 'nightlife',
    categories: cats,
    subcategory: (event.lat && event.lng) ? 'geocoded' : 'approximate',
    lat: lat!,
    lng: lng!,
    district: event.district || (event as any).venueName || '',
    address: (event as any).venueName || event.district || '',
    image: event.image || '',
    modeScores: merged,
    vibeTags: modeTags,
    priceRange: 2,
    upcomingEvents: 1,
    pastRecaps: 0,
  };
}

// ─── Marker icon creator — mode-aware, uses SVG icons ───
export function createMarkerIcon(category: string, color: string, isActive: boolean, aesthetic: string, neutralMode = false) {
  const size = isActive ? 48 : 40;
  const iconSize = isActive ? 20 : 16;
  const isBoldPoster = aesthetic === 'bold-poster';
  const isEditorial = aesthetic === 'editorial-minimal';
  const isWarm = aesthetic === 'warm-playful';

  // Neutral mode: white-filled markers with colored accent for strong visibility on light maps
  if (neutralMode) {
    const neutralBg = isActive ? color : '#FFFFFF';
    const neutralBorder = `2px solid ${isActive ? color : `${color}cc`}`;
    const neutralIconColor = isActive ? '#FFFFFF' : color;
    const neutralShadow = isActive
      ? `0 4px 16px ${color}50, 0 2px 6px rgba(0,0,0,0.12)`
      : `0 2px 10px rgba(0,0,0,0.12), 0 1px 3px rgba(0,0,0,0.08)`;
    const svgHtml = getMarkerSvg(category, iconSize, neutralIconColor);
    return L.divIcon({
      className: 'custom-marker',
      html: `
        <div style="
          width: ${size}px;
          height: ${size}px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 50%;
          background: ${neutralBg};
          border: ${neutralBorder};
          cursor: pointer;
          transition: all 0.3s ease;
          box-shadow: ${neutralShadow};
          ${isActive ? 'animation: pulse 2s infinite;' : ''}
        ">${svgHtml}</div>
      `,
      iconSize: [size, size],
      iconAnchor: [size / 2, size / 2],
    });
  }

  const radius = isBoldPoster ? '4px' : isEditorial ? '2px' : isWarm ? '50%' : '50%';
  const bg = isBoldPoster
    ? (isActive ? '#0A0A0A' : '#EDFF00')
    : `${color}20`;
  const border = isBoldPoster
    ? `2px solid ${isActive ? '#D600FF' : '#0A0A0A'}`
    : `2px solid ${color}`;
  const shadow = isBoldPoster
    ? 'none'
    : `0 0 ${isActive ? '20' : '10'}px ${color}40`;
  const iconColor = isBoldPoster
    ? (isActive ? '#D600FF' : '#0A0A0A')
    : color;
  const svgHtml = getMarkerSvg(category, iconSize, iconColor);

  return L.divIcon({
    className: 'custom-marker',
    html: `
      <div style="
        width: ${size}px;
        height: ${size}px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: ${radius};
        background: ${bg};
        border: ${border};
        backdrop-filter: blur(8px);
        cursor: pointer;
        transition: all 0.3s ease;
        box-shadow: ${shadow};
        ${isActive && !isBoldPoster ? `animation: pulse 2s infinite;` : ''}
      ">${svgHtml}</div>
    `,
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2],
  });
}

/** Community event marker — distinctive star/heart shape with pulsing ring for geocoded pins */
export function createCommunityMarkerIcon(category: string, color: string, isActive: boolean, isGeocoded: boolean) {
  const size = isActive ? 50 : 42;
  const iconSize = isActive ? 18 : 14;
  const svgHtml = getMarkerSvg(category, iconSize, isActive ? '#FFFFFF' : color);
  const badgeColor = isGeocoded ? '#10b981' : '#f59e0b';
  const badgeIcon = isGeocoded ? '📍' : '≈';
  return L.divIcon({
    className: 'custom-marker community-marker',
    html: `
      <div style="position:relative;">
        ${isActive ? `<div style="
          position:absolute; top:50%; left:50%; transform:translate(-50%,-50%);
          width:${size + 14}px; height:${size + 14}px; border-radius:50%;
          border:2px solid ${color}60; animation: communityPulse 2s infinite;
        "></div>` : ''}
        <div style="
          width: ${size}px; height: ${size}px;
          display: flex; align-items: center; justify-content: center;
          border-radius: 50%;
          background: ${isActive ? color : `linear-gradient(135deg, ${color}18, ${color}30)`};
          border: 2.5px solid ${color};
          cursor: pointer;
          transition: all 0.3s ease;
          box-shadow: ${isActive
            ? `0 4px 20px ${color}50, 0 0 0 3px ${color}20`
            : `0 2px 12px ${color}30, 0 1px 3px rgba(0,0,0,0.1)`};
        ">${svgHtml}</div>
        <div style="
          position:absolute; top:-4px; right:-4px;
          width:18px; height:18px;
          background: ${badgeColor}; color: white;
          border-radius:50%; border:2px solid white;
          display:flex; align-items:center; justify-content:center;
          font-size:8px; font-weight:700;
          box-shadow:0 1px 4px rgba(0,0,0,0.2);
        ">${badgeIcon}</div>
      </div>
    `,
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2],
  });
}

// ─── Lifestyle marker icon ───
export function createLifestyleMarkerIcon(category: string, isActive: boolean) {
  const size = isActive ? 48 : 38;
  const categoryEmojis: Record<string, string> = {
    'run-clubs': '🏃', 'wellness': '🧘', 'hikes': '⛰️',
    'coffee-raves': '☕', 'workshops': '🎨', 'meetups': '🤝',
  };
  const emoji = categoryEmojis[category] || '🌿';
  return L.divIcon({
    className: 'custom-marker',
    html: `
      <div style="
        width: ${size}px;
        height: ${size}px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        background: ${isActive ? 'rgba(45,106,79,0.95)' : 'rgba(250,250,245,0.92)'};
        border: 2px solid ${isActive ? '#95D5B2' : '#2D6A4F'};
        backdrop-filter: blur(8px);
        cursor: pointer;
        transition: all 0.3s ease;
        box-shadow: 0 0 ${isActive ? '20' : '10'}px rgba(45,106,79,0.3);
        font-size: ${isActive ? '20px' : '16px'};
        ${isActive ? 'animation: pulse 2s infinite;' : ''}
      ">${emoji}</div>
    `,
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2],
  });
}

// ─── Lifestyle venue marker icon ───
export function createLifestyleVenueMarkerIcon(isActive: boolean) {
  const size = isActive ? 44 : 34;
  return L.divIcon({
    className: 'custom-marker',
    html: `
      <div style="
        width: ${size}px;
        height: ${size}px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 12px;
        background: ${isActive ? '#2D6A4F' : 'rgba(250,250,245,0.95)'};
        border: 2px solid ${isActive ? '#95D5B2' : '#2D6A4F'};
        backdrop-filter: blur(8px);
        cursor: pointer;
        transition: all 0.3s ease;
        box-shadow: 0 0 ${isActive ? '20' : '8'}px rgba(45,106,79,${isActive ? '0.5' : '0.2'});
        ${isActive ? 'animation: pulse 2s infinite;' : ''}
      ">
        <svg width="${isActive ? 20 : 16}" height="${isActive ? 20 : 16}" viewBox="0 0 24 24" fill="none" stroke="${isActive ? '#95D5B2' : '#2D6A4F'}" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
          <circle cx="12" cy="10" r="3"/>
        </svg>
      </div>
    `,
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2],
  });
}

// ─── Map bounds tracker — reports visible bounds on move/zoom ───
export interface MapBounds {
  north: number;
  south: number;
  east: number;
  west: number;
}

export function MapBoundsTracker({ onBoundsChange }: { onBoundsChange: (bounds: MapBounds) => void }) {
  const map = useMap();

  useEffect(() => {
    const reportBounds = () => {
      const b = map.getBounds();
      onBoundsChange({
        north: b.getNorth(),
        south: b.getSouth(),
        east: b.getEast(),
        west: b.getWest(),
      });
    };
    // Report initial bounds once map is ready
    reportBounds();
    map.on('moveend', reportBounds);
    return () => { map.off('moveend', reportBounds); };
  }, [map, onBoundsChange]);

  return null;
}

/** Filter venues to only those within the given map bounds */
export function filterVenuesByBounds(venues: Venue[], bounds: MapBounds | null): Venue[] {
  if (!bounds) return venues;
  return venues.filter(v =>
    v.lat >= bounds.south && v.lat <= bounds.north &&
    v.lng >= bounds.west && v.lng <= bounds.east
  );
}

export function MapClickHandler({ onLocationClick, onMapClick }: { onLocationClick: (lat: number, lng: number) => void; onMapClick?: () => void }) {
  useMapEvents({
    click() {
      onMapClick?.();
    },
    dblclick(e) {
      onLocationClick(e.latlng.lat, e.latlng.lng);
    },
  });
  return null;
}

export function FlyToVenue({ venue }: { venue: Venue | null }) {
  const map = useMap();
  useEffect(() => {
    if (venue) {
      map.flyTo([venue.lat, venue.lng], 16, { duration: 1.2 });
    }
  }, [venue, map]);
  return null;
}

// ─── FlyTo for lifestyle events ───
export function FlyToEvent({ event }: { event: { lat?: number; lng?: number } | null }) {
  const map = useMap();
  useEffect(() => {
    if (event?.lat && event?.lng) {
      map.flyTo([event.lat, event.lng], 15, { duration: 1.2 });
    }
  }, [event, map]);
  return null;
}