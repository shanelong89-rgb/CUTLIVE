/**
 * StreetViewPanel — mode-aware immersive street view experience
 */
import { useState, useEffect } from 'react';
import { Link } from 'react-router';
import { motion } from 'motion/react';
import { X, Navigation, ChevronRight, Eye } from 'lucide-react';
import { useMode } from '../../context/ModeContext';
import { modeConfig, type Venue } from '../../data/mock-data';
import { getDesignTokens } from '../../data/mode-styles';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { getVenueLink } from '../../utils/event-helpers';

export function StreetViewPanel({
  venue,
  onClose,
}: {
  venue: Venue;
  onClose: () => void;
}) {
  const { currentMode } = useMode();
  const modeColor = currentMode && currentMode !== 'lifestyle' ? modeConfig[currentMode].color : currentMode === 'lifestyle' ? '#2D6A4F' : '#8338EC';
  const tokens = getDesignTokens(currentMode);
  const [rotation, setRotation] = useState(0);
  const [isAutoRotating, setIsAutoRotating] = useState(true);

  useEffect(() => {
    if (!isAutoRotating) return;
    const interval = setInterval(() => {
      setRotation((r) => (r + 0.2) % 360);
    }, 50);
    return () => clearInterval(interval);
  }, [isAutoRotating]);

  const isDegen = currentMode === 'degen';
  const isArtsy = currentMode === 'artsy';
  const isFamily = currentMode === 'family';
  const chromeBg = isDegen ? 'rgba(10,10,10,0.85)' : isArtsy ? 'rgba(30,25,20,0.8)' : isFamily ? 'rgba(50,40,60,0.7)' : 'rgba(10,10,15,0.85)';
  const chromeRadius = isDegen ? '4px' : isArtsy ? '2px' : isFamily ? '24px' : '12px';
  const labelColor = isDegen ? '#EDFF00' : modeColor;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[9999] bg-black"
    >
      <div
        className="absolute inset-0 overflow-hidden cursor-grab active:cursor-grabbing"
        onMouseDown={() => setIsAutoRotating(false)}
        onMouseUp={() => setIsAutoRotating(true)}
        onMouseMove={(e) => {
          if (e.buttons === 1) setRotation((r) => r + e.movementX * 0.3);
        }}
        onTouchStart={() => setIsAutoRotating(false)}
        onTouchEnd={() => setIsAutoRotating(true)}
        onTouchMove={(e) => {
          const touch = e.touches[0];
          if (touch && (e.target as any)._lastTouchX !== undefined) {
            setRotation((r) => r + (touch.clientX - (e.target as any)._lastTouchX) * 0.3);
          }
          (e.target as any)._lastTouchX = touch.clientX;
        }}
      >
        <div
          className="h-full w-[300%] flex transition-none"
          style={{ transform: `translateX(${-rotation % 100}%)` }}
        >
          <ImageWithFallback src={venue.image} alt={venue.name} className="h-full w-1/3 object-cover" style={{ filter: `hue-rotate(${rotation * 0.5}deg) brightness(0.7)` }} />
          <ImageWithFallback src={venue.image} alt={venue.name} className="h-full w-1/3 object-cover" style={{ filter: `brightness(0.7) saturate(1.3)`, transform: 'scaleX(-1)' }} />
          <ImageWithFallback src={venue.image} alt={venue.name} className="h-full w-1/3 object-cover" style={{ filter: `brightness(0.6) sepia(0.2)` }} />
        </div>

        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background: `
              radial-gradient(ellipse at center, transparent 40%, ${modeColor}15 100%),
              linear-gradient(to bottom, transparent 60%, ${modeColor}20 100%)
            `,
          }}
        />

        {isDegen && (
          <div className="absolute inset-0 pointer-events-none overflow-hidden">
            <div className="absolute top-6 left-6" style={{ color: '#EDFF00', fontFamily: tokens.headingFont, fontSize: '0.6rem', fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', opacity: 0.6 }}>/STREET VIEW</div>
            <div className="absolute bottom-16 right-8" style={{ color: '#D600FF', fontFamily: tokens.headingFont, fontSize: '2.5rem', fontWeight: 700, opacity: 0.08, textTransform: 'uppercase' }}>CULTIVE</div>
          </div>
        )}

        {isArtsy && (
          <div className="absolute inset-0 pointer-events-none" style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg viewBox=\'0 0 200 200\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cfilter id=\'noise\'%3E%3CfeTurbulence type=\'fractalNoise\' baseFrequency=\'0.85\' stitchTiles=\'stitch\'/%3E%3C/filter%3E%3Crect width=\'100%25\' height=\'100%25\' filter=\'url(%23noise)\' opacity=\'0.04\'/%3E%3C/svg%3E")', opacity: 0.5 }} />
        )}
      </div>

      <div className="absolute top-0 left-0 right-0 p-3 sm:p-4 flex items-start justify-between gap-2">
        <div className="backdrop-blur-xl p-3 sm:p-4 max-w-[calc(100%-48px)] sm:max-w-sm" style={{ background: chromeBg, borderRadius: chromeRadius }}>
          <div className="flex items-center gap-2 mb-2">
            <Eye size={14} style={{ color: labelColor }} />
            <span className="text-xs tracking-widest uppercase" style={{ color: labelColor, fontFamily: tokens.headingFont, fontWeight: isDegen ? 700 : 400 }}>
              Street View
            </span>
          </div>
          <h2 className="text-white mb-1" style={{ fontSize: '1.2rem', fontFamily: tokens.headingFont, textTransform: isDegen ? 'uppercase' : 'none' }}>{venue.name}</h2>
          <p className="text-xs text-white/40" style={{ fontFamily: tokens.bodyFont }}>{venue.nameZh}</p>
          <p className="text-xs text-white/50 mt-2" style={{ fontFamily: tokens.bodyFont }}>{venue.address}</p>
          <div className="flex flex-wrap gap-1.5 mt-3">
            {(venue.vibeTags || []).slice(0, 3).map((tag) => (
              <span
                key={tag}
                className="px-2 py-0.5 text-[10px]"
                style={{ backgroundColor: `${modeColor}20`, color: `${modeColor}cc`, borderRadius: isDegen ? '2px' : isArtsy ? '0' : '9999px' }}
              >
                #{tag}
              </span>
            ))}
          </div>
        </div>

        <button
          onClick={onClose}
          className="backdrop-blur-xl p-2 text-white/60 hover:text-white transition-all"
          style={{ background: chromeBg, borderRadius: isDegen ? '4px' : isArtsy ? '2px' : '9999px' }}
        >
          <X size={20} />
        </button>
      </div>

      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 w-[calc(100%-32px)] sm:w-auto">
        <div className="backdrop-blur-xl px-4 sm:px-6 py-2 flex items-center justify-center gap-2 sm:gap-3 w-full sm:w-auto" style={{ background: chromeBg, borderRadius: chromeRadius }}>
          <Navigation
            size={14}
            className="flex-shrink-0"
            style={{ color: labelColor, transform: `rotate(${rotation}deg)`, transition: 'transform 0.1s' }}
          />
          <span className="text-xs text-white/50 flex-shrink-0" style={{ fontFamily: tokens.headingFont }}>{Math.round(rotation % 360)}&deg;</span>
          <span className="text-xs text-white/30 hidden sm:inline">|</span>
          <span className="text-xs text-white/40 hidden sm:inline" style={{ fontFamily: tokens.bodyFont }}>Drag to look around</span>
        </div>
        <Link
          to={getVenueLink(venue)}
          className="flex items-center gap-1.5 text-xs backdrop-blur-xl px-4 py-2 transition-all hover:opacity-80"
          style={{ color: isDegen ? '#0A0A0A' : modeColor, background: isDegen ? '#EDFF00' : chromeBg, borderRadius: chromeRadius, fontFamily: tokens.headingFont, fontWeight: isDegen ? 700 : 400, textTransform: isDegen ? 'uppercase' : 'none', letterSpacing: isDegen ? '0.05em' : 'normal' }}
        >
          {venue.id?.startsWith('sub_') ? 'View Event' : 'Enter Venue'} <ChevronRight size={12} />
        </Link>
      </div>
    </motion.div>
  );
}