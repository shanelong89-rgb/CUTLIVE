/**
 * LifestyleMapView — fully custom lifestyle mode map experience
 */
import { useState, useMemo, useEffect, useRef, useCallback } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMapEvents, useMap } from './LeafletWrapper';
import { motion, AnimatePresence } from 'motion/react';
import { X, MapPin, ArrowRight, Leaf, Users, Mountain, Coffee, BookOpen, Heart, Sparkles, Calendar, Clock, MapIcon, Columns2, List, Building2, Star, Globe, Phone, ExternalLink, Eye } from 'lucide-react';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { ModeSelector } from '../ModeSelector';
import { LC, LF, lifestyleCategories, formatLifestyleDate, culturalEventToLifestyle, type LifestyleCategory, type LifestyleEvent } from '../../data/lifestyle-data';
import { FlyToEvent, createLifestyleMarkerIcon, createLifestyleVenueMarkerIcon } from './map-utils';
import { useData } from '../../context/DataContext';
import type { Venue } from '../../data/mock-data';
import { useCollections } from '../../context/CollectionsContext';
import { useAuth } from '../../context/AuthContext';
import { useEventStats } from '../../context/EventStatsContext';

type ViewMode = 'map' | 'split' | 'list';

// ─── Hoisted map child components (stable React identity prevents unmount/remount) ───
function LifestyleMapClickClear({ onClear }: { onClear: () => void }) {
  useMapEvents({ click: onClear });
  return null;
}

function LifestyleMapSizeInvalidator() {
  const map = useMap();
  useEffect(() => {
    // Multiple invalidations to handle AnimatePresence mode="wait" delays
    const delays = [0, 50, 150, 300, 500, 800, 1200, 2000];
    const timers = delays.map(ms =>
      setTimeout(() => { try { map.invalidateSize(); } catch (_) {} }, ms)
    );

    // Also use ResizeObserver on the map container for robust detection
    const container = map.getContainer();
    let resizeObserver: ResizeObserver | null = null;
    if (container && typeof ResizeObserver !== 'undefined') {
      resizeObserver = new ResizeObserver(() => {
        try { map.invalidateSize(); } catch (_) {}
      });
      resizeObserver.observe(container);
    }

    // Listen for visibility changes (e.g. AnimatePresence opacity transitions)
    const handleVisibility = () => {
      try { map.invalidateSize(); } catch (_) {}
    };
    window.addEventListener('resize', handleVisibility);

    return () => {
      timers.forEach(t => clearTimeout(t));
      resizeObserver?.disconnect();
      window.removeEventListener('resize', handleVisibility);
    };
  }, [map]);
  return null;
}

export function LifestyleMapView() {
  const { events, venues } = useData();
  const { allSavedItemIds } = useCollections();
  const { savedEventIds } = useAuth();
  const { getStats } = useEventStats();

  // Merge both save systems
  const allSavedIds = useMemo(() => {
    const merged = new Set(allSavedItemIds);
    for (const id of savedEventIds) merged.add(id);
    return merged;
  }, [allSavedItemIds, savedEventIds]);

  // ── Defer map mount until container has non-zero dimensions ──
  // Fixes Leaflet initializing with 0-width flex container during AnimatePresence animation
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const [mapReady, setMapReady] = useState(false);
  useEffect(() => {
    const el = mapContainerRef.current;
    if (!el) return;
    // Check immediately
    const check = () => {
      if (el.offsetWidth > 0 && el.offsetHeight > 0) {
        setMapReady(true);
        return true;
      }
      return false;
    };
    if (check()) return;
    // Poll + ResizeObserver fallback
    const timers = [100, 200, 350, 500, 800].map(ms => setTimeout(check, ms));
    let ro: ResizeObserver | null = null;
    if (typeof ResizeObserver !== 'undefined') {
      ro = new ResizeObserver(() => { check(); });
      ro.observe(el);
    }
    return () => { timers.forEach(clearTimeout); ro?.disconnect(); };
  }, []);

  // Filter main events tagged with 'lifestyle' modeTag
  const allLifestyleEvents = events
    .filter(e => e.modeTags?.includes('lifestyle'))
    .map(culturalEventToLifestyle);

  // ── Lifestyle venues: filter venues with lifestyle modeScore >= 0.3 ──
  const lifestyleVenues = useMemo(() => {
    return venues.filter(v =>
      v && v.id && typeof v.lat === 'number' && typeof v.lng === 'number' &&
      !isNaN(v.lat) && !isNaN(v.lng) && v.lat !== 0 && v.lng !== 0 &&
      v.modeScores && (v.modeScores.lifestyle || 0) >= 0.3
    ).sort((a, b) => (b.modeScores?.lifestyle || 0) - (a.modeScores?.lifestyle || 0));
  }, [venues]);

  const [selectedEvent, setSelectedEvent] = useState<LifestyleEvent | null>(null);
  const [selectedVenue, setSelectedVenue] = useState<Venue | null>(null);
  const [categoryFilter, setCategoryFilter] = useState<LifestyleCategory>('all');
  const [hoveredId, setHoveredId] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<ViewMode>('split');
  const [listTab, setListTab] = useState<'events' | 'venues'>('events');
  const [showSavedOnly, setShowSavedOnly] = useState(false);

  // Clear the other selection when one is picked
  const selectEvent = useCallback((event: LifestyleEvent) => { setSelectedEvent(event); setSelectedVenue(null); }, []);
  const selectVenue = useCallback((venue: Venue) => { setSelectedVenue(venue); setSelectedEvent(null); }, []);
  const clearSelection = useCallback(() => { setSelectedEvent(null); setSelectedVenue(null); }, []);

  const categoryIcons: Record<string, typeof Leaf> = {
    'all': Sparkles, 'run-clubs': Users, 'wellness': Leaf, 'hikes': Mountain,
    'coffee-raves': Coffee, 'workshops': BookOpen, 'meetups': Heart,
  };

  const filteredEvents = categoryFilter === 'all'
    ? allLifestyleEvents
    : allLifestyleEvents.filter(e => e.category === categoryFilter);

  // Apply saved filter
  // When showSavedOnly is active, include ALL saved items regardless of category filter
  // so saved events/venues never "disappear" when switching categories
  const displayEvents = useMemo(() => {
    if (!showSavedOnly) return filteredEvents;
    // Show ALL saved lifestyle events, bypassing category filter
    return allLifestyleEvents.filter(e => allSavedIds.has(e.id));
  }, [filteredEvents, allLifestyleEvents, showSavedOnly, allSavedIds]);

  const displayVenues = useMemo(() => {
    if (!showSavedOnly) return lifestyleVenues;
    // Show ALL saved venues (not just lifestyle-scored ones)
    return venues.filter(v =>
      v && v.id && typeof v.lat === 'number' && typeof v.lng === 'number' &&
      !isNaN(v.lat) && !isNaN(v.lng) &&
      allSavedIds.has(v.id)
    );
  }, [lifestyleVenues, venues, showSavedOnly, allSavedIds]);

  const eventsWithCoords = displayEvents.filter(e => e.lat && e.lng);

  const lifestyleMapStyles = `
    .leaflet-popup-content-wrapper {
      background: rgba(18,42,32,0.95) !important;
      color: #FFFFFF !important;
      border: 1px solid rgba(45,106,79,0.3) !important;
      border-radius: 16px !important;
      backdrop-filter: blur(12px);
      font-family: ${LF.heading};
    }
    .leaflet-popup-tip { background: rgba(18,42,32,0.95) !important; }
    .custom-marker { background: transparent !important; border: none !important; }
    @keyframes pulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.1); } }
    @keyframes communityPulse { 0% { transform: translate(-50%,-50%) scale(1); opacity: 0.6; } 50% { transform: translate(-50%,-50%) scale(1.3); opacity: 0.2; } 100% { transform: translate(-50%,-50%) scale(1); opacity: 0.6; } }
    .scrollbar-hide::-webkit-scrollbar { display: none; }
    .scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
  `;

  // ─── View toggle ───
  const viewToggleItems: { key: ViewMode; icon: typeof MapIcon; label: string }[] = [
    { key: 'map', icon: MapIcon, label: 'Map' },
    { key: 'split', icon: Columns2, label: 'Split' },
    { key: 'list', icon: List, label: 'Grid' },
  ];

  const renderViewToggle = () => (
    <div className="backdrop-blur-xl flex overflow-hidden" style={{ background: 'rgba(18,42,32,0.9)', border: '1px solid rgba(45,106,79,0.3)', borderRadius: '12px' }}>
      {viewToggleItems.map((item) => (
        <button
          key={item.key}
          onClick={() => setViewMode(item.key)}
          className="flex items-center gap-1.5 px-3 py-1.5 text-[11px] transition-all cursor-pointer"
          style={{
            background: viewMode === item.key ? 'rgba(45,106,79,0.5)' : 'transparent',
            color: viewMode === item.key ? LC.sage : 'rgba(149,213,178,0.4)',
            fontFamily: LF.body,
            fontWeight: viewMode === item.key ? 600 : 400,
          }}
        >
          <item.icon size={13} />
          {item.label}
        </button>
      ))}
    </div>
  );

  // ─── Category filter pills ───
  const renderCategoryPills = (variant: 'panel' | 'floating' = 'panel') => (
    <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-hide">
      {lifestyleCategories.map((cat) => {
        const Icon = categoryIcons[cat.key] || Sparkles;
        const isActive = categoryFilter === cat.key;
        return (
          <button key={cat.key} onClick={() => setCategoryFilter(cat.key)}
            className="flex items-center gap-1 px-3 py-1.5 text-[10px] whitespace-nowrap transition-all cursor-pointer flex-shrink-0"
            style={{
              borderRadius: '9999px',
              backgroundColor: isActive ? LC.forest : (variant === 'floating' ? 'transparent' : 'rgba(45,106,79,0.1)'),
              color: isActive ? LC.white : LC.sage,
              border: isActive ? 'none' : `1px solid ${LC.deepForestBorder}`,
              fontFamily: LF.body, fontWeight: isActive ? 600 : 400,
            }}>
            <Icon size={11} />
            {cat.label}
          </button>
        );
      })}
    </div>
  );

  // ─── Saved filter button ───
  const renderSavedButton = (variant: 'panel' | 'floating' = 'panel') => (
    <button
      onClick={() => setShowSavedOnly(!showSavedOnly)}
      className="flex items-center gap-1.5 px-2.5 py-1.5 text-[11px] transition-all cursor-pointer"
      style={{
        background: showSavedOnly
          ? 'rgba(45,106,79,0.25)'
          : variant === 'floating' ? 'rgba(18,42,32,0.85)' : 'rgba(45,106,79,0.1)',
        border: `1px solid ${showSavedOnly ? LC.forest : LC.deepForestBorder}`,
        borderRadius: '10px',
        color: showSavedOnly ? LC.sage : 'rgba(149,213,178,0.5)',
        fontFamily: LF.body,
        fontWeight: showSavedOnly ? 600 : 400,
      }}
    >
      <Heart size={12} fill={showSavedOnly ? LC.sage : 'none'} />
      Saved
      {showSavedOnly && allSavedIds.size > 0 && (
        <span className="text-[9px] px-1 py-0.5 rounded-full" style={{ backgroundColor: 'rgba(149,213,178,0.2)', color: LC.sage }}>
          {allSavedIds.size}
        </span>
      )}
    </button>
  );

  // ─── Shared map render ───
  const renderLifestyleMap = (className?: string) => (
    <div ref={mapContainerRef} className={className || 'h-full w-full'} style={{ background: '#FAFAF5' }}>
      {mapReady ? (
        <MapContainer center={[22.295, 114.175]} zoom={12} className="h-full w-full" zoomControl={false}
          style={{ background: '#FAFAF5' }}>
          <LifestyleMapClickClear onClear={clearSelection} />
          <LifestyleMapSizeInvalidator />
          <TileLayer
            url="https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png"
            attribution='&copy; <a href="https://carto.com/">CARTO</a>'
          />
          <FlyToEvent event={selectedEvent} />
          {/* FlyTo for selected venue */}
          <FlyToEvent event={selectedVenue ? { lat: selectedVenue.lat, lng: selectedVenue.lng } : null} />
          {eventsWithCoords.map((event) => (
            <Marker key={event.id}
              position={[event.lat!, event.lng!]}
              icon={createLifestyleMarkerIcon(event.category, selectedEvent?.id === event.id || hoveredId === event.id)}
              eventHandlers={{
                click: () => selectEvent(event),
                mouseover: () => setHoveredId(event.id),
                mouseout: () => setHoveredId(null),
              }}>
              <Popup className="custom-popup">
                <div className="text-sm" style={{ fontFamily: LF.heading, fontWeight: 700 }}>{event.title}</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <span className="text-[11px]" style={{ fontFamily: LF.body, opacity: 0.7 }}>{event.district}</span>
                  {(getStats(event.id)?.views || 0) > 0 && (
                    <span style={{ display: 'flex', alignItems: 'center', gap: '2px', fontSize: '10px', opacity: 0.5 }}>
                      <Eye size={8} /> {getStats(event.id)!.views}
                    </span>
                  )}
                </div>
              </Popup>
            </Marker>
          ))}
          {displayVenues.map((venue) => (
            <Marker key={venue.id}
              position={[venue.lat, venue.lng]}
              icon={createLifestyleVenueMarkerIcon(selectedVenue?.id === venue.id || hoveredId === venue.id)}
              eventHandlers={{
                click: () => selectVenue(venue),
                mouseover: () => setHoveredId(venue.id),
                mouseout: () => setHoveredId(null),
              }}>
              <Popup className="custom-popup">
                <div className="text-sm" style={{ fontFamily: LF.heading, fontWeight: 700 }}>{venue.name}</div>
                <div className="text-[11px]" style={{ fontFamily: LF.body, opacity: 0.7 }}>{venue.district}</div>
              </Popup>
            </Marker>
          ))}
        </MapContainer>
      ) : (
        <div className="h-full w-full flex items-center justify-center" style={{ background: '#FAFAF5' }}>
          <Leaf size={24} className="animate-pulse" style={{ color: LC.sage }} />
        </div>
      )}
    </div>
  );

  // ─── Event row card (split panel) ───
  const renderEventRow = (event: LifestyleEvent) => {
    const isSelected = selectedEvent?.id === event.id;
    const isHovered = hoveredId === event.id;
    return (
      <motion.button key={event.id}
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        onClick={() => selectEvent(event)}
        onMouseEnter={() => setHoveredId(event.id)}
        onMouseLeave={() => setHoveredId(null)}
        className="w-full text-left transition-all cursor-pointer flex gap-3 p-3"
        style={{
          borderRadius: '16px',
          backgroundColor: isSelected ? 'rgba(45,106,79,0.2)' : isHovered ? 'rgba(45,106,79,0.08)' : 'transparent',
          border: isSelected ? `2px solid ${LC.forest}` : `1px solid ${LC.deepForestBorder}`,
        }}>
        <div className="h-16 w-16 flex-shrink-0 overflow-hidden" style={{ borderRadius: '12px' }}>
          <ImageWithFallback src={event.image} alt={event.title} className="h-full w-full object-cover" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5 mb-0.5">
            <span className="text-[9px] uppercase tracking-wider px-1.5 py-0.5" style={{
              color: LC.sage, backgroundColor: 'rgba(149,213,178,0.1)', borderRadius: '4px', fontFamily: LF.mono, fontWeight: 600,
            }}>
              {lifestyleCategories.find(c => c.key === event.category)?.boldLabel}
            </span>
          </div>
          <h3 className="text-sm truncate" style={{ fontFamily: LF.heading, fontWeight: 800, color: LC.white, lineHeight: 1.2 }}>
            {event.title}
          </h3>
          <p className="text-[10px] mt-0.5 truncate" style={{ color: LC.deepForestTextLight, fontFamily: LF.body, fontStyle: 'italic' }}>{event.subtitle}</p>
          <div className="flex items-center gap-2 mt-1.5">
            <span className="flex items-center gap-1 text-[10px]" style={{ color: LC.sage, fontFamily: LF.body }}>
              <Calendar size={9} /> {formatLifestyleDate(event.date)}
            </span>
            <span className="text-[10px]" style={{ color: LC.deepForestTextLight }}>{event.time}</span>
            <span className="text-[10px] ml-auto font-semibold" style={{ color: event.price === 'Free' ? LC.sage : '#E8744F', fontFamily: LF.mono }}>{event.price}</span>
            {(getStats(event.id)?.views || 0) > 0 && (
              <span className="flex items-center gap-0.5 text-[9px] ml-1" style={{ color: LC.deepForestTextLight, opacity: 0.6 }}>
                <Eye size={8} /> {(getStats(event.id)?.views || 0) > 999 ? `${((getStats(event.id)?.views || 0) / 1000).toFixed(1)}k` : getStats(event.id)?.views}
              </span>
            )}
          </div>
        </div>
      </motion.button>
    );
  };

  // ─── Event grid card ───
  const renderEventGridCard = (event: LifestyleEvent) => {
    const isSelected = selectedEvent?.id === event.id;
    const isHovered = hoveredId === event.id;
    return (
      <motion.button
        key={event.id}
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        onClick={() => selectEvent(event)}
        onMouseEnter={() => setHoveredId(event.id)}
        onMouseLeave={() => setHoveredId(null)}
        className="w-full text-left transition-all cursor-pointer group flex flex-col overflow-hidden"
        style={{
          borderRadius: '16px',
          border: isSelected ? `2px solid ${LC.forest}` : `1px solid ${LC.deepForestBorder}`,
          backgroundColor: isSelected ? 'rgba(45,106,79,0.15)' : isHovered ? 'rgba(45,106,79,0.06)' : LC.deepForestCard,
        }}
      >
        <div className="relative overflow-hidden aspect-[16/10]">
          <ImageWithFallback src={event.image} alt={event.title} className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
          <div className="absolute top-3 left-3">
            <span className="text-[9px] uppercase tracking-wider px-2 py-1 backdrop-blur-xl" style={{
              color: LC.white, backgroundColor: 'rgba(45,106,79,0.7)', borderRadius: '8px', fontFamily: LF.mono, fontWeight: 600,
            }}>
              {lifestyleCategories.find(c => c.key === event.category)?.boldLabel}
            </span>
          </div>
          <div className="absolute top-3 right-3">
            <span className="text-[10px] font-semibold px-2 py-1 backdrop-blur-sm" style={{
              color: '#fff',
              backgroundColor: event.price === 'Free' ? 'rgba(45,106,79,0.8)' : 'rgba(232,116,79,0.8)',
              borderRadius: '9999px', fontFamily: LF.mono,
            }}>
              {event.price}
            </span>
          </div>
          <div className="absolute bottom-3 left-3 flex items-center gap-1.5">
            <MapPin size={10} style={{ color: 'rgba(255,255,255,0.7)' }} />
            <span className="text-[11px] text-white/80" style={{ fontFamily: LF.body }}>{event.district}</span>
          </div>
        </div>
        <div className="p-3 sm:p-4 flex-1 flex flex-col">
          <h3 className="mb-1 line-clamp-1 group-hover:opacity-80 transition-opacity" style={{
            fontFamily: LF.heading, fontSize: '0.95rem', color: LC.white, fontWeight: 800, letterSpacing: '-0.01em',
          }}>
            {event.title}
          </h3>
          <p className="text-xs mb-2 line-clamp-1" style={{ color: LC.deepForestTextLight, fontFamily: LF.body, fontStyle: 'italic' }}>{event.subtitle}</p>
          <p className="text-xs line-clamp-2 hidden sm:block mb-3" style={{ color: 'rgba(149,213,178,0.6)', fontFamily: LF.body, lineHeight: 1.6 }}>{event.description}</p>
          <div className="flex flex-wrap gap-1.5 mb-3">
            {event.tags.slice(0, 3).map((tag) => (
              <span key={tag} className="px-2 py-0.5 text-[10px]" style={{
                backgroundColor: 'rgba(45,106,79,0.15)', color: LC.sage, borderRadius: '9999px', fontFamily: LF.body,
              }}>
                #{tag}
              </span>
            ))}
          </div>
          <div className="flex items-center justify-between mt-auto pt-3" style={{ borderTop: `1px solid ${LC.deepForestBorder}` }}>
            <div className="flex items-center gap-3">
              <span className="flex items-center gap-1 text-[11px]" style={{ color: LC.deepForestTextLight }}>
                <Calendar size={11} /> {formatLifestyleDate(event.date)}
              </span>
              <span className="text-[11px]" style={{ color: LC.deepForestTextLight }}>{event.time}</span>
              {(getStats(event.id)?.views || 0) > 0 && (
                <span className="flex items-center gap-0.5 text-[9px]" style={{ color: LC.deepForestTextLight, opacity: 0.6 }}>
                  <Eye size={8} /> {(getStats(event.id)?.views || 0) > 999 ? `${((getStats(event.id)?.views || 0) / 1000).toFixed(1)}k` : getStats(event.id)?.views}
                </span>
              )}
            </div>
            <span className="flex items-center gap-1 text-[11px]" style={{ color: LC.sage, fontWeight: 600 }}>
              Details <ArrowRight size={10} />
            </span>
          </div>
        </div>
      </motion.button>
    );
  };

  // ─── Shared event detail content (used in both panel & overlay) ───
  const renderEventDetailContent = () => {
    if (!selectedEvent) return null;
    return (
      <>
        <button onClick={() => setSelectedEvent(null)}
          className="absolute top-4 right-4 z-10 p-2 cursor-pointer transition-all hover:opacity-70"
          style={{ borderRadius: '50%', backgroundColor: 'rgba(45,106,79,0.1)', color: LC.forest }}>
          <X size={16} />
        </button>

        <div className="relative h-52 overflow-hidden">
          <ImageWithFallback src={selectedEvent.image} alt={selectedEvent.title} className="h-full w-full object-cover" />
          <div className="absolute inset-0" style={{ background: `linear-gradient(to top, ${LC.offWhite}, transparent 60%)` }} />
          <div className="absolute top-4 left-4 flex gap-2">
            <span className="text-[10px] uppercase tracking-wider px-2.5 py-1 backdrop-blur-xl" style={{ color: LC.white, backgroundColor: 'rgba(45,106,79,0.7)', borderRadius: '8px', fontFamily: LF.mono, fontWeight: 600 }}>
              {lifestyleCategories.find(c => c.key === selectedEvent.category)?.boldLabel}
            </span>
            {selectedEvent.difficulty && (
              <span className="text-[10px] uppercase tracking-wider px-2.5 py-1 backdrop-blur-xl" style={{ color: LC.white, backgroundColor: 'rgba(0,0,0,0.4)', borderRadius: '8px', fontFamily: LF.mono }}>
                {selectedEvent.difficulty}
              </span>
            )}
          </div>
        </div>

        <div className="px-5 pb-6 -mt-6 relative">
          <h2 style={{ fontFamily: LF.heading, fontSize: '1.5rem', fontWeight: 900, color: LC.black, letterSpacing: '-0.02em', lineHeight: 1.1, marginBottom: '4px' }}>
            {selectedEvent.title}
          </h2>
          <p className="text-sm mb-4" style={{ color: LC.textMuted, fontFamily: LF.body, fontStyle: 'italic' }}>{selectedEvent.subtitle}</p>
          <p className="text-sm mb-5" style={{ color: '#5A5A5A', fontFamily: LF.body, lineHeight: 1.7 }}>{selectedEvent.description}</p>

          <div className="grid grid-cols-2 gap-2.5 mb-5">
            {[
              { icon: Calendar, label: 'Date', value: formatLifestyleDate(selectedEvent.date) },
              { icon: Clock, label: 'Time', value: selectedEvent.time },
              { icon: MapPin, label: 'Location', value: selectedEvent.location },
              { icon: Users, label: 'Capacity', value: `${selectedEvent.spotsLeft}/${selectedEvent.capacity}` },
            ].map((item) => (
              <div key={item.label} className="p-2.5" style={{ borderRadius: '12px', backgroundColor: 'rgba(45,106,79,0.06)' }}>
                <div className="flex items-center gap-1.5 mb-0.5">
                  <item.icon size={11} style={{ color: LC.forest }} />
                  <span className="text-[9px] uppercase tracking-wider" style={{ color: LC.textMuted, fontFamily: LF.mono }}>{item.label}</span>
                </div>
                <span className="text-xs" style={{ color: LC.black, fontFamily: LF.body, fontWeight: 500 }}>{item.value}</span>
              </div>
            ))}
          </div>

          <div className="flex items-center gap-3 mb-5 p-3" style={{ borderRadius: '12px', backgroundColor: 'rgba(45,106,79,0.06)' }}>
            <div className="h-9 w-9 flex items-center justify-center" style={{ borderRadius: '10px', backgroundColor: 'rgba(45,106,79,0.1)' }}>
              <Heart size={14} style={{ color: LC.forestLight }} />
            </div>
            <div className="flex-1">
              <span className="text-sm block" style={{ color: LC.black, fontFamily: LF.body, fontWeight: 600 }}>{selectedEvent.organizer}</span>
              <span className="text-[10px]" style={{ color: LC.textMuted, fontFamily: LF.body }}>Organizer</span>
            </div>
          </div>

          <div className="flex flex-wrap gap-1.5 mb-5">
            {selectedEvent.tags.map((tag) => (
              <span key={tag} className="px-2.5 py-0.5 text-[10px]" style={{ color: LC.textMuted, backgroundColor: 'rgba(0,0,0,0.04)', borderRadius: '9999px', fontFamily: LF.body }}>
                #{tag}
              </span>
            ))}
          </div>

          <a
            href={selectedEvent.ticketUrl || selectedEvent.sourceUrl || '#'}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full flex items-center justify-center gap-2 py-3 text-sm transition-all hover:opacity-90 cursor-pointer no-underline"
            style={{ backgroundColor: LC.forest, color: LC.white, borderRadius: '14px', fontFamily: LF.body, fontWeight: 700 }}>
            Join Event &mdash; {selectedEvent.price}
            <ExternalLink size={14} />
          </a>
        </div>
      </>
    );
  };

  // ─── Selected event detail panel (map/split view) ───
  const renderEventDetail = () => (
    <AnimatePresence>
      {selectedEvent && (
        <motion.div
          initial={{ x: '100%', opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: '100%', opacity: 0 }}
          transition={{ type: 'spring', stiffness: 300, damping: 30 }}
          className="absolute top-0 right-0 bottom-0 w-full sm:w-[380px] z-[1000] backdrop-blur-xl border-l overflow-y-auto"
          style={{ background: 'rgba(250,250,245,0.97)', borderColor: LC.deepForestBorder }}>
          {renderEventDetailContent()}
        </motion.div>
      )}
    </AnimatePresence>
  );

  // ─── Venue detail content ───
  const renderVenueDetailContent = () => {
    if (!selectedVenue) return null;
    const score = Math.round((selectedVenue.modeScores?.lifestyle || 0) * 100);
    return (
      <>
        <button onClick={() => setSelectedVenue(null)}
          className="absolute top-4 right-4 z-10 p-2 cursor-pointer transition-all hover:opacity-70"
          style={{ borderRadius: '50%', backgroundColor: 'rgba(45,106,79,0.1)', color: LC.forest }}>
          <X size={16} />
        </button>

        <div className="relative h-52 overflow-hidden">
          {selectedVenue.image ? (
            <ImageWithFallback src={selectedVenue.image} alt={selectedVenue.name} className="h-full w-full object-cover" />
          ) : (
            <div className="h-full w-full flex items-center justify-center" style={{ backgroundColor: 'rgba(45,106,79,0.1)' }}>
              <Building2 size={48} style={{ color: 'rgba(45,106,79,0.3)' }} />
            </div>
          )}
          <div className="absolute inset-0" style={{ background: `linear-gradient(to top, ${LC.offWhite}, transparent 60%)` }} />
          <div className="absolute top-4 left-4 flex gap-2">
            <span className="text-[10px] uppercase tracking-wider px-2.5 py-1 backdrop-blur-xl" style={{ color: LC.white, backgroundColor: 'rgba(45,106,79,0.7)', borderRadius: '8px', fontFamily: LF.mono, fontWeight: 600 }}>
              Venue
            </span>
            <span className="text-[10px] uppercase tracking-wider px-2.5 py-1 backdrop-blur-xl" style={{ color: LC.white, backgroundColor: 'rgba(45,106,79,0.5)', borderRadius: '8px', fontFamily: LF.mono }}>
              {score}% match
            </span>
          </div>
        </div>

        <div className="px-5 pb-6 -mt-6 relative">
          <h2 style={{ fontFamily: LF.heading, fontSize: '1.5rem', fontWeight: 900, color: LC.black, letterSpacing: '-0.02em', lineHeight: 1.1, marginBottom: '4px' }}>
            {selectedVenue.name}
          </h2>
          {selectedVenue.nameZh && (
            <p className="text-sm mb-1" style={{ color: LC.textMuted, fontFamily: LF.body }}>{selectedVenue.nameZh}</p>
          )}
          <p className="text-xs mb-4" style={{ color: LC.textMuted, fontFamily: LF.body, fontStyle: 'italic' }}>
            {selectedVenue.category}{selectedVenue.subcategory ? ` · ${selectedVenue.subcategory}` : ''} · {selectedVenue.district}
          </p>
          {selectedVenue.description && (
            <p className="text-sm mb-5" style={{ color: '#5A5A5A', fontFamily: LF.body, lineHeight: 1.7 }}>{selectedVenue.description}</p>
          )}

          <div className="grid grid-cols-2 gap-2.5 mb-5">
            {[
              { icon: MapPin, label: 'District', value: selectedVenue.district || '—' },
              { icon: Building2, label: 'Category', value: selectedVenue.category || '—' },
              ...(selectedVenue.address ? [{ icon: Globe, label: 'Address', value: selectedVenue.address }] : []),
              ...(typeof (selectedVenue as any).googleRating === 'number' ? [{ icon: Star, label: 'Rating', value: `${(selectedVenue as any).googleRating}/5` }] : []),
            ].map((item) => (
              <div key={item.label} className="p-2.5" style={{ borderRadius: '12px', backgroundColor: 'rgba(45,106,79,0.06)' }}>
                <div className="flex items-center gap-1.5 mb-0.5">
                  <item.icon size={11} style={{ color: LC.forest }} />
                  <span className="text-[9px] uppercase tracking-wider" style={{ color: LC.textMuted, fontFamily: LF.mono }}>{item.label}</span>
                </div>
                <span className="text-xs" style={{ color: LC.black, fontFamily: LF.body, fontWeight: 500 }}>{item.value}</span>
              </div>
            ))}
          </div>

          {/* Mode scores */}
          <div className="mb-5 p-3" style={{ borderRadius: '12px', backgroundColor: 'rgba(45,106,79,0.06)' }}>
            <span className="text-[9px] uppercase tracking-wider block mb-2" style={{ color: LC.textMuted, fontFamily: LF.mono }}>Mode Fit</span>
            {Object.entries(selectedVenue.modeScores || {}).filter(([, s]) => (s as number) > 0).sort((a, b) => (b[1] as number) - (a[1] as number)).map(([mode, s]) => {
              const modeLabels: Record<string, string> = { degen: 'Night', artsy: 'Art', foodie: 'Food', family: 'Family', lifestyle: 'Lifestyle' };
              const modeColors: Record<string, string> = { degen: '#D600FF', artsy: '#8338EC', foodie: '#2563EB', family: '#FF8C42', lifestyle: '#2D6A4F' };
              return (
                <div key={mode} className="flex items-center gap-2 mb-1.5">
                  <span className="text-[10px] w-14" style={{ color: modeColors[mode] || LC.forest, fontFamily: LF.body, fontWeight: 600 }}>{modeLabels[mode] || mode}</span>
                  <div className="flex-1 h-1.5 rounded-full overflow-hidden" style={{ backgroundColor: 'rgba(0,0,0,0.06)' }}>
                    <div className="h-full rounded-full" style={{ width: `${(s as number) * 100}%`, backgroundColor: modeColors[mode] || LC.forest }} />
                  </div>
                  <span className="text-[10px] tabular-nums" style={{ color: LC.black, fontFamily: LF.mono }}>{Math.round((s as number) * 100)}%</span>
                </div>
              );
            })}
          </div>

          {/* Vibe tags */}
          {selectedVenue.vibeTags && selectedVenue.vibeTags.length > 0 && (
            <div className="flex flex-wrap gap-1.5 mb-5">
              {selectedVenue.vibeTags.map((tag) => (
                <span key={tag} className="px-2.5 py-0.5 text-[10px]" style={{ color: LC.textMuted, backgroundColor: 'rgba(0,0,0,0.04)', borderRadius: '9999px', fontFamily: LF.body }}>
                  #{tag}
                </span>
              ))}
            </div>
          )}

          {/* Price range */}
          <div className="flex items-center gap-2 mb-5">
            <span className="text-[10px]" style={{ color: LC.textMuted, fontFamily: LF.mono }}>PRICE:</span>
            <span className="text-sm" style={{ color: LC.forest, fontWeight: 700 }}>{'$'.repeat(selectedVenue.priceRange || 1)}</span>
            <span className="text-sm" style={{ color: 'rgba(0,0,0,0.1)' }}>{'$'.repeat(Math.max(0, 4 - (selectedVenue.priceRange || 1)))}</span>
          </div>

          {/* Google links */}
          {(selectedVenue as any).googleMapsUrl && (
            <a href={(selectedVenue as any).googleMapsUrl} target="_blank" rel="noopener noreferrer"
              className="w-full flex items-center justify-center gap-2 py-3 text-sm transition-all hover:opacity-90 cursor-pointer"
              style={{ backgroundColor: LC.forest, color: LC.white, borderRadius: '14px', fontFamily: LF.body, fontWeight: 700 }}>
              <MapPin size={14} /> View on Google Maps
            </a>
          )}
        </div>
      </>
    );
  };

  // ─── Venue detail slide-in panel (map/split view) ───
  const renderVenueDetail = () => (
    <AnimatePresence>
      {selectedVenue && (
        <motion.div
          initial={{ x: '100%', opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: '100%', opacity: 0 }}
          transition={{ type: 'spring', stiffness: 300, damping: 30 }}
          className="absolute top-0 right-0 bottom-0 w-full sm:w-[380px] z-[1000] backdrop-blur-xl border-l overflow-y-auto"
          style={{ background: 'rgba(250,250,245,0.97)', borderColor: LC.deepForestBorder }}>
          {renderVenueDetailContent()}
        </motion.div>
      )}
    </AnimatePresence>
  );

  // ─── Venue row card (split panel) ───
  const renderVenueRow = (venue: Venue) => {
    const isSelected = selectedVenue?.id === venue.id;
    const isHovered = hoveredId === venue.id;
    const score = Math.round((venue.modeScores?.lifestyle || 0) * 100);
    return (
      <motion.button key={venue.id}
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        onClick={() => selectVenue(venue)}
        onMouseEnter={() => setHoveredId(venue.id)}
        onMouseLeave={() => setHoveredId(null)}
        className="w-full text-left transition-all cursor-pointer flex gap-3 p-3"
        style={{
          borderRadius: '16px',
          backgroundColor: isSelected ? 'rgba(45,106,79,0.2)' : isHovered ? 'rgba(45,106,79,0.08)' : 'transparent',
          border: isSelected ? `2px solid ${LC.forest}` : `1px solid ${LC.deepForestBorder}`,
        }}>
        <div className="h-16 w-16 flex-shrink-0 overflow-hidden flex items-center justify-center" style={{ borderRadius: '12px', backgroundColor: 'rgba(45,106,79,0.15)' }}>
          {venue.image ? (
            <ImageWithFallback src={venue.image} alt={venue.name} className="h-full w-full object-cover" />
          ) : (
            <Building2 size={20} style={{ color: LC.sage }} />
          )}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5 mb-0.5">
            <span className="text-[9px] uppercase tracking-wider px-1.5 py-0.5" style={{
              color: LC.sage, backgroundColor: 'rgba(149,213,178,0.1)', borderRadius: '4px', fontFamily: LF.mono, fontWeight: 600,
            }}>
              {venue.category || 'Venue'}
            </span>
            <span className="text-[9px] font-semibold tabular-nums" style={{ color: LC.sage, fontFamily: LF.mono }}>
              {score}%
            </span>
          </div>
          <h3 className="text-sm truncate" style={{ fontFamily: LF.heading, fontWeight: 800, color: LC.white, lineHeight: 1.2 }}>
            {venue.name}
          </h3>
          {venue.nameZh && <p className="text-[10px] mt-0.5 truncate" style={{ color: LC.deepForestTextLight, fontFamily: LF.body }}>{venue.nameZh}</p>}
          <div className="flex items-center gap-2 mt-1.5">
            <span className="flex items-center gap-1 text-[10px]" style={{ color: LC.sage, fontFamily: LF.body }}>
              <MapPin size={9} /> {venue.district || '—'}
            </span>
            <span className="text-[10px] ml-auto" style={{ color: LC.sage, fontFamily: LF.mono, fontWeight: 600 }}>
              {'$'.repeat(venue.priceRange || 1)}
            </span>
          </div>
        </div>
      </motion.button>
    );
  };

  // ─── Venue grid card ───
  const renderVenueGridCard = (venue: Venue) => {
    const isSelected = selectedVenue?.id === venue.id;
    const isHovered = hoveredId === venue.id;
    const score = Math.round((venue.modeScores?.lifestyle || 0) * 100);
    return (
      <motion.button
        key={venue.id}
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        onClick={() => selectVenue(venue)}
        onMouseEnter={() => setHoveredId(venue.id)}
        onMouseLeave={() => setHoveredId(null)}
        className="w-full text-left transition-all cursor-pointer group flex flex-col overflow-hidden"
        style={{
          borderRadius: '16px',
          border: isSelected ? `2px solid ${LC.forest}` : `1px solid ${LC.deepForestBorder}`,
          backgroundColor: isSelected ? 'rgba(45,106,79,0.15)' : isHovered ? 'rgba(45,106,79,0.06)' : LC.deepForestCard,
        }}
      >
        <div className="relative overflow-hidden aspect-[16/10]">
          {venue.image ? (
            <ImageWithFallback src={venue.image} alt={venue.name} className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
          ) : (
            <div className="h-full w-full flex items-center justify-center" style={{ backgroundColor: 'rgba(45,106,79,0.15)' }}>
              <Building2 size={32} style={{ color: 'rgba(149,213,178,0.4)' }} />
            </div>
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
          <div className="absolute top-3 left-3">
            <span className="text-[9px] uppercase tracking-wider px-2 py-1 backdrop-blur-xl" style={{
              color: LC.white, backgroundColor: 'rgba(45,106,79,0.7)', borderRadius: '8px', fontFamily: LF.mono, fontWeight: 600,
            }}>
              {venue.category || 'Venue'}
            </span>
          </div>
          <div className="absolute top-3 right-3">
            <span className="text-[10px] font-semibold px-2 py-1 backdrop-blur-sm" style={{
              color: '#fff',
              backgroundColor: 'rgba(45,106,79,0.8)',
              borderRadius: '9999px', fontFamily: LF.mono,
            }}>
              {score}% match
            </span>
          </div>
          <div className="absolute bottom-3 left-3 flex items-center gap-1.5">
            <MapPin size={10} style={{ color: 'rgba(255,255,255,0.7)' }} />
            <span className="text-[11px] text-white/80" style={{ fontFamily: LF.body }}>{venue.district || '—'}</span>
          </div>
        </div>
        <div className="p-3 sm:p-4 flex-1 flex flex-col">
          <h3 className="mb-1 line-clamp-1 group-hover:opacity-80 transition-opacity" style={{
            fontFamily: LF.heading, fontSize: '0.95rem', color: LC.white, fontWeight: 800, letterSpacing: '-0.01em',
          }}>
            {venue.name}
          </h3>
          {venue.nameZh && <p className="text-xs mb-1" style={{ color: LC.deepForestTextLight, fontFamily: LF.body }}>{venue.nameZh}</p>}
          {venue.description && (
            <p className="text-xs line-clamp-2 mb-3" style={{ color: 'rgba(149,213,178,0.6)', fontFamily: LF.body, lineHeight: 1.6 }}>{venue.description}</p>
          )}
          {venue.vibeTags && venue.vibeTags.length > 0 && (
            <div className="flex flex-wrap gap-1.5 mb-3">
              {venue.vibeTags.slice(0, 3).map((tag) => (
                <span key={tag} className="px-2 py-0.5 text-[10px]" style={{
                  backgroundColor: 'rgba(45,106,79,0.15)', color: LC.sage, borderRadius: '9999px', fontFamily: LF.body,
                }}>
                  #{tag}
                </span>
              ))}
            </div>
          )}
          <div className="flex items-center justify-between mt-auto pt-3" style={{ borderTop: `1px solid ${LC.deepForestBorder}` }}>
            <span className="text-[11px]" style={{ color: LC.sage, fontFamily: LF.mono, fontWeight: 600 }}>
              {'$'.repeat(venue.priceRange || 1)}
            </span>
            <span className="flex items-center gap-1 text-[11px]" style={{ color: LC.sage, fontWeight: 600 }}>
              Details <ArrowRight size={10} />
            </span>
          </div>
        </div>
      </motion.button>
    );
  };

  // ─── Events/Venues tab toggle ───
  const renderTabToggle = (variant: 'panel' | 'floating' = 'panel') => (
    <div className="flex overflow-hidden" style={{
      background: variant === 'floating' ? 'rgba(18,42,32,0.85)' : 'rgba(45,106,79,0.1)',
      border: `1px solid ${LC.deepForestBorder}`,
      borderRadius: '10px',
    }}>
      {([
        { key: 'events' as const, icon: Calendar, label: 'Events', count: displayEvents.length },
        { key: 'venues' as const, icon: Building2, label: 'Venues', count: displayVenues.length },
      ]).map((tab) => (
        <button
          key={tab.key}
          onClick={() => setListTab(tab.key)}
          className="flex items-center gap-1.5 px-3 py-1.5 text-[10px] transition-all cursor-pointer"
          style={{
            background: listTab === tab.key ? 'rgba(45,106,79,0.4)' : 'transparent',
            color: listTab === tab.key ? LC.sage : 'rgba(149,213,178,0.4)',
            fontFamily: LF.body,
            fontWeight: listTab === tab.key ? 600 : 400,
          }}
        >
          <tab.icon size={11} />
          {tab.label}
          <span className="text-[9px] px-1 py-0.5 rounded-full tabular-nums" style={{
            backgroundColor: listTab === tab.key ? 'rgba(149,213,178,0.2)' : 'transparent',
            color: listTab === tab.key ? LC.sage : 'rgba(149,213,178,0.3)',
          }}>
            {tab.count}
          </span>
        </button>
      ))}
    </div>
  );

  // ─── Detail overlay for list/grid view (events + venues) ───
  const renderDetailOverlay = () => (
    <AnimatePresence>
      {(selectedEvent || selectedVenue) && (
        <div className="fixed inset-0 z-[1050]">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/30 backdrop-blur-sm"
            onClick={() => { setSelectedEvent(null); setSelectedVenue(null); }}
          />
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            className="absolute top-0 right-0 bottom-0 w-full sm:w-[420px] backdrop-blur-xl border-l overflow-y-auto"
            style={{ background: 'rgba(250,250,245,0.97)', borderColor: LC.deepForestBorder }}
          >
            {selectedEvent ? renderEventDetailContent() : renderVenueDetailContent()}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );

  // ══════════════════════════════════════════════
  // LIST / GRID VIEW
  // ══════════════════════════════════════════════
  if (viewMode === 'list') {
    return (
      <div className="h-[calc(100vh-64px)] overflow-y-auto" data-nav-theme="light" style={{ backgroundColor: LC.deepForest }}>
        {/* Top bar */}
        <div className="sticky top-0 z-[1000] px-4 sm:px-6 pt-4 pb-3" style={{ backgroundColor: LC.deepForest }}>
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 sm:justify-between mb-3">
            <div className="max-w-[calc(100vw-32px)] sm:max-w-none">
              <div className="backdrop-blur-xl p-2" style={{ background: 'rgba(250,250,245,0.92)', border: `1px solid rgba(45,106,79,0.15)`, borderRadius: '16px' }}>
                <ModeSelector compact />
              </div>
            </div>
            <div className="flex gap-2">
              {renderTabToggle('floating')}
              {renderSavedButton('floating')}
              {renderViewToggle()}
            </div>
          </div>
          {listTab === 'events' && renderCategoryPills()}
          <p className="text-[11px] mt-2" style={{ color: LC.deepForestTextLight, fontFamily: LF.body }}>
            {listTab === 'events'
              ? `${displayEvents.length} event${displayEvents.length !== 1 ? 's' : ''}`
              : `${displayVenues.length} venue${displayVenues.length !== 1 ? 's' : ''}`}
          </p>
        </div>

        {/* Grid */}
        <div className="px-4 sm:px-6 pb-8">
          {listTab === 'events' ? (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {displayEvents.map((event) => (
                  <div key={event.id}>{renderEventGridCard(event)}</div>
                ))}
              </div>
              {displayEvents.length === 0 && (
                <div className="text-center py-20">
                  <Leaf size={32} style={{ color: LC.sage, margin: '0 auto 12px' }} />
                  <p style={{ color: LC.deepForestTextLight, fontFamily: LF.heading, fontSize: '0.9rem' }}>
                    No events match the current filter.
                  </p>
                </div>
              )}
            </>
          ) : (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {displayVenues.map((venue) => (
                  <div key={venue.id}>{renderVenueGridCard(venue)}</div>
                ))}
              </div>
              {displayVenues.length === 0 && (
                <div className="text-center py-20">
                  <Building2 size={32} style={{ color: LC.sage, margin: '0 auto 12px' }} />
                  <p style={{ color: LC.deepForestTextLight, fontFamily: LF.heading, fontSize: '0.9rem' }}>
                    No lifestyle venues found.
                  </p>
                </div>
              )}
            </>
          )}
        </div>

        {renderDetailOverlay()}
        <style>{lifestyleMapStyles}</style>
      </div>
    );
  }

  // ══════════════════════════════════════════════
  // MAP-ONLY VIEW
  // ══════════════════════════════════════════════
  if (viewMode === 'map') {
    return (
      <div className="relative h-[calc(100vh-64px)] overflow-hidden" data-nav-theme="dark">
        <div className="h-full w-full">
          {renderLifestyleMap('h-full w-full')}
        </div>

        {/* All floating controls in one stacked container — prevents overlap on mobile */}
        <div className="absolute top-3 left-3 right-3 z-[1001] flex flex-col gap-1.5 pointer-events-none">
          {/* Row 1: Mode selector + view toggle */}
          <div className="flex items-center gap-2 pointer-events-auto">
            <div className="backdrop-blur-xl p-1.5 overflow-x-auto scrollbar-hide flex-1 min-w-0" style={{ background: 'rgba(250,250,245,0.92)', border: `1px solid rgba(45,106,79,0.15)`, borderRadius: '16px' }}>
              <ModeSelector compact />
            </div>
            <div className="flex-shrink-0">
              {renderViewToggle()}
            </div>
          </div>
          {/* Row 2: Category pills — flows below mode selector naturally */}
          <div className="pointer-events-auto flex items-center gap-2">
            <div className="backdrop-blur-xl p-1.5 overflow-x-auto scrollbar-hide inline-flex" style={{ background: 'rgba(18,42,32,0.85)', borderRadius: '12px', border: `1px solid ${LC.deepForestBorder}` }}>
              {renderCategoryPills('floating')}
            </div>
            {renderSavedButton('floating')}
          </div>
        </div>

        {/* Map count badge */}
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-[1000]">
          <div className="backdrop-blur-xl px-4 py-2 flex items-center gap-3" style={{ background: 'rgba(18,42,32,0.9)', borderRadius: '9999px', border: `1px solid ${LC.deepForestBorder}` }}>
            <span className="flex items-center gap-1.5 text-[11px]" style={{ color: LC.sage, fontFamily: LF.body, fontWeight: 500 }}>
              <Leaf size={12} /> {eventsWithCoords.length} event{eventsWithCoords.length !== 1 ? 's' : ''}
            </span>
            {lifestyleVenues.length > 0 && (
              <>
                <span style={{ color: LC.deepForestBorder }}>·</span>
                <span className="flex items-center gap-1.5 text-[11px]" style={{ color: LC.sage, fontFamily: LF.body, fontWeight: 500 }}>
                  <Building2 size={12} /> {lifestyleVenues.length} venue{lifestyleVenues.length !== 1 ? 's' : ''}
                </span>
              </>
            )}
          </div>
        </div>

        {renderEventDetail()}
        {renderVenueDetail()}
        <style>{lifestyleMapStyles}</style>
      </div>
    );
  }

  // ══════════════════════════════════════════════
  // SPLIT VIEW (default)
  // ══════════════════════════════════════════════
  return (
    <div className="relative h-[calc(100vh-64px)] overflow-hidden flex flex-col sm:flex-row" data-nav-theme="dark">
      {/* Left: list panel */}
      <div className="w-full sm:w-[380px] lg:w-[420px] flex-shrink-0 h-1/2 sm:h-full overflow-y-auto order-2 sm:order-1 border-r relative"
        style={{ backgroundColor: LC.deepForest, borderColor: LC.deepForestBorder }}>

        {/* Panel header */}
        <div className="sticky top-0 z-10 px-4 pt-4 pb-3 relative" style={{ backgroundColor: LC.deepForest }}>
          <div className="flex items-center justify-between mb-3">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Leaf size={14} style={{ color: LC.sage }} />
                <span className="text-[10px] uppercase tracking-[0.2em]" style={{ color: LC.sage, fontFamily: LF.mono, fontWeight: 500 }}>
                  Lifestyle Map
                </span>
              </div>
              <h2 style={{ fontFamily: LF.heading, fontWeight: 900, fontSize: '1.1rem', color: LC.white, letterSpacing: '-0.02em' }}>
                Discover<span style={{ color: LC.sage, fontWeight: 400, fontStyle: 'italic' }}> nearby</span>.
              </h2>
            </div>
            <div className="flex items-center gap-2">
              {renderViewToggle()}
            </div>
          </div>

          {/* Tab toggle + category pills */}
          <div className="flex items-center gap-2 mb-2">
            {renderTabToggle()}
            {renderSavedButton()}
          </div>
          {listTab === 'events' && renderCategoryPills()}

          <p className="text-[11px] mt-2" style={{ color: LC.deepForestTextLight, fontFamily: LF.body }}>
            {listTab === 'events'
              ? `${displayEvents.length} event${displayEvents.length !== 1 ? 's' : ''}`
              : `${displayVenues.length} venue${displayVenues.length !== 1 ? 's' : ''}`}
          </p>
        </div>

        {/* Content list */}
        <div className="px-3 pb-4 space-y-2 relative">
          {listTab === 'events'
            ? displayEvents.map((event) => renderEventRow(event))
            : displayVenues.map((venue) => renderVenueRow(venue))
          }
          {listTab === 'events' && displayEvents.length === 0 && (
            <div className="text-center py-10">
              <Leaf size={24} style={{ color: LC.sage, margin: '0 auto 8px' }} />
              <p className="text-xs" style={{ color: LC.deepForestTextLight }}>No events match filter</p>
            </div>
          )}
          {listTab === 'venues' && displayVenues.length === 0 && (
            <div className="text-center py-10">
              <Building2 size={24} style={{ color: LC.sage, margin: '0 auto 8px' }} />
              <p className="text-xs" style={{ color: LC.deepForestTextLight }}>No lifestyle venues found</p>
            </div>
          )}
        </div>
      </div>

      {/* Right: Map */}
      <div className="flex-1 relative order-1 sm:order-2 h-1/2 sm:h-full">
        {renderLifestyleMap()}

        {/* Floating controls on map — ModeSelector (desktop) */}
        <div className="absolute top-4 left-3 right-3 z-[1000] flex items-start justify-between gap-2 pointer-events-none">
          <div className="pointer-events-auto hidden sm:block">
            <div
              className="backdrop-blur-xl p-2"
              style={{ background: 'rgba(250,250,245,0.92)', border: `1px solid rgba(45,106,79,0.15)`, borderRadius: '16px' }}
            >
              <ModeSelector compact />
            </div>
          </div>
        </div>

        {renderEventDetail()}
        {renderVenueDetail()}
      </div>

      {/* Mobile: floating mode selector */}
      <div className="absolute top-2 left-2 right-2 z-[1001] sm:hidden pointer-events-none">
        <div className="pointer-events-auto" style={{ borderRadius: '16px', padding: '6px', backgroundColor: 'rgba(250,250,245,0.92)', border: `1px solid ${LC.deepForestBorder}`, backdropFilter: 'blur(12px)' }}>
          <ModeSelector compact />
        </div>
      </div>

      <style>{lifestyleMapStyles}</style>
    </div>
  );
}