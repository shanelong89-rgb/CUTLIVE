/**
 * VenueCard — mode-aware venue card used in MapPage list/split views
 */
import { MapPin, ArrowRight, Heart } from 'lucide-react';
import { useNavigate } from 'react-router';
import { useTranslation } from 'react-i18next';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { CIcon } from '../CIcon';
import type { Mode, Venue } from '../../data/mock-data';
import { getBilingualField } from '../../utils/bilingual';

export interface VenueCardTokens {
  modeColor: string;
  currentMode: Mode | null;
  isDegen: boolean;
  isArtsy: boolean;
  headingFont: string;
  bodyFont: string;
  overlayRadius: string;
  cardBorder: string;
  cardText: string;
  cardTextMuted: string;
  cardTextSub: string;
  imgRadius: string;
}

export function VenueCard({
  venue,
  variant,
  isSelected,
  isHovered,
  isSaved,
  onSelect,
  onHover,
  onLeave,
  tokens,
}: {
  venue: Venue;
  variant: 'split' | 'list';
  isSelected: boolean;
  isHovered: boolean;
  isSaved?: boolean;
  onSelect: () => void;
  onHover: () => void;
  onLeave: () => void;
  tokens: VenueCardTokens;
}) {
  const { modeColor, currentMode, isDegen, isArtsy, headingFont, bodyFont, overlayRadius, cardBorder, cardText, cardTextMuted, cardTextSub, imgRadius } = tokens;
  const isListVariant = variant === 'list';
  const navigate = useNavigate();
  const { i18n } = useTranslation();
  const lang = i18n.language;
  const isZh = lang === 'zh-Hant' || lang.startsWith('zh');
  const venueName = getBilingualField(venue, 'name', lang);
  const venueDistrict = getBilingualField(venue, 'district', lang);
  const venueDescription = getBilingualField(venue, 'description', lang);
  // Secondary name: show the "other" language name
  const secondaryName = isZh ? venue.name : venue.nameZh;

  const descriptionClampStyle: React.CSSProperties = {
    display: '-webkit-box',
    WebkitLineClamp: 3,
    WebkitBoxOrient: 'vertical' as const,
    overflow: 'hidden',
  };

  const splitDescClampStyle: React.CSSProperties = {
    display: '-webkit-box',
    WebkitLineClamp: 2,
    WebkitBoxOrient: 'vertical' as const,
    overflow: 'hidden',
  };

  return (
    <div
      className="group"
      onMouseEnter={onHover}
      onMouseLeave={onLeave}
    >
      <button
        onClick={onSelect}
        className="w-full text-left transition-all cursor-pointer"
        style={{
          borderRadius: isListVariant ? overlayRadius : isDegen ? '4px' : isArtsy ? '2px' : '12px',
          background: isSelected
            ? (isDegen ? 'rgba(237,255,0,0.08)' : `${modeColor}08`)
            : isHovered
              ? (isDegen ? 'rgba(237,255,0,0.04)' : 'rgba(0,0,0,0.02)')
              : 'transparent',
          border: isSelected
            ? `2px solid ${isDegen ? '#EDFF00' : `${modeColor}30`}`
            : `1px solid ${cardBorder}`,
          overflow: 'hidden',
        }}
      >
        {isListVariant ? (
          /* ─── Grid card layout ─── */
          <div className="flex flex-col">
            <div className="relative overflow-hidden aspect-[16/10]">
              <ImageWithFallback
                src={venue.image}
                alt={venue.name}
                className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
              <div className="absolute top-3 left-3">
                <div className="p-1.5 backdrop-blur-sm" style={{ borderRadius: imgRadius, backgroundColor: 'rgba(0,0,0,0.4)' }}>
                  <CIcon id={venue.category} size={16} mode="auto" />
                </div>
              </div>
              <div className="absolute bottom-3 left-3">
                <span className="text-[11px] text-white/80" style={{ fontFamily: bodyFont }}>{venueDistrict}</span>
              </div>
              {isSaved && (
                <div className="absolute bottom-3 right-3">
                  <div className="p-1 backdrop-blur-sm rounded-full" style={{ backgroundColor: 'rgba(0,0,0,0.4)' }}>
                    <Heart size={12} fill={modeColor} style={{ color: modeColor }} />
                  </div>
                </div>
              )}
              {currentMode && currentMode !== 'lifestyle' && (
                <div className="absolute top-3 right-3">
                  <span
                    className="px-2 py-1 text-[10px] backdrop-blur-sm"
                    style={{
                      backgroundColor: isDegen ? 'rgba(237,255,0,0.9)' : `${modeColor}cc`,
                      color: isDegen ? '#0A0A0A' : '#fff',
                      borderRadius: isDegen ? '2px' : isArtsy ? '0' : '9999px',
                      fontFamily: headingFont,
                      fontWeight: 700,
                    }}
                  >
                    {Math.round((venue.modeScores[currentMode] || 0) * 100)}%
                  </span>
                </div>
              )}
            </div>
            <div className="p-3 sm:p-4">
              <h3
                className="mb-1 line-clamp-1 group-hover:opacity-80 transition-opacity"
                style={{
                  fontFamily: headingFont,
                  fontSize: '0.95rem',
                  color: cardText,
                  fontWeight: isDegen ? 700 : isArtsy ? 400 : 600,
                  textTransform: isDegen ? 'uppercase' : 'none',
                }}
              >
                {venueName}
              </h3>
              <p className="text-xs mb-2" style={{ color: cardTextMuted, fontFamily: bodyFont }}>{secondaryName}</p>

              {/* Description — clamped to 3 lines with "Read more" */}
              {venueDescription && (
                <div className="hidden sm:block mb-3">
                  <p
                    className="text-xs"
                    style={{ color: cardTextSub, fontFamily: bodyFont, lineHeight: 1.6, ...descriptionClampStyle }}
                  >
                    {venueDescription}
                  </p>
                  {venueDescription.length > 120 && (
                    <button
                      onClick={(e) => { e.stopPropagation(); navigate(venue.id?.startsWith('ra_') || venue.id?.startsWith('sub_') ? `/event/${venue.id}` : `/venue/${venue.id}`); }}
                      className="text-[10px] mt-0.5 cursor-pointer hover:underline"
                      style={{ color: modeColor, fontFamily: bodyFont }}
                    >
                      Read more →
                    </button>
                  )}
                </div>
              )}

              <div className="flex items-center gap-2 flex-wrap">
                {(venue.vibeTags || []).slice(0, 3).map((tag) => (
                  <span
                    key={tag}
                    className="px-2 py-0.5 text-[10px]"
                    style={{
                      backgroundColor: isDegen ? 'rgba(237,255,0,0.08)' : `${modeColor}10`,
                      color: isDegen ? '#EDFF00' : `${modeColor}aa`,
                      borderRadius: isDegen ? '2px' : isArtsy ? '0' : '9999px',
                      fontFamily: bodyFont,
                    }}
                  >
                    #{tag}
                  </span>
                ))}
              </div>
              <div className="flex items-center justify-between mt-3 pt-3" style={{ borderTop: `1px solid ${cardBorder}` }}>
                <div className="flex items-center gap-3">
                  <span className="flex items-center gap-1 text-[11px]" style={{ color: cardTextMuted }}>
                    <MapPin size={11} /> {venueDistrict}
                  </span>
                  <span className="text-[11px]" style={{ color: cardTextMuted }}>{'$'.repeat(venue.priceRange)}</span>
                </div>
                <span className="flex items-center gap-1 text-[11px]" style={{ color: modeColor, fontWeight: 600 }}>
                  Details <ArrowRight size={10} />
                </span>
              </div>
            </div>
          </div>
        ) : (
          /* ─── Split panel row layout ─── */
          <div className="flex gap-3 p-3">
            <div className="h-20 w-20 flex-shrink-0 overflow-hidden relative" style={{ borderRadius: imgRadius }}>
              <ImageWithFallback
                src={venue.image}
                alt={venue.name}
                className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
              />
              {isSaved && (
                <div className="absolute bottom-1 right-1">
                  <div className="p-0.5 backdrop-blur-sm rounded-full" style={{ backgroundColor: 'rgba(0,0,0,0.4)' }}>
                    <Heart size={10} fill={modeColor} style={{ color: modeColor }} />
                  </div>
                </div>
              )}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5 mb-0.5">
                <CIcon id={venue.category} size={14} mode="auto" />
                <h3
                  className="text-sm truncate group-hover:opacity-80 transition-opacity"
                  style={{
                    fontFamily: headingFont,
                    color: cardText,
                    fontWeight: isDegen ? 700 : isArtsy ? 400 : 600,
                    textTransform: isDegen ? 'uppercase' : 'none',
                  }}
                >
                  {venueName}
                </h3>
              </div>
              <p className="text-[11px] mb-1" style={{ color: cardTextMuted, fontFamily: bodyFont }}>{secondaryName}</p>
              {/* Description — 2-line clamp */}
              {venueDescription && (
                <p className="text-xs" style={{ color: cardTextSub, fontFamily: bodyFont, lineHeight: 1.5, ...splitDescClampStyle }}>
                  {venueDescription}
                </p>
              )}
              <div className="flex items-center gap-2 mt-1.5">
                <span className="flex items-center gap-1 text-[10px]" style={{ color: cardTextMuted }}>
                  <MapPin size={10} /> {venueDistrict}
                </span>
                {currentMode && currentMode !== 'lifestyle' && (
                  <span
                    className="px-1.5 py-0.5 text-[9px]"
                    style={{
                      backgroundColor: isDegen ? 'rgba(237,255,0,0.15)' : `${modeColor}15`,
                      color: isDegen ? '#EDFF00' : modeColor,
                      borderRadius: isDegen ? '2px' : isArtsy ? '0' : '9999px',
                      fontFamily: headingFont,
                      fontWeight: isDegen ? 700 : 500,
                    }}
                  >
                    {Math.round((venue.modeScores[currentMode] || 0) * 100)}%
                  </span>
                )}
                <span className="text-[10px]" style={{ color: cardTextMuted }}>{'$'.repeat(venue.priceRange)}</span>
              </div>
            </div>
          </div>
        )}
      </button>
    </div>
  );
}