/**
 * Pure Leaflet React wrapper — replaces react-leaflet to avoid React 19 dependency.
 * Provides MapContainer, TileLayer, Marker, Popup components and useMap/useMapEvents hooks.
 */
import { createContext, useContext, useEffect, useRef, useState, useCallback, type ReactNode } from 'react';
import L from 'leaflet';

// ─── Map Context ───
const MapContext = createContext<L.Map | null>(null);

export function useMap(): L.Map {
  const map = useContext(MapContext);
  if (!map) throw new Error('useMap must be used inside MapContainer');
  return map;
}

export function useMapEvents(handlers: Partial<Record<string, (e: any) => void>>): L.Map {
  const map = useMap();
  useEffect(() => {
    const entries = Object.entries(handlers);
    entries.forEach(([event, handler]) => {
      if (handler) map.on(event, handler);
    });
    return () => {
      entries.forEach(([event, handler]) => {
        if (handler) map.off(event, handler);
      });
    };
  }, [map]); // intentionally stable — handlers shouldn't change
  return map;
}

// ─── MapContainer ───
interface MapContainerProps {
  center: [number, number];
  zoom: number;
  className?: string;
  style?: React.CSSProperties;
  zoomControl?: boolean;
  children?: ReactNode;
}

export function MapContainer({ center, zoom, className, style, zoomControl = true, children }: MapContainerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const [mapReady, setMapReady] = useState(false);

  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;
    const map = L.map(containerRef.current, {
      center,
      zoom,
      zoomControl,
    });
    mapRef.current = map;
    // Defer mapReady and invalidate size after layout settles
    // A single rAF may not be enough when the map container is inside a
    // flex/grid layout that only resolves after the first paint (e.g.
    // switching from Lifestyle mode's separate MapContainer to the
    // regular split-view MapContainer).
    requestAnimationFrame(() => {
      if (mapRef.current === map) {
        try { map.invalidateSize(); } catch (_) {}
        setMapReady(true);
        // Belt-and-suspenders: invalidate multiple times as layout/transitions settle
        // This handles AnimatePresence mode="wait" which delays container visibility
        const delays = [200, 500, 1000];
        delays.forEach(ms => {
          setTimeout(() => {
            if (mapRef.current === map) {
              try { map.invalidateSize(); } catch (_) {}
            }
          }, ms);
        });
      }
    });

    // ResizeObserver: re-invalidate whenever the container is resized
    // (e.g. split-view panel resize, window resize, mode switch layout change)
    let ro: ResizeObserver | null = null;
    if (typeof ResizeObserver !== 'undefined' && containerRef.current) {
      ro = new ResizeObserver(() => {
        if (mapRef.current === map) {
          try { map.invalidateSize(); } catch (_) {}
        }
      });
      ro.observe(containerRef.current);
    }

    return () => {
      setMapReady(false);
      if (ro) { try { ro.disconnect(); } catch (_) {} }
      // Stop any in-flight zoom/pan animations before removing
      try { map.stop(); } catch (_) {}
      // Small delay to let pending animation frames settle
      try { map.remove(); } catch (_) {}
      mapRef.current = null;
    };
  }, []); // mount once

  // Update center/zoom if they change (for key-based remounting)
  useEffect(() => {
    const map = mapRef.current;
    if (map && map.getContainer()) {
      try { map.setView(center, zoom); } catch (_) {}
    }
  }, [center[0], center[1], zoom]);

  return (
    <div ref={containerRef} className={className} style={style}>
      {mapReady && mapRef.current && (
        <MapContext.Provider value={mapRef.current}>
          {children}
        </MapContext.Provider>
      )}
    </div>
  );
}

// ─── TileLayer ───
interface TileLayerProps {
  url: string;
  attribution?: string;
}

export function TileLayer({ url, attribution }: TileLayerProps) {
  const map = useMap();
  const layerRef = useRef<L.TileLayer | null>(null);

  useEffect(() => {
    const layer = L.tileLayer(url, { attribution: attribution || '' });
    layer.addTo(map);
    layerRef.current = layer;
    return () => {
      layer.remove();
    };
  }, [map, url, attribution]);

  return null;
}

// ─── Marker ───
interface MarkerProps {
  position: [number, number];
  icon?: L.DivIcon | L.Icon;
  eventHandlers?: Partial<Record<string, (e: any) => void>>;
  children?: ReactNode;
}

export function Marker({ position, icon, eventHandlers, children }: MarkerProps) {
  const map = useMap();
  const markerRef = useRef<L.Marker | null>(null);
  const popupRef = useRef<L.Popup | null>(null);
  const [popupContainer, setPopupContainer] = useState<HTMLDivElement | null>(null);

  // Create marker
  useEffect(() => {
    const opts: L.MarkerOptions = {};
    if (icon) opts.icon = icon;
    const marker = L.marker(position, opts).addTo(map);
    markerRef.current = marker;

    // Attach event handlers
    if (eventHandlers) {
      Object.entries(eventHandlers).forEach(([event, handler]) => {
        if (handler) marker.on(event, handler);
      });
    }

    return () => {
      marker.remove();
      markerRef.current = null;
    };
  }, [map]); // mount once per map

  // Update position
  useEffect(() => {
    if (markerRef.current) {
      markerRef.current.setLatLng(position);
    }
  }, [position[0], position[1]]);

  // Update icon
  useEffect(() => {
    if (markerRef.current && icon) {
      markerRef.current.setIcon(icon);
    }
  }, [icon]);

  // Update event handlers
  useEffect(() => {
    const marker = markerRef.current;
    if (!marker || !eventHandlers) return;
    // Re-bindhandlers
    Object.entries(eventHandlers).forEach(([event, handler]) => {
      marker.off(event);
      if (handler) marker.on(event, handler);
    });
  }, [eventHandlers]);

  // Handle Popup children
  useEffect(() => {
    const marker = markerRef.current;
    if (!marker) return;
    // We look for a Popup child — handled via PopupPortal below
  }, [children]);

  return <>{children && markerRef.current ? <PopupBinder marker={markerRef.current}>{children}</PopupBinder> : null}</>;
}

// ─── Popup ───
interface PopupProps {
  className?: string;
  children?: ReactNode;
}

// Internal: binds popup content to a marker
function PopupBinder({ marker, children }: { marker: L.Marker; children: ReactNode }) {
  // Extract Popup children
  const popupChildren: ReactNode[] = [];
  const otherChildren: ReactNode[] = [];

  const childArray = Array.isArray(children) ? children : [children];
  childArray.forEach((child: any) => {
    if (child && child.type === Popup) {
      popupChildren.push(child);
    } else {
      otherChildren.push(child);
    }
  });

  return (
    <>
      {popupChildren.map((popup: any, i) => (
        <PopupRenderer key={i} marker={marker} className={popup.props?.className}>
          {popup.props?.children}
        </PopupRenderer>
      ))}
    </>
  );
}

function PopupRenderer({ marker, className, children }: { marker: L.Marker; className?: string; children?: ReactNode }) {
  const containerRef = useRef<HTMLDivElement>(document.createElement('div'));
  const popupRef = useRef<L.Popup | null>(null);
  const [, forceUpdate] = useState(0);

  useEffect(() => {
    const popup = L.popup({ className: className || '' });
    popup.setContent(containerRef.current);
    marker.bindPopup(popup);
    popupRef.current = popup;
    forceUpdate(n => n + 1);

    return () => {
      marker.unbindPopup();
    };
  }, [marker, className]);

  // Render children into the container div using a portal-like approach
  // We use a simpler approach: render to innerHTML
  useEffect(() => {
    if (!containerRef.current) return;
    // For simple text/HTML content, we'll render via a temporary container
  }, [children]);

  // Use a ref-based approach to render React content
  return (
    <PopupContent container={containerRef.current}>
      {children}
    </PopupContent>
  );
}

// Renders React content into a DOM element (for Leaflet popup)
import { createPortal } from 'react-dom';

function PopupContent({ container, children }: { container: HTMLElement; children?: ReactNode }) {
  return createPortal(children, container);
}

export function Popup({ className, children }: PopupProps) {
  // This is a marker component — actual rendering is handled by PopupBinder/PopupRenderer
  return null;
}