/**
 * LifestyleEventPanel — slide-in detail panel for lifestyle events on the map
 */
import { motion } from 'motion/react';
import { X, Calendar, Clock, MapPin, Users, Heart, ExternalLink, ArrowRight, Building2 } from 'lucide-react';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { LC, LF, lifestyleCategories, formatLifestyleDate, type LifestyleEvent } from '../../data/lifestyle-data';

interface Props {
  event: LifestyleEvent;
  onClose: () => void;
}

export function LifestyleEventPanel({ event, onClose }: Props) {
  return (
    <motion.div
      initial={{ x: '100%', opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      exit={{ x: '100%', opacity: 0 }}
      transition={{ type: 'spring', stiffness: 300, damping: 30 }}
      className="absolute top-0 right-0 bottom-0 w-full sm:w-[380px] z-[1000] backdrop-blur-xl border-l overflow-y-auto"
      style={{ background: 'rgba(250,250,245,0.97)', borderColor: LC.deepForestBorder }}
    >
      <button onClick={onClose}
        className="absolute top-4 right-4 z-10 p-2 cursor-pointer transition-all hover:opacity-70"
        style={{ borderRadius: '50%', backgroundColor: 'rgba(45,106,79,0.1)', color: LC.forest }}>
        <X size={16} />
      </button>

      <div className="relative h-52 overflow-hidden">
        <ImageWithFallback src={event.image} alt={event.title} className="h-full w-full object-cover" />
        <div className="absolute inset-0" style={{ background: `linear-gradient(to top, ${LC.offWhite}, transparent 60%)` }} />
        <div className="absolute top-4 left-4 flex gap-2">
          <span className="text-[10px] uppercase tracking-wider px-2.5 py-1 backdrop-blur-xl" style={{ color: LC.white, backgroundColor: 'rgba(45,106,79,0.7)', borderRadius: '8px', fontFamily: LF.mono, fontWeight: 600 }}>
            {lifestyleCategories.find(c => c.key === event.category)?.boldLabel}
          </span>
          {event.difficulty && (
            <span className="text-[10px] uppercase tracking-wider px-2.5 py-1 backdrop-blur-xl" style={{ color: LC.white, backgroundColor: 'rgba(0,0,0,0.4)', borderRadius: '8px', fontFamily: LF.mono }}>
              {event.difficulty}
            </span>
          )}
        </div>
      </div>

      <div className="px-5 pb-6 -mt-6 relative">
        <h2 style={{ fontFamily: LF.heading, fontSize: '1.5rem', fontWeight: 900, color: LC.black, letterSpacing: '-0.02em', lineHeight: 1.1, marginBottom: '4px' }}>
          {event.title}
        </h2>
        <p className="text-sm mb-4" style={{ color: LC.textMuted, fontFamily: LF.body, fontStyle: 'italic' }}>{event.subtitle}</p>
        <p className="text-sm mb-5" style={{ color: '#5A5A5A', fontFamily: LF.body, lineHeight: 1.7 }}>{event.description}</p>

        <div className="grid grid-cols-2 gap-2.5 mb-5">
          {[
            { icon: Calendar, label: 'Date', value: formatLifestyleDate(event.date) },
            { icon: Clock, label: 'Time', value: event.time },
            { icon: MapPin, label: 'Location', value: event.location },
            { icon: Users, label: 'Capacity', value: `${event.spotsLeft}/${event.capacity}` },
          ].map((item) => (
            <div key={item.label} className="p-2.5" style={{ borderRadius: '12px', backgroundColor: 'rgba(45,106,79,0.06)' }}>
              <div className="flex items-center gap-1.5 mb-0.5">
                <item.icon size={11} style={{ color: LC.forest }} />
                <span className="text-[9px] uppercase tracking-wider" style={{ color: LC.textMuted, fontFamily: LF.mono }}>{item.label}</span>
              </div>
              <span className="text-xs" style={{ color: LC.black, fontFamily: LF.body, fontWeight: 500 }}>{item.value}</span>
            </div>
          ))}
        </div>

        <div className="flex items-center gap-3 mb-5 p-3" style={{ borderRadius: '12px', backgroundColor: 'rgba(45,106,79,0.06)' }}>
          <div className="h-9 w-9 flex items-center justify-center" style={{ borderRadius: '10px', backgroundColor: 'rgba(45,106,79,0.1)' }}>
            <Heart size={14} style={{ color: LC.forestLight }} />
          </div>
          <div className="flex-1">
            <span className="text-sm block" style={{ color: LC.black, fontFamily: LF.body, fontWeight: 600 }}>{event.organizer}</span>
            <span className="text-[10px]" style={{ color: LC.textMuted, fontFamily: LF.body }}>Organizer</span>
          </div>
        </div>

        <div className="flex flex-wrap gap-1.5 mb-5">
          {event.tags.map((tag) => (
            <span key={tag} className="px-2.5 py-0.5 text-[10px]" style={{ color: LC.textMuted, backgroundColor: 'rgba(0,0,0,0.04)', borderRadius: '9999px', fontFamily: LF.body }}>
              #{tag}
            </span>
          ))}
        </div>

        <a
          href={event.ticketUrl || event.sourceUrl || '#'}
          target="_blank"
          rel="noopener noreferrer"
          className="w-full flex items-center justify-center gap-2 py-3 text-sm transition-all hover:opacity-90 cursor-pointer no-underline"
          style={{ backgroundColor: LC.forest, color: LC.white, borderRadius: '14px', fontFamily: LF.body, fontWeight: 700 }}>
          Join Event &mdash; {event.price}
          <ExternalLink size={14} />
        </a>
      </div>
    </motion.div>
  );
}

/** Compact lifestyle event card for split panel list */
export function LifestyleEventRow({ event, isSelected, isHovered, onSelect, onHover, onLeave }: {
  event: LifestyleEvent;
  isSelected: boolean;
  isHovered: boolean;
  onSelect: () => void;
  onHover: () => void;
  onLeave: () => void;
}) {
  return (
    <motion.button
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      onClick={onSelect}
      onMouseEnter={onHover}
      onMouseLeave={onLeave}
      className="w-full text-left transition-all cursor-pointer flex gap-3 p-3"
      style={{
        borderRadius: '16px',
        backgroundColor: isSelected ? 'rgba(45,106,79,0.2)' : isHovered ? 'rgba(45,106,79,0.08)' : 'transparent',
        border: isSelected ? `2px solid ${LC.forest}` : `1px solid ${LC.deepForestBorder}`,
      }}
    >
      <div className="h-16 w-16 flex-shrink-0 overflow-hidden" style={{ borderRadius: '12px' }}>
        <ImageWithFallback src={event.image} alt={event.title} className="h-full w-full object-cover" />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5 mb-0.5">
          <span className="text-[9px] uppercase tracking-wider px-1.5 py-0.5" style={{
            color: LC.sage, backgroundColor: 'rgba(149,213,178,0.1)', borderRadius: '4px', fontFamily: LF.mono, fontWeight: 600,
          }}>
            {lifestyleCategories.find(c => c.key === event.category)?.boldLabel}
          </span>
        </div>
        <h3 className="text-sm truncate" style={{ fontFamily: LF.heading, fontWeight: 800, color: LC.white, lineHeight: 1.2 }}>
          {event.title}
        </h3>
        <p className="text-[10px] mt-0.5 truncate" style={{ color: LC.deepForestTextLight, fontFamily: LF.body, fontStyle: 'italic' }}>{event.subtitle}</p>
        <div className="flex items-center gap-2 mt-1.5">
          <span className="flex items-center gap-1 text-[10px]" style={{ color: LC.sage, fontFamily: LF.body }}>
            <Calendar size={9} /> {formatLifestyleDate(event.date)}
          </span>
          <span className="text-[10px]" style={{ color: LC.deepForestTextLight }}>{event.time}</span>
          <span className="text-[10px] ml-auto font-semibold" style={{ color: event.price === 'Free' ? LC.sage : '#E8744F', fontFamily: LF.mono }}>{event.price}</span>
        </div>
      </div>
    </motion.button>
  );
}

/** Lifestyle event grid card for list view */
export function LifestyleEventGridCard({ event, isSelected, isHovered, onSelect, onHover, onLeave }: {
  event: LifestyleEvent;
  isSelected: boolean;
  isHovered: boolean;
  onSelect: () => void;
  onHover: () => void;
  onLeave: () => void;
}) {
  return (
    <motion.button
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      onClick={onSelect}
      onMouseEnter={onHover}
      onMouseLeave={onLeave}
      className="w-full text-left transition-all cursor-pointer group flex flex-col overflow-hidden"
      style={{
        borderRadius: '16px',
        border: isSelected ? `2px solid ${LC.forest}` : `1px solid ${LC.deepForestBorder}`,
        backgroundColor: isSelected ? 'rgba(45,106,79,0.15)' : isHovered ? 'rgba(45,106,79,0.06)' : LC.deepForestCard,
      }}
    >
      <div className="relative overflow-hidden aspect-[16/10]">
        <ImageWithFallback src={event.image} alt={event.title} className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
        <div className="absolute top-3 left-3">
          <span className="text-[9px] uppercase tracking-wider px-2 py-1 backdrop-blur-xl" style={{
            color: LC.white, backgroundColor: 'rgba(45,106,79,0.7)', borderRadius: '8px', fontFamily: LF.mono, fontWeight: 600,
          }}>
            {lifestyleCategories.find(c => c.key === event.category)?.boldLabel}
          </span>
        </div>
        <div className="absolute top-3 right-3">
          <span className="text-[10px] font-semibold px-2 py-1 backdrop-blur-sm" style={{
            color: '#fff',
            backgroundColor: event.price === 'Free' ? 'rgba(45,106,79,0.8)' : 'rgba(232,116,79,0.8)',
            borderRadius: '9999px', fontFamily: LF.mono,
          }}>
            {event.price}
          </span>
        </div>
        <div className="absolute bottom-3 left-3 flex items-center gap-1.5">
          <MapPin size={10} style={{ color: 'rgba(255,255,255,0.7)' }} />
          <span className="text-[11px] text-white/80" style={{ fontFamily: LF.body }}>{event.district}</span>
        </div>
      </div>
      <div className="p-3 sm:p-4 flex-1 flex flex-col">
        <h3 className="mb-1 line-clamp-1 group-hover:opacity-80 transition-opacity" style={{
          fontFamily: LF.heading, fontSize: '0.95rem', color: LC.white, fontWeight: 800, letterSpacing: '-0.01em',
        }}>
          {event.title}
        </h3>
        <p className="text-xs mb-2 line-clamp-1" style={{ color: LC.deepForestTextLight, fontFamily: LF.body, fontStyle: 'italic' }}>{event.subtitle}</p>
        <div className="flex flex-wrap gap-1.5 mb-3">
          {event.tags.slice(0, 3).map((tag) => (
            <span key={tag} className="px-2 py-0.5 text-[10px]" style={{
              backgroundColor: 'rgba(45,106,79,0.15)', color: LC.sage, borderRadius: '9999px', fontFamily: LF.body,
            }}>
              #{tag}
            </span>
          ))}
        </div>
        <div className="flex items-center justify-between mt-auto pt-3" style={{ borderTop: `1px solid ${LC.deepForestBorder}` }}>
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1 text-[11px]" style={{ color: LC.deepForestTextLight }}>
              <Calendar size={11} /> {formatLifestyleDate(event.date)}
            </span>
            <span className="text-[11px]" style={{ color: LC.deepForestTextLight }}>{event.time}</span>
          </div>
          <span className="flex items-center gap-1 text-[11px]" style={{ color: LC.sage, fontWeight: 600 }}>
            Details <ArrowRight size={10} />
          </span>
        </div>
      </div>
    </motion.button>
  );
}

/** Lifestyle venue row card for split panel */
export function LifestyleVenueRow({ venue, isSelected, isHovered, onSelect, onHover, onLeave }: {
  venue: { id: string; name: string; nameZh?: string; category?: string; district?: string; image?: string; priceRange?: number; modeScores?: Record<string, number> };
  isSelected: boolean;
  isHovered: boolean;
  onSelect: () => void;
  onHover: () => void;
  onLeave: () => void;
}) {
  const score = Math.round((venue.modeScores?.lifestyle || 0) * 100);
  return (
    <motion.button
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      onClick={onSelect}
      onMouseEnter={onHover}
      onMouseLeave={onLeave}
      className="w-full text-left transition-all cursor-pointer flex gap-3 p-3"
      style={{
        borderRadius: '16px',
        backgroundColor: isSelected ? 'rgba(45,106,79,0.2)' : isHovered ? 'rgba(45,106,79,0.08)' : 'transparent',
        border: isSelected ? `2px solid ${LC.forest}` : `1px solid ${LC.deepForestBorder}`,
      }}
    >
      <div className="h-16 w-16 flex-shrink-0 overflow-hidden flex items-center justify-center" style={{ borderRadius: '12px', backgroundColor: 'rgba(45,106,79,0.15)' }}>
        {venue.image ? (
          <ImageWithFallback src={venue.image} alt={venue.name} className="h-full w-full object-cover" />
        ) : (
          <Building2 size={20} style={{ color: LC.sage }} />
        )}
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5 mb-0.5">
          <span className="text-[9px] uppercase tracking-wider px-1.5 py-0.5" style={{
            color: LC.sage, backgroundColor: 'rgba(149,213,178,0.1)', borderRadius: '4px', fontFamily: LF.mono, fontWeight: 600,
          }}>
            {venue.category || 'Venue'}
          </span>
          <span className="text-[9px] font-semibold tabular-nums" style={{ color: LC.sage, fontFamily: LF.mono }}>
            {score}%
          </span>
        </div>
        <h3 className="text-sm truncate" style={{ fontFamily: LF.heading, fontWeight: 800, color: LC.white, lineHeight: 1.2 }}>
          {venue.name}
        </h3>
        {venue.nameZh && <p className="text-[10px] mt-0.5 truncate" style={{ color: LC.deepForestTextLight, fontFamily: LF.body }}>{venue.nameZh}</p>}
        <div className="flex items-center gap-2 mt-1.5">
          <span className="flex items-center gap-1 text-[10px]" style={{ color: LC.sage, fontFamily: LF.body }}>
            <MapPin size={9} /> {venue.district || '—'}
          </span>
          <span className="text-[10px] ml-auto" style={{ color: LC.sage, fontFamily: LF.mono, fontWeight: 600 }}>
            {'$'.repeat(venue.priceRange || 1)}
          </span>
        </div>
      </div>
    </motion.button>
  );
}