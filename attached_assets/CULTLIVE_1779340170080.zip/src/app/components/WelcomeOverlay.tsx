import { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowRight, Check, Sparkles, X } from 'lucide-react';
import { useMode } from '../context/ModeContext';
import { modeConfig, type Mode } from '../data/mock-data';
import { CIcon } from './CIcon';
import type { TasteProfile } from './OnboardingQuiz';

// ═══════════════════════════════════════════════════════════════════
// ENTER THE VOID — Kinetic typography + enriched taste quiz
// Phase 1: Gaspar Noé-style rapid-fire type sequence
// Phase 2: Mode selector + detailed sub-genre taste quiz
// Saves both mode preference AND taste profile for weekly picks
// ═══════════════════════════════════════════════════════════════════

const STORAGE_KEY = 'cultive-welcome-seen';
const PREFS_KEY = 'cultive-preferences';
const TASTE_KEY = 'cultive:taste_quiz';

// Words that flash during the intro
const SEQUENCE_WORDS: { text: string; color: string; glow: string; scale?: number }[] = [
  { text: 'CULTIVE', color: '#ffffff', glow: '#ffffff', scale: 1.4 },
  { text: '文化活', color: '#ffffff', glow: '#ffffff', scale: 1.2 },
  { text: 'NIGHT', color: '#D600FF', glow: '#D600FF', scale: 1.3 },
  { text: 'NIGHTLIFE', color: '#EDFF00', glow: '#EDFF00' },
  { text: 'MUSIC', color: '#D600FF', glow: '#D600FF' },
  { text: 'UNDERGROUND', color: '#EDFF00', glow: '#EDFF00', scale: 0.8 },
  { text: 'ART & DESIGN', color: '#8338EC', glow: '#8338EC', scale: 1.3 },
  { text: 'GALLERIES', color: '#B4A0D1', glow: '#8338EC' },
  { text: 'EXHIBITIONS', color: '#8338EC', glow: '#8338EC', scale: 0.85 },
  { text: 'CULTURE', color: '#B4A0D1', glow: '#8338EC' },
  { text: 'FOOD', color: '#2563EB', glow: '#2563EB', scale: 1.3 },
  { text: 'FOOD & DRINKS', color: '#60A5FA', glow: '#2563EB', scale: 0.9 },
  { text: 'MARKETS', color: '#2563EB', glow: '#2563EB' },
  { text: 'FAMILY', color: '#FF8C42', glow: '#FF8C42', scale: 1.3 },
  { text: 'COMMUNITY', color: '#43D9AD', glow: '#43D9AD' },
  { text: 'WORSHIP', color: '#FFD700', glow: '#FFD700' },
  { text: 'LIFESTYLE', color: '#2D6A4F', glow: '#2D6A4F', scale: 1.3 },
  { text: 'WELLNESS', color: '#95D5B2', glow: '#95D5B2' },
  { text: 'RUN CLUBS', color: '#2D6A4F', glow: '#2D6A4F' },
  { text: 'ARTS', color: '#8338EC', glow: '#8338EC' },
  { text: 'HONG KONG', color: '#FF3366', glow: '#FF3366', scale: 1.1 },
  { text: '香港', color: '#FF3366', glow: '#FF3366', scale: 1.4 },
  { text: 'ENTER', color: '#ffffff', glow: '#ffffff', scale: 1.6 },
];

// ─── Enriched taste categories (replaces basic interest tags) ───
interface TasteChip {
  id: string;
  label: string;
  modes: Mode[]; // which modes this chip relates to
}

interface TasteGroup {
  key: string;
  label: string;
  emoji: string;
  color: string;
  glow: string;
  chips: TasteChip[];
}

const TASTE_GROUPS: TasteGroup[] = [
  {
    key: 'music',
    label: 'Music & Nightlife',
    emoji: '🎵',
    color: '#D600FF',
    glow: '#D600FF',
    chips: [
      { id: 'music:dnb', label: 'DnB', modes: ['degen'] },
      { id: 'music:electronic', label: 'Electronic / Techno', modes: ['degen'] },
      { id: 'music:hip-hop', label: 'Hip-Hop / R&B', modes: ['degen'] },
      { id: 'music:jazz', label: 'Jazz / Soul', modes: ['degen', 'artsy'] },
      { id: 'music:live', label: 'Live Bands', modes: ['degen'] },
      { id: 'music:indie', label: 'Indie / Alternative', modes: ['degen', 'artsy'] },
      { id: 'music:canto', label: 'Cantopop / 廣東歌', modes: ['degen', 'artsy'] },
    ],
  },
  {
    key: 'food',
    label: 'Food & Drink',
    emoji: '🍜',
    color: '#2563EB',
    glow: '#2563EB',
    chips: [
      { id: 'food:fine-dining', label: 'Fine Dining', modes: ['foodie'] },
      { id: 'food:street', label: 'Street Food / Dai Pai Dong', modes: ['foodie'] },
      { id: 'food:cafes', label: 'Specialty Coffee', modes: ['foodie'] },
      { id: 'food:bars', label: 'Cocktail Bars / Wine', modes: ['foodie', 'degen'] },
      { id: 'food:markets', label: 'Markets & Pop-ups', modes: ['foodie', 'family'] },
      { id: 'food:brunch', label: 'Brunch / Casual', modes: ['foodie'] },
    ],
  },
  {
    key: 'art',
    label: 'Art & Culture',
    emoji: '🎨',
    color: '#8338EC',
    glow: '#8338EC',
    chips: [
      { id: 'art:galleries', label: 'Galleries & Exhibitions', modes: ['artsy'] },
      { id: 'art:theatre', label: 'Theatre & Performance', modes: ['artsy'] },
      { id: 'art:film', label: 'Indie Film / Screenings', modes: ['artsy'] },
      { id: 'art:design', label: 'Design & Architecture', modes: ['artsy'] },
      { id: 'art:photography', label: 'Photography', modes: ['artsy'] },
      { id: 'art:workshops', label: 'Creative Workshops', modes: ['artsy', 'family'] },
    ],
  },
  {
    key: 'wellness',
    label: 'Wellness & Outdoors',
    emoji: '🧘',
    color: '#2D6A4F',
    glow: '#95D5B2',
    chips: [
      { id: 'wellness:yoga', label: 'Yoga / Pilates', modes: ['family'] },
      { id: 'wellness:running', label: 'Run Clubs', modes: ['family'] },
      { id: 'wellness:hiking', label: 'Hiking / Nature', modes: ['family'] },
      { id: 'wellness:meditation', label: 'Sound Bath / Meditation', modes: ['artsy', 'family'] },
      { id: 'wellness:fitness', label: 'CrossFit / Fitness', modes: ['family'] },
    ],
  },
  {
    key: 'social',
    label: 'Social & Community',
    emoji: '🤝',
    color: '#FF8C42',
    glow: '#FF8C42',
    chips: [
      { id: 'social:meetups', label: 'Meetups & Networking', modes: ['family'] },
      { id: 'social:family', label: 'Family & Kids', modes: ['family'] },
      { id: 'social:startup', label: 'Startup / Tech Events', modes: ['artsy'] },
      { id: 'social:language', label: 'Language Exchange', modes: ['family'] },
      { id: 'social:volunteer', label: 'Volunteering', modes: ['family'] },
    ],
  },
];

// All chips flat for scoring
const ALL_CHIPS = TASTE_GROUPS.flatMap(g => g.chips);

interface WelcomeOverlayProps {
  onComplete: () => void;
}

type Phase = 'sequence' | 'picker';

export function WelcomeOverlay({ onComplete }: WelcomeOverlayProps) {
  const { setMode } = useMode();
  const [phase, setPhase] = useState<Phase>('sequence');
  const [wordIndex, setWordIndex] = useState(0);
  const [selectedMode, setSelectedMode] = useState<Mode | null>(null);
  const [selectedChips, setSelectedChips] = useState<Set<string>>(new Set());
  const [isExiting, setIsExiting] = useState(false);
  const sequenceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // ── Title sequence timing ──
  useEffect(() => {
    if (phase !== 'sequence') return;

    const durations = SEQUENCE_WORDS.map((_, i) => {
      if (i < 3) return 320;
      if (i < 8) return 200;
      if (i < 14) return 160;
      if (i < 18) return 140;
      return 280;
    });

    if (wordIndex < SEQUENCE_WORDS.length) {
      sequenceTimerRef.current = setTimeout(() => {
        setWordIndex((i) => i + 1);
      }, durations[wordIndex]);
    } else {
      sequenceTimerRef.current = setTimeout(() => {
        setPhase('picker');
      }, 400);
    }

    return () => {
      if (sequenceTimerRef.current) clearTimeout(sequenceTimerRef.current);
    };
  }, [phase, wordIndex]);

  const skipSequence = useCallback(() => {
    if (sequenceTimerRef.current) clearTimeout(sequenceTimerRef.current);
    setPhase('picker');
  }, []);

  const toggleChip = useCallback((id: string) => {
    setSelectedChips(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  // Auto-suggest mode based on selected chips
  useEffect(() => {
    if (selectedChips.size === 0) {
      setSelectedMode(null);
      return;
    }
    const scores: Record<Mode, number> = { degen: 0, artsy: 0, foodie: 0, family: 0 };
    selectedChips.forEach(id => {
      const chip = ALL_CHIPS.find(c => c.id === id);
      if (chip) chip.modes.forEach(m => { scores[m] += 1; });
    });
    const best = (Object.entries(scores) as [Mode, number][]).sort((a, b) => b[1] - a[1])[0];
    if (best[1] > 0) setSelectedMode(best[0]);
  }, [selectedChips]);

  const handleStart = useCallback(() => {
    // Save mode preferences (legacy)
    localStorage.setItem(PREFS_KEY, JSON.stringify({
      mode: selectedMode,
      interests: Array.from(selectedChips),
      timestamp: Date.now(),
    }));
    localStorage.setItem(STORAGE_KEY, 'true');

    // Save taste profile for weekly picks system
    if (selectedChips.size > 0) {
      const tasteProfile: TasteProfile = {
        selections: Array.from(selectedChips),
        completedAt: new Date().toISOString(),
      };
      localStorage.setItem(TASTE_KEY, JSON.stringify(tasteProfile));
    }

    if (selectedMode) setMode(selectedMode);

    setIsExiting(true);
    setTimeout(() => {
      onComplete();
    }, 600);
  }, [selectedMode, selectedChips, setMode, onComplete]);

  const currentWord = phase === 'sequence' && wordIndex < SEQUENCE_WORDS.length
    ? SEQUENCE_WORDS[wordIndex]
    : null;

  const activeColor = selectedMode ? modeConfig[selectedMode].color : '#ffffff';

  return (
    <AnimatePresence>
      {!isExiting && (
        <motion.div
          className="fixed inset-0 z-[99999] flex items-center justify-center overflow-hidden"
          style={{ backgroundColor: '#000000' }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
        >
          {/* ═══ PHASE 1: Enter the Void title sequence ═══ */}
          <AnimatePresence mode="wait">
            {phase === 'sequence' && (
              <motion.div
                key="sequence"
                className="absolute inset-0 flex items-center justify-center cursor-pointer"
                onClick={skipSequence}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
              >
                {/* Strobing background flash */}
                <AnimatePresence mode="wait">
                  {currentWord && (
                    <motion.div
                      key={`bg-${wordIndex}`}
                      className="absolute inset-0"
                      initial={{ opacity: 0.15 }}
                      animate={{ opacity: 0 }}
                      transition={{ duration: 0.15 }}
                      style={{ backgroundColor: currentWord.color }}
                    />
                  )}
                </AnimatePresence>

                {/* The word */}
                <AnimatePresence mode="wait">
                  {currentWord && (
                    <motion.div
                      key={`word-${wordIndex}`}
                      className="absolute inset-0 flex items-center justify-center px-4"
                      initial={{ opacity: 0, scale: 1.8 }}
                      animate={{ opacity: 1, scale: currentWord.scale || 1 }}
                      exit={{ opacity: 0, scale: 0.85 }}
                      transition={{
                        duration: 0.1,
                        ease: [0.16, 1, 0.3, 1],
                      }}
                    >
                      <span
                        className="text-center select-none leading-none"
                        style={{
                          fontFamily: "'Archivo Black', 'Space Grotesk', sans-serif",
                          fontSize: 'clamp(3rem, 18vw, 14rem)',
                          fontWeight: 900,
                          color: currentWord.color,
                          textTransform: 'uppercase',
                          letterSpacing: '-0.04em',
                          textShadow: `
                            0 0 40px ${currentWord.glow}60,
                            0 0 80px ${currentWord.glow}30,
                            0 0 120px ${currentWord.glow}15
                          `,
                          WebkitTextStroke: wordIndex < 2 ? 'none' : undefined,
                        }}
                      >
                        {currentWord.text}
                      </span>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Skip hint */}
                <motion.div
                  className="absolute bottom-8 left-0 right-0 text-center"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 0.3 }}
                  transition={{ delay: 1.5 }}
                >
                  <span
                    className="text-white/30 text-xs tracking-[0.3em] uppercase"
                    style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                  >
                    Tap to skip
                  </span>
                </motion.div>

                {/* Scan lines overlay for CRT effect */}
                <div
                  className="absolute inset-0 pointer-events-none"
                  style={{
                    backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.15) 2px, rgba(0,0,0,0.15) 4px)',
                    mixBlendMode: 'multiply',
                  }}
                />
              </motion.div>
            )}
          </AnimatePresence>

          {/* ═══ PHASE 2: Enriched Taste Quiz ═══ */}
          <AnimatePresence>
            {phase === 'picker' && (
              <motion.div
                key="picker"
                className="absolute inset-0 flex flex-col"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
              >
                {/* Ambient glow bg */}
                <div
                  className="fixed inset-0 pointer-events-none"
                  style={{
                    background: selectedMode
                      ? `radial-gradient(ellipse at 50% 20%, ${activeColor}10, transparent 60%)`
                      : 'none',
                    transition: 'background 0.8s ease',
                  }}
                />

                {/* Skip */}
                <motion.button
                  onClick={handleStart}
                  className="fixed top-5 right-5 z-10 flex items-center gap-1 px-3 py-1.5 text-[11px] text-white/25 hover:text-white/50 transition-colors cursor-pointer"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.4 }}
                  style={{ fontFamily: "'Space Grotesk', sans-serif", letterSpacing: '0.05em', backgroundColor: 'transparent', border: 'none' }}
                >
                  Skip <X size={12} />
                </motion.button>

                {/* Scrollable content */}
                <div className="flex-1 overflow-y-auto">
                  <div className="w-full max-w-xl mx-auto px-5 pt-12 pb-32 sm:pt-16">
                    {/* ── Header: Logo + tagline ── */}
                    <motion.div
                      className="text-center mb-10"
                      initial={{ opacity: 0, y: 16 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.7, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
                    >
                      <h1
                        className="leading-none"
                        style={{
                          fontFamily: "'Archivo Black', sans-serif",
                          fontSize: 'clamp(2rem, 6vw, 3.5rem)',
                          color: '#ffffff',
                          letterSpacing: '-0.03em',
                        }}
                      >
                        CULTIVE
                      </h1>
                      <p
                        className="mt-1.5"
                        style={{
                          fontFamily: "'Noto Sans HK', sans-serif",
                          fontSize: '0.85rem',
                          color: 'rgba(255,255,255,0.18)',
                          letterSpacing: '0.25em',
                        }}
                      >
                        文化活
                      </p>
                      <p
                        className="mt-5 max-w-xs mx-auto"
                        style={{
                          fontFamily: "'Inter', sans-serif",
                          fontSize: '0.8rem',
                          color: 'rgba(255,255,255,0.3)',
                          lineHeight: 1.65,
                        }}
                      >
                        Tell us what you're into — we'll shape your experience around it.
                      </p>
                    </motion.div>

                    {/* ── Mode Selector (compact horizontal strip) ── */}
                    <motion.div
                      className="mb-10"
                      initial={{ opacity: 0, y: 16 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.3, duration: 0.6 }}
                    >
                      <p
                        className="text-[10px] tracking-[0.2em] uppercase text-center mb-3"
                        style={{ color: 'rgba(255,255,255,0.2)', fontFamily: "'Space Grotesk', sans-serif" }}
                      >
                        Choose your mode
                      </p>

                      <div className="flex gap-2 justify-center">
                        {(Object.entries(modeConfig) as [Mode, typeof modeConfig.degen][]).map(
                          ([mode, config], i) => {
                            const isSelected = selectedMode === mode;
                            return (
                              <motion.button
                                key={mode}
                                onClick={() => setSelectedMode(isSelected ? null : mode)}
                                className="relative flex items-center gap-2 px-4 py-2.5 transition-all cursor-pointer"
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: 0.35 + i * 0.06 }}
                                whileHover={{ y: -1 }}
                                whileTap={{ scale: 0.97 }}
                                style={{
                                  borderRadius: '10px',
                                  backgroundColor: isSelected
                                    ? `${config.color}15`
                                    : 'rgba(255,255,255,0.03)',
                                  border: isSelected
                                    ? `1.5px solid ${config.color}50`
                                    : '1.5px solid rgba(255,255,255,0.06)',
                                  boxShadow: isSelected
                                    ? `0 0 20px ${config.color}12, inset 0 1px 0 ${config.color}10`
                                    : 'none',
                                }}
                              >
                                {config.emoji && <CIcon id={config.emoji} size={18} mode={mode} glow={isSelected} animated />}
                                <div className="text-left hidden sm:block">
                                  <span
                                    className="block text-xs leading-tight"
                                    style={{
                                      color: isSelected ? config.color : 'rgba(255,255,255,0.55)',
                                      fontFamily: "'Space Grotesk', sans-serif",
                                      fontWeight: 600,
                                      transition: 'color 0.3s',
                                    }}
                                  >
                                    {config.label}
                                  </span>
                                  <span
                                    className="block text-[9px] leading-tight mt-0.5"
                                    style={{
                                      color: isSelected
                                        ? `${config.color}70`
                                        : 'rgba(255,255,255,0.18)',
                                      fontFamily: "'Noto Sans HK', sans-serif",
                                      transition: 'color 0.3s',
                                    }}
                                  >
                                    {config.labelZh}
                                  </span>
                                </div>
                                {isSelected && (
                                  <motion.div
                                    className="absolute -top-1 -right-1"
                                    initial={{ scale: 0 }}
                                    animate={{ scale: 1 }}
                                    transition={{ type: 'spring', stiffness: 500, damping: 25 }}
                                  >
                                    <div
                                      className="w-4 h-4 rounded-full flex items-center justify-center"
                                      style={{ backgroundColor: config.color }}
                                    >
                                      <Check size={9} className="text-white" strokeWidth={3} />
                                    </div>
                                  </motion.div>
                                )}
                              </motion.button>
                            );
                          }
                        )}
                      </div>
                    </motion.div>

                    {/* ── Enriched Taste Quiz — sub-genre chips ── */}
                    <motion.div
                      className="space-y-7"
                      initial={{ opacity: 0, y: 16 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.55, duration: 0.6 }}
                    >
                      <p
                        className="text-[10px] tracking-[0.2em] uppercase text-center mb-1"
                        style={{ color: 'rgba(255,255,255,0.2)', fontFamily: "'Space Grotesk', sans-serif" }}
                      >
                        What are you into?
                      </p>

                      {TASTE_GROUPS.map((group, gi) => (
                        <motion.div
                          key={group.key}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: 0.6 + gi * 0.08 }}
                        >
                          {/* Group header */}
                          <div className="flex items-center gap-2.5 mb-3 px-1">
                            <span style={{ fontSize: '1rem' }}>{group.emoji}</span>
                            <div
                              className="w-1 h-3.5 rounded-full"
                              style={{ backgroundColor: `${group.color}60` }}
                            />
                            <span
                              className="text-[11px] tracking-wide"
                              style={{
                                color: `${group.color}90`,
                                fontFamily: "'Space Grotesk', sans-serif",
                                fontWeight: 500,
                              }}
                            >
                              {group.label}
                            </span>
                          </div>

                          {/* Chips */}
                          <div className="flex flex-wrap gap-2">
                            {group.chips.map(chip => {
                              const isSelected = selectedChips.has(chip.id);
                              return (
                                <motion.button
                                  key={chip.id}
                                  onClick={() => toggleChip(chip.id)}
                                  className="flex items-center gap-1.5 px-3.5 py-2 text-[12px] transition-all cursor-pointer"
                                  whileHover={{ scale: 1.04 }}
                                  whileTap={{ scale: 0.95 }}
                                  style={{
                                    borderRadius: '9px',
                                    backgroundColor: isSelected
                                      ? `${group.color}18`
                                      : 'rgba(255,255,255,0.03)',
                                    border: isSelected
                                      ? `1.5px solid ${group.color}45`
                                      : '1.5px solid rgba(255,255,255,0.06)',
                                    color: isSelected ? group.color : 'rgba(255,255,255,0.4)',
                                    fontFamily: "'Inter', sans-serif",
                                    fontWeight: isSelected ? 500 : 400,
                                    transition: 'all 0.2s ease',
                                    boxShadow: isSelected ? `0 0 12px ${group.color}10` : 'none',
                                  }}
                                >
                                  {chip.label}
                                  {isSelected && (
                                    <Check size={11} strokeWidth={2.5} style={{ color: group.color, marginLeft: 2 }} />
                                  )}
                                </motion.button>
                              );
                            })}
                          </div>
                        </motion.div>
                      ))}
                    </motion.div>
                  </div>
                </div>

                {/* ── Fixed bottom CTA bar ── */}
                <motion.div
                  className="fixed bottom-0 left-0 right-0 z-10"
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.9, duration: 0.5 }}
                >
                  {/* Gradient fade */}
                  <div
                    className="h-16 pointer-events-none"
                    style={{ background: 'linear-gradient(to bottom, transparent, #000000)' }}
                  />
                  <div
                    className="px-5 pb-6 pt-2 flex flex-col items-center gap-3"
                    style={{ backgroundColor: '#000000' }}
                  >
                    {/* Summary pill */}
                    <AnimatePresence>
                      {selectedChips.size > 0 && (
                        <motion.div
                          className="flex items-center gap-2 px-3 py-1 rounded-full"
                          initial={{ opacity: 0, y: 8 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: 8 }}
                          style={{
                            backgroundColor: 'rgba(255,255,255,0.05)',
                            border: '1px solid rgba(255,255,255,0.08)',
                          }}
                        >
                          <span
                            className="text-[11px]"
                            style={{ color: 'rgba(255,255,255,0.35)', fontFamily: "'Inter', sans-serif" }}
                          >
                            {selectedChips.size} interest{selectedChips.size !== 1 ? 's' : ''}
                          </span>
                          {selectedMode && (
                            <>
                              <span style={{ color: 'rgba(255,255,255,0.12)' }}>·</span>
                              <span
                                className="text-[11px] flex items-center gap-1"
                                style={{
                                  color: `${activeColor}90`,
                                  fontFamily: "'Space Grotesk', sans-serif",
                                  fontWeight: 500,
                                }}
                              >
                                <CIcon id={selectedMode} size={12} mode={selectedMode} glow />
                                {modeConfig[selectedMode].label}
                              </span>
                            </>
                          )}
                        </motion.div>
                      )}
                    </AnimatePresence>

                    {/* CTA button */}
                    <motion.button
                      onClick={handleStart}
                      className="group flex items-center justify-center gap-2.5 w-full max-w-sm py-3.5 text-[13px] cursor-pointer"
                      whileHover={{ scale: 1.02, y: -1 }}
                      whileTap={{ scale: 0.98 }}
                      style={{
                        borderRadius: selectedMode === 'degen' ? '6px' : '14px',
                        backgroundColor: selectedMode ? activeColor : '#ffffff',
                        color: selectedMode
                          ? (selectedMode === 'family' ? '#1a1a1a' : '#ffffff')
                          : '#000000',
                        fontFamily: "'Space Grotesk', sans-serif",
                        fontWeight: 700,
                        letterSpacing: '0.04em',
                        textTransform: 'uppercase',
                        boxShadow: selectedMode
                          ? `0 4px 24px ${activeColor}30, 0 0 60px ${activeColor}10`
                          : '0 4px 24px rgba(255,255,255,0.08)',
                        transition: 'background-color 0.4s, box-shadow 0.4s, border-radius 0.3s',
                        border: 'none',
                      }}
                    >
                      <Sparkles size={15} />
                      {selectedMode
                        ? `Enter ${modeConfig[selectedMode].label} Mode`
                        : 'Start Exploring'}
                      <ArrowRight
                        size={15}
                        className="transition-transform group-hover:translate-x-0.5"
                      />
                    </motion.button>

                    <p
                      className="text-[10px]"
                      style={{
                        color: 'rgba(255,255,255,0.1)',
                        fontFamily: "'Inter', sans-serif",
                      }}
                    >
                      Change anytime from your profile
                    </p>
                  </div>
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

/** Hook to manage welcome overlay visibility */
export function useWelcomeOverlay() {
  const [showWelcome, setShowWelcome] = useState(() => {
    try {
      return localStorage.getItem(STORAGE_KEY) !== 'true';
    } catch {
      return true;
    }
  });

  const dismiss = useCallback(() => {
    setShowWelcome(false);
  }, []);

  const reset = useCallback(() => {
    localStorage.removeItem(STORAGE_KEY);
    localStorage.removeItem(PREFS_KEY);
    localStorage.removeItem(TASTE_KEY);
    setShowWelcome(true);
  }, []);

  return { showWelcome, dismiss, reset };
}
