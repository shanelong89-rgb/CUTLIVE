import { useState } from 'react';
import { Link } from 'react-router';
import { useTranslation } from 'react-i18next';
import { motion } from 'motion/react';
import { ArrowRight, MapPin, Clock, Flame, UtensilsCrossed, Star, Map, ChevronLeft, ChevronRight } from 'lucide-react';
import { useData } from '../../context/DataContext';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { getDesignTokens } from '../../data/mode-styles';
import { ThingsToDo } from '../ThingsToDo';
import { CIcon } from '../CIcon';
import { CarouselFade } from '../CarouselFade';
import { getEventLink } from '../../utils/event-helpers';
import { parseEventDate } from '../../utils/date-helpers';
import { getBilingualField } from '../../utils/bilingual';
import { useSiteImages } from '../../hooks/useSiteImages';

// ═══════════════════════════════════════════════════════════════════
// FOOD MODE: Pretty Patty-inspired bold restaurant website
// ═══════════════════════════════════════════════════════════════════

function FoodieHero() {
  const { events } = useData();
  const { i18n, t } = useTranslation();
  const lang = i18n.language;
  const tokens = getDesignTokens('foodie');
  const foodieEvents = events.filter((e) => e.modeTags.includes('foodie'));
  const heroEvent = foodieEvents[0] || events[0];
  const { img: siteImg } = useSiteImages();

  return (
    <section className="relative min-h-[60vh] sm:min-h-[92vh] overflow-hidden flex items-center" data-nav-theme="light">
      {/* Background */}
      <div className="absolute inset-0">
        <ImageWithFallback
          src={siteImg('mode-hero-food') || heroEvent.image}
          alt={heroEvent.title}
          className="h-full w-full object-cover"
          style={{ filter: 'brightness(0.35) saturate(1.2)' }}
        />
        <div
          className="absolute inset-0"
          style={{
            background: `linear-gradient(135deg, rgba(10,18,40,0.95) 0%, rgba(10,18,40,0.6) 50%, rgba(37,99,235,0.15) 100%)`,
          }}
        />
        {/* Warm glow */}
        <div
          className="absolute bottom-0 right-0 w-[60%] h-[60%]"
          style={{
            background: 'radial-gradient(ellipse at 80% 80%, rgba(37,99,235,0.2), transparent 70%)',
          }}
        />
      </div>

      <div className="relative w-full max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-12 py-8 sm:py-0">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 sm:gap-8 items-center">
          {/* Left: text */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
          >
            <div className="flex items-center gap-2 mb-3 sm:mb-5">
              <div
                className="flex items-center gap-1.5 px-3 py-1.5"
                style={{
                  backgroundColor: 'rgba(37,99,235,0.15)',
                  borderRadius: '24px',
                  border: '1px solid rgba(37,99,235,0.25)',
                }}
              >
                <Flame size={13} color="#2563EB" />
                <span
                  style={{
                    fontFamily: tokens.headingFont,
                    fontSize: '0.7rem',
                    color: '#2563EB',
                    fontWeight: 600,
                  }}
                >
                  {t('foodie.trendingNow')}
                </span>
              </div>
            </div>

            <h1
              className="mb-3 sm:mb-5"
              style={{
                fontFamily: tokens.headingFont,
                fontSize: 'clamp(2rem, 6vw, 4.5rem)',
                lineHeight: 0.95,
                color: tokens.textPrimary,
                fontWeight: 800,
                letterSpacing: '-0.03em',
              }}
            >
              {t('foodie.heroHeadline')}
              <br />
              <span style={{ color: '#2563EB' }}>{t('foodie.heroAccent')}</span>
            </h1>

            <p
              className="mb-5 sm:mb-8 max-w-md hidden sm:block line-clamp-3"
              style={{
                fontFamily: tokens.bodyFont,
                fontSize: '1rem',
                lineHeight: 1.6,
                color: tokens.textSecondary,
              }}
            >
              {getBilingualField(heroEvent, 'description', lang)}
            </p>

            <div className="flex flex-wrap items-center gap-2 sm:gap-3 mb-5 sm:mb-8">
              <span
                className="flex items-center gap-1.5 px-3 py-1.5"
                style={{
                  backgroundColor: tokens.cardBg,
                  borderRadius: '20px',
                  fontSize: '0.8rem',
                  color: tokens.textSecondary,
                }}
              >
                <MapPin size={13} /> {getBilingualField(heroEvent, 'venueName', lang)}
              </span>
              <span
                className="flex items-center gap-1.5 px-3 py-1.5"
                style={{
                  backgroundColor: tokens.cardBg,
                  borderRadius: '20px',
                  fontSize: '0.8rem',
                  color: tokens.textSecondary,
                }}
              >
                <Clock size={13} /> {heroEvent.time}
              </span>
              <span
                className="px-3 py-1.5"
                style={{
                  backgroundColor: 'rgba(37,99,235,0.15)',
                  borderRadius: '20px',
                  fontSize: '0.8rem',
                  color: '#2563EB',
                  fontWeight: 600,
                }}
              >
                {heroEvent.price}
              </span>
            </div>

            <div className="flex gap-2 sm:gap-3">
              <Link
                to={getEventLink(heroEvent)}
                className="flex items-center gap-2 px-5 py-3 sm:px-7 sm:py-3.5 text-xs sm:text-sm transition-all hover:brightness-110"
                style={{
                  backgroundColor: '#2563EB',
                  color: '#fff',
                  borderRadius: '28px',
                  fontFamily: tokens.headingFont,
                  fontWeight: 700,
                }}
              >
                {t('foodie.reserveNow')} <ArrowRight size={16} />
              </Link>
              <Link
                to="/map"
                className="flex items-center gap-2 px-5 py-3 sm:px-7 sm:py-3.5 text-xs sm:text-sm transition-all hover:bg-white/10"
                style={{
                  border: '1px solid rgba(232,240,255,0.15)',
                  color: tokens.textSecondary,
                  borderRadius: '28px',
                  fontFamily: tokens.headingFont,
                  fontWeight: 500,
                }}
              >
                {t('foodie.exploreMap')}
              </Link>
            </div>
          </motion.div>

          {/* Right: hero food image card */}
          <motion.div
            initial={{ opacity: 0, scale: 0.97 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
            className="hidden lg:block"
          >
            <div
              className="relative overflow-hidden aspect-[4/5]"
              style={{ borderRadius: '32px', border: '1px solid rgba(37,99,235,0.15)' }}
            >
              <ImageWithFallback
                src={heroEvent.image}
                alt={heroEvent.title}
                className="h-full w-full object-cover"
                style={{ filter: 'saturate(1.15) contrast(1.05)' }}
              />
              <div
                className="absolute inset-0"
                style={{ background: 'linear-gradient(to top, rgba(10,18,40,0.7) 0%, transparent 40%)' }}
              />
              {/* Floating rating badge */}
              <div
                className="absolute top-5 right-5 flex items-center gap-1.5 px-3 py-2"
                style={{
                  backgroundColor: 'rgba(10,18,40,0.8)',
                  backdropFilter: 'blur(12px)',
                  borderRadius: '16px',
                  border: '1px solid rgba(37,99,235,0.2)',
                }}
              >
                <Star size={14} color="#2563EB" fill="#2563EB" />
                <span style={{ fontFamily: tokens.headingFont, fontSize: '0.85rem', color: tokens.textPrimary, fontWeight: 700 }}>
                  4.8
                </span>
              </div>
              {/* Bottom info */}
              <div className="absolute bottom-5 left-5 right-5">
                <h3
                  style={{
                    fontFamily: tokens.headingFont,
                    fontSize: '1.4rem',
                    color: '#fff',
                    fontWeight: 700,
                    marginBottom: '4px',
                  }}
                >
                  {getBilingualField(heroEvent, 'title', lang)}
                </h3>
                <span style={{ fontSize: '0.8rem', color: 'rgba(232,240,255,0.6)' }}>
                  {getBilingualField(heroEvent, 'venueName', lang)} · {getBilingualField(heroEvent, 'district', lang)}
                </span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

    </section>
  );
}

function FoodieCategories() {
  const tokens = getDesignTokens('foodie');
  const { t } = useTranslation();
  const categories = [
    { icon: 'noodles', label: 'Noodles', count: 12 },
    { icon: 'sushi', label: 'Sushi', count: 8 },
    { icon: 'hotpot', label: 'Hot Pot', count: 15 },
    { icon: 'tea', label: 'Tea', count: 22 },
    { icon: 'cocktails', label: 'Cocktails', count: 10 },
    { icon: 'bakery', label: 'Bakery', count: 6 },
  ];

  return (
    <section className="px-4 sm:px-6 lg:px-12 py-6 sm:py-16 max-w-[1440px] mx-auto">
      <div className="flex items-center justify-between mb-4 sm:mb-8">
        <h2
          style={{
            fontFamily: tokens.headingFont,
            fontSize: 'clamp(1.1rem, 2.5vw, 1.8rem)',
            color: tokens.textPrimary,
            fontWeight: 700,
            letterSpacing: '-0.02em',
          }}
        >
          {t('foodie.browseBy')}
        </h2>
      </div>

      <CarouselFade fadeBg={tokens.pageBg}>
      <div className="flex sm:grid sm:grid-cols-6 gap-3 overflow-x-auto sm:overflow-visible pb-2 sm:pb-0 -mx-4 px-4 sm:mx-0 sm:px-0 scrollbar-hide snap-x snap-mandatory sm:snap-none">
        {categories.map((cat, i) => (
          <motion.div
            key={cat.label}
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.06 }}
            whileHover={{ scale: 1.05 }}
            className="cursor-pointer flex flex-col items-center gap-1.5 sm:gap-2 py-3 sm:py-5 px-4 sm:px-3 transition-all flex-shrink-0 min-w-[80px] sm:min-w-0 snap-start"
            style={{
              backgroundColor: tokens.cardBg,
              borderRadius: '24px',
              border: `1px solid ${tokens.cardBorder}`,
            }}
          >
            <CIcon id={cat.icon} size={28} style={{ color: '#2563EB' }} />
            <span style={{ fontFamily: tokens.headingFont, fontSize: '0.8rem', color: tokens.textPrimary, fontWeight: 600 }}>
              {cat.label}
            </span>
            <span style={{ fontSize: '0.65rem', color: tokens.textMuted }}>
              {cat.count} spots
            </span>
          </motion.div>
        ))}
      </div>
      </CarouselFade>
    </section>
  );
}

function FoodiePopularVenues() {
  const { venues } = useData();
  const { i18n, t } = useTranslation();
  const lang = i18n.language;
  const tokens = getDesignTokens('foodie');
  const foodieVenues = venues
    .filter((v) => (v.modeScores?.foodie || 0) > 0.5)
    .sort((a, b) => (b.modeScores?.foodie || 0) - (a.modeScores?.foodie || 0));

  return (
    <section className="px-4 sm:px-6 lg:px-12 py-6 sm:py-16 max-w-[1440px] mx-auto">
      <div className="flex items-center justify-between mb-4 sm:mb-8">
        <div>
          <div className="flex items-center gap-2 mb-1 sm:mb-2">
            <Flame size={18} color="#2563EB" />
            <span
              style={{
                fontFamily: tokens.headingFont,
                fontSize: '0.7rem',
                color: '#2563EB',
                fontWeight: 600,
                letterSpacing: '0.05em',
              }}
            >
              {t('foodie.hotRightNow')}
            </span>
          </div>
          <h2
            style={{
              fontFamily: tokens.headingFont,
              fontSize: 'clamp(1.1rem, 2.5vw, 1.8rem)',
              color: tokens.textPrimary,
              fontWeight: 700,
              letterSpacing: '-0.02em',
            }}
          >
            {t('foodie.popularSpots')}
          </h2>
        </div>
        <Link
          to="/map"
          className="flex items-center gap-2 px-4 py-2 sm:px-5 sm:py-2.5 text-xs sm:text-sm transition-all hover:brightness-110"
          style={{
            backgroundColor: 'rgba(37,99,235,0.12)',
            color: '#2563EB',
            borderRadius: '24px',
            fontFamily: tokens.headingFont,
            fontWeight: 600,
          }}
        >
          {t('modeHome.viewAll')} <ArrowRight size={14} />
        </Link>
      </div>

      {/* Large card + smaller grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Large featured card */}
        {foodieVenues[0] && (
          <motion.div
            className="lg:col-span-7"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <Link to={`/venue/${foodieVenues[0].id}`} className="group block">
              <div
                className="relative overflow-hidden aspect-[4/3]"
                style={{ borderRadius: '24px' }}
              >
                <ImageWithFallback
                  src={foodieVenues[0].image}
                  alt={foodieVenues[0].name}
                  className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                  style={{ filter: 'saturate(1.1)' }}
                />
                <div
                  className="absolute inset-0"
                  style={{ background: 'linear-gradient(to top, rgba(10,18,40,0.85) 0%, transparent 50%)' }}
                />
                {/* Rating */}
                <div
                  className="absolute top-4 left-4 flex items-center gap-1.5 px-3 py-1.5"
                  style={{
                    backgroundColor: 'rgba(10,18,40,0.7)',
                    backdropFilter: 'blur(12px)',
                    borderRadius: '20px',
                  }}
                >
                  <Star size={12} color="#2563EB" fill="#2563EB" />
                  <span style={{ fontFamily: tokens.headingFont, fontSize: '0.75rem', color: tokens.textPrimary, fontWeight: 600 }}>
                    {Math.round((foodieVenues[0].modeScores?.foodie || 0) * 50 + 1) / 10}
                  </span>
                </div>
                {/* Price */}
                <div
                  className="absolute top-4 right-4 px-3 py-1.5"
                  style={{
                    backgroundColor: '#2563EB',
                    borderRadius: '20px',
                    fontSize: '0.7rem',
                    color: '#fff',
                    fontWeight: 700,
                    fontFamily: tokens.headingFont,
                  }}
                >
                  {'$'.repeat(foodieVenues[0].priceRange)}
                </div>
                {/* Bottom */}
                <div className="absolute bottom-5 left-5 right-5">
                  <div className="flex flex-wrap gap-2 mb-3">
                    {(foodieVenues[0].vibeTags || []).map((tag) => (
                      <span
                        key={tag}
                        className="px-2.5 py-1"
                        style={{
                          backgroundColor: 'rgba(232,240,255,0.1)',
                          borderRadius: '16px',
                          fontSize: '0.65rem',
                          color: 'rgba(232,240,255,0.7)',
                          backdropFilter: 'blur(8px)',
                        }}
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                  <h3
                    style={{
                      fontFamily: tokens.headingFont,
                      fontSize: '1.6rem',
                      color: '#fff',
                      fontWeight: 700,
                      letterSpacing: '-0.02em',
                    }}
                  >
                    {getBilingualField(foodieVenues[0] as any, 'name', lang)}
                  </h3>
                  <span style={{ fontSize: '0.8rem', color: 'rgba(232,240,255,0.5)' }}>
                    {foodieVenues[0].nameZh} · {getBilingualField(foodieVenues[0] as any, 'district', lang)}
                  </span>
                </div>
              </div>
            </Link>
          </motion.div>
        )}

        {/* Right column: stacked cards — horizontal scroll on mobile */}
        <CarouselFade fadeBg={tokens.pageBg}>
        <div className="lg:col-span-5 flex sm:grid sm:grid-cols-2 lg:grid-cols-1 gap-3 sm:gap-4 overflow-x-auto sm:overflow-visible pb-2 sm:pb-0 -mx-4 px-4 sm:mx-0 sm:px-0 scrollbar-hide snap-x snap-mandatory sm:snap-none">
          {foodieVenues.slice(1, 4).map((venue, i) => (
            <motion.div
              key={venue.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
            >
              <Link to={`/venue/${venue.id}`} className="group flex gap-3 sm:gap-4 p-3 transition-all hover:bg-white/[0.03] flex-shrink-0 w-[260px] sm:w-auto snap-start" style={{ borderRadius: '20px', border: `1px solid ${tokens.cardBorder}` }}>
                <div
                  className="w-24 h-24 flex-shrink-0 overflow-hidden"
                  style={{ borderRadius: '16px' }}
                >
                  <ImageWithFallback
                    src={venue.image}
                    alt={venue.name}
                    className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                </div>
                <div className="flex-1 flex flex-col justify-center min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <CIcon id={venue.category} size={14} mode="auto" />
                    <span style={{ fontSize: '0.65rem', color: tokens.textMuted }}>{getBilingualField(venue, 'district', lang)}</span>
                  </div>
                  <h4
                    className="truncate"
                    style={{
                      fontFamily: tokens.headingFont,
                      fontSize: '1rem',
                      color: tokens.textPrimary,
                      fontWeight: 700,
                    }}
                  >
                    {getBilingualField(venue, 'name', lang)}
                  </h4>
                  <div className="flex items-center gap-2 mt-1">
                    <div className="flex items-center gap-1">
                      <Star size={11} color="#2563EB" fill="#2563EB" />
                      <span style={{ fontSize: '0.7rem', color: tokens.textSecondary, fontWeight: 600 }}>
                        {((venue.modeScores?.foodie || 0) * 5).toFixed(1)}
                      </span>
                    </div>
                    <span style={{ fontSize: '0.7rem', color: tokens.textMuted }}>·</span>
                    <span style={{ fontSize: '0.7rem', color: '#2563EB', fontWeight: 600 }}>
                      {'$'.repeat(venue.priceRange)}
                    </span>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
        </CarouselFade>
      </div>
    </section>
  );
}

function FoodieUpcomingEvents() {
  const { events } = useData();
  const { i18n, t } = useTranslation();
  const lang = i18n.language;
  const isZh = lang === 'zh-Hant' || lang.startsWith('zh');
  const tokens = getDesignTokens('foodie');
  const foodieEvents = events.filter((e) => e.modeTags.includes('foodie'));
  const PAGE_SIZE = 12;
  const [page, setPage] = useState(0);
  const totalPages = Math.ceil(foodieEvents.length / PAGE_SIZE);
  const pagedEvents = foodieEvents.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);

  return (
    <section className="px-4 sm:px-6 lg:px-12 py-6 sm:py-16 max-w-[1440px] mx-auto">
      <div className="flex items-center justify-between mb-4 sm:mb-8">
        <h2
          style={{
            fontFamily: tokens.headingFont,
            fontSize: 'clamp(1.1rem, 2.5vw, 1.8rem)',
            color: tokens.textPrimary,
            fontWeight: 700,
            letterSpacing: '-0.02em',
          }}
        >
          {t('foodie.foodDrinkEvents')}
        </h2>
        <Link
          to="/events"
          className="flex items-center gap-2 text-xs sm:text-sm transition-all hover:brightness-110"
          style={{
            color: '#2563EB',
            fontFamily: tokens.headingFont,
            fontWeight: 600,
          }}
        >
          {t('modeHome.seeAll')} <ArrowRight size={14} />
        </Link>
      </div>

      <CarouselFade fadeBg={tokens.pageBg}>
      <div className="flex sm:grid sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5 overflow-x-auto sm:overflow-visible pb-2 sm:pb-0 -mx-4 px-4 sm:mx-0 sm:px-0 scrollbar-hide snap-x snap-mandatory sm:snap-none">
        {pagedEvents.map((event, i) => (
          <motion.div
            key={event.id}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.08 }}
            className="flex-shrink-0 w-[260px] sm:w-auto snap-start"
          >
            <Link to={getEventLink(event)} className="group block h-full">
              <div className="flex flex-col h-full">
              <div
                className="relative overflow-hidden aspect-[4/3]"
                style={{ borderRadius: '20px' }}
              >
                <ImageWithFallback
                  src={event.image}
                  alt={event.title}
                  className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                  style={{ filter: 'saturate(1.1)' }}
                />
                <div
                  className="absolute inset-0"
                  style={{ background: 'linear-gradient(to top, rgba(10,18,40,0.75) 0%, transparent 50%)' }}
                />
                {/* Date badge */}
                <div
                  className="absolute top-4 left-4 flex flex-col items-center px-3 py-2"
                  style={{
                    backgroundColor: 'rgba(10,18,40,0.75)',
                    backdropFilter: 'blur(12px)',
                    borderRadius: '14px',
                    minWidth: '52px',
                  }}
                >
                  <span style={{ fontFamily: tokens.headingFont, fontSize: '1.1rem', color: '#2563EB', fontWeight: 800 }}>
                    {(parseEventDate(event.date) || new Date()).getDate()}
                  </span>
                  <span style={{ fontSize: '0.55rem', color: tokens.textMuted, fontWeight: 500 }}>
                    {(parseEventDate(event.date) || new Date()).toLocaleDateString('en', { month: 'short' }).toUpperCase()}
                  </span>
                </div>
                {/* Price */}
                <div
                  className="absolute top-4 right-4 px-3 py-1.5"
                  style={{
                    backgroundColor: '#2563EB',
                    borderRadius: '20px',
                    fontSize: '0.7rem',
                    color: '#fff',
                    fontWeight: 700,
                    fontFamily: tokens.headingFont,
                  }}
                >
                  {event.price}
                </div>
                {/* Bottom */}
                <div className="absolute bottom-4 left-4 right-4">
                  <span style={{ fontSize: '0.65rem', color: 'rgba(232,240,255,0.5)' }}>
                    {event.category}
                  </span>
                </div>
              </div>

              <div className="pt-3 sm:pt-4 flex flex-col flex-1">
              <h3
                className="mb-1 group-hover:opacity-80 transition-opacity"
                style={{
                  fontFamily: tokens.headingFont,
                  fontSize: '1.05rem',
                  color: tokens.textPrimary,
                  fontWeight: 700,
                  letterSpacing: '-0.01em',
                  display: '-webkit-box',
                  WebkitLineClamp: 2,
                  WebkitBoxOrient: 'vertical' as const,
                  overflow: 'hidden',
                  lineHeight: 1.4,
                }}
              >
                {getBilingualField(event, 'title', lang)}
              </h3>
              <div className="flex items-center gap-2 mt-auto">
                <span className="truncate" style={{ fontSize: '0.75rem', color: tokens.textMuted }}>
                  {getBilingualField(event, 'venueName', lang)}
                </span>
                {event.time && (
                  <>
                    <span style={{ fontSize: '0.6rem', color: tokens.textMuted }}>·</span>
                    <span className="flex-shrink-0" style={{ fontSize: '0.75rem', color: tokens.textMuted }}>
                      {event.time}
                    </span>
                  </>
                )}
              </div>
              </div>
              </div>
            </Link>
          </motion.div>
        ))}
      </div>
      </CarouselFade>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-4 mt-6 sm:mt-8">
          <button
            onClick={() => setPage(p => Math.max(0, p - 1))}
            disabled={page === 0}
            className="flex items-center gap-1.5 px-4 py-2 text-xs transition-all hover:brightness-110 disabled:opacity-30 disabled:cursor-default cursor-pointer"
            style={{
              border: '1px solid rgba(37,99,235,0.2)',
              borderRadius: '20px',
              fontFamily: tokens.headingFont,
              fontWeight: 600,
              color: '#2563EB',
              background: 'transparent',
            }}
          >
            <ChevronLeft size={14} /> {isZh ? '上一頁' : 'Prev'}
          </button>
          <span style={{ fontSize: '0.8rem', color: tokens.textMuted, fontWeight: 600, fontFamily: tokens.headingFont }}>
            {page + 1} / {totalPages}
          </span>
          <button
            onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))}
            disabled={page >= totalPages - 1}
            className="flex items-center gap-1.5 px-4 py-2 text-xs transition-all hover:brightness-110 disabled:opacity-30 disabled:cursor-default cursor-pointer"
            style={{
              backgroundColor: '#2563EB',
              color: '#fff',
              borderRadius: '20px',
              fontFamily: tokens.headingFont,
              fontWeight: 600,
              border: 'none',
            }}
          >
            {isZh ? '下一頁' : 'Next'} <ChevronRight size={14} />
          </button>
        </div>
      )}
    </section>
  );
}

function FoodieMapCTA() {
  const tokens = getDesignTokens('foodie');
  const { t } = useTranslation();

  return (
    <section className="px-4 sm:px-6 lg:px-12 py-6 sm:py-16 max-w-[1440px] mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="relative overflow-hidden p-5 sm:p-12 lg:p-16"
        style={{
          borderRadius: '24px',
          background: 'linear-gradient(135deg, #0E1A2E, #0A1220)',
          border: '1px solid rgba(37,99,235,0.15)',
        }}
      >
        {/* Big emoji background */}
        <div className="absolute right-4 sm:right-12 top-1/2 -translate-y-1/2 opacity-10">
          <span style={{ fontSize: 'clamp(6rem, 15vw, 12rem)', opacity: 0.08, fontFamily: tokens.headingFont, fontWeight: 800, color: '#2563EB' }}>FOOD</span>
        </div>

        <div className="relative z-10 max-w-lg">
          <div className="flex items-center gap-2 mb-4">
            <UtensilsCrossed size={16} color="#2563EB" />
            <span
              style={{
                fontFamily: tokens.headingFont,
                fontSize: '0.7rem',
                color: '#2563EB',
                fontWeight: 600,
              }}
            >
              {t('foodie.foodMap')}
            </span>
          </div>
          <h2
            className="mb-4"
            style={{
              fontFamily: tokens.headingFont,
              fontSize: 'clamp(1.5rem, 3vw, 2.5rem)',
              color: tokens.textPrimary,
              fontWeight: 800,
              letterSpacing: '-0.03em',
              lineHeight: 1.1,
            }}
          >
            {t('foodie.findNextBite')}
            <br />
            <span style={{ color: '#2563EB' }}>{t('foodie.favoriteBite')}</span>
          </h2>
          <p
            className="mb-5 sm:mb-8 hidden sm:block"
            style={{
              fontFamily: tokens.bodyFont,
              fontSize: '0.95rem',
              color: tokens.textSecondary,
              lineHeight: 1.6,
            }}
          >
            {t('foodie.mapCTABody')}
          </p>
          <Link
            to="/map"
            className="inline-flex items-center gap-2 px-5 py-3 sm:px-7 sm:py-3.5 text-xs sm:text-sm transition-all hover:brightness-110"
            style={{
              backgroundColor: '#2563EB',
              color: '#fff',
              borderRadius: '28px',
              fontFamily: tokens.headingFont,
              fontWeight: 700,
            }}
          >
            <Map size={16} /> {t('foodie.openFoodMap')}
          </Link>
        </div>
      </motion.div>
    </section>
  );
}

function FoodieFooter() {
  const tokens = getDesignTokens('foodie');
  const { t, i18n } = useTranslation();

  const footerLinks: [string, string][] = [
    [t('nav.map'), '/map'],
    [t('nav.events'), '/events'],
    [t('nav.recaps'), '/recaps'],
    [t('nav.contribute'), '/contribute'],
    [t('nav.about'), '/about'],
  ];

  return (
    <footer
      className="px-4 sm:px-6 lg:px-12 py-8 sm:py-14"
      style={{ borderTop: `1px solid ${tokens.cardBorder}` }}
    >
      <div className="max-w-[1440px] mx-auto">
        <div className="flex flex-col gap-6 sm:grid sm:grid-cols-2 lg:grid-cols-4 sm:gap-8">
          <div>
            <div className="flex items-center gap-2.5 mb-2 sm:mb-3">
              <div
                className="flex h-8 w-8 items-center justify-center"
                style={{ backgroundColor: '#2563EB', borderRadius: '10px' }}
              >
                <UtensilsCrossed size={14} color="#fff" />
              </div>
              <span style={{ fontFamily: tokens.headingFont, fontSize: '0.9rem', color: tokens.textPrimary, fontWeight: 700 }}>
                CULTIVE
              </span>
            </div>
            <p className="hidden sm:block" style={{ fontSize: '0.8rem', color: tokens.textMuted, maxWidth: '220px', lineHeight: 1.6 }}>
              {t('footer.taglineFoodie')}
            </p>
          </div>
          <div>
            <h4
              className="mb-2 sm:mb-3"
              style={{ fontFamily: tokens.headingFont, fontSize: '0.75rem', color: tokens.textMuted, fontWeight: 600 }}
            >
              {t('footer.explore')}
            </h4>
            <div className="space-y-1.5 sm:space-y-2">
              {footerLinks.map(([label, path]) => (
                <Link key={path} to={path} className="block text-xs sm:text-sm transition-colors hover:opacity-70" style={{ color: tokens.textSecondary }}>
                  {label}
                </Link>
              ))}
            </div>
          </div>
          <div>
            <h4
              className="mb-2 sm:mb-3"
              style={{ fontFamily: tokens.headingFont, fontSize: '0.75rem', color: tokens.textMuted, fontWeight: 600 }}
            >
              {t('foodie.cuisines')}
            </h4>
            <div className="space-y-1.5 sm:space-y-2">
              {['Japanese', 'Chinese', 'Street Food', 'Cocktails'].map((item) => (
                <span key={item} className="block text-xs sm:text-sm" style={{ color: tokens.textSecondary }}>{item}</span>
              ))}
            </div>
          </div>
          <div className="hidden lg:block">
            <h4
              className="mb-2 sm:mb-3"
              style={{ fontFamily: tokens.headingFont, fontSize: '0.75rem', color: tokens.textMuted, fontWeight: 600 }}
            >
              {t('footer.connect')}
            </h4>
            <div className="space-y-1.5 sm:space-y-2">
              {['Instagram', 'TikTok', 'info@cultive.city'].map((item) => (
                <span key={item} className="block text-xs sm:text-sm" style={{ color: tokens.textSecondary }}>{item}</span>
              ))}
              <Link to="/contribute" className="inline-flex items-center gap-1.5 mt-2 text-xs sm:text-sm transition-opacity hover:opacity-70" style={{ color: '#2563EB', fontWeight: 600, fontFamily: tokens.headingFont }}>
                {t('common.submitEvent')}
              </Link>
            </div>
          </div>
        </div>
        <div
          className="mt-6 sm:mt-10 pt-4 sm:pt-6 flex flex-wrap items-center justify-between gap-2 sm:gap-4"
          style={{ borderTop: `1px solid ${tokens.cardBorder}` }}
        >
          <span style={{ fontSize: '0.7rem', color: tokens.textMuted }}>{t('common.copyright')}</span>
          <div className="flex items-center gap-3 sm:gap-4">
            <Link to="/privacy" className="transition-opacity hover:opacity-70" style={{ fontSize: '0.7rem', color: tokens.textMuted }}>{t('footer.privacy')}</Link>
            <Link to="/terms" className="transition-opacity hover:opacity-70" style={{ fontSize: '0.7rem', color: tokens.textMuted }}>{t('footer.terms')}</Link>
            <span style={{ fontSize: '0.7rem', color: tokens.textMuted }}>{t('common.madeInHK')}</span>
          </div>
        </div>
      </div>
    </footer>
  );
}

export function FoodieHomePage() {
  return (
    <div>
      <FoodieHero />
      <FoodieCategories />
      <ThingsToDo />
      <FoodiePopularVenues />
      <FoodieUpcomingEvents />
      <FoodieMapCTA />
      <FoodieFooter />
    </div>
  );
}