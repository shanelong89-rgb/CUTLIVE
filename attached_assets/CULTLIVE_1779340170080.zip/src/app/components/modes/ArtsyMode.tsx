import { Link } from 'react-router';
import { useTranslation } from 'react-i18next';
import { motion } from 'motion/react';
import { ArrowRight } from 'lucide-react';
import { useData } from '../../context/DataContext';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { getDesignTokens } from '../../data/mode-styles';
import { ThingsToDo } from '../ThingsToDo';
import { CarouselFade } from '../CarouselFade';
import { getEventLink } from '../../utils/event-helpers';
import { getBilingualField } from '../../utils/bilingual';
import { useSiteImages } from '../../hooks/useSiteImages';

// ═══════════════════════════════════════════════════════════════════
// ART & DESIGN MODE: Editorial Minimalist Layout
// ═══════════════════════════════════════════════════════════════════

function ArtsyHero() {
  const { events } = useData();
  const { t, i18n } = useTranslation();
  const lang = i18n.language;
  const tokens = getDesignTokens('artsy');
  const featured = events.filter((e) => e.modeTags.includes('artsy'));
  const heroEvent = featured[0] || events[0];

  return (
    <section className="min-h-[60vh] sm:min-h-[90vh] flex flex-col justify-end relative" data-nav-theme="dark">
      <div className="absolute inset-0 pointer-events-none z-10 hidden lg:block">
        <div className="h-full w-full grid grid-cols-3 grid-rows-3">
          {Array.from({ length: 9 }).map((_, i) => (
            <div key={i} className="border-r border-b" style={{ borderColor: 'rgba(0,0,0,0.03)' }} />
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 min-h-[60vh] sm:min-h-[90vh]">
        <div className="lg:col-span-4 flex flex-col justify-end px-5 sm:px-8 lg:px-12 pb-8 sm:pb-16 lg:pb-24 pt-24 sm:pt-32 lg:pt-0 order-2 lg:order-1">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
          >
            <span
              className="block mb-3 sm:mb-6 tracking-[0.3em] uppercase"
              style={{ fontFamily: tokens.bodyFont, fontSize: '0.65rem', color: tokens.textMuted, letterSpacing: '0.35em' }}
            >
              Editor's Selection
            </span>
            <h1
              className="mb-3 sm:mb-6"
              style={{
                fontFamily: tokens.headingFont,
                fontSize: 'clamp(1.6rem, 4vw, 3.5rem)',
                lineHeight: 1.08,
                color: tokens.textPrimary,
                fontWeight: 400,
              }}
            >
              {getBilingualField(heroEvent, 'title', lang)}
            </h1>
            <div className="w-12 h-px mb-4 sm:mb-6" style={{ backgroundColor: tokens.textMuted }} />
            <p className="mb-5 sm:mb-8 max-w-sm hidden sm:block line-clamp-3" style={{ fontFamily: tokens.bodyFont, fontSize: '0.95rem', lineHeight: 1.8, color: tokens.textSecondary }}>
              {getBilingualField(heroEvent, 'description', lang)}
            </p>
            <div className="space-y-2 mb-6 sm:mb-10">
              <div className="flex items-center gap-3">
                <span style={{ fontSize: '0.75rem', color: tokens.textMuted, fontFamily: tokens.bodyFont }}>{getBilingualField(heroEvent, 'venueName', lang)}</span>
                <span style={{ color: tokens.textMuted, fontSize: '0.5rem' }}>&#9679;</span>
                <span style={{ fontSize: '0.75rem', color: tokens.textMuted, fontFamily: tokens.bodyFont }}>{getBilingualField(heroEvent, 'district', lang)}</span>
              </div>
              <span style={{ fontSize: '0.75rem', color: tokens.textMuted, fontFamily: tokens.bodyFont }}>{heroEvent.date}</span>
            </div>
            <Link
              to={getEventLink(heroEvent)}
              className="inline-flex items-center gap-3 group"
              style={{ fontFamily: tokens.headingFont, fontSize: '0.8rem', color: tokens.textPrimary, letterSpacing: '0.15em' }}
            >
              <span className="uppercase">{t('nav.discover')}</span>
              <ArrowRight size={14} className="transition-transform group-hover:translate-x-1" />
            </Link>
          </motion.div>
        </div>
        <div className="lg:col-span-8 relative order-1 lg:order-2 min-h-[35vh] sm:min-h-[50vh] lg:min-h-0">
          <motion.div
            initial={{ opacity: 0, scale: 1.01 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
            className="absolute inset-0"
          >
            <ImageWithFallback src={heroEvent.image} alt={heroEvent.title} className="h-full w-full object-cover" />
            <div className="absolute inset-0" style={{ background: 'linear-gradient(to right, rgba(245,241,235,0.3), transparent 30%)' }} />
          </motion.div>
          <div className="absolute bottom-8 right-8 z-10">
            <span style={{ fontFamily: tokens.headingFont, fontSize: '4rem', color: 'rgba(255,255,255,0.15)', fontWeight: 400, fontStyle: 'italic' }}>01</span>
          </div>
        </div>
      </div>
    </section>
  );
}

function ArtsyEditorialGrid() {
  const { events } = useData();
  const { t, i18n } = useTranslation();
  const lang = i18n.language;
  const tokens = getDesignTokens('artsy');
  const artsyEvents = events.filter((e) => e.modeTags.includes('artsy'));

  return (
    <section className="px-4 sm:px-8 lg:px-12 py-8 sm:py-20 lg:py-32 max-w-[1440px] mx-auto">
      <div className="flex items-end justify-between mb-6 sm:mb-16 lg:mb-24">
        <div>
          <span className="block mb-3 tracking-[0.3em] uppercase" style={{ fontSize: '0.6rem', color: tokens.textMuted, fontFamily: tokens.bodyFont }}>{t('timePeriod.artsy.today')}</span>
          <h2 style={{ fontFamily: tokens.headingFont, fontSize: 'clamp(1.5rem, 3vw, 2.8rem)', color: tokens.textPrimary, fontWeight: 400, lineHeight: 1.1 }}>
            Exhibitions &<br /><em style={{ fontStyle: 'italic' }}>Cultural Events</em>
          </h2>
        </div>
        <Link to="/events" className="hidden sm:flex items-center gap-2 group" style={{ fontSize: '0.7rem', color: tokens.textMuted, letterSpacing: '0.2em', fontFamily: tokens.bodyFont }}>
          <span className="uppercase">{t('modeHome.viewAll')}</span>
          <ArrowRight size={12} className="transition-transform group-hover:translate-x-1" />
        </Link>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-y-8 sm:gap-y-16 lg:gap-x-8 lg:gap-y-24">
        {artsyEvents[0] && (
          <motion.div className="lg:col-span-7" initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}>
            <Link to={getEventLink(artsyEvents[0])} className="group block">
              <div className="relative overflow-hidden aspect-[4/3] mb-4 sm:mb-6">
                <ImageWithFallback src={artsyEvents[0].image} alt={artsyEvents[0].title} className="h-full w-full object-cover transition-transform duration-1000 group-hover:scale-[1.02]" />
              </div>
              <div className="max-w-lg">
                <span className="block mb-2 tracking-[0.25em] uppercase" style={{ fontSize: '0.6rem', color: tokens.textMuted, fontFamily: tokens.bodyFont }}>{artsyEvents[0].category}</span>
                <h3 className="mb-3" style={{ fontFamily: tokens.headingFont, fontSize: 'clamp(1.2rem, 2vw, 1.8rem)', color: tokens.textPrimary, fontWeight: 400, lineHeight: 1.2 }}>{getBilingualField(artsyEvents[0], 'title', lang)}</h3>
                <p className="mb-3 hidden sm:block line-clamp-3" style={{ fontFamily: tokens.bodyFont, fontSize: '0.9rem', color: tokens.textSecondary, lineHeight: 1.7 }}>{getBilingualField(artsyEvents[0], 'description', lang)}</p>
                <div className="flex items-center gap-3">
                  <span style={{ fontSize: '0.7rem', color: tokens.textMuted }}>{getBilingualField(artsyEvents[0], 'venueName', lang)}</span>
                  <span className="w-4 h-px" style={{ backgroundColor: tokens.textMuted }} />
                  <span style={{ fontSize: '0.7rem', color: tokens.textMuted }}>{artsyEvents[0].date}</span>
                </div>
              </div>
            </Link>
          </motion.div>
        )}
        <CarouselFade fadeBg={tokens.pageBg}>
        <div className="lg:col-span-5 lg:pt-32 flex sm:block gap-4 overflow-x-auto sm:overflow-visible pb-2 sm:pb-0 -mx-4 px-4 sm:mx-0 sm:px-0 scrollbar-hide snap-x snap-mandatory sm:snap-none sm:space-y-16 lg:space-y-24">
          {artsyEvents.slice(1, 3).map((event, i) => (
            <motion.div key={event.id} initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} transition={{ duration: 0.8, delay: i * 0.15, ease: [0.22, 1, 0.36, 1] }} className="flex-shrink-0 w-[220px] sm:w-auto snap-start">
              <Link to={getEventLink(event)} className="group block">
                <div className="relative overflow-hidden aspect-[3/4] mb-3 sm:mb-5">
                  <ImageWithFallback src={event.image} alt={event.title} className="h-full w-full object-cover transition-transform duration-1000 group-hover:scale-[1.02]" />
                  {event.status === 'ongoing' && (
                    <div className="absolute top-4 left-4"><span className="px-3 py-1 text-xs tracking-[0.15em] uppercase" style={{ backgroundColor: 'rgba(255,255,255,0.9)', color: tokens.textPrimary, fontSize: '0.55rem' }}>Now Showing</span></div>
                  )}
                </div>
                <span className="block mb-2 tracking-[0.25em] uppercase" style={{ fontSize: '0.55rem', color: tokens.textMuted, fontFamily: tokens.bodyFont }}>{event.category}</span>
                <h3 className="mb-2" style={{ fontFamily: tokens.headingFont, fontSize: '1.15rem', color: tokens.textPrimary, fontWeight: 400, lineHeight: 1.25 }}>{getBilingualField(event, 'title', lang)}</h3>
                <span style={{ fontSize: '0.7rem', color: tokens.textMuted }}>{getBilingualField(event, 'venueName', lang)}, {getBilingualField(event, 'district', lang)}</span>
              </Link>
            </motion.div>
          ))}
        </div>
        </CarouselFade>
      </div>
    </section>
  );
}

function ArtsyVenueStrip() {
  const { venues } = useData();
  const { t, i18n } = useTranslation();
  const lang = i18n.language;
  const isZh = lang === 'zh-Hant' || lang.startsWith('zh');
  const tokens = getDesignTokens('artsy');
  const artsyVenues = venues.filter((v) => (v.modeScores?.artsy || 0) > 0.5).sort((a, b) => (b.modeScores?.artsy || 0) - (a.modeScores?.artsy || 0));

  return (
    <section className="py-8 sm:py-20 lg:py-32">
      <div className="px-4 sm:px-8 lg:px-12 max-w-[1440px] mx-auto mb-6 sm:mb-12">
        <div className="h-px w-full" style={{ backgroundColor: 'rgba(0,0,0,0.08)' }} />
        <div className="flex items-center justify-between mt-6">
          <h2 style={{ fontFamily: tokens.headingFont, fontSize: '1.1rem', color: tokens.textPrimary, fontWeight: 400, fontStyle: 'italic' }}>{t('artsy.curatedSpaces')}</h2>
          <Link to="/map" className="flex items-center gap-2 group" style={{ fontSize: '0.65rem', color: tokens.textMuted, letterSpacing: '0.2em' }}>
            <span className="uppercase">{t('modeHome.mapView')}</span>
            <ArrowRight size={10} className="transition-transform group-hover:translate-x-1" />
          </Link>
        </div>
      </div>
      <CarouselFade fadeBg={tokens.pageBg}>
      <div className="overflow-x-auto scrollbar-hide snap-x snap-mandatory">
        <div className="flex gap-1 px-4 sm:px-8 lg:px-12" style={{ minWidth: 'max-content' }}>
          {artsyVenues.map((venue, i) => (
            <motion.div key={venue.id} initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} transition={{ duration: 0.6, delay: i * 0.1 }} className="w-[180px] sm:w-[280px] snap-start">
              <Link to={`/venue/${venue.id}`} className="group block">
                <div className="relative overflow-hidden aspect-[3/4] mb-4">
                  <ImageWithFallback src={venue.image} alt={venue.name} className="h-full w-full object-cover transition-transform duration-1000 group-hover:scale-[1.03]" style={{ filter: 'grayscale(20%) contrast(1.05)' }} />
                </div>
                <h4 style={{ fontFamily: tokens.headingFont, fontSize: '0.95rem', color: tokens.textPrimary, fontWeight: 400 }}>{getBilingualField(venue, 'name', lang)}</h4>
                <div className="flex items-center gap-2 mt-1">
                  <span style={{ fontSize: '0.7rem', color: tokens.textMuted, fontFamily: tokens.bodyFont }}>{isZh ? venue.name : venue.nameZh}</span>
                  <span className="w-3 h-px" style={{ backgroundColor: tokens.textMuted }} />
                  <span style={{ fontSize: '0.7rem', color: tokens.textMuted, fontFamily: tokens.bodyFont }}>{getBilingualField(venue, 'district', lang)}</span>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
      </CarouselFade>
    </section>
  );
}

function ArtsyMapCTA() {
  const tokens = getDesignTokens('artsy');
  const { t } = useTranslation();
  const { img: siteImg } = useSiteImages();
  return (
    <section className="px-4 sm:px-8 lg:px-12 py-8 sm:py-20 lg:py-32 max-w-[1440px] mx-auto">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-8 items-center">
        <div className="lg:col-span-5">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.8 }}>
            <span className="block mb-3 sm:mb-4 tracking-[0.3em] uppercase" style={{ fontSize: '0.6rem', color: tokens.textMuted, fontFamily: tokens.bodyFont }}>{t('modeHome.exploreMap')}</span>
            <h2 className="mb-4 sm:mb-6" style={{ fontFamily: tokens.headingFont, fontSize: 'clamp(1.3rem, 3vw, 2.5rem)', color: tokens.textPrimary, fontWeight: 400, lineHeight: 1.15 }}>
              {t('artsy.mapCTATitle')}
            </h2>
            <div className="w-8 h-px mb-4 sm:mb-6" style={{ backgroundColor: tokens.textMuted }} />
            <p className="mb-5 sm:mb-8 hidden sm:block" style={{ fontFamily: tokens.bodyFont, fontSize: '0.9rem', color: tokens.textSecondary, lineHeight: 1.8, maxWidth: '360px' }}>
              {t('artsy.mapCTABody')}
            </p>
            <Link to="/map" className="inline-flex items-center gap-3 py-3 group" style={{ fontFamily: tokens.headingFont, fontSize: '0.75rem', color: tokens.textPrimary, letterSpacing: '0.15em', borderBottom: `1px solid ${tokens.textPrimary}` }}>
              <span className="uppercase">{t('artsy.openMapBtn')}</span>
              <ArrowRight size={14} className="transition-transform group-hover:translate-x-1" />
            </Link>
          </motion.div>
        </div>
        <div className="lg:col-span-7">
          <motion.div initial={{ opacity: 0, scale: 0.98 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ duration: 1 }} className="aspect-[16/10] overflow-hidden">
            <ImageWithFallback src={siteImg('mode-hero-art') || "https://images.unsplash.com/photo-1643622288042-ecedf3e21e9f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlZGl0b3JpYWwlMjBhcmNoaXRlY3R1cmUlMjBidWlsZGluZyUyMGZhY2FkZXxlbnwxfHx8fDE3NzMwMjQwMDV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"} alt="Architectural space" className="h-full w-full object-cover" style={{ filter: 'grayscale(30%) contrast(1.1)' }} />
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function ArtsyFooter() {
  const tokens = getDesignTokens('artsy');
  const { t, i18n } = useTranslation();

  const footerLinks: [string, string][] = [
    [t('nav.discover'), '/'],
    [t('nav.map'), '/map'],
    [t('nav.events'), '/events'],
    [t('nav.recaps'), '/recaps'],
    [t('nav.contribute'), '/contribute'],
    [t('nav.about'), '/about'],
  ];

  return (
    <footer className="px-4 sm:px-8 lg:px-12 py-8 sm:py-16" style={{ borderTop: `1px solid rgba(0,0,0,0.06)` }}>
      <div className="max-w-[1440px] mx-auto">
        <div className="flex flex-col gap-6 sm:grid sm:grid-cols-2 lg:grid-cols-12 sm:gap-12">
          <div className="lg:col-span-4">
            <span className="block tracking-[0.4em] uppercase mb-2 sm:mb-3" style={{ fontFamily: tokens.headingFont, fontSize: '0.8rem', color: tokens.textPrimary }}>CULTIVE</span>
            <span className="block mb-3 sm:mb-4" style={{ fontFamily: tokens.bodyFont, fontSize: '0.75rem', color: tokens.textMuted }}>文化活</span>
            <p className="hidden sm:block" style={{ fontFamily: tokens.bodyFont, fontSize: '0.85rem', color: tokens.textSecondary, lineHeight: 1.7, maxWidth: '280px' }}>
              {t('footer.taglineArtsy')}
            </p>
          </div>
          <div className="lg:col-span-2 lg:col-start-7">
            <span className="block mb-2 sm:mb-4 tracking-[0.2em] uppercase" style={{ fontSize: '0.6rem', color: tokens.textMuted }}>{t('footer.explore')}</span>
            <div className="space-y-1.5 sm:space-y-3">
              {footerLinks.map(([label, path]) => (
                <Link key={path} to={path} className="block transition-colors hover:opacity-70" style={{ fontFamily: tokens.bodyFont, fontSize: '0.8rem', color: tokens.textSecondary }}>{label}</Link>
              ))}
            </div>
          </div>
          <div className="hidden lg:block lg:col-span-2">
            <span className="block mb-2 sm:mb-4 tracking-[0.2em] uppercase" style={{ fontSize: '0.6rem', color: tokens.textMuted }}>{t('footer.connect')}</span>
            <div className="space-y-1.5 sm:space-y-3">
              {['Instagram', 'TikTok', 'info@cultive.city'].map((item) => (
                <span key={item} className="block" style={{ fontFamily: tokens.bodyFont, fontSize: '0.8rem', color: tokens.textSecondary }}>{item}</span>
              ))}
              <Link to="/contribute" className="inline-flex items-center gap-1.5 mt-2 transition-opacity hover:opacity-70" style={{ fontFamily: tokens.bodyFont, fontSize: '0.8rem', color: tokens.textPrimary, fontWeight: 500 }}>
                {t('common.submitEvent')}
              </Link>
            </div>
          </div>
        </div>
        <div className="mt-8 sm:mt-16 pt-4 sm:pt-6 flex items-center justify-between" style={{ borderTop: `1px solid rgba(0,0,0,0.06)` }}>
          <span style={{ fontSize: '0.65rem', color: tokens.textMuted }}>{t('common.copyright')}</span>
          <div className="flex items-center gap-3 sm:gap-4">
            <Link to="/privacy" className="transition-opacity hover:opacity-70" style={{ fontSize: '0.65rem', color: tokens.textMuted }}>{t('footer.privacy')}</Link>
            <Link to="/terms" className="transition-opacity hover:opacity-70" style={{ fontSize: '0.65rem', color: tokens.textMuted }}>{t('footer.terms')}</Link>
            <span style={{ fontFamily: tokens.headingFont, fontSize: '0.65rem', color: tokens.textMuted, fontStyle: 'italic' }}>{t('common.madeInHK')}</span>
          </div>
        </div>
      </div>
    </footer>
  );
}

export function ArtsyHomePage() {
  return (
    <div>
      <ArtsyHero />
      <ArtsyEditorialGrid />
      <ThingsToDo />
      <ArtsyVenueStrip />
      <ArtsyMapCTA />
      <ArtsyFooter />
      <style>{`.scrollbar-hide::-webkit-scrollbar{display:none}.scrollbar-hide{-ms-overflow-style:none;scrollbar-width:none}`}</style>
    </div>
  );
}