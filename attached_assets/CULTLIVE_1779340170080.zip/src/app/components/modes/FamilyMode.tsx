import { useState } from 'react';
import { Link } from 'react-router';
import { useTranslation } from 'react-i18next';
import { motion } from 'motion/react';
import { ArrowRight, MapPin, Clock, Heart, Map, ChevronLeft, ChevronRight } from 'lucide-react';
import { useData } from '../../context/DataContext';
import { ModeSelector } from '../ModeSelector';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { getDesignTokens } from '../../data/mode-styles';
import { ThingsToDo } from '../ThingsToDo';
import { CIcon } from '../CIcon';
import { CarouselFade } from '../CarouselFade';
import { getEventLink } from '../../utils/event-helpers';
import { parseEventDate } from '../../utils/date-helpers';
import { getBilingualField } from '../../utils/bilingual';
import { useSiteImages } from '../../hooks/useSiteImages';

// ═══════════════════════════════════════════════════════════════════
// FAMILY MODE: Playhouse Daycare-Inspired Warm & Playful
// ═══════════════════════════════════════════════════════════════════

const FAMILY_ORANGE = '#FF8C42';
const FAMILY_CORAL = '#FF6B6B';
const FAMILY_MINT = '#43D9AD';
const FAMILY_LAVENDER = '#B8A9E8';
const FAMILY_YELLOW = '#FFD166';
const FAMILY_PEACH = '#FFB4A2';

function FamilyHero() {
  const { events } = useData();
  const { t } = useTranslation();
  const tokens = getDesignTokens('family');
  const familyEvents = events.filter((e) => e.modeTags.includes('family'));
  const heroEvent = familyEvents[0] || events[0];
  const { img: siteImg } = useSiteImages();

  return (
    <section className="relative min-h-[70vh] sm:min-h-[88vh] overflow-hidden flex items-center" style={{ backgroundColor: '#FFF8F0' }} data-nav-theme="dark">
      {/* Decorative blob shapes */}
      <div className="absolute top-[-10%] right-[-5%] w-[500px] h-[500px] rounded-full opacity-30" style={{ background: `radial-gradient(circle, ${FAMILY_PEACH}60, transparent 70%)` }} />
      <div className="absolute bottom-[-15%] left-[-8%] w-[600px] h-[600px] rounded-full opacity-25" style={{ background: `radial-gradient(circle, ${FAMILY_MINT}40, transparent 70%)` }} />
      <div className="absolute top-[30%] left-[40%] w-[300px] h-[300px] rounded-full opacity-20" style={{ background: `radial-gradient(circle, ${FAMILY_LAVENDER}40, transparent 70%)` }} />
      <div className="absolute bottom-[20%] right-[20%] w-[200px] h-[200px] rounded-full opacity-25" style={{ background: `radial-gradient(circle, ${FAMILY_YELLOW}50, transparent 70%)` }} />

      {/* Mode selector — hidden on mobile (available in nav menu) */}
      <div className="absolute top-6 right-4 sm:right-8 z-10 hidden md:block">
        <ModeSelector />
      </div>

      {/* Content */}
      <div className="relative w-full max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
          {/* Left text */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
          >
            {/* Badge */}
            <motion.div
              className="inline-flex items-center gap-2 px-4 py-2 mb-3 sm:mb-6"
              style={{
                backgroundColor: `${FAMILY_ORANGE}12`,
                borderRadius: '9999px',
                border: `1px solid ${FAMILY_ORANGE}20`,
              }}
            >
              <span style={{ fontFamily: tokens.headingFont, fontSize: '0.75rem', color: FAMILY_ORANGE, fontWeight: 700 }}>
                {t('timePeriod.family.week')}
              </span>
            </motion.div>

            <h1
              className="mb-3 sm:mb-5"
              style={{
                fontFamily: tokens.headingFont,
                fontSize: 'clamp(2rem, 6vw, 4rem)',
                lineHeight: 1.05,
                color: tokens.textPrimary,
                fontWeight: 800,
                letterSpacing: '-0.03em',
              }}
            >
              {t('family.heroHeadline')}{' '}
              <span style={{ color: FAMILY_ORANGE, position: 'relative', display: 'inline-block' }}>
                {t('family.heroAccent')}
                <svg className="absolute -bottom-1 left-0 w-full" height="8" viewBox="0 0 200 8" preserveAspectRatio="none">
                  <path d="M0,5 Q50,0 100,5 T200,5" stroke={FAMILY_ORANGE} strokeWidth="3" fill="none" strokeLinecap="round" opacity="0.4" />
                </svg>
              </span>
              <br />family
            </h1>

            <p
              className="mb-5 sm:mb-8 max-w-md hidden sm:block"
              style={{
                fontFamily: tokens.bodyFont,
                fontSize: '1.05rem',
                lineHeight: 1.7,
                color: tokens.textSecondary,
              }}
            >
              {t('family.heroBody')}
            </p>

            <div className="flex flex-wrap items-center gap-2 sm:gap-3 mb-5 sm:mb-8">
              {[
                { icon: '', label: 'Ages 0-3' },
                { icon: '', label: 'Ages 4-8' },
                { icon: '', label: 'Ages 9-12' },
                { icon: '', label: 'All Ages' },
              ].map((age) => (
                <span
                  key={age.label}
                  className="flex items-center gap-1.5 px-3 py-1.5 cursor-pointer transition-all hover:scale-105"
                  style={{
                    backgroundColor: '#fff',
                    borderRadius: '9999px',
                    fontSize: '0.8rem',
                    color: tokens.textSecondary,
                    fontFamily: tokens.bodyFont,
                    fontWeight: 600,
                    boxShadow: '0 2px 8px rgba(0,0,0,0.06)',
                    border: '1px solid rgba(0,0,0,0.04)',
                  }}
                >
                  <span>{age.icon}</span> {age.label}
                </span>
              ))}
            </div>

            <div className="flex gap-2 sm:gap-3">
              <Link
                to="/events"
                className="flex items-center gap-2 px-5 py-3 sm:px-7 sm:py-3.5 text-xs sm:text-sm transition-all hover:brightness-105 hover:scale-[1.02]"
                style={{
                  backgroundColor: FAMILY_ORANGE,
                  color: '#fff',
                  borderRadius: '9999px',
                  fontFamily: tokens.headingFont,
                  fontWeight: 700,
                  boxShadow: `0 6px 20px ${FAMILY_ORANGE}35`,
                }}
              >
                {t('modeHome.browseEvents')} <ArrowRight size={16} />
              </Link>
              <Link
                to="/map"
                className="flex items-center gap-2 px-5 py-3 sm:px-7 sm:py-3.5 text-xs sm:text-sm transition-all hover:bg-black/[0.03]"
                style={{
                  border: '1px solid rgba(0,0,0,0.1)',
                  color: tokens.textSecondary,
                  borderRadius: '9999px',
                  fontFamily: tokens.headingFont,
                  fontWeight: 600,
                }}
              >
                <Map size={16} /> {t('modeHome.exploreMapBtn')}
              </Link>
            </div>
          </motion.div>

          {/* Right: Image collage */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
            className="hidden lg:block"
          >
            <div className="relative">
              {/* Main image */}
              <div
                className="relative overflow-hidden aspect-[4/5] max-w-[400px] ml-auto"
                style={{
                  borderRadius: '40px',
                  boxShadow: '0 20px 60px rgba(0,0,0,0.08)',
                }}
              >
                <ImageWithFallback
                  src={siteImg('mode-hero-family') || "https://images.unsplash.com/photo-1755727764068-7512292ef4b9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGlsZHJlbiUyMGFydCUyMHdvcmtzaG9wJTIwY29sb3JmdWwlMjBwYWludGluZ3xlbnwxfHx8fDE3NzMwMjU3MTZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"}
                  alt="Children art workshop"
                  className="h-full w-full object-cover"
                  style={{ filter: 'brightness(1.05) saturate(1.1)' }}
                />
              </div>
              {/* Floating badge - top left */}
              <motion.div
                className="absolute -top-3 -left-3 px-4 py-3 z-10"
                style={{
                  backgroundColor: '#fff',
                  borderRadius: '24px',
                  boxShadow: '0 8px 24px rgba(0,0,0,0.08)',
                }}
                animate={{ y: [0, -6, 0] }}
                transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
              >
                <div className="flex items-center gap-2">
                  <div>
                    <span style={{ fontFamily: tokens.headingFont, fontSize: '0.7rem', color: tokens.textPrimary, fontWeight: 700, display: 'block' }}>Art Workshop</span>
                    <span style={{ fontSize: '0.6rem', color: FAMILY_MINT, fontWeight: 600 }}>Ages 4-8</span>
                  </div>
                </div>
              </motion.div>
              {/* Floating badge - bottom right */}
              <motion.div
                className="absolute -bottom-4 -right-4 px-4 py-3 z-10"
                style={{
                  backgroundColor: '#fff',
                  borderRadius: '24px',
                  boxShadow: '0 8px 24px rgba(0,0,0,0.08)',
                }}
                animate={{ y: [0, 6, 0] }}
                transition={{ duration: 3.5, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
              >
                <div className="flex items-center gap-2">
                  <div className="flex -space-x-2">
                    {[FAMILY_PEACH, FAMILY_MINT, FAMILY_LAVENDER].map((c, i) => (
                      <span key={i} className="flex h-7 w-7 items-center justify-center rounded-full text-[9px] font-bold" style={{ backgroundColor: c + '40', border: '2px solid #fff', color: c }}>{['A', 'B', 'C'][i]}</span>
                    ))}
                  </div>
                  <div>
                    <span style={{ fontFamily: tokens.headingFont, fontSize: '0.7rem', color: tokens.textPrimary, fontWeight: 700, display: 'block' }}>2.4k families</span>
                    <span style={{ fontSize: '0.6rem', color: FAMILY_ORANGE, fontWeight: 600 }}>joined this month</span>
                  </div>
                </div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function FamilyAgeCategories() {
  const tokens = getDesignTokens('family');
  const categories = [
    { icon: 'babies-toddlers', label: 'Babies & Toddlers', ages: '0-3 yrs', count: 8, color: FAMILY_PEACH },
    { icon: 'creative-kids', label: 'Creative Kids', ages: '4-8 yrs', count: 15, color: FAMILY_LAVENDER },
    { icon: 'young-explorers', label: 'Young Explorers', ages: '9-12 yrs', count: 10, color: FAMILY_MINT },
    { icon: 'outdoor-fun', label: 'Outdoor Fun', ages: 'All ages', count: 22, color: '#B8E0A0' },
    { icon: 'museums', label: 'Museums', ages: 'All ages', count: 12, color: FAMILY_YELLOW },
    { icon: 'shows-theater', label: 'Shows & Theater', ages: '3+ yrs', count: 6, color: FAMILY_CORAL },
  ];

  return (
    <section className="px-4 sm:px-6 lg:px-12 py-6 sm:py-16 max-w-[1440px] mx-auto">
      <div className="flex items-center justify-between mb-4 sm:mb-8">
        <div>
          <h2
            style={{
              fontFamily: tokens.headingFont,
              fontSize: 'clamp(1.1rem, 2.5vw, 1.8rem)',
              color: tokens.textPrimary,
              fontWeight: 800,
              letterSpacing: '-0.02em',
            }}
          >
            Browse by{' '}
            <span style={{ color: FAMILY_ORANGE }}>Activity</span>
          </h2>
          <p className="mt-1 hidden sm:block" style={{ fontSize: '0.85rem', color: tokens.textMuted, fontFamily: tokens.bodyFont }}>
            Find the perfect activity for your little ones
          </p>
        </div>
      </div>

      <CarouselFade fadeBg={tokens.pageBg}>
      <div className="flex sm:grid sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4 overflow-x-auto sm:overflow-visible pb-2 sm:pb-0 -mx-4 px-4 sm:mx-0 sm:px-0 scrollbar-hide snap-x snap-mandatory sm:snap-none">
        {categories.map((cat, i) => (
          <motion.div
            key={cat.label}
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.06 }}
            whileHover={{ scale: 1.04 }}
            className="cursor-pointer flex flex-col items-center gap-2 sm:gap-3 py-4 sm:py-6 px-4 transition-all flex-shrink-0 min-w-[100px] sm:min-w-0 snap-start"
            style={{
              backgroundColor: '#fff',
              borderRadius: '28px',
              boxShadow: '0 4px 16px rgba(0,0,0,0.04)',
              border: '1px solid rgba(0,0,0,0.04)',
            }}
          >
            <div
              className="flex h-14 w-14 items-center justify-center rounded-full"
              style={{ backgroundColor: cat.color + '25' }}
            >
              <CIcon id={cat.icon} size={24} style={{ color: cat.color }} />
            </div>
            <div className="text-center">
              <span style={{ fontFamily: tokens.headingFont, fontSize: '0.8rem', color: tokens.textPrimary, fontWeight: 700, display: 'block' }}>
                {cat.label}
              </span>
              <span style={{ fontSize: '0.65rem', color: tokens.textMuted, fontWeight: 500 }}>
                {cat.ages} · {cat.count} events
              </span>
            </div>
          </motion.div>
        ))}
      </div>
      </CarouselFade>
    </section>
  );
}

function FamilyFeaturedVenues() {
  const { venues } = useData();
  const { i18n, t } = useTranslation();
  const lang = i18n.language;
  const isZh = lang === 'zh-Hant' || lang.startsWith('zh');
  const tokens = getDesignTokens('family');
  const familyVenues = venues
    .filter((v) => (v.modeScores?.family || 0) > 0.4)
    .sort((a, b) => (b.modeScores?.family || 0) - (a.modeScores?.family || 0));

  const pastelColors = [FAMILY_PEACH, FAMILY_MINT, FAMILY_LAVENDER, FAMILY_YELLOW];

  return (
    <section className="px-4 sm:px-6 lg:px-12 py-6 sm:py-16 max-w-[1440px] mx-auto">
      <div className="flex items-center justify-between mb-4 sm:mb-8">
        <div>
          <div className="flex items-center gap-2 mb-1 sm:mb-2">
            <Heart size={16} color={FAMILY_CORAL} fill={FAMILY_CORAL} />
            <span
              style={{
                fontFamily: tokens.headingFont,
                fontSize: '0.7rem',
                color: FAMILY_CORAL,
                fontWeight: 700,
                letterSpacing: '0.05em',
              }}
            >
              FAMILY FAVORITES
            </span>
          </div>
          <h2
            style={{
              fontFamily: tokens.headingFont,
              fontSize: 'clamp(1.1rem, 2.5vw, 1.8rem)',
              color: tokens.textPrimary,
              fontWeight: 800,
              letterSpacing: '-0.02em',
            }}
          >
            Top Spots for Families
          </h2>
        </div>
        <Link
          to="/map"
          className="flex items-center gap-2 px-4 py-2 sm:px-5 sm:py-2.5 text-xs sm:text-sm transition-all hover:scale-105"
          style={{
            backgroundColor: `${FAMILY_ORANGE}12`,
            color: FAMILY_ORANGE,
            borderRadius: '9999px',
            fontFamily: tokens.headingFont,
            fontWeight: 700,
          }}
        >
          {t('modeHome.viewAll')} <ArrowRight size={14} />
        </Link>
      </div>

      <CarouselFade fadeBg={tokens.pageBg}>
      <div className="flex sm:grid sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5 overflow-x-auto sm:overflow-visible pb-2 sm:pb-0 -mx-4 px-4 sm:mx-0 sm:px-0 scrollbar-hide snap-x snap-mandatory sm:snap-none">
        {familyVenues.slice(0, 4).map((venue, i) => (
          <motion.div
            key={venue.id}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.08 }}
            className="flex-shrink-0 w-[220px] sm:w-auto snap-start"
          >
            <Link to={`/venue/${venue.id}`} className="group block">
              <div
                className="relative overflow-hidden aspect-[4/3] mb-3 sm:mb-4"
                style={{
                  borderRadius: '28px',
                  boxShadow: '0 6px 24px rgba(0,0,0,0.06)',
                }}
              >
                <ImageWithFallback
                  src={venue.image}
                  alt={venue.name}
                  className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                  style={{ filter: 'brightness(1.05) saturate(1.05)' }}
                />
                <div
                  className="absolute inset-0"
                  style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.35) 0%, transparent 50%)' }}
                />
                <div
                  className="absolute top-4 left-4 px-3 py-1.5"
                  style={{
                    backgroundColor: '#fff',
                    borderRadius: '9999px',
                    fontSize: '0.65rem',
                    color: tokens.textPrimary,
                    fontWeight: 700,
                    fontFamily: tokens.headingFont,
                    boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
                  }}
                >
                  All ages
                </div>
                <div
                  className="absolute top-4 right-4 px-3 py-1.5"
                  style={{
                    backgroundColor: pastelColors[i % pastelColors.length] + 'cc',
                    borderRadius: '9999px',
                    fontSize: '0.65rem',
                    color: '#fff',
                    fontWeight: 600,
                    fontFamily: tokens.headingFont,
                  }}
                >
                  {venue.category}
                </div>
                <div className="absolute bottom-4 left-4 right-4">
                  <h3
                    style={{
                      fontFamily: tokens.headingFont,
                      fontSize: '1.15rem',
                      color: '#fff',
                      fontWeight: 700,
                    }}
                  >
                    {getBilingualField(venue, 'name', lang)}
                  </h3>
                  <span style={{ fontSize: '0.75rem', color: 'rgba(255,255,255,0.7)' }}>
                    {isZh ? venue.name : venue.nameZh} · {getBilingualField(venue, 'district', lang)}
                  </span>
                </div>
              </div>

              <div className="flex flex-wrap gap-1.5 mt-2">
                {(venue.vibeTags || []).slice(0, 3).map((tag) => (
                  <span
                    key={tag}
                    className="px-2.5 py-1"
                    style={{
                      backgroundColor: `${FAMILY_ORANGE}08`,
                      borderRadius: '9999px',
                      fontSize: '0.6rem',
                      color: tokens.textMuted,
                      fontWeight: 600,
                    }}
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </Link>
          </motion.div>
        ))}
      </div>
      </CarouselFade>
    </section>
  );
}

function FamilyUpcomingEvents() {
  const { events } = useData();
  const { i18n, t } = useTranslation();
  const lang = i18n.language;
  const isZh = lang === 'zh-Hant' || lang.startsWith('zh');
  const tokens = getDesignTokens('family');
  const familyEvents = events.filter((e) => e.modeTags.includes('family'));
  const PAGE_SIZE = 12;
  const [page, setPage] = useState(0);
  const totalPages = Math.ceil(familyEvents.length / PAGE_SIZE);
  const pagedEvents = familyEvents.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);

  const eventColors = [FAMILY_PEACH, FAMILY_MINT, FAMILY_LAVENDER, FAMILY_YELLOW, FAMILY_CORAL];

  return (
    <section className="px-4 sm:px-6 lg:px-12 py-6 sm:py-16 max-w-[1440px] mx-auto">
      <div className="flex items-center justify-between mb-4 sm:mb-8">
        <h2
          style={{
            fontFamily: tokens.headingFont,
            fontSize: 'clamp(1.1rem, 2.5vw, 1.8rem)',
            color: tokens.textPrimary,
            fontWeight: 800,
            letterSpacing: '-0.02em',
          }}
        >
          Upcoming{' '}
          <span style={{ color: FAMILY_MINT }}>Adventures</span>
        </h2>
        <Link
          to="/events"
          className="flex items-center gap-2 text-xs sm:text-sm transition-all"
          style={{
            color: FAMILY_ORANGE,
            fontFamily: tokens.headingFont,
            fontWeight: 700,
          }}
        >
          {t('modeHome.seeAll')} <ArrowRight size={14} />
        </Link>
      </div>

      <CarouselFade fadeBg={tokens.pageBg}>
      <div className="flex sm:grid sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 overflow-x-auto sm:overflow-visible pb-2 sm:pb-0 -mx-4 px-4 sm:mx-0 sm:px-0 scrollbar-hide snap-x snap-mandatory sm:snap-none">
        {pagedEvents.map((event, i) => (
          <motion.div
            key={event.id}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.08 }}
            className="flex-shrink-0 w-[260px] sm:w-auto snap-start"
          >
            <Link to={getEventLink(event)} className="group block">
              <div
                className="overflow-hidden flex flex-col"
                style={{
                  borderRadius: '24px',
                  backgroundColor: '#fff',
                  boxShadow: '0 4px 20px rgba(0,0,0,0.05)',
                  border: '1px solid rgba(0,0,0,0.04)',
                  height: '100%',
                }}
              >
                <div className="relative overflow-hidden aspect-[16/10]">
                  <ImageWithFallback
                    src={event.image}
                    alt={event.title}
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                    style={{ filter: 'brightness(1.05)' }}
                  />
                  <div
                    className="absolute inset-0"
                    style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.2) 0%, transparent 40%)' }}
                  />
                  <div
                    className="absolute top-4 left-4 flex flex-col items-center px-3 py-2"
                    style={{
                      backgroundColor: '#fff',
                      borderRadius: '20px',
                      boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
                      minWidth: '52px',
                    }}
                  >
                    <span style={{ fontFamily: tokens.headingFont, fontSize: '1.1rem', color: FAMILY_ORANGE, fontWeight: 800 }}>
                      {(parseEventDate(event.date) || new Date()).getDate()}
                    </span>
                    <span style={{ fontSize: '0.5rem', color: tokens.textMuted, fontWeight: 700 }}>
                      {(parseEventDate(event.date) || new Date()).toLocaleDateString('en', { month: 'short' }).toUpperCase()}
                    </span>
                  </div>
                  <div
                    className="absolute top-4 right-4 px-3 py-1.5"
                    style={{
                      backgroundColor: event.price === 'Free' ? FAMILY_MINT : '#fff',
                      borderRadius: '9999px',
                      fontSize: '0.7rem',
                      color: event.price === 'Free' ? '#fff' : FAMILY_ORANGE,
                      fontWeight: 700,
                      fontFamily: tokens.headingFont,
                      boxShadow: event.price !== 'Free' ? '0 2px 8px rgba(0,0,0,0.08)' : undefined,
                    }}
                  >
                    {event.price}
                  </div>
                </div>

                <div className="p-5 flex flex-col flex-1">
                  <div
                    className="inline-flex items-center gap-1 px-2.5 py-1 mb-2 self-start"
                    style={{
                      backgroundColor: eventColors[i % eventColors.length] + '20',
                      borderRadius: '9999px',
                      fontSize: '0.6rem',
                      color: tokens.textSecondary,
                      fontWeight: 600,
                    }}
                  >
                    {event.category}
                  </div>

                  <h3
                    className="mb-1.5 group-hover:opacity-80 transition-opacity"
                    style={{
                      fontFamily: tokens.headingFont,
                      fontSize: '1.1rem',
                      color: tokens.textPrimary,
                      fontWeight: 800,
                      display: '-webkit-box',
                      WebkitLineClamp: 2,
                      WebkitBoxOrient: 'vertical',
                      overflow: 'hidden',
                      lineHeight: 1.3,
                    }}
                  >
                    {getBilingualField(event, 'title', lang)}
                  </h3>

                  {(event.description || (event as any).descriptionZh) && (
                    <p
                      className="mb-2"
                      style={{
                        fontSize: '0.75rem',
                        color: tokens.textMuted,
                        lineHeight: 1.5,
                        display: '-webkit-box',
                        WebkitLineClamp: 2,
                        WebkitBoxOrient: 'vertical',
                        overflow: 'hidden',
                      }}
                    >
                      {getBilingualField(event, 'description', lang)}
                    </p>
                  )}

                  <div className="flex items-center gap-3 mt-auto">
                    <span className="flex items-center gap-1 truncate" style={{ fontSize: '0.75rem', color: tokens.textMuted }}>
                      <MapPin size={12} className="flex-shrink-0" /> <span className="truncate">{getBilingualField(event, 'venueName', lang)}</span>
                    </span>
                    <span style={{ fontSize: '0.75rem', color: tokens.textMuted }}>·</span>
                    <span className="flex items-center gap-1 flex-shrink-0" style={{ fontSize: '0.75rem', color: FAMILY_ORANGE, fontWeight: 600 }}>
                      <Clock size={12} /> {event.time}
                    </span>
                  </div>
                </div>
              </div>
            </Link>
          </motion.div>
        ))}
      </div>
      </CarouselFade>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-4 mt-6 sm:mt-8">
          <button
            onClick={() => setPage(p => Math.max(0, p - 1))}
            disabled={page === 0}
            className="flex items-center gap-1.5 px-4 py-2 text-xs transition-all hover:scale-105 disabled:opacity-30 disabled:cursor-default cursor-pointer"
            style={{
              border: '1px solid rgba(0,0,0,0.1)',
              borderRadius: '9999px',
              fontFamily: tokens.headingFont,
              fontWeight: 700,
              color: tokens.textSecondary,
              background: '#fff',
            }}
          >
            <ChevronLeft size={14} /> {isZh ? '上一頁' : 'Prev'}
          </button>
          <span style={{ fontSize: '0.8rem', color: tokens.textMuted, fontWeight: 600, fontFamily: tokens.headingFont }}>
            {page + 1} / {totalPages}
          </span>
          <button
            onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))}
            disabled={page >= totalPages - 1}
            className="flex items-center gap-1.5 px-4 py-2 text-xs transition-all hover:scale-105 disabled:opacity-30 disabled:cursor-default cursor-pointer"
            style={{
              backgroundColor: FAMILY_ORANGE,
              color: '#fff',
              borderRadius: '9999px',
              fontFamily: tokens.headingFont,
              fontWeight: 700,
              border: 'none',
              boxShadow: `0 4px 12px ${FAMILY_ORANGE}30`,
            }}
          >
            {isZh ? '下一頁' : 'Next'} <ChevronRight size={14} />
          </button>
        </div>
      )}
    </section>
  );
}

function FamilySafetyBanner() {
  const tokens = getDesignTokens('family');

  const features = [
    { icon: 'kid-verified', title: 'Kid-Verified', desc: 'Every venue checked for child safety' },
    { icon: 'family-facilities', title: 'Family Facilities', desc: 'Restrooms, stroller access & more' },
    { icon: 'nearby-parking', title: 'Nearby Parking', desc: 'Parking info for every location' },
    { icon: 'parent-reviews', title: 'Parent Reviews', desc: 'Real feedback from local families' },
  ];

  return (
    <section className="px-4 sm:px-6 lg:px-12 py-6 sm:py-10 max-w-[1440px] mx-auto">
      <div
        className="p-4 sm:p-8"
        style={{
          backgroundColor: '#fff',
          borderRadius: '32px',
          boxShadow: '0 4px 24px rgba(0,0,0,0.04)',
          border: '1px solid rgba(0,0,0,0.04)',
        }}
      >
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              className="flex gap-3 items-start"
            >
              <div
                className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-full"
                style={{ backgroundColor: `${FAMILY_ORANGE}10` }}
              >
                <CIcon id={f.icon} size={18} style={{ color: FAMILY_ORANGE }} />
              </div>
              <div>
                <h4 style={{ fontFamily: tokens.headingFont, fontSize: '0.85rem', color: tokens.textPrimary, fontWeight: 700 }}>
                  {f.title}
                </h4>
                <p style={{ fontSize: '0.7rem', color: tokens.textMuted, lineHeight: 1.5 }}>
                  {f.desc}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function FamilyMapCTA() {
  const tokens = getDesignTokens('family');
  const { t } = useTranslation();

  return (
    <section className="px-4 sm:px-6 lg:px-12 py-6 sm:py-16 max-w-[1440px] mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="relative overflow-hidden p-5 sm:p-12 lg:p-16"
        style={{
          borderRadius: '28px',
          background: `linear-gradient(135deg, ${FAMILY_ORANGE}15, ${FAMILY_PEACH}20, ${FAMILY_YELLOW}15)`,
          border: '1px solid rgba(0,0,0,0.04)',
          boxShadow: '0 8px 32px rgba(0,0,0,0.04)',
        }}
      >
        <div className="absolute right-8 top-8 opacity-15">
          <div className="w-24 h-24 rounded-full" style={{ backgroundColor: FAMILY_CORAL }} />
        </div>
        <div className="absolute right-24 bottom-8 opacity-10">
          <div className="w-32 h-32 rounded-full" style={{ backgroundColor: FAMILY_MINT }} />
        </div>
        <div className="absolute left-[50%] top-4 opacity-10">
          <div className="w-16 h-16 rounded-full" style={{ backgroundColor: FAMILY_LAVENDER }} />
        </div>

        <div className="relative z-10 max-w-lg">
          <div className="flex items-center gap-2 mb-4">
            <Map size={16} color={FAMILY_ORANGE} />
            <span
              style={{
                fontFamily: tokens.headingFont,
                fontSize: '0.7rem',
                color: FAMILY_ORANGE,
                fontWeight: 700,
              }}
            >
              FAMILY MAP
            </span>
          </div>
          <h2
            className="mb-4"
            style={{
              fontFamily: tokens.headingFont,
              fontSize: 'clamp(1.5rem, 3vw, 2.5rem)',
              color: tokens.textPrimary,
              fontWeight: 800,
              letterSpacing: '-0.03em',
              lineHeight: 1.1,
            }}
          >
            {t('family.mapCTATitle')}{' '}
            <span style={{ color: FAMILY_ORANGE }}>{t('family.mapCTAAccent')}</span>
          </h2>
          <p
            className="mb-5 sm:mb-8 hidden sm:block"
            style={{
              fontFamily: tokens.bodyFont,
              fontSize: '0.95rem',
              color: tokens.textSecondary,
              lineHeight: 1.7,
            }}
          >
            {t('family.mapCTABody')}
          </p>
          <Link
            to="/map"
            className="inline-flex items-center gap-2 px-5 py-3 sm:px-7 sm:py-3.5 text-xs sm:text-sm transition-all hover:brightness-105 hover:scale-[1.02]"
            style={{
              backgroundColor: FAMILY_ORANGE,
              color: '#fff',
              borderRadius: '9999px',
              fontFamily: tokens.headingFont,
              fontWeight: 700,
              boxShadow: `0 6px 20px ${FAMILY_ORANGE}35`,
            }}
          >
            <Map size={16} /> {t('family.openFamilyMap')}
          </Link>
        </div>
      </motion.div>
    </section>
  );
}

function FamilyFooter() {
  const tokens = getDesignTokens('family');
  const { t, i18n } = useTranslation();

  const footerLinks: [string, string][] = [
    [t('nav.map'), '/map'],
    [t('nav.events'), '/events'],
    [t('nav.recaps'), '/recaps'],
    [t('nav.contribute'), '/contribute'],
    [t('nav.about'), '/about'],
  ];

  return (
    <footer
      className="px-4 sm:px-6 lg:px-12 py-8 sm:py-14"
      style={{ borderTop: '1px solid rgba(0,0,0,0.06)' }}
    >
      <div className="max-w-[1440px] mx-auto">
        <div className="flex flex-col gap-6 sm:grid sm:grid-cols-2 lg:grid-cols-4 sm:gap-8">
          <div>
            <div className="flex items-center gap-2.5 mb-2 sm:mb-3">
              <div
                className="flex h-9 w-9 items-center justify-center"
                style={{
                  background: `linear-gradient(135deg, ${FAMILY_ORANGE}, ${FAMILY_YELLOW})`,
                  borderRadius: '14px',
                }}
              >
                <span style={{ fontFamily: tokens.headingFont, fontSize: '0.65rem', color: '#fff', fontWeight: 800 }}>C</span>
              </div>
              <span style={{ fontFamily: tokens.headingFont, fontSize: '0.9rem', color: tokens.textPrimary, fontWeight: 800 }}>
                CULTIVE
              </span>
            </div>
            <p className="hidden sm:block" style={{ fontSize: '0.8rem', color: tokens.textMuted, maxWidth: '220px', lineHeight: 1.7 }}>
              {t('footer.taglineFamily')}
            </p>
          </div>
          <div>
            <h4
              className="mb-2 sm:mb-3"
              style={{ fontFamily: tokens.headingFont, fontSize: '0.75rem', color: FAMILY_ORANGE, fontWeight: 700 }}
            >
              {t('footer.explore')}
            </h4>
            <div className="space-y-1.5 sm:space-y-2">
              {footerLinks.map(([label, path]) => (
                <Link key={path} to={path} className="block text-xs sm:text-sm transition-colors hover:opacity-70" style={{ color: tokens.textSecondary }}>
                  {label}
                </Link>
              ))}
            </div>
          </div>
          <div>
            <h4
              className="mb-2 sm:mb-3"
              style={{ fontFamily: tokens.headingFont, fontSize: '0.75rem', color: FAMILY_MINT, fontWeight: 700 }}
            >
              ACTIVITIES
            </h4>
            <div className="space-y-1.5 sm:space-y-2">
              {['Workshops', 'Museums', 'Outdoor', 'Theater'].map((item) => (
                <span key={item} className="block text-xs sm:text-sm" style={{ color: tokens.textSecondary }}>{item}</span>
              ))}
            </div>
          </div>
          <div className="hidden lg:block">
            <h4
              className="mb-2 sm:mb-3"
              style={{ fontFamily: tokens.headingFont, fontSize: '0.75rem', color: FAMILY_LAVENDER, fontWeight: 700 }}
            >
              {t('footer.connect')}
            </h4>
            <div className="space-y-1.5 sm:space-y-2">
              {['Instagram', 'WhatsApp Group', 'info@cultive.city'].map((item) => (
                <span key={item} className="block text-xs sm:text-sm" style={{ color: tokens.textSecondary }}>{item}</span>
              ))}
              <Link to="/contribute" className="inline-flex items-center gap-1.5 mt-2 text-xs sm:text-sm transition-all hover:scale-105" style={{ color: FAMILY_ORANGE, fontWeight: 700, fontFamily: tokens.headingFont }}>
                + {t('common.submitEvent')}
              </Link>
            </div>
          </div>
        </div>
        <div
          className="mt-6 sm:mt-10 pt-4 sm:pt-6 flex flex-wrap items-center justify-between gap-2 sm:gap-4"
          style={{ borderTop: '1px solid rgba(0,0,0,0.06)' }}
        >
          <span style={{ fontSize: '0.7rem', color: tokens.textMuted }}>{t('common.copyright')}</span>
          <div className="flex items-center gap-3 sm:gap-4">
            <Link to="/privacy" className="transition-opacity hover:opacity-70" style={{ fontSize: '0.7rem', color: tokens.textMuted }}>{t('footer.privacy')}</Link>
            <Link to="/terms" className="transition-opacity hover:opacity-70" style={{ fontSize: '0.7rem', color: tokens.textMuted }}>{t('footer.terms')}</Link>
            <span style={{ fontSize: '0.7rem', color: tokens.textMuted }}>{t('common.madeInHK')}</span>
          </div>
        </div>
      </div>
    </footer>
  );
}

export function FamilyHomePage() {
  return (
    <div>
      <FamilyHero />
      <FamilyAgeCategories />
      <ThingsToDo />
      <FamilySafetyBanner />
      <FamilyFeaturedVenues />
      <FamilyUpcomingEvents />
      <FamilyMapCTA />
      <FamilyFooter />
    </div>
  );
}