import { Link } from 'react-router';
import { useTranslation } from 'react-i18next';
import { motion } from 'motion/react';
import { ArrowRight, Map } from 'lucide-react';
import { useData } from '../../context/DataContext';
import { ModeSelector } from '../ModeSelector';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { getDesignTokens } from '../../data/mode-styles';
import { ThingsToDo } from '../ThingsToDo';
import { CIcon } from '../CIcon';
import { CarouselFade } from '../CarouselFade';
import { getEventLink } from '../../utils/event-helpers';
import { useSiteImages } from '../../hooks/useSiteImages';
import { getBilingualField } from '../../utils/bilingual';
import { useState } from 'react';

// ═══════════════════════════════════════════════════════════════════
// NIGHT MODE: Plenty Fish-Inspired Bold Poster / Editorial Brutalist
// ═══════════════════════════════════════════════════════════════════

const DEGEN_YELLOW = '#EDFF00';
const DEGEN_MAGENTA = '#D600FF';
const DEGEN_BLACK = '#0A0A0A';

function DegenHero() {
  const { events } = useData();
  const tokens = getDesignTokens('degen');
  const degenEvents = events.filter((e) => e.modeTags.includes('degen'));
  const heroEvent = degenEvents[0] || events[0];
  const { img: siteImg } = useSiteImages();

  // Scattered annotation words — Plenty Fish style
  const scatterWords = [
    { text: 'CENTRAL', top: '18%', left: '62%', size: '0.55rem' },
    { text: 'WAN CHAI', top: '28%', right: '8%', size: '0.55rem' },
    { text: 'LKF', top: '44%', left: '55%', size: '0.55rem' },
    { text: 'SHEUNG WAN', top: '52%', right: '12%', size: '0.55rem' },
    { text: 'TST', top: '62%', left: '60%', size: '0.55rem' },
    { text: 'SSP', top: '35%', left: '70%', size: '0.55rem' },
  ];

  return (
    <section className="relative min-h-[75vh] sm:min-h-[100vh] overflow-hidden flex items-center" style={{ backgroundColor: DEGEN_YELLOW }} data-nav-theme="dark">
      {/* Scattered small annotation words — Plenty Fish style */}
      {scatterWords.map((w) => (
        <span
          key={w.text}
          className="absolute hidden lg:block pointer-events-none select-none"
          style={{
            top: w.top,
            left: w.left,
            right: (w as any).right,
            fontSize: w.size,
            color: 'rgba(0,0,0,0.15)',
            fontFamily: tokens.bodyFont,
            fontWeight: 500,
            letterSpacing: '0.1em',
          }}
        >
          {w.text}
        </span>
      ))}

      {/* Mode selector — hidden on mobile (available in nav menu) */}
      <div className="absolute top-6 right-4 sm:right-8 z-10 hidden md:block">
        <ModeSelector />
      </div>

      {/* Content */}
      <div className="relative w-full max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          {/* Left: Massive poster typography */}
          <div className="lg:col-span-7">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
            >
              <span
                className="block mb-4"
                style={{
                  fontFamily: tokens.bodyFont,
                  fontSize: '0.65rem',
                  color: 'rgba(0,0,0,0.3)',
                  letterSpacing: '0.1em',
                }}
              >
                /001
              </span>

              <h1
                className="mb-3"
                style={{
                  fontFamily: tokens.headingFont,
                  fontSize: 'clamp(2.5rem, 10vw, 8rem)',
                  lineHeight: 0.88,
                  color: DEGEN_BLACK,
                  fontWeight: 700,
                  letterSpacing: '-0.04em',
                  textTransform: 'uppercase',
                }}
              >
                AFTER
                <br />
                <span style={{ color: DEGEN_MAGENTA }}>DARK</span>
                <br />
                HK
              </h1>

              <div className="flex flex-wrap gap-x-4 sm:gap-x-6 gap-y-1 mb-4 sm:mb-6 max-w-lg">
                {['NIGHTLIFE', 'PARTIES', 'UNDERGROUND', 'CULTURE', 'LATE NIGHT', 'SCENES'].map((w) => (
                  <span
                    key={w}
                    style={{
                      fontFamily: tokens.bodyFont,
                      fontSize: '0.6rem',
                      color: 'rgba(0,0,0,0.35)',
                      letterSpacing: '0.08em',
                    }}
                  >
                    {w}
                  </span>
                ))}
              </div>

              <p
                className="mb-5 sm:mb-8 max-w-md hidden sm:block"
                style={{
                  fontFamily: tokens.bodyFont,
                  fontSize: '0.9rem',
                  lineHeight: 1.7,
                  color: tokens.textSecondary,
                }}
              >
                The events the tourists won't find. Late-night culture, underground scenes, and where the young artsy crowd actually goes in Hong Kong.
              </p>

              <div className="flex gap-2 sm:gap-3">
                <Link
                  to="/events"
                  className="flex items-center gap-2 px-5 py-3 sm:px-8 sm:py-4 text-xs sm:text-sm transition-all hover:scale-[1.02]"
                  style={{
                    backgroundColor: DEGEN_BLACK,
                    color: DEGEN_YELLOW,
                    borderRadius: '4px',
                    fontFamily: tokens.headingFont,
                    fontWeight: 700,
                    textTransform: 'uppercase',
                    letterSpacing: '0.05em',
                  }}
                >
                  WHAT'S ON <ArrowRight size={16} />
                </Link>
                <Link
                  to="/map"
                  className="flex items-center gap-2 px-5 py-3 sm:px-8 sm:py-4 text-xs sm:text-sm transition-all hover:bg-black/5"
                  style={{
                    border: '2px solid #0A0A0A',
                    color: DEGEN_BLACK,
                    borderRadius: '4px',
                    fontFamily: tokens.headingFont,
                    fontWeight: 700,
                    textTransform: 'uppercase',
                    letterSpacing: '0.05em',
                  }}
                >
                  NIGHT MAP
                </Link>
              </div>
            </motion.div>
          </div>

          {/* Right: Featured image  stark, editorial crop */}
          <div className="lg:col-span-5">
            <motion.div
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
              className="hidden lg:block"
            >
              <div
                className="relative overflow-hidden aspect-[3/4] max-w-[400px] ml-auto"
                style={{ borderRadius: '4px' }}
              >
                <ImageWithFallback
                  src={siteImg('mode-hero-night') || "https://images.unsplash.com/photo-1650302469504-99734c9df41e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob25nJTIwa29uZyUyMHN0cmVldCUyMG5pZ2h0JTIwbmVvbiUyMHNpZ25zfGVufDF8fHx8MTc3MzAyNjE5OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"}
                  alt="Hong Kong nightlife"
                  className="h-full w-full object-cover"
                  style={{ filter: 'contrast(1.15) saturate(1.1)' }}
                />
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <span
                    style={{
                      fontFamily: tokens.headingFont,
                      fontSize: 'clamp(2rem, 4vw, 3.5rem)',
                      color: DEGEN_MAGENTA,
                      fontWeight: 700,
                      textTransform: 'uppercase',
                      lineHeight: 0.9,
                      textShadow: '0 2px 20px rgba(0,0,0,0.5)',
                    }}
                  >
                    PLENTY
                    <br />
                    TO DO
                  </span>
                </div>
                <div className="absolute top-4 right-4">
                  <span
                    className="px-3 py-1.5"
                    style={{
                      backgroundColor: DEGEN_MAGENTA,
                      color: '#fff',
                      fontFamily: tokens.headingFont,
                      fontSize: '0.65rem',
                      fontWeight: 700,
                      borderRadius: '2px',
                    }}
                  >
                    NOW
                  </span>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}

function DegenThingsToDo() {
  const tokens = getDesignTokens('degen');
  const { t } = useTranslation();

  return (
    <section className="px-4 sm:px-6 lg:px-12 py-6 sm:py-14 max-w-[1440px] mx-auto">
      <span
        className="block mb-2 sm:mb-4"
        style={{ fontFamily: tokens.bodyFont, fontSize: '0.65rem', color: 'rgba(0,0,0,0.25)', letterSpacing: '0.1em' }}
      >
        /002
      </span>
      <div className="flex items-center justify-between mb-4 sm:mb-6">
        <h2
          style={{
            fontFamily: tokens.headingFont,
            fontSize: 'clamp(1.2rem, 3vw, 2.5rem)',
            color: DEGEN_BLACK,
            fontWeight: 700,
            letterSpacing: '-0.03em',
            textTransform: 'uppercase',
          }}
        >
          FIND YOUR <span style={{ color: DEGEN_MAGENTA }}>VIBE</span>
        </h2>
      </div>

      <ThingsToDo
        items={[
          { label: 'CLUBS', count: 8 },
          { label: 'BARS', count: 14 },
          { label: 'DJ SETS', count: 6 },
          { label: 'LIVE MUSIC', count: 5 },
          { label: 'SPEAKEASY', count: 7 },
          { label: 'LATE NIGHT', count: 12 },
          { label: 'ROOFTOP', count: 4 },
          { label: 'UNDERGROUND', count: 9 },
        ]}
        tokens={tokens}
        bgColor={DEGEN_BLACK}
        textColor={DEGEN_YELLOW}
        hoverColor={DEGEN_MAGENTA}
      />
    </section>
  );
}

function DegenVenueSpotlight() {
  const { venues } = useData();
  const { i18n } = useTranslation();
  const lang = i18n.language;
  const isZh = lang === 'zh-Hant' || lang.startsWith('zh');
  const tokens = getDesignTokens('degen');
  const degenVenues = venues
    .filter((v) => (v.modeScores?.degen || 0) > 0.4)
    .sort((a, b) => (b.modeScores?.degen || 0) - (a.modeScores?.degen || 0));

  return (
    <section className="py-6 sm:py-14 max-w-[1440px] mx-auto">
      <div className="mx-4 sm:mx-6 lg:mx-12 p-4 sm:p-10 lg:p-12" style={{ backgroundColor: DEGEN_BLACK, borderRadius: '6px' }}>
        <span
          className="block mb-2 sm:mb-4"
          style={{ fontFamily: tokens.bodyFont, fontSize: '0.65rem', color: 'rgba(255,255,255,0.2)', letterSpacing: '0.1em' }}
        >
          /003
        </span>
        <div className="flex items-center justify-between mb-4 sm:mb-8">
          <h2
            style={{
              fontFamily: tokens.headingFont,
              fontSize: 'clamp(1.5rem, 3vw, 2.8rem)',
              color: DEGEN_YELLOW,
              fontWeight: 700,
              letterSpacing: '-0.03em',
              textTransform: 'uppercase',
            }}
          >
            HOT SPOTS
          </h2>
          <Link
            to="/map"
            className="flex items-center gap-2 px-4 py-2 sm:px-5 sm:py-2.5 text-xs sm:text-sm transition-all hover:bg-white/10"
            style={{
              border: `2px solid ${DEGEN_YELLOW}`,
              color: DEGEN_YELLOW,
              borderRadius: '4px',
              fontFamily: tokens.headingFont,
              fontWeight: 700,
              textTransform: 'uppercase',
              letterSpacing: '0.03em',
            }}
          >
            ALL <ArrowRight size={14} />
          </Link>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {degenVenues[0] && (
            <motion.div
              className="lg:col-span-7"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <Link to={`/venue/${degenVenues[0].id}`} className="group block">
                <div className="relative overflow-hidden aspect-[4/3]" style={{ borderRadius: '4px' }}>
                  <ImageWithFallback
                    src={degenVenues[0].image}
                    alt={degenVenues[0].name}
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                    style={{ filter: 'contrast(1.1) saturate(1.1)' }}
                  />
                  <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.8) 0%, rgba(0,0,0,0.2) 40%, transparent 70%)' }} />
                  <div
                    className="absolute top-4 right-4 px-3 py-1.5"
                    style={{
                      backgroundColor: DEGEN_MAGENTA,
                      borderRadius: '2px',
                      fontSize: '0.7rem',
                      color: '#fff',
                      fontWeight: 700,
                      fontFamily: tokens.headingFont,
                    }}
                  >
                    {Math.round((degenVenues[0].modeScores?.degen || 0) * 100)}%
                  </div>
                  <div className="absolute bottom-5 left-5 right-5">
                    <div className="flex flex-wrap gap-2 mb-3">
                      {(degenVenues[0].vibeTags || []).slice(0, 3).map((tag) => (
                        <span
                          key={tag}
                          className="px-2.5 py-1"
                          style={{
                            backgroundColor: 'rgba(255,255,255,0.12)',
                            borderRadius: '2px',
                            fontSize: '0.65rem',
                            color: DEGEN_YELLOW,
                            fontWeight: 600,
                            textTransform: 'uppercase',
                          }}
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                    <h3
                      style={{
                        fontFamily: tokens.headingFont,
                        fontSize: 'clamp(1.5rem, 3vw, 2.2rem)',
                        color: '#fff',
                        fontWeight: 700,
                        letterSpacing: '-0.02em',
                        textTransform: 'uppercase',
                      }}
                    >
                      {getBilingualField(degenVenues[0], 'name', lang)}
                    </h3>
                    <span style={{ fontSize: '0.8rem', color: 'rgba(255,255,255,0.4)' }}>
                      {isZh ? degenVenues[0].name : degenVenues[0].nameZh} · {getBilingualField(degenVenues[0], 'district', lang)}
                    </span>
                  </div>
                </div>
              </Link>
            </motion.div>
          )}

          <CarouselFade fadeBg={tokens.pageBg}>
          <div className="lg:col-span-5 flex sm:flex-col gap-3 overflow-x-auto sm:overflow-visible pb-2 sm:pb-0 -mx-4 px-4 sm:mx-0 sm:px-0 scrollbar-hide snap-x snap-mandatory sm:snap-none">
            {degenVenues.slice(1, 4).map((venue, i) => (
              <motion.div
                key={venue.id}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="flex-shrink-0 w-[240px] sm:w-auto snap-start"
              >
                <Link
                  to={`/venue/${venue.id}`}
                  className="group flex gap-3 sm:gap-4 p-3 transition-all hover:bg-white/5"
                  style={{
                    borderRadius: '4px',
                    border: '1px solid rgba(255,255,255,0.06)',
                  }}
                >
                  <div className="w-20 h-20 flex-shrink-0 overflow-hidden" style={{ borderRadius: '4px' }}>
                    <ImageWithFallback
                      src={venue.image}
                      alt={venue.name}
                      className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                  </div>
                  <div className="flex-1 flex flex-col justify-center min-w-0">
                    <span style={{ fontSize: '0.6rem', color: 'rgba(255,255,255,0.3)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                      {venue.district}
                    </span>
                    <h4
                      className="truncate mt-1"
                      style={{
                        fontFamily: tokens.headingFont,
                        fontSize: '1rem',
                        color: '#fff',
                        fontWeight: 700,
                        textTransform: 'uppercase',
                      }}
                    >
                      {getBilingualField(venue, 'name', lang)}
                    </h4>
                    <div className="flex items-center gap-2 mt-1">
                      <span style={{ fontSize: '0.65rem', color: DEGEN_MAGENTA, fontWeight: 700 }}>
                        {Math.round((venue.modeScores?.degen || 0) * 100)}% MATCH
                      </span>
                      <span style={{ fontSize: '0.65rem', color: 'rgba(255,255,255,0.2)' }}>
                        {'$'.repeat(venue.priceRange)}
                      </span>
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
          </CarouselFade>
        </div>
      </div>
    </section>
  );
}

function DegenUpcomingEvents() {
  const { events } = useData();
  const { i18n } = useTranslation();
  const lang = i18n.language;
  const tokens = getDesignTokens('degen');
  const degenEvents = events.filter((e) => e.modeTags.includes('degen'));
  const PAGE_SIZE = 10;
  const [page, setPage] = useState(0);
  const totalPages = Math.ceil(degenEvents.length / PAGE_SIZE);
  const pagedEvents = degenEvents.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);

  return (
    <section className="px-4 sm:px-6 lg:px-12 py-6 sm:py-14 max-w-[1440px] mx-auto">
      <span
        className="block mb-2 sm:mb-4"
        style={{ fontFamily: tokens.bodyFont, fontSize: '0.65rem', color: 'rgba(0,0,0,0.25)', letterSpacing: '0.1em' }}
      >
        /004
      </span>
      <div className="flex items-center justify-between mb-4 sm:mb-8">
        <h2
          style={{
            fontFamily: tokens.headingFont,
            fontSize: 'clamp(1.2rem, 3vw, 2.5rem)',
            color: DEGEN_BLACK,
            fontWeight: 700,
            letterSpacing: '-0.03em',
            textTransform: 'uppercase',
          }}
        >
          WHAT'S <span style={{ color: DEGEN_MAGENTA }}>ON</span>
        </h2>
        <Link
          to="/events"
          className="flex items-center gap-2 text-xs sm:text-sm transition-all hover:opacity-70"
          style={{
            color: DEGEN_BLACK,
            fontFamily: tokens.headingFont,
            fontWeight: 700,
            textTransform: 'uppercase',
            letterSpacing: '0.03em',
          }}
        >
          ALL EVENTS <ArrowRight size={14} />
        </Link>
      </div>

      <CarouselFade fadeBg={tokens.pageBg}>
      <div className="flex sm:block gap-4 overflow-x-auto sm:overflow-visible pb-2 sm:pb-0 -mx-4 px-4 sm:mx-0 sm:px-0 scrollbar-hide snap-x snap-mandatory sm:snap-none sm:space-y-4">
        {pagedEvents.map((event, i) => (
          <motion.div
            key={event.id}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.06 }}
            className="flex-shrink-0 w-[260px] sm:w-auto snap-start"
          >
            <Link
              to={getEventLink(event)}
              className="group flex flex-col sm:flex-row gap-3 sm:gap-5 items-start sm:items-center py-3 sm:py-5 transition-all hover:bg-black/[0.03]"
              style={{ borderBottom: '2px solid rgba(0,0,0,0.08)', borderRadius: '0' }}
            >
              <div className="w-full sm:w-32 h-20 sm:h-24 flex-shrink-0 overflow-hidden" style={{ borderRadius: '4px' }}>
                <ImageWithFallback
                  src={event.image}
                  alt={event.title}
                  className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
                  style={{ filter: 'contrast(1.1)' }}
                />
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex flex-wrap items-center gap-3 mb-1">
                  <span
                    className="px-2 py-0.5"
                    style={{
                      backgroundColor: DEGEN_MAGENTA,
                      color: '#fff',
                      borderRadius: '2px',
                      fontSize: '0.6rem',
                      fontWeight: 700,
                      fontFamily: tokens.headingFont,
                      textTransform: 'uppercase',
                    }}
                  >
                    {event.category}
                  </span>
                  <span style={{ fontSize: '0.65rem', color: tokens.textMuted, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                    {event.date} · {event.time}
                  </span>
                </div>
                <h3
                  className="group-hover:opacity-70 transition-opacity"
                  style={{
                    fontFamily: tokens.headingFont,
                    fontSize: 'clamp(1rem, 2vw, 1.5rem)',
                    color: DEGEN_BLACK,
                    fontWeight: 700,
                    textTransform: 'uppercase',
                    letterSpacing: '-0.02em',
                  }}
                >
                  {getBilingualField(event, 'title', lang)}
                </h3>
                <span style={{ fontSize: '0.75rem', color: tokens.textMuted }}>
                  {getBilingualField(event, 'venueName', lang)} · {getBilingualField(event, 'district', lang)}
                </span>
              </div>

              <div className="flex-shrink-0">
                <span
                  className="px-4 py-2"
                  style={{
                    border: `2px solid ${DEGEN_BLACK}`,
                    borderRadius: '4px',
                    fontSize: '0.8rem',
                    color: DEGEN_BLACK,
                    fontWeight: 700,
                    fontFamily: tokens.headingFont,
                  }}
                >
                  {event.price}
                </span>
              </div>
            </Link>
          </motion.div>
        ))}
      </div>
      </CarouselFade>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-6 mt-6">
          <button
            onClick={() => setPage(p => Math.max(0, p - 1))}
            disabled={page === 0}
            className="px-4 py-2 text-xs transition-all hover:scale-[1.02] disabled:opacity-30 disabled:cursor-default cursor-pointer"
            style={{
              border: `2px solid ${DEGEN_BLACK}`,
              borderRadius: '4px',
              fontFamily: tokens.headingFont,
              fontWeight: 700,
              textTransform: 'uppercase',
              letterSpacing: '0.05em',
              color: DEGEN_BLACK,
              background: 'none',
            }}
          >
            PREV
          </button>
          <span
            style={{
              fontFamily: tokens.headingFont,
              fontSize: '0.8rem',
              color: DEGEN_BLACK,
              fontWeight: 700,
            }}
          >
            {page + 1} / {totalPages}
          </span>
          <button
            onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))}
            disabled={page >= totalPages - 1}
            className="px-4 py-2 text-xs transition-all hover:scale-[1.02] disabled:opacity-30 disabled:cursor-default cursor-pointer"
            style={{
              backgroundColor: DEGEN_BLACK,
              color: DEGEN_YELLOW,
              borderRadius: '4px',
              fontFamily: tokens.headingFont,
              fontWeight: 700,
              textTransform: 'uppercase',
              letterSpacing: '0.05em',
              border: 'none',
            }}
          >
            NEXT
          </button>
        </div>
      )}
    </section>
  );
}

function DegenMapCTA() {
  const tokens = getDesignTokens('degen');
  const { t } = useTranslation();

  return (
    <section className="px-4 sm:px-6 lg:px-12 py-6 sm:py-14 max-w-[1440px] mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="relative overflow-hidden p-5 sm:p-12 lg:p-16"
        style={{
          borderRadius: '6px',
          backgroundColor: DEGEN_BLACK,
        }}
      >
        <div className="absolute top-0 left-0 bottom-0 w-[6px]" style={{ backgroundColor: DEGEN_MAGENTA }} />

        <div className="absolute right-4 sm:right-10 top-1/2 -translate-y-1/2 pointer-events-none select-none">
          <span
            style={{
              fontFamily: tokens.headingFont,
              fontSize: 'clamp(4rem, 12vw, 10rem)',
              color: 'rgba(255,255,255,0.03)',
              fontWeight: 700,
              textTransform: 'uppercase',
              lineHeight: 0.85,
            }}
          >
            MAP
          </span>
        </div>

        <div className="relative z-10 max-w-lg">
          <span
            className="block mb-4"
            style={{ fontFamily: tokens.bodyFont, fontSize: '0.65rem', color: 'rgba(255,255,255,0.2)', letterSpacing: '0.1em' }}
          >
            /005
          </span>
          <h2
            className="mb-4"
            style={{
              fontFamily: tokens.headingFont,
              fontSize: 'clamp(1.8rem, 4vw, 3rem)',
              color: DEGEN_YELLOW,
              fontWeight: 700,
              letterSpacing: '-0.03em',
              lineHeight: 1,
              textTransform: 'uppercase',
            }}
          >
            NAVIGATE
            <br />
            THE <span style={{ color: DEGEN_MAGENTA }}>UNDERGROUND</span>
          </h2>
          <p
            className="mb-5 sm:mb-8 hidden sm:block"
            style={{
              fontFamily: tokens.bodyFont,
              fontSize: '0.9rem',
              color: 'rgba(255,255,255,0.5)',
              lineHeight: 1.7,
            }}
          >
            {t('degen.mapCTABody')}
          </p>
          <Link
            to="/map"
            className="inline-flex items-center gap-2 px-5 py-3 sm:px-8 sm:py-4 text-xs sm:text-sm transition-all hover:scale-[1.02]"
            style={{
              backgroundColor: DEGEN_YELLOW,
              color: DEGEN_BLACK,
              borderRadius: '4px',
              fontFamily: tokens.headingFont,
              fontWeight: 700,
              textTransform: 'uppercase',
              letterSpacing: '0.05em',
            }}
          >
            {t('degen.openMapBtn')} <ArrowRight size={16} />
          </Link>
        </div>
      </motion.div>
    </section>
  );
}

function DegenFooter() {
  const tokens = getDesignTokens('degen');
  const { t, i18n } = useTranslation();

  const footerLinks: [string, string][] = [
    [t('nav.map'), '/map'],
    [t('nav.events'), '/events'],
    [t('nav.recaps'), '/recaps'],
    [t('nav.contribute'), '/contribute'],
    [t('nav.about'), '/about'],
  ];

  return (
    <footer className="px-4 sm:px-6 lg:px-12 py-8 sm:py-14" style={{ borderTop: '2px solid rgba(0,0,0,0.08)' }}>
      <div className="max-w-[1440px] mx-auto">
        <div className="flex flex-col gap-6 sm:grid sm:grid-cols-2 lg:grid-cols-4 sm:gap-8">
          <div>
            <span
              style={{
                fontFamily: tokens.headingFont,
                fontSize: '1.3rem',
                color: DEGEN_BLACK,
                fontWeight: 700,
                textTransform: 'uppercase',
                display: 'block',
                marginBottom: '8px',
              }}
            >
              CULTIVE
            </span>
            <p className="hidden sm:block" style={{ fontSize: '0.8rem', color: tokens.textMuted, maxWidth: '220px', lineHeight: 1.7 }}>
              {t('footer.taglineDegen')}
            </p>
          </div>
          <div>
            <h4
              className="mb-2 sm:mb-3"
              style={{ fontFamily: tokens.headingFont, fontSize: '0.7rem', color: DEGEN_BLACK, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em' }}
            >
              {t('footer.explore')}
            </h4>
            <div className="space-y-1.5 sm:space-y-2">
              {footerLinks.map(([label, path]) => (
                <Link key={path} to={path} className="block text-xs sm:text-sm transition-colors hover:opacity-70" style={{ color: tokens.textSecondary }}>
                  {label}
                </Link>
              ))}
            </div>
          </div>
          <div>
            <h4
              className="mb-2 sm:mb-3"
              style={{ fontFamily: tokens.headingFont, fontSize: '0.7rem', color: DEGEN_BLACK, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em' }}
            >
              VIBES
            </h4>
            <div className="space-y-1.5 sm:space-y-2">
              {['Nightclubs', 'Speakeasies', 'DJ Sets', 'Late Night'].map((item) => (
                <span key={item} className="block text-xs sm:text-sm" style={{ color: tokens.textSecondary }}>{item}</span>
              ))}
            </div>
          </div>
          <div className="hidden lg:block">
            <h4
              className="mb-2 sm:mb-3"
              style={{ fontFamily: tokens.headingFont, fontSize: '0.7rem', color: DEGEN_MAGENTA, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em' }}
            >
              {t('footer.connect')}
            </h4>
            <div className="space-y-1.5 sm:space-y-2">
              {['Instagram', 'TikTok', 'info@cultive.city'].map((item) => (
                <span key={item} className="block text-xs sm:text-sm" style={{ color: tokens.textSecondary }}>{item}</span>
              ))}
              <Link to="/contribute" className="inline-flex items-center gap-1.5 mt-2 text-xs sm:text-sm transition-opacity hover:opacity-70" style={{ color: DEGEN_MAGENTA, fontWeight: 700, fontFamily: tokens.headingFont, textTransform: 'uppercase', letterSpacing: '0.03em' }}>
                {t('common.submitEvent')}
              </Link>
            </div>
          </div>
        </div>
        <div
          className="mt-6 sm:mt-10 pt-4 sm:pt-6 flex flex-wrap items-center justify-between gap-2 sm:gap-4"
          style={{ borderTop: '2px solid rgba(0,0,0,0.08)' }}
        >
          <span style={{ fontSize: '0.7rem', color: tokens.textMuted }}>{t('common.copyright')}</span>
          <div className="flex items-center gap-3 sm:gap-4">
            <Link to="/privacy" className="transition-opacity hover:opacity-70" style={{ fontSize: '0.7rem', color: tokens.textMuted }}>{t('footer.privacy')}</Link>
            <Link to="/terms" className="transition-opacity hover:opacity-70" style={{ fontSize: '0.7rem', color: tokens.textMuted }}>{t('footer.terms')}</Link>
            <span style={{ fontSize: '0.7rem', color: tokens.textMuted }}>{t('common.madeInHK')}</span>
          </div>
        </div>
      </div>
    </footer>
  );
}

export function DegenHomePage() {
  const tokens = getDesignTokens('degen');

  return (
    <div style={{ backgroundColor: tokens.pageBg }}>
      <DegenHero />
      <ModeSelector />
      <DegenThingsToDo />
      <DegenVenueSpotlight />
      <DegenUpcomingEvents />
      <DegenMapCTA />
      <DegenFooter />
    </div>
  );
}