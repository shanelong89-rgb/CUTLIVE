import { useState, useCallback, useRef, useEffect, useMemo } from 'react';
import { Link, useNavigate } from 'react-router';
import { useTranslation } from 'react-i18next';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowRight, MapPin, Clock, Map as MapIcon, Star, ChevronLeft, ChevronRight as ChevronRightIcon, Plus, Send, ArrowUpRight } from 'lucide-react';
import { useMode } from '../../context/ModeContext';
import type { UIMode } from '../../context/ModeContext';
import { modeConfig, type Mode } from '../../data/mock-data';
import { useData } from '../../context/DataContext';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { useSiteImages } from '../../hooks/useSiteImages';
import { getDesignTokens } from '../../data/mode-styles';
import { parseEventDate } from '../../utils/date-helpers';
import { ThingsToDo } from '../ThingsToDo';
import { CIcon } from '../CIcon';
import { getEventLink } from '../../utils/event-helpers';
import { useAuth } from '../../context/AuthContext';
import { BookmarkHeart } from '../BookmarkHeart';
import { getBilingualField } from '../../utils/bilingual';
import { MobileEditorialHomeWithTheme } from '../MobileEditorialHome';
import { MapContainer, TileLayer, Marker } from '../map/LeafletWrapper';
import L from 'leaflet';
import { useNeutralTheme } from '../../context/NeutralThemeContext';
import { useTemplateData } from '../../hooks/useTemplateData';

// ═════════════════════════════════════════════════════════════════
// DEFAULT MODE: Editorial Magazine — Warm, Minimal, Rule-of-Thirds
// ═══════════════════════════════════════════════════════════════════

const BG = '#FAFAF8';

// Shared editorial micro-label style
const eLabelStyle: React.CSSProperties = {
  fontSize: '0.6rem',
  fontWeight: 600,
  letterSpacing: '0.18em',
  textTransform: 'uppercase',
  color: '#B5B0A8',
};

// Hero video for neutral homepage — loops silently behind the overlay
// These are fallback defaults; the Template Editor can override them
const HERO_VIDEO_DEFAULT = 'https://videos.pexels.com/video-files/3129671/3129671-uhd_2560_1440_30fps.mp4';
const HERO_POSTER_DEFAULT = 'https://images.unsplash.com/photo-1759053117752-0362834a4381?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxIb25nJTIwS29uZyUyMGhhcmJvdXIlMjBza3lsaW5lJTIwZ29sZGVuJTIwaG91ciUyMGVkaXRvcmlhbHxlbnwxfHx8fDE3NzMwNTg3MjB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral';


function FeaturedHero() {
  const { events } = useData();
  const { t, i18n: _i18n } = useTranslation();
  const isZh = _i18n.language?.startsWith('zh');
  const heroEvent = events.find(e => e.featured) || events[0];
  const { theme: neutralTheme } = useNeutralTheme();
  const navThemeValue = neutralTheme === 'dark' ? 'light' : 'dark';

  // Use the shared template data hook (replaces inline CMS fetch)
  const tpl = useTemplateData('home');

  // Resolve values with fallback to defaults
  const loaded = tpl.loaded;
  const heroType = tpl.hero.heroType || 'video';
  const heroVideo = tpl.hero.videoUrl || HERO_VIDEO_DEFAULT;
  const heroPoster = tpl.hero.posterImage || HERO_POSTER_DEFAULT;
  const headline = tpl.hero.headline || t('default.heroHeadline');
  const subheadline = tpl.hero.subheadline || t('default.heroSubhead');
  const description = tpl.hero.description || t('default.heroBody');
  const ctaPrimary = tpl.hero.ctaPrimary || t('default.browseEvents');
  const ctaSecondary = tpl.hero.ctaSecondary || t('default.exploreMap');

  return (
    <section style={{ backgroundColor: BG, paddingTop: '12vh', paddingBottom: '6vh' }} data-nav-theme={navThemeValue}>
      <div className="max-w-[1440px] mx-auto px-10 lg:px-14">
        {/* Masthead meta */}
        <div className="flex items-baseline justify-between mb-6">
          <span style={{ ...eLabelStyle, fontFamily: "'Archivo Black', sans-serif" }}>
            {new Date().toLocaleDateString('en', { month: 'long', day: 'numeric', year: 'numeric' })}
          </span>
          <span style={{ ...eLabelStyle, fontFamily: "'Noto Sans HK', sans-serif" }}>
            Hong Kong
          </span>
        </div>

        <div className="h-px w-full" style={{ backgroundColor: '#1A1A1A' }} />

        {/* Editorial headline — rule of thirds */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '2rem', marginTop: '3rem' }}>
          {/* Left third — headline */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
          >
            <h1 style={{
              fontFamily: "'Archivo Black', sans-serif",
              fontSize: 'clamp(2.5rem, 5vw, 4rem)',
              lineHeight: 0.95,
              color: '#1A1A1A',
              letterSpacing: '-0.04em',
            }}>
              {isZh ? '本週精選' : headline || 'This week'}
            </h1>
          </motion.div>

          {/* Right two-thirds — description + CTAs */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.35, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
            className="flex flex-col justify-end"
          >
            <p style={{
              fontSize: '0.95rem',
              lineHeight: 1.65,
              color: '#A09B93',
              maxWidth: '480px',
              marginBottom: '2rem',
            }}>
              {isZh ? '香港值得你出門的事。' : description || "What's worth leaving the house for in Hong Kong."}
            </p>

            <div className="flex items-center gap-3">
              <Link
                to="/events"
                className="inline-flex items-center gap-2 px-6 py-3 text-sm transition-all hover:opacity-90"
                style={{
                  backgroundColor: '#1A1A1A',
                  color: '#fff',
                  borderRadius: '12px',
                  fontWeight: 600,
                }}
              >
                {ctaPrimary || (isZh ? '瀏覽活動' : 'Browse Events')} <ArrowRight size={14} />
              </Link>
              <Link
                to="/map"
                className="inline-flex items-center gap-2 px-6 py-3 text-sm transition-all hover:opacity-80"
                style={{
                  border: '1px solid #E8E4DE',
                  color: '#1A1A1A',
                  borderRadius: '12px',
                  fontWeight: 500,
                }}
              >
                <MapIcon size={14} /> {ctaSecondary || (isZh ? '探索地圖' : 'Explore Map')}
              </Link>
            </div>
          </motion.div>
        </div>

        {/* Featured event — offset to right third */}
        {heroEvent && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5, duration: 0.6 }}
            style={{ marginTop: '3rem', paddingLeft: '33.3%' }}
          >
            <Link to={getEventLink(heroEvent)} className="group inline-flex items-center gap-5">
              <div className="h-20 w-32 rounded-xl overflow-hidden flex-shrink-0">
                <ImageWithFallback src={heroEvent.image} alt={heroEvent.title} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
              </div>
              <div>
                <span style={{ ...eLabelStyle, color: '#C5C0B8', display: 'block', marginBottom: '0.35rem' }}>{t('common.featured')}</span>
                <h3 className="group-hover:opacity-60 transition-opacity" style={{ fontFamily: "'Archivo Black', sans-serif", fontSize: '1.1rem', color: '#1A1A1A', letterSpacing: '-0.02em', lineHeight: 1.2 }}>{heroEvent.title}</h3>
                <span style={{ fontSize: '0.75rem', color: '#B5B0A8' }}>{heroEvent.venueName} · {heroEvent.district}</span>
              </div>
            </Link>
          </motion.div>
        )}
      </div>
    </section>
  );
}

// ─── 3D Cube Flip Mode Selector ───

const MODE_PREVIEW_DATA = [
  {
    mode: 'degen' as const, title: 'Night', subtitle: 'Nightlife, parties & underground scenes',
    image: 'https://images.unsplash.com/photo-1558877310-867ca3e64002?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxIb25nJTIwS29uZyUyMG5lb24lMjBzaWducyUyMG5pZ2h0JTIwY2l0eXxlbnwxfHx8fDE3NzMwMzI0NzN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    previewBg: '#EDFF00', previewText: '#0A0A0A', previewAccent: '#D600FF',
    previewFont: "'Space Grotesk', sans-serif",
  },
  {
    mode: 'artsy' as const, title: 'Art & Design', subtitle: 'Galleries, exhibitions & creative studios',
    image: 'https://images.unsplash.com/photo-1668566398322-6bbc9be03736?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxIb25nJTIwS29uZyUyMGFydCUyMGdhbGxlcnklMjBtb2Rlcm4lMjBpbnRlcmlvcnxlbnwxfHx8fDE3NzMwMzI0NzN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    previewBg: '#F5F1EB', previewText: '#1a1a1a', previewAccent: '#8338EC',
    previewFont: "'Playfair Display', serif",
  },
  {
    mode: 'foodie' as const, title: 'Food', subtitle: 'Restaurants, pop-ups & night markets',
    image: 'https://images.unsplash.com/photo-1552912470-ee2e96439539?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxIb25nJTIwS29uZyUyMHN0cmVldCUyMG1hcmtldCUyMGZvb2QlMjBzdGFsbHN8ZW58MXx8fHwxNzczMDMyNDcyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    previewBg: '#0A1228', previewText: '#E8F0FF', previewAccent: '#2563EB',
    previewFont: "'DM Sans', sans-serif",
  },
  {
    mode: 'family' as const, title: 'Family', subtitle: 'Kid-friendly adventures, parks & museums',
    image: 'https://images.unsplash.com/photo-1770837656797-e1178e626f6f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxIb25nJTIwS29uZyUyMGZhbWlseSUyMHBhcmslMjBvdXRkb29yJTIwbmF0dXJlfGVufDF8fHx8MTc3MzAzMjQ3M3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    previewBg: '#FFF8F0', previewText: '#2D2A32', previewAccent: '#FF8C42',
    previewFont: "'Nunito', sans-serif",
  },
  {
    mode: 'lifestyle' as const, title: 'Lifestyle', subtitle: 'Run clubs, wellness & creative meetups',
    image: 'https://images.unsplash.com/photo-1758798469179-dea5d63257ba?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb3JuaW5nJTIwb3V0ZG9vciUyMHlvZ2ElMjB3ZWxsbmVzcyUyMGdyb3VwfGVufDF8fHx8MTc3MzA0NDkwN3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    previewBg: '#122A20', previewText: '#FFFFFF', previewAccent: '#95D5B2',
    previewFont: "'Playfair Display', serif",
  },
];

const MODE_SLOT_MAP: Record<string, string> = {
  degen: 'mode-card-night',
  artsy: 'mode-card-art',
  foodie: 'mode-card-food',
  family: 'mode-card-family',
  lifestyle: 'mode-card-lifestyle',
};

function DefaultModeCards() {
  const { setMode } = useMode();
  const navigate = useNavigate();
  const tokens = getDesignTokens(null);
  const { img: siteImg } = useSiteImages();
  const scrollRef = useRef<HTMLDivElement>(null);
  const [flippingMode, setFlippingMode] = useState<string | null>(null);
  const { theme: neutralThemeMC } = useNeutralTheme();
  const navThemeValueMC = neutralThemeMC === 'dark' ? 'light' : 'dark';
  const tpl = useTemplateData('home');

  const handleModeClick = useCallback((mode: string) => {
    setFlippingMode(mode);
    setTimeout(() => {
      setMode(mode as UIMode);
      if (mode === 'lifestyle') navigate('/lifestyle');
    }, 500);
    setTimeout(() => {
      setFlippingMode(null);
    }, 900);
  }, [setMode, navigate]);

  const scroll = useCallback((direction: 'left' | 'right') => {
    if (scrollRef.current) {
      scrollRef.current.scrollBy({ left: direction === 'left' ? -380 : 380, behavior: 'smooth' });
    }
  }, []);

  return (
    <section className="py-10 sm:py-20 max-w-[1440px] mx-auto" data-nav-theme={navThemeValueMC}>
      <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.6 }}>
        <div className="mb-6 sm:mb-10 px-5 sm:px-10 lg:px-14">
          <div className="h-px w-full mb-8" style={{ backgroundColor: '#E8E4DE' }} />
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '1.5rem' }}>
            <div className="flex flex-col justify-between">
              <span style={{
                fontSize: '0.6rem',
                fontWeight: 600,
                letterSpacing: '0.18em',
                textTransform: 'uppercase' as const,
                color: '#B5B0A8',
              }}>Five Modes</span>
              <div className="hidden sm:flex xl:hidden items-center gap-2 mt-4">
                <button onClick={() => scroll('left')} className="flex items-center justify-center w-9 h-9 rounded-full transition-all hover:bg-black/5 cursor-pointer" style={{ border: '1px solid #E8E4DE' }}>
                  <ChevronLeft size={16} style={{ color: '#A09B93' }} />
                </button>
                <button onClick={() => scroll('right')} className="flex items-center justify-center w-9 h-9 rounded-full transition-all hover:bg-black/5 cursor-pointer" style={{ border: '1px solid #E8E4DE' }}>
                  <ChevronRightIcon size={16} style={{ color: '#A09B93' }} />
                </button>
              </div>
            </div>
            <div>
              <h2 style={{ fontFamily: "'Archivo Black', sans-serif", fontSize: 'clamp(1.3rem, 2.5vw, 1.8rem)', color: '#1A1A1A', letterSpacing: '-0.03em', lineHeight: 1.1 }}>{tpl['mode-cards'].sectionTitle || 'Choose your vibe'}</h2>
              <p className="mt-2 hidden sm:block" style={{ fontSize: '0.85rem', color: '#A09B93', lineHeight: 1.6 }}>{tpl['mode-cards'].sectionSubtitle || 'Each mode transforms the entire experience — design, events, and map'}</p>
            </div>
          </div>
        </div>

        {/* xl override: cards fill grid cells instead of using fixed width */}
        <style>{`@media (min-width: 1280px) { .vibe-card-item { width: auto !important; flex-shrink: 1 !important; } .vibe-card-btn { height: clamp(360px, 30vw, 440px) !important; } }`}</style>

        {/* Horizontal slider on smaller screens, full grid on xl+ */}
        <div ref={scrollRef} className="flex gap-5 overflow-x-auto pb-4 pl-5 sm:pl-10 lg:pl-14 pr-5 sm:pr-10 lg:pr-14 scrollbar-hide snap-x snap-mandatory xl:grid xl:grid-cols-5 xl:overflow-visible xl:snap-none" style={{ scrollSnapType: 'x mandatory' }}>
          {MODE_PREVIEW_DATA.map((card, i) => {
            const config = (modeConfig as any)[card.mode];
            const isFlipping = flippingMode === card.mode;
            return (
              <motion.div key={card.mode} initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} transition={{ delay: i * 0.08, duration: 0.5 }} className="vibe-card-item flex-shrink-0 snap-start" style={{ width: 'clamp(300px, 34vw, 380px)', perspective: '1200px' }}>
                <motion.button
                  onClick={() => handleModeClick(card.mode)}
                  className="vibe-card-btn relative w-full text-left cursor-pointer group"
                  style={{ transformStyle: 'preserve-3d', height: 'clamp(420px, 50vw, 520px)' }}
                  animate={isFlipping ? { rotateY: [0, -45], scale: [1, 0.88], opacity: [1, 0] } : { rotateY: 0, scale: 1, opacity: 1 }}
                  transition={isFlipping ? { duration: 0.45, ease: [0.55, 0, 1, 0.45] } : { duration: 0.3 }}
                  whileHover={!isFlipping ? { y: -6, scale: 1.01 } : undefined}
                >
                  <div className="absolute inset-0 overflow-hidden flex flex-col" style={{ borderRadius: '20px', backfaceVisibility: 'hidden', boxShadow: '0 8px 40px rgba(0,0,0,0.12), 0 2px 12px rgba(0,0,0,0.06)' }}>
                    {/* Top: Mode image */}
                    <div className="relative h-[55%] overflow-hidden">
                      <ImageWithFallback src={siteImg(MODE_SLOT_MAP[card.mode]) || card.image} alt={card.title} className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
                      <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.6) 0%, rgba(0,0,0,0.1) 50%, transparent 100%)' }} />
                      <div className="absolute top-4 left-4 flex items-center gap-1.5 px-2.5 py-1" style={{ backgroundColor: `${config?.color || card.previewAccent}20`, backdropFilter: 'blur(8px)', borderRadius: '8px', border: `1px solid ${config?.color || card.previewAccent}30` }}>
                        <CIcon id={config?.emoji || card.mode} size={12} style={{ filter: 'brightness(10)' }} />
                        <span style={{ fontSize: '0.65rem', color: '#fff', fontWeight: 600 }}>{config?.label || card.title}</span>
                      </div>
                      <div className="absolute bottom-4 left-4 right-4">
                        <h3 style={{ fontFamily: "'Inter', sans-serif", fontSize: '1.3rem', fontWeight: 700, color: '#fff', letterSpacing: '-0.02em', lineHeight: 1.15 }}>{card.title}</h3>
                        <p className="mt-1" style={{ fontSize: '0.75rem', color: 'rgba(255,255,255,0.55)', lineHeight: 1.4, minHeight: '2.8em' }}>{card.subtitle}</p>
                      </div>
                    </div>

                    {/* Bottom: Mode logo rendered at 150% nav size */}
                    <div className="flex-1 relative overflow-hidden flex items-center justify-center" style={{ backgroundColor: card.previewBg }}>
                      <div className="flex flex-col items-center justify-center gap-2 px-6 transition-transform duration-500 group-hover:scale-105">
                        {card.mode === 'degen' && (
                          <div className="flex items-center gap-2.5">
                            <span style={{ fontFamily: "'Space Grotesk', sans-serif", color: '#0A0A0A', fontSize: '1.4rem', fontWeight: 700, letterSpacing: '-0.03em', textTransform: 'uppercase' as const, lineHeight: 1 }}>CULTIVE</span>
                            <span className="px-2.5 py-0.5" style={{ backgroundColor: '#D600FF', color: '#fff', fontFamily: "'Space Grotesk', sans-serif", fontSize: '0.7rem', fontWeight: 700, borderRadius: '3px', letterSpacing: '0.06em', lineHeight: '1.6' }}>NIGHT</span>
                          </div>
                        )}
                        {card.mode === 'artsy' && (
                          <div className="flex flex-col items-center">
                            <span style={{ fontFamily: "'Playfair Display', serif", color: '#1a1a1a', fontSize: '1.15rem', letterSpacing: '0.3em', textTransform: 'uppercase' as const, lineHeight: 1 }}>CULTIVE</span>
                            <span className="mt-2" style={{ color: '#999', fontSize: '0.8rem', letterSpacing: '0.12em', lineHeight: 1 }}>文化活</span>
                          </div>
                        )}
                        {card.mode === 'foodie' && (
                          <div className="flex flex-col items-center">
                            <span style={{ fontFamily: "'DM Sans', sans-serif", color: '#E8F0FF', fontSize: '1.4rem', fontWeight: 700, letterSpacing: '-0.02em', lineHeight: 1 }}>CULTIVE</span>
                            <div className="flex items-center gap-2 mt-2">
                              <div style={{ width: 14, height: 1.5, backgroundColor: '#2563EB', borderRadius: 1 }} />
                              <span style={{ color: 'rgba(232,240,255,0.5)', fontSize: '0.65rem', letterSpacing: '0.12em', fontWeight: 500, fontFamily: "'DM Sans', sans-serif", lineHeight: 1 }}>美食 · FOOD</span>
                              <div style={{ width: 14, height: 1.5, backgroundColor: '#2563EB', borderRadius: 1 }} />
                            </div>
                          </div>
                        )}
                        {card.mode === 'family' && (
                          <div className="flex flex-col items-center">
                            <span style={{ fontFamily: "'Nunito', sans-serif", color: '#2D2A32', fontSize: '1.4rem', fontWeight: 900, letterSpacing: '-0.01em', lineHeight: 1 }}>CULTIVE</span>
                            <div className="flex items-center gap-1.5 mt-2">
                              <Star size={9} style={{ color: '#FF8C42', fill: '#FF8C42' }} />
                              <span style={{ color: '#FF8C42', fontSize: '0.6rem', letterSpacing: '0.12em', fontWeight: 700, fontFamily: "'Nunito', sans-serif", lineHeight: 1 }}>FAMILY</span>
                              <Star size={9} style={{ color: '#FF8C42', fill: '#FF8C42' }} />
                            </div>
                          </div>
                        )}
                        {card.mode === 'lifestyle' && (
                          <div className="flex items-center gap-2.5">
                            <span style={{ fontFamily: "'Playfair Display', serif", fontSize: '1.4rem', fontWeight: 900, color: '#FFFFFF', letterSpacing: '-0.02em', lineHeight: 1 }}>CULTIVE</span>
                            <span className="px-2.5 py-0.5" style={{ backgroundColor: '#2D6A4F', color: '#fff', fontFamily: "'Playfair Display', serif", fontSize: '0.7rem', fontWeight: 700, borderRadius: '9999px', letterSpacing: '0.04em', fontStyle: 'italic', lineHeight: '1.6' }}>lifestyle.</span>
                          </div>
                        )}
                        <div className="flex items-center gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity duration-300 mt-1">
                          <span style={{ fontSize: '0.6rem', color: card.previewAccent, fontWeight: 600, fontFamily: "'Inter', sans-serif", letterSpacing: '0.08em' }}>ENTER MODE</span>
                          <ArrowRight size={10} style={{ color: card.previewAccent }} className="transition-transform group-hover:translate-x-1" />
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.button>
              </motion.div>
            );
          })}
        </div>
      </motion.div>

      {/* Mode Transition Overlay */}
      <AnimatePresence>
        {flippingMode && (() => {
          const fc = MODE_PREVIEW_DATA.find(c => c.mode === flippingMode);
          if (!fc) return null;
          return (
            <motion.div
              className="fixed inset-0 z-[2000] flex items-center justify-center"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.25, ease: 'easeOut' }}
            >
              {/* Background — fast scale-up from center */}
              <motion.div
                className="absolute inset-0"
                style={{ backgroundColor: fc.previewBg }}
                initial={{ scale: 1.1, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
              />
              {/* Center content — cube face reveal */}
              <motion.div className="relative z-10 flex flex-col items-center gap-3">
                <motion.div
                  initial={{ scale: 0.5, opacity: 0, rotateX: 30 }}
                  animate={{ scale: 1, opacity: 1, rotateX: 0 }}
                  transition={{ delay: 0.15, duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
                  className="w-14 h-14 sm:w-16 sm:h-16 flex items-center justify-center rounded-2xl"
                  style={{ backgroundColor: `${fc.previewAccent}15`, border: `1px solid ${fc.previewAccent}25` }}
                >
                  <CIcon id={(modeConfig as any)[fc.mode]?.emoji || fc.mode} size={26} />
                </motion.div>
                <motion.h2
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.25, duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
                  style={{
                    fontFamily: fc.previewFont,
                    fontSize: 'clamp(1.4rem, 3vw, 2rem)',
                    fontWeight: fc.mode === 'degen' ? 700 : 600,
                    color: fc.previewText,
                    textTransform: fc.mode === 'degen' ? 'uppercase' : 'none',
                    letterSpacing: '-0.02em',
                  }}
                >
                  {fc.title}
                </motion.h2>
                <motion.div
                  className="h-0.5 rounded-full"
                  style={{ backgroundColor: fc.previewAccent, width: 32 }}
                  initial={{ scaleX: 0 }}
                  animate={{ scaleX: 1 }}
                  transition={{ delay: 0.35, duration: 0.25 }}
                />
                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 0.5 }}
                  transition={{ delay: 0.4, duration: 0.2 }}
                  style={{ fontSize: '0.75rem', color: fc.previewText, fontFamily: "'Inter', sans-serif" }}
                >
                  Loading experience...
                </motion.p>
              </motion.div>
            </motion.div>
          );
        })()}
      </AnimatePresence>
    </section>
  );
}

function DefaultUpcomingEvents() {
  const { events, venues } = useData();
  const { t, i18n } = useTranslation();
  const lang = i18n.language;
  const isZh = lang?.startsWith('zh');
  const navigate = useNavigate();
  const tpl = useTemplateData('home');
  const maxEvents = Number(tpl['upcoming-events']?.maxItems) || 3;
  const sectionTitle = tpl['upcoming-events']?.sectionTitle || (isZh ? '在地圖上探索' : 'Explore on the map');

  // Gather pins: events with coordinates, or fall back to their venue coordinates
  const pins = useMemo(() => {
    const upcoming = events
      .filter((e) => e.status === 'upcoming' || e.status === 'ongoing')
      .slice(0, 20);

    const venueMap = new Map(venues.map(v => [v.id, v]));

    return upcoming
      .map((ev) => {
        const lat = ev.lat ?? venueMap.get(ev.venueId)?.lat;
        const lng = ev.lng ?? venueMap.get(ev.venueId)?.lng;
        if (lat == null || lng == null) return null;
        return { id: ev.id, lat, lng, title: getBilingualField(ev, 'title', lang), district: getBilingualField(ev, 'district', lang) || ev.district, category: ev.category };
      })
      .filter(Boolean) as { id: string; lat: number; lng: number; title: string; district: string; category: string }[];
  }, [events, venues, lang]);

  // Top 3 upcoming events for the sidebar cards
  const topEvents = useMemo(() => {
    return events
      .filter((e) => e.status === 'upcoming' || e.status === 'ongoing')
      .slice(0, maxEvents)
      .map((ev) => ({
        ...ev,
        titleLocalized: getBilingualField(ev, 'title', lang) || ev.title,
        districtLocalized: getBilingualField(ev, 'district', lang) || ev.district,
        venueLocalized: getBilingualField(ev, 'venueName', lang) || ev.venueName,
        dateFormatted: (() => {
          const d = parseEventDate(ev.date);
          if (!d) return ev.date || '';
          return d.toLocaleDateString(isZh ? 'zh-HK' : 'en', { month: 'short', day: 'numeric' });
        })(),
      }));
  }, [events, lang, maxEvents]);

  // Simple dot marker
  const dotIcon = useMemo(() => L.divIcon({
    className: '',
    html: `<div style="width:10px;height:10px;border-radius:50%;background:#1A1A1A;border:2px solid #fff;box-shadow:0 1px 4px rgba(0,0,0,0.25);"></div>`,
    iconSize: [10, 10],
    iconAnchor: [5, 5],
  }), []);

  // Highlighted dot for top events
  const highlightIcon = useMemo(() => L.divIcon({
    className: '',
    html: `<div style="width:14px;height:14px;border-radius:50%;background:#1A1A1A;border:2.5px solid #fff;box-shadow:0 0 0 3px rgba(26,26,26,0.15), 0 2px 8px rgba(0,0,0,0.3);"></div>`,
    iconSize: [14, 14],
    iconAnchor: [7, 7],
  }), []);

  const eventCount = events.filter(e => e.status === 'upcoming' || e.status === 'ongoing').length;

  // IDs of top events so we can highlight their pins
  const topEventIds = useMemo(() => new Set(topEvents.map(e => e.id)), [topEvents]);

  return (
    <section className="px-4 sm:px-6 lg:px-8 py-6 sm:py-16 max-w-[1440px] mx-auto">
      <div className="mb-8 sm:mb-12 px-6 lg:px-6">
        <div className="h-px w-full mb-8" style={{ backgroundColor: '#E8E4DE' }} />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '1.5rem' }}>
          <div>
            <span style={{ ...eLabelStyle }}>Map</span>
          </div>
          <div className="flex items-end justify-between">
            <h2 style={{ fontFamily: "'Archivo Black', sans-serif", fontSize: 'clamp(1.3rem, 2.5vw, 1.8rem)', color: '#1A1A1A', letterSpacing: '-0.03em', lineHeight: 1.1 }}>
              {sectionTitle}
            </h2>
            <Link to="/map" className="flex items-center gap-1.5 text-sm transition-all hover:opacity-70" style={{ color: '#A09B93', fontWeight: 500 }}>
              {isZh ? '打開地圖' : 'Open map'} <ArrowRight size={14} />
            </Link>
          </div>
        </div>
      </div>

      {/* Map + Event Cards side by side */}
      <div className="flex gap-5" style={{ height: 'clamp(320px, 35vw, 460px)' }}>
        {/* Map preview — clickable */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="relative overflow-hidden cursor-pointer group flex-1"
          style={{ borderRadius: '20px' }}
          onClick={() => navigate('/map')}
        >
          {/* Leaflet map — non-interactive preview */}
          <div className="absolute inset-0" style={{ pointerEvents: 'none' }}>
            <MapContainer
              center={[22.28, 114.17]}
              zoom={12}
              className="w-full h-full"
              zoomControl={false}
            >
              <TileLayer url="https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png" />
              {pins.map((pin) => (
                <Marker key={pin.id} position={[pin.lat, pin.lng]} icon={topEventIds.has(pin.id) ? highlightIcon : dotIcon} />
              ))}
            </MapContainer>
          </div>

          {/* Gradient overlays */}
          <div className="absolute inset-0 pointer-events-none" style={{
            background: 'linear-gradient(to bottom, rgba(250,250,248,0.95) 0%, rgba(250,250,248,0.3) 25%, transparent 50%, rgba(26,26,26,0.05) 80%, rgba(26,26,26,0.4) 100%)',
          }} />

          {/* Top-left editorial label */}
          <div className="absolute top-6 left-7 z-10 pointer-events-none">
            <span style={{
              fontFamily: "'Archivo Black', sans-serif",
              fontSize: '2.5rem',
              color: '#EDEAE5',
              letterSpacing: '-0.05em',
              lineHeight: 1,
            }}>
              {String(eventCount).padStart(2, '0')}
            </span>
            <span className="block mt-1" style={{ ...eLabelStyle, color: '#C5C0B8' }}>
              {isZh ? '即將舉行的活動' : 'upcoming events'}
            </span>
          </div>

          {/* Bottom-right CTA */}
          <div className="absolute bottom-6 right-7 z-10 pointer-events-none">
            <div className="flex items-center gap-2 px-5 py-3 transition-all group-hover:scale-105 group-hover:shadow-lg"
              style={{
                backgroundColor: '#1A1A1A',
                color: '#fff',
                borderRadius: '12px',
                fontSize: '0.8rem',
                fontWeight: 600,
              }}
            >
              <MapIcon size={14} />
              {isZh ? '探索完整地圖' : 'Explore full map'}
              <ArrowUpRight size={13} className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </div>
          </div>

          {/* Vertical branding watermark */}
          <div className="absolute bottom-6 left-7 z-10 pointer-events-none">
            <span style={{
              fontFamily: "'Archivo Black', sans-serif",
              fontSize: '0.55rem',
              color: 'rgba(26,26,26,0.08)',
              letterSpacing: '-0.03em',
              writingMode: 'vertical-lr' as const,
            }}>
              CULTIVE
            </span>
          </div>
        </motion.div>

        {/* Right sidebar — Top 3 events */}
        <motion.div
          initial={{ opacity: 0, x: 16 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.15 }}
          className="hidden lg:flex flex-col gap-3"
          style={{ width: '320px', flexShrink: 0 }}
        >
          <div className="flex items-center justify-between mb-1">
            <span style={{ ...eLabelStyle, color: '#B5B0A8' }}>
              {isZh ? '本週精選' : 'This week'}
            </span>
          </div>

          {topEvents.map((ev, i) => (
            <Link
              key={ev.id}
              to={getEventLink(ev)}
              className="group flex gap-3.5 p-3.5 transition-all hover:shadow-md"
              style={{
                backgroundColor: '#fff',
                borderRadius: '16px',
                border: '1px solid #F0EDE8',
                flex: 1,
                minHeight: 0,
              }}
            >
              {/* Number */}
              <div className="flex-shrink-0 flex items-start pt-0.5">
                <span style={{
                  fontFamily: "'Archivo Black', sans-serif",
                  fontSize: '1.6rem',
                  color: '#EDEAE5',
                  lineHeight: 1,
                  letterSpacing: '-0.04em',
                }}>
                  {String(i + 1).padStart(2, '0')}
                </span>
              </div>

              {/* Info */}
              <div className="flex-1 min-w-0 flex flex-col justify-center">
                <h4 className="line-clamp-2 group-hover:opacity-70 transition-opacity" style={{
                  fontSize: '0.85rem',
                  fontWeight: 600,
                  color: '#1A1A1A',
                  lineHeight: 1.3,
                  letterSpacing: '-0.01em',
                }}>
                  {ev.titleLocalized}
                </h4>
                <div className="flex items-center gap-1.5 mt-1.5">
                  <MapPin size={11} style={{ color: '#C5C0B8', flexShrink: 0 }} />
                  <span className="line-clamp-1" style={{ fontSize: '0.7rem', color: '#A09B93' }}>
                    {ev.venueLocalized || ev.districtLocalized}
                  </span>
                </div>
                <div className="flex items-center gap-1.5 mt-1">
                  <Clock size={11} style={{ color: '#C5C0B8', flexShrink: 0 }} />
                  <span style={{ fontSize: '0.7rem', color: '#A09B93' }}>
                    {ev.dateFormatted}
                  </span>
                </div>
              </div>

              {/* Thumbnail */}
              {ev.image && (
                <div className="flex-shrink-0 w-16 h-16 rounded-xl overflow-hidden self-center">
                  <ImageWithFallback
                    src={ev.image}
                    alt={ev.titleLocalized}
                    className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                </div>
              )}
            </Link>
          ))}

          {/* View all link */}
          <Link
            to="/events"
            className="flex items-center justify-center gap-1.5 py-2.5 mt-auto transition-all hover:opacity-70"
            style={{
              fontSize: '0.75rem',
              color: '#A09B93',
              fontWeight: 500,
              border: '1px solid #F0EDE8',
              borderRadius: '12px',
            }}
          >
            {isZh ? '查看所有活動' : 'View all events'} <ArrowRight size={12} />
          </Link>
        </motion.div>
      </div>
    </section>
  );
}

function DefaultPopularVenues() {
  const { venues } = useData();
  const { t, i18n } = useTranslation();
  const lang = i18n.language;
  const isZh = lang === 'zh-Hant' || lang.startsWith('zh');
  const tokens = getDesignTokens(null);
  const tpl = useTemplateData('home');
  const maxVenues = Math.min(Number(tpl['popular-venues'].maxItems) || 5, 5);
  const popular = venues.sort((a, b) => b.pastRecaps - a.pastRecaps).slice(0, maxVenues);

  return (
    <section className="px-4 sm:px-6 lg:px-8 py-6 sm:py-16 max-w-[1440px] mx-auto">
      <div className="mb-8 sm:mb-12 px-6 lg:px-6">
        <div className="h-px w-full mb-8" style={{ backgroundColor: '#E8E4DE' }} />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '1.5rem' }}>
          <div>
            <span style={{ ...eLabelStyle }}>Places</span>
          </div>
          <div className="flex items-end justify-between">
            <h2 style={{ fontFamily: "'Archivo Black', sans-serif", fontSize: 'clamp(1.3rem, 2.5vw, 1.8rem)', color: '#1A1A1A', letterSpacing: '-0.03em', lineHeight: 1.1 }}>{tpl['popular-venues'].sectionTitle || t('default.popularVenues')}</h2>
            <Link to="/map" className="flex items-center gap-1.5 text-sm transition-all hover:opacity-70" style={{ color: '#A09B93', fontWeight: 500 }}>{t('modeHome.mapView')} <ArrowRight size={14} /></Link>
          </div>
        </div>
      </div>
      {/* Mobile: horizontal scroll | Desktop: 5-col grid */}
      <div className="flex sm:grid sm:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4 overflow-x-auto sm:overflow-visible pb-2 sm:pb-0 -mx-4 px-4 sm:mx-0 sm:px-0 scrollbar-hide snap-x snap-mandatory sm:snap-none">
        {popular.map((venue, i) => (
          <motion.div key={venue.id} initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} transition={{ delay: i * 0.06 }} className="flex-shrink-0 w-[140px] sm:w-auto snap-start">
            <Link to={`/venue/${venue.id}`} className="group block">
              <div className="relative aspect-[3/4] overflow-hidden mb-2 sm:mb-3" style={{ borderRadius: '16px' }}>
                <ImageWithFallback src={venue.image} alt={venue.name} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
                <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.4) 0%, transparent 50%)' }} />
                <div className="absolute bottom-2 left-2 right-2 sm:bottom-3 sm:left-3 sm:right-3">
                  <div className="flex items-center gap-1.5">
                    <CIcon id={venue.category} size={12} mode="auto" style={{ color: '#fff' }} />
                    <span className="text-[10px] sm:text-[11px] text-white/70">{venue.district}</span>
                  </div>
                </div>
              </div>
              <h4 className="text-xs sm:text-sm group-hover:opacity-70 transition-opacity line-clamp-1" style={{ color: tokens.textPrimary, fontWeight: 500 }}>{getBilingualField(venue, 'name', lang)}</h4>
              <p className="text-[10px] sm:text-xs mt-0.5 line-clamp-1" style={{ color: tokens.textMuted }}>{isZh ? venue.name : venue.nameZh}</p>
            </Link>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

function DefaultMapCTA() {
  const tokens = getDesignTokens(null);
  const { t } = useTranslation();
  return (
    <section className="px-4 sm:px-6 lg:px-8 py-6 sm:py-16 max-w-[1440px] mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="relative overflow-hidden p-5 sm:p-12 lg:p-16"
        style={{ borderRadius: '20px', backgroundColor: '#1A1A1A' }}
      >
        <div className="relative z-10" style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '2rem' }}>
          {/* Left third — vertical branding + label */}
          <div className="flex flex-col justify-between">
            <span style={{ ...eLabelStyle, color: 'rgba(255,255,255,0.2)' }}>Explore</span>
            <span style={{
              fontFamily: "'Archivo Black', sans-serif",
              fontSize: '0.6rem',
              color: 'rgba(255,255,255,0.1)',
              letterSpacing: '-0.03em',
              writingMode: 'vertical-lr' as const,
            }}>
              CULTIVE
            </span>
          </div>

          {/* Right two-thirds — content */}
          <div>
            <h2 className="mb-4" style={{ fontFamily: "'Archivo Black', sans-serif", fontSize: 'clamp(1.4rem, 3vw, 2.2rem)', color: '#ffffff', letterSpacing: '-0.03em', lineHeight: 1.1 }}>
              {t('default.exploreHKTitle')}<br /> {t('default.exploreHKAccent')}
            </h2>
            <p className="mb-8 max-w-md" style={{ fontSize: '0.85rem', color: 'rgba(255,255,255,0.4)', lineHeight: 1.65 }}>{t('default.exploreHKBody')}</p>
            <Link to="/map" className="inline-flex items-center gap-2 px-6 py-3 text-sm transition-all hover:opacity-90" style={{ backgroundColor: '#ffffff', color: '#1A1A1A', borderRadius: '12px', fontWeight: 600 }}><MapIcon size={15} /> {t('default.openMap')}</Link>
          </div>
        </div>
      </motion.div>
    </section>
  );
}

function DefaultContributeCTA() {
  const tokens = getDesignTokens(null);
  const { t } = useTranslation();
  return (
    <section className="px-4 sm:px-6 lg:px-8 py-6 sm:py-16 max-w-[1440px] mx-auto">
      <div className="h-px w-full mb-12" style={{ backgroundColor: '#E8E4DE' }} />
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '2rem' }}
      >
        {/* Left third — label */}
        <div>
          <span style={{ ...eLabelStyle }}>Community</span>
        </div>

        {/* Right two-thirds — content */}
        <div>
          <h2 className="mb-4" style={{ fontFamily: "'Archivo Black', sans-serif", fontSize: 'clamp(1.3rem, 2.5vw, 1.8rem)', color: '#1A1A1A', letterSpacing: '-0.03em', lineHeight: 1.1 }}>
            Know something happening?
          </h2>
          <p className="mb-8 max-w-lg" style={{ fontSize: '0.85rem', color: '#A09B93', lineHeight: 1.65 }}>
            Share events, pop-ups, and cultural happenings with the community. Paste an Instagram link — our AI does the rest.
          </p>

          <div className="flex flex-col gap-4 mb-8 max-w-sm">
            {[
              { step: '01', text: 'Paste an Instagram or event link' },
              { step: '02', text: 'AI auto-fills event details' },
              { step: '03', text: 'Review and submit for publishing' },
            ].map((item) => (
              <div key={item.step} className="flex items-baseline gap-4">
                <span style={{ fontFamily: "'Archivo Black', sans-serif", fontSize: '0.7rem', color: '#C5C0B8', letterSpacing: '-0.02em' }}>{item.step}</span>
                <span style={{ fontSize: '0.8rem', color: '#1A1A1A', fontWeight: 500 }}>{item.text}</span>
              </div>
            ))}
          </div>

          <div className="flex flex-wrap gap-3">
            <Link to="/contribute" className="inline-flex items-center gap-2 px-6 py-3 text-sm transition-all hover:opacity-90" style={{ backgroundColor: '#1A1A1A', color: '#fff', borderRadius: '12px', fontWeight: 600 }}>
              <Plus size={15} /> {t('common.submitEvent')}
            </Link>
            <Link to="/contribute" className="inline-flex items-center gap-2 px-6 py-3 text-sm transition-all hover:opacity-80" style={{ border: '1px solid #E8E4DE', color: '#1A1A1A', borderRadius: '12px', fontWeight: 500 }}>
              Learn More <ArrowRight size={14} />
            </Link>
          </div>
        </div>
      </motion.div>
    </section>
  );
}

function DefaultFooter() {
  const tokens = getDesignTokens(null);
  const { setMode } = useMode();
  const { t, i18n } = useTranslation();
  const isZh = i18n.language?.startsWith('zh');

  // Footer nav links with translated labels
  const footerLinks: [string, string][] = [
    [t('nav.discover'), '/'],
    [t('nav.map'), '/map'],
    [t('nav.events'), '/events'],
    [t('nav.recaps'), '/recaps'],
    [t('nav.contribute'), '/contribute'],
    [t('nav.about'), '/about'],
  ];

  return (
    <footer className="px-4 sm:px-6 lg:px-8 py-8 sm:py-14" style={{ borderTop: `1px solid ${tokens.cardBorder}` }}>
      <div className="max-w-[1440px] mx-auto">
        <div className="flex flex-col gap-6 sm:grid sm:grid-cols-2 lg:grid-cols-4 sm:gap-8">
          <div>
            <div className="flex items-center gap-2 mb-2 sm:mb-3">
              <span style={{ fontFamily: "'Archivo Black', sans-serif", fontSize: '1rem', color: tokens.textPrimary, letterSpacing: '-0.03em' }}>CULTIVE</span>
              <span style={{ fontSize: '0.55rem', color: tokens.textMuted, fontFamily: "'Noto Sans HK', sans-serif" }}>文化活</span>
            </div>
            <p className="hidden sm:block" style={{ fontSize: '0.8rem', color: tokens.textMuted, maxWidth: '240px', lineHeight: 1.65 }}>{t('footer.tagline')}</p>
          </div>
          <div>
            <h4 className="mb-2 sm:mb-3 text-xs" style={{ color: tokens.textMuted, fontWeight: 600, letterSpacing: '0.05em', textTransform: 'uppercase' }}>{t('footer.explore')}</h4>
            <div className="space-y-1.5 sm:space-y-2.5">
              {footerLinks.map(([label, path]) => (
                <Link key={path} to={path} className="block text-xs sm:text-sm transition-colors hover:opacity-70" style={{ color: tokens.textSecondary }}>{label}</Link>
              ))}
            </div>
          </div>
          <div>
            <h4 className="mb-2 sm:mb-3 text-xs" style={{ color: tokens.textMuted, fontWeight: 600, letterSpacing: '0.05em', textTransform: 'uppercase' }}>{t('footer.modes')}</h4>
            <div className="space-y-1.5 sm:space-y-2.5">
              {Object.entries(modeConfig).map(([key, config]) => (<button key={key} onClick={() => setMode(key as Mode)} className="flex items-center gap-2 text-xs sm:text-sm cursor-pointer bg-transparent border-none p-0 hover:opacity-70 transition-opacity" style={{ color: tokens.textSecondary }}><CIcon id={key} size={14} mode={key as Mode} animated /> {config.label}</button>))}
            </div>
          </div>
          <div className="hidden lg:block">
            <h4 className="mb-2 sm:mb-3 text-xs" style={{ color: tokens.textMuted, fontWeight: 600, letterSpacing: '0.05em', textTransform: 'uppercase' }}>{t('footer.connect')}</h4>
            <div className="space-y-1.5 sm:space-y-2.5">
              {['Instagram', 'TikTok', 'info@cultive.city'].map((item) => (<span key={item} className="block text-xs sm:text-sm" style={{ color: tokens.textSecondary }}>{item}</span>))}
              <Link to="/contribute" className="inline-flex items-center gap-1.5 mt-2 text-xs sm:text-sm transition-opacity hover:opacity-70" style={{ color: tokens.textPrimary, fontWeight: 500 }}>
                {t('common.submitEvent')}
              </Link>
            </div>
          </div>
        </div>
        <div className="mt-6 sm:mt-12 pt-4 sm:pt-6 flex flex-wrap items-center justify-between gap-2 sm:gap-4" style={{ borderTop: `1px solid ${tokens.cardBorder}` }}>
          <span className="text-[10px] sm:text-xs" style={{ color: tokens.textMuted }}>{t('common.copyright')}</span>
          <div className="flex items-center gap-3 sm:gap-4">
            <Link to="/privacy" className="text-[10px] sm:text-xs transition-opacity hover:opacity-70" style={{ color: tokens.textMuted }}>{t('footer.privacy')}</Link>
            <Link to="/terms" className="text-[10px] sm:text-xs transition-opacity hover:opacity-70" style={{ color: tokens.textMuted }}>{t('footer.terms')}</Link>
            <span className="text-[10px] sm:text-xs" style={{ color: tokens.textMuted }}>{t('common.madeInHK')}</span>
          </div>
        </div>
      </div>
    </footer>
  );
}

export function DefaultHomePage() {
  return (
    <div>
      {/* Mobile: Editorial "friend with taste" layout */}
      <MobileEditorialHomeWithTheme />
      {/* Desktop: Full cinematic layout */}
      <div className="hidden md:block" style={{ backgroundColor: BG }}>
        <FeaturedHero />
        <DefaultModeCards />
        <ThingsToDo />
        <DefaultUpcomingEvents />
        <DefaultPopularVenues />
        <DefaultContributeCTA />
        <DefaultFooter />
      </div>
      <style>{`.scrollbar-hide::-webkit-scrollbar{display:none}.scrollbar-hide{-ms-overflow-style:none;scrollbar-width:none}`}</style>
    </div>
  );
}