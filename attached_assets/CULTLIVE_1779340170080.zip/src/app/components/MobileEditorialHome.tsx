import { useState, useCallback } from 'react';
import { Link, useNavigate } from 'react-router';
import { useTranslation } from 'react-i18next';
import { motion } from 'motion/react';
import { ArrowUpRight, Send, Sun, Moon } from 'lucide-react';
import { useData } from '../context/DataContext';
import { useMode } from '../context/ModeContext';
import type { UIMode } from '../context/ModeContext';
import { modeConfig } from '../data/mock-data';
import { parseEventDate } from '../utils/date-helpers';
import { getEventLink } from '../utils/event-helpers';
import { getBilingualField } from '../utils/bilingual';
import { useAuth } from '../context/AuthContext';
import { CIcon } from './CIcon';
import { useWeeklyPicks } from '../hooks/useWeeklyPicks';
import { OnboardingQuiz, ResetTasteButton, type TasteProfile } from './OnboardingQuiz';
import { useNeutralTheme, NeutralThemeProvider } from '../context/NeutralThemeContext';

// ═══════════════════════════════════════════════════════════════════
// MOBILE EDITORIAL HOMEPAGE — Rule of Thirds spatial system
//
// Every section uses a consistent 1/3 + 2/3 column rhythm.
// Vertical zones anchor key moments at 33vh intervals.
// Labels live in the left third, content in the right two-thirds.
// ═══════════════════════════════════════════════════════════════════

const WHATSAPP_CHANNEL_URL = 'https://whatsapp.com/channel/cultive';

function getIssueDate(): string {
  const now = new Date();
  const m = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  return `${m[now.getMonth()]} ${now.getDate()}, ${now.getFullYear()}`;
}

function getWeekNumber(): number {
  const now = new Date();
  const start = new Date(now.getFullYear(), 0, 1);
  return Math.ceil(((now.getTime() - start.getTime()) / 86400000 + start.getDay() + 1) / 7);
}

function formatPickDate(dateStr: string, time?: string): string {
  const d = parseEventDate(dateStr);
  if (!d) return time || '';
  const days = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
  return `${days[d.getDay()]}${time ? ' · ' + time : ''}`;
}

// Shared micro-label style
const labelStyle: React.CSSProperties = {
  fontSize: '0.55rem',
  fontWeight: 600,
  letterSpacing: '0.18em',
  textTransform: 'uppercase',
  color: 'var(--n-muted)',
};

// ─── Masthead — 33vh hero, headline at bottom-third intersection ───
function Masthead() {
  const { i18n } = useTranslation();
  const isZh = i18n.language?.startsWith('zh');
  const { theme, toggleTheme } = useNeutralTheme();

  return (
    <header
      className="flex flex-col justify-end"
      style={{ backgroundColor: 'var(--n-bg)', minHeight: '33vh', padding: '0 6.5vw 6vh' }}
    >
      {/* Top meta — pushed to the right third */}
      <div className="flex items-baseline justify-between mb-4">
        <span style={{ ...labelStyle, fontFamily: "'Archivo Black', sans-serif" }}>
          {getIssueDate()}
        </span>
        <button
          onClick={toggleTheme}
          className="cursor-pointer transition-opacity hover:opacity-60"
          style={{ background: 'none', border: 'none', color: 'var(--n-muted)', padding: '0.25rem' }}
          aria-label={theme === 'light' ? 'Switch to dark mode' : 'Switch to light mode'}
        >
          {theme === 'light' ? <Moon size={13} /> : <Sun size={13} />}
        </button>
      </div>

      <div className="h-px w-full" style={{ backgroundColor: 'var(--n-text)' }} />

      {/* Headline — occupies left 2/3 of width */}
      <div style={{ maxWidth: '66.6%', marginTop: '2rem' }}>
        <h1 style={{
          fontFamily: "'Archivo Black', sans-serif",
          fontSize: 'clamp(2rem, 9vw, 2.6rem)',
          lineHeight: 0.95,
          color: 'var(--n-text)',
          letterSpacing: '-0.04em',
        }}>
          {isZh ? '本週精選' : 'This week'}
        </h1>
      </div>

      {/* Subline — offset to right, starts at 1/3 mark */}
      <p style={{
        fontSize: '0.8rem',
        lineHeight: 1.55,
        color: 'var(--n-secondary)',
        marginTop: '1.25rem',
        paddingLeft: '33.3%',
      }}>
        {isZh
          ? '香港值得你出門的事。'
          : "What's worth leaving the house for."}
      </p>
    </header>
  );
}

// ─── 3 Picks — number in left 1/3, content in right 2/3 ───
function Picks() {
  const { i18n } = useTranslation();
  const lang = i18n.language;
  const isZh = lang?.startsWith('zh');
  const { user } = useAuth();
  const { picks, tier, loading, hasQuiz, refreshQuiz } = useWeeklyPicks();
  const [showQuiz, setShowQuiz] = useState(false);
  const [quizDone, setQuizDone] = useState(hasQuiz);

  const handleQuizComplete = useCallback((_profile: TasteProfile) => {
    setQuizDone(true);
    setShowQuiz(false);
    refreshQuiz();
  }, [refreshQuiz]);

  const tierLabel = {
    curated: isZh ? '編輯精選' : 'Curated',
    personalized: isZh ? '為你推薦' : 'For you',
    quiz: isZh ? '你的口味' : 'Your taste',
    default: isZh ? '精選' : 'Picks',
  }[tier];

  return (
    <section style={{ backgroundColor: 'var(--n-bg)', padding: '0 6.5vw 2rem' }}>
      {/* Section header — label left-third, action right-aligned */}
      <div className="flex items-center justify-between mb-8">
        <span style={labelStyle}>{tierLabel}</span>
        {!user && !quizDone && !showQuiz && (
          <button
            onClick={() => setShowQuiz(true)}
            className="cursor-pointer"
            style={{
              ...labelStyle,
              color: 'var(--n-secondary)',
              background: 'none',
              border: 'none',
              borderBottom: '1px solid var(--n-border-subtle)',
              paddingBottom: '1px',
            }}
          >
            {isZh ? '個人化' : 'Personalize'}
          </button>
        )}
        {quizDone && (
          <ResetTasteButton onReset={() => { setQuizDone(false); refreshQuiz(); }} />
        )}
      </div>

      {/* Quiz inline */}
      {showQuiz && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          className="mb-10 overflow-hidden"
          style={{ border: '1px solid var(--n-border)', borderRadius: '2px' }}
        >
          <OnboardingQuiz onComplete={handleQuizComplete} compact />
        </motion.div>
      )}

      {/* Pick cards — 1/3 + 2/3 grid */}
      {loading ? (
        <div className="flex justify-center py-20">
          <div className="w-2.5 h-2.5 rounded-full animate-pulse" style={{ backgroundColor: '#DDD' }} />
        </div>
      ) : (
        <div>
          {picks.map((event, i) => (
            <motion.div
              key={event.id}
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08, duration: 0.4 }}
            >
              <Link to={getEventLink(event)} className="block group">
                <div
                  style={{
                    borderTop: '1px solid var(--n-border)',
                    display: 'grid',
                    gridTemplateColumns: '1fr 2fr',
                    gap: '0',
                    paddingTop: '1.75rem',
                    paddingBottom: '1.75rem',
                  }}
                >
                  {/* Left third — number + category */}
                  <div className="flex flex-col justify-between pr-4">
                    <span style={{
                      fontFamily: "'Archivo Black', sans-serif",
                      fontSize: '2.5rem',
                      lineHeight: 1,
                      color: 'var(--n-number)',
                      letterSpacing: '-0.05em',
                    }}>
                      {String(i + 1).padStart(2, '0')}
                    </span>
                    <span style={{
                      fontSize: '0.5rem',
                      fontWeight: 600,
                      letterSpacing: '0.12em',
                      textTransform: 'uppercase',
                      color: '#C5C0B8',
                      marginTop: '0.75rem',
                    }}>
                      {event.category}
                    </span>
                  </div>

                  {/* Right two-thirds — content */}
                  <div className="flex flex-col justify-between">
                    <div>
                      <h3
                        className="group-hover:opacity-60 transition-opacity"
                        style={{
                          fontFamily: "'Archivo Black', sans-serif",
                          fontSize: '1.15rem',
                          color: 'var(--n-text)',
                          letterSpacing: '-0.03em',
                          lineHeight: 1.15,
                          marginBottom: '0.5rem',
                        }}
                      >
                        {getBilingualField(event, 'title', lang)}
                      </h3>

                      {(event.editorialHook || event.editorialHook_zh) ? (
                        <p style={{
                          fontSize: '0.8rem',
                          color: 'var(--n-secondary)',
                          lineHeight: 1.6,
                          fontStyle: 'italic',
                        }}>
                          {isZh
                            ? (event.editorialHook_zh || event.editorialHook)
                            : (event.editorialHook || event.editorialHook_zh)}
                        </p>
                      ) : (
                        <p className="line-clamp-2" style={{
                          fontSize: '0.8rem',
                          color: 'var(--n-secondary)',
                          lineHeight: 1.6,
                        }}>
                          {getBilingualField(event, 'description', lang) || ''}
                        </p>
                      )}
                    </div>

                    {/* Meta row */}
                    <div className="flex items-center justify-between mt-4">
                      <span style={{ fontSize: '0.65rem', color: 'var(--n-muted)', letterSpacing: '0.02em' }}>
                        {formatPickDate(event.date, event.time)}
                        {event.district ? ` — ${getBilingualField(event, 'district', lang)}` : ''}
                      </span>
                      <ArrowUpRight
                        size={13}
                        className="opacity-0 group-hover:opacity-100 transition-opacity"
                        style={{ color: 'var(--n-secondary)' }}
                      />
                    </div>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
          <div className="h-px" style={{ backgroundColor: 'var(--n-border)' }} />
        </div>
      )}
    </section>
  );
}

// ─── Also happening — label in left third, list in right two-thirds ───
function AlsoHappening() {
  const { events } = useData();
  const { i18n } = useTranslation();
  const lang = i18n.language;
  const isZh = lang?.startsWith('zh');

  const extras = events
    .filter((e) => e.status === 'upcoming' || e.status === 'ongoing')
    .slice(3, 8);

  if (extras.length === 0) return null;

  return (
    <section style={{ backgroundColor: 'var(--n-bg)', padding: '3rem 6.5vw' }}>
      <div style={{
        display: 'grid',
        gridTemplateColumns: '1fr 2fr',
        gap: '1rem',
      }}>
        {/* Left third — section label, pinned top */}
        <div>
          <span style={labelStyle}>
            {isZh ? '同期進行' : 'Also on'}
          </span>
        </div>

        {/* Right two-thirds — event list */}
        <div>
          {extras.map((event, i) => (
            <Link
              key={event.id}
              to={getEventLink(event)}
              className="block group"
              style={{
                padding: '0.6rem 0',
                borderBottom: i < extras.length - 1 ? '1px solid var(--n-border-subtle)' : 'none',
              }}
            >
              <div className="flex items-baseline justify-between gap-3">
                <span
                  className="group-hover:opacity-50 transition-opacity"
                  style={{ fontSize: '0.85rem', color: 'var(--n-text)', lineHeight: 1.4 }}
                >
                  {getBilingualField(event, 'title', lang)}
                </span>
                <span className="flex-shrink-0" style={{ fontSize: '0.6rem', color: 'var(--n-muted)' }}>
                  {getBilingualField(event, 'district', lang) || event.district || ''}
                </span>
              </div>
            </Link>
          ))}

          <Link
            to="/events"
            className="inline-flex items-center gap-1 mt-5 group"
            style={{ ...labelStyle, color: '#999' }}
          >
            {isZh ? '查看全部' : 'All events'}
            <ArrowUpRight size={10} className="group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
          </Link>
        </div>
      </div>
    </section>
  );
}

// ─── Explore CTA — links to the expanded /whats-on view ───
function ExploreCTA() {
  const { i18n } = useTranslation();
  const isZh = i18n.language?.startsWith('zh');

  return (
    <section style={{ backgroundColor: 'var(--n-bg)', padding: '0 6.5vw 1rem' }}>
      <div style={{
        display: 'grid',
        gridTemplateColumns: '1fr 2fr',
        gap: '1rem',
      }}>
        <div>
          <span style={labelStyle}>{isZh ? '探索' : 'Explore'}</span>
        </div>
        <div>
          <Link
            to="/whats-on"
            className="group flex items-center justify-between py-3"
            style={{}}
          >
            <span style={{
              fontFamily: "'Archivo Black', sans-serif",
              fontSize: '0.85rem',
              color: 'var(--n-text)',
              letterSpacing: '-0.02em',
            }}
              className="group-hover:opacity-60 transition-opacity"
            >
              {isZh ? '全部活動 · 篩選 · 主題' : "What's On · Filter · Themes"}
            </span>
            <ArrowUpRight
              size={14}
              className="group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform"
              style={{ color: 'var(--n-muted)' }}
            />
          </Link>
        </div>
      </div>
    </section>
  );
}

// ─── Modes — 3-column grid (rule of 3) ───
function ModeStrip() {
  const { setMode } = useMode();
  const navigate = useNavigate();
  const { i18n } = useTranslation();
  const isZh = i18n.language?.startsWith('zh');

  const modes = [
    { key: 'degen', en: 'Night', zh: '夜行者' },
    { key: 'artsy', en: 'Art', zh: '藝術' },
    { key: 'foodie', en: 'Food', zh: '美食' },
    { key: 'family', en: 'Family', zh: '親子' },
    { key: 'lifestyle', en: 'Lifestyle', zh: '生活' },
  ];

  const handleMode = (key: string) => {
    setMode(key as UIMode);
    if (key === 'lifestyle') navigate('/lifestyle');
  };

  return (
    <section style={{ backgroundColor: 'var(--n-bg)', padding: '2rem 6.5vw 3rem' }}>
      <div style={{
        display: 'grid',
        gridTemplateColumns: '1fr 2fr',
        gap: '1rem',
      }}>
        {/* Left third — label */}
        <div>
          <span style={labelStyle}>{isZh ? '探索' : 'Modes'}</span>
        </div>

        {/* Right two-thirds — 3-column button grid */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(3, 1fr)',
          gap: '0.5rem 0.75rem',
        }}>
          {modes.map((m) => {
            const config = (modeConfig as any)[m.key];
            return (
              <button
                key={m.key}
                onClick={() => handleMode(m.key)}
                className="cursor-pointer group flex items-center gap-1.5"
                style={{
                  background: 'none',
                  border: 'none',
                  padding: '0.4rem 0',
                }}
              >
                <CIcon id={config?.emoji || m.key} size={11} mode={m.key as any} />
                <span
                  className="group-hover:opacity-60 transition-opacity"
                  style={{ fontSize: '0.75rem', color: 'var(--n-secondary)' }}
                >
                  {isZh ? m.zh : m.en}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
}

// ─── CTA — dark section, content offset to right 2/3 ───
function BottomCTA() {
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);
  const { user } = useAuth();
  const { i18n } = useTranslation();
  const isZh = i18n.language?.startsWith('zh');

  const handleSubmit = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) { setSent(true); setTimeout(() => setSent(false), 3000); }
  }, [email]);

  return (
    <section style={{ backgroundColor: 'var(--n-cta-bg)', padding: '3rem 6.5vw' }}>
      <div style={{
        display: 'grid',
        gridTemplateColumns: '1fr 2fr',
        gap: '1rem',
      }}>
        {/* Left third — vertical branding mark */}
        <div className="flex flex-col items-start justify-center">
          <span style={{
            fontFamily: "'Archivo Black', sans-serif",
            fontSize: '0.6rem',
            color: 'rgba(255,255,255,0.15)',
            letterSpacing: '-0.03em',
            writingMode: 'vertical-lr',
          }}>
            CULTIVE
          </span>
        </div>

        {/* Right two-thirds — CTAs */}
        <div>
          {/* Sign up */}
          {!user && (
            <div className="mb-8">
              <p style={{
                fontSize: '0.8rem',
                color: 'rgba(255,255,255,0.35)',
                lineHeight: 1.6,
                marginBottom: '0.75rem',
              }}>
                {isZh
                  ? '儲存活動、個人化推介。'
                  : 'Save events. Get personalized picks.'}
              </p>
              <Link
                to="/signup"
                className="inline-flex items-center gap-1.5 transition-opacity hover:opacity-80"
                style={{
                  color: '#fff',
                  fontSize: '0.8rem',
                  fontWeight: 500,
                  borderBottom: '1px solid rgba(255,255,255,0.25)',
                  paddingBottom: '2px',
                }}
              >
                {isZh ? '免費註冊' : 'Create an account'}
                <ArrowUpRight size={12} />
              </Link>
            </div>
          )}

          {/* Newsletter */}
          <span style={{ ...labelStyle, color: 'rgba(255,255,255,0.2)', display: 'block', marginBottom: '0.6rem' }}>
            {isZh ? '週報' : 'Weekly dispatch'}
          </span>

          <form onSubmit={handleSubmit} className="flex gap-2 mb-5">
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder={isZh ? '電郵地址' : 'Email'}
              className="flex-1 min-w-0 px-3 py-2 text-sm outline-none"
              style={{
                backgroundColor: 'rgba(255,255,255,0.05)',
                border: '1px solid rgba(255,255,255,0.08)',
                borderRadius: '2px',
                color: '#fff',
              }}
            />
            <button
              type="submit"
              className="px-3.5 py-2 text-xs cursor-pointer transition-opacity hover:opacity-80"
              style={{
                backgroundColor: 'rgba(255,255,255,0.1)',
                color: '#fff',
                borderRadius: '2px',
                fontWeight: 500,
                border: 'none',
              }}
            >
              {sent ? '✓' : <Send size={12} />}
            </button>
          </form>

          {/* WhatsApp */}
          <a
            href={WHATSAPP_CHANNEL_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 transition-opacity hover:opacity-70"
            style={{ ...labelStyle, color: 'rgba(255,255,255,0.2)' }}
          >
            <svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
            </svg>
            WhatsApp
          </a>
        </div>
      </div>
    </section>
  );
}

// ─── Footer — 3-column grid ───
function MinimalFooter() {
  const { t, i18n } = useTranslation();
  const isZh = i18n.language?.startsWith('zh');

  return (
    <footer style={{ backgroundColor: 'var(--n-bg)', borderTop: '1px solid var(--n-border)', padding: '1.75rem 6.5vw' }}>
      {/* Top row — 1/3 + 2/3 */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '1rem', marginBottom: '1.25rem' }}>
        <div className="flex items-baseline gap-1">
          <span style={{
            fontFamily: "'Archivo Black', sans-serif",
            fontSize: '0.65rem',
            color: 'var(--n-text)',
            letterSpacing: '-0.03em',
          }}>
            CULTIVE
          </span>
          <span style={{ fontSize: '0.4rem', color: 'var(--n-muted)', fontFamily: "'Noto Sans HK', sans-serif" }}>
            文化活
          </span>
        </div>
        <div className="flex flex-wrap gap-4">
          {[
            { label: isZh ? '活動' : 'Events', to: '/events' },
            { label: isZh ? '地圖' : 'Map', to: '/map' },
            { label: isZh ? '回顧' : 'Recaps', to: '/recaps' },
            { label: isZh ? '提交' : 'Submit', to: '/contribute' },
          ].map((link) => (
            <Link
              key={link.to}
              to={link.to}
              className="transition-opacity hover:opacity-50"
              style={{ fontSize: '0.65rem', color: 'var(--n-secondary)' }}
            >
              {link.label}
            </Link>
          ))}
        </div>
      </div>

      {/* Bottom row */}
      <div className="flex items-center justify-between pt-3" style={{ borderTop: '1px solid var(--n-border-subtle)' }}>
        <span style={{ fontSize: '0.5rem', color: 'var(--n-muted)' }}>
          {t('common.copyright')}
        </span>
        <div className="flex items-center gap-3">
          <Link to="/privacy" style={{ fontSize: '0.5rem', color: 'var(--n-muted)' }}>{t('footer.privacy')}</Link>
          <Link to="/terms" style={{ fontSize: '0.5rem', color: 'var(--n-muted)' }}>{t('footer.terms')}</Link>
          <span style={{ fontSize: '0.5rem', color: 'var(--n-muted)' }}>{isZh ? '香港' : 'HK'}</span>
        </div>
      </div>
    </footer>
  );
}

// ═══════════════════════════════════════════════════════════════════
// MAIN EXPORT
// ═══════════════════════════════════════════════════════════════════

export function MobileEditorialHome() {
  const { palette } = useNeutralTheme();

  const cssVars = {
    '--n-bg': palette.bg,
    '--n-bg-alt': palette.bgAlt,
    '--n-text': palette.text,
    '--n-secondary': palette.textSecondary,
    '--n-muted': palette.textMuted,
    '--n-border': palette.border,
    '--n-border-subtle': palette.borderSubtle,
    '--n-card-bg': palette.cardBg,
    '--n-number': palette.numberColor,
    '--n-cta-bg': palette.ctaBg,
    '--n-cta-text': palette.ctaText,
    '--n-cta-border': palette.ctaBorder,
    '--n-input-bg': palette.inputBg,
    '--n-input-border': palette.inputBorder,
  } as React.CSSProperties;

  return (
    <div className="md:hidden" style={{ ...cssVars, backgroundColor: palette.bg, transition: 'background-color 0.3s ease, color 0.3s ease' }}>
      <Masthead />
      <Picks />
      <ExploreCTA />
      <AlsoHappening />
      <ModeStrip />
      <BottomCTA />
      <MinimalFooter />
    </div>
  );
}

// Wrapped export that provides the theme context
export function MobileEditorialHomeWithTheme() {
  return <MobileEditorialHome />;
}