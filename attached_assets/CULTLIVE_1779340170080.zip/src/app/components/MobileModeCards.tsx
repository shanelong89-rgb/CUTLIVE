import { useCallback } from 'react';
import { motion } from 'motion/react';
import { ArrowRight, Check } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { modeConfig } from '../data/mock-data';
import { useMode } from '../context/ModeContext';
import type { UIMode } from '../context/ModeContext';
import { modeDesignTokens } from '../data/mode-styles';
import { CIcon } from './CIcon';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { useSiteImages } from '../hooks/useSiteImages';

const MODE_CARDS = [
  {
    key: 'degen' as const,
    label: 'Night',
    labelZh: '夜行者',
    tagline: 'Nightlife & underground',
    image: 'https://images.unsplash.com/photo-1616394158624-a2ba9cfe2994?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxIb25nJTIwS29uZyUyMG5lb24lMjBuaWdodGxpZmUlMjBzdHJlZXQlMjBkYXJrfGVufDF8fHx8MTc3MzA0NTM4MHww&ixlib=rb-4.1.0&q=80&w=400&utm_source=figma&utm_medium=referral',
    gradient: 'linear-gradient(135deg, #EDFF00 0%, #D600FF 100%)',
  },
  {
    key: 'family' as const,
    label: 'Family',
    labelZh: '親子',
    tagline: 'Kid-friendly adventures',
    image: 'https://images.unsplash.com/photo-1756657266978-c15f15bd3266?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxIb25nJTIwS29uZyUyMGZhbWlseSUyMGNoaWxkcmVuJTIwcGFyayUyMHBsYXlncm91bmR8ZW58MXx8fHwxNzczMDQ1Mzg0fDA&ixlib=rb-4.1.0&q=80&w=400&utm_source=figma&utm_medium=referral',
    gradient: 'linear-gradient(135deg, #FF8C42 0%, #FFB347 100%)',
  },
  {
    key: 'artsy' as const,
    label: 'Art & Design',
    labelZh: '藝術',
    tagline: 'Galleries & exhibitions',
    image: 'https://images.unsplash.com/photo-1767294274414-5e1e6c3974e9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBhcnQlMjBnYWxsZXJ5JTIwd2hpdGUlMjBleGhpYml0aW9uJTIwc3BhY2V8ZW58MXx8fHwxNzczMDQ1Mzg3fDA&ixlib=rb-4.1.0&q=80&w=400&utm_source=figma&utm_medium=referral',
    gradient: 'linear-gradient(135deg, #8338EC 0%, #3d2b7a 100%)',
  },
  {
    key: 'foodie' as const,
    label: 'Food',
    labelZh: '美食',
    tagline: 'Restaurants & markets',
    image: 'https://images.unsplash.com/photo-1746105866475-33b40bcc24d1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxIb25nJTIwS29uZyUyMGRpbSUyMHN1bSUyMGZvb2QlMjBtYXJrZXQlMjByZXN0YXVyYW50fGVufDF8fHx8MTc3MzA0NTM4OXww&ixlib=rb-4.1.0&q=80&w=400&utm_source=figma&utm_medium=referral',
    gradient: 'linear-gradient(135deg, #2563EB 0%, #0A1628 100%)',
  },
  {
    key: 'lifestyle' as const,
    label: 'Lifestyle',
    labelZh: '生活',
    tagline: 'Wellness & meetups',
    image: 'https://images.unsplash.com/photo-1760774714285-61ff516f86c5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvdXRkb29yJTIweW9nYSUyMHdlbGxuZXNzJTIwc3VucmlzZSUyMGdyb3VwfGVufDF8fHx8MTc3MzA0NTM5Mnww&ixlib=rb-4.1.0&q=80&w=400&utm_source=figma&utm_medium=referral',
    gradient: 'linear-gradient(135deg, #2D6A4F 0%, #40916C 100%)',
  },
];

const MOBILE_CARD_SLOT_MAP: Record<string, string> = {
  degen: 'mobile-mode-night',
  family: 'mobile-mode-family',
  artsy: 'mobile-mode-art',
  foodie: 'mobile-mode-food',
  lifestyle: 'mobile-mode-lifestyle',
};

// Fallback chain: mobile-mode → mode-card → mode-hero → hardcoded
const MOBILE_CARD_FALLBACKS: Record<string, string[]> = {
  degen: ['mode-card-night', 'mode-hero-night'],
  family: ['mode-card-family', 'mode-hero-family'],
  artsy: ['mode-card-art', 'mode-hero-art'],
  foodie: ['mode-card-food', 'mode-hero-food'],
  lifestyle: ['mode-card-lifestyle', 'mode-hero-lifestyle'],
};

function resolveMobileCardImage(siteImg: (id: string) => string, override: (id: string) => string, cardKey: string, fallbackUrl: string): string {
  // Check for direct CMS override on mobile slot
  const primaryOverride = override(MOBILE_CARD_SLOT_MAP[cardKey]);
  if (primaryOverride) return primaryOverride;
  // Fallback chain: mode-card → mode-hero
  for (const slot of (MOBILE_CARD_FALLBACKS[cardKey] || [])) {
    const url = override(slot);
    if (url) return url;
  }
  // Use the img() helper which returns static default
  return siteImg(MOBILE_CARD_SLOT_MAP[cardKey]) || fallbackUrl;
}

interface MobileModeCardsProps {
  onSelect?: () => void;
}

export function MobileModeCards({ onSelect }: MobileModeCardsProps) {
  const { currentMode, setMode } = useMode();
  const { t, i18n } = useTranslation();
  const isZh = i18n.language === 'zh-Hant' || i18n.language.startsWith('zh');
  const { img: siteImg, override: siteOverride, focal: siteFocal } = useSiteImages();

  const handleSelect = useCallback((key: string) => {
    const isActive = currentMode === key;
    if (isActive) {
      setMode(null);
    } else {
      setMode(key as UIMode);
    }
    onSelect?.();
  }, [currentMode, setMode, onSelect]);

  return (
    <div className="flex flex-col gap-2">
      <span
        style={{
          fontSize: '0.6rem',
          fontWeight: 600,
          letterSpacing: '0.1em',
          textTransform: 'uppercase',
          color: 'rgba(128,128,128,0.6)',
          marginBottom: '2px',
        }}
      >
        {t('modes.switchMode')}
      </span>
      {MODE_CARDS.map((card, i) => {
        const config = (modeConfig as any)[card.key];
        const mTokens = (modeDesignTokens as any)[card.key];
        const isActive = currentMode === card.key;

        return (
          <motion.button
            key={card.key}
            className="relative overflow-hidden cursor-pointer w-full text-left"
            style={{
              borderRadius: '16px',
              height: '82px',
              border: isActive ? `2px solid ${config.color}` : '2px solid transparent',
              boxShadow: isActive ? `0 0 20px ${config.color}30` : '0 2px 8px rgba(0,0,0,0.15)',
            }}
            initial={{ opacity: 0, x: -16 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.04, duration: 0.3 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => handleSelect(card.key)}
          >
            {/* Background image */}
            <div className="absolute inset-0">
              <ImageWithFallback
                src={resolveMobileCardImage(siteImg, siteOverride, card.key, card.image)}
                alt={card.label}
                className="h-full w-full object-cover"
                style={{ filter: 'brightness(0.35) saturate(1.2)', objectPosition: siteFocal(MOBILE_CARD_SLOT_MAP[card.key]) }}
              />
              <div
                className="absolute inset-0"
                style={{
                  background: 'linear-gradient(to right, rgba(0,0,0,0.7) 0%, rgba(0,0,0,0.15) 60%)',
                }}
              />
              {/* Top accent strip */}
              <div
                className="absolute top-0 left-0 right-0 h-[3px]"
                style={{ background: card.gradient }}
              />
            </div>

            {/* Content row */}
            <div className="relative h-full flex items-center justify-between px-4">
              <div className="flex items-center gap-3.5 min-w-0">
                {/* Mode icon */}
                <div
                  className="flex items-center justify-center flex-shrink-0"
                  style={{
                    width: 44,
                    height: 44,
                    borderRadius: '12px',
                    backgroundColor: `${config.color}25`,
                    border: `1.5px solid ${config.color}50`,
                    backdropFilter: 'blur(8px)',
                    WebkitBackdropFilter: 'blur(8px)',
                    boxShadow: `0 0 12px ${config.color}20`,
                  }}
                >
                  <CIcon id={config.emoji} size={22} mode={card.key} glow style={{ color: config.color, filter: `drop-shadow(0 0 6px ${config.color}80)` }} />
                </div>

                {/* Labels */}
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span
                      style={{
                        fontFamily: mTokens.headingFont,
                        fontSize: '1.1rem',
                        fontWeight: 700,
                        color: '#fff',
                        letterSpacing: '-0.01em',
                        lineHeight: 1.2,
                        textShadow: '0 1px 4px rgba(0,0,0,0.5)',
                      }}
                    >
                      {card.label}
                    </span>
                    <span
                      style={{
                        fontSize: '0.7rem',
                        color: 'rgba(255,255,255,0.6)',
                        fontWeight: 500,
                      }}
                    >
                      {card.labelZh}
                    </span>
                  </div>
                  <p
                    style={{
                      fontSize: '0.75rem',
                      color: 'rgba(255,255,255,0.55)',
                      lineHeight: 1.3,
                      marginTop: '2px',
                    }}
                  >
                    {card.tagline}
                  </p>
                </div>
              </div>

              {/* Right side: active badge or arrow */}
              {isActive ? (
                <div
                  className="flex items-center gap-1.5 px-3 py-1.5 flex-shrink-0"
                  style={{
                    backgroundColor: config.color,
                    borderRadius: '10px',
                    boxShadow: `0 0 12px ${config.color}40`,
                  }}
                >
                  <Check size={13} color="#fff" strokeWidth={3} />
                  <span style={{ fontSize: '0.6rem', color: '#fff', fontWeight: 700 }}>ON</span>
                </div>
              ) : (
                <ArrowRight size={18} color="rgba(255,255,255,0.5)" className="flex-shrink-0" />
              )}
            </div>
          </motion.button>
        );
      })}
    </div>
  );
}