import { motion } from 'motion/react';
import { useRef, useCallback, useEffect } from 'react';
import { modeConfig, type Mode } from '../data/mock-data';
import { useMode } from '../context/ModeContext';
import type { UIMode } from '../context/ModeContext';
import { getDesignTokens, isLightMode, modeDesignTokens } from '../data/mode-styles';
import { CIcon } from './CIcon';

export function ModeSelector({ compact = false }: { compact?: boolean }) {
  const { currentMode, setMode } = useMode();
  const modes = Object.entries(modeConfig) as [string, (typeof modeConfig)[keyof typeof modeConfig]][];
  const light = isLightMode(currentMode);
  const tokens = getDesignTokens(currentMode);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const touchStartRef = useRef<{ x: number; y: number; locked: 'h' | 'v' | null }>({ x: 0, y: 0, locked: null });

  // Forward vertical wheel events to the page so the mode switcher
  // only captures horizontal scroll and doesn't block page scrolling
  const handleWheel = useCallback((e: React.WheelEvent<HTMLDivElement>) => {
    const el = scrollContainerRef.current;
    if (!el) return;

    const hasHorizontalOverflow = el.scrollWidth > el.clientWidth;
    const isHorizontalScroll = Math.abs(e.deltaX) > Math.abs(e.deltaY);

    // If the user is scrolling vertically, let it pass through to the page
    if (!isHorizontalScroll) {
      return;
    }

    // For horizontal scroll, only consume it if there's overflow to scroll
    if (hasHorizontalOverflow && isHorizontalScroll) {
      return;
    }
  }, []);

  // On touch devices, detect scroll direction and only capture horizontal swipes.
  // Vertical swipes should pass through to scroll the page.
  useEffect(() => {
    const el = scrollContainerRef.current;
    if (!el) return;

    const onTouchStart = (e: TouchEvent) => {
      const touch = e.touches[0];
      touchStartRef.current = { x: touch.clientX, y: touch.clientY, locked: null };
    };

    const onTouchMove = (e: TouchEvent) => {
      const touch = e.touches[0];
      const dx = Math.abs(touch.clientX - touchStartRef.current.x);
      const dy = Math.abs(touch.clientY - touchStartRef.current.y);

      // Lock direction once we've moved enough
      if (!touchStartRef.current.locked && (dx > 5 || dy > 5)) {
        touchStartRef.current.locked = dx > dy ? 'h' : 'v';
      }

      // If locked to vertical, prevent the mode selector from capturing the scroll
      if (touchStartRef.current.locked === 'v') {
        // Let it pass through to the page — do not call preventDefault
        // Override overflow to prevent the container from scrolling horizontally during a vertical swipe
        el.style.overflowX = 'hidden';
      }
    };

    const onTouchEnd = () => {
      // Restore horizontal scroll
      el.style.overflowX = 'auto';
      touchStartRef.current = { x: 0, y: 0, locked: null };
    };

    el.addEventListener('touchstart', onTouchStart, { passive: true });
    el.addEventListener('touchmove', onTouchMove, { passive: true });
    el.addEventListener('touchend', onTouchEnd, { passive: true });
    el.addEventListener('touchcancel', onTouchEnd, { passive: true });

    return () => {
      el.removeEventListener('touchstart', onTouchStart);
      el.removeEventListener('touchmove', onTouchMove);
      el.removeEventListener('touchend', onTouchEnd);
      el.removeEventListener('touchcancel', onTouchEnd);
    };
  }, []);

  // Mode-specific button shape
  const getButtonRadius = () => {
    if (!currentMode || currentMode === 'lifestyle') return '9999px'; // pill
    const t = modeDesignTokens[currentMode];
    if (t.aesthetic === 'bold-poster') return '4px';
    if (t.aesthetic === 'editorial-minimal') return '2px';
    if (t.aesthetic === 'warm-playful') return '9999px';
    if (t.aesthetic === 'rich-magazine') return '9999px';
    return '9999px';
  };

  const buttonRadius = getButtonRadius();
  const isDegen = currentMode === 'degen';
  const isArtsy = currentMode === 'artsy';

  const getInactiveStyle = () => {
    if (isDegen) {
      return {
        backgroundColor: 'transparent',
        color: '#666666',
        border: '2px solid rgba(0,0,0,0.1)',
      };
    }
    if (isArtsy) {
      return {
        backgroundColor: 'transparent',
        color: tokens.textMuted,
        borderBottom: `1px solid transparent`,
      };
    }
    return {
      backgroundColor: light ? 'rgba(0,0,0,0.06)' : 'rgba(255,255,255,0.1)',
      color: light ? '#4a4a4a' : 'rgba(255,255,255,0.7)',
    };
  };

  const getActiveStyle = (color: string) => {
    if (isDegen) {
      return {
        backgroundColor: '#0A0A0A',
        color: '#EDFF00',
        border: '2px solid #0A0A0A',
      };
    }
    return { backgroundColor: color };
  };

  const handleModeClick = (key: string) => {
    const isActive = currentMode === key;
    if (isActive) {
      setMode(null);
    } else {
      setMode(key as UIMode);
    }
  };

  return (
    <div
      ref={scrollContainerRef}
      className={`flex overflow-x-auto scrollbar-hide ${compact ? 'gap-1.5' : 'gap-2'}`}
      style={{ WebkitOverflowScrolling: 'touch', overscrollBehaviorX: 'contain', overflowY: 'visible' }}
      onWheel={handleWheel}
    >
      {modes.map(([key, config]) => {
        const isActive = currentMode === key;
        return (
          <motion.button
            key={key}
            onClick={() => handleModeClick(key)}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className={`
              relative flex items-center gap-1 sm:gap-1.5 transition-all duration-300 flex-shrink-0
              ${compact ? 'px-2.5 sm:px-3 py-1.5' : 'px-3 sm:px-4 py-2'}
              ${isActive ? 'shadow-lg' : 'backdrop-blur-sm'}
            `}
            style={{
              borderRadius: buttonRadius,
              fontFamily: isDegen ? tokens.headingFont : undefined,
              fontWeight: isDegen ? 700 : undefined,
              textTransform: isDegen ? 'uppercase' : undefined,
              letterSpacing: isDegen ? '0.03em' : isArtsy ? '0.1em' : undefined,
              ...(isActive
                ? { ...getActiveStyle(config.color), color: isActive && isDegen ? '#EDFF00' : '#fff' }
                : getInactiveStyle()),
            }}
          >
            {config.emoji && <CIcon id={config.emoji} size={compact ? 14 : 16} mode={key as any} glow={isActive} animated />}
            <span className={`whitespace-nowrap ${compact ? 'text-[11px] sm:text-xs' : 'text-xs sm:text-sm'}`}>{config.label}</span>
            {isActive && !isDegen && (
              <motion.div
                layoutId="mode-indicator"
                className="absolute inset-0"
                style={{ backgroundColor: config.color, zIndex: -1, borderRadius: buttonRadius }}
                transition={{ type: 'spring', stiffness: 400, damping: 30 }}
              />
            )}
          </motion.button>
        );
      })}
      <style>{`.scrollbar-hide::-webkit-scrollbar { display: none; } .scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }`}</style>
    </div>
  );
}