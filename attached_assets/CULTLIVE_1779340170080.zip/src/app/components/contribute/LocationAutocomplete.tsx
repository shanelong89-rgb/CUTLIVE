import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { createPortal } from 'react-dom';
import { MapPin, Loader2, Search, X, AlertCircle, Navigation, Hash } from 'lucide-react';
import { projectId, publicAnonKey } from '../../config/supabase';
import { parseCoordinates, reverseDistrictFromCoords, type ParsedCoords } from '../../utils/coord-parser';

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-d507b98c`;

interface LocationResult {
  name: string;
  lat?: number;
  lng?: number;
  district?: string;
}

interface GooglePrediction {
  place_id: string;
  description: string;
  structured_formatting: {
    main_text: string;
    secondary_text: string;
  };
  terms: { value: string }[];
}

// Map Google address component types to CULTIVE district names
const DISTRICT_ALIASES: Record<string, string> = {
  'central': 'Central',
  'central and western district': 'Central',
  'central and western': 'Central',
  'wan chai': 'Wan Chai',
  'wan chai district': 'Wan Chai',
  'wanchai': 'Wan Chai',
  'causeway bay': 'Causeway Bay',
  'sheung wan': 'Sheung Wan',
  'sai ying pun': 'Sai Ying Pun',
  'kennedy town': 'Kennedy Town',
  'tsim sha tsui': 'Tsim Sha Tsui',
  'yau tsim mong': 'Tsim Sha Tsui',
  'yau tsim mong district': 'Tsim Sha Tsui',
  'mong kok': 'Mong Kok',
  'mongkok': 'Mong Kok',
  'sham shui po': 'Sham Shui Po',
  'sham shui po district': 'Sham Shui Po',
  'west kowloon': 'West Kowloon',
  'wong chuk hang': 'Wong Chuk Hang',
  'stanley': 'Stanley',
  'repulse bay': 'Repulse Bay',
  'shau kei wan': 'Shau Kei Wan',
  'eastern district': 'Shau Kei Wan',
  'tai tam': 'Tai Tam',
  'sha tin': 'Sha Tin',
  'sha tin district': 'Sha Tin',
  'shatin': 'Sha Tin',
  'tai po': 'Tai Po',
  'tai po district': 'Tai Po',
  'sai kung': 'Sai Kung',
  'sai kung district': 'Sai Kung',
  'lantau': 'Lantau',
  'islands district': 'Lantau',
  'tung chung': 'Lantau',
  'discovery bay': 'Lantau',
  'kowloon city': 'West Kowloon',
  'kowloon city district': 'West Kowloon',
  'kwun tong': 'Other',
  'kwun tong district': 'Other',
  'wong tai sin': 'Other',
  'wong tai sin district': 'Other',
  'kwai tsing': 'Other',
  'kwai tsing district': 'Other',
  'tsuen wan': 'Other',
  'tsuen wan district': 'Other',
  'tuen mun': 'Other',
  'tuen mun district': 'Other',
  'yuen long': 'Other',
  'yuen long district': 'Other',
  'north district': 'Other',
  'southern district': 'Wong Chuk Hang',
  'aberdeen': 'Wong Chuk Hang',
  'ap lei chau': 'Wong Chuk Hang',
  'happy valley': 'Wan Chai',
  'north point': 'Causeway Bay',
  'quarry bay': 'Shau Kei Wan',
  'taikoo': 'Shau Kei Wan',
  'chai wan': 'Shau Kei Wan',
  'mid-levels': 'Central',
  'the peak': 'Central',
  'soho': 'Central',
  'admiralty': 'Central',
  'jordan': 'Tsim Sha Tsui',
  'yau ma tei': 'Mong Kok',
  'prince edward': 'Mong Kok',
  'hung hom': 'Tsim Sha Tsui',
  'to kwa wan': 'West Kowloon',
};

function detectDistrictFromComponents(
  components: { long_name: string; short_name: string; types: string[] }[] | undefined,
  description: string
): string | undefined {
  if (components) {
    // Check sublocality, neighborhood, administrative levels
    const relevantTypes = [
      'sublocality_level_1', 'sublocality', 'neighborhood',
      'administrative_area_level_2', 'locality',
    ];
    for (const type of relevantTypes) {
      const comp = components.find(c => c.types.includes(type));
      if (comp) {
        const key = comp.long_name.toLowerCase();
        if (DISTRICT_ALIASES[key]) return DISTRICT_ALIASES[key];
        // Partial match
        for (const [alias, district] of Object.entries(DISTRICT_ALIASES)) {
          if (key.includes(alias) || alias.includes(key)) return district;
        }
      }
    }
  }

  // Fallback: scan the full description text
  const lower = description.toLowerCase();
  for (const [alias, district] of Object.entries(DISTRICT_ALIASES)) {
    if (lower.includes(alias)) return district;
  }
  return undefined;
}

interface Props {
  value: string;
  onChange: (result: LocationResult) => void;
  inputStyle: React.CSSProperties;
  tokens: {
    accent: string;
    accentBg: string;
    accentBorder: string;
    text: string;
    textSecondary: string;
    textMuted: string;
    surface: string;
    surfaceMuted: string;
    border: string;
    font: string;
    green: string;
  };
}

export function LocationAutocomplete({ value, onChange, inputStyle, tokens }: Props) {
  const [query, setQuery] = useState(value);
  const [predictions, setPredictions] = useState<GooglePrediction[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const [fetchingDetails, setFetchingDetails] = useState(false);
  const [coordMode, setCoordMode] = useState(false);
  const [detectedCoords, setDetectedCoords] = useState<ParsedCoords | null>(null);
  const debounceRef = useRef<any>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const coordInputRef = useRef<HTMLInputElement>(null);
  const [dropdownPos, setDropdownPos] = useState<{ top: number; left: number; width: number } | null>(null);

  // Sync external value
  useEffect(() => {
    setQuery(value);
  }, [value]);

  // Update dropdown position when open
  const updatePosition = useCallback(() => {
    if (!inputRef.current) return;
    const rect = inputRef.current.getBoundingClientRect();
    setDropdownPos({
      top: rect.bottom + 4,
      left: rect.left,
      width: rect.width,
    });
  }, []);

  useEffect(() => {
    if (isOpen) {
      updatePosition();
      window.addEventListener('scroll', updatePosition, true);
      window.addEventListener('resize', updatePosition);
      return () => {
        window.removeEventListener('scroll', updatePosition, true);
        window.removeEventListener('resize', updatePosition);
      };
    }
  }, [isOpen, updatePosition]);

  // Close on outside click
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        const portalEl = document.getElementById('location-autocomplete-portal');
        if (portalEl && portalEl.contains(e.target as Node)) return;
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const searchPlaces = useCallback(async (q: string) => {
    if (q.length < 2) {
      setPredictions([]);
      setError(null);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams({ q });
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 8000);

      const res = await fetch(`${API_BASE}/places/autocomplete?${params}`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
        },
        signal: controller.signal,
      });
      clearTimeout(timeoutId);

      if (res.ok) {
        const data = await res.json();
        if (data.error) {
          console.log(`[LocationAutocomplete] Server error: ${data.error}`);
          setError(data.details || data.error);
          setPredictions([]);
          setIsOpen(false);
        } else {
          const preds: GooglePrediction[] = data.predictions || [];
          console.log(`[LocationAutocomplete] Google returned ${preds.length} predictions for "${q}"`);
          setPredictions(preds);
          if (preds.length > 0) {
            setIsOpen(true);
            setSelectedIndex(-1);
          } else {
            setError('No places found. Try a different search.');
            setIsOpen(false);
          }
        }
      } else {
        const errData = await res.json().catch(() => ({}));
        console.log(`[LocationAutocomplete] API error: ${res.status}`, errData);
        setError(errData.error || `Search failed (${res.status})`);
      }
    } catch (err: any) {
      if (err.name === 'AbortError') {
        setError('Search timed out. Check your connection.');
      } else {
        console.log('[LocationAutocomplete] Search error:', err);
        setError('Search unavailable. You can type the address manually.');
      }
    }
    setLoading(false);
  }, []);

  const handleInputChange = useCallback((val: string) => {
    setQuery(val);
    setError(null);

    // Check if input looks like coordinates
    const coords = parseCoordinates(val);
    if (coords) {
      setDetectedCoords(coords);
      setPredictions([]);
      setIsOpen(false);
      if (debounceRef.current) clearTimeout(debounceRef.current);
      // Auto-apply after a short pause so user sees the detection
      const district = reverseDistrictFromCoords(coords.lat, coords.lng);
      onChange({
        name: val,
        lat: coords.lat,
        lng: coords.lng,
        district,
      });
      return;
    }

    setDetectedCoords(null);
    // Update form with typed text (no coordinates yet)
    onChange({ name: val });

    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => searchPlaces(val), 350);
  }, [searchPlaces, onChange]);

  // Handle coordinate-mode input changes
  const handleCoordInput = useCallback((val: string) => {
    setQuery(val);
    setError(null);

    const coords = parseCoordinates(val);
    if (coords) {
      setDetectedCoords(coords);
      const district = reverseDistrictFromCoords(coords.lat, coords.lng);
      onChange({
        name: val,
        lat: coords.lat,
        lng: coords.lng,
        district,
      });
    } else {
      setDetectedCoords(null);
      onChange({ name: val });
    }
  }, [onChange]);

  const handleSelect = useCallback(async (prediction: GooglePrediction) => {
    const displayName = prediction.structured_formatting.main_text;
    setQuery(displayName);
    setIsOpen(false);
    setPredictions([]);
    setError(null);
    setFetchingDetails(true);

    try {
      // Fetch place details for lat/lng and district
      const params = new URLSearchParams({ place_id: prediction.place_id });
      const res = await fetch(`${API_BASE}/places/details?${params}`, {
        headers: { 'Authorization': `Bearer ${publicAnonKey}` },
      });

      if (res.ok) {
        const data = await res.json();
        const district = detectDistrictFromComponents(
          data.addressComponents,
          prediction.description
        );

        onChange({
          name: data.name || displayName,
          lat: data.lat,
          lng: data.lng,
          district,
        });
        setQuery(data.name || displayName);
      } else {
        // Fallback: use prediction text without coordinates
        const district = detectDistrictFromComponents(undefined, prediction.description);
        onChange({ name: displayName, district });
      }
    } catch (err) {
      console.log('[LocationAutocomplete] Details fetch error:', err);
      const district = detectDistrictFromComponents(undefined, prediction.description);
      onChange({ name: displayName, district });
    }
    setFetchingDetails(false);
  }, [onChange]);

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (!isOpen || predictions.length === 0) return;

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex(prev => (prev + 1) % predictions.length);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex(prev => (prev - 1 + predictions.length) % predictions.length);
    } else if (e.key === 'Enter' && selectedIndex >= 0) {
      e.preventDefault();
      handleSelect(predictions[selectedIndex]);
    } else if (e.key === 'Escape') {
      setIsOpen(false);
    }
  }, [isOpen, predictions, selectedIndex, handleSelect]);

  const handleClear = useCallback(() => {
    setQuery('');
    setPredictions([]);
    setIsOpen(false);
    setError(null);
    setDetectedCoords(null);
    onChange({ name: '' });
    if (coordMode) {
      coordInputRef.current?.focus();
    } else {
      inputRef.current?.focus();
    }
  }, [onChange, coordMode]);

  // Dropdown rendered via portal to escape overflow:hidden containers
  const dropdown = useMemo(() => {
    if (!isOpen || predictions.length === 0 || !dropdownPos) return null;

    return createPortal(
      <div
        id="location-autocomplete-portal"
        className="py-1 max-h-72 overflow-auto"
        style={{
          position: 'fixed',
          top: dropdownPos.top,
          left: dropdownPos.left,
          width: dropdownPos.width,
          zIndex: 99999,
          backgroundColor: tokens.surface,
          border: `1px solid ${tokens.border}`,
          borderRadius: '10px',
          boxShadow: '0 8px 32px rgba(0,0,0,0.12)',
        }}
      >
        {predictions.map((pred, i) => {
          const mainText = pred.structured_formatting.main_text;
          const secondaryText = pred.structured_formatting.secondary_text;
          const district = detectDistrictFromComponents(undefined, pred.description);

          return (
            <button
              key={pred.place_id}
              type="button"
              onClick={() => handleSelect(pred)}
              onMouseEnter={() => setSelectedIndex(i)}
              className="w-full px-3 py-2.5 text-left flex items-start gap-2.5 transition-colors cursor-pointer"
              style={{
                backgroundColor: selectedIndex === i ? tokens.surfaceMuted : 'transparent',
              }}
            >
              <MapPin size={14} className="flex-shrink-0 mt-0.5" style={{ color: tokens.accent }} />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate" style={{ color: tokens.text }}>
                  {mainText}
                </p>
                <p className="text-xs truncate mt-0.5" style={{ color: tokens.textMuted }}>
                  {secondaryText}
                </p>
                {district && (
                  <span
                    className="inline-flex items-center gap-1 px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wider mt-1"
                    style={{
                      backgroundColor: `${tokens.green}10`,
                      color: tokens.green,
                      borderRadius: '3px',
                    }}
                  >
                    {district}
                  </span>
                )}
              </div>
            </button>
          );
        })}
        <div className="px-3 py-1.5 border-t flex items-center gap-1.5" style={{ borderColor: tokens.border }}>
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" style={{ flexShrink: 0 }}>
            <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/>
            <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
            <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18A10.96 10.96 0 001 12c0 1.77.42 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"/>
            <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
          </svg>
          <p className="text-[9px]" style={{ color: tokens.textMuted }}>
            Powered by Google
          </p>
        </div>
      </div>,
      document.body
    );
  }, [isOpen, predictions, dropdownPos, selectedIndex, tokens, handleSelect]);

  return (
    <div ref={containerRef} className="relative">
      {/* Mode toggle: Search vs Coordinates */}
      <div className="flex items-center gap-2 mb-2">
        <button
          type="button"
          onClick={() => {
            setCoordMode(false);
            setDetectedCoords(null);
            setError(null);
          }}
          className="flex items-center gap-1.5 px-2.5 py-1 text-[11px] font-medium rounded-full transition-all cursor-pointer"
          style={{
            backgroundColor: !coordMode ? tokens.accent : tokens.surfaceMuted,
            color: !coordMode ? '#fff' : tokens.textMuted,
            border: `1px solid ${!coordMode ? tokens.accent : tokens.border}`,
          }}
        >
          <Search size={10} />
          Search
        </button>
        <button
          type="button"
          onClick={() => {
            setCoordMode(true);
            setPredictions([]);
            setIsOpen(false);
            setError(null);
            setTimeout(() => coordInputRef.current?.focus(), 50);
          }}
          className="flex items-center gap-1.5 px-2.5 py-1 text-[11px] font-medium rounded-full transition-all cursor-pointer"
          style={{
            backgroundColor: coordMode ? tokens.accent : tokens.surfaceMuted,
            color: coordMode ? '#fff' : tokens.textMuted,
            border: `1px solid ${coordMode ? tokens.accent : tokens.border}`,
          }}
        >
          <Navigation size={10} />
          Coordinates
        </button>
        {coordMode && (
          <span className="text-[10px] ml-1" style={{ color: tokens.textMuted }}>
            Paste GPS coordinates
          </span>
        )}
      </div>

      {/* Coordinate input mode */}
      {coordMode ? (
        <div>
          <div className="relative">
            <Navigation size={15} className="absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" style={{ color: tokens.textMuted }} />
            <input
              ref={coordInputRef}
              type="text"
              value={query}
              onChange={e => handleCoordInput(e.target.value)}
              placeholder={'22°19\'41.5"N 114°09\'36.4"E  or  22.3282, 114.1601'}
              className="w-full pl-9 pr-16 py-2.5 text-sm outline-none"
              style={inputStyle}
            />
            <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
              {query && (
                <button
                  type="button"
                  onClick={handleClear}
                  className="p-1 cursor-pointer rounded hover:bg-black/5 transition-colors"
                >
                  <X size={12} style={{ color: tokens.textMuted }} />
                </button>
              )}
              <Navigation size={14} style={{ color: detectedCoords ? tokens.green : tokens.textMuted }} />
            </div>
          </div>

          {/* Coordinate detection feedback */}
          {query && !detectedCoords && query.length >= 3 && (
            <div className="flex items-center gap-1.5 mt-1.5 px-1">
              <AlertCircle size={11} style={{ color: tokens.textMuted }} />
              <p className="text-[10px]" style={{ color: tokens.textMuted }}>
                Couldn't parse coordinates. Try formats like: <strong>22°19'41.5"N 114°09'36.4"E</strong> or <strong>22.3282, 114.1601</strong>
              </p>
            </div>
          )}
          {detectedCoords && (
            <div className="flex items-center gap-1.5 mt-1.5 px-1">
              <Navigation size={11} style={{ color: tokens.green }} />
              <p className="text-[11px] font-medium" style={{ color: tokens.green }}>
                Coordinates detected: {detectedCoords.lat.toFixed(5)}, {detectedCoords.lng.toFixed(5)}
                {(() => {
                  const d = reverseDistrictFromCoords(detectedCoords.lat, detectedCoords.lng);
                  return d ? <> &middot; {d}</> : null;
                })()}
              </p>
            </div>
          )}

          {/* Format examples */}
          {!query && (
            <div className="mt-2 px-1 space-y-1">
              <p className="text-[10px] font-medium" style={{ color: tokens.textSecondary }}>Supported formats:</p>
              {[
                { label: 'DMS', example: '22°19\'41.5"N 114°09\'36.4"E' },
                { label: 'Decimal', example: '22.3282, 114.1601' },
                { label: 'Space-separated', example: '22.3282 114.1601' },
              ].map((fmt) => (
                <button
                  key={fmt.label}
                  type="button"
                  onClick={() => {
                    handleCoordInput(fmt.example);
                  }}
                  className="flex items-center gap-2 w-full text-left px-2 py-1 rounded transition-colors hover:bg-black/5 cursor-pointer"
                >
                  <span className="text-[9px] font-semibold uppercase tracking-wider px-1 py-0.5 rounded" style={{ backgroundColor: tokens.surfaceMuted, color: tokens.textMuted }}>
                    {fmt.label}
                  </span>
                  <code className="text-[10px]" style={{ color: tokens.textSecondary, fontFamily: 'monospace' }}>
                    {fmt.example}
                  </code>
                </button>
              ))}
            </div>
          )}
        </div>
      ) : (
        /* Search mode (original) */
        <>
          <div className="relative">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" style={{ color: tokens.textMuted }} />
            <input
              ref={inputRef}
              type="text"
              value={query}
              onChange={e => handleInputChange(e.target.value)}
              onFocus={() => {
                if (predictions.length > 0) {
                  updatePosition();
                  setIsOpen(true);
                }
              }}
              onKeyDown={handleKeyDown}
              placeholder="Search venues and places in Hong Kong..."
              className="w-full pl-9 pr-16 py-2.5 text-sm outline-none"
              style={inputStyle}
            />
            <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
              {(loading || fetchingDetails) && <Loader2 size={14} className="animate-spin" style={{ color: tokens.accent }} />}
              {query && !loading && !fetchingDetails && (
                <button
                  type="button"
                  onClick={handleClear}
                  className="p-1 cursor-pointer rounded hover:bg-black/5 transition-colors"
                >
                  <X size={12} style={{ color: tokens.textMuted }} />
                </button>
              )}
              <MapPin size={14} style={{ color: tokens.textMuted }} />
            </div>
          </div>

          {/* Auto-detected coordinates in search mode */}
          {detectedCoords && !isOpen && (
            <div className="flex items-center gap-1.5 mt-1.5 px-1">
              <Navigation size={11} style={{ color: tokens.green }} />
              <p className="text-[11px] font-medium" style={{ color: tokens.green }}>
                Coordinates detected: {detectedCoords.lat.toFixed(5)}, {detectedCoords.lng.toFixed(5)}
                {(() => {
                  const d = reverseDistrictFromCoords(detectedCoords.lat, detectedCoords.lng);
                  return d ? <> &middot; {d}</> : null;
                })()}
              </p>
            </div>
          )}

          {/* Error / no results feedback */}
          {error && !isOpen && query.length >= 2 && !detectedCoords && (
            <div className="flex items-center gap-1.5 mt-1.5 px-1">
              <AlertCircle size={11} style={{ color: tokens.textMuted }} />
              <p className="text-[11px]" style={{ color: tokens.textMuted }}>{error}</p>
            </div>
          )}

          {/* Fetching details indicator */}
          {fetchingDetails && (
            <div className="flex items-center gap-1.5 mt-1.5 px-1">
              <Loader2 size={11} className="animate-spin" style={{ color: tokens.accent }} />
              <p className="text-[11px]" style={{ color: tokens.textMuted }}>Getting location details...</p>
            </div>
          )}
        </>
      )}

      {/* Dropdown via portal */}
      {dropdown}
    </div>
  );
}