/**
 * CategoryPills — shared multi-category pill display with primary indicator
 * Used across EventGridCard, MapPage popups, VenueInfoPanel, EventDetailPage, and admin pipeline.
 */
import { modeConfig, type Mode } from '../data/mock-data';

const CATEGORY_MODE_MAP: Record<string, Mode> = {
  'nightlife': 'degen',
  'art': 'artsy',
  'workshops': 'artsy',
  'food': 'foodie',
  'family': 'family',
  'run-clubs': 'lifestyle',
  'wellness': 'lifestyle',
  'hikes': 'lifestyle',
  'coffee-raves': 'lifestyle',
  'meetups': 'lifestyle',
  'other': 'lifestyle',
};

const CATEGORY_LABELS: Record<string, string> = {
  'run-clubs': 'Run Clubs',
  'wellness': 'Wellness',
  'hikes': 'Hikes',
  'coffee-raves': 'Coffee Raves',
  'workshops': 'Workshops',
  'meetups': 'Meetups',
  'nightlife': 'Nightlife',
  'art': 'Art',
  'food': 'Food',
  'family': 'Family',
  'other': 'Other',
};

export function getCategoryColor(cat: string, fallbackColor?: string): string {
  const mode = CATEGORY_MODE_MAP[cat];
  if (mode && mode !== 'lifestyle') {
    return modeConfig[mode]?.color || fallbackColor || '#8338EC';
  }
  if (mode === 'lifestyle') return '#2D6A4F';
  return fallbackColor || '#8338EC';
}

export function getCategoryLabel(cat: string): string {
  return CATEGORY_LABELS[cat] || cat;
}

/** Resolves categories array from mixed event data (supports both `categories` array and `category` string) */
export function resolveCategories(event: { category?: string; categories?: string[] }): string[] {
  if (event.categories && event.categories.length > 0) return event.categories;
  if (event.category) return [event.category];
  return [];
}

export type PillSize = 'xs' | 'sm' | 'md';

interface Props {
  categories: string[];
  /** Show primary indicator (slightly bolder first pill) */
  showPrimary?: boolean;
  size?: PillSize;
  /** Maximum number of pills to show before "+N more" */
  maxVisible?: number;
  /** For overlay contexts (white text on dark bg) */
  overlay?: boolean;
  className?: string;
}

const SIZE_STYLES: Record<PillSize, { fontSize: string; px: string; py: string; gap: string; iconSize: number }> = {
  xs: { fontSize: '9px', px: '4px', py: '1px', gap: '3px', iconSize: 6 },
  sm: { fontSize: '10px', px: '6px', py: '2px', gap: '4px', iconSize: 8 },
  md: { fontSize: '11px', px: '8px', py: '3px', gap: '6px', iconSize: 10 },
};

export function CategoryPills({ categories, showPrimary = true, size = 'sm', maxVisible = 4, overlay = false, className = '' }: Props) {
  if (!categories || categories.length === 0) return null;

  const s = SIZE_STYLES[size];
  const visible = categories.slice(0, maxVisible);
  const remaining = categories.length - maxVisible;

  return (
    <div className={`flex flex-wrap items-center ${className}`} style={{ gap: s.gap }}>
      {visible.map((cat, i) => {
        const color = getCategoryColor(cat);
        const isPrimary = showPrimary && i === 0 && categories.length > 1;
        return (
          <span
            key={cat}
            className="inline-flex items-center font-semibold uppercase tracking-wider"
            style={{
              fontSize: s.fontSize,
              padding: `${s.py} ${s.px}`,
              borderRadius: '4px',
              backgroundColor: overlay ? 'rgba(255,255,255,0.15)' : `${color}14`,
              color: overlay ? '#fff' : color,
              fontWeight: isPrimary ? 700 : 600,
              border: isPrimary ? `1.5px solid ${overlay ? 'rgba(255,255,255,0.3)' : `${color}30`}` : 'none',
            }}
          >
            {isPrimary && (
              <svg width={s.iconSize} height={s.iconSize} viewBox="0 0 12 12" fill="currentColor" style={{ marginRight: '2px', opacity: 0.7 }}>
                <path d="M6 0l1.76 3.58L12 4.16 8.98 7.1l.72 4.2L6 9.27 2.3 11.3l.72-4.2L0 4.16l4.24-.58z" />
              </svg>
            )}
            {getCategoryLabel(cat)}
          </span>
        );
      })}
      {remaining > 0 && (
        <span
          className="inline-flex items-center font-medium"
          style={{
            fontSize: s.fontSize,
            padding: `${s.py} ${s.px}`,
            borderRadius: '4px',
            backgroundColor: overlay ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.04)',
            color: overlay ? 'rgba(255,255,255,0.6)' : 'rgba(0,0,0,0.4)',
          }}
        >
          +{remaining}
        </span>
      )}
    </div>
  );
}
