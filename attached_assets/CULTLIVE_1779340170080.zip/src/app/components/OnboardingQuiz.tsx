import { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useTranslation } from 'react-i18next';
import { Check, ChevronRight, RotateCcw } from 'lucide-react';
import { useNeutralTheme } from '../context/NeutralThemeContext';

// ═══════════════════════════════════════════════════════════════════
// ONBOARDING TASTE QUIZ — "Help us get to know you"
// Voting chips, no vote counts, stored in localStorage
// Used to personalize the 3 weekly picks for anonymous users
// ═══════════════════════════════════════════════════════════════════

const LS_KEY = 'cultive:taste_quiz';

export interface TasteProfile {
  selections: string[]; // e.g. ['music:dnb', 'food:fine-dining', 'art:galleries']
  completedAt: string;
}

export function getTasteProfile(): TasteProfile | null {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  return null;
}

export function clearTasteProfile() {
  localStorage.removeItem(LS_KEY);
}

// ─── Taste categories with chips ───
interface TasteCategory {
  key: string;
  label: string;
  labelZh: string;
  emoji: string;
  chips: { id: string; label: string; labelZh: string }[];
}

const TASTE_CATEGORIES: TasteCategory[] = [
  {
    key: 'music',
    label: 'Music & Nightlife',
    labelZh: '音樂與夜生活',
    emoji: '🎵',
    chips: [
      { id: 'music:dnb', label: 'DnB', labelZh: 'DnB' },
      { id: 'music:electronic', label: 'Electronic / Techno', labelZh: '電子/Techno' },
      { id: 'music:hip-hop', label: 'Hip-Hop / R&B', labelZh: 'Hip-Hop / R&B' },
      { id: 'music:jazz', label: 'Jazz / Soul', labelZh: '爵士/靈魂' },
      { id: 'music:live', label: 'Live Bands', labelZh: '現場樂隊' },
      { id: 'music:indie', label: 'Indie / Alternative', labelZh: '獨立/另類' },
      { id: 'music:canto', label: 'Cantopop / Mandopop', labelZh: '廣東歌/華語' },
    ],
  },
  {
    key: 'food',
    label: 'Food & Drink',
    labelZh: '飲食',
    emoji: '🍜',
    chips: [
      { id: 'food:fine-dining', label: 'Fine Dining', labelZh: '高級餐廳' },
      { id: 'food:street', label: 'Street Food / Dai Pai Dong', labelZh: '街頭小食/大排檔' },
      { id: 'food:cafes', label: 'Specialty Coffee / Cafes', labelZh: '精品咖啡/Cafe' },
      { id: 'food:bars', label: 'Cocktail Bars / Wine', labelZh: '雞尾酒吧/葡萄酒' },
      { id: 'food:markets', label: 'Markets & Pop-ups', labelZh: '市集與快閃' },
      { id: 'food:brunch', label: 'Brunch / Casual', labelZh: 'Brunch/輕鬆聚餐' },
    ],
  },
  {
    key: 'art',
    label: 'Art & Culture',
    labelZh: '藝術與文化',
    emoji: '🎨',
    chips: [
      { id: 'art:galleries', label: 'Galleries & Exhibitions', labelZh: '畫廊與展覽' },
      { id: 'art:theatre', label: 'Theatre & Performance', labelZh: '劇場與表演' },
      { id: 'art:film', label: 'Indie Film / Screenings', labelZh: '獨立電影/放映' },
      { id: 'art:design', label: 'Design & Architecture', labelZh: '設計與建築' },
      { id: 'art:photography', label: 'Photography', labelZh: '攝影' },
      { id: 'art:workshops', label: 'Creative Workshops', labelZh: '創意工作坊' },
    ],
  },
  {
    key: 'wellness',
    label: 'Wellness & Outdoors',
    labelZh: '身心與戶外',
    emoji: '🧘',
    chips: [
      { id: 'wellness:yoga', label: 'Yoga / Pilates', labelZh: '瑜伽/普拉提' },
      { id: 'wellness:running', label: 'Run Clubs', labelZh: '跑步社群' },
      { id: 'wellness:hiking', label: 'Hiking / Nature', labelZh: '行山/自然' },
      { id: 'wellness:meditation', label: 'Meditation / Sound Bath', labelZh: '冥想/聲浴' },
      { id: 'wellness:fitness', label: 'CrossFit / Fitness', labelZh: '健身' },
    ],
  },
  {
    key: 'social',
    label: 'Social & Community',
    labelZh: '社交與社群',
    emoji: '🤝',
    chips: [
      { id: 'social:meetups', label: 'Meetups & Networking', labelZh: '聚會與社交' },
      { id: 'social:family', label: 'Family & Kids', labelZh: '親子活動' },
      { id: 'social:startup', label: 'Startup / Tech Events', labelZh: '創業/科技活動' },
      { id: 'social:language', label: 'Language Exchange', labelZh: '語言交換' },
      { id: 'social:volunteer', label: 'Volunteering', labelZh: '義工活動' },
    ],
  },
];

const C_DARK = {
  bg: '#1A1A1A',
  text: '#F5F0EA',
  muted: '#9A9488',
  accent: '#D4644F',
  border: '#333',
  cardBg: '#242424',
  chipBg: '#2A2A2A',
  chipActive: '#D4644F',
  chipActiveBg: '#D4644F22',
  btnBg: '#F5F0EA',
  btnText: '#1A1A1A',
};

const C = {
  bg: '#FDFAF6',
  text: '#1A1A1A',
  muted: '#8A8478',
  accent: '#B2483A',
  border: '#E8E1D9',
  cardBg: '#FFFDF9',
  chipBg: '#F5F0EA',
  chipActive: '#B2483A',
  chipActiveBg: '#B2483A14',
  btnBg: '#1A1A1A',
  btnText: '#ffffff',
};

function useQuizColors() {
  try {
    const { theme } = useNeutralTheme();
    return theme === 'dark' ? C_DARK : C;
  } catch {
    return C;
  }
}

interface OnboardingQuizProps {
  onComplete: (profile: TasteProfile) => void;
  compact?: boolean; // inline mode (no overlay)
}

export function OnboardingQuiz({ onComplete, compact }: OnboardingQuizProps) {
  const { i18n } = useTranslation();
  const isZh = i18n.language?.startsWith('zh');
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [step, setStep] = useState(0); // 0 = intro, 1+ = category steps

  const toggle = useCallback((id: string) => {
    setSelected(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  const finish = useCallback(() => {
    const profile: TasteProfile = {
      selections: Array.from(selected),
      completedAt: new Date().toISOString(),
    };
    localStorage.setItem(LS_KEY, JSON.stringify(profile));
    onComplete(profile);
  }, [selected, onComplete]);

  const totalCategories = TASTE_CATEGORIES.length;
  const currentCategory = step > 0 ? TASTE_CATEGORIES[step - 1] : null;
  const isLastStep = step === totalCategories;
  const canFinish = selected.size >= 2;

  const colors = useQuizColors();

  // ─── Intro screen ───
  if (step === 0) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className={compact ? 'py-8' : 'py-14'}
      >
        <div className="text-center px-5">
          <p className="mb-2" style={{ fontSize: '2rem' }}>
            👋
          </p>
          <h2
            className="mb-3"
            style={{
              fontFamily: "'Archivo Black', sans-serif",
              fontSize: compact ? '1.3rem' : '1.5rem',
              color: colors.text,
              letterSpacing: '-0.02em',
              lineHeight: 1.15,
            }}
          >
            {isZh ? '你喜歡什麼類型？' : 'What are you into?'}
          </h2>
          <p className="mb-8 mx-auto max-w-[280px]" style={{ fontSize: '0.9rem', color: colors.muted, lineHeight: 1.5 }}>
            {isZh
              ? '幫我們了解你的口味，我們會推薦最適合你的活動。'
              : "Help us understand your taste and we'll recommend events you'll actually want to go to."}
          </p>
          <button
            onClick={() => setStep(1)}
            className="inline-flex items-center gap-2 px-6 py-3 text-sm transition-all hover:opacity-90 cursor-pointer"
            style={{
              backgroundColor: colors.btnBg,
              color: colors.btnText,
              borderRadius: '12px',
              fontWeight: 600,
              border: 'none',
            }}
          >
            {isZh ? '開始（30秒）' : "Let's go (30 sec)"}
            <ChevronRight size={15} />
          </button>
          <p className="mt-4" style={{ fontSize: '0.7rem', color: colors.muted }}>
            {isZh ? '隨時可以跳過或重做' : 'Skip or redo anytime'}
          </p>
        </div>
      </motion.div>
    );
  }

  // ─── Category step ───
  if (currentCategory) {
    return (
      <motion.div
        key={currentCategory.key}
        initial={{ opacity: 0, x: 30 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: -30 }}
        transition={{ duration: 0.3 }}
        className="py-8 px-5"
      >
        {/* Progress */}
        <div className="flex items-center gap-2 mb-6">
          {TASTE_CATEGORIES.map((_, i) => (
            <div
              key={i}
              className="flex-1 h-1 rounded-full transition-colors"
              style={{
                backgroundColor: i < step ? colors.accent : `${colors.border}`,
              }}
            />
          ))}
        </div>

        <div className="flex items-center gap-2 mb-2">
          <span style={{ fontSize: '1.4rem' }}>{currentCategory.emoji}</span>
          <h3
            style={{
              fontFamily: "'Archivo Black', sans-serif",
              fontSize: '1.2rem',
              color: colors.text,
              letterSpacing: '-0.02em',
            }}
          >
            {isZh ? currentCategory.labelZh : currentCategory.label}
          </h3>
        </div>
        <p className="mb-5" style={{ fontSize: '0.8rem', color: colors.muted }}>
          {isZh ? '選你喜歡的（可多選或跳過）' : 'Pick what you like (multi-select or skip)'}
        </p>

        <div className="flex flex-wrap gap-2 mb-8">
          {currentCategory.chips.map((chip) => {
            const isActive = selected.has(chip.id);
            return (
              <motion.button
                key={chip.id}
                whileTap={{ scale: 0.95 }}
                onClick={() => toggle(chip.id)}
                className="flex items-center gap-1.5 px-3.5 py-2 text-sm cursor-pointer transition-all"
                style={{
                  backgroundColor: isActive ? colors.chipActiveBg : colors.chipBg,
                  border: `1.5px solid ${isActive ? colors.chipActive : 'transparent'}`,
                  borderRadius: '10px',
                  color: isActive ? colors.chipActive : colors.text,
                  fontWeight: isActive ? 600 : 400,
                }}
              >
                {isActive && <Check size={13} strokeWidth={3} />}
                {isZh ? chip.labelZh : chip.label}
              </motion.button>
            );
          })}
        </div>

        <div className="flex items-center gap-3">
          {step > 1 && (
            <button
              onClick={() => setStep(s => s - 1)}
              className="px-4 py-2.5 text-xs cursor-pointer transition-opacity hover:opacity-70"
              style={{ color: colors.muted, backgroundColor: 'transparent', border: 'none' }}
            >
              {isZh ? '上一步' : 'Back'}
            </button>
          )}
          <button
            onClick={() => {
              if (step < totalCategories) setStep(s => s + 1);
              else finish();
            }}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 text-sm cursor-pointer transition-all hover:opacity-90"
            style={{
              backgroundColor: colors.btnBg,
              color: colors.btnText,
              borderRadius: '10px',
              fontWeight: 600,
              border: 'none',
            }}
          >
            {step < totalCategories
              ? (isZh ? '下一步' : 'Next')
              : (isZh ? '完成' : 'Done')}
            <ChevronRight size={14} />
          </button>
          {step < totalCategories && (
            <button
              onClick={() => setStep(s => s + 1)}
              className="px-4 py-2.5 text-xs cursor-pointer transition-opacity hover:opacity-70"
              style={{ color: colors.muted, backgroundColor: 'transparent', border: 'none' }}
            >
              {isZh ? '跳過' : 'Skip'}
            </button>
          )}
        </div>
      </motion.div>
    );
  }

  // ─── Final summary / done ───
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.4 }}
      className="py-10 px-5 text-center"
    >
      <p className="mb-3" style={{ fontSize: '2rem' }}>
        ✨
      </p>
      <h3
        className="mb-2"
        style={{
          fontFamily: "'Archivo Black', sans-serif",
          fontSize: '1.3rem',
          color: colors.text,
          letterSpacing: '-0.02em',
        }}
      >
        {isZh ? '了解你了！' : 'Got it!'}
      </h3>
      <p className="mb-2" style={{ fontSize: '0.85rem', color: colors.muted }}>
        {selected.size > 0
          ? (isZh
              ? `你選了 ${selected.size} 個興趣 — 我們會據此推薦活動。`
              : `${selected.size} interests selected — we'll tailor your picks.`)
          : (isZh ? '沒有選擇也行 — 我們會顯示綜合推介。' : "No selections — we'll show our general picks.")}
      </p>
      <button
        onClick={finish}
        className={`inline-flex items-center gap-2 px-6 py-3 text-sm mt-4 cursor-pointer transition-all hover:opacity-90`}
        style={{
          backgroundColor: colors.accent,
          color: '#ffffff',
          borderRadius: '12px',
          fontWeight: 600,
          border: 'none',
        }}
      >
        {isZh ? '看我的推薦' : 'Show my picks'}
        <ChevronRight size={15} />
      </button>
    </motion.div>
  );
}

// ─── Compact reset button (used in settings or editorial footer) ───
export function ResetTasteButton({ onReset }: { onReset?: () => void }) {
  const { i18n } = useTranslation();
  const isZh = i18n.language?.startsWith('zh');

  return (
    <button
      onClick={() => {
        clearTasteProfile();
        onReset?.();
      }}
      className="flex items-center gap-1.5 px-3 py-1.5 text-xs cursor-pointer transition-opacity hover:opacity-70"
      style={{ color: C.muted, backgroundColor: 'transparent', border: `1px solid ${C.border}`, borderRadius: '8px' }}
    >
      <RotateCcw size={12} />
      {isZh ? '重設口味' : 'Reset taste quiz'}
    </button>
  );
}

// ─── Mapping: taste chip IDs → event matching tags ───
// Used by useWeeklyPicks to score events against user preferences
export const TASTE_TO_EVENT_MAP: Record<string, { categories: string[]; vibes: string[]; keywords: string[] }> = {
  'music:dnb': { categories: ['nightlife'], vibes: ['bass', 'underground'], keywords: ['dnb', 'drum and bass', 'drum & bass', 'jungle'] },
  'music:electronic': { categories: ['nightlife'], vibes: ['underground', 'warehouse'], keywords: ['electronic', 'techno', 'house', 'trance', 'edm', 'rave'] },
  'music:hip-hop': { categories: ['nightlife'], vibes: ['urban'], keywords: ['hip-hop', 'hip hop', 'r&b', 'rnb', 'rap'] },
  'music:jazz': { categories: ['nightlife', 'art'], vibes: ['chill', 'intimate'], keywords: ['jazz', 'soul', 'blues', 'swing'] },
  'music:live': { categories: ['nightlife'], vibes: ['energetic'], keywords: ['live music', 'live band', 'concert', 'gig'] },
  'music:indie': { categories: ['nightlife', 'art'], vibes: ['alternative'], keywords: ['indie', 'alternative', 'lo-fi'] },
  'music:canto': { categories: ['nightlife', 'art'], vibes: [], keywords: ['cantopop', 'mandopop', '廣東歌', '粵語'] },
  'food:fine-dining': { categories: ['food'], vibes: ['luxury', 'high-end'], keywords: ['fine dining', 'tasting menu', 'michelin', 'omakase'] },
  'food:street': { categories: ['food'], vibes: ['local', 'casual'], keywords: ['street food', 'dai pai dong', 'hawker', 'local food'] },
  'food:cafes': { categories: ['food', 'coffee-raves'], vibes: ['chill'], keywords: ['coffee', 'cafe', 'specialty coffee', 'latte art'] },
  'food:bars': { categories: ['food', 'nightlife'], vibes: ['intimate', 'social'], keywords: ['cocktail', 'wine', 'bar', 'speakeasy', 'happy hour'] },
  'food:markets': { categories: ['food'], vibes: ['social', 'outdoor'], keywords: ['market', 'pop-up', 'popup', 'farmers market', 'street market'] },
  'food:brunch': { categories: ['food'], vibes: ['casual', 'social'], keywords: ['brunch', 'breakfast', 'casual dining'] },
  'art:galleries': { categories: ['art'], vibes: ['contemplative'], keywords: ['gallery', 'exhibition', 'art show', 'installation'] },
  'art:theatre': { categories: ['art'], vibes: ['dramatic'], keywords: ['theatre', 'theater', 'performance', 'play', 'dance', 'ballet'] },
  'art:film': { categories: ['art'], vibes: ['alternative'], keywords: ['film', 'screening', 'cinema', 'movie', 'documentary'] },
  'art:design': { categories: ['art'], vibes: ['creative'], keywords: ['design', 'architecture', 'graphic', 'typography'] },
  'art:photography': { categories: ['art'], vibes: ['creative'], keywords: ['photography', 'photo', 'camera'] },
  'art:workshops': { categories: ['workshops', 'art'], vibes: ['creative', 'hands-on'], keywords: ['workshop', 'class', 'pottery', 'ceramics', 'painting'] },
  'wellness:yoga': { categories: ['wellness'], vibes: ['calm', 'mindful'], keywords: ['yoga', 'pilates', 'stretch'] },
  'wellness:running': { categories: ['run-clubs'], vibes: ['energetic', 'social'], keywords: ['run club', 'running', 'jog', '5k', '10k'] },
  'wellness:hiking': { categories: ['hikes'], vibes: ['outdoor', 'nature'], keywords: ['hike', 'hiking', 'trail', 'peak', 'nature'] },
  'wellness:meditation': { categories: ['wellness'], vibes: ['calm', 'mindful'], keywords: ['meditation', 'sound bath', 'breathwork', 'mindfulness'] },
  'wellness:fitness': { categories: ['wellness'], vibes: ['energetic'], keywords: ['crossfit', 'fitness', 'gym', 'workout', 'HIIT'] },
  'social:meetups': { categories: ['meetups'], vibes: ['social'], keywords: ['meetup', 'networking', 'social', 'gathering'] },
  'social:family': { categories: ['family'], vibes: ['family-friendly'], keywords: ['family', 'kids', 'children', 'parent'] },
  'social:startup': { categories: ['meetups'], vibes: ['entrepreneurial'], keywords: ['startup', 'tech', 'hackathon', 'pitch'] },
  'social:language': { categories: ['meetups'], vibes: ['social'], keywords: ['language exchange', 'conversation', 'tandem'] },
  'social:volunteer': { categories: ['meetups'], vibes: ['community'], keywords: ['volunteer', 'charity', 'cleanup', 'community service'] },
};