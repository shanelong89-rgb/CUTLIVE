import React from 'react';
import { useMode } from '../context/ModeContext';
import { getDesignTokens, isLightMode } from '../data/mode-styles';
import { LC } from '../data/lifestyle-data';

// ─── Shimmer keyframe injected once ───
const SHIMMER_CSS = `
@keyframes cultive-shimmer {
  0% { transform: translateX(-100%); }
  100% { transform: translateX(100%); }
}
`;
let shimmerInjected = false;
function ensureShimmer() {
  if (shimmerInjected) return;
  shimmerInjected = true;
  const style = document.createElement('style');
  style.textContent = SHIMMER_CSS;
  document.head.appendChild(style);
}

// ─── Shimmer bar ───
function Shimmer({ className = '', style: extraStyle = {} }: { className?: string; style?: React.CSSProperties }) {
  ensureShimmer();
  return (
    <div className={`relative overflow-hidden ${className}`} style={{ ...extraStyle }}>
      <div
        className="absolute inset-0"
        style={{
          background: 'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.12) 50%, transparent 100%)',
          animation: 'cultive-shimmer 1.6s ease-in-out infinite',
        }}
      />
    </div>
  );
}

// ─── Event card skeleton ───
function EventCardSkeleton({ tokens, light, idx }: { tokens: ReturnType<typeof getDesignTokens>; light: boolean; idx: number }) {
  const bg = light ? 'rgba(0,0,0,0.04)' : 'rgba(255,255,255,0.06)';
  const bar = light ? 'rgba(0,0,0,0.07)' : 'rgba(255,255,255,0.08)';
  return (
    <div
      className="rounded-lg overflow-hidden"
      style={{
        background: tokens.cardBg,
        border: `1px solid ${tokens.cardBorder}`,
        borderRadius: tokens.cardRadius,
        animationDelay: `${idx * 80}ms`,
      }}
    >
      {/* Image placeholder */}
      <Shimmer
        className="w-full"
        style={{ height: '180px', backgroundColor: bg, borderRadius: `${tokens.imageRadius} ${tokens.imageRadius} 0 0` }}
      />
      {/* Text placeholders */}
      <div className="p-4 space-y-3">
        <Shimmer className="rounded" style={{ height: '14px', width: '35%', backgroundColor: bar }} />
        <Shimmer className="rounded" style={{ height: '18px', width: '80%', backgroundColor: bar }} />
        <div className="flex items-center gap-2 pt-1">
          <Shimmer className="rounded" style={{ height: '12px', width: '24%', backgroundColor: bar }} />
          <Shimmer className="rounded" style={{ height: '12px', width: '30%', backgroundColor: bar }} />
        </div>
        <Shimmer className="rounded" style={{ height: '12px', width: '50%', backgroundColor: bar }} />
      </div>
    </div>
  );
}

// ─── Venue card skeleton (for map list) ───
function VenueCardSkeleton({ tokens, light, idx }: { tokens: ReturnType<typeof getDesignTokens>; light: boolean; idx: number }) {
  const bar = light ? 'rgba(0,0,0,0.07)' : 'rgba(255,255,255,0.08)';
  return (
    <div
      className="flex items-center gap-3 p-3 rounded-lg"
      style={{
        background: tokens.cardBg,
        border: `1px solid ${tokens.cardBorder}`,
        borderRadius: tokens.cardRadius,
        animationDelay: `${idx * 60}ms`,
      }}
    >
      <Shimmer className="flex-shrink-0 rounded" style={{ width: '56px', height: '56px', backgroundColor: bar, borderRadius: tokens.imageRadius }} />
      <div className="flex-1 space-y-2">
        <Shimmer className="rounded" style={{ height: '14px', width: '60%', backgroundColor: bar }} />
        <Shimmer className="rounded" style={{ height: '11px', width: '40%', backgroundColor: bar }} />
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════
// EVENTS PAGE SKELETON
// ═══════════════════════════════════════════════
export function EventsPageSkeleton() {
  const { currentMode } = useMode();
  const tokens = getDesignTokens(currentMode);
  const light = isLightMode(currentMode);
  const bar = light ? 'rgba(0,0,0,0.07)' : 'rgba(255,255,255,0.08)';

  return (
    <div className="min-h-screen" style={{ backgroundColor: tokens.pageBg }}>
      {/* Hero skeleton */}
      <div className="px-4 sm:px-8 lg:px-12 pt-8 pb-6">
        <div className="max-w-[1440px] mx-auto space-y-4">
          <Shimmer className="rounded" style={{ height: '16px', width: '120px', backgroundColor: bar }} />
          <Shimmer className="rounded" style={{ height: '32px', width: '260px', backgroundColor: bar }} />
          <div className="flex gap-2 pt-2">
            {[80, 60, 70, 90].map((w, i) => (
              <Shimmer key={i} className="rounded-full" style={{ height: '32px', width: `${w}px`, backgroundColor: bar }} />
            ))}
          </div>
        </div>
      </div>

      {/* Event grid skeleton */}
      <div className="max-w-[1440px] mx-auto px-4 sm:px-8 lg:px-12 pb-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {Array.from({ length: 8 }, (_, i) => (
            <EventCardSkeleton key={i} tokens={tokens} light={light} idx={i} />
          ))}
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════
// MAP PAGE SKELETON
// ═══════════════════════════════════════════════
export function MapPageSkeleton() {
  const { currentMode } = useMode();
  const tokens = getDesignTokens(currentMode);
  const light = isLightMode(currentMode);
  const bar = light ? 'rgba(0,0,0,0.07)' : 'rgba(255,255,255,0.08)';
  const listBg = currentMode === 'degen' ? '#0A0A0A' : currentMode === 'lifestyle' ? '#122A20' : currentMode === 'foodie' ? '#0A1220' : tokens.pageBg;

  return (
    <div className="relative h-[calc(100vh-64px)] overflow-hidden flex flex-col sm:flex-row">
      {/* Sidebar */}
      <div className="w-full sm:w-[380px] lg:w-[440px] flex-shrink-0 h-[60%] sm:h-full overflow-hidden order-2 sm:order-1" style={{ backgroundColor: listBg }}>
        <div className="px-3 sm:px-4 pt-3 sm:pt-4 pb-2 space-y-3">
          <Shimmer className="rounded" style={{ height: '14px', width: '80px', backgroundColor: bar }} />
          <div className="flex gap-2">
            {[60, 50, 70].map((w, i) => (
              <Shimmer key={i} className="rounded-full" style={{ height: '28px', width: `${w}px`, backgroundColor: bar }} />
            ))}
          </div>
        </div>
        <div className="px-3 pb-4 space-y-2">
          {Array.from({ length: 6 }, (_, i) => (
            <VenueCardSkeleton key={i} tokens={tokens} light={light} idx={i} />
          ))}
        </div>
      </div>
      {/* Map area */}
      <div className="flex-1 order-1 sm:order-2 h-[40%] sm:h-full" style={{ backgroundColor: light ? '#e8e4df' : '#1a1a2e' }}>
        <Shimmer className="w-full h-full" style={{ backgroundColor: light ? 'rgba(0,0,0,0.03)' : 'rgba(255,255,255,0.03)' }} />
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════
// LIFESTYLE PAGE SKELETON
// ═══════════════════════════════════════════════
export function LifestylePageSkeleton() {
  const bar = 'rgba(45,106,79,0.1)';
  return (
    <div className="min-h-screen" style={{ backgroundColor: LC.offWhite }}>
      {/* Hero skeleton */}
      <div className="relative h-[50vh] sm:h-[60vh]">
        <Shimmer className="w-full h-full" style={{ backgroundColor: 'rgba(45,106,79,0.06)' }} />
        <div className="absolute bottom-8 left-8 space-y-3">
          <Shimmer className="rounded" style={{ height: '12px', width: '80px', backgroundColor: bar }} />
          <Shimmer className="rounded" style={{ height: '28px', width: '220px', backgroundColor: bar }} />
          <Shimmer className="rounded" style={{ height: '14px', width: '160px', backgroundColor: bar }} />
        </div>
      </div>

      {/* Categories skeleton */}
      <div className="max-w-[1200px] mx-auto px-6 py-8">
        <div className="flex gap-3 mb-8">
          {[50, 75, 60, 85, 65, 55].map((w, i) => (
            <Shimmer key={i} className="rounded-full" style={{ height: '36px', width: `${w}px`, backgroundColor: bar }} />
          ))}
        </div>
        {/* Event cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {Array.from({ length: 6 }, (_, i) => (
            <div key={i} className="rounded-2xl overflow-hidden" style={{ border: `1px solid ${LC.deepForestBorder}`, background: LC.deepForestCard }}>
              <Shimmer className="w-full" style={{ height: '160px', backgroundColor: 'rgba(149,213,178,0.06)' }} />
              <div className="p-4 space-y-3">
                <Shimmer className="rounded" style={{ height: '10px', width: '30%', backgroundColor: 'rgba(149,213,178,0.1)' }} />
                <Shimmer className="rounded" style={{ height: '16px', width: '75%', backgroundColor: 'rgba(149,213,178,0.1)' }} />
                <div className="flex gap-2">
                  <Shimmer className="rounded" style={{ height: '10px', width: '25%', backgroundColor: 'rgba(149,213,178,0.1)' }} />
                  <Shimmer className="rounded" style={{ height: '10px', width: '30%', backgroundColor: 'rgba(149,213,178,0.1)' }} />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════
// HOME / MODE PAGE SKELETON
// ═══════════════════════════════════════════════
export function HomePageSkeleton() {
  const { currentMode } = useMode();
  const tokens = getDesignTokens(currentMode);
  const light = isLightMode(currentMode);
  const bar = light ? 'rgba(0,0,0,0.07)' : 'rgba(255,255,255,0.08)';

  return (
    <div className="min-h-screen" style={{ backgroundColor: tokens.pageBg }}>
      {/* Hero */}
      <Shimmer className="w-full" style={{ height: '45vh', backgroundColor: light ? 'rgba(0,0,0,0.04)' : 'rgba(255,255,255,0.04)' }} />
      {/* Content */}
      <div className="max-w-[1200px] mx-auto px-4 sm:px-8 py-8 space-y-6">
        <Shimmer className="rounded" style={{ height: '24px', width: '200px', backgroundColor: bar }} />
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {Array.from({ length: 4 }, (_, i) => (
            <EventCardSkeleton key={i} tokens={tokens} light={light} idx={i} />
          ))}
        </div>
      </div>
    </div>
  );
}