import { useMemo } from 'react';
import {
  Moon, Users, Palette, UtensilsCrossed,
  Music, EyeOff, Zap, GalleryHorizontal, Layers,
  Theater, Film, Camera, Flame, Wine, Store,
  Hammer, TreePine, Baby, Heart, MapPin,
  Sun, Calendar, CalendarDays,
  PartyPopper, Coffee, Martini, CakeSlice, Soup,
  Fish, ShieldCheck, Car, Star, Building2,
  Compass, Landmark, Drama, Leaf,
  type LucideIcon,
} from 'lucide-react';
import { motion, type Variants, type Transition } from 'motion/react';
import type { Mode } from '../data/mock-data';
import { modeConfig } from '../data/mock-data';

// ─── Master icon registry ───
const ICON_MAP: Record<string, LucideIcon> = {
  // Modes
  degen: Moon,
  family: Users,
  artsy: Palette,
  foodie: UtensilsCrossed,
  lifestyle: Leaf,

  // Interests / categories
  nightlife: Moon,
  music: Music,
  underground: EyeOff,
  popup: Zap,
  galleries: GalleryHorizontal,
  exhibitions: Layers,
  theater: Drama,
  film: Film,
  photography: Camera,
  worship: Flame,
  food: UtensilsCrossed,
  drinks: Wine,
  markets: Store,
  workshops: Hammer,
  outdoor: TreePine,
  kids: Baby,
  community: Users,
  wellness: Heart,

  // Venue categories (map markers)
  nightclub: PartyPopper,
  bar: Martini,
  speakeasy: EyeOff,
  lounge: Wine,
  park: TreePine,
  museum: Landmark,
  cafe: Coffee,
  gallery: GalleryHorizontal,
  exhibition: Layers,
  studio: Palette,
  restaurant: UtensilsCrossed,
  market: Store,
  bakery: CakeSlice,

  // Foodie sub-categories
  noodles: Soup,
  sushi: Fish,
  hotpot: Flame,
  tea: Coffee,
  cocktails: Martini,

  // Family sub-categories
  'babies-toddlers': Baby,
  'creative-kids': Palette,
  'young-explorers': Compass,
  'outdoor-fun': TreePine,
  museums: Landmark,
  'shows-theater': Drama,

  // Family features
  'kid-verified': ShieldCheck,
  'family-facilities': Building2,
  'nearby-parking': Car,
  'parent-reviews': Star,

  // Time periods
  'past-week': CalendarDays,
  'past-month': Calendar,
  'past-year': Sun,
};

// ─── Which mode does a given icon key belong to? ───
// Used to auto-resolve colour when `mode` is provided as `'auto'`
const ICON_MODE_AFFINITY: Record<string, string> = {
  degen: 'degen', nightlife: 'degen', music: 'degen', underground: 'degen',
  nightclub: 'degen', bar: 'degen', speakeasy: 'degen', lounge: 'degen',
  artsy: 'artsy', galleries: 'artsy', exhibitions: 'artsy', theater: 'artsy',
  film: 'artsy', photography: 'artsy', worship: 'artsy', gallery: 'artsy',
  exhibition: 'artsy', studio: 'artsy',
  foodie: 'foodie', food: 'foodie', drinks: 'foodie', markets: 'foodie',
  noodles: 'foodie', sushi: 'foodie', hotpot: 'foodie', tea: 'foodie',
  cocktails: 'foodie', restaurant: 'foodie', market: 'foodie', bakery: 'foodie', cafe: 'foodie',
  family: 'family', workshops: 'family', outdoor: 'family', kids: 'family',
  community: 'family', wellness: 'family', park: 'family', museum: 'family',
  'babies-toddlers': 'family', 'creative-kids': 'family', 'young-explorers': 'family',
  'outdoor-fun': 'family', museums: 'family', 'shows-theater': 'family',
  'kid-verified': 'family', 'family-facilities': 'family', 'nearby-parking': 'family',
  'parent-reviews': 'family',
  lifestyle: 'lifestyle',
};

// ═══════════════════════════════════════════════════════════════
// Mode-specific glow & colour presets
// ═══════════════════════════════════════════════════════════════

interface ModeIconTheme {
  color: string;
  glow: string;        // CSS filter for neon/ambient glow
  glowShadow: string;  // text-shadow for an outer halo
}

const MODE_ICON_THEMES: Record<string, ModeIconTheme> = {
  degen: {
    color: '#D600FF',
    glow: 'drop-shadow(0 0 4px rgba(214,0,255,0.7)) drop-shadow(0 0 12px rgba(214,0,255,0.35))',
    glowShadow: '0 0 6px rgba(214,0,255,0.55), 0 0 18px rgba(214,0,255,0.25), 0 0 30px rgba(214,0,255,0.10)',
  },
  artsy: {
    color: '#8338EC',
    glow: 'drop-shadow(0 0 3px rgba(131,56,236,0.35))',
    glowShadow: '0 0 4px rgba(131,56,236,0.25), 0 0 12px rgba(131,56,236,0.10)',
  },
  family: {
    color: '#FF8C42',
    glow: 'drop-shadow(0 0 3px rgba(255,140,66,0.4))',
    glowShadow: '0 0 4px rgba(255,140,66,0.3), 0 0 10px rgba(255,140,66,0.12)',
  },
  foodie: {
    color: '#2563EB',
    glow: 'drop-shadow(0 0 3px rgba(37,99,235,0.5)) drop-shadow(0 0 10px rgba(37,99,235,0.2))',
    glowShadow: '0 0 5px rgba(37,99,235,0.4), 0 0 14px rgba(37,99,235,0.15)',
  },
  lifestyle: {
    color: '#2D6A4F',
    glow: 'drop-shadow(0 0 3px rgba(45,106,79,0.4))',
    glowShadow: '0 0 4px rgba(45,106,79,0.3), 0 0 10px rgba(45,106,79,0.12)',
  },
};

// ═══════════════════════════════════════════════════════════════
// Per-mode hover animation variants
// ═══════════════════════════════════════════════════════════════

type HoverPreset = 'neon-pulse' | 'elegant-lift' | 'bounce' | 'sizzle' | 'scale';

const MODE_HOVER_PRESET: Record<string, HoverPreset> = {
  degen: 'neon-pulse',
  artsy: 'elegant-lift',
  family: 'bounce',
  foodie: 'sizzle',
  lifestyle: 'elegant-lift',
};

function getHoverVariants(preset: HoverPreset): { variants: Variants; transition: Transition } {
  switch (preset) {
    case 'neon-pulse':
      return {
        variants: {
          idle: { scale: 1, rotate: 0, filter: 'brightness(1)' },
          hover: {
            scale: [1, 1.18, 1.12],
            rotate: [0, -6, 6, 0],
            filter: ['brightness(1)', 'brightness(1.4)', 'brightness(1.2)'],
          },
        },
        transition: { duration: 0.5, ease: 'easeInOut' },
      };
    case 'elegant-lift':
      return {
        variants: {
          idle: { scale: 1, y: 0, rotate: 0 },
          hover: { scale: 1.08, y: -2, rotate: -3 },
        },
        transition: { duration: 0.45, ease: [0.22, 1, 0.36, 1] },
      };
    case 'bounce':
      return {
        variants: {
          idle: { scale: 1, y: 0 },
          hover: {
            scale: [1, 1.25, 0.92, 1.1, 1],
            y: [0, -4, 1, -2, 0],
          },
        },
        transition: { duration: 0.55, ease: 'easeOut' },
      };
    case 'sizzle':
      return {
        variants: {
          idle: { scale: 1, rotate: 0 },
          hover: {
            scale: [1, 1.15, 1.08],
            rotate: [0, -8, 8, -4, 0],
          },
        },
        transition: { duration: 0.45, ease: 'easeInOut' },
      };
    case 'scale':
    default:
      return {
        variants: {
          idle: { scale: 1 },
          hover: { scale: 1.12 },
        },
        transition: { duration: 0.25, ease: 'easeOut' },
      };
  }
}

// ═══════════════════════════════════════════════════════════════
// CIcon component
// ═══════════════════════════════════════════════════════════════

interface CIconProps {
  /** The icon key — a mode name, interest id, venue category, etc. */
  id: string;
  size?: number;
  className?: string;
  style?: React.CSSProperties;

  // ── Mode-aware theming (opt-in) ──
  /**
   * Pass a Mode to activate mode-specific colour & glow.
   * Pass `'auto'` to infer the mode from the icon key.
   * Leave undefined (default) for no mode theming — fully backward-compatible.
   */
  mode?: Mode | 'lifestyle' | 'auto' | null;

  /** Enable the neon / ambient glow halo. Defaults to true when a mode is active. */
  glow?: boolean;

  // ── Hover animation (opt-in) ──
  /** Wrap in motion.span and animate on hover. Off by default. */
  animated?: boolean;

  /** Override the hover preset. If omitted, chosen from the active mode. */
  hoverEffect?: HoverPreset;
}

/**
 * Centralized icon component for CULTIVE.
 *
 * Basic usage (backward-compatible):
 *   <CIcon id="degen" size={20} />
 *
 * Mode-aware colour + glow:
 *   <CIcon id="nightlife" size={20} mode="degen" />
 *   <CIcon id="nightlife" size={20} mode="auto" />
 *
 * Animated on hover:
 *   <CIcon id="degen" size={24} mode="degen" animated />
 */
export function CIcon({
  id,
  size = 14,
  className,
  style,
  mode,
  glow,
  animated = false,
  hoverEffect,
}: CIconProps) {
  const Icon = ICON_MAP[id] || MapPin;

  // Resolve mode
  const resolvedMode: string | null = useMemo(() => {
    if (mode === 'auto') return ICON_MODE_AFFINITY[id] ?? null;
    if (mode === undefined || mode === null) return null;
    return mode;
  }, [mode, id]);

  const theme = resolvedMode ? MODE_ICON_THEMES[resolvedMode] : null;

  // Should glow? Default to true when a mode is active, unless explicitly false
  const showGlow = glow !== undefined ? glow : !!resolvedMode;

  // Merge styles — explicit style.color wins over theme colour
  const mergedStyle = useMemo<React.CSSProperties>(() => {
    const base: React.CSSProperties = { ...style };
    if (theme && !base.color) {
      base.color = theme.color;
    }
    if (showGlow && theme) {
      base.filter = [base.filter, theme.glow].filter(Boolean).join(' ');
    }
    return base;
  }, [style, theme, showGlow]);

  // Non-animated render (fast path for most usages)
  if (!animated) {
    return <Icon size={size} className={className} style={mergedStyle} />;
  }

  // Animated render
  const preset = hoverEffect ?? (resolvedMode ? MODE_HOVER_PRESET[resolvedMode] : 'scale');
  const { variants, transition } = getHoverVariants(preset);

  return (
    <motion.span
      className={`inline-flex items-center justify-center ${className ?? ''}`}
      style={{ display: 'inline-flex', lineHeight: 0 }}
      variants={variants}
      initial="idle"
      whileHover="hover"
      transition={transition}
    >
      <Icon size={size} style={mergedStyle} />
    </motion.span>
  );
}

/**
 * Get the Lucide icon component for a mode.
 * Useful when you need the component reference itself (e.g. for map markers).
 */
export function getModeIcon(mode: Mode): LucideIcon {
  return ICON_MAP[mode] || MapPin;
}

/**
 * Get the Lucide icon component for any key.
 */
export function getIcon(id: string): LucideIcon {
  return ICON_MAP[id] || MapPin;
}

/**
 * Look up the mode-specific icon theme for colour/glow values outside of CIcon.
 */
export function getModeIconTheme(mode: Mode): ModeIconTheme {
  return MODE_ICON_THEMES[mode];
}

/**
 * Render an SVG string for use inside Leaflet divIcon HTML.
 * Returns an inline SVG that matches the Lucide icon for the given category.
 */
export function getMarkerSvg(category: string, size: number = 18, color: string = 'currentColor'): string {
  // Compact SVG paths for map markers — keeps the HTML lightweight
  const svgPaths: Record<string, string> = {
    nightclub: `<circle cx="12" cy="12" r="3"/><path d="M12 2v2m0 16v2M4.93 4.93l1.41 1.41m11.32 11.32 1.41 1.41M2 12h2m16 0h2M4.93 19.07l1.41-1.41m11.32-11.32 1.41-1.41"/><path d="m8 16 1.5-3.5L13 11l1.5 3.5L18 16"/>`,
    bar: `<path d="M8 22h8"/><path d="M12 11v11"/><path d="m19 3-7 8-7-8Z"/>`,
    speakeasy: `<path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/><line x1="2" y1="2" x2="22" y2="22"/>`,
    lounge: `<path d="M17 11h1a3 3 0 0 1 0 6h-1"/><path d="M9 12a3 3 0 0 0-3-3H3v9h3a3 3 0 0 0 3-3"/><path d="M9 18h6"/><path d="M9 12h6"/>`,
    park: `<path d="m17 14 3 3.3a1 1 0 0 1-.7 1.7H4.7a1 1 0 0 1-.7-1.7L7 14"/><path d="m12 2 4.6 7.4a1 1 0 0 1-.8 1.6H8.2a1 1 0 0 1-.8-1.6L12 2Z"/><path d="M12 11v8"/>`,
    museum: `<path d="M3 22h18"/><path d="M6 18v-7"/><path d="M10 18v-7"/><path d="M14 18v-7"/><path d="M18 18v-7"/><path d="M12 2 3 7h18Z"/>`,
    cafe: `<path d="M10 2v2"/><path d="M14 2v2"/><path d="M16 8a1 1 0 0 1 1 1v8a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4V9a1 1 0 0 1 1-1h14z"/><path d="M16 8h2a2 2 0 0 1 2 2v1a2 2 0 0 1-2 2h-2"/>`,
    gallery: `<rect x="2" y="7" width="20" height="15" rx="2" ry="2"/><polyline points="17 2 12 7 7 2"/>`,
    exhibition: `<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18"/><path d="M9 21V9"/>`,
    studio: `<circle cx="13.5" cy="6.5" r="2.5"/><path d="M17 2H7a5 5 0 0 0-5 5v10a5 5 0 0 0 5 5h10a5 5 0 0 0 5-5V7a5 5 0 0 0-5-5Z"/>`,
    theater: `<path d="M2 10.5c2 0 4-1.5 6-1.5s4 1.5 6 1.5 4-1.5 6-1.5"/><path d="M2 13.5c2 0 4-1.5 6-1.5s4 1.5 6 1.5 4-1.5 6-1.5"/><path d="M2 4h20"/><path d="M4 4v16"/><path d="M20 4v16"/>`,
    restaurant: `<path d="M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2"/><path d="M7 2v20"/><path d="M21 15V2a5 5 0 0 0-5 5v6c0 1.1.9 2 2 2h3Zm0 0v7"/>`,
    popup: `<path d="m13 2-2 2.5h3L12 7"/><path d="M10 14v-3"/><path d="M14 14v-3"/><path d="M11 19c-1.7 0-3-1.3-3-3v-2h8v2c0 1.7-1.3 3-3 3Z"/>`,
    market: `<path d="m2 7 4.41-4.41A2 2 0 0 1 7.83 2h8.34a2 2 0 0 1 1.42.59L22 7"/><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><path d="M15 22v-4a2 2 0 0 0-2-2h-2a2 2 0 0 0-2 2v4"/><path d="M2 7h20"/><path d="M22 7v3a2 2 0 0 1-2 2a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 16 12a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 12 12a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 8 12a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 4 12a2 2 0 0 1-2-2V7"/>`,
    bakery: `<path d="M20 21v-8a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8"/><path d="M4 16s.5-1 2-1 2.5 2 4 2 2.5-2 4-2 2.5 2 4 2 2-1 2-1"/><path d="M2 21h20"/><path d="M7 8v3"/><path d="M12 8v3"/><path d="M17 8v3"/><path d="M7 4h.01"/><path d="M12 4h.01"/><path d="M17 4h.01"/>`,
  };

  const paths = svgPaths[category] || `<circle cx="12" cy="12" r="3"/><path d="M12 2v2m0 16v2"/>`;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${paths}</svg>`;
}