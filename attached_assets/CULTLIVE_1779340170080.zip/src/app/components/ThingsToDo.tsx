import { useState, useMemo, useEffect } from 'react';
import { Link } from 'react-router';
import { useTranslation } from 'react-i18next';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, MapPin, Clock, ArrowRight, ChevronLeft, ChevronRight, Sun, Calendar, CalendarDays, Eye } from 'lucide-react';
import { useMode } from '../context/ModeContext';
import { useData } from '../context/DataContext';
import { useTimePeriod } from '../context/TimePeriodContext';
import { modeConfig, type Mode, type CulturalEvent } from '../data/mock-data';
import { getDesignTokens } from '../data/mode-styles';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { getEventLink } from '../utils/event-helpers';
import { parseEventDate, getHKToday } from '../utils/date-helpers';
import { useTemplateData } from '../hooks/useTemplateData';
import { useEventStats } from '../context/EventStatsContext';

type TimePeriod = 'today' | 'week' | 'month';

function getTimeFilteredEvents(events: CulturalEvent[], period: TimePeriod, mode: Mode | null): CulturalEvent[] {
  const today = getHKToday();

  // Filter by mode first
  let filtered = mode
    ? events.filter((e) => e.modeTags.includes(mode))
    : events;

  filtered = filtered.filter((event) => {
    const eventStart = parseEventDate(event.date);
    if (!eventStart) return true; // include events with unparseable dates
    const eventEnd = event.endDate ? (parseEventDate(event.endDate) || eventStart) : eventStart;

    if (period === 'today') {
      return eventStart <= today && eventEnd >= today;
    }

    if (period === 'week') {
      const dayOfWeek = today.getDay();
      const monday = new Date(today);
      monday.setDate(today.getDate() - (dayOfWeek === 0 ? 6 : dayOfWeek - 1));
      const sunday = new Date(monday);
      sunday.setDate(monday.getDate() + 6);
      return eventStart <= sunday && eventEnd >= monday;
    }

    if (period === 'month') {
      const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
      const monthEnd = new Date(today.getFullYear(), today.getMonth() + 1, 0);
      return eventStart <= monthEnd && eventEnd >= monthStart;
    }

    return true;
  });

  return filtered;
}

function formatDate(dateStr: string): string {
  const d = parseEventDate(dateStr);
  if (!d) return dateStr;
  return d.toLocaleDateString('en-HK', { weekday: 'short', month: 'short', day: 'numeric' });
}

function getDayName(dateStr: string): string {
  if (!dateStr) return '';
  const d = parseEventDate(dateStr);
  if (!d) return dateStr;
  const today = getHKToday();
  const tomorrow = new Date(today);
  tomorrow.setDate(today.getDate() + 1);
  if (d.toDateString() === today.toDateString()) return 'Today';
  if (d.toDateString() === tomorrow.toDateString()) return 'Tomorrow';
  return d.toLocaleDateString('en-HK', { weekday: 'long' });
}

// Shared views badge for all modes
function ViewsBadge({ eventId, style }: { eventId: string; style?: 'overlay' | 'inline' | 'degen' }) {
  const { getStats } = useEventStats();
  const views = getStats(eventId)?.views || 0;
  if (views <= 0) return null;
  const label = views > 999 ? `${(views / 1000).toFixed(1)}k` : String(views);

  if (style === 'overlay') {
    return (
      <span className="flex items-center gap-1 px-1.5 py-1 text-[10px] font-medium text-white" style={{ backgroundColor: 'rgba(0,0,0,0.35)', borderRadius: '6px', backdropFilter: 'blur(4px)' }}>
        <Eye size={10} /> {label}
      </span>
    );
  }
  if (style === 'degen') {
    return (
      <span className="flex items-center gap-1 px-2 py-0.5" style={{ fontSize: '0.6rem', color: 'rgba(0,0,0,0.35)', fontWeight: 600 }}>
        <Eye size={10} /> {label}
      </span>
    );
  }
  return (
    <span className="flex items-center gap-1 text-[11px]" style={{ color: 'rgba(0,0,0,0.3)' }}>
      <Eye size={10} /> {label}
    </span>
  );
}

// ══════════════════════════════════════════════════════════════════
// DEFAULT / NULL MODE
// ═══════════════════════════════════════════════════════════════════

function DefaultThingsToDo() {
  const { currentMode } = useMode();
  const { events } = useData();
  const { t } = useTranslation();
  const { timePeriod: globalTimePeriod, setTimePeriod: setGlobalTimePeriod } = useTimePeriod();
  const period: TimePeriod = globalTimePeriod === 'all' ? 'today' : globalTimePeriod;
  const setPeriod = (p: TimePeriod) => { setGlobalTimePeriod(p); setPage(0); };
  const modeColor = currentMode && currentMode !== 'lifestyle' ? modeConfig[currentMode].color : currentMode === 'lifestyle' ? '#2D6A4F' : '#8338EC';
  const tokens = getDesignTokens(currentMode);
  const [page, setPage] = useState(0);
  const tpl = useTemplateData('home');
  const ITEMS_PER_PAGE = 9;
  const { getStats } = useEventStats();

  const filtered = useMemo(() => {
    let result = getTimeFilteredEvents(events, period, currentMode);
    if (tpl['things-to-do'].showFeaturedOnly) {
      const featuredOnly = result.filter(e => e.featured);
      if (featuredOnly.length > 0) result = featuredOnly;
    }
    return result;
  }, [events, period, currentMode, tpl]);
  const totalPages = Math.max(1, Math.ceil(filtered.length / ITEMS_PER_PAGE));
  const currentPage = Math.min(page, totalPages - 1);
  const paged = filtered.slice(currentPage * ITEMS_PER_PAGE, (currentPage + 1) * ITEMS_PER_PAGE);

  const tabs: { key: TimePeriod; label: string; icon: typeof Sun }[] = [
    { key: 'today', label: 'Today', icon: Sun },
    { key: 'week', label: 'This Weekend', icon: Calendar },
    { key: 'month', label: 'This Month', icon: CalendarDays },
  ];

  return (
    <section className="px-4 sm:px-6 lg:px-8 py-6 sm:py-16 max-w-[1440px] mx-auto">
      <div className="mb-8 sm:mb-12 px-6 lg:px-6">
        <div className="h-px w-full mb-8" style={{ backgroundColor: '#E8E4DE' }} />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '1.5rem' }}>
          <div>
            <span style={{
              fontSize: '0.6rem',
              fontWeight: 600,
              letterSpacing: '0.18em',
              textTransform: 'uppercase' as const,
              color: '#B5B0A8',
            }}>Curated</span>
          </div>
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
            <h2 style={{ fontFamily: "'Archivo Black', sans-serif", fontSize: 'clamp(1.3rem, 2.5vw, 1.8rem)', color: '#1A1A1A', letterSpacing: '-0.03em', lineHeight: 1.1 }}>
              {tpl['things-to-do'].sectionTitle || t('modeHome.thingsToDo')}
            </h2>
            <div className="flex gap-1 p-1 rounded-full self-start sm:self-auto" style={{ backgroundColor: '#F5F3EF', border: '1px solid #E8E4DE' }}>
              {tabs.map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setPeriod(tab.key)}
                  className="flex items-center gap-1 sm:gap-1.5 px-3 sm:px-4 py-1.5 sm:py-2 text-[11px] sm:text-xs transition-all rounded-full cursor-pointer"
                  style={{
                    backgroundColor: period === tab.key ? '#1A1A1A' : 'transparent',
                    color: period === tab.key ? '#fff' : '#A09B93',
                    fontWeight: period === tab.key ? 600 : 400,
                  }}
                >
                  <tab.icon size={12} /> <span className="hidden sm:inline">{tab.label}</span><span className="sm:hidden">{tab.key === 'today' ? 'Today' : tab.key === 'week' ? 'Weekend' : 'Month'}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={period}
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -12 }}
          transition={{ duration: 0.25 }}
        >
          {filtered.length === 0 ? (
            <div className="text-center py-16">
              <span className="text-4xl mb-4 block"></span>
              <p style={{ color: tokens.textMuted, fontSize: '0.9rem' }}>
                No events {period === 'today' ? 'today' : period === 'week' ? 'this week' : 'this month'}.
              </p>
              <Link
                to="/events"
                className="inline-flex items-center gap-2 mt-4 text-sm"
                style={{ color: modeColor }}
              >
                Browse all events <ArrowRight size={14} />
              </Link>
            </div>
          ) : (
            <>
              <div className="flex sm:grid sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5 overflow-x-auto sm:overflow-x-visible sm:overflow-y-visible pb-2 sm:pb-0 -mx-4 px-4 sm:mx-0 sm:px-0 scrollbar-hide snap-x snap-mandatory sm:snap-none">
                {paged.map((event, i) => (
                  <motion.div
                    key={event.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: i * 0.08 }}
                    className="flex-shrink-0 w-[260px] sm:w-auto snap-start"
                  >
                    <Link to={getEventLink(event)} className="group block">
                      <div className="overflow-hidden flex flex-col h-full" style={{ borderRadius: '18px', backgroundColor: tokens.cardBg, border: `1px solid ${tokens.cardBorder}`, boxShadow: '0 1px 3px rgba(0,0,0,0.04)' }}>
                        <div className="relative aspect-[16/10] overflow-hidden">
                          <ImageWithFallback
                            src={event.image}
                            alt={event.title}
                            className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                          {/* Day label */}
                          {getDayName(event.date) && (
                          <div className="absolute top-3 left-3">
                            <span className="px-2.5 py-1 text-xs backdrop-blur-sm rounded-full" style={{ backgroundColor: `${modeColor}cc`, color: '#fff', fontWeight: 600 }}>
                              {getDayName(event.date)}
                            </span>
                          </div>
                          )}
                          {/* Price + Views */}
                          <div className="absolute top-3 right-3 flex items-center gap-1.5">
                            <ViewsBadge eventId={event.id} style="overlay" />
                            <span className="px-2 py-0.5 text-xs backdrop-blur-sm rounded-full" style={{ backgroundColor: 'rgba(0,0,0,0.5)', color: '#fff' }}>
                              {event.price}
                            </span>
                          </div>
                          {/* Mode tags */}
                          <div className="absolute bottom-3 left-3 flex gap-1">
                            {event.modeTags.map((tag) => (
                              <span key={tag} className="rounded-full px-2 py-0.5 text-xs backdrop-blur-sm" style={{ backgroundColor: `${modeConfig[tag]?.color || '#888'}30`, color: modeConfig[tag]?.color || '#888' }}>
                                {modeConfig[tag]?.label || tag}
                              </span>
                            ))}
                          </div>
                        </div>
                        <div className="p-3 sm:p-4 flex flex-col flex-1">
                          <h3 className="mb-1 group-hover:opacity-80 transition-opacity" style={{ fontSize: '0.875rem', color: tokens.textPrimary, fontFamily: tokens.headingFont, fontWeight: 600, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical' as const, overflow: 'hidden', lineHeight: 1.4 }}>
                            {event.title}
                          </h3>
                          <div className="flex items-center gap-3 text-[11px] sm:text-xs mt-auto" style={{ color: tokens.textMuted }}>
                            <span className="flex items-center gap-1 truncate"><MapPin size={11} /> {event.venueName}</span>
                            <span className="hidden sm:flex items-center gap-1"><Clock size={11} /> {event.time}</span>
                          </div>
                        </div>
                      </div>
                    </Link>
                  </motion.div>
                ))}
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex items-center justify-center gap-2 sm:gap-3 mt-8 sm:mt-12">
                  <button
                    onClick={() => setPage(Math.max(0, currentPage - 1))}
                    disabled={currentPage === 0}
                    className="flex items-center gap-1.5 px-4 py-2 text-xs transition-all cursor-pointer disabled:opacity-25 disabled:cursor-not-allowed"
                    style={{
                      color: currentPage === 0 ? '#C5C0B8' : '#A09B93',
                      fontWeight: 500,
                      background: 'none',
                      border: 'none',
                    }}
                  >
                    <ChevronLeft size={13} />
                    <span className="hidden sm:inline">Previous</span>
                  </button>

                  <div className="flex items-center gap-1">
                    {Array.from({ length: totalPages }, (_, i) => (
                      <button
                        key={i}
                        onClick={() => setPage(i)}
                        className="w-8 h-8 flex items-center justify-center text-xs transition-all cursor-pointer"
                        style={{
                          backgroundColor: i === currentPage ? '#1A1A1A' : 'transparent',
                          color: i === currentPage ? '#fff' : '#A09B93',
                          fontWeight: i === currentPage ? 600 : 400,
                          borderRadius: '50%',
                          border: 'none',
                        }}
                      >
                        {i + 1}
                      </button>
                    ))}
                  </div>

                  <button
                    onClick={() => setPage(Math.min(totalPages - 1, currentPage + 1))}
                    disabled={currentPage >= totalPages - 1}
                    className="flex items-center gap-1.5 px-4 py-2.5 text-xs transition-all cursor-pointer disabled:opacity-25 disabled:cursor-not-allowed"
                    style={{
                      color: currentPage >= totalPages - 1 ? '#C5C0B8' : '#1A1A1A',
                      fontWeight: 500,
                      background: 'none',
                      border: currentPage >= totalPages - 1 ? 'none' : '1px solid #E8E4DE',
                      borderRadius: '9999px',
                    }}
                  >
                    <span className="hidden sm:inline">Next</span>
                    <ChevronRight size={13} />
                  </button>
                </div>
              )}
            </>
          )}
        </motion.div>
      </AnimatePresence>
    </section>
  );
}

// ═══════════════════════════════════════════════════════════════════
// NIGHT MODE
// ═══════════════════════════════════════════════════════════════════

const DEGEN_YELLOW = '#EDFF00';
const DEGEN_MAGENTA = '#D600FF';
const DEGEN_BLACK = '#0A0A0A';

function DegenThingsToDo() {
  const { events } = useData();
  const { timePeriod: globalTimePeriod, setTimePeriod: setGlobalTimePeriod } = useTimePeriod();
  const period: TimePeriod = globalTimePeriod === 'all' ? 'today' : globalTimePeriod;
  const setPeriod = (p: TimePeriod) => setGlobalTimePeriod(p);
  const tokens = getDesignTokens('degen');

  const filtered = useMemo(() => getTimeFilteredEvents(events, period, 'degen'), [events, period]);

  const tabs: { key: TimePeriod; label: string }[] = [
    { key: 'today', label: 'TONIGHT' },
    { key: 'week', label: 'THIS WEEK' },
    { key: 'month', label: 'THIS MONTH' },
  ];

  return (
    <section className="px-4 sm:px-6 lg:px-12 py-6 sm:py-14 max-w-[1440px] mx-auto">
      <span
        className="block mb-2 sm:mb-4"
        style={{ fontFamily: tokens.bodyFont, fontSize: '0.65rem', color: 'rgba(0,0,0,0.25)', letterSpacing: '0.1em' }}
      >
        /006
      </span>
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 sm:gap-4 mb-4 sm:mb-8">
        <h2
          style={{
            fontFamily: tokens.headingFont,
            fontSize: 'clamp(1.2rem, 3vw, 2.5rem)',
            color: DEGEN_BLACK,
            fontWeight: 700,
            letterSpacing: '-0.03em',
            textTransform: 'uppercase',
          }}
        >
          THINGS TO <span style={{ color: DEGEN_MAGENTA }}>DO</span>
        </h2>
        <div className="flex gap-2">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setPeriod(tab.key)}
              className="px-5 py-2.5 text-xs transition-all cursor-pointer"
              style={{
                backgroundColor: period === tab.key ? DEGEN_BLACK : 'transparent',
                color: period === tab.key ? DEGEN_YELLOW : DEGEN_BLACK,
                border: `2px solid ${DEGEN_BLACK}`,
                borderRadius: '4px',
                fontFamily: tokens.headingFont,
                fontWeight: 700,
                letterSpacing: '0.03em',
                textTransform: 'uppercase',
              }}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={period}
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -12 }}
          transition={{ duration: 0.2 }}
        >
          {filtered.length === 0 ? (
            <div
              className="text-center py-14"
              style={{ border: `2px dashed rgba(0,0,0,0.15)`, borderRadius: '4px' }}
            >
              <span className="text-3xl mb-3 block"></span>
              <p style={{ color: tokens.textMuted, fontSize: '0.85rem', fontFamily: tokens.headingFont, fontWeight: 700, textTransform: 'uppercase' }}>
                Nothing {period === 'today' ? 'tonight' : period === 'week' ? 'this week' : 'this month'}
              </p>
              <Link
                to="/events"
                className="inline-flex items-center gap-2 mt-3 text-sm"
                style={{ color: DEGEN_MAGENTA, fontFamily: tokens.headingFont, fontWeight: 700, textTransform: 'uppercase' }}
              >
                SEE ALL <ArrowRight size={14} />
              </Link>
            </div>
          ) : (
            <div className="space-y-3">
              {filtered.map((event, i) => (
                <motion.div
                  key={event.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.05 }}
                >
                  <Link
                    to={getEventLink(event)}
                    className="group flex flex-row gap-3 sm:gap-4 items-center py-3 sm:py-5 transition-all hover:bg-black/[0.03]"
                    style={{ borderBottom: '2px solid rgba(0,0,0,0.08)' }}
                  >
                    {/* Date block */}
                    <div
                      className="flex-shrink-0 flex flex-col items-center justify-center w-12 h-12 sm:w-16 sm:h-16"
                      style={{
                        backgroundColor: DEGEN_MAGENTA,
                        borderRadius: '4px',
                      }}
                    >
                      <span style={{ fontFamily: tokens.headingFont, fontSize: 'clamp(1rem, 1.5vw, 1.3rem)', color: '#fff', fontWeight: 700, lineHeight: 1 }}>
                        {(parseEventDate(event.date) || new Date()).getDate()}
                      </span>
                      <span style={{ fontFamily: tokens.bodyFont, fontSize: '0.5rem', color: 'rgba(255,255,255,0.7)', textTransform: 'uppercase' }}>
                        {(parseEventDate(event.date) || new Date()).toLocaleDateString('en', { month: 'short' })}
                      </span>
                    </div>

                    {/* Image */}
                    <div className="hidden sm:block w-24 h-16 flex-shrink-0 overflow-hidden" style={{ borderRadius: '4px' }}>
                      <ImageWithFallback
                        src={event.image}
                        alt={event.title}
                        className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
                        style={{ filter: 'contrast(1.1)' }}
                      />
                    </div>

                    {/* Info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-1.5 sm:gap-2 mb-0.5 sm:mb-1">
                        <span
                          className="px-2 py-0.5"
                          style={{
                            backgroundColor: DEGEN_MAGENTA,
                            color: '#fff',
                            borderRadius: '2px',
                            fontSize: '0.6rem',
                            fontWeight: 700,
                            fontFamily: tokens.headingFont,
                            textTransform: 'uppercase',
                          }}
                        >
                          {event.category}
                        </span>
                        <span className="hidden sm:inline" style={{ fontSize: '0.65rem', color: tokens.textMuted, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                          {getDayName(event.date)} · {event.time}
                        </span>
                      </div>
                      <h3
                        className="group-hover:opacity-70 transition-opacity truncate"
                        style={{
                          fontFamily: tokens.headingFont,
                          fontSize: 'clamp(0.75rem, 1.5vw, 1.3rem)',
                          color: DEGEN_BLACK,
                          fontWeight: 700,
                          textTransform: 'uppercase',
                          letterSpacing: '-0.02em',
                        }}
                      >
                        {event.title}
                      </h3>
                      <span className="hidden sm:inline" style={{ fontSize: '0.75rem', color: tokens.textMuted }}>
                        {event.venueName} · {event.district}
                      </span>
                      <span className="sm:hidden" style={{ fontSize: '0.65rem', color: tokens.textMuted }}>
                        {event.venueName}
                      </span>
                    </div>

                    {/* Price */}
                    <div className="flex-shrink-0">
                      <span
                        className="px-2.5 py-1.5 sm:px-4 sm:py-2"
                        style={{
                          border: `2px solid ${DEGEN_BLACK}`,
                          borderRadius: '4px',
                          fontSize: '0.8rem',
                          color: DEGEN_BLACK,
                          fontWeight: 700,
                          fontFamily: tokens.headingFont,
                        }}
                      >
                        {event.price}
                      </span>
                    </div>
                    {/* Views badge */}
                    <div className="flex-shrink-0">
                      <ViewsBadge eventId={event.id} style="degen" />
                    </div>
                  </Link>
                </motion.div>
              ))}
            </div>
          )}
        </motion.div>
      </AnimatePresence>
    </section>
  );
}

// ═══════════════════════════════════════════════════════════════════
// ART & DESIGN MODE
// ═══════════════════════════════════════════════════════════════════

function ArtsyThingsToDo() {
  const { events } = useData();
  const { timePeriod: globalTimePeriod, setTimePeriod: setGlobalTimePeriod } = useTimePeriod();
  const period: TimePeriod = globalTimePeriod === 'all' ? 'today' : globalTimePeriod;
  const setPeriod = (p: TimePeriod) => setGlobalTimePeriod(p);
  const tokens = getDesignTokens('artsy');
  const [visibleCount, setVisibleCount] = useState(10);

  const filtered = useMemo(() => getTimeFilteredEvents(events, period, 'artsy'), [events, period]);
  const paginated = filtered.slice(0, visibleCount);

  // Reset visible count when period changes
  useEffect(() => { setVisibleCount(10); }, [period]);

  const tabs: { key: TimePeriod; label: string }[] = [
    { key: 'today', label: 'Now Showing' },
    { key: 'week', label: 'This Week' },
    { key: 'month', label: 'Season' },
  ];

  return (
    <section className="px-4 sm:px-8 lg:px-12 py-8 sm:py-20 lg:py-28 max-w-[1440px] mx-auto">
      <div className="h-px w-full mb-4 sm:mb-8" style={{ backgroundColor: 'rgba(0,0,0,0.06)' }} />
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 sm:gap-6 mb-6 sm:mb-16">
        <div>
          <span className="block mb-3 tracking-[0.3em] uppercase" style={{ fontSize: '0.6rem', color: tokens.textMuted, fontFamily: tokens.bodyFont }}>
            Calendar
          </span>
          <h2 style={{ fontFamily: tokens.headingFont, fontSize: 'clamp(1.5rem, 3vw, 2.5rem)', color: tokens.textPrimary, fontWeight: 400, lineHeight: 1.1 }}>
            Things to <em style={{ fontStyle: 'italic' }}>Experience</em>
          </h2>
        </div>
        <div className="flex gap-3 sm:gap-6">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setPeriod(tab.key)}
              className="pb-2 text-xs tracking-[0.15em] uppercase transition-all cursor-pointer bg-transparent"
              style={{
                color: period === tab.key ? tokens.textPrimary : tokens.textMuted,
                borderBottom: period === tab.key ? `1px solid ${tokens.textPrimary}` : '1px solid transparent',
                fontFamily: tokens.bodyFont,
                letterSpacing: '0.2em',
              }}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={period}
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -16 }}
          transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
        >
          {filtered.length === 0 ? (
            <div className="text-center py-20">
              <div className="w-12 h-px mx-auto mb-6" style={{ backgroundColor: tokens.textMuted }} />
              <p style={{ color: tokens.textMuted, fontSize: '0.85rem', fontFamily: tokens.bodyFont, fontStyle: 'italic' }}>
                No exhibitions or events {period === 'today' ? 'today' : period === 'week' ? 'this week' : 'this month'}
              </p>
              <Link
                to="/events"
                className="inline-flex items-center gap-3 mt-6 group"
                style={{ fontFamily: tokens.headingFont, fontSize: '0.75rem', color: tokens.textPrimary, letterSpacing: '0.15em' }}
              >
                <span className="uppercase">View Archive</span>
                <ArrowRight size={12} className="transition-transform group-hover:translate-x-1" />
              </Link>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-y-12 lg:gap-x-8">
              {paginated.map((event, i) => (
                <motion.div
                  key={event.id}
                  className={i === 0 ? 'lg:col-span-7' : 'lg:col-span-5'}
                  initial={{ opacity: 0, y: 24 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1, duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
                >
                  <Link to={getEventLink(event)} className="group block">
                    <div className={`relative overflow-hidden ${i === 0 ? 'aspect-[4/3]' : 'aspect-[3/4]'} mb-5`}>
                      <ImageWithFallback
                        src={event.image}
                        alt={event.title}
                        className="h-full w-full object-cover transition-transform duration-1000 group-hover:scale-[1.02]"
                        style={{ filter: 'grayscale(15%) contrast(1.05)' }}
                      />
                      {event.status === 'ongoing' && (
                        <div className="absolute top-4 left-4">
                          <span className="px-3 py-1 text-xs tracking-[0.15em] uppercase" style={{ backgroundColor: 'rgba(255,255,255,0.9)', color: tokens.textPrimary, fontSize: '0.55rem' }}>
                            Now Showing
                          </span>
                        </div>
                      )}
                    </div>
                    <div className="flex items-center gap-3 mb-2">
                      <span className="tracking-[0.25em] uppercase" style={{ fontSize: '0.55rem', color: tokens.textMuted, fontFamily: tokens.bodyFont }}>
                        {getDayName(event.date)}
                      </span>
                      <span className="w-3 h-px" style={{ backgroundColor: tokens.textMuted }} />
                      <span style={{ fontSize: '0.55rem', color: tokens.textMuted, fontFamily: tokens.bodyFont }}>
                        {event.time}
                      </span>
                    </div>
                    <h3
                      className="mb-2"
                      style={{
                        fontFamily: tokens.headingFont,
                        fontSize: i === 0 ? 'clamp(1.2rem, 2vw, 1.8rem)' : '1.1rem',
                        color: tokens.textPrimary,
                        fontWeight: 400,
                        lineHeight: 1.2,
                      }}
                    >
                      {event.title}
                    </h3>
                    {i === 0 && (
                      <p className="mb-3 max-w-lg" style={{ fontFamily: tokens.bodyFont, fontSize: '0.9rem', color: tokens.textSecondary, lineHeight: 1.7, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical' as const, overflow: 'hidden' }}>
                        {event.description}
                      </p>
                    )}
                    {/* Artsy: venue/price metadata row — remove broken absolute badge, keep inline */}
                    <div className="flex items-center gap-3">
                      <span style={{ fontSize: '0.7rem', color: tokens.textMuted }}>{event.venueName}</span>
                      <span className="w-3 h-px" style={{ backgroundColor: tokens.textMuted }} />
                      <span style={{ fontSize: '0.7rem', color: tokens.textMuted }}>{event.price}</span>
                      <ViewsBadge eventId={event.id} style="inline" />
                    </div>
                  </Link>
                </motion.div>
              ))}
            </div>
          )}

          {filtered.length > visibleCount && (
            <div className="flex justify-center mt-10 sm:mt-16">
              <button
                onClick={() => setVisibleCount(prev => prev + 10)}
                className="inline-flex items-center gap-3 group cursor-pointer bg-transparent"
                style={{ fontFamily: tokens.bodyFont, fontSize: '0.7rem', color: tokens.textMuted, letterSpacing: '0.2em', borderBottom: `1px solid ${tokens.textMuted}`, paddingBottom: '4px' }}
              >
                <span className="uppercase">Show More ({filtered.length - visibleCount} remaining)</span>
                <ArrowRight size={12} className="transition-transform group-hover:translate-x-1" />
              </button>
            </div>
          )}
        </motion.div>
      </AnimatePresence>
    </section>
  );
}

// ═════════════════════════════════════════════════════════════════

export function ThingsToDo() {
  const { currentMode } = useMode();

  if (currentMode === 'degen') return <DegenThingsToDo />;
  if (currentMode === 'artsy') return <ArtsyThingsToDo />;
  return <DefaultThingsToDo />;
}