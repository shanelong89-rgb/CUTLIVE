import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { X, RotateCcw, Calendar, Bookmark, Settings, ChevronRight } from 'lucide-react';
import { useMode } from '../context/ModeContext';
import { useOnboarding } from '../context/OnboardingContext';
import { modeConfig, type Mode } from '../data/mock-data';
import { getDesignTokens, isLightMode } from '../data/mode-styles';
import { CIcon } from './CIcon';

const PREFS_KEY = 'cultive-preferences';

interface SavedPreferences {
  mode: Mode | null;
  interests: string[];
  timestamp: number;
}

const INTEREST_LABELS: Record<string, { label: string }> = {
  nightlife: { label: 'Nightlife' },
  music: { label: 'Live Music' },
  underground: { label: 'Underground' },
  galleries: { label: 'Galleries' },
  exhibitions: { label: 'Exhibitions' },
  theater: { label: 'Theater' },
  film: { label: 'Film' },
  food: { label: 'Food & Dining' },
  drinks: { label: 'Cocktails & Bars' },
  markets: { label: 'Markets' },
  workshops: { label: 'Workshops' },
  outdoor: { label: 'Outdoor' },
  kids: { label: 'Kid-Friendly' },
  community: { label: 'Community' },
  wellness: { label: 'Wellness' },
  worship: { label: 'Worship & Ritual' },
  popup: { label: 'Pop-ups' },
  photography: { label: 'Photography' },
};

export function ProfilePanel({ onClose }: { onClose: () => void }) {
  const { currentMode } = useMode();
  const { resetWelcome } = useOnboarding();
  const tokens = getDesignTokens(currentMode);
  const light = isLightMode(currentMode);
  const modeColor = currentMode && currentMode !== 'lifestyle' ? modeConfig[currentMode].color : currentMode === 'lifestyle' ? '#2D6A4F' : '#8338EC';

  const isDegen = currentMode === 'degen';
  const isArtsy = currentMode === 'artsy';
  const isFamily = currentMode === 'family';
  const isFoodie = currentMode === 'foodie';

  const [prefs, setPrefs] = useState<SavedPreferences | null>(null);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(PREFS_KEY);
      if (raw) setPrefs(JSON.parse(raw));
    } catch {}
  }, []);

  const panelBg = isDegen
    ? 'rgba(10,10,10,0.96)'
    : isArtsy
      ? 'rgba(245,241,235,0.98)'
      : isFamily
        ? 'rgba(255,248,240,0.98)'
        : isFoodie
          ? 'rgba(10,18,40,0.98)'
          : 'rgba(255,255,255,0.98)';
  const panelBorder = isDegen
    ? 'rgba(237,255,0,0.15)'
    : isArtsy
      ? 'rgba(0,0,0,0.06)'
      : isFamily
        ? 'rgba(0,0,0,0.05)'
        : `rgba(255,255,255,0.08)`;
  const textMain = isDegen ? '#EDFF00' : tokens.textPrimary;
  const textSub = isDegen ? 'rgba(255,255,255,0.5)' : tokens.textSecondary;
  const textMuted = isDegen ? 'rgba(255,255,255,0.25)' : tokens.textMuted;
  const cardRadius = isDegen ? '4px' : isArtsy ? '2px' : isFamily ? '16px' : '12px';
  const surfaceBg = isDegen
    ? 'rgba(237,255,0,0.06)'
    : isArtsy
      ? 'rgba(0,0,0,0.03)'
      : isFamily
        ? 'rgba(255,140,66,0.06)'
        : light
          ? 'rgba(0,0,0,0.03)'
          : 'rgba(255,255,255,0.04)';

  const handleReset = () => {
    resetWelcome();
    onClose();
  };

  return (
    <>
      {/* Backdrop */}
      <motion.div
        className="fixed inset-0 z-[1200]"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        style={{ backgroundColor: 'rgba(0,0,0,0.3)' }}
      />

      {/* Panel */}
      <motion.div
        className="fixed top-16 right-4 z-[1201] w-80 max-h-[calc(100vh-80px)] overflow-y-auto backdrop-blur-xl"
        initial={{ opacity: 0, y: -10, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: -10, scale: 0.97 }}
        transition={{ type: 'spring', stiffness: 400, damping: 30 }}
        style={{
          background: panelBg,
          border: `1px solid ${panelBorder}`,
          borderRadius: isFamily ? '20px' : isDegen ? '4px' : isArtsy ? '2px' : '16px',
          boxShadow: '0 20px 60px rgba(0,0,0,0.3)',
        }}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 pb-3">
          <h3
            style={{
              color: textMain,
              fontFamily: tokens.headingFont,
              fontWeight: isDegen ? 700 : isArtsy ? 400 : 600,
              fontSize: isDegen ? '0.75rem' : '0.9rem',
              textTransform: isDegen ? 'uppercase' : undefined,
              letterSpacing: isDegen ? '0.05em' : isArtsy ? '0.15em' : undefined,
            }}
          >
            {isDegen ? 'YOUR PROFILE' : isArtsy ? 'PROFILE' : 'Your Profile'}
          </h3>
          <button
            onClick={onClose}
            className="p-1 transition-colors"
            style={{
              color: textMuted,
              borderRadius: isDegen ? '2px' : '9999px',
            }}
          >
            <X size={16} />
          </button>
        </div>

        <div className="px-4 pb-4 space-y-3">
          {/* Current Mode */}
          {currentMode && (
            <div
              className="p-3"
              style={{ backgroundColor: surfaceBg, borderRadius: cardRadius }}
            >
              <span
                className="text-[10px] block mb-2"
                style={{
                  color: textMuted,
                  fontFamily: tokens.headingFont,
                  textTransform: 'uppercase',
                  letterSpacing: '0.1em',
                }}
              >
                Current Mode
              </span>
              <div className="flex items-center gap-2">
                <CIcon id={currentMode} size={20} mode={currentMode} glow animated />
                <div>
                  <span
                    className="block text-sm"
                    style={{ color: modeColor, fontFamily: tokens.headingFont, fontWeight: 600 }}
                  >
                    {currentMode === 'lifestyle' ? 'Lifestyle' : modeConfig[currentMode].label}
                  </span>
                  <span className="block text-[10px]" style={{ color: textMuted }}>
                    {currentMode === 'lifestyle' ? '生活方式' : modeConfig[currentMode].labelZh}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Saved Interests */}
          {prefs && prefs.interests.length > 0 && (
            <div
              className="p-3"
              style={{ backgroundColor: surfaceBg, borderRadius: cardRadius }}
            >
              <span
                className="text-[10px] block mb-2"
                style={{
                  color: textMuted,
                  fontFamily: tokens.headingFont,
                  textTransform: 'uppercase',
                  letterSpacing: '0.1em',
                }}
              >
                Your Interests
              </span>
              <div className="flex flex-wrap gap-1.5">
                {prefs.interests.map((id) => {
                  const info = INTEREST_LABELS[id];
                  if (!info) return null;
                  return (
                    <span
                      key={id}
                      className="px-2 py-1 text-[10px]"
                      style={{
                        backgroundColor: `${modeColor}15`,
                        color: `${modeColor}cc`,
                        borderRadius: isDegen ? '2px' : '9999px',
                        fontFamily: tokens.bodyFont,
                      }}
                    >
                      <CIcon id={id} size={10} mode="auto" glow={false} /> {info.label}
                    </span>
                  );
                })}
              </div>
            </div>
          )}

          {/* Coming Soon Features */}
          <div className="space-y-1">
            {[
              { icon: Calendar, label: 'My Calendar', desc: 'Saved events & reminders' },
              { icon: Bookmark, label: 'Saved Events', desc: 'Your bookmarked events' },
              { icon: Settings, label: 'Preferences', desc: 'Notification & sync settings' },
            ].map((item) => (
              <div
                key={item.label}
                className="flex items-center gap-3 p-2.5 opacity-50 cursor-not-allowed"
                style={{ borderRadius: cardRadius }}
              >
                <item.icon size={15} style={{ color: textSub }} />
                <div className="flex-1">
                  <span
                    className="block text-xs"
                    style={{ color: textSub, fontFamily: tokens.headingFont }}
                  >
                    {item.label}
                  </span>
                  <span className="block text-[10px]" style={{ color: textMuted }}>
                    {item.desc}
                  </span>
                </div>
                <span
                  className="px-1.5 py-0.5 text-[9px]"
                  style={{
                    backgroundColor: surfaceBg,
                    color: textMuted,
                    borderRadius: isDegen ? '2px' : '9999px',
                    fontFamily: tokens.headingFont,
                    textTransform: 'uppercase',
                    letterSpacing: '0.05em',
                  }}
                >
                  Soon
                </span>
              </div>
            ))}
          </div>

          {/* Divider */}
          <div style={{ height: 1, backgroundColor: panelBorder }} />

          {/* Reset Preferences */}
          <button
            onClick={handleReset}
            className="flex items-center gap-2 w-full p-2.5 text-xs transition-all hover:opacity-70 cursor-pointer"
            style={{
              color: textSub,
              borderRadius: cardRadius,
              fontFamily: tokens.headingFont,
              textTransform: isDegen ? 'uppercase' : undefined,
              letterSpacing: isDegen ? '0.03em' : undefined,
            }}
          >
            <RotateCcw size={13} />
            <span>{isDegen ? 'RESET PREFERENCES' : 'Reset Preferences'}</span>
          </button>
        </div>
      </motion.div>
    </>
  );
}