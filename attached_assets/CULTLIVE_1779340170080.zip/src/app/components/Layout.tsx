import { Map, Home, CalendarDays, Info, Menu, X, Search, UtensilsCrossed, User, Leaf, Bookmark, LogOut, LogIn, Plus, Eye, EyeOff, Loader2, AlertCircle, ArrowLeft, CheckCircle2, MapPin, Heart, Sparkles, ChevronRight, Settings, FolderOpen, Bell, Camera } from 'lucide-react';
import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useTranslation } from 'react-i18next';
import { useLocation, Link, Outlet, useNavigate } from 'react-router';
import { ModeSelector } from './ModeSelector';
import { ModeStackTrigger, ModeCardStack } from './ModeCardStack';
import { MobileModeCards } from './MobileModeCards';
import { useMode } from '../context/ModeContext';
import { useAuth } from '../context/AuthContext';
import { useCollections } from '../context/CollectionsContext';
import { modeConfig } from '../data/mock-data';
import { getDesignTokens, isLightMode } from '../data/mode-styles';
import { DisplaceNavLink, DisplaceNavStyles } from './DisplaceNavLink';
import { useNavTheme } from '../hooks/useNavTheme';
import { SearchOverlay } from './SearchOverlay';
import { ProfileAuthForms } from './ProfileAuthForms';
import { CIcon } from './CIcon';
import { NotificationBell } from './NotificationBell';
import { useNotifications } from '../context/NotificationsContext';
import { useData } from '../context/DataContext';
import { LanguageToggle } from './LanguageToggle';
import { useNeutralTheme } from '../context/NeutralThemeContext';

export function Layout() {
  const location = useLocation();
  const navigate = useNavigate();
  const { t, i18n } = useTranslation();
  const isZh = i18n.language?.startsWith('zh');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [profileTab, setProfileTab] = useState<'profile' | 'notifications' | 'activity' | 'settings'>('profile');
  const [authView, setAuthView] = useState<'guest' | 'signin' | 'signup'>('guest');
  const [modeStackOpen, setModeStackOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const { currentMode, setMode } = useMode();
  const { user, signOut, savedEventIds } = useAuth();
  const { collections } = useCollections();
  const { unreadCount: notifUnreadCount, settings: notifSettings, updateSettings: updateNotifSettings } = useNotifications();
  const tokens = getDesignTokens(currentMode);
  const light = isLightMode(currentMode);
  const modeColor = currentMode && currentMode !== 'lifestyle' ? modeConfig[currentMode].color : currentMode === 'lifestyle' ? '#2D6A4F' : undefined;
  const isArtsy = currentMode === 'artsy';
  const isFoodie = currentMode === 'foodie';
  const isDegen = currentMode === 'degen';
  const isFamily = currentMode === 'family';
  const isLifestyle = currentMode === 'lifestyle';

  const { theme: neutralTheme, palette: neutralPalette } = useNeutralTheme();
  // Only apply dark theme on editorial pages (homepage + What's On)
  const isEditorialPage = location.pathname === '/' || location.pathname === '/whats-on';
  const neutralIsDark = !currentMode && isEditorialPage && neutralTheme === 'dark';

  const heroIsDark = isFoodie || neutralIsDark;
  const contentIsDark = isFoodie || neutralIsDark;
  const heroNavTheme: 'light' | 'dark' = heroIsDark ? 'light' : 'dark';
  const contentNavTheme: 'light' | 'dark' = contentIsDark ? 'light' : 'dark';

  const navTheme = useNavTheme(heroNavTheme, contentNavTheme);

  const navIsLight = navTheme === 'light';
  const navTextColor = navIsLight ? 'rgba(255,255,255,0.65)' : 'rgba(0,0,0,0.45)';
  const navTextActiveColor = navIsLight ? '#FFFFFF' : '#1A1A1A';
  const navTextSecondaryColor = navIsLight ? 'rgba(255,255,255,0.55)' : 'rgba(0,0,0,0.5)';
  const navBtnBg = navIsLight ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.06)';

  const navItems = [
    { path: '/', label: t('nav.discover'), icon: Home },
    { path: '/map', label: t('nav.map'), icon: Map },
    { path: '/events', label: t('nav.events'), icon: CalendarDays },
    { path: '/recaps', label: t('nav.recaps'), icon: Camera },
    { path: '/about', label: t('nav.about'), icon: Info },
  ];

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setSearchOpen(prev => !prev);
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  // Scroll to top on route change
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location.pathname]);

  // Sync body background with neutral theme to prevent white flash
  useEffect(() => {
    if (neutralIsDark) {
      document.body.style.backgroundColor = neutralPalette.bg;
    } else if (!currentMode) {
      document.body.style.backgroundColor = '';
    }
  }, [neutralIsDark, neutralPalette.bg, currentMode]);

  return (
    <div
      className="min-h-screen transition-colors duration-300 overflow-x-hidden"
      style={{
        backgroundColor: neutralIsDark ? neutralPalette.bg : tokens.pageBg,
        color: neutralIsDark ? neutralPalette.text : tokens.textPrimary,
        fontFamily: tokens.bodyFont,
      }}
    >
      {!currentMode && <DisplaceNavStyles />}

      {/* Top Navigation */}
      <header
        className="fixed top-0 left-0 right-0 z-[1100] transition-all duration-500"
      >
        <div
          className="mx-auto max-w-[1440px] px-4 sm:px-6 lg:px-8"
          style={{
            margin: '8px auto',
            borderRadius: '16px',
            background: navIsLight
              ? 'rgba(255,255,255,0.06)'
              : !currentMode
                ? neutralIsDark
                  ? 'rgba(10, 10, 10, 0.85)'
                  : 'rgba(250, 250, 248, 0.85)'
                : 'rgba(255,255,255,0.72)',
            backdropFilter: 'blur(16px) saturate(1.4)',
            WebkitBackdropFilter: 'blur(16px) saturate(1.4)',
            border: navIsLight
              ? '1px solid rgba(255,255,255,0.08)'
              : neutralIsDark
                ? '1px solid rgba(255,255,255,0.06)'
                : '1px solid rgba(0,0,0,0.06)',
            boxShadow: navIsLight
              ? '0 1px 8px rgba(0,0,0,0.04)'
              : neutralIsDark
                ? '0 2px 16px rgba(0,0,0,0.3), 0 1px 3px rgba(0,0,0,0.2)'
                : '0 2px 16px rgba(0,0,0,0.06), 0 1px 3px rgba(0,0,0,0.04)',
            transition: 'background 0.5s ease, border 0.5s ease, box-shadow 0.5s ease',
          }}
        >
          <div className={`flex items-center justify-between ${isArtsy ? 'h-16' : 'h-14'} transition-all duration-500`}>
            {/* Logo */}
            <Link to="/" className="flex items-center gap-2 transition-colors duration-300" onClick={(e) => { e.preventDefault(); setMode(null); navigate('/'); }}>
              {isLifestyle ? (
                <div className="flex items-center gap-2">
                  <span
                    style={{
                      fontFamily: "'Playfair Display', serif",
                      fontSize: '1.15rem',
                      fontWeight: 900,
                      color: navTextActiveColor,
                      letterSpacing: '-0.02em',
                      lineHeight: 1,
                      transition: 'color 0.3s ease',
                    }}
                  >
                    CULTIVE
                  </span>
                  <span
                    className="px-2 py-0.5"
                    style={{
                      backgroundColor: '#2D6A4F',
                      color: '#fff',
                      fontFamily: "'Playfair Display', serif",
                      fontSize: '0.55rem',
                      fontWeight: 700,
                      borderRadius: '9999px',
                      letterSpacing: '0.05em',
                      fontStyle: 'italic',
                    }}
                  >
                    lifestyle.
                  </span>
                </div>
              ) : isArtsy ? (
                <div className="flex flex-col">
                  <span
                    className="tracking-[0.5em] uppercase"
                    style={{
                      fontFamily: tokens.headingFont,
                      color: navTextActiveColor,
                      fontSize: '0.85rem',
                      letterSpacing: '0.4em',
                      transition: 'color 0.3s ease',
                    }}
                  >
                    CULTIVE
                  </span>
                  <span
                    className="tracking-[0.15em]"
                    style={{ color: navTextColor, fontSize: '0.6rem', transition: 'color 0.3s ease' }}
                  >
                    文化活
                  </span>
                </div>
              ) : isFoodie ? (
                <div className="flex items-center gap-2.5">
                  <div
                    className="flex h-9 w-9 items-center justify-center"
                    style={{ backgroundColor: '#2563EB', borderRadius: '12px' }}
                  >
                    <UtensilsCrossed size={16} color="#fff" />
                  </div>
                  <div className="flex flex-col">
                    <span
                      style={{
                        fontFamily: tokens.headingFont,
                        color: navTextActiveColor,
                        fontSize: '0.9rem',
                        fontWeight: 700,
                        letterSpacing: '-0.02em',
                        transition: 'color 0.3s ease',
                      }}
                    >
                      CULTIVE
                    </span>
                    <span style={{ color: navTextColor, fontSize: '0.55rem', letterSpacing: '0.1em', transition: 'color 0.3s ease' }}>
                      美食 · FOOD
                    </span>
                  </div>
                </div>
              ) : isDegen ? (
                <div className="flex items-center gap-2">
                  <span
                    style={{
                      fontFamily: tokens.headingFont,
                      color: navTextActiveColor,
                      fontSize: '1.1rem',
                      fontWeight: 700,
                      letterSpacing: '-0.02em',
                      textTransform: 'uppercase' as const,
                      transition: 'color 0.3s ease',
                    }}
                  >
                    CULTIVE
                  </span>
                  <span
                    className="px-2 py-0.5"
                    style={{
                      backgroundColor: '#D600FF',
                      color: '#fff',
                      fontFamily: tokens.headingFont,
                      fontSize: '0.55rem',
                      fontWeight: 700,
                      borderRadius: '2px',
                      letterSpacing: '0.08em',
                    }}
                  >
                    NIGHT
                  </span>
                </div>
              ) : isFamily ? (
                <div className="flex items-center gap-2.5">
                  <div
                    className="flex h-10 w-10 items-center justify-center"
                    style={{
                      background: 'linear-gradient(135deg, #FF8C42, #FFB347)',
                      borderRadius: '16px',
                      boxShadow: '0 4px 12px rgba(255,140,66,0.25)',
                    }}
                  >
                    <span
                      style={{
                        fontFamily: tokens.headingFont,
                        fontSize: '0.75rem',
                        color: '#fff',
                        fontWeight: 800,
                      }}
                    >
                      C
                    </span>
                  </div>
                  <div className="flex flex-col">
                    <span
                      style={{
                        fontFamily: tokens.headingFont,
                        color: navTextActiveColor,
                        fontSize: '0.95rem',
                        fontWeight: 800,
                        letterSpacing: '-0.01em',
                        transition: 'color 0.3s ease',
                      }}
                    >
                      CULTIVE
                    </span>
                    <span style={{ color: '#FF8C42', fontSize: '0.5rem', letterSpacing: '0.1em', fontWeight: 600 }}>
                      FAMILY
                    </span>
                  </div>
                </div>
              ) : (
                <div className="flex items-center gap-2.5">
                  <span
                    style={{
                      fontFamily: "'Archivo Black', sans-serif",
                      fontSize: '1.15rem',
                      color: navTextActiveColor,
                      letterSpacing: '-0.03em',
                      lineHeight: 1,
                      transition: 'color 0.3s ease',
                    }}
                  >
                    CULTIVE
                  </span>
                  <span
                    style={{
                      fontFamily: "'Noto Sans HK', sans-serif",
                      fontSize: '0.6rem',
                      color: navTextColor,
                      letterSpacing: '0.1em',
                      transition: 'color 0.3s ease',
                    }}
                  >
                    文化活
                  </span>
                </div>
              )}
            </Link>

            {/* Desktop Nav */}
            <nav className="hidden md:flex items-center gap-1">
              {navItems.map((item) => {
                const isActive = location.pathname === item.path;

                if (!currentMode) {
                  return (
                    <DisplaceNavLink
                      key={item.path}
                      to={item.path}
                      label={item.label}
                      isActive={isActive}
                      textColor={navTextColor}
                      activeColor={navTextActiveColor}
                    />
                  );
                }

                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    className="relative flex items-center gap-1.5 px-4 py-2 transition-all duration-300 text-sm"
                    style={{
                      color: isActive ? navTextActiveColor : navTextColor,
                      fontFamily: (isArtsy || isFoodie || isDegen) ? tokens.headingFont : "'Inter', sans-serif",
                      fontWeight: isDegen ? 700 : isFoodie ? (isActive ? 600 : 400) : (isActive ? 500 : 400),
                      letterSpacing: isArtsy ? '0.1em' : isDegen ? '0.03em' : undefined,
                      textTransform: isDegen ? 'uppercase' : undefined,
                      borderRadius: tokens.borderRadius,
                    }}
                  >
                    {!isArtsy && currentMode && <item.icon size={15} />}
                    <span>{isArtsy ? item.label.toUpperCase() : item.label}</span>
                    {isActive && !isArtsy && !isFoodie && !isDegen && currentMode && (
                      <motion.div
                        layoutId="nav-active"
                        className="absolute inset-0"
                        style={{
                          backgroundColor: navIsLight ? 'rgba(255,255,255,0.1)' : (modeColor ? `${modeColor}20` : 'rgba(0,0,0,0.04)'),
                          border: `1px solid ${navIsLight ? 'rgba(255,255,255,0.15)' : (modeColor ? `${modeColor}30` : 'rgba(0,0,0,0.06)')}`,
                          borderRadius: tokens.borderRadius,
                        }}
                        transition={{ type: 'spring', stiffness: 400, damping: 30 }}
                      />
                    )}
                    {isActive && isArtsy && (
                      <motion.div
                        layoutId="nav-active"
                        className="absolute bottom-0 left-4 right-4 h-px"
                        style={{ backgroundColor: navTextActiveColor }}
                        transition={{ type: 'spring', stiffness: 400, damping: 30 }}
                      />
                    )}
                    {isActive && isDegen && (
                      <motion.div
                        layoutId="nav-active"
                        className="absolute inset-0"
                        style={{
                          backgroundColor: navIsLight ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.06)',
                          border: `2px solid ${navIsLight ? 'rgba(255,255,255,0.15)' : 'rgba(0,0,0,0.1)'}`,
                          borderRadius: '4px',
                        }}
                        transition={{ type: 'spring', stiffness: 400, damping: 30 }}
                      />
                    )}
                    {isActive && isFoodie && (
                      <motion.div
                        layoutId="nav-active"
                        className="absolute inset-0"
                        style={{
                          backgroundColor: 'rgba(37,99,235,0.15)',
                          borderRadius: '24px',
                        }}
                        transition={{ type: 'spring', stiffness: 400, damping: 30 }}
                      />
                    )}
                  </Link>
                );
              })}
            </nav>

            {/* Right side */}
            <div className="hidden md:flex items-center gap-2">
              <LanguageToggle
                navBtnBg={navBtnBg}
                textColor={navTextSecondaryColor}
                activeColor={navTextActiveColor}
                borderRadius={isDegen ? '4px' : isFoodie ? '24px' : '9999px'}
              />
              <ModeStackTrigger onClick={() => setModeStackOpen(true)} btnBg={navBtnBg} textColor={navTextSecondaryColor} />
              {!isArtsy && (
                <button
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs transition-all duration-300 cursor-pointer"
                  style={{
                    backgroundColor: navBtnBg,
                    color: navTextSecondaryColor,
                    borderRadius: isDegen ? '4px' : isFoodie ? '24px' : '9999px',
                    fontFamily: isDegen ? tokens.headingFont : undefined,
                    fontWeight: isDegen ? 700 : 400,
                    textTransform: isDegen ? 'uppercase' : undefined,
                    letterSpacing: isDegen ? '0.03em' : undefined,
                  }}
                  onClick={() => setSearchOpen(true)}
                >
                  <Search size={13} />
                  <span>{t('nav.search')}</span>
                </button>
              )}
              {isArtsy && (
                <button
                  className="flex items-center gap-1.5 py-1.5 text-xs transition-all duration-300 cursor-pointer"
                  style={{
                    color: navTextColor,
                    borderBottom: `1px solid ${navTextColor}`,
                  }}
                  onClick={() => setSearchOpen(true)}
                >
                  <Search size={13} />
                </button>
              )}
              <NotificationBell
                navBtnBg={navBtnBg}
                navTextSecondaryColor={navTextSecondaryColor}
                tokens={tokens}
                isDegen={isDegen}
                isFoodie={isFoodie}
              />
              <button
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs transition-all duration-300 cursor-pointer"
                style={{
                  backgroundColor: navBtnBg,
                  color: navTextSecondaryColor,
                  borderRadius: isDegen ? '4px' : isFoodie ? '24px' : '9999px',
                  fontFamily: isDegen ? tokens.headingFont : undefined,
                  fontWeight: isDegen ? 700 : 400,
                  textTransform: isDegen ? 'uppercase' : undefined,
                  letterSpacing: isDegen ? '0.03em' : undefined,
                }}
                onClick={() => setProfileOpen(!profileOpen)}
              >
                <User size={13} />
                <span>{t('nav.profile')}</span>
              </button>
            </div>

            {/* Mobile menu button */}
            <div className="flex items-center gap-1 md:hidden">
              <button
                className="p-2 transition-colors duration-300 cursor-pointer"
                style={{ color: navTextSecondaryColor }}
                onClick={() => { setMobileMenuOpen(false); setSearchOpen(true); }}
              >
                <Search size={18} />
              </button>
              <NotificationBell
                navBtnBg={navBtnBg}
                navTextSecondaryColor={navTextSecondaryColor}
                tokens={tokens}
                isDegen={isDegen}
                isFoodie={isFoodie}
              />
              <button
                className="p-2 transition-colors duration-300 cursor-pointer"
                style={{ color: navTextSecondaryColor }}
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mode Card Stack Overlay */}
      <ModeCardStack isOpen={modeStackOpen} onClose={() => setModeStackOpen(false)} />

      {/* Profile panel */}
      <AnimatePresence>
        {profileOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[9998]"
              style={{ backgroundColor: 'rgba(0,0,0,0.3)', backdropFilter: 'blur(2px)' }}
              onClick={() => setProfileOpen(false)}
            />
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 28, stiffness: 300 }}
              className="fixed top-0 right-0 bottom-0 w-[300px] sm:w-[340px] z-[9999] flex flex-col"
              style={{
                backgroundColor: !currentMode ? neutralPalette.bg : tokens.pageBg,
                borderLeft: `1px solid ${!currentMode ? neutralPalette.border : tokens.cardBorder}`,
                boxShadow: '-4px 0 24px rgba(0,0,0,0.1)',
              }}
            >
              <div className="flex items-center justify-between px-5 py-4" style={{ borderBottom: `1px solid ${!currentMode ? neutralPalette.border : tokens.cardBorder}` }}>
                <span style={{
                  color: !currentMode ? neutralPalette.text : tokens.textPrimary,
                  fontFamily: !currentMode ? "'Archivo Black', sans-serif" : undefined,
                  fontSize: !currentMode ? '0.55rem' : '0.875rem',
                  fontWeight: !currentMode ? 600 : 600,
                  letterSpacing: !currentMode ? '0.18em' : undefined,
                  textTransform: !currentMode ? 'uppercase' : undefined,
                } as React.CSSProperties}>{!currentMode ? 'PROFILE' : t('profile.title')}</span>
                <button onClick={() => setProfileOpen(false)} className="p-1.5 cursor-pointer hover:opacity-70" style={{ color: !currentMode ? neutralPalette.textMuted : tokens.textMuted, borderRadius: !currentMode ? '2px' : '9999px' }}>
                  <X size={16} />
                </button>
              </div>
              {user ? (
                <div className="flex-1 flex flex-col overflow-y-auto">
                  {!currentMode ? (
                    /* ═══ NEUTRAL EDITORIAL PROFILE ═══ */
                    <>
                      <div style={{ padding: '2.5rem 1.5rem 1.75rem', backgroundColor: neutralPalette.bg }}>
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '0', alignItems: 'start' }}>
                          <div className="flex flex-col items-center">
                            <div className="relative">
                              <div className="w-[72px] h-[72px] rounded-full p-[2px]" style={{ background: `linear-gradient(135deg, ${neutralPalette.text}, ${neutralPalette.textMuted})` }}>
                                <div className="w-full h-full rounded-full flex items-center justify-center" style={{ backgroundColor: neutralPalette.bg, color: neutralPalette.text, fontFamily: "'Archivo Black', sans-serif", fontSize: '1.4rem' }}>
                                  {user.name?.charAt(0).toUpperCase() || 'U'}
                                </div>
                              </div>
                              <div className="absolute -bottom-0.5 -right-0.5 w-6 h-6 rounded-full flex items-center justify-center cursor-pointer" style={{ backgroundColor: neutralPalette.text, border: `2.5px solid ${neutralPalette.bg}` }}>
                                <Camera size={10} color={neutralPalette.bg} />
                              </div>
                            </div>
                          </div>
                          <div className="flex flex-col justify-center" style={{ paddingLeft: '0.5rem' }}>
                            <p style={{ fontFamily: "'Archivo Black', sans-serif", fontSize: '1.1rem', lineHeight: 1.1, letterSpacing: '-0.03em', color: neutralPalette.text, marginBottom: '0.35rem' }}>{user.name}</p>
                            <p style={{ fontSize: '0.7rem', color: neutralPalette.textMuted, letterSpacing: '0.02em' }}>{user.email}</p>
                            <button onClick={async () => { await signOut(); setProfileOpen(false); }} className="cursor-pointer transition-opacity hover:opacity-60 mt-2 self-start" style={{ fontSize: '0.55rem', fontWeight: 600, letterSpacing: '0.18em', textTransform: 'uppercase', color: neutralPalette.textSecondary, background: 'none', border: 'none', borderBottom: `1px solid ${neutralPalette.border}`, padding: '0 0 2px 0' }}>
                              Sign Out
                            </button>
                          </div>
                        </div>
                      </div>
                      <div style={{ borderTop: `1px solid ${neutralPalette.border}`, borderBottom: `1px solid ${neutralPalette.border}`, backgroundColor: neutralPalette.bg }}>
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr' }}>
                          {[
                            { count: savedEventIds.length, label: 'Saved' },
                            { count: collections.length, label: 'Collections' },
                            { count: 0, label: 'Attended' },
                          ].map((stat, i) => (
                            <div key={stat.label} className="flex flex-col items-center py-3.5" style={{ borderLeft: i > 0 ? `1px solid ${neutralPalette.border}` : undefined }}>
                              <span style={{ fontFamily: "'Archivo Black', sans-serif", fontSize: '1.15rem', color: neutralPalette.text, lineHeight: 1 }}>{stat.count}</span>
                              <span style={{ fontSize: '0.5rem', fontWeight: 600, letterSpacing: '0.18em', textTransform: 'uppercase', color: neutralPalette.textMuted, marginTop: '0.3rem' }}>{stat.label}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr', borderBottom: `1px solid ${neutralPalette.border}`, backgroundColor: neutralPalette.bg }}>
                        {([
                          { id: 'profile' as const, label: 'Profile' },
                          { id: 'activity' as const, label: 'Activity' },
                          { id: 'notifications' as const, label: 'Alerts' },
                          { id: 'settings' as const, label: 'Settings' },
                        ]).map((tab) => (
                          <button key={tab.id} onClick={() => setProfileTab(tab.id)} className="cursor-pointer transition-opacity hover:opacity-70" style={{ padding: '0.75rem 0', fontSize: '0.55rem', fontWeight: 600, letterSpacing: '0.15em', textTransform: 'uppercase', color: profileTab === tab.id ? neutralPalette.text : neutralPalette.textMuted, background: 'none', border: 'none', borderBottom: profileTab === tab.id ? `2px solid ${neutralPalette.text}` : '2px solid transparent' }}>
                            {tab.label}
                            {tab.id === 'notifications' && notifUnreadCount > 0 && (
                              <span className="inline-flex items-center justify-center ml-1 text-[8px] font-bold rounded-full" style={{ backgroundColor: neutralPalette.text, color: neutralPalette.bg, width: 14, height: 14 }}>{notifUnreadCount > 9 ? '9+' : notifUnreadCount}</span>
                            )}
                          </button>
                        ))}
                      </div>
                      <div className="flex-1 overflow-y-auto" style={{ backgroundColor: neutralPalette.bg, padding: '1.5rem' }}>
                        {profileTab === 'profile' && (
                          <div>
                            {(() => {
                              try {
                                const raw = localStorage.getItem('cultive-preferences');
                                const prefs = raw ? JSON.parse(raw) : null;
                                if (prefs?.interests?.length > 0) {
                                  return (
                                    <div style={{ marginBottom: '1.5rem' }}>
                                      <span style={{ fontSize: '0.55rem', fontWeight: 600, letterSpacing: '0.18em', textTransform: 'uppercase', color: neutralPalette.textMuted, display: 'block', marginBottom: '0.75rem' }}>{t('profile.yourInterests')}</span>
                                      <div className="flex flex-wrap gap-1.5">
                                        {prefs.interests.slice(0, 8).map((id: string) => (
                                          <span key={id} className="inline-flex items-center gap-1 px-2.5 py-1" style={{ fontSize: '0.65rem', color: neutralPalette.textSecondary, border: `1px solid ${neutralPalette.border}`, borderRadius: '2px' }}>
                                            <CIcon id={id} size={10} mode="auto" glow={false} />
                                            {t(`interests.${id}`, id)}
                                          </span>
                                        ))}
                                      </div>
                                    </div>
                                  );
                                }
                              } catch {}
                              return null;
                            })()}
                            <div style={{ height: 1, backgroundColor: neutralPalette.border, marginBottom: '1.25rem' }} />
                            <span style={{ fontSize: '0.55rem', fontWeight: 600, letterSpacing: '0.18em', textTransform: 'uppercase', color: neutralPalette.textMuted, display: 'block', marginBottom: '0.75rem' }}>Quick Actions</span>
                            <div>
                              {[
                                { to: '/saved', icon: Bookmark, label: t('profile.savedEvents') },
                                { to: '/collections', icon: FolderOpen, label: t('profile.collections') },
                                { to: '/map', icon: MapPin, label: t('profile.exploreMap') },
                                { to: '/contribute', icon: Plus, label: t('profile.submitEvent') },
                              ].map((item) => (
                                <Link key={item.to} to={item.to} onClick={() => setProfileOpen(false)} className="group transition-opacity hover:opacity-70" style={{ textDecoration: 'none', padding: '0.65rem 0', borderBottom: `1px solid ${neutralPalette.borderSubtle}`, display: 'grid', gridTemplateColumns: '1fr 2fr', gap: 0 }}>
                                  <item.icon size={14} style={{ color: neutralPalette.textMuted }} />
                                  <span style={{ fontSize: '0.75rem', color: neutralPalette.text, fontWeight: 500 }}>{item.label}</span>
                                </Link>
                              ))}
                            </div>
                          </div>
                        )}
                        {profileTab === 'activity' && (
                          <div>
                            <span style={{ fontSize: '0.55rem', fontWeight: 600, letterSpacing: '0.18em', textTransform: 'uppercase', color: neutralPalette.textMuted, display: 'block', marginBottom: '1rem' }}>Your Activity</span>
                            {[
                              { count: savedEventIds.length, label: 'Saved Events', sub: 'Events bookmarked' },
                              { count: collections.length, label: 'Collections', sub: 'Curated lists' },
                              { count: 0, label: 'Attended', sub: 'Events visited' },
                            ].map((item) => (
                              <div key={item.label} style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: 0, padding: '1rem 0', borderBottom: `1px solid ${neutralPalette.borderSubtle}` }}>
                                <span style={{ fontFamily: "'Archivo Black', sans-serif", fontSize: '1.6rem', color: neutralPalette.numberColor, lineHeight: 1 }}>{String(item.count).padStart(2, '0')}</span>
                                <div>
                                  <span style={{ fontSize: '0.8rem', fontWeight: 600, color: neutralPalette.text, display: 'block' }}>{item.label}</span>
                                  <span style={{ fontSize: '0.65rem', color: neutralPalette.textMuted }}>{item.sub}</span>
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                        {profileTab === 'notifications' && (
                          <div>
                            <span style={{ fontSize: '0.55rem', fontWeight: 600, letterSpacing: '0.18em', textTransform: 'uppercase', color: neutralPalette.textMuted, display: 'block', marginBottom: '1rem' }}>Alerts</span>
                            {([
                              { key: 'upcomingEvents' as const, label: 'Upcoming Events' },
                              { key: 'newEvents' as const, label: 'New Events' },
                              { key: 'savedEventReminders' as const, label: 'Reminders' },
                              { key: 'collectionUpdates' as const, label: 'Collections' },
                              { key: 'emailNotifications' as const, label: 'Email' },
                            ]).map((item) => (
                              <div key={item.key} style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 0, padding: '0.75rem 0', borderBottom: `1px solid ${neutralPalette.borderSubtle}`, alignItems: 'center' }}>
                                <span style={{ fontSize: '0.75rem', color: neutralPalette.text, fontWeight: 500 }}>{item.label}</span>
                                <div className="flex justify-end">
                                  <button onClick={() => updateNotifSettings({ [item.key]: !notifSettings[item.key] })} className="relative cursor-pointer flex-shrink-0 transition-colors" style={{ width: 36, height: 20, borderRadius: 10, backgroundColor: notifSettings[item.key] ? neutralPalette.text : neutralPalette.border, border: 'none' }}>
                                    <div className="absolute rounded-full shadow-sm transition-all" style={{ top: 2, width: 16, height: 16, left: notifSettings[item.key] ? 18 : 2, backgroundColor: neutralPalette.bg, borderRadius: '50%' }} />
                                  </button>
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                        {profileTab === 'settings' && (
                          <div>
                            <span style={{ fontSize: '0.55rem', fontWeight: 600, letterSpacing: '0.18em', textTransform: 'uppercase', color: neutralPalette.textMuted, display: 'block', marginBottom: '1rem' }}>Settings</span>
                            <Link to="/profile" onClick={() => setProfileOpen(false)} className="transition-opacity hover:opacity-70" style={{ textDecoration: 'none', display: 'grid', gridTemplateColumns: '2fr 1fr', padding: '0.75rem 0', borderBottom: `1px solid ${neutralPalette.borderSubtle}` }}>
                              <span style={{ fontSize: '0.75rem', color: neutralPalette.text, fontWeight: 500 }}>{t('profile.profileSettings')}</span>
                              <ChevronRight size={14} className="ml-auto" style={{ color: neutralPalette.textMuted }} />
                            </Link>
                            <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', padding: '0.75rem 0', borderBottom: `1px solid ${neutralPalette.borderSubtle}`, alignItems: 'center' }}>
                              <span style={{ fontSize: '0.75rem', color: neutralPalette.text, fontWeight: 500 }}>Language</span>
                              <div className="flex justify-end">
                                <LanguageToggle navBtnBg={neutralPalette.bgAlt} textColor={neutralPalette.textMuted} activeColor={neutralPalette.text} borderRadius="2px" />
                              </div>
                            </div>
                            <div className="mt-6 flex items-center gap-2">
                              <Sparkles size={10} style={{ color: neutralPalette.textMuted, opacity: 0.5 }} />
                              <span style={{ fontSize: '0.5rem', color: neutralPalette.textMuted, opacity: 0.6, letterSpacing: '0.1em' }}>{t('profile.tagline')}</span>
                            </div>
                          </div>
                        )}
                      </div>
                    </>
                  ) : (
                    /* ═══ MODE-SPECIFIC PROFILE ═══ */
                    <>
                      <div className="relative px-5 pt-8 pb-6 text-center" style={{ background: `linear-gradient(180deg, ${modeColor ? modeColor + '12' : 'rgba(131,56,236,0.06)'} 0%, transparent 100%)` }}>
                        <div className="flex justify-center mb-4">
                          <div className="relative">
                            <div className="w-[88px] h-[88px] rounded-full p-[3px]" style={{ background: `linear-gradient(135deg, ${modeColor || '#8338EC'}, ${modeColor ? modeColor + '88' : '#8338EC88'})` }}>
                              <div className="w-full h-full rounded-full flex items-center justify-center text-2xl font-bold" style={{ backgroundColor: tokens.pageBg, color: modeColor || '#8338EC' }}>
                                {user.name?.charAt(0).toUpperCase() || 'U'}
                              </div>
                            </div>
                            <div className="absolute bottom-0 right-0 w-7 h-7 rounded-full flex items-center justify-center cursor-pointer" style={{ backgroundColor: modeColor || '#8338EC', border: `3px solid ${tokens.pageBg}` }}>
                              <Camera size={12} color="#fff" />
                            </div>
                          </div>
                        </div>
                        <p className="text-base font-semibold" style={{ color: tokens.textPrimary }}>{user.name}</p>
                        <p className="text-xs mt-0.5" style={{ color: tokens.textMuted }}>{user.email}</p>
                        <div className="flex items-center justify-center gap-4 mt-3 text-xs" style={{ color: tokens.textSecondary }}>
                          <div className="flex items-center gap-1.5">
                            <Heart size={12} style={{ color: '#EF4444' }} />
                            <span className="font-semibold" style={{ color: tokens.textPrimary }}>{savedEventIds.length}</span>
                            <span>{t('profile.saved')}</span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <FolderOpen size={12} style={{ color: modeColor || '#8338EC' }} />
                            <span className="font-semibold" style={{ color: tokens.textPrimary }}>{collections.length}</span>
                            <span>Collections</span>
                          </div>
                        </div>
                        <button onClick={async () => { await signOut(); setProfileOpen(false); }} className="mt-4 inline-flex items-center gap-2 px-5 py-2 text-xs font-medium rounded-full cursor-pointer transition-all hover:opacity-80" style={{ color: '#EF4444', border: '1.5px solid rgba(239,68,68,0.3)', backgroundColor: 'rgba(239,68,68,0.04)' }}>
                          <LogOut size={13} />
                          {t('profile.signOut')}
                        </button>
                      </div>
                      <div style={{ height: 1, backgroundColor: tokens.cardBorder }} />
                      <div className="flex items-center px-3 py-2 gap-1" style={{ borderBottom: `1px solid ${tokens.cardBorder}` }}>
                        {([
                          { id: 'profile' as const, icon: User },
                          { id: 'notifications' as const, icon: Bell },
                          { id: 'activity' as const, icon: CalendarDays },
                          { id: 'settings' as const, icon: Settings },
                        ]).map((tab) => (
                          <button key={tab.id} onClick={() => setProfileTab(tab.id)} className="flex-1 flex items-center justify-center py-2.5 rounded-xl transition-all cursor-pointer" style={{ backgroundColor: profileTab === tab.id ? (modeColor ? `${modeColor}10` : 'rgba(131,56,236,0.08)') : 'transparent', color: profileTab === tab.id ? (modeColor || '#8338EC') : tokens.textMuted, border: profileTab === tab.id ? `1px solid ${modeColor ? modeColor + '25' : 'rgba(131,56,236,0.15)'}` : '1px solid transparent' }}>
                            <tab.icon size={16} />
                            {tab.id === 'notifications' && notifUnreadCount > 0 && (
                              <span className="ml-1 min-w-[16px] h-[16px] flex items-center justify-center text-[9px] font-bold rounded-full" style={{ backgroundColor: modeColor || '#8338EC', color: '#fff' }}>{notifUnreadCount > 9 ? '9+' : notifUnreadCount}</span>
                            )}
                          </button>
                        ))}
                      </div>
                      <div className="flex-1 px-5 py-4 overflow-y-auto">
                        {profileTab === 'profile' && (
                          <div className="space-y-3">
                            <div>
                              <span className="block text-[10px] font-medium uppercase tracking-wider mb-2" style={{ color: tokens.textMuted }}>{t('profile.activeMode')}</span>
                              <div className="flex items-center gap-3 px-3.5 py-3 rounded-xl" style={{ backgroundColor: `${modeColor || '#8338EC'}10`, border: `1px solid ${modeColor || '#8338EC'}20` }}>
                                <CIcon id={currentMode} size={22} mode={currentMode} glow animated />
                                <div className="flex-1 min-w-0">
                                  <span className="block text-sm font-semibold" style={{ color: modeColor || '#8338EC' }}>{currentMode === 'lifestyle' ? t('modes.lifestyle') : modeConfig[currentMode].label}</span>
                                  <span className="block text-[10px]" style={{ color: tokens.textMuted }}>{currentMode === 'lifestyle' ? '生活方式 · Curated living' : `${modeConfig[currentMode].labelZh} · ${modeConfig[currentMode].description}`}</span>
                                </div>
                              </div>
                            </div>
                            {(() => {
                              try {
                                const raw = localStorage.getItem('cultive-preferences');
                                const prefs = raw ? JSON.parse(raw) : null;
                                if (prefs?.interests?.length > 0) {
                                  return (
                                    <div>
                                      <span className="block text-[10px] font-medium uppercase tracking-wider mb-2" style={{ color: tokens.textMuted }}>{t('profile.yourInterests')}</span>
                                      <div className="flex flex-wrap gap-1.5">
                                        {prefs.interests.slice(0, 8).map((id: string) => (
                                          <span key={id} className="inline-flex items-center gap-1 px-2.5 py-1 text-[10px] rounded-full" style={{ backgroundColor: `${modeColor || '#8338EC'}12`, color: `${modeColor || '#8338EC'}cc` }}>
                                            <CIcon id={id} size={10} mode="auto" glow={false} />
                                            {t(`interests.${id}`, id)}
                                          </span>
                                        ))}
                                      </div>
                                    </div>
                                  );
                                }
                              } catch {}
                              return null;
                            })()}
                            <div style={{ height: 1, backgroundColor: tokens.cardBorder }} />
                            <div className="space-y-0.5">
                              {[
                                { to: '/saved', icon: Bookmark, label: t('profile.savedEvents'), color: modeColor || '#8338EC' },
                                { to: '/collections', icon: FolderOpen, label: t('profile.collections'), color: modeColor || '#8338EC' },
                                { to: '/map', icon: MapPin, label: t('profile.exploreMap'), color: modeColor || '#8338EC' },
                                { to: '/contribute', icon: Plus, label: t('profile.submitEvent'), color: modeColor || '#8338EC' },
                              ].map((item) => (
                                <Link key={item.to} to={item.to} onClick={() => setProfileOpen(false)} className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-all hover:opacity-80 group" style={{ color: tokens.textPrimary, textDecoration: 'none' }}>
                                  <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: `${item.color}12` }}>
                                    <item.icon size={15} style={{ color: item.color }} />
                                  </div>
                                  <span className="flex-1 text-[13px] font-medium">{item.label}</span>
                                  <ChevronRight size={14} style={{ color: tokens.textMuted, opacity: 0.5 }} />
                                </Link>
                              ))}
                            </div>
                          </div>
                        )}
                        {profileTab === 'notifications' && (
                          <div>
                            <span className="block text-[10px] font-medium uppercase tracking-wider mb-3" style={{ color: tokens.textMuted }}>Notification Preferences</span>
                            <div className="space-y-1">
                              {([
                                { key: 'upcomingEvents' as const, label: 'Upcoming Events', desc: "Reminders for events you've saved" },
                                { key: 'newEvents' as const, label: 'New Events', desc: 'When new events are added in your interests' },
                                { key: 'savedEventReminders' as const, label: 'Event Reminders', desc: '24h reminder before saved events' },
                                { key: 'collectionUpdates' as const, label: 'Collection Updates', desc: 'When shared collections are updated' },
                                { key: 'emailNotifications' as const, label: 'Email Notifications', desc: 'Receive notifications by email' },
                              ]).map((item) => (
                                <div key={item.key} className="flex items-center justify-between px-3 py-3 rounded-xl" style={{ backgroundColor: tokens.surfaceBg }}>
                                  <div className="flex-1 min-w-0 mr-3">
                                    <span className="block text-[13px] font-medium" style={{ color: tokens.textPrimary }}>{item.label}</span>
                                    <span className="block text-[10px]" style={{ color: tokens.textMuted }}>{item.desc}</span>
                                  </div>
                                  <button onClick={() => updateNotifSettings({ [item.key]: !notifSettings[item.key] })} className="relative w-11 h-6 rounded-full transition-colors cursor-pointer flex-shrink-0" style={{ backgroundColor: notifSettings[item.key] ? (modeColor || '#8338EC') : 'rgba(0,0,0,0.12)' }}>
                                    <div className="absolute top-[3px] w-[18px] h-[18px] rounded-full bg-white shadow-sm transition-transform" style={{ left: notifSettings[item.key] ? '22px' : '3px' }} />
                                  </button>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                        {profileTab === 'activity' && (
                          <div>
                            <span className="block text-[10px] font-medium uppercase tracking-wider mb-3" style={{ color: tokens.textMuted }}>Your Activity</span>
                            <div className="space-y-3">
                              {([
                                { icon: Heart, count: savedEventIds.length, label: 'Saved Events', color: '#EF4444', bg: 'rgba(239,68,68,0.08)' },
                                { icon: FolderOpen, count: collections.length, label: 'Collections', color: modeColor || '#8338EC', bg: `${modeColor || '#8338EC'}12` },
                                { icon: CalendarDays, count: 0, label: 'Events Attended', color: modeColor || '#8338EC', bg: `${modeColor || '#8338EC'}12` },
                              ]).map((item) => (
                                <div key={item.label} className="flex flex-col items-center py-5 rounded-2xl" style={{ backgroundColor: tokens.surfaceBg, border: `1px solid ${tokens.cardBorder}` }}>
                                  <div className="w-10 h-10 rounded-full flex items-center justify-center mb-2" style={{ backgroundColor: item.bg }}>
                                    <item.icon size={18} style={{ color: item.color }} />
                                  </div>
                                  <span className="text-xl font-bold" style={{ color: tokens.textPrimary }}>{item.count}</span>
                                  <span className="text-[11px]" style={{ color: tokens.textMuted }}>{item.label}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                        {profileTab === 'settings' && (
                          <div className="space-y-3">
                            <span className="block text-[10px] font-medium uppercase tracking-wider mb-2" style={{ color: tokens.textMuted }}>Settings</span>
                            <Link to="/profile" onClick={() => setProfileOpen(false)} className="flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all hover:opacity-80" style={{ color: tokens.textPrimary, backgroundColor: tokens.surfaceBg, textDecoration: 'none' }}>
                              <Settings size={15} style={{ color: tokens.textMuted }} />
                              <span className="text-[13px] font-medium">{t('profile.profileSettings')}</span>
                              <ChevronRight size={14} className="ml-auto" style={{ color: tokens.textMuted, opacity: 0.5 }} />
                            </Link>
                            <div className="flex items-center gap-3 px-3 py-2.5 rounded-xl" style={{ backgroundColor: tokens.surfaceBg }}>
                              <span className="text-[13px] font-medium" style={{ color: tokens.textPrimary }}>Language</span>
                              <div className="ml-auto">
                                <LanguageToggle navBtnBg={tokens.surfaceBg} textColor={tokens.textMuted} activeColor={modeColor || '#8338EC'} borderRadius="9999px" />
                              </div>
                            </div>
                            <div style={{ height: 1, backgroundColor: tokens.cardBorder }} />
                            <div className="flex items-center gap-2 px-1">
                              <Sparkles size={12} style={{ color: tokens.textMuted, opacity: 0.5 }} />
                              <span className="text-[10px]" style={{ color: tokens.textMuted, opacity: 0.7 }}>{t('profile.tagline')}</span>
                            </div>
                          </div>
                        )}
                      </div>
                    </>
                  )}
                </div>
              ) : (
                <ProfileAuthForms 
                  onClose={() => setProfileOpen(false)}
                  tokens={tokens}
                  modeColor={modeColor}
                />
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Mobile menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="fixed inset-x-0 z-[1100] md:hidden"
            style={{
              top: isArtsy ? '80px' : '64px',
              bottom: 0,
              borderBottom: `1px solid ${tokens.navBorder}`,
              backgroundColor: isArtsy
                ? 'rgba(245, 241, 235, 0.97)'
                : isFoodie
                  ? 'rgba(10, 18, 32, 0.97)'
                  : isFamily
                    ? 'rgba(255, 248, 240, 0.97)'
                    : isDegen
                      ? 'rgba(237, 255, 0, 0.97)'
                      : neutralIsDark
                        ? 'rgba(10, 10, 10, 0.97)'
                        : 'rgba(250, 250, 248, 0.97)',
              backdropFilter: 'blur(20px)',
            }}
          >
            <div className="p-4 space-y-3 overflow-y-auto h-full pb-8">
              {navItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={() => { setMobileMenuOpen(false); }}
                  className="flex items-center gap-3 px-4 py-3 transition-all"
                  style={{
                    borderRadius: tokens.borderRadius,
                    backgroundColor: location.pathname === item.path
                      ? (isFoodie ? 'rgba(37,99,235,0.12)' : (light && !neutralIsDark ? 'rgba(0,0,0,0.06)' : 'rgba(255,255,255,0.1)'))
                      : 'transparent',
                    color: location.pathname === item.path
                      ? (neutralIsDark ? '#FAFAF8' : tokens.textPrimary)
                      : (neutralIsDark ? 'rgba(255,255,255,0.5)' : tokens.textMuted),
                  }}
                >
                  <item.icon size={18} />
                  <span>{item.label}</span>
                </Link>
              ))}
              {user ? (
                <div className="flex items-center gap-1 flex-wrap pt-1">
                  <Link
                    to="/profile"
                    onClick={() => setMobileMenuOpen(false)}
                    className="flex items-center gap-3 px-4 py-3 flex-1 transition-all"
                    style={{
                      borderRadius: tokens.borderRadius,
                      color: location.pathname === '/profile'
                        ? (neutralIsDark ? '#FAFAF8' : tokens.textPrimary)
                        : (neutralIsDark ? 'rgba(255,255,255,0.5)' : tokens.textMuted),
                      backgroundColor: location.pathname === '/profile'
                        ? (isFoodie ? 'rgba(37,99,235,0.12)' : (light && !neutralIsDark ? 'rgba(0,0,0,0.06)' : 'rgba(255,255,255,0.1)'))
                        : 'transparent',
                    }}
                  >
                    <div className="relative">
                      <User size={18} />
                      {notifUnreadCount > 0 && (
                        <span
                          className="absolute -top-1.5 -right-1.5 min-w-[14px] h-[14px] flex items-center justify-center text-[8px] font-bold rounded-full"
                          style={{
                            backgroundColor: modeColor || '#8338EC',
                            color: '#fff',
                            padding: '0 2px',
                          }}
                        >
                          {notifUnreadCount > 9 ? '9+' : notifUnreadCount}
                        </span>
                      )}
                    </div>
                    <span>{t('nav.profile', 'Profile')}</span>
                    {notifUnreadCount > 0 && (
                      <span
                        className="ml-auto text-[11px] px-2 py-0.5 rounded-full font-semibold"
                        style={{ backgroundColor: modeColor ? `${modeColor}18` : 'rgba(131,56,236,0.1)', color: modeColor || '#8338EC' }}
                      >
                        {notifUnreadCount}
                      </span>
                    )}
                  </Link>
                </div>
              ) : (
                <Link
                  to="/login"
                  onClick={() => setMobileMenuOpen(false)}
                  className="flex items-center gap-3 px-4 py-3 transition-all"
                  style={{
                    borderRadius: tokens.borderRadius,
                    color: neutralIsDark ? 'rgba(255,255,255,0.5)' : tokens.textMuted,
                  }}
                >
                  <LogIn size={18} />
                  <span>{t('nav.signIn', 'Sign In')}</span>
                </Link>
              )}
              {/* Language toggle in mobile menu */}
              <div className="flex items-center gap-3 px-4 py-2">
                <LanguageToggle
                  navBtnBg={neutralIsDark ? 'rgba(255,255,255,0.1)' : (light ? 'rgba(0,0,0,0.06)' : 'rgba(255,255,255,0.1)')}
                  textColor={neutralIsDark ? 'rgba(255,255,255,0.5)' : tokens.textMuted}
                  activeColor={neutralIsDark ? '#FAFAF8' : tokens.textPrimary}
                  borderRadius={isDegen ? '4px' : '9999px'}
                />
              </div>
              <div className="pt-3" style={{ borderTop: `1px solid ${tokens.navBorder}` }}>
                <MobileModeCards onSelect={() => setMobileMenuOpen(false)} />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main content — map page skips AnimatePresence to prevent Leaflet blank-render */}
      <main className={`${isArtsy ? 'pt-20' : 'pt-16'} overflow-x-hidden`}>
        {location.pathname === '/map' ? (
          <div style={{ minHeight: 'calc(100vh - 64px)' }}>
            <Outlet />
          </div>
        ) : (
          <AnimatePresence mode="wait" initial={false}>
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.15, ease: 'easeOut' }}
              style={{ minHeight: 'calc(100vh - 64px)' }}
            >
              <Outlet />
            </motion.div>
          </AnimatePresence>
        )}
      </main>

      <SearchOverlay isOpen={searchOpen} onClose={() => setSearchOpen(false)} />
    </div>
  );
}