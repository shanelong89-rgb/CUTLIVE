import type { ReactNode } from 'react';

/**
 * Wraps a mobile horizontal-scroll carousel with subtle fade edges
 * that indicate swipe-ability. Hidden on sm+ breakpoints.
 * Pass `fadeBg` matching the section background color.
 */
export function CarouselFade({ children, fadeBg = '#ffffff' }: { children: ReactNode; fadeBg?: string }) {
  return (
    <div
      className="carousel-fade-edges"
      style={{ '--carousel-fade-bg': fadeBg } as React.CSSProperties}
    >
      {children}
    </div>
  );
}
