/**
 * ═══════════════════════════════════════════════════════════════════
 * CULTIVE API & CMS Manifest — Machine-readable route map
 *
 * Single source of truth for all API endpoints, CMS data flows,
 * admin pages, and public routes. Designed for AI agent navigation
 * (Paperclip-style zero-human orchestration).
 *
 * An agent can import this file and programmatically discover:
 *   - Every API endpoint and its purpose
 *   - The CMS data pipeline (submit → review → publish → render)
 *   - Admin page ↔ API endpoint relationships
 *   - Frontend page ↔ data source relationships
 * ═══════════════════════════════════════════════════════════════════
 */

import { projectId } from './supabase';

export const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-d507b98c`;
export const CMS_BASE = `${API_BASE}/cms`;

// ─── API Endpoints ───────────────────────────────────────────────────────

export interface ApiEndpoint {
  path: string;
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  auth: 'anon' | 'admin';
  description: string;
  requestBody?: string;
  responseShape?: string;
}

export const API_ENDPOINTS: ApiEndpoint[] = [
  // ── System ──
  { path: '/status',     method: 'GET',  auth: 'anon',  description: 'Check if KV store is seeded; returns { seeded, details: { version } }' },
  { path: '/seed',       method: 'POST', auth: 'anon',  description: 'Seed KV store with initial data (venues, events, recaps)' },

  // ── Primary Data (KV store) ──
  { path: '/venues',            method: 'GET',  auth: 'anon',  description: 'All seeded venues',              responseShape: '{ venues: Venue[] }' },
  { path: '/events',            method: 'GET',  auth: 'anon',  description: 'All seeded events',              responseShape: '{ events: CulturalEvent[] }' },
  { path: '/events/:id',        method: 'GET',  auth: 'anon',  description: 'Single event by ID',             responseShape: '{ event: CulturalEvent }' },
  { path: '/events/:id',        method: 'DELETE', auth: 'admin', description: 'Delete a single event from KV' },
  { path: '/recaps',            method: 'GET',  auth: 'anon',  description: 'All recaps',                     responseShape: '{ recaps: Recap[] }' },

  // ── Bulk Import ──
  { path: '/events/bulk',         method: 'POST', auth: 'anon',  description: 'Bulk upsert events (RA/Apify)', requestBody: '{ events, batchMeta }' },
  { path: '/events/bulk/history', method: 'GET',  auth: 'anon',  description: 'Import batch history',              responseShape: '{ batches: ImportBatch[] }' },

  // ── CMS Content (generic CRUD) ──
  { path: '/cms/content/:type/public', method: 'GET',  auth: 'anon',  description: 'Public CMS items by type (event/venue/recap)', responseShape: '{ items: T[] }' },
  { path: '/cms/content/:type',        method: 'GET',  auth: 'admin', description: 'All CMS items by type (includes drafts)' },
  { path: '/cms/content/:type',        method: 'POST', auth: 'admin', description: 'Create CMS item',           requestBody: '{ ...fields }' },
  { path: '/cms/content/:type/:id',    method: 'PUT',  auth: 'admin', description: 'Update CMS item by ID',     requestBody: '{ ...fields }' },
  { path: '/cms/content/:type/:id',    method: 'DELETE', auth: 'admin', description: 'Delete CMS item by ID' },
  { path: '/cms/content/:type/bulk-delete', method: 'POST', auth: 'admin', description: 'Bulk delete CMS items', requestBody: '{ ids: string[] }' },

  // ── CMS Submissions Pipeline ──
  { path: '/cms/submissions',             method: 'GET',  auth: 'admin', description: 'All submissions (with counts by status)', responseShape: '{ submissions, counts }' },
  { path: '/cms/submissions',             method: 'POST', auth: 'anon',  description: 'Create new submission (public contribute form)' },
  { path: '/cms/submissions/published',   method: 'GET',  auth: 'anon',  description: 'Published submissions for frontend rendering', responseShape: '{ submissions: Submission[] }' },
  { path: '/cms/submissions/:id/status',  method: 'PUT',  auth: 'admin', description: 'Update submission status (approve/reject/publish)', requestBody: '{ status, adminNotes? }' },
  { path: '/cms/submissions/:id',         method: 'PATCH', auth: 'admin', description: 'Partial update submission fields' },
  { path: '/cms/submissions/:id',         method: 'DELETE', auth: 'admin', description: 'Delete a submission' },
  { path: '/cms/submissions/bulk-action', method: 'POST', auth: 'admin', description: 'Bulk approve/reject/publish/delete', requestBody: '{ ids, action }' },

  // ── CMS Single Event Lookup ──
  { path: '/cms/event/:id',  method: 'GET', auth: 'anon', description: 'Single event from CMS submissions (fallback for EventDetailPage)' },

  // ── Weekly Picks ──
  { path: '/cms/content/weekly-picks', method: 'GET', auth: 'anon',  description: 'Current curated picks (content KV store)', responseShape: '{ items: [{ id: "curated", data: { eventIds, note, updatedAt } }] }' },
  { path: '/cms/content/weekly-picks/curated', method: 'PUT', auth: 'admin', description: 'Save curated picks',    requestBody: '{ id: "curated", sectionId: "curated", data: { eventIds, note } }' },

  // ── Hidden IDs ──
  { path: '/cms/hidden-ids', method: 'GET', auth: 'anon', description: 'IDs of hidden/deleted events to filter from frontend', responseShape: '{ ids: string[] }' },

  // ── Media & Utils ──
  { path: '/cms/upload',             method: 'POST', auth: 'anon',  description: 'Upload images (multipart/form-data)' },
  { path: '/cms/parse-url',          method: 'POST', auth: 'anon',  description: 'Parse Instagram/Google Maps URL for autofill', requestBody: '{ url }' },
  { path: '/cms/analyze-content',    method: 'POST', auth: 'anon',  description: 'AI content analysis for submissions',          requestBody: '{ text, authorName? }' },
  { path: '/submission-status/:id',  method: 'GET',  auth: 'anon',  description: 'Public submission status check' },

  // ── Admin Auth ──
  { path: '/cms/admin/check',  method: 'GET',  auth: 'anon', description: 'Check if admin user exists',  responseShape: '{ hasAdmin }' },
  { path: '/cms/admin/signup', method: 'POST', auth: 'anon', description: 'Create first admin account', requestBody: '{ email, password, name }' },

  // ── Contributors ──
  { path: '/cms/contributors', method: 'GET', auth: 'admin', description: 'List all contributors' },

  // ── Mock Data Management ──
  { path: '/admin/mock-data/stats', method: 'GET',  auth: 'anon', description: 'Mock vs real data stats' },
  { path: '/admin/mock-data/purge', method: 'POST', auth: 'anon', description: 'Purge all mock/seed data' },

  // ── Analytics & Reports (Clawbot + Admin) ──
  { path: '/admin/analytics/overview',    method: 'GET',  auth: 'admin', description: 'Platform-wide analytics: total views, saves, shares, top events, category/venue/contributor breakdowns', responseShape: '{ overview, topByViews, topBySaves, topByShares, categoryBreakdown, venueBreakdown, contributorBreakdown }' },
  { path: '/admin/analytics/event/:id',   method: 'GET',  auth: 'admin', description: 'Single event analytics: views, saves, shares, metadata', responseShape: '{ eventId, title, views, saves, shares, category, venue, date, contributor }' },
  { path: '/admin/analytics/report',      method: 'POST', auth: 'admin', description: 'Generate structured report for venue/contributor/platform. Returns summary + per-event breakdown.', requestBody: '{ type: "venue"|"contributor"|"platform", targetId?, targetName? }', responseShape: '{ report: { reportType, targetName, generatedAt, summary, topEvents, allEvents } }' },
  { path: '/events/track-view',           method: 'POST', auth: 'anon',  description: 'Increment view count for an event',    requestBody: '{ eventId }' },
  { path: '/events/track-save',           method: 'POST', auth: 'anon',  description: 'Increment/decrement save count',       requestBody: '{ eventId, action: "save"|"unsave" }' },
  { path: '/events/track-share',          method: 'POST', auth: 'anon',  description: 'Increment share count for an event',   requestBody: '{ eventId, platform?: string }' },
  { path: '/events/stats/:id',            method: 'GET',  auth: 'anon',  description: 'Get view + save + share count for one event',  responseShape: '{ views, saves, shares }' },
  { path: '/events/stats/batch',          method: 'POST', auth: 'anon',  description: 'Batch get stats for multiple events',  requestBody: '{ eventIds: string[] }', responseShape: '{ stats: Record<string, { views, saves, shares }> }' },

  // ── Webhooks (KV-backed) ──
  { path: '/cms/webhooks',              method: 'GET',    auth: 'admin', description: 'Read registered webhooks + delivery log from KV',       responseShape: '{ webhooks: WebhookRegistration[], deliveryLog: DeliveryLogEntry[] }' },
  { path: '/cms/webhooks',              method: 'PUT',    auth: 'admin', description: 'Save entire webhook registry to KV',                    requestBody: '{ webhooks: WebhookRegistration[] }' },
  { path: '/cms/webhooks/delivery-log',  method: 'GET',    auth: 'admin', description: 'Read delivery log from KV',                             responseShape: '{ deliveryLog: DeliveryLogEntry[] }' },
  { path: '/cms/webhooks/delivery-log',  method: 'POST',   auth: 'admin', description: 'Append delivery log entries to KV (capped at 200)',     requestBody: '{ entries: DeliveryLogEntry[] }' },
  { path: '/cms/webhooks/delivery-log',  method: 'DELETE',  auth: 'admin', description: 'Clear delivery log in KV' },
  { path: '/cms/webhooks/delivery-log/export', method: 'GET', auth: 'admin', description: 'Export delivery log as downloadable CSV or JSON file. Query param: format=csv|json. Includes Content-Disposition header for audit trails.', responseShape: 'File download (text/csv or application/json)' },
  { path: '/cms/webhooks/health',        method: 'GET',    auth: 'anon',  description: 'Public health check for agent connectivity verification. Rate-limited: 30 req/min per IP. Returns platform info, supported event types, nonce for latency measurement. Includes X-RateLimit-* headers.', responseShape: '{ status, platform, version, nonce, timestamp, capabilities, registeredCount, activeCount }' },
];

// ─── CMS Pipeline ────────────────────────────────────────────────────────

export const CMS_PIPELINE = {
  description: 'Content flows through: Submit → Review → Approve/Reject → Publish → Render on frontend',
  stages: [
    { name: 'submit', description: 'Public form creates a submission (status: pending)' },
    { name: 'review', description: 'Admin reviews in CMS dashboard (/admin/submissions)' },
    { name: 'approve', description: 'Admin approves  status: approved' },
    { name: 'reject', description: 'Admin rejects with notes → status: rejected' },
    { name: 'publish', description: 'Admin publishes → status: published, visible on frontend' },
  ],
};

// ─── Admin Pages ─────────────────────────────────────────────────────────

export const ADMIN_PAGES = [
  { path: '/admin', description: 'Admin dashboard — overview stats' },
  { path: '/admin/content', description: 'CMS content manager (events, venues, recaps)' },
  { path: '/admin/submissions', description: 'Submission review pipeline (approve/reject/publish)' },
  { path: '/admin/weekly-picks', description: 'Curate weekly event picks' },
  { path: '/admin/import', description: 'Bulk import from RA/Apify' },
  { path: '/admin/webhooks', description: 'Webhook registry + delivery logs + export' },
  { path: '/admin/contributors', description: 'Contributor management' },
  { path: '/admin/copy-editor', description: 'CMS copy override editor' },
  { path: '/admin/mock-data', description: 'Mock data stats + purge tool' },
  { path: '/admin/template-editor', description: 'Template editor with Site Images tab — override all hardcoded images sitewide via CMS' },
];

// ─── Public Pages ────────────────────────────────────────────────────────

export const PUBLIC_PAGES = [
  { path: '/', description: 'Homepage — event discovery with 5-mode system' },
  { path: '/events/:id', description: 'Event detail page' },
  { path: '/venues/:id', description: 'Venue detail page' },
  { path: '/contribute', description: 'Public event submission form' },
  { path: '/submission-status/:id', description: 'Public submission status tracker' },
  { path: '/api/manifest', description: 'Machine-readable API manifest (this page)' },
];

// ─── Auth Pattern ────────────────────────────────────────────────────────

export const AUTH_PATTERN = {
  type: 'single-admin',
  description: 'Single admin account. AdminLayout provides accessToken via useOutletContext. All admin pages consume it — never call useAdminAuth() independently.',
  tokenHeader: 'X-Auth-Token',
  signupEndpoint: '/cms/admin/signup',
  checkEndpoint: '/cms/admin/check',
};

// ─── Content Types ───────────────────────────────────────────────────────

export const CONTENT_TYPES = ['event', 'venue', 'recap'];

// ─── Cache Strategy ──────────────────────────────────────────────────────

export const CACHE_STRATEGY = {
  description: 'Client-side SWR with localStorage fallback. No CDN caching on Edge Functions.',
  ttl: '5 minutes for public data, no cache for admin endpoints',
};