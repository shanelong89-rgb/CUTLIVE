/**
 * ═══════════════════════════════════════════════════════════════════
 * CULTIVE Webhook System — Paperclip-style event-driven orchestration
 *
 * Enables AI agents and external systems to react to CMS state changes
 * in real-time. Webhooks fire on submission lifecycle transitions,
 * content CRUD, weekly picks updates, and bulk import completions.
 *
 * Architecture:
 *   1. Admin registers webhook URLs via WebhookManager or API
 *   2. On CMS state change, fireWebhook() sends POST to all matching URLs
 *   3. Payload is signed with HMAC-SHA256 for verification
 *   4. Failed deliveries are retried with exponential backoff (max 5 attempts)
 *
 * Storage:
 *   Primary: Supabase KV via /cms/webhooks endpoints (persists across devices)
 *   Fallback: localStorage (offline / no auth scenarios)
 *   Sync: On load, KV data is pulled and merged with localStorage cache
 *
 * Usage (in admin pages / API handlers):
 *   import { fireWebhook } from '../config/webhooks';
 *   await fireWebhook('submission.published', { submissionId, title });
 * ═══════════════════════════════════════════════════════════════════
 */

import { projectId, publicAnonKey } from './supabase';

const CMS_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-d507b98c/cms`;

// ─── Event Types ─────────────────────────────────────────────────────────

export const WEBHOOK_EVENTS = [
  'submission.created',
  'submission.status_changed',
  'submission.published',
  'submission.rejected',
  'content.created',
  'content.updated',
  'content.deleted',
  'weekly_picks.updated',
  'bulk_import.completed',
] as const;

export type WebhookEvent = (typeof WEBHOOK_EVENTS)[number];

export interface WebhookRegistration {
  id: string;
  url: string;
  events: WebhookEvent[];     // which events trigger this hook
  secret: string;             // shared secret for HMAC signing
  active: boolean;
  label?: string;             // human-readable label ("Paperclip orchestrator")
  createdAt: string;
  lastTriggered?: string;
  failCount: number;
}

export interface WebhookPayload {
  event: WebhookEvent;
  timestamp: string;
  data: Record<string, any>;
  deliveryId: string;
  attempt: number;
}

// ─── Retry Queue Types ──────────────────────────────────────────────────

interface RetryEntry {
  id: string;
  hookId: string;
  hookUrl: string;
  hookSecret: string;
  payload: WebhookPayload;
  attempt: number;
  maxAttempts: number;
  nextRetryAt: number; // timestamp ms
}

const RETRY_KEY = 'cultive_webhook_retries';
const MAX_RETRY_ATTEMPTS = 5;
const BASE_DELAY_MS = 2000; // 2s, 4s, 8s, 16s, 32s

function getRetryQueue(): RetryEntry[] {
  try {
    const raw = localStorage.getItem(RETRY_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
}

function saveRetryQueue(queue: RetryEntry[]) {
  try { localStorage.setItem(RETRY_KEY, JSON.stringify(queue)); } catch {}
}

function enqueueRetry(entry: Omit<RetryEntry, 'nextRetryAt'>) {
  const queue = getRetryQueue();
  const delay = BASE_DELAY_MS * Math.pow(2, entry.attempt - 1); // exponential backoff
  queue.push({ ...entry, nextRetryAt: Date.now() + delay });
  saveRetryQueue(queue);
  console.log(`[CULTIVE] Retry queued for ${entry.hookUrl} — attempt ${entry.attempt}/${entry.maxAttempts} in ${delay}ms`);
}

export function getRetryQueueSize(): number {
  return getRetryQueue().length;
}

export function clearRetryQueue() {
  saveRetryQueue([]);
}

// ─── Storage: KV-backed with localStorage fallback ──────────────────────

const WEBHOOKS_KEY = 'cultive_webhooks';
let _kvSyncToken: string | null = null;

/** Set the admin access token so KV operations can authenticate */
export function setWebhookAuthToken(token: string | null) {
  _kvSyncToken = token;
}

function kvHeaders() {
  const h: Record<string, string> = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${publicAnonKey}`,
  };
  if (_kvSyncToken) h['X-Auth-Token'] = _kvSyncToken;
  return h;
}

/** Read webhooks — try KV first, fall back to localStorage */
export function getWebhooks(): WebhookRegistration[] {
  try {
    const raw = localStorage.getItem(WEBHOOKS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveWebhooks(hooks: WebhookRegistration[]) {
  try {
    localStorage.setItem(WEBHOOKS_KEY, JSON.stringify(hooks));
  } catch {}
  // Async KV write (fire-and-forget)
  persistToKV(hooks);
}

/** Sync from KV → localStorage. Call on admin page mount. */
export async function syncFromKV(): Promise<WebhookRegistration[]> {
  try {
    const res = await fetch(`${CMS_BASE}/webhooks`, {
      headers: kvHeaders(),
    });
    if (res.ok) {
      const data = await res.json();
      const hooks: WebhookRegistration[] = data.webhooks || [];
      if (hooks.length > 0) {
        // Merge: KV is source of truth, localStorage supplements
        const local = getWebhooks();
        const kvIds = new Set(hooks.map(h => h.id));
        const localOnly = local.filter(h => !kvIds.has(h.id));
        const merged = [...hooks, ...localOnly];
        try { localStorage.setItem(WEBHOOKS_KEY, JSON.stringify(merged)); } catch {}
        return merged;
      }
      // KV is empty but we might have local hooks to push up
      const local = getWebhooks();
      if (local.length > 0) {
        persistToKV(local);
      }
      return local;
    }
  } catch {
    // KV unavailable — use localStorage
  }
  return getWebhooks();
}

/** Push current webhooks to KV (async, non-blocking) */
async function persistToKV(hooks: WebhookRegistration[]) {
  if (!_kvSyncToken) return; // Need auth for KV writes
  try {
    await fetch(`${CMS_BASE}/webhooks`, {
      method: 'PUT',
      headers: kvHeaders(),
      body: JSON.stringify({ webhooks: hooks }),
    });
  } catch {
    // KV write failed — data is still safe in localStorage
  }
}

// ─── Delivery Log (persisted to KV for post-mortem debugging) ───────────

export interface DeliveryLogEntry {
  id: string;
  webhookId: string;
  webhookLabel?: string;
  webhookUrl: string;
  event: WebhookEvent;
  timestamp: string;
  status: 'success' | 'failed';
  responseTime: number;
  attempt: number;
  error?: string;
  deliveryId: string;
}

const DELIVERY_LOG_KEY = 'cultive_webhook_delivery_log';

export function getDeliveryLog(): DeliveryLogEntry[] {
  try {
    const raw = localStorage.getItem(DELIVERY_LOG_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
}

function saveDeliveryLog(log: DeliveryLogEntry[]) {
  // Keep max 200 locally
  const trimmed = log.slice(0, 200);
  try { localStorage.setItem(DELIVERY_LOG_KEY, JSON.stringify(trimmed)); } catch {}
}

/** Record a delivery attempt and persist to KV */
export function recordDelivery(entry: DeliveryLogEntry) {
  const log = getDeliveryLog();
  log.unshift(entry);
  saveDeliveryLog(log);
  // Async KV persist
  persistDeliveryLogToKV([entry]);
}

/** Persist delivery entries to KV (append mode) */
async function persistDeliveryLogToKV(entries: DeliveryLogEntry[]) {
  if (!_kvSyncToken) return;
  try {
    await fetch(`${CMS_BASE}/webhooks/delivery-log`, {
      method: 'POST',
      headers: kvHeaders(),
      body: JSON.stringify({ entries }),
    });
  } catch {}
}

/** Sync delivery log from KV on page mount */
export async function syncDeliveryLogFromKV(): Promise<DeliveryLogEntry[]> {
  try {
    const res = await fetch(`${CMS_BASE}/webhooks/delivery-log`, {
      headers: kvHeaders(),
    });
    if (res.ok) {
      const data = await res.json();
      const kvLog: DeliveryLogEntry[] = data.deliveryLog || [];
      if (kvLog.length > 0) {
        // Merge KV + local, dedupe by id
        const local = getDeliveryLog();
        const seen = new Set(kvLog.map(e => e.id));
        const localOnly = local.filter(e => !seen.has(e.id));
        const merged = [...kvLog, ...localOnly]
          .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
          .slice(0, 200);
        saveDeliveryLog(merged);
        return merged;
      }
      return getDeliveryLog();
    }
  } catch {}
  return getDeliveryLog();
}

/** Clear delivery log (local + KV) */
export async function clearDeliveryLog() {
  saveDeliveryLog([]);
  if (_kvSyncToken) {
    try {
      await fetch(`${CMS_BASE}/webhooks/delivery-log`, {
        method: 'DELETE',
        headers: kvHeaders(),
      });
    } catch {}
  }
}

/** Export delivery log as downloadable file (CSV or JSON) */
export async function exportDeliveryLog(format: 'csv' | 'json' = 'json'): Promise<void> {
  // Try KV export endpoint first (includes all persisted data)
  if (_kvSyncToken) {
    try {
      const res = await fetch(`${CMS_BASE}/webhooks/delivery-log/export?format=${format}`, {
        headers: kvHeaders(),
      });
      if (res.ok) {
        const blob = await res.blob();
        const disposition = res.headers.get('Content-Disposition') || '';
        const match = disposition.match(/filename="(.+?)"/);
        const filename = match?.[1] || `cultive-delivery-log.${format}`;
        triggerDownload(blob, filename);
        return;
      }
    } catch {}
  }

  // Fallback: export from localStorage
  const log = getDeliveryLog();
  const ts = new Date().toISOString().replace(/[:.]/g, '-');

  if (format === 'csv') {
    const cols = ['id', 'deliveryId', 'webhookId', 'webhookLabel', 'webhookUrl', 'event', 'timestamp', 'status', 'responseTime', 'attempt', 'error'];
    const esc = (v: any) => { const s = String(v ?? ''); return s.includes(',') || s.includes('"') || s.includes('\n') ? `"${s.replace(/"/g, '""')}"` : s; };
    const csv = [cols.join(','), ...log.map(e => cols.map(c => esc((e as any)[c])).join(','))].join('\n');
    triggerDownload(new Blob([csv], { type: 'text/csv' }), `cultive-delivery-log-${ts}.csv`);
  } else {
    const json = JSON.stringify({ exportedAt: new Date().toISOString(), platform: 'CULTIVE', count: log.length, deliveryLog: log }, null, 2);
    triggerDownload(new Blob([json], { type: 'application/json' }), `cultive-delivery-log-${ts}.json`);
  }
}

function triggerDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => { document.body.removeChild(a); URL.revokeObjectURL(url); }, 100);
}

// ─── CRUD ────────────────────────────────────────────────────────────────

export function registerWebhook(
  url: string,
  events: WebhookEvent[],
  label?: string
): WebhookRegistration {
  const hooks = getWebhooks();
  const hook: WebhookRegistration = {
    id: `wh_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    url,
    events,
    secret: crypto.randomUUID?.() || Math.random().toString(36).slice(2),
    active: true,
    label,
    createdAt: new Date().toISOString(),
    failCount: 0,
  };
  hooks.push(hook);
  saveWebhooks(hooks);
  return hook;
}

export function deleteWebhook(id: string) {
  const hooks = getWebhooks().filter(h => h.id !== id);
  saveWebhooks(hooks);
  // Also purge any pending retries for this hook
  const queue = getRetryQueue().filter(r => r.hookId !== id);
  saveRetryQueue(queue);
}

export function toggleWebhook(id: string, active: boolean) {
  const hooks = getWebhooks();
  const hook = hooks.find(h => h.id === id);
  if (hook) {
    hook.active = active;
    // Reset fail count on re-enable
    if (active) hook.failCount = 0;
    saveWebhooks(hooks);
  }
}

// ─── HMAC Signing ────────────────────────────────────────────────────────

async function signPayload(body: string, secret: string): Promise<string> {
  try {
    const encoder = new TextEncoder();
    const key = await crypto.subtle.importKey(
      'raw',
      encoder.encode(secret),
      { name: 'HMAC', hash: 'SHA-256' },
      false,
      ['sign']
    );
    const sig = await crypto.subtle.sign('HMAC', key, encoder.encode(body));
    return Array.from(new Uint8Array(sig))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');
  } catch {
    return 'signing-unavailable';
  }
}

// ─── Deliver Single Webhook ──────────────────────────────────────────────

async function deliverWebhook(
  hook: { id: string; url: string; secret: string },
  payload: WebhookPayload,
): Promise<boolean> {
  const body = JSON.stringify(payload);
  const signature = await signPayload(body, hook.secret);

  const res = await fetch(hook.url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Cultive-Event': payload.event,
      'X-Cultive-Signature': signature,
      'X-Cultive-Delivery': payload.deliveryId,
      'X-Cultive-Attempt': String(payload.attempt),
    },
    body,
    signal: AbortSignal.timeout(10000),
  });

  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return true;
}

// ─── Fire Webhook ────────────────────────────────────────────────────────

/**
 * Fire all registered webhooks matching the given event type.
 * Non-blocking — failures are queued for retry with exponential backoff.
 */
export async function fireWebhook(
  event: WebhookEvent,
  data: Record<string, any>
): Promise<{ sent: number; failed: number; queued: number }> {
  const hooks = getWebhooks().filter(h => h.active && h.events.includes(event));
  if (hooks.length === 0) return { sent: 0, failed: 0, queued: 0 };

  const deliveryId = `del_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

  let sent = 0;
  let failed = 0;
  let queued = 0;

  const results = await Promise.allSettled(
    hooks.map(async (hook) => {
      const payload: WebhookPayload = {
        event,
        timestamp: new Date().toISOString(),
        data,
        deliveryId,
        attempt: 1,
      };

      try {
        const start = Date.now();
        const success = await deliverWebhook(hook, payload);
        const responseTime = Date.now() - start;

        // Update last triggered
        const allHooks = getWebhooks();
        const h = allHooks.find(wh => wh.id === hook.id);
        if (h) {
          h.lastTriggered = new Date().toISOString();
          h.failCount = 0;
          saveWebhooks(allHooks);
        }

        // Record delivery
        recordDelivery({
          id: `log_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
          webhookId: hook.id,
          webhookLabel: hook.label,
          webhookUrl: hook.url,
          event,
          timestamp: new Date().toISOString(),
          status: 'success',
          responseTime,
          attempt: 1,
          deliveryId,
        });
        return 'sent' as const;
      } catch (err) {
        console.warn(`[CULTIVE] Webhook delivery failed for ${hook.id} (${hook.url}):`, err);

        // Increment fail count
        const allHooks = getWebhooks();
        const h = allHooks.find(wh => wh.id === hook.id);
        if (h) {
          h.failCount += 1;
          if (h.failCount >= 10) {
            h.active = false;
            console.warn(`[CULTIVE] Webhook ${hook.id} auto-disabled after ${h.failCount} failures`);
          }
          saveWebhooks(allHooks);
        }

        // Queue for retry (if not auto-disabled)
        if (!h || h.active) {
          // Record initial failure
          recordDelivery({
            id: `log_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
            webhookId: hook.id,
            webhookLabel: hook.label,
            webhookUrl: hook.url,
            event,
            timestamp: new Date().toISOString(),
            status: 'failed',
            responseTime: 0,
            attempt: 1,
            error: err instanceof Error ? err.message : 'Unknown error',
            deliveryId,
          });

          enqueueRetry({
            id: `retry_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
            hookId: hook.id,
            hookUrl: hook.url,
            hookSecret: hook.secret,
            payload: { ...payload, attempt: 2 },
            attempt: 2,
            maxAttempts: MAX_RETRY_ATTEMPTS,
          });
          return 'queued' as const;
        }

        throw err;
      }
    })
  );

  for (const r of results) {
    if (r.status === 'fulfilled') {
      if (r.value === 'sent') sent++;
      else if (r.value === 'queued') queued++;
    } else {
      failed++;
    }
  }

  console.log(`[CULTIVE] Webhook "${event}": ${sent} sent, ${queued} queued for retry, ${failed} failed`);

  // Kick off retry processor if anything was queued
  if (queued > 0) scheduleRetryProcessor();

  return { sent, failed, queued };
}

// ─── Retry Processor ─────────────────────────────────────────────────────

let _retryTimer: ReturnType<typeof setTimeout> | null = null;

function scheduleRetryProcessor() {
  if (_retryTimer) return; // Already scheduled

  const queue = getRetryQueue();
  if (queue.length === 0) return;

  // Find the soonest retry
  const soonest = Math.min(...queue.map(r => r.nextRetryAt));
  const delay = Math.max(soonest - Date.now(), 500); // at least 500ms

  _retryTimer = setTimeout(async () => {
    _retryTimer = null;
    await processRetryQueue();
  }, delay);

  console.log(`[CULTIVE] Retry processor scheduled in ${delay}ms (${queue.length} pending)`);
}

async function processRetryQueue() {
  const queue = getRetryQueue();
  const now = Date.now();
  const ready = queue.filter(r => r.nextRetryAt <= now);
  const notReady = queue.filter(r => r.nextRetryAt > now);

  if (ready.length === 0) {
    if (notReady.length > 0) scheduleRetryProcessor();
    return;
  }

  console.log(`[CULTIVE] Processing ${ready.length} webhook retries...`);

  const stillPending: RetryEntry[] = [];

  await Promise.allSettled(
    ready.map(async (entry) => {
      try {
        const start = Date.now();
        const success = await deliverWebhook(
          { id: entry.hookId, url: entry.hookUrl, secret: entry.hookSecret },
          entry.payload,
        );
        const responseTime = Date.now() - start;

        console.log(`[CULTIVE] Retry succeeded for ${entry.hookUrl} on attempt ${entry.attempt}`);

        // Update hook's state
        const allHooks = getWebhooks();
        const h = allHooks.find(wh => wh.id === entry.hookId);
        if (h) {
          h.lastTriggered = new Date().toISOString();
          h.failCount = Math.max(0, h.failCount - 1);
          saveWebhooks(allHooks);
        }

        // Record delivery
        recordDelivery({
          id: `log_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
          webhookId: entry.hookId,
          webhookLabel: h?.label,
          webhookUrl: entry.hookUrl,
          event: entry.payload.event,
          timestamp: new Date().toISOString(),
          status: 'success',
          responseTime,
          attempt: entry.attempt,
          deliveryId: entry.payload.deliveryId,
        });
      } catch (err) {
        console.warn(`[CULTIVE] Retry attempt ${entry.attempt}/${entry.maxAttempts} failed for ${entry.hookUrl}:`, err);

        if (entry.attempt < entry.maxAttempts) {
          // Re-queue with incremented attempt
          const nextAttempt = entry.attempt + 1;
          const delay = BASE_DELAY_MS * Math.pow(2, nextAttempt - 1);
          stillPending.push({
            ...entry,
            attempt: nextAttempt,
            payload: { ...entry.payload, attempt: nextAttempt },
            nextRetryAt: Date.now() + delay,
          });
          console.log(`[CULTIVE] Re-queued ${entry.hookUrl} — attempt ${nextAttempt}/${entry.maxAttempts} in ${delay}ms`);
        } else {
          console.warn(`[CULTIVE] Webhook ${entry.hookId} exhausted all ${entry.maxAttempts} retry attempts for delivery ${entry.payload.deliveryId}`);
          // Increment fail count on hook
          const allHooks = getWebhooks();
          const h = allHooks.find(wh => wh.id === entry.hookId);
          if (h) {
            h.failCount += 1;
            if (h.failCount >= 10) {
              h.active = false;
              console.warn(`[CULTIVE] Webhook ${entry.hookId} auto-disabled after ${h.failCount} failures`);
            }
            saveWebhooks(allHooks);
          }

          // Record delivery
          recordDelivery({
            id: `log_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
            webhookId: entry.hookId,
            webhookLabel: h?.label,
            webhookUrl: entry.hookUrl,
            event: entry.payload.event,
            timestamp: new Date().toISOString(),
            status: 'failed',
            responseTime: 0,
            attempt: entry.attempt,
            error: err instanceof Error ? err.message : String(err),
            deliveryId: entry.payload.deliveryId,
          });
        }
      }
    })
  );

  // Save remaining queue
  saveRetryQueue([...notReady, ...stillPending]);

  // Continue processing if items remain
  if (notReady.length + stillPending.length > 0) {
    scheduleRetryProcessor();
  }
}

// Boot retry processor on module load (picks up any pending retries from previous session)
if (typeof window !== 'undefined') {
  setTimeout(() => scheduleRetryProcessor(), 3000);
}

// ─── Webhook Event Descriptions (for UI) ─────────────────────────────────

export const WEBHOOK_EVENT_INFO: Record<WebhookEvent, { label: string; description: string }> = {
  'submission.created': {
    label: 'Submission Created',
    description: 'Fires when a new community submission is created via /contribute',
  },
  'submission.status_changed': {
    label: 'Status Changed',
    description: 'Fires when a submission transitions between pipeline stages',
  },
  'submission.published': {
    label: 'Submission Published',
    description: 'Fires when a submission is published and goes live on the frontend',
  },
  'submission.rejected': {
    label: 'Submission Rejected',
    description: 'Fires when a submission is rejected by an admin',
  },
  'content.created': {
    label: 'Content Created',
    description: 'Fires when a new CMS content item (event/venue/recap) is created',
  },
  'content.updated': {
    label: 'Content Updated',
    description: 'Fires when a CMS content item is updated',
  },
  'content.deleted': {
    label: 'Content Deleted',
    description: 'Fires when a CMS content item is deleted',
  },
  'weekly_picks.updated': {
    label: 'Weekly Picks Updated',
    description: 'Fires when the curated weekly picks are saved',
  },
  'bulk_import.completed': {
    label: 'Bulk Import Completed',
    description: 'Fires when a bulk event import (RA/LSA/Apify) finishes',
  },
};