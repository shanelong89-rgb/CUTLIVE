import { NeutralThemeProvider } from './context/NeutralThemeContext';
import { Toaster } from 'sonner';
import { useEffect } from 'react';
import { RouterProvider } from 'react-router';
import { router } from './routes';
// Initialize i18n before any components render
import './i18n';
import { ModeProvider } from './context/ModeContext';
import { DataProvider } from './context/DataContext';
import { TimePeriodProvider } from './context/TimePeriodContext';
import { OnboardingProvider, useOnboarding } from './context/OnboardingContext';
import { AuthProvider } from './context/AuthContext';
import { CollectionsProvider } from './context/CollectionsContext';
import { NotificationsProvider } from './context/NotificationsContext';
import { EventStatsProvider } from './context/EventStatsContext';
import { WelcomeOverlay } from './components/WelcomeOverlay';

function AppInner() {
  const { showWelcome, dismissWelcome } = useOnboarding();

  useEffect(() => {
    document.title = 'CULTIVE';
    
    // Set favicon to a "C" letter on white background
    const canvas = document.createElement('canvas');
    canvas.width = 64;
    canvas.height = 64;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      // White background
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, 64, 64);
      // Black "C" letter
      ctx.fillStyle = '#000000';
      ctx.font = '700 48px "Helvetica Neue", Arial, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('C', 32, 34);
      // Apply as favicon
      const link = document.querySelector("link[rel*='icon']") as HTMLLinkElement || document.createElement('link');
      link.type = 'image/png';
      link.rel = 'icon';
      link.href = canvas.toDataURL('image/png');
      document.head.appendChild(link);
    }
  }, []);

  return (
    <>
      {showWelcome && <WelcomeOverlay onComplete={dismissWelcome} />}
      <RouterProvider router={router} />
    </>
  );
}

export default function App() {
  return (
    <NeutralThemeProvider>
    <ModeProvider>
      <DataProvider>
        <TimePeriodProvider>
          <AuthProvider>
            <CollectionsProvider>
              <NotificationsProvider>
                <EventStatsProvider>
                <OnboardingProvider>
                  <AppInner />
                  <Toaster position="bottom-center" duration={2000} toastOptions={{ style: { fontSize: '13px', padding: '10px 16px' } }} />
                </OnboardingProvider>
                </EventStatsProvider>
              </NotificationsProvider>
            </CollectionsProvider>
          </AuthProvider>
        </TimePeriodProvider>
      </DataProvider>
    </ModeProvider>
    </NeutralThemeProvider>
  );
}