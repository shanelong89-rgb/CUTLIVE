// ─── Media type detection helpers ───

const VIDEO_EXTENSIONS = ['.mp4', '.mov', '.webm', '.m4v', '.avi', '.mkv', '.ogv'];

/**
 * Detect if a URL points to a video file based on extension or known patterns.
 */
export function isVideoUrl(url: string): boolean {
  if (!url) return false;
  // Strip query params and hash for extension check
  const clean = url.split('?')[0].split('#')[0].toLowerCase();
  if (VIDEO_EXTENSIONS.some(ext => clean.endsWith(ext))) return true;
  // Supabase storage sometimes uses content-type in path
  if (clean.includes('/video/') || clean.includes('video%2f')) return true;
  return false;
}

/**
 * Accepted file types for the media upload input.
 */
export const MEDIA_ACCEPT = 'image/jpeg,image/png,image/gif,image/webp,image/heic,video/mp4,video/quicktime,video/webm,video/x-m4v,.mp4,.mov,.webm,.m4v';
