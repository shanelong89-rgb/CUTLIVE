/**
 * Bilingual data layer helper for CULTIVE
 *
 * Dynamic content (events, venues) stored in Supabase can have
 * bilingual fields: title / title_zh, description / description_zh, etc.
 * This utility picks the right field based on the current i18n language.
 *
 * Usage:
 *   const title = useBilingual(event, 'title');
 *   const desc  = useBilingual(event, 'description');
 *   const name  = useBilingual(venue, 'name');
 */
import { useTranslation } from 'react-i18next';
import { useMemo } from 'react';

/**
 * Hook: resolve a bilingual field from a data object.
 * If current language is zh-Hant and `field_zh` exists, return it.
 * Otherwise fall back to the English `field`.
 */
export function useBilingual<T extends Record<string, any>>(
  item: T | null | undefined,
  field: string
): string {
  const { i18n } = useTranslation();
  return useMemo(() => {
    if (!item) return '';
    return getBilingualField(item, field, i18n.language);
  }, [item, field, i18n.language]);
}

/**
 * Hook: resolve multiple bilingual fields at once.
 * Returns an object with each requested field resolved.
 *
 * Usage:
 *   const { title, description } = useBilingualFields(event, ['title', 'description']);
 */
export function useBilingualFields<T extends Record<string, any>>(
  item: T | null | undefined,
  fields: string[]
): Record<string, string> {
  const { i18n } = useTranslation();
  return useMemo(() => {
    if (!item) return Object.fromEntries(fields.map(f => [f, '']));
    const result: Record<string, string> = {};
    for (const field of fields) {
      result[field] = getBilingualField(item, field, i18n.language);
    }
    return result;
  }, [item, fields, i18n.language]);
}

/**
 * Pure function: resolve a bilingual field from a data object.
 * Use this in non-hook contexts (e.g. utilities, loops).
 *
 * @param item  - The data object (event, venue, etc.)
 * @param field - The base field name (e.g. 'title', 'description', 'name')
 * @param lang  - Current language code ('en' or 'zh-Hant')
 */
export function getBilingualField(
  item: Record<string, any>,
  field: string,
  lang: string
): string {
  if (lang === 'zh-Hant' || lang.startsWith('zh')) {
    // Try zh-specific field first: title_zh, description_zh, name_zh, etc.
    const zhKey = `${field}_zh`;
    const zhValue = item[zhKey];
    if (zhValue && typeof zhValue === 'string' && zhValue.trim()) {
      return zhValue;
    }
    // Also try nameZh pattern (existing Venue field convention)
    const camelZhKey = `${field}Zh`;
    const camelValue = item[camelZhKey];
    if (camelValue && typeof camelValue === 'string' && camelValue.trim()) {
      return camelValue;
    }
  }
  // Fall back to English field
  const value = item[field];
  return typeof value === 'string' ? value : '';
}

/**
 * Format price for bilingual display.
 * "Free" → translated, HK$ amounts stay as-is.
 */
export function useBilingualPrice(price: string | undefined): string {
  const { i18n, t } = useTranslation();
  return useMemo(() => {
    if (!price || price === 'Free' || /^free$/i.test(price)) {
      return t('common.free');
    }
    return price;
  }, [price, i18n.language, t]);
}
