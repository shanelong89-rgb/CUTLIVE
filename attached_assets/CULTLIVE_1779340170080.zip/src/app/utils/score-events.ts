import { TASTE_TO_EVENT_MAP, type TasteProfile } from '../components/OnboardingQuiz';
import type { CulturalEvent } from '../data/mock-data';

// ═══════════════════════════════════════════════════════════════════
// Shared event scoring engine
// Used by useWeeklyPicks (3 picks) and WhatsOnPage (full list sort)
// ═══════════════════════════════════════════════════════════════════

export interface ScoredEvent {
  event: CulturalEvent;
  score: number;
}

/**
 * Score events against user taste preferences.
 * Returns scored array sorted by score descending.
 */
export function scoreEventsRaw(
  pool: CulturalEvent[],
  quiz: TasteProfile | null,
  savedIds: string[],
  allEvents: CulturalEvent[],
): ScoredEvent[] {
  if (pool.length === 0) return [];

  // Build preference signals from quiz
  const prefCategories = new Set<string>();
  const prefKeywords: string[] = [];
  const prefVibes = new Set<string>();

  if (quiz) {
    for (const sel of quiz.selections) {
      const mapping = TASTE_TO_EVENT_MAP[sel];
      if (mapping) {
        mapping.categories.forEach(c => prefCategories.add(c));
        prefKeywords.push(...mapping.keywords);
        mapping.vibes.forEach(v => prefVibes.add(v));
      }
    }
  }

  // Build preference signals from saved events
  if (savedIds.length > 0) {
    const savedEvents = savedIds
      .map(id => allEvents.find(e => e.id === id))
      .filter(Boolean) as CulturalEvent[];
    for (const ev of savedEvents) {
      if (ev.category) prefCategories.add(ev.category);
      if (ev.vibes) ev.vibes.forEach(v => prefVibes.add(v));
    }
  }

  const hasPrefs = prefCategories.size > 0 || prefKeywords.length > 0 || prefVibes.size > 0;

  // Score each event
  return pool.map(event => {
    let score = 0;

    if (hasPrefs) {
      // Category match
      if (prefCategories.has(event.category)) score += 30;

      // Keyword match in title + description
      const text = `${event.title} ${event.description || ''}`.toLowerCase();
      for (const kw of prefKeywords) {
        if (text.includes(kw.toLowerCase())) {
          score += 10;
          break;
        }
      }

      // Vibe match
      if (event.vibes) {
        for (const v of event.vibes) {
          if (prefVibes.has(v)) { score += 8; break; }
        }
      }
    }

    // Featured bonus
    if (event.featured) score += 5;

    // Editorial hook bonus
    if (event.editorialHook) score += 7;

    // Community submission bonus
    if (event.id.startsWith('sub_')) score += 3;

    return { event, score };
  }).sort((a, b) => b.score - a.score);
}

/**
 * Score and return diverse top-N picks (used by useWeeklyPicks).
 */
export function scoreEvents(
  pool: CulturalEvent[],
  quiz: TasteProfile | null,
  savedIds: string[],
  allEvents: CulturalEvent[],
): CulturalEvent[] {
  const scored = scoreEventsRaw(pool, quiz, savedIds, allEvents);

  // Diverse selection: try not to repeat categories
  const result: CulturalEvent[] = [];
  const usedCategories = new Set<string>();

  // First pass: best from each category
  for (const { event } of scored) {
    if (result.length >= 3) break;
    if (!usedCategories.has(event.category)) {
      result.push(event);
      usedCategories.add(event.category);
    }
  }

  // Fill remaining from top scores
  for (const { event } of scored) {
    if (result.length >= 3) break;
    if (!result.includes(event)) {
      result.push(event);
    }
  }

  return result;
}
