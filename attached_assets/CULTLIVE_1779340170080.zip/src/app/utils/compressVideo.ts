/**
 * Client-side video compressor using real-time Canvas playback + MediaRecorder.
 *
 * How it works:
 *  1. Loads the source video into a hidden &lt;video&gt; element
 *  2. Plays it at 1× speed (ensuring every frame is decoded properly)
 *  3. Draws each frame onto a downscaled &lt;canvas&gt; via requestAnimationFrame
 *  4. MediaRecorder captures the canvas stream at a controlled bitrate
 *  5. Returns the compressed file
 *
 * Compression time ≈ video duration (a 1-min clip takes ~1 min).
 * Quality is excellent because the browser decodes every frame natively —
 * similar to what VideoSmaller.com achieves server-side with FFmpeg,
 * minus the server overhead.
 */

export interface CompressOptions {
  /** Target video bitrate in bits/sec.  Default 4_000_000 (4 Mbps). */
  targetBitrate?: number;
  /** Max output width in px. Default 1280. */
  maxWidth?: number;
  /** Max output height in px. Default 720. */
  maxHeight?: number;
  /** Output frame rate for captureStream. Default 30. */
  fps?: number;
  /** Progress callback: 0 → 1. */
  onProgress?: (pct: number) => void;
}

export async function compressVideo(
  file: File,
  opts: CompressOptions = {},
): Promise<File> {
  const {
    targetBitrate = 4_000_000,
    maxWidth = 1280,
    maxHeight = 720,
    fps = 30,
    onProgress,
  } = opts;

  return new Promise<File>((resolve, reject) => {
    const video = document.createElement('video');
    video.muted = true;
    video.playsInline = true;
    video.preload = 'auto';

    const objUrl = URL.createObjectURL(file);
    video.src = objUrl;
    const cleanup = () => {
      cancelAnimationFrame(rafId);
      URL.revokeObjectURL(objUrl);
    };

    let rafId = 0;

    video.onerror = () => {
      cleanup();
      reject(new Error('Could not load video for compression'));
    };

    video.onloadedmetadata = () => {
      /* ── Compute output dimensions ── */
      let w = video.videoWidth;
      let h = video.videoHeight;
      if (w > maxWidth) {
        h = Math.round(h * (maxWidth / w));
        w = maxWidth;
      }
      if (h > maxHeight) {
        w = Math.round(w * (maxHeight / h));
        h = maxHeight;
      }
      // Ensure even dimensions (required by most codecs)
      w = w % 2 === 0 ? w : w - 1;
      h = h % 2 === 0 ? h : h - 1;

      const canvas = document.createElement('canvas');
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext('2d')!;

      /* ── MediaRecorder setup ── */
      const stream = canvas.captureStream(fps);
      const codecs = [
        'video/webm;codecs=vp9',
        'video/webm;codecs=vp8',
        'video/webm',
      ];
      const mimeType =
        codecs.find((c) => MediaRecorder.isTypeSupported(c)) || 'video/webm';

      const recorder = new MediaRecorder(stream, {
        mimeType,
        videoBitsPerSecond: targetBitrate,
      });

      const chunks: Blob[] = [];
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunks.push(e.data);
      };

      recorder.onerror = () => {
        cleanup();
        reject(new Error('MediaRecorder error during compression'));
      };

      recorder.onstop = () => {
        cleanup();
        const cleanMime = mimeType.split(';')[0]; // "video/webm"
        const ext = cleanMime.includes('webm') ? 'webm' : 'mp4';
        const blob = new Blob(chunks, { type: cleanMime });
        const out = new File(
          [blob],
          file.name.replace(/\.[^.]+$/, `.${ext}`),
          { type: cleanMime },
        );
        onProgress?.(1);
        resolve(out);
      };

      /* ── Draw loop: runs at screen refresh rate while video plays ── */
      const duration = video.duration;

      const drawLoop = () => {
        if (video.ended || video.paused) return;
        ctx.drawImage(video, 0, 0, w, h);
        if (duration && onProgress) {
          onProgress(Math.min(video.currentTime / duration, 0.99));
        }
        rafId = requestAnimationFrame(drawLoop);
      };

      /* ── Events ── */
      video.onplay = () => {
        drawLoop();
      };

      video.onended = () => {
        // Draw the very last frame
        ctx.drawImage(video, 0, 0, w, h);
        cancelAnimationFrame(rafId);
        // Give MediaRecorder a moment to flush
        setTimeout(() => recorder.stop(), 200);
      };

      /* ── Go: start recording, then play at 1× ── */
      recorder.start(500); // flush data every 500ms
      video.playbackRate = 1;
      video.currentTime = 0;
      video.play().catch((err) => {
        cleanup();
        reject(
          new Error(
            `Could not play video for compression: ${err.message}`,
          ),
        );
      });
    };
  });
}

/* ─────────────────────── helpers ─────────────────────── */

/** Returns true when the file is a video larger than `thresholdMB`. */
export function shouldCompress(file: File, thresholdMB = 10): boolean {
  return (
    file.type.startsWith('video/') && file.size > thresholdMB * 1024 * 1024
  );
}
