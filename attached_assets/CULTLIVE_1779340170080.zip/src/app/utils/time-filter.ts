import type { TimePeriod } from '../context/TimePeriodContext';
import type { CulturalEvent, Mode } from '../data/mock-data';
import { parseEventDate, getHKToday } from './date-helpers';
import i18n from '../i18n';

export function filterEventsByTimePeriod(
  events: CulturalEvent[],
  period: TimePeriod,
  mode?: Mode | null
): CulturalEvent[] {
  let filtered = mode
    ? events.filter((e) => (e.modeTags || (e as any).modes || []).includes(mode))
    : events;

  if (period === 'all') return filtered;

  const today = getHKToday();

  return filtered.filter((event) => {
    const eventStart = parseEventDate(event.date);
    if (!eventStart) return true; // include events with unparseable dates
    const eventEnd = event.endDate ? (parseEventDate(event.endDate) || eventStart) : eventStart;

    if (period === 'today') {
      return eventStart <= today && eventEnd >= today;
    }

    if (period === 'week') {
      const dayOfWeek = today.getDay();
      const monday = new Date(today);
      monday.setDate(today.getDate() - (dayOfWeek === 0 ? 6 : dayOfWeek - 1));
      const sunday = new Date(monday);
      sunday.setDate(monday.getDate() + 6);
      return eventStart <= sunday && eventEnd >= monday;
    }

    if (period === 'month') {
      const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
      const monthEnd = new Date(today.getFullYear(), today.getMonth() + 1, 0);
      return eventStart <= monthEnd && eventEnd >= monthStart;
    }

    return true;
  });
}

/**
 * Given a set of venues and events, return venue IDs that have at least
 * one event in the given time period.
 */
export function getVenueIdsWithEvents(
  events: CulturalEvent[],
  period: TimePeriod,
  mode?: Mode | null
): Set<string> {
  const filtered = filterEventsByTimePeriod(events, period, mode);
  return new Set(filtered.map((e) => e.venueId));
}

/**
 * Get mode-specific tab labels, using i18n for bilingual support.
 * Each mode has creative label variations translated via timePeriod.[mode].[key].
 */
export function getTimePeriodTabs(mode: Mode | null): { key: TimePeriod; label: string }[] {
  const modeKey = mode || 'default';
  return [
    { key: 'all', label: i18n.t(`timePeriod.${modeKey}.all`) },
    { key: 'today', label: i18n.t(`timePeriod.${modeKey}.today`) },
    { key: 'week', label: i18n.t(`timePeriod.${modeKey}.week`) },
    { key: 'month', label: i18n.t(`timePeriod.${modeKey}.month`) },
  ];
}
