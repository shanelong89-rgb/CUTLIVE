/**
 * Shared helpers for event display across the app
 */

/**
 * Determine the correct link for an event.
 * - Contributor submissions (sub_*) → /event/:id
 * - RA-imported events (ra_*)        → /event/:id
 * - LSA-scraped events (lsa_*)       → /event/:id
 * - Mock/seeded events with a venueId → /venue/:venueId
 */
export function getEventLink(event: { id?: string; venueId?: string }): string {
  if (!event.id) return `/venue/${event.venueId || ''}`;
  // Any event with its own ID that isn't a plain seeded venue-event gets a detail page
  if (event.id.startsWith('sub_') || event.id.startsWith('ra_') || event.id.startsWith('lsa_') || event.id.startsWith('apify_')) {
    return `/event/${event.id}`;
  }
  return `/venue/${event.venueId || ''}`;
}

/** Format price for display — normalizes raw values like "150" → "HK$150" */
export function formatPrice(price: string | undefined): string {
  if (!price) return 'Free';
  const trimmed = price.trim();
  if (!trimmed) return 'Free';
  if (/^free$/i.test(trimmed)) return 'Free';
  if (/^[HK$£€¥]/.test(trimmed) || trimmed.startsWith('HK$')) return trimmed;
  const numMatch = trimmed.match(/^(\d[\d,]*(?:\.\d{1,2})?)(%)?$/);
  if (numMatch) return `HK$${numMatch[1]}`;
  return trimmed;
}

/** Get the detail link for a venue (submissions go to /event/:id, real venues to /venue/:id) */
export function getVenueLink(venue: { id?: string }): string {
  if (venue.id?.startsWith('sub_') || venue.id?.startsWith('ra_') || venue.id?.startsWith('lsa_') || venue.id?.startsWith('apify_')) return `/event/${venue.id}`;
  return `/venue/${venue.id}`;
}