/**
 * coord-parser.ts — Parse GPS coordinates in various formats
 * Used by ContributePage and admin EventManager for manual coordinate entry.
 *
 * Supported formats:
 *   DMS:     22°19'41.5"N 114°09'36.4"E
 *   Decimal: 22.3282, 114.1601
 *   Mixed:   22.3282 114.1601
 *   Google Maps style: 22.3282,114.1601
 */

export interface ParsedCoords {
  lat: number;
  lng: number;
}

/** Parse DMS component like 22°19'41.5"N → decimal degrees */
function parseDMS(dms: string): number | null {
  const normalized = dms
    .replace(/[°º]/g, '°')
    .replace(/[′'ʼ]/g, "'")
    .replace(/[″"ʺ]/g, '"')
    .trim();

  // Match: degrees°minutes'seconds"direction
  const match = normalized.match(
    /^(-?\d+(?:\.\d+)?)\s*°\s*(\d+(?:\.\d+)?)\s*['']\s*(\d+(?:\.\d+)?)\s*[""]?\s*([NSEWnsew])?$/
  );
  if (match) {
    const deg = parseFloat(match[1]);
    const min = parseFloat(match[2]);
    const sec = parseFloat(match[3]);
    const dir = (match[4] || '').toUpperCase();
    let dd = deg + min / 60 + sec / 3600;
    if (dir === 'S' || dir === 'W') dd = -dd;
    return dd;
  }

  // Match degrees°minutes' (no seconds)
  const match2 = normalized.match(
    /^(-?\d+(?:\.\d+)?)\s*°\s*(\d+(?:\.\d+)?)\s*['']\s*([NSEWnsew])?$/
  );
  if (match2) {
    const deg = parseFloat(match2[1]);
    const min = parseFloat(match2[2]);
    const dir = (match2[3] || '').toUpperCase();
    let dd = deg + min / 60;
    if (dir === 'S' || dir === 'W') dd = -dd;
    return dd;
  }

  return null;
}

/** Check if coordinates are roughly within Hong Kong area (generous bounds) */
export function isValidHKCoords(lat: number, lng: number): boolean {
  return lat >= 22.0 && lat <= 22.6 && lng >= 113.7 && lng <= 114.5;
}

/** Try to parse coordinate input in various formats */
export function parseCoordinates(input: string): ParsedCoords | null {
  const trimmed = input.trim();
  if (!trimmed) return null;

  // 1. Try DMS format: 22°19'41.5"N 114°09'36.4"E
  const dmsPattern = /(-?\d+(?:\.\d+)?\s*[°º]\s*\d+(?:\.\d+)?\s*[''ʼ′]\s*\d+(?:\.\d+)?\s*["ʺ″]?\s*[NSEWnsew]?)/g;
  const dmsMatches = trimmed.match(dmsPattern);
  if (dmsMatches && dmsMatches.length >= 2) {
    const a = parseDMS(dmsMatches[0]);
    const b = parseDMS(dmsMatches[1]);
    if (a !== null && b !== null) {
      const aDir = dmsMatches[0].match(/[NSEWnsew]\s*$/)?.[0]?.trim().toUpperCase();
      const bDir = dmsMatches[1].match(/[NSEWnsew]\s*$/)?.[0]?.trim().toUpperCase();
      let lat: number, lng: number;
      if (aDir === 'N' || aDir === 'S') {
        lat = a; lng = b;
      } else if (bDir === 'N' || bDir === 'S') {
        lat = b; lng = a;
      } else {
        lat = a; lng = b;
      }
      if (isValidHKCoords(lat, lng)) return { lat, lng };
    }
  }

  // 2. Try decimal format: "22.3282, 114.1601" or "22.3282 114.1601"
  const decimalMatch = trimmed.match(
    /^(-?\d+(?:\.\d+)?)\s*[,;\s]\s*(-?\d+(?:\.\d+)?)$/
  );
  if (decimalMatch) {
    const a = parseFloat(decimalMatch[1]);
    const b = parseFloat(decimalMatch[2]);
    if (!isNaN(a) && !isNaN(b)) {
      if (isValidHKCoords(a, b)) return { lat: a, lng: b };
      if (isValidHKCoords(b, a)) return { lat: b, lng: a };
      if (Math.abs(a) <= 90 && Math.abs(b) <= 180) return { lat: a, lng: b };
      if (Math.abs(b) <= 90 && Math.abs(a) <= 180) return { lat: b, lng: a };
    }
  }

  // 3. DMS pair with comma separator
  if (trimmed.includes('°')) {
    const parts = trimmed.split(/[,;]\s*/);
    if (parts.length === 2) {
      const a = parseDMS(parts[0].trim());
      const b = parseDMS(parts[1].trim());
      if (a !== null && b !== null) {
        if (isValidHKCoords(a, b)) return { lat: a, lng: b };
        if (isValidHKCoords(b, a)) return { lat: b, lng: a };
        if (Math.abs(a) <= 90 && Math.abs(b) <= 180) return { lat: a, lng: b };
      }
    }
  }

  return null;
}

/** Rough reverse-district lookup from coordinates */
export function reverseDistrictFromCoords(lat: number, lng: number): string | undefined {
  const districts: { name: string; lat: number; lng: number; radius: number }[] = [
    { name: 'Central', lat: 22.2816, lng: 114.1585, radius: 0.015 },
    { name: 'Wan Chai', lat: 22.2783, lng: 114.1747, radius: 0.012 },
    { name: 'Causeway Bay', lat: 22.2801, lng: 114.1876, radius: 0.012 },
    { name: 'Sheung Wan', lat: 22.2866, lng: 114.1504, radius: 0.012 },
    { name: 'Tsim Sha Tsui', lat: 22.2988, lng: 114.1722, radius: 0.015 },
    { name: 'Mong Kok', lat: 22.3193, lng: 114.1694, radius: 0.012 },
    { name: 'Sham Shui Po', lat: 22.3308, lng: 114.1591, radius: 0.015 },
    { name: 'West Kowloon', lat: 22.3048, lng: 114.1611, radius: 0.015 },
    { name: 'Wong Chuk Hang', lat: 22.2484, lng: 114.1681, radius: 0.012 },
    { name: 'Kennedy Town', lat: 22.2817, lng: 114.1284, radius: 0.012 },
    { name: 'Sai Ying Pun', lat: 22.2862, lng: 114.1425, radius: 0.010 },
    { name: 'Stanley', lat: 22.2180, lng: 114.2114, radius: 0.015 },
    { name: 'Shau Kei Wan', lat: 22.2793, lng: 114.2282, radius: 0.015 },
    { name: 'Sha Tin', lat: 22.3815, lng: 114.1895, radius: 0.025 },
    { name: 'Tai Po', lat: 22.4507, lng: 114.1687, radius: 0.025 },
    { name: 'Sai Kung', lat: 22.3813, lng: 114.2715, radius: 0.030 },
    { name: 'Lantau', lat: 22.2665, lng: 113.9432, radius: 0.060 },
  ];

  let closest: { name: string; dist: number } | null = null;
  for (const d of districts) {
    const dist = Math.sqrt((lat - d.lat) ** 2 + (lng - d.lng) ** 2);
    if (dist <= d.radius && (!closest || dist < closest.dist)) {
      closest = { name: d.name, dist };
    }
  }
  return closest?.name;
}
