/**
 * Parse an event date string robustly.
 * Handles ISO dates ("2026-03-14"), range strings ("2026-03-14 – 2026-03-16"),
 * and other formats. Returns the start Date or null if unparseable.
 */
export function parseEventDate(dateStr: string | undefined | null): Date | null {
  if (!dateStr || !dateStr.trim()) return null;

  // If it's a range like "2026-03-14 – 2026-03-16", extract the start date
  let cleaned = dateStr.trim();
  if (cleaned.includes('–') || cleaned.includes('—')) {
    cleaned = cleaned.split(/\s*[–—]\s*/)[0].trim();
  }

  // Try parsing
  const d = new Date(cleaned + (cleaned.length === 10 ? 'T00:00:00' : ''));
  if (!isNaN(d.getTime())) return d;

  // Fallback: try the raw string
  const fallback = new Date(dateStr);
  return isNaN(fallback.getTime()) ? null : fallback;
}

/**
 * Get the current date in Hong Kong timezone (UTC+8), returned as a
 * midnight-local Date object so it can be compared with parseEventDate results.
 */
export function getHKToday(): Date {
  // Get current time in HK by formatting with the Asia/Hong_Kong timezone
  const hkStr = new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Hong_Kong' }); // 'en-CA' gives YYYY-MM-DD
  return new Date(hkStr + 'T00:00:00');
}

/**
 * Dynamically compute event status based on the current date in HK timezone.
 * - past:     event date (and endDate if present) is before today
 * - ongoing:  today falls within the event date range, OR event is today
 * - upcoming: event date is after today
 */
export function computeEventStatus(
  dateStr: string | undefined,
  endDateStr?: string | undefined
): 'upcoming' | 'ongoing' | 'past' {
  if (!dateStr) return 'upcoming'; // no date → assume upcoming
  const today = getHKToday();
  const eventStart = parseEventDate(dateStr);
  if (!eventStart) return 'upcoming';

  const eventEnd = endDateStr ? (parseEventDate(endDateStr) || eventStart) : eventStart;

  // Compare dates (midnight to midnight)
  const startDay = new Date(eventStart.getFullYear(), eventStart.getMonth(), eventStart.getDate());
  const endDay = new Date(eventEnd.getFullYear(), eventEnd.getMonth(), eventEnd.getDate());
  const todayDay = new Date(today.getFullYear(), today.getMonth(), today.getDate());

  if (endDay < todayDay) return 'past';
  if (startDay <= todayDay && endDay >= todayDay) return 'ongoing';
  return 'upcoming';
}