import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import en from './locales/en.json';
import zhHant from './locales/zh-Hant.json';

// ═══════════════════════════════════════════════════════════════════
// CULTIVE i18n Configuration
// Hybrid approach:
//   - react-i18next for static UI strings (nav, buttons, labels)
//   - Bilingual Supabase fields (title_zh, description_zh) for
//     dynamic content (events, venues) — handled at data layer
// ═══════════════════════════════════════════════════════════════════

const STORAGE_KEY = 'cultive:lang';

// Read persisted language preference
function getInitialLanguage(): string {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved === 'en' || saved === 'zh-Hant') return saved;
  } catch {}
  return 'en';
}

i18n
  .use(initReactI18next)
  .init({
    resources: {
      en: { translation: en },
      'zh-Hant': { translation: zhHant },
    },
    lng: getInitialLanguage(),
    fallbackLng: 'en',
    interpolation: {
      escapeValue: false, // React already handles XSS
    },
    react: {
      useSuspense: false,
    },
  });

// Persist language changes
i18n.on('languageChanged', (lng) => {
  try {
    localStorage.setItem(STORAGE_KEY, lng);
    // Update <html lang> attribute
    document.documentElement.lang = lng === 'zh-Hant' ? 'zh-Hant' : 'en';
  } catch {}
});

// Set initial html lang
try {
  document.documentElement.lang = getInitialLanguage() === 'zh-Hant' ? 'zh-Hant' : 'en';
} catch {}

export default i18n;
