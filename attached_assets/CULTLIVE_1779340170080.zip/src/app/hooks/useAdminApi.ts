import { useState, useCallback, useEffect } from 'react';
import { projectId, publicAnonKey } from '../config/supabase';
import { supabase } from '../lib/supabase';

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-d507b98c/cms`;

// ─── Auth ───
export function useAdminAuth() {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [accessToken, setAccessToken] = useState<string | null>(null);

  useEffect(() => {
    // Check existing session
    supabase.auth.getSession().then(({ data }) => {
      if (data?.session) {
        setUser(data.session.user);
        setAccessToken(data.session.access_token);
      }
      setLoading(false);
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user || null);
      setAccessToken(session?.access_token || null);
    });

    return () => subscription.unsubscribe();
  }, []);

  const signIn = useCallback(async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw error;
    setUser(data.session?.user || null);
    setAccessToken(data.session?.access_token || null);
    return data;
  }, []);

  const signUp = useCallback(async (email: string, password: string, name: string) => {
    const res = await fetch(`${API_BASE}/admin/signup`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${publicAnonKey}`,
      },
      body: JSON.stringify({ email, password, name }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Signup failed');
    return data;
  }, []);

  const signOut = useCallback(async () => {
    await supabase.auth.signOut();
    setUser(null);
    setAccessToken(null);
  }, []);

  const checkAdminExists = useCallback(async () => {
    const res = await fetch(`${API_BASE}/admin/check`, {
      headers: { 'Authorization': `Bearer ${publicAnonKey}` },
    });
    const data = await res.json();
    return data.hasAdmin;
  }, []);

  return { user, loading, accessToken, signIn, signUp, signOut, checkAdminExists };
}

// ─── API Calls ───
export function authHeaders(accessToken: string | null) {
  return {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${publicAnonKey}`,
    ...(accessToken ? { 'X-Auth-Token': accessToken } : {}),
  };
}

export async function fetchSubmissions(accessToken: string, status?: string) {
  const url = status ? `${API_BASE}/submissions?status=${status}` : `${API_BASE}/submissions`;
  const res = await fetch(url, { headers: authHeaders(accessToken) });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Failed to fetch submissions');
  }
  return res.json();
}

export async function updateSubmissionStatus(accessToken: string, id: string, status: string, adminNotes?: string) {
  const res = await fetch(`${API_BASE}/submissions/${id}/status`, {
    method: 'PUT',
    headers: authHeaders(accessToken),
    body: JSON.stringify({ status, adminNotes }),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Failed to update submission');
  }
  return res.json();
}

export async function updateSubmissionFields(accessToken: string, id: string, fields: Record<string, any>) {
  const res = await fetch(`${API_BASE}/submissions/${id}`, {
    method: 'PATCH',
    headers: authHeaders(accessToken),
    body: JSON.stringify(fields),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Failed to update submission');
  }
  return res.json();
}

export async function bulkAction(accessToken: string, ids: string[], action: string) {
  const res = await fetch(`${API_BASE}/submissions/bulk-action`, {
    method: 'POST',
    headers: authHeaders(accessToken),
    body: JSON.stringify({ ids, action }),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Bulk action failed');
  }
  return res.json();
}

export async function deleteSubmission(accessToken: string, id: string) {
  const res = await fetch(`${API_BASE}/submissions/${id}`, {
    method: 'DELETE',
    headers: authHeaders(accessToken),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Failed to delete');
  }
  return res.json();
}

export async function fetchContributors(accessToken: string) {
  const res = await fetch(`${API_BASE}/contributors`, {
    headers: authHeaders(accessToken),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Failed to fetch contributors');
  }
  return res.json();
}

// ─── Public API ───
export async function uploadImages(files: File[]): Promise<{ uploaded: { url: string; path: string; name: string; size: number }[]; errors: string[]; count: number }> {
  const formData = new FormData();
  files.forEach(f => formData.append('files', f));

  const res = await fetch(`${API_BASE}/upload`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${publicAnonKey}`,
      // Note: do NOT set Content-Type — browser sets it with the boundary for multipart
    },
    body: formData,
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Upload failed');
  }
  return res.json();
}

export async function createSubmission(data: any) {
  const res = await fetch(`${API_BASE}/submissions`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${publicAnonKey}`,
    },
    body: JSON.stringify(data),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Submission failed');
  }
  return res.json();
}

export async function parseSourceUrl(url: string) {
  const res = await fetch(`${API_BASE}/parse-url`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${publicAnonKey}`,
    },
    body: JSON.stringify({ url }),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Failed to parse URL');
  }
  return res.json();
}

export async function checkSubmissionStatus(id: string) {
  const res = await fetch(`${API_BASE}/submission-status/${id}`, {
    headers: { 'Authorization': `Bearer ${publicAnonKey}` },
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Failed to check status');
  }
  return res.json();
}

export async function analyzeContent(text: string, authorName?: string) {
  const res = await fetch(`${API_BASE}/analyze-content`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${publicAnonKey}`,
    },
    body: JSON.stringify({ text, authorName }),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Analysis failed');
  }
  return res.json();
}

export async function fetchPublishedSubmissions() {
  const res = await fetch(`${API_BASE}/submissions/published`, {
    headers: { 'Authorization': `Bearer ${publicAnonKey}` },
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Failed to fetch published submissions');
  }
  return res.json();
}

export async function fetchPublishedEvent(id: string) {
  const BASE = `https://${projectId}.supabase.co/functions/v1/make-server-d507b98c`;
  const headers = { 'Authorization': `Bearer ${publicAnonKey}` };

  // 1. Try the main KV events store first (covers RA-imported and seeded events)
  try {
    const kvRes = await fetch(`${BASE}/events/${encodeURIComponent(id)}`, { headers });
    if (kvRes.ok) {
      const data = await kvRes.json();
      if (data?.event) return data;
    }
  } catch { /* fall through */ }

  // 2. Fall back to CMS submission store (covers contributor submissions)
  const cmsRes = await fetch(`${BASE}/cms/event/${encodeURIComponent(id)}`, { headers });
  if (!cmsRes.ok) {
    let errorMsg = 'Event not found';
    try {
      const err = await cmsRes.json();
      errorMsg = err.error || errorMsg;
    } catch { /* not JSON */ }
    throw new Error(errorMsg);
  }
  return cmsRes.json();
}