// ═══════════════════════════════════════════════════
// useSiteImages — runtime hook for CMS image overrides
// Fetches overrides from the Template Editor's KV store,
// falls back to hardcoded defaults from site-images.ts
// ═══════════════════════════════════════════════════

import { useState, useEffect, useCallback } from 'react';
import { staticSiteImages, type SiteImageSlot } from '../data/site-images';
import { projectId, publicAnonKey } from '../config/supabase';

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-d507b98c/cms`;

// In-memory cache so multiple components don't re-fetch
let cachedOverrides: Record<string, string> | null = null;
let fetchPromise: Promise<Record<string, string>> | null = null;
// Cache version — incremented on invalidation to trigger re-renders
let cacheVersion = 0;

// Build a set of known slot IDs for filtering
const slotIds = new Set(staticSiteImages.map(s => s.id));
// Also track focal point keys (e.g. 'about-mid-focal')
const focalSuffix = '-focal';
// Build a map of default URLs so we can skip "overrides" that are identical to defaults
const defaultUrls = new Map(staticSiteImages.map(s => [s.id, s.url]));

/** Convert Supabase signed URLs to public URLs so they don't expire */
function normalizeStorageUrl(url: string): string {
  if (url.includes('/object/sign/')) {
    return url.replace('/object/sign/', '/object/public/').replace(/\?token=.*$/, '');
  }
  return url;
}

/** Extract image overrides from a raw API response object */
function extractOverrides(responseData: any, overrides: Record<string, string>) {
  if (!responseData || typeof responseData !== 'object') return;

  // Handle { items: [...] } wrapper
  const items = Array.isArray(responseData) ? responseData
    : Array.isArray(responseData.items) ? responseData.items
    : [responseData];

  for (const item of items) {
    // Try item.data first (Template Editor format), then item itself
    const sources = [item.data, item].filter(Boolean);
    for (const source of sources) {
      if (typeof source !== 'object') continue;
      for (const [key, val] of Object.entries(source)) {
        // Handle focal point data (stored as {x,y} objects or JSON strings)
        if (key.endsWith(focalSuffix)) {
          if (val && typeof val === 'object' && 'x' in (val as any)) {
            const fp = val as { x: number; y: number };
            // Skip default center (50,50) — treat as "not set"
            if (fp.x === 50 && fp.y === 50) continue;
            if (!overrides[key]) overrides[key] = JSON.stringify(val);
            continue;
          }
          // Also handle string-encoded JSON (e.g. after CMS roundtrip serialization)
          if (typeof val === 'string' && val.startsWith('{')) {
            try {
              const parsed = JSON.parse(val);
              if (parsed && typeof parsed.x === 'number' && typeof parsed.y === 'number') {
                // Skip default center (50,50) — treat as "not set"
                if (parsed.x === 50 && parsed.y === 50) continue;
                if (!overrides[key]) overrides[key] = val;
                continue;
              }
            } catch { /* not valid JSON, skip */ }
          }
          continue;
        }
        if (
          typeof val === 'string' &&
          val.length > 0 &&
          slotIds.has(key) &&
          key !== 'sectionId' && key !== 'updatedAt' && key !== 'visible'
        ) {
          const normalizedVal = normalizeStorageUrl(val);
          // Skip if identical to hardcoded default (also compare normalized)
          const defaultUrl = defaultUrls.get(key);
          if (normalizedVal === defaultUrl || normalizedVal === normalizeStorageUrl(defaultUrl || '')) continue;
          // Don't overwrite — first source (site-images store) takes priority
          if (!overrides[key]) overrides[key] = normalizedVal;
        }
      }
    }
  }
}

async function fetchOverrides(): Promise<Record<string, string>> {
  if (cachedOverrides) return cachedOverrides;
  if (fetchPromise) return fetchPromise;

  fetchPromise = (async () => {
    try {
      // Fetch from both the dedicated site-images store AND page template stores
      // Site-images store fetched FIRST — it's the canonical source for image overrides
      // Page-specific stores are secondary (they may contain stale data from removed sections)
      // NOTE: Must use /public suffix — the non-public endpoint requires X-Auth-Token
      const urls = [
        `${API_BASE}/content/template-site-images/public`,
        `${API_BASE}/content/template-home/public`,
        `${API_BASE}/content/template-about/public`,
        `${API_BASE}/content/template-modes/public`,
        `${API_BASE}/content/template-events/public`,
      ];
      const results = await Promise.allSettled(
        urls.map(url => fetch(url, {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
          },
          cache: 'no-store',
        }).then(r => r.ok ? r.json() : { items: [] }))
      );

      const overrides: Record<string, string> = {};

      for (const result of results) {
        if (result.status !== 'fulfilled') continue;
        extractOverrides(result.value, overrides);
      }

      cachedOverrides = overrides;
      return overrides;
    } catch (e) {
      console.warn('[useSiteImages] Fetch failed:', e);
      cachedOverrides = {};
      return {};
    } finally {
      fetchPromise = null;
    }
  })();

  return fetchPromise;
}

/** Invalidate cache (call after saving in Template Editor) */
export function invalidateSiteImageCache() {
  cachedOverrides = null;
  fetchPromise = null;
  cacheVersion++;
  // Dispatch a custom event so all mounted hooks re-fetch
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('site-images-invalidated'));
  }
}

/**
 * Hook: returns an `img(slotId)` function that resolves
 * CMS override URL → hardcoded default URL.
 *
 * Usage:
 *   const { img, loading } = useSiteImages();
 *   <img src={img('mode-card-night')} />
 */
export function useSiteImages() {
  const [overrides, setOverrides] = useState<Record<string, string>>(cachedOverrides || {});
  const [loading, setLoading] = useState(!cachedOverrides);

  useEffect(() => {
    let cancelled = false;

    const doFetch = () => {
      // Always fetch fresh — cache is just for deduplication within the same render cycle
      fetchOverrides().then(o => {
        if (!cancelled) {
          setOverrides(o);
          setLoading(false);
        }
      });
    };

    doFetch();

    // Listen for invalidation events (e.g., after Template Editor save)
    const onInvalidated = () => {
      fetchOverrides().then(o => {
        if (!cancelled) {
          setOverrides(o);
          setLoading(false);
        }
      });
    };
    window.addEventListener('site-images-invalidated', onInvalidated);

    return () => {
      cancelled = true;
      window.removeEventListener('site-images-invalidated', onInvalidated);
    };
  }, []);

  /** Resolve a slot id to its effective URL (override or default) */
  const img = useCallback((slotId: string): string => {
    if (overrides[slotId]) return overrides[slotId];
    const slot = staticSiteImages.find(s => s.id === slotId);
    // Normalize default URLs too (in case they contain signed URLs)
    return slot?.url ? normalizeStorageUrl(slot.url) : '';
  }, [overrides]);

  /** Check if a slot has a CMS override (not just the hardcoded default) */
  const hasOverride = useCallback((slotId: string): boolean => {
    return !!overrides[slotId];
  }, [overrides]);

  /** Get only the CMS override URL for a slot, empty string if none */
  const override = useCallback((slotId: string): string => {
    return overrides[slotId] || '';
  }, [overrides]);

  /** Get alt text for a slot */
  const alt = useCallback((slotId: string): string => {
    const slot = staticSiteImages.find(s => s.id === slotId);
    return slot?.alt ?? '';
  }, []);

  /** Get focal point CSS object-position for a slot, defaults to 'center center' */
  const focal = useCallback((slotId: string, fallback?: string): string => {
    const raw = overrides[`${slotId}-focal`];
    if (raw) {
      try {
        const fp = JSON.parse(raw);
        if (fp && typeof fp.x === 'number' && typeof fp.y === 'number') {
          return `${fp.x}% ${fp.y}%`;
        }
      } catch { /* ignore */ }
    }
    return fallback || 'center center';
  }, [overrides]);

  return { img, alt, loading, overrides, hasOverride, override, focal };
}