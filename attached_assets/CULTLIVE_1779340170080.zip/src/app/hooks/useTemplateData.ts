import { useState, useEffect, useMemo } from 'react';
import { projectId, publicAnonKey } from '../config/supabase';

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-d507b98c/cms`;

// Default values matching the template editor schema
const HERO_DEFAULTS: Record<string, any> = {
  heroType: 'video',
  videoUrl: 'https://videos.pexels.com/video-files/3129671/3129671-uhd_2560_1440_30fps.mp4',
  posterImage: '',
  headline: "Discover what's\nhappening in HK",
  subheadline: "Hong Kong's Cultural Discovery Platform",
  description: 'Explore cultural events, venues, and experiences curated for every vibe — from nightlife to family-friendly adventures.',
  ctaPrimary: 'Browse Events',
  ctaSecondary: 'Explore Map',
  overlayOpacity: 0.35,
};

const MODE_CARDS_DEFAULTS: Record<string, any> = {
  sectionTitle: 'Choose your vibe',
  sectionSubtitle: 'Five curated modes transform everything — colours, fonts, map filters and recommendations.',
  showArrows: true,
  cardHeight: 'short',
};

const FOOTER_DEFAULTS: Record<string, any> = {
  tagline: 'Discover. Connect. Experience.',
  copyrightText: '2026 CULTIVE. All rights reserved.',
  showSocials: true,
};

export interface TemplateData {
  [sectionId: string]: Record<string, any>;
  visibility: Record<string, boolean>;
  loaded: boolean;
}

const HOME_SECTION_DEFAULTS: Record<string, Record<string, any>> = {
  hero: HERO_DEFAULTS,
  'mode-cards': MODE_CARDS_DEFAULTS,
  'things-to-do': { sectionTitle: 'Things to do', maxItems: 12, showFeaturedOnly: false },
  'upcoming-events': { sectionTitle: 'Upcoming Events', maxItems: 6, layout: 'grid-3' },
  'popular-venues': { sectionTitle: 'Popular Venues', maxItems: 6 },
  'map-cta': { headline: 'Explore the map', description: '', backgroundImage: '' },
  footer: FOOTER_DEFAULTS,
};

const ABOUT_SECTION_DEFAULTS: Record<string, Record<string, any>> = {
  hero: { subtitle: 'About CULTIVE', heroTitle: 'Culture is a *verb*' },
  manifesto: {
    manifesto: 'A hyper-local cultural events platform for Hong Kong — where *how* you discover is as important as *what* you discover.',
    manifestoBody: "Hong Kong is one of the most culturally dense cities on earth. No single platform captured this energy. We believe the way you discover a late-night speakeasy should feel fundamentally different from finding a weekend family workshop — and the platform should reflect that.",
    showStats: true,
    stat1Value: '25+', stat1Label: 'Cultural Venues',
    stat2Value: '40+', stat2Label: 'Events Monthly',
    stat3Value: '9', stat3Label: 'HK Districts',
    stat4Value: '5', stat4Label: 'Discovery Modes',
  },
  'five-lenses': {
    sectionLabel: 'Five Lenses',
    sectionTitle: 'One city, five ways to see it.',
    nightTagline: 'After-dark culture, underground scenes, and late-night energy.',
    familyTagline: 'Kid-friendly workshops, outdoor adventures, and weekend fun.',
    artTagline: 'Exhibitions, gallery openings, and the creative pulse of the city.',
    foodTagline: 'Culinary experiences, night markets, and the flavours of Hong Kong.',
    lifestyleTagline: 'Run clubs, wellness, workshops, and community — the living side of culture.',
  },
  quote: { quoteText: 'The same city, the same venues — experienced through your chosen lens.' },
  'how-it-works': {
    sectionLabel: 'How It Works',
    step01Title: 'Choose Your Lens',
    step01Body: 'Pick a mode that matches your mood. The entire platform — typography, palette, layout, and content curation — transforms to match.',
    step02Title: 'Explore the Map',
    step02Body: "An interactive map highlights venues scored and filtered by your chosen mode, with custom markers and district-level discovery.",
    step03Title: 'Discover Events',
    step03Body: "Browse upcoming events filtered and ranked by your mode. See what's happening today, this week, or this month across Hong Kong.",
    step04Title: 'Experience & Share',
    step04Body: 'Visit venues, attend events, and contribute to the community through recaps, reviews, and recommendations.',
  },
  'get-involved': {
    sectionLabel: 'Get Involved',
    sectionTitle: "Let's build Hong Kong's cultural future, *together*",
    collabTitle: 'Collaboration',
    collabDesc: 'Partner with us on events, venues & cultural projects',
    collabBody: "We partner with venues, event organizers, brands, and cultural institutions across Hong Kong. Whether you're hosting an exhibition, launching a pop-up, or curating a community experience — we'd love to help you reach the right audience.",
    collabEmail: 'info@cultive.city',
    submitTitle: 'Submit a Story',
    submitDesc: 'Share a venue, event, or narrative with our community',
    submitBody: "CULTIVE is built on community-driven content. If you know a hidden gem, run a cultural space, or are organizing something extraordinary in Hong Kong, we want to hear from you.",
  },
  cta: {
    headline: 'Ready to explore?',
    description: "Discover Hong Kong's most vibrant cultural experiences.",
    ctaPrimaryLabel: 'Open Map',
    ctaSecondaryLabel: 'Events',
  },
};

const PAGE_DEFAULTS: Record<string, Record<string, Record<string, any>>> = {
  home: HOME_SECTION_DEFAULTS,
  about: ABOUT_SECTION_DEFAULTS,
};

// Module-level cache — supports multiple pages
const _caches: Record<string, { sections: Record<string, Record<string, any>>; visibility: Record<string, boolean>; ts: number }> = {};
const CACHE_TTL = 60_000; // 1 minute

/**
 * Fetches template data saved from the admin Template Editor.
 * Falls back to hardcoded defaults if nothing has been saved yet.
 */
export function useTemplateData(pageId: string = 'home'): TemplateData {
  const [sections, setSections] = useState<Record<string, Record<string, any>>>(
    _caches[pageId]?.ts && Date.now() - _caches[pageId].ts < CACHE_TTL ? _caches[pageId].sections : {}
  );
  const [visibility, setVisibility] = useState<Record<string, boolean>>(
    _caches[pageId]?.ts && Date.now() - _caches[pageId].ts < CACHE_TTL ? _caches[pageId].visibility : {}
  );
  const [loaded, setLoaded] = useState(
    _caches[pageId]?.ts && Date.now() - _caches[pageId].ts < CACHE_TTL
  );

  useEffect(() => {
    // If we have a fresh cache, skip fetch
    if (_caches[pageId]?.ts && Date.now() - _caches[pageId].ts < CACHE_TTL) {
      setSections(_caches[pageId].sections);
      setVisibility(_caches[pageId].visibility);
      setLoaded(true);
      return;
    }

    let cancelled = false;

    async function load() {
      try {
        const url = `${API_BASE}/content/template-${pageId}/public`;

        const res = await fetch(url, {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
          },
        });

        if (res.ok) {
          const data = await res.json();
          const items = data.items || [];

          if (items.length > 0) {
            const loadedSections: Record<string, Record<string, any>> = {};
            const loadedVisibility: Record<string, boolean> = {};

            items.forEach((item: any) => {
              // Support both formats: item.sectionId (preferred) or extract from id
              const sectionId = item.sectionId || item.id?.replace(`template-${pageId}-`, '');
              if (sectionId) {
                // item.data holds the actual field values
                loadedSections[sectionId] = item.data || {};
                loadedVisibility[sectionId] = item.visible !== false;
              }
            });

            if (!cancelled) {
              setSections(loadedSections);
              setVisibility(loadedVisibility);
              // Update cache
              _caches[pageId] = { sections: loadedSections, visibility: loadedVisibility, ts: Date.now() };
            }
          } else {
            // No saved template data found, using defaults
          }
        }
      } catch (err) {
        console.log('[useTemplateData] Fetch error (using defaults):', err);
      }

      if (!cancelled) setLoaded(true);
    }

    load();
    return () => { cancelled = true; };
  }, [pageId]);

  // Listen for invalidation events (e.g., after Template Editor save)
  useEffect(() => {
    const onInvalidated = () => {
      // Clear cache and re-fetch
      delete _caches[pageId];
      fetch(`${API_BASE}/content/template-${pageId}/public`, {
        headers: { 'Authorization': `Bearer ${publicAnonKey}` },
      })
        .then(r => r.ok ? r.json() : { items: [] })
        .then(data => {
          const items = data.items || [];
          const loadedSections: Record<string, Record<string, any>> = {};
          const loadedVisibility: Record<string, boolean> = {};
          items.forEach((item: any) => {
            const sectionId = item.sectionId || item.id?.replace(`template-${pageId}-`, '');
            if (sectionId) {
              loadedSections[sectionId] = item.data || {};
              loadedVisibility[sectionId] = item.visible !== false;
            }
          });
          setSections(loadedSections);
          setVisibility(loadedVisibility);
          _caches[pageId] = { sections: loadedSections, visibility: loadedVisibility, ts: Date.now() };
        })
        .catch(() => {});
    };
    window.addEventListener('template-data-invalidated', onInvalidated);
    return () => window.removeEventListener('template-data-invalidated', onInvalidated);
  }, [pageId]);

  // Build resolved result with saved values falling back to defaults
  const result = useMemo<TemplateData>(() => {
    const pageDefaults = PAGE_DEFAULTS[pageId] || HOME_SECTION_DEFAULTS;
    const out: TemplateData = {
      visibility: {},
      loaded,
    };

    for (const sectionId of Object.keys(pageDefaults)) {
      const defaults = pageDefaults[sectionId];
      const saved = sections[sectionId] || {};
      const resolved: Record<string, any> = {};

      for (const key of Object.keys(defaults)) {
        const savedVal = saved[key];
        resolved[key] = (savedVal !== undefined && savedVal !== '') ? savedVal : defaults[key];
      }

      // Also include any extra keys from saved data not in defaults
      for (const key of Object.keys(saved)) {
        if (!(key in resolved)) {
          resolved[key] = saved[key];
        }
      }

      out[sectionId] = resolved;
      out.visibility[sectionId] = visibility[sectionId] !== false;
    }

    return out;
  }, [sections, visibility, loaded, pageId]);

  return result;
}

/**
 * Invalidate the template cache (call after saving in the admin)
 */
export function invalidateTemplateCache() {
  // Clear all caches
  for (const pageId in _caches) {
    delete _caches[pageId];
  }
  // Dispatch event so all mounted hooks re-fetch
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('template-data-invalidated'));
  }
}