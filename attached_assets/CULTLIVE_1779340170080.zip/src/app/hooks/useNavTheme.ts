import { useState, useEffect, useRef } from 'react';

/**
 * Watches elements with [data-nav-theme="dark"|"light"] and returns
 * the current theme the nav should use based on what's behind it.
 *
 * Falls back to scroll-position heuristic when no sentinel is found:
 *   - top of page (over hero): use `heroTheme`
 *   - scrolled past hero: use `contentTheme`
 */
export function useNavTheme(
  heroTheme: 'light' | 'dark' = 'light',
  contentTheme: 'light' | 'dark' = 'dark',
): 'light' | 'dark' {
  const [theme, setTheme] = useState<'light' | 'dark'>(heroTheme);
  const observerRef = useRef<IntersectionObserver | null>(null);
  const sentinelsFound = useRef(false);
  const hasVisibleSentinel = useRef(false);

  // When the default themes change (e.g. dark mode toggle) and no sentinel
  // is actively providing a value, sync the state to the new default.
  useEffect(() => {
    if (!hasVisibleSentinel.current) {
      setTheme(heroTheme);
    }
  }, [heroTheme]);

  useEffect(() => {
    // --- Method 1: observe [data-nav-theme] sections ---
    const handleSentinels = () => {
      const sentinels = document.querySelectorAll<HTMLElement>('[data-nav-theme]');
      sentinelsFound.current = sentinels.length > 0;

      if (!sentinelsFound.current) return;

      // Disconnect previous observer
      observerRef.current?.disconnect();

      // Track which sections are currently visible at the top 80px
      const visibleSections = new Map<HTMLElement, boolean>();

      observerRef.current = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            visibleSections.set(entry.target as HTMLElement, entry.isIntersecting);
          });

          // Find the topmost visible sentinel
          let topSection: HTMLElement | null = null;
          let topY = Infinity;
          visibleSections.forEach((isVisible, el) => {
            if (isVisible) {
              const rect = el.getBoundingClientRect();
              if (rect.top < topY) {
                topY = rect.top;
                topSection = el;
              }
            }
          });

          if (topSection) {
            const t = (topSection as HTMLElement).getAttribute('data-nav-theme');
            if (t === 'light' || t === 'dark') {
              hasVisibleSentinel.current = true;
              setTheme(t);
            }
          } else {
            hasVisibleSentinel.current = false;
          }
        },
        {
          // Watch the top 80px band of the viewport
          rootMargin: '0px 0px -90% 0px',
          threshold: 0,
        },
      );

      sentinels.forEach((el) => observerRef.current!.observe(el));
    };

    handleSentinels();

    // Re-scan when DOM changes (route transitions add/remove sections)
    const mo = new MutationObserver(() => {
      handleSentinels();
    });
    mo.observe(document.body, { childList: true, subtree: true });

    // --- Method 2: scroll fallback when no sentinels ---
    const handleScroll = () => {
      if (sentinelsFound.current) return;
      const scrollY = window.scrollY;
      const heroHeight = window.innerHeight * 0.65;
      setTheme(scrollY < heroHeight ? heroTheme : contentTheme);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();

    return () => {
      observerRef.current?.disconnect();
      mo.disconnect();
      window.removeEventListener('scroll', handleScroll);
    };
  }, [heroTheme, contentTheme]);

  return theme;
}