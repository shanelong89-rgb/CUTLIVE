import { useState, useEffect, useMemo } from 'react';
import { useData } from '../context/DataContext';
import { useAuth } from '../context/AuthContext';
import { getTasteProfile, type TasteProfile } from '../components/OnboardingQuiz';
import { projectId, publicAnonKey } from '../config/supabase';
import type { CulturalEvent } from '../data/mock-data';
import { scoreEvents } from '../utils/score-events';

// ═══════════════════════════════════════════════════════════════════
// useWeeklyPicks — 3-tier pick resolution for "This Weekend"
//
// Tier 1 (highest): CMS curated picks (admin manually selected)
// Tier 2: Personalized picks (signed-in user with saved events + quiz)
// Tier 3: Quiz-based picks (anonymous user completed taste quiz)
// Fallback: Featured/upcoming events (current default logic)
// ═══════════════════════════════════════════════════════════════════

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-d507b98c`;

interface WeeklyPicksResult {
  picks: CulturalEvent[];
  tier: 'curated' | 'personalized' | 'quiz' | 'default';
  loading: boolean;
  hasQuiz: boolean;
  quizProfile: TasteProfile | null;
  refreshQuiz: () => void;
}

export function useWeeklyPicks(): WeeklyPicksResult {
  const { events } = useData();
  const { user, savedEventIds } = useAuth();
  const [curatedIds, setCuratedIds] = useState<string[] | null>(null);
  const [curatedLoading, setCuratedLoading] = useState(true);
  const [quizProfile, setQuizProfile] = useState<TasteProfile | null>(() => getTasteProfile());

  // Fetch CMS curated picks
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch(`${API_BASE}/cms/content/weekly-picks`, {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
          },
        });
        if (res.ok) {
          const data = await res.json();
          if (!cancelled) {
            // Find the curated picks item in the content KV store
            const items = data.items || [];
            const picksItem = items.find((i: any) => i.id === 'curated' || i.sectionId === 'curated');
            const picksData = picksItem?.data || picksItem;
            if (picksData?.eventIds?.length > 0) {
              setCuratedIds(picksData.eventIds);
            }
          }
        }
      } catch {}
      if (!cancelled) setCuratedLoading(false);
    })();
    return () => { cancelled = true; };
  }, []);

  const refreshQuiz = () => setQuizProfile(getTasteProfile());

  // Eligible events pool: upcoming/ongoing only
  const pool = useMemo(() =>
    events.filter(e => e.status === 'upcoming' || e.status === 'ongoing'),
    [events]
  );

  const result = useMemo((): WeeklyPicksResult => {
    const base = { hasQuiz: !!quizProfile, quizProfile, refreshQuiz, loading: curatedLoading };

    // ─── Tier 1: CMS curated ───
    if (curatedIds && curatedIds.length > 0) {
      const curated = curatedIds
        .map(id => events.find(e => e.id === id))
        .filter(Boolean) as CulturalEvent[];
      if (curated.length > 0) {
        return { ...base, picks: curated.slice(0, 3), tier: 'curated', loading: false };
      }
    }

    // ─── Tier 2: Personalized (signed-in user) ───
    if (user && (savedEventIds.length > 0 || quizProfile)) {
      const scored = scoreEvents(pool, quizProfile, savedEventIds, events);
      if (scored.length > 0) {
        return { ...base, picks: scored.slice(0, 3), tier: 'personalized', loading: false };
      }
    }

    // ─── Tier 3: Quiz-based (anonymous with quiz) ───
    if (quizProfile && quizProfile.selections.length > 0) {
      const scored = scoreEvents(pool, quizProfile, [], events);
      if (scored.length > 0) {
        return { ...base, picks: scored.slice(0, 3), tier: 'quiz', loading: false };
      }
    }

    // ─── Fallback: featured/upcoming ───
    const fallback = [...pool]
      .sort((a, b) => {
        if (a.featured && !b.featured) return -1;
        if (!a.featured && b.featured) return 1;
        const aIsSub = a.id.startsWith('sub_') ? 0 : 1;
        const bIsSub = b.id.startsWith('sub_') ? 0 : 1;
        return aIsSub - bIsSub;
      })
      .slice(0, 3);

    return { ...base, picks: fallback, tier: 'default', loading: false };
  }, [events, pool, curatedIds, curatedLoading, user, savedEventIds, quizProfile]);

  return result;
}