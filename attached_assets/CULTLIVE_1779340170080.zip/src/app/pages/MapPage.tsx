import { useState, useEffect, useCallback, useMemo } from 'react';
import { useSearchParams, Link } from 'react-router';
import { MapContainer, TileLayer, Marker, Popup } from '../components/map/LeafletWrapper';
import { motion, AnimatePresence } from 'motion/react';
import { Filter, List, MapIcon, Columns2, Search, X, ChevronDown, ChevronUp, Heart, Calendar, MapPin, Clock, Eye } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { useMode } from '../context/ModeContext';
import { useData } from '../context/DataContext';
import { useTimePeriod } from '../context/TimePeriodContext';
import { useCollections } from '../context/CollectionsContext';
import { useAuth } from '../context/AuthContext';
import { modeConfig, type Mode, type Venue, type CulturalEvent } from '../data/mock-data';
import { ModeSelector } from '../components/ModeSelector';
import { TimePeriodFilter } from '../components/TimePeriodFilter';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import { getDesignTokens, isLightMode } from '../data/mode-styles';
import { getVenueIdsWithEvents, filterEventsByTimePeriod } from '../utils/time-filter';
import { CIcon } from '../components/CIcon';
import { CategoryPills } from '../components/CategoryPills';
import { MapPageSkeleton } from '../components/LoadingSkeleton';
// leaflet CSS loaded via CDN in fonts.css

// Extracted map components
import { submissionToVenue, raEventToVenue, createMarkerIcon, createCommunityMarkerIcon, MapClickHandler, FlyToVenue, MapBoundsTracker, filterVenuesByBounds, type MapBounds, FlyToEvent, createLifestyleMarkerIcon, createLifestyleVenueMarkerIcon } from '../components/map/map-utils';
import { VenueInfoPanel } from '../components/map/VenueInfoPanel';
import { StreetViewPanel } from '../components/map/StreetViewPanel';
import { VenueCard, type VenueCardTokens } from '../components/map/VenueCard';
import { LifestyleEventPanel, LifestyleEventRow, LifestyleEventGridCard, LifestyleVenueRow } from '../components/map/LifestyleEventPanel';
import { LC, LF, lifestyleCategories, culturalEventToLifestyle, type LifestyleCategory, type LifestyleEvent } from '../data/lifestyle-data';
import { getEventLink } from '../utils/event-helpers';
import { getBilingualField } from '../utils/bilingual';
import { useEventStats } from '../context/EventStatsContext';

type ViewMode = 'map' | 'split' | 'list';

// ─── Levenshtein distance for fuzzy search param matching ───
function levenshtein(a: string, b: string): number {
  const al = a.length, bl = b.length;
  if (al === 0) return bl;
  if (bl === 0) return al;
  let prev = Array.from({ length: bl + 1 }, (_, i) => i);
  let curr = new Array(bl + 1);
  for (let i = 1; i <= al; i++) {
    curr[0] = i;
    for (let j = 1; j <= bl + 1 - 1; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      curr[j] = Math.min(prev[j] + 1, curr[j - 1] + 1, prev[j - 1] + cost);
    }
    [prev, curr] = [curr, prev];
  }
  return prev[bl];
}

// Stop-words to skip when tokenising multi-word AI suggestions
const STOP_WORDS = new Set([
  'in', 'at', 'on', 'for', 'the', 'a', 'an', 'of', 'and', 'or',
  'near', 'me', 'best', 'great', 'good', 'top', 'hk', 'hong', 'kong',
]);

/** Check whether a single token matches any field of a venue */
function tokenMatchesVenue(token: string, venue: Venue): boolean {
  const fields = [
    venue.name, venue.nameZh || '', venue.category || '',
    venue.subcategory || '', venue.district || '', venue.description || '',
    ...(venue.vibeTags || []),
  ];

  // Exact substring
  for (const field of fields) {
    if (field.toLowerCase().includes(token)) return true;
  }

  // Fuzzy match on short fields for tokens ≥3 chars
  if (token.length >= 3) {
    const shortFields = [venue.name, venue.district || '', venue.category || '', ...(venue.vibeTags || [])];
    for (const field of shortFields) {
      if (!field) continue;
      const words = field.toLowerCase().split(/[\s\-_/,·]+/);
      for (const word of words) {
        if (word.length < 2) continue;
        const dist = levenshtein(word, token);
        const maxLen = Math.max(word.length, token.length);
        if (1 - dist / maxLen > 0.6) return true;
      }
    }
  }

  return false;
}

function venueMatchesSearch(venue: Venue, query: string): boolean {
  const q = query.toLowerCase().trim();

  // ── Single-word / short query: use original whole-query matching ──
  if (!q.includes(' ')) {
    return tokenMatchesVenue(q, venue);
  }

  // ── Multi-word query (AI suggestions are always multi-word phrases) ──
  // Strategy: split into meaningful tokens, venue passes if it matches
  // at least one meaningful token OR the whole phrase as a substring.

  // First, try the whole phrase as a substring (catches exact descriptions)
  const allFields = [
    venue.name, venue.nameZh || '', venue.category || '',
    venue.subcategory || '', venue.district || '', venue.description || '',
    ...(venue.vibeTags || []),
  ];
  for (const field of allFields) {
    if (field.toLowerCase().includes(q)) return true;
  }

  // Tokenise, skip stop-words and very short words
  const tokens = q
    .split(/[\s,]+/)
    .map(t => t.replace(/[^a-z0-9\u4e00-\u9fff]/g, ''))
    .filter(t => t.length >= 3 && !STOP_WORDS.has(t));

  if (tokens.length === 0) return false;

  // Venue passes if ANY meaningful token matches (OR logic for discovery)
  return tokens.some(token => tokenMatchesVenue(token, venue));
}

// ─── Main Map Page ───
export function MapPage() {
  const { t, i18n } = useTranslation();
  const { currentMode } = useMode();
  const { venues, events, allEvents, loading } = useData();
  const { timePeriod } = useTimePeriod();
  const { getStats } = useEventStats();

  // Read search params from URL — useSearchParams reacts to navigation changes
  const [searchParams, setSearchParams] = useSearchParams();
  const activeSearchQuery = searchParams.get('search') || '';

  // Clear search
  const clearSearch = useCallback(() => {
    setSearchParams(prev => {
      const next = new URLSearchParams(prev);
      next.delete('search');
      return next;
    }, { replace: true });
  }, [setSearchParams]);

  const modeColor = currentMode && currentMode !== 'lifestyle' ? modeConfig[currentMode].color : currentMode === 'lifestyle' ? '#2D6A4F' : '#1A1A1A';
  const tokens = getDesignTokens(currentMode);
  const light = isLightMode(currentMode);
  const [selectedVenue, setSelectedVenue] = useState<Venue | null>(null);
  const [streetViewVenue, setStreetViewVenue] = useState<Venue | null>(null);
  const [filterOpen, setFilterOpen] = useState(false);
  const [mapStyle, setMapStyle] = useState<'dark' | 'light' | 'satellite'>('light');
  const [prevMode, setPrevMode] = useState(currentMode);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [viewMode, setViewMode] = useState<ViewMode>('split'); // Default to split view
  const [hoveredVenueId, setHoveredVenueId] = useState<string | null>(null);

  // ─── Airbnb-style bounds filtering ───
  const [mapBounds, setMapBounds] = useState<MapBounds | null>(null);
  const [searchAsMove, setSearchAsMove] = useState(true);

  // Mobile map controls expanded state
  const [mobileControlsOpen, setMobileControlsOpen] = useState(false);
  const [showSavedOnly, setShowSavedOnly] = useState(false);
  const { allSavedItemIds, isInAnyCollection } = useCollections();
  const { savedEventIds } = useAuth();

  // Merge both save systems: collection-based (Quick Saves) + event-based (heart button on event detail)
  const allSavedIds = useMemo(() => {
    const merged = new Set(allSavedItemIds);
    for (const id of savedEventIds) merged.add(id);
    return merged;
  }, [allSavedItemIds, savedEventIds]);

  const handleBoundsChange = useCallback((bounds: MapBounds) => {
    setMapBounds(bounds);
  }, []);

  const isDegen = currentMode === 'degen';
  const isArtsy = currentMode === 'artsy';
  const isFamily = currentMode === 'family';
  const isFoodie = currentMode === 'foodie';
  const isLifestyle = currentMode === 'lifestyle';
  const isNeutral = !currentMode;

  // ─── Lifestyle-specific state ───
  const [selectedLifestyleEvent, setSelectedLifestyleEvent] = useState<LifestyleEvent | null>(null);
  const [lifestyleCategory, setLifestyleCategory] = useState<LifestyleCategory>('all');
  const [lifestyleListTab, setLifestyleListTab] = useState<'events' | 'venues'>('events');

  // Lifestyle events
  const allLifestyleEvents = useMemo(() => {
    if (!isLifestyle) return [];
    return events.filter(e => e.modeTags?.includes('lifestyle')).map(culturalEventToLifestyle);
  }, [events, isLifestyle]);

  const filteredLifestyleEvents = useMemo(() => {
    if (lifestyleCategory === 'all') return allLifestyleEvents;
    return allLifestyleEvents.filter(e => e.category === lifestyleCategory);
  }, [allLifestyleEvents, lifestyleCategory]);

  // Apply saved filter to lifestyle events
  const displayLifestyleEvents = useMemo(() => {
    if (!showSavedOnly) return filteredLifestyleEvents;
    return allLifestyleEvents.filter(e => allSavedIds.has(e.id));
  }, [filteredLifestyleEvents, allLifestyleEvents, showSavedOnly, allSavedIds]);

  // Lifestyle venues for list/split panel (no bounds filtering, includes saved from all venues)
  const displayLifestyleVenues = useMemo(() => {
    if (!isLifestyle) return [];
    const safeVenues = venues.filter(v =>
      v && v.id && typeof v.lat === 'number' && typeof v.lng === 'number' &&
      !isNaN(v.lat) && !isNaN(v.lng) && v.lat !== 0 && v.lng !== 0 &&
      v.modeScores && typeof v.modeScores === 'object'
    );
    if (showSavedOnly) {
      // Show ALL saved venues regardless of mode score
      return safeVenues.filter(v => allSavedIds.has(v.id));
    }
    return safeVenues
      .filter(v => (v.modeScores.lifestyle || 0) >= 0.3)
      .sort((a, b) => (b.modeScores.lifestyle || 0) - (a.modeScores.lifestyle || 0));
  }, [isLifestyle, venues, showSavedOnly, allSavedIds]);

  const lifestyleEventsWithCoords = useMemo(() => {
    return displayLifestyleEvents.filter(e => e.lat && e.lng);
  }, [displayLifestyleEvents]);

  // Lifestyle venue selection helper — clear the other selection
  const selectLifestyleEvent = useCallback((event: LifestyleEvent) => {
    setSelectedLifestyleEvent(event);
    setSelectedVenue(null);
  }, []);
  const selectLifestyleVenue = useCallback((venue: Venue) => {
    setSelectedVenue(venue);
    setSelectedLifestyleEvent(null);
  }, []);

  useEffect(() => {
    if (currentMode !== prevMode) {
      setIsTransitioning(true);
      const timer = setTimeout(() => {
        setPrevMode(currentMode);
        setIsTransitioning(false);
      }, 400);
      return () => clearTimeout(timer);
    }
  }, [currentMode, prevMode]);

  useEffect(() => {
    if (isDegen || isArtsy || isFamily || isLifestyle) {
      setMapStyle('light');
    } else if (!currentMode) {
      setMapStyle('light');
    } else {
      setMapStyle('dark');
    }
  }, [currentMode, isDegen, isArtsy, isFamily, isLifestyle]);

  const filteredVenues = useMemo(() => {
    // Safety: filter out any venues with invalid coordinates or missing modeScores
    const safeVenues = venues.filter(v =>
      v && v.id && typeof v.lat === 'number' && typeof v.lng === 'number' &&
      !isNaN(v.lat) && !isNaN(v.lng) && v.lat !== 0 && v.lng !== 0 &&
      v.modeScores && typeof v.modeScores === 'object'
    );

    let result = currentMode
      ? (isLifestyle
          ? safeVenues.filter((v) => (v.modeScores.lifestyle || 0) >= 0.3).sort((a, b) => (b.modeScores.lifestyle || 0) - (a.modeScores.lifestyle || 0))
          : safeVenues.filter((v) => (v.modeScores[currentMode as Mode] || 0) > 0.3).sort((a, b) => (b.modeScores[currentMode as Mode] || 0) - (a.modeScores[currentMode as Mode] || 0))
        )
      : safeVenues;

    if (timePeriod !== 'all') {
      // Use allEvents for venue-event matching so past-hidden events still link to their venues
      const venueIdsWithEvents = getVenueIdsWithEvents(allEvents, timePeriod, currentMode);
      result = result.filter((v) => venueIdsWithEvents.has(v.id));
    }

    // Build set of venue IDs already in the result (for raEventToVenue dedup)
    const existingIds = new Set(result.map(v => v.id));

    // Use allEvents (bypasses hidePastEvents) for imported event → pin conversion
    // The map has its own time period filter for temporal filtering
    const allImportableEvents = timePeriod !== 'all'
      ? filterEventsByTimePeriod(allEvents, timePeriod, currentMode)
      : allEvents;

    // Merge published submission events as venue pins
    const submissionVenues = allImportableEvents
      .filter(e => e.id?.startsWith('sub_') && !existingIds.has(e.id))
      .map(submissionToVenue)
      .filter((v): v is Venue => v !== null);

    // Also convert RA-imported events to venue pins
    // Pass existingIds so events whose venue is already shown are skipped
    const raVenues = allImportableEvents
      .filter(e => (e.id?.startsWith('ra_') || e.id?.startsWith('lsa_') || e.id?.startsWith('apify_')) && !existingIds.has(e.id))
      .map(e => raEventToVenue(e, existingIds))
      .filter((v): v is Venue => v !== null);

    // Filter event venues by mode if active
    const allEventVenues = [...submissionVenues, ...raVenues];
    const filteredSubs = currentMode && currentMode !== 'lifestyle'
      ? allEventVenues.filter(v => (v.modeScores[currentMode as Mode] || 0) > 0.3)
      : allEventVenues;

    // Merge and sort: intersperse community venues by mode relevance
    if (currentMode && currentMode !== 'lifestyle') {
      const allVenues = [...result, ...filteredSubs];
      const merged = allVenues.sort((a, b) => (b.modeScores[currentMode as Mode] || 0) - (a.modeScores[currentMode as Mode] || 0));
      // Apply search query filter if present
      if (activeSearchQuery) return merged.filter(v => venueMatchesSearch(v, activeSearchQuery));
      return merged;
    }

    const merged = [...result, ...filteredSubs];
    // Apply search query filter if present
    if (activeSearchQuery) return merged.filter(v => venueMatchesSearch(v, activeSearchQuery));
    return merged;
  }, [currentMode, venues, events, allEvents, timePeriod, activeSearchQuery]);

  // Venues visible in the current map viewport
  const visibleVenues = useMemo(() => {
    let result = filteredVenues;
    // Apply saved filter — when showSavedOnly, include ALL saved venues
    // regardless of mode/time filters so saved items never disappear
    if (showSavedOnly) {
      const savedFromFiltered = new Set(result.filter(v => allSavedIds.has(v.id)).map(v => v.id));
      // Also include saved venues that were filtered out by mode/time
      const safeVenues = venues.filter(v =>
        v && v.id && typeof v.lat === 'number' && typeof v.lng === 'number' &&
        !isNaN(v.lat) && !isNaN(v.lng) && v.lat !== 0 && v.lng !== 0 &&
        v.modeScores && typeof v.modeScores === 'object'
      );
      const missingSaved = safeVenues.filter(v => allSavedIds.has(v.id) && !savedFromFiltered.has(v.id));
      result = [...result.filter(v => allSavedIds.has(v.id)), ...missingSaved];
    }
    if (!searchAsMove || !mapBounds) return result;
    return filterVenuesByBounds(result, mapBounds);
  }, [filteredVenues, venues, mapBounds, searchAsMove, showSavedOnly, allSavedIds]);

  // Venues for list view (no map bounds, but respects saved filter)
  const listViewVenues = useMemo(() => {
    if (!showSavedOnly) return filteredVenues;
    // Include ALL saved venues regardless of mode/time filters
    const savedFromFiltered = new Set(filteredVenues.filter(v => allSavedIds.has(v.id)).map(v => v.id));
    const safeVenues = venues.filter(v =>
      v && v.id && typeof v.lat === 'number' && typeof v.lng === 'number' &&
      !isNaN(v.lat) && !isNaN(v.lng) && v.lat !== 0 && v.lng !== 0 &&
      v.modeScores && typeof v.modeScores === 'object'
    );
    const missingSaved = safeVenues.filter(v => allSavedIds.has(v.id) && !savedFromFiltered.has(v.id));
    return [...filteredVenues.filter(v => allSavedIds.has(v.id)), ...missingSaved];
  }, [filteredVenues, venues, showSavedOnly, allSavedIds]);

  // Saved events — shown when Saved filter is active
  const savedEvents = useMemo(() => {
    if (!showSavedOnly) return [];
    return allEvents.filter(e => e && e.id && allSavedIds.has(e.id));
  }, [allEvents, showSavedOnly, allSavedIds]);

  // Venues to render on the map — only saved when Saved filter is active
  const mapVenues = useMemo(() => {
    if (!showSavedOnly) return visibleVenues;
    return visibleVenues.filter(v => allSavedIds.has(v.id));
  }, [visibleVenues, showSavedOnly, allSavedIds]);

  // Saved events with coordinates — for map markers
  const savedEventsWithCoords = useMemo(() => {
    return savedEvents.filter(e => e && typeof e.lat === 'number' && typeof e.lng === 'number' && !isNaN(e.lat) && !isNaN(e.lng));
  }, [savedEvents]);

  const tileUrl = useMemo(() => {
    // Lifestyle uses warm voyager tiles
    if (isLifestyle && mapStyle === 'light') {
      return 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png';
    }
    switch (mapStyle) {
      case 'dark':
        return 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png';
      case 'light':
        return 'https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png';
      case 'satellite':
        return 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}';
    }
  }, [mapStyle, isLifestyle]);

  const handleStreetView = useCallback((venue: Venue) => {
    setStreetViewVenue(venue);
  }, []);

  // Overlay chrome tokens per mode
  const overlayBg = isDegen ? 'rgba(237,255,0,0.92)' : isArtsy ? 'rgba(245,241,235,0.88)' : isFamily ? 'rgba(255,248,240,0.88)' : isFoodie ? 'rgba(10,18,40,0.85)' : isLifestyle ? 'rgba(250,250,245,0.92)' : 'rgba(255,255,255,0.96)';
  const overlayBorder = isDegen ? 'rgba(0,0,0,0.08)' : isArtsy ? 'rgba(0,0,0,0.06)' : isFamily ? 'rgba(0,0,0,0.05)' : isFoodie ? 'rgba(37,99,235,0.1)' : isLifestyle ? 'rgba(45,106,79,0.15)' : 'rgba(0,0,0,0.12)';
  const overlayShadow = isNeutral ? '0 2px 16px rgba(0,0,0,0.10), 0 1px 4px rgba(0,0,0,0.06)' : 'none';
  const overlayRadius = isDegen ? '4px' : isArtsy ? '2px' : isFamily ? '24px' : isFoodie ? '20px' : isLifestyle ? '16px' : '12px';
  const overlayText = isDegen ? '#0A0A0A' : isArtsy ? '#1a1a1a' : isFamily ? '#2D2A32' : isFoodie ? '#E8F0FF' : isLifestyle ? '#0A0A0A' : '#1a1a1a';
  const overlayTextMuted = isDegen ? 'rgba(0,0,0,0.4)' : isArtsy ? '#8a8a8a' : isFamily ? '#A39DAE' : isFoodie ? 'rgba(232,240,255,0.4)' : isLifestyle ? '#8A8580' : 'rgba(0,0,0,0.45)';
  const mapBg = isDegen ? '#E5F500' : isArtsy ? '#F5F1EB' : isFamily ? '#FFF8F0' : isFoodie ? '#0A1220' : isLifestyle ? '#FAFAF5' : '#FAFAF8';

  // card style tokens
  const cardBg = isDegen ? 'rgba(10,10,10,0.9)' : isArtsy ? 'rgba(255,255,255,0.92)' : isFamily ? 'rgba(255,255,255,0.92)' : isFoodie ? 'rgba(10,18,40,0.92)' : isLifestyle ? 'rgba(26,61,46,0.92)' : 'rgba(255,255,255,0.97)';
  const cardBorder = isDegen ? 'rgba(237,255,0,0.15)' : isArtsy ? 'rgba(0,0,0,0.06)' : isFamily ? 'rgba(0,0,0,0.05)' : isFoodie ? 'rgba(37,99,235,0.1)' : isLifestyle ? 'rgba(45,106,79,0.2)' : 'rgba(0,0,0,0.08)';
  const cardText = isDegen ? '#EDFF00' : isArtsy ? '#1a1a1a' : isFamily ? '#2D2A32' : isFoodie ? '#E8F0FF' : isLifestyle ? '#FFFFFF' : '#1a1a1a';
  const cardTextMuted = isDegen ? 'rgba(237,255,0,0.4)' : isArtsy ? '#8a8a8a' : isFamily ? '#A39DAE' : isFoodie ? 'rgba(232,240,255,0.4)' : isLifestyle ? 'rgba(149,213,178,0.5)' : 'rgba(0,0,0,0.45)';
  const cardTextSub = isDegen ? 'rgba(255,255,255,0.5)' : isArtsy ? '#666' : isFamily ? '#6B6574' : isFoodie ? 'rgba(232,240,255,0.6)' : isLifestyle ? 'rgba(149,213,178,0.7)' : '#555';
  const imgRadius = isDegen ? '4px' : isArtsy ? '0' : isFamily ? '12px' : isFoodie ? '12px' : isLifestyle ? '14px' : '8px';

  // Small inline views badge for map event cards
  const ViewsBadge = ({ eventId, size = 'sm' }: { eventId: string; size?: 'sm' | 'xs' }) => {
    const views = getStats(eventId)?.views || 0;
    if (views <= 0) return null;
    const label = views > 999 ? `${(views / 1000).toFixed(1)}k` : String(views);
    return (
      <span className="flex items-center gap-0.5 flex-shrink-0" style={{ fontSize: size === 'xs' ? '9px' : '10px', color: cardTextMuted, opacity: 0.7 }}>
        <Eye size={size === 'xs' ? 8 : 9} /> {label}
      </span>
    );
  };
  const listPanelBg = isDegen ? '#0A0A0A' : isArtsy ? '#F5F1EB' : isFamily ? '#FFF8F0' : isFoodie ? '#0A1220' : isLifestyle ? '#122A20' : '#FAFAF8';

  // View toggle items
  const viewToggleItems: { key: ViewMode; icon: typeof MapIcon; label: string }[] = [
    { key: 'map', icon: MapIcon, label: t('map.mapView') },
    { key: 'split', icon: Columns2, label: t('map.splitView') },
    { key: 'list', icon: List, label: t('map.listView') },
  ];

  // ─── Search banner (shown when activeSearchQuery is set) ───
  const renderSearchBanner = (variant: 'floating' | 'inline' = 'floating') => {
    if (!activeSearchQuery) return null;
    const isFloating = variant === 'floating';
    return (
      <motion.div
        initial={{ opacity: 0, y: isFloating ? -6 : 0 }}
        animate={{ opacity: 1, y: 0 }}
        className={isFloating ? 'pointer-events-auto mb-2' : 'mb-3'}
      >
        <div
          className="backdrop-blur-xl flex items-center gap-2 px-3 py-2"
          style={{
            background: `${modeColor}10`,
            border: `1px solid ${modeColor}25`,
            borderRadius: overlayRadius,
            boxShadow: isFloating ? overlayShadow : 'none',
          }}
        >
          <Search size={13} style={{ color: modeColor, flexShrink: 0 }} />
          <span className="text-xs" style={{ color: overlayText, fontFamily: tokens.bodyFont }}>
            Showing results for "<span className="font-semibold">{activeSearchQuery}</span>"
          </span>
          <span className="text-[10px] px-1.5 py-0.5 rounded-full" style={{ backgroundColor: `${modeColor}15`, color: modeColor, fontWeight: 600 }}>
            {mapVenues.length}
          </span>
          <button
            onClick={clearSearch}
            className="ml-auto p-1 rounded-full cursor-pointer transition-opacity hover:opacity-70"
            style={{ color: overlayTextMuted }}
          >
            <X size={13} />
          </button>
        </div>
      </motion.div>
    );
  };

  // ─── Shared map render ───
  const renderMap = (className?: string) => (
    <MapContainer
      center={[22.295, 114.155]}
      zoom={14}
      className={className || 'h-full w-full'}
      zoomControl={false}
      style={{ background: mapBg }}
    >
      <TileLayer url={tileUrl} attribution='&copy; <a href="https://carto.com/">CARTO</a>' />
      <FlyToVenue venue={selectedVenue} />
      <MapClickHandler onLocationClick={() => {}} onMapClick={() => { setSelectedVenue(null); setSelectedLifestyleEvent(null); }} />
      <MapBoundsTracker onBoundsChange={handleBoundsChange} />
      {/* Lifestyle event markers */}
      {isLifestyle && <FlyToEvent event={selectedLifestyleEvent} />}
      {isLifestyle && lifestyleEventsWithCoords.map((event) => (
        <Marker key={event.id}
          position={[event.lat!, event.lng!]}
          icon={createLifestyleMarkerIcon(event.category, selectedLifestyleEvent?.id === event.id || hoveredVenueId === event.id)}
          eventHandlers={{
            click: () => selectLifestyleEvent(event),
            mouseover: () => setHoveredVenueId(event.id),
            mouseout: () => setHoveredVenueId(null),
          }}>
          <Popup className="custom-popup">
            <div className="text-sm" style={{ fontFamily: LF.heading, fontWeight: 700 }}>{event.title}</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <span className="text-[11px]" style={{ fontFamily: LF.body, opacity: 0.7 }}>{event.district}</span>
              {(getStats(event.id)?.views || 0) > 0 && (
                <span style={{ display: 'flex', alignItems: 'center', gap: '2px', fontSize: '10px', opacity: 0.5 }}>
                  <Eye size={8} /> {getStats(event.id)!.views}
                </span>
              )}
            </div>
          </Popup>
        </Marker>
      ))}
      {mapVenues.map((venue) => (
        <Marker
          key={venue.id}
          position={[venue.lat, venue.lng]}
          icon={isLifestyle
            ? createLifestyleVenueMarkerIcon(selectedVenue?.id === venue.id || hoveredVenueId === venue.id)
            : (venue.id?.startsWith('sub_') || venue.id?.startsWith('ra_') || venue.id?.startsWith('lsa_') || venue.id?.startsWith('apify_'))
              ? createCommunityMarkerIcon(
                  venue.category,
                  modeColor,
                  selectedVenue?.id === venue.id || hoveredVenueId === venue.id,
                  venue.subcategory === 'geocoded'
                )
              : createMarkerIcon(
                  venue.category,
                  modeColor,
                  selectedVenue?.id === venue.id || hoveredVenueId === venue.id,
                  tokens.aesthetic,
                  isNeutral
                )
          }
          eventHandlers={{
            click: () => isLifestyle ? selectLifestyleVenue(venue) : setSelectedVenue(venue),
            mouseover: () => setHoveredVenueId(venue.id),
            mouseout: () => setHoveredVenueId(null),
          }}
        >
          <Popup className="custom-popup">
            <div className="text-sm font-medium">{venue.name}</div>
            {venue.categories && venue.categories.length > 1 ? (
              <div style={{ marginTop: '4px' }}>
                <CategoryPills categories={venue.categories} size="xs" showPrimary maxVisible={3} />
              </div>
            ) : venue.category ? (
              <div className="text-[10px] mt-0.5 opacity-60 uppercase tracking-wider">{venue.category}</div>
            ) : null}
            {venue.district && (
              <div className="text-[10px] mt-0.5 opacity-50">{venue.district}</div>
            )}
          </Popup>
        </Marker>
      ))}
      {/* Saved event markers on map */}
      {savedEventsWithCoords.map((event) => (
        <Marker
          key={`event-${event.id}`}
          position={[event.lat!, event.lng!]}
          icon={createMarkerIcon(
            'event',
            modeColor,
            false,
            tokens.aesthetic,
            isNeutral
          )}
        >
          <Popup className="custom-popup">
            <div className="text-sm font-medium">{getBilingualField(event, 'title', i18n.language)}</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <span className="text-[10px] opacity-60">
                <span style={{ marginRight: '4px' }}>📅</span>
                {getBilingualField(event, 'venueName', i18n.language) || event.district}
              </span>
              {(getStats(event.id)?.views || 0) > 0 && (
                <span style={{ display: 'flex', alignItems: 'center', gap: '2px', fontSize: '10px', opacity: 0.5 }}>
                  <Eye size={8} /> {getStats(event.id)!.views}
                </span>
              )}
            </div>
          </Popup>
        </Marker>
      ))}
    </MapContainer>
  );

  // ─── View toggle control ───
  const renderViewToggle = () => (
    <div className="backdrop-blur-xl flex overflow-hidden" style={{
      background: isLifestyle ? 'rgba(18,42,32,0.9)' : overlayBg,
      border: `1px solid ${isLifestyle ? 'rgba(45,106,79,0.3)' : overlayBorder}`,
      borderRadius: isLifestyle ? '12px' : overlayRadius,
      boxShadow: isLifestyle ? 'none' : overlayShadow,
    }}>
      {viewToggleItems.map((item) => (
        <button
          key={item.key}
          onClick={() => setViewMode(item.key)}
          className="flex items-center gap-1.5 px-3 py-1.5 text-[11px] transition-all cursor-pointer"
          style={{
            background: viewMode === item.key
              ? (isDegen ? 'rgba(0,0,0,0.9)' : isLifestyle ? 'rgba(45,106,79,0.5)' : light ? 'rgba(0,0,0,0.08)' : 'rgba(255,255,255,0.15)')
              : 'transparent',
            color: viewMode === item.key
              ? (isDegen ? '#EDFF00' : isLifestyle ? LC.sage : overlayText)
              : (isLifestyle ? 'rgba(149,213,178,0.4)' : overlayTextMuted),
            fontFamily: isLifestyle ? LF.body : tokens.headingFont,
            fontWeight: viewMode === item.key ? (isDegen ? 700 : 600) : 400,
          }}
        >
          <item.icon size={13} />
          {item.label}
        </button>
      ))}
    </div>
  );

  // ─── Venue list card ───
  const venueCardTokens: VenueCardTokens = {
    modeColor, currentMode, isDegen, isArtsy,
    headingFont: tokens.headingFont, bodyFont: tokens.bodyFont,
    overlayRadius, cardBorder, cardText, cardTextMuted, cardTextSub, imgRadius,
  };

  const renderVenueCard = (venue: Venue, variant: 'split' | 'list') => (
    <VenueCard
      venue={venue}
      variant={variant}
      isSelected={selectedVenue?.id === venue.id}
      isHovered={hoveredVenueId === venue.id}
      isSaved={allSavedIds.has(venue.id)}
      onSelect={() => setSelectedVenue(venue)}
      onHover={() => setHoveredVenueId(venue.id)}
      onLeave={() => setHoveredVenueId(null)}
      tokens={venueCardTokens}
    />
  );

  // Shared CSS
  const sharedStyles = `
    .leaflet-popup-content-wrapper {
      background: ${isDegen ? 'rgba(10,10,10,0.95)' : isArtsy ? 'rgba(245,241,235,0.95)' : isFamily ? 'rgba(255,248,240,0.95)' : isFoodie ? 'rgba(10,18,40,0.95)' : isLifestyle ? 'rgba(18,42,32,0.95)' : 'rgba(255,255,255,0.95)'} !important;
      color: ${isDegen ? '#EDFF00' : isArtsy ? '#1a1a1a' : isFamily ? '#2D2A32' : isFoodie ? '#E8F0FF' : isLifestyle ? '#FFFFFF' : '#1a1a1a'} !important;
      border: 1px solid ${overlayBorder} !important;
      border-radius: ${overlayRadius} !important;
      backdrop-filter: blur(12px);
      font-family: ${tokens.headingFont};
      ${isDegen ? 'text-transform: uppercase; font-weight: 700; letter-spacing: 0.03em;' : ''}
    }
    .leaflet-popup-tip {
      background: ${isDegen ? 'rgba(10,10,10,0.95)' : isArtsy ? 'rgba(245,241,235,0.95)' : isFamily ? 'rgba(255,248,240,0.95)' : isFoodie ? 'rgba(10,18,40,0.95)' : isLifestyle ? 'rgba(18,42,32,0.95)' : 'rgba(255,255,255,0.95)'} !important;
    }
    .custom-marker { background: transparent !important; border: none !important; }
    @keyframes pulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.1); } }
    @keyframes communityPulse { 0% { transform: translate(-50%,-50%) scale(1); opacity: 0.6; } 50% { transform: translate(-50%,-50%) scale(1.3); opacity: 0.2; } 100% { transform: translate(-50%,-50%) scale(1); opacity: 0.6; } }
    .scrollbar-hide::-webkit-scrollbar { display: none; }
    .scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
  `;

  // Show skeleton during initial load (no data yet)
  if (loading && venues.length === 0) {
    return <MapPageSkeleton />;
  }

  // ─── Lifestyle category pills ───
  const renderLifestyleCategoryPills = (variant: 'panel' | 'floating' = 'panel') => (
    <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-hide">
      {lifestyleCategories.map((cat) => {
        const isActive = lifestyleCategory === cat.key;
        return (
          <button key={cat.key} onClick={() => setLifestyleCategory(cat.key)}
            className="flex items-center gap-1 px-3 py-1.5 text-[10px] whitespace-nowrap transition-all cursor-pointer flex-shrink-0"
            style={{
              borderRadius: '9999px',
              backgroundColor: isActive ? LC.forest : (variant === 'floating' ? 'transparent' : 'rgba(45,106,79,0.1)'),
              color: isActive ? LC.white : LC.sage,
              border: isActive ? 'none' : `1px solid ${LC.deepForestBorder}`,
              fontFamily: LF.body, fontWeight: isActive ? 600 : 400,
            }}>
            {cat.label}
          </button>
        );
      })}
    </div>
  );

  // ─── Lifestyle events/venues tab toggle ───
  const renderLifestyleTabToggle = (variant: 'panel' | 'floating' = 'panel') => (
    <div className="flex overflow-hidden" style={{
      background: variant === 'floating' ? 'rgba(18,42,32,0.85)' : 'rgba(45,106,79,0.1)',
      border: `1px solid ${LC.deepForestBorder}`,
      borderRadius: '10px',
    }}>
      {([
        { key: 'events' as const, label: 'Events', count: displayLifestyleEvents.length },
        { key: 'venues' as const, label: 'Venues', count: isLifestyle ? displayLifestyleVenues.length : visibleVenues.length },
      ]).map((tab) => (
        <button
          key={tab.key}
          onClick={() => setLifestyleListTab(tab.key)}
          className="flex items-center gap-1.5 px-3 py-1.5 text-[11px] transition-all cursor-pointer"
          style={{
            background: lifestyleListTab === tab.key ? 'rgba(45,106,79,0.4)' : 'transparent',
            color: lifestyleListTab === tab.key ? LC.sage : 'rgba(149,213,178,0.4)',
            fontFamily: LF.body,
            fontWeight: lifestyleListTab === tab.key ? 600 : 400,
          }}
        >
          {tab.label}
          <span className="text-[10px] px-1.5 py-0.5 rounded-full tabular-nums" style={{
            backgroundColor: lifestyleListTab === tab.key ? 'rgba(149,213,178,0.2)' : 'transparent',
            color: lifestyleListTab === tab.key ? LC.sage : 'rgba(149,213,178,0.3)',
          }}>
            {tab.count}
          </span>
        </button>
      ))}
    </div>
  );

  // ═════════════════════════════════════════════
  // LIST VIEW
  // ══════════════════════════════════════════════
  if (viewMode === 'list') {
    return (
      <div className="h-[calc(100vh-64px)] overflow-y-auto overflow-x-hidden relative" data-nav-theme={light ? 'dark' : 'light'} style={{ backgroundColor: listPanelBg }}>
        {/* Top bar */}
        <div className="sticky top-0 z-[1000] px-4 sm:px-6 pt-4 pb-3" style={{ backgroundColor: listPanelBg }}>
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 sm:justify-between mb-2">
            <div className="max-w-[calc(100vw-32px)] sm:max-w-none">
              <div
                className="backdrop-blur-xl p-2"
                style={{ background: overlayBg, border: `1px solid ${overlayBorder}`, borderRadius: overlayRadius }}
              >
                <ModeSelector compact />
              </div>
            </div>
            <div className="flex gap-2">
              {isLifestyle && renderLifestyleTabToggle('floating')}
              {renderViewToggle()}
            </div>
          </div>
          {isLifestyle && lifestyleListTab === 'events' && renderLifestyleCategoryPills()}
          <div className="flex items-center justify-between">
            {!isLifestyle && (
              <div
                className="backdrop-blur-xl p-1.5"
                style={{ background: overlayBg, border: `1px solid ${overlayBorder}`, borderRadius: overlayRadius }}
              >
                <TimePeriodFilter variant="overlay" />
              </div>
            )}
            <div className="flex items-center gap-3">
              <button
                onClick={() => setShowSavedOnly(!showSavedOnly)}
                className="flex items-center gap-1.5 px-2.5 py-1.5 text-[11px] transition-all cursor-pointer"
                style={{
                  background: showSavedOnly ? (isLifestyle ? 'rgba(45,106,79,0.25)' : `${modeColor}12`) : (isLifestyle ? 'rgba(45,106,79,0.1)' : overlayBg),
                  border: `1px solid ${showSavedOnly ? (isLifestyle ? LC.forest : modeColor + '35') : (isLifestyle ? LC.deepForestBorder : overlayBorder)}`,
                  borderRadius: isLifestyle ? '10px' : overlayRadius,
                  color: showSavedOnly ? (isLifestyle ? LC.sage : modeColor) : cardTextMuted,
                  fontFamily: isLifestyle ? LF.body : tokens.headingFont,
                  fontWeight: showSavedOnly ? 600 : 400,
                }}
              >
                <Heart size={12} fill={showSavedOnly ? (isLifestyle ? LC.sage : modeColor) : 'none'} />
                Saved
                {showSavedOnly && allSavedIds.size > 0 && (
                  <span className="text-[9px] px-1 py-0.5 rounded-full" style={{ backgroundColor: isLifestyle ? 'rgba(149,213,178,0.2)' : `${modeColor}18`, color: isLifestyle ? LC.sage : modeColor }}>{allSavedIds.size}</span>
                )}
              </button>
              <p className="text-xs" style={{ color: cardTextMuted, fontFamily: isLifestyle ? LF.body : tokens.bodyFont }}>
                {isLifestyle
                  ? (lifestyleListTab === 'events' ? `${displayLifestyleEvents.length} event${displayLifestyleEvents.length !== 1 ? 's' : ''}` : `${listViewVenues.length} venue${listViewVenues.length !== 1 ? 's' : ''}`)
                  : `${listViewVenues.length + savedEvents.length} place${(listViewVenues.length + savedEvents.length) !== 1 ? 's' : ''}`}
              </p>
            </div>
          </div>
        </div>

        {/* Grid */}
        <div className="px-4 sm:px-6 pb-8">
          {/* Lifestyle event grid */}
          {isLifestyle && lifestyleListTab === 'events' && (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {displayLifestyleEvents.map((event) => (
                  <div key={event.id}>
                    <LifestyleEventGridCard
                      event={event}
                      isSelected={selectedLifestyleEvent?.id === event.id}
                      isHovered={hoveredVenueId === event.id}
                      onSelect={() => selectLifestyleEvent(event)}
                      onHover={() => setHoveredVenueId(event.id)}
                      onLeave={() => setHoveredVenueId(null)}
                    />
                  </div>
                ))}
              </div>
              {displayLifestyleEvents.length === 0 && (
                <div className="text-center py-20">
                  <span className="text-3xl mb-3 block">🌿</span>
                  <p style={{ color: LC.deepForestTextLight, fontFamily: LF.heading, fontSize: '0.9rem' }}>
                    No events match the current filter.
                  </p>
                </div>
              )}
            </>
          )}
          {/* Lifestyle venue grid */}
          {isLifestyle && lifestyleListTab === 'venues' && (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {displayLifestyleVenues.map((venue) => (
                  <div key={venue.id}>{renderVenueCard(venue, 'list')}</div>
                ))}
              </div>
              {displayLifestyleVenues.length === 0 && (
                <div className="text-center py-20">
                  <span className="text-3xl mb-3 block">📍</span>
                  <p style={{ color: LC.deepForestTextLight, fontFamily: LF.heading, fontSize: '0.9rem' }}>
                    No lifestyle venues found.
                  </p>
                </div>
              )}
            </>
          )}
          {/* Saved events in list view (non-lifestyle) */}
          {!isLifestyle && savedEvents.length > 0 && (
            <div className="mb-6">
              <p className="text-xs uppercase tracking-wider mb-3" style={{ color: cardTextMuted, fontFamily: tokens.headingFont, fontWeight: 600 }}>
                Saved Events ({savedEvents.length})
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {savedEvents.map((event) => (
                  <Link
                    key={event.id}
                    to={getEventLink(event)}
                    className="flex items-center gap-3 p-3 transition-all hover:opacity-90 no-underline"
                    style={{
                      borderRadius: isDegen ? '4px' : isArtsy ? '2px' : '12px',
                      border: `1px solid ${cardBorder}`,
                      background: `${modeColor}06`,
                    }}
                  >
                    <div className="h-16 w-16 overflow-hidden flex-shrink-0 relative" style={{ borderRadius: imgRadius }}>
                      <ImageWithFallback src={event.image} alt={event.title} className="h-full w-full object-cover" />
                      <div className="absolute top-1 left-1 p-0.5 rounded-sm" style={{ background: `${modeColor}CC` }}>
                        <Calendar size={10} color="white" />
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="text-sm truncate" style={{ color: cardText, fontFamily: tokens.headingFont, fontWeight: isDegen ? 700 : 500 }}>
                          {getBilingualField(event, 'title', i18n.language)}
                        </span>
                        <Heart size={10} fill={modeColor} style={{ color: modeColor, flexShrink: 0 }} />
                        <ViewsBadge eventId={event.id} />
                      </div>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="flex items-center gap-0.5 text-[11px]" style={{ color: cardTextMuted, fontFamily: tokens.bodyFont }}>
                          <MapPin size={10} /> {getBilingualField(event, 'venueName', i18n.language) || event.district}
                        </span>
                        {event.date && (
                          <span className="flex items-center gap-0.5 text-[11px]" style={{ color: cardTextMuted, fontFamily: tokens.bodyFont }}>
                            <Clock size={10} /> {event.date}
                          </span>
                        )}
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          )}
          {!isLifestyle && savedEvents.length > 0 && listViewVenues.length > 0 && (
            <p className="text-xs uppercase tracking-wider mb-3" style={{ color: cardTextMuted, fontFamily: tokens.headingFont, fontWeight: 600 }}>
              Saved Venues ({listViewVenues.length})
            </p>
          )}
          {!isLifestyle && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {listViewVenues.map((venue) => (
                <div key={venue.id}>{renderVenueCard(venue, 'list')}</div>
              ))}
            </div>
          )}
          {!isLifestyle && listViewVenues.length === 0 && savedEvents.length === 0 && (
            <div className="text-center py-20">
              <span className="text-3xl mb-3 block">&#x1F4CD;</span>
              <p style={{ color: cardTextMuted, fontFamily: tokens.headingFont, fontSize: '0.9rem' }}>
                {t('map.noPlacesFilter')}
              </p>
            </div>
          )}
        </div>

        {/* Selected venue detail overlay */}
        <AnimatePresence>
          {selectedVenue && (
            <div className="fixed inset-0 z-[1050]">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 bg-black/30 backdrop-blur-sm"
                onClick={() => setSelectedVenue(null)}
              />
              <motion.div
                initial={{ x: '100%' }}
                animate={{ x: 0 }}
                exit={{ x: '100%' }}
                transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                className="absolute top-0 right-0 bottom-0 w-full sm:w-[420px]"
              >
                <VenueInfoPanel
                  venue={selectedVenue}
                  onClose={() => setSelectedVenue(null)}
                  onStreetView={() => handleStreetView(selectedVenue)}
                />
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* Lifestyle event detail overlay */}
        <AnimatePresence>
          {selectedLifestyleEvent && (
            <div className="fixed inset-0 z-[1050]">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 bg-black/30 backdrop-blur-sm"
                onClick={() => setSelectedLifestyleEvent(null)}
              />
              <motion.div
                initial={{ x: '100%' }}
                animate={{ x: 0 }}
                exit={{ x: '100%' }}
                transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                className="absolute top-0 right-0 bottom-0 w-full sm:w-[420px]"
              >
                <LifestyleEventPanel event={selectedLifestyleEvent} onClose={() => setSelectedLifestyleEvent(null)} />
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {streetViewVenue && (
            <StreetViewPanel venue={streetViewVenue} onClose={() => setStreetViewVenue(null)} />
          )}
        </AnimatePresence>

        <style>{sharedStyles}</style>
      </div>
    );
  }

  // ══════════════════════════════════════════════
  // SPLIT VIEW
  // ══════════════════════════════════════════════
  if (viewMode === 'split') {
    return (
      <div className="relative h-[calc(100vh-64px)] overflow-hidden flex flex-col sm:flex-row" data-nav-theme={light ? 'dark' : 'light'}>
        {/* Left: Venue list panel — on mobile takes 60% height for more content */}
        <div
          className="w-full sm:w-[380px] lg:w-[440px] flex-shrink-0 h-[60%] sm:h-full overflow-y-auto order-2 sm:order-1 border-r relative"
          style={{ backgroundColor: listPanelBg, borderColor: cardBorder }}
        >
          {/* Panel header — compact on mobile */}
          <div className="sticky top-0 z-10 px-3 sm:px-4 pt-3 sm:pt-4 pb-2 sm:pb-3" style={{ backgroundColor: listPanelBg }}>
            {isLifestyle ? (
              <>
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-[10px] uppercase tracking-[0.2em]" style={{ color: LC.sage, fontFamily: LF.mono, fontWeight: 500 }}>Lifestyle Map</span>
                    </div>
                    <h2 style={{ fontFamily: LF.heading, fontWeight: 900, fontSize: '1.1rem', color: LC.white, letterSpacing: '-0.02em' }}>
                      Discover<span style={{ color: LC.sage, fontWeight: 400, fontStyle: 'italic' }}> nearby</span>.
                    </h2>
                  </div>
                  <div className="flex items-center gap-2">{renderViewToggle()}</div>
                </div>
                <div className="flex items-center gap-2 mb-2">
                  {renderLifestyleTabToggle()}
                  <button onClick={() => setShowSavedOnly(!showSavedOnly)}
                    className="flex items-center gap-1.5 px-2.5 py-1.5 text-[11px] transition-all cursor-pointer"
                    style={{ background: showSavedOnly ? 'rgba(45,106,79,0.25)' : 'rgba(45,106,79,0.1)', border: `1px solid ${showSavedOnly ? LC.forest : LC.deepForestBorder}`, borderRadius: '10px', color: showSavedOnly ? LC.sage : 'rgba(149,213,178,0.5)', fontFamily: LF.body, fontWeight: showSavedOnly ? 600 : 400 }}>
                    <Heart size={11} fill={showSavedOnly ? LC.sage : 'none'} /> Saved
                  </button>
                </div>
                {lifestyleListTab === 'events' && renderLifestyleCategoryPills()}
                <p className="text-[11px] mt-1" style={{ color: LC.deepForestTextLight, fontFamily: LF.body }}>
                  {lifestyleListTab === 'events' ? `${displayLifestyleEvents.length} event${displayLifestyleEvents.length !== 1 ? 's' : ''}` : `${displayLifestyleVenues.length} venue${displayLifestyleVenues.length !== 1 ? 's' : ''}`}
                </p>
              </>
            ) : (
              <>
                <div className="flex items-center justify-between mb-2 sm:mb-3">
                  <div className="flex items-center gap-2 sm:gap-0 sm:flex-col sm:items-start">
                    <h2 className="text-xs sm:text-sm" style={{ fontFamily: tokens.headingFont, color: cardText, fontWeight: isDegen ? 700 : isArtsy ? 400 : 600, textTransform: isDegen ? 'uppercase' : 'none', letterSpacing: isDegen ? '0.03em' : isArtsy ? '0.15em' : 'normal' }}>
                      {showSavedOnly ? (isDegen ? 'VENUES & EVENTS' : 'Venues & Events') : (isDegen ? 'VENUES' : isArtsy ? 'Spaces' : 'Venues')}
                    </h2>
                    <p className="text-[10px] sm:text-[11px] sm:mt-0.5" style={{ color: cardTextMuted, fontFamily: tokens.bodyFont }}>
                      {visibleVenues.length + savedEvents.length} result{(visibleVenues.length + savedEvents.length) !== 1 ? 's' : ''}{searchAsMove && mapBounds ? ' in view' : ''}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button onClick={() => setShowSavedOnly(!showSavedOnly)} className="flex items-center gap-1 px-2 py-1.5 text-[10px] transition-all cursor-pointer flex-shrink-0"
                      style={{ background: showSavedOnly ? `${modeColor}12` : 'transparent', border: `1px solid ${showSavedOnly ? modeColor + '35' : cardBorder}`, borderRadius: isDegen ? '4px' : isArtsy ? '2px' : '8px', color: showSavedOnly ? modeColor : cardTextMuted, fontFamily: tokens.headingFont, fontWeight: showSavedOnly ? 600 : 400 }}>
                      <Heart size={11} fill={showSavedOnly ? modeColor : 'none'} />
                      <span className="hidden sm:inline">Saved</span>
                      {showSavedOnly && allSavedIds.size > 0 && (<span className="text-[9px] px-1 py-0.5 rounded-full" style={{ backgroundColor: `${modeColor}18`, color: modeColor }}>{allSavedIds.size}</span>)}
                    </button>
                    <div className="flex overflow-hidden" style={{ borderRadius: isDegen ? '4px' : isArtsy ? '2px' : '8px', border: `1px solid ${cardBorder}` }}>
                      {viewToggleItems.map((item) => (
                        <button key={item.key} onClick={() => setViewMode(item.key)} className="p-1.5 transition-all cursor-pointer"
                          style={{ background: viewMode === item.key ? (isDegen ? '#EDFF00' : `${modeColor}15`) : 'transparent', color: viewMode === item.key ? (isDegen ? '#0A0A0A' : modeColor) : cardTextMuted }}>
                          <item.icon size={14} />
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex-1 overflow-x-auto scrollbar-hide"><TimePeriodFilter variant="overlay" /></div>
                  <div className="relative w-8 h-[18px] rounded-full transition-colors flex-shrink-0 cursor-pointer"
                    style={{ backgroundColor: searchAsMove ? modeColor : (isDegen ? 'rgba(255,255,255,0.15)' : 'rgba(0,0,0,0.12)') }}
                    onClick={() => setSearchAsMove(!searchAsMove)} title={searchAsMove ? 'Search as I move: ON' : 'Search as I move: OFF'}>
                    <div className="absolute top-[2px] w-[14px] h-[14px] rounded-full bg-white transition-all shadow-sm" style={{ left: searchAsMove ? '16px' : '2px' }} />
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Venue & Event list */}
          <div className="px-3 pb-4 space-y-2">
            {/* Lifestyle split content */}
            {isLifestyle && lifestyleListTab === 'events' && displayLifestyleEvents.map((event) => (
              <LifestyleEventRow key={event.id} event={event}
                isSelected={selectedLifestyleEvent?.id === event.id}
                isHovered={hoveredVenueId === event.id}
                onSelect={() => selectLifestyleEvent(event)}
                onHover={() => setHoveredVenueId(event.id)}
                onLeave={() => setHoveredVenueId(null)} />
            ))}
            {isLifestyle && lifestyleListTab === 'venues' && displayLifestyleVenues.map((venue) => (
              <LifestyleVenueRow key={venue.id} venue={venue}
                isSelected={selectedVenue?.id === venue.id}
                isHovered={hoveredVenueId === venue.id}
                onSelect={() => selectLifestyleVenue(venue)}
                onHover={() => setHoveredVenueId(venue.id)}
                onLeave={() => setHoveredVenueId(null)} />
            ))}
            {isLifestyle && lifestyleListTab === 'events' && displayLifestyleEvents.length === 0 && (
              <div className="text-center py-10"><span className="text-2xl mb-2 block">🌿</span><p className="text-xs" style={{ color: LC.deepForestTextLight }}>No events match filter</p></div>
            )}
            {isLifestyle && lifestyleListTab === 'venues' && displayLifestyleVenues.length === 0 && (
              <div className="text-center py-10"><span className="text-2xl mb-2 block">📍</span><p className="text-xs" style={{ color: LC.deepForestTextLight }}>No lifestyle venues found</p></div>
            )}
            {/* Non-lifestyle: Saved events section */}
            {!isLifestyle && savedEvents.length > 0 && (
              <>
                <p className="text-[10px] uppercase tracking-wider pt-1 pb-0.5" style={{ color: cardTextMuted, fontFamily: tokens.headingFont, fontWeight: 600 }}>
                  Events ({savedEvents.length})
                </p>
                {savedEvents.map((event) => (
                  <Link
                    key={event.id}
                    to={getEventLink(event)}
                    className="flex items-center gap-3 p-2.5 transition-all hover:opacity-90 no-underline"
                    style={{
                      borderRadius: isDegen ? '4px' : isArtsy ? '2px' : '10px',
                      border: `1px solid ${cardBorder}`,
                      background: `${modeColor}06`,
                    }}
                  >
                    <div className="h-14 w-14 overflow-hidden flex-shrink-0 relative" style={{ borderRadius: imgRadius }}>
                      <ImageWithFallback src={event.image} alt={event.title} className="h-full w-full object-cover" />
                      <div className="absolute top-0.5 left-0.5 p-0.5 rounded-sm" style={{ background: `${modeColor}CC` }}>
                        <Calendar size={8} color="white" />
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span
                          className="text-xs truncate"
                          style={{ color: cardText, fontFamily: tokens.headingFont, fontWeight: isDegen ? 700 : 500 }}
                        >
                          {getBilingualField(event, 'title', i18n.language)}
                        </span>
                        <Heart size={9} fill={modeColor} style={{ color: modeColor, flexShrink: 0 }} />
                        <ViewsBadge eventId={event.id} size="xs" />
                      </div>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="flex items-center gap-0.5 text-[10px]" style={{ color: cardTextMuted, fontFamily: tokens.bodyFont }}>
                          <MapPin size={9} /> {getBilingualField(event, 'venueName', i18n.language) || event.district}
                        </span>
                        {event.date && (
                          <span className="flex items-center gap-0.5 text-[10px]" style={{ color: cardTextMuted, fontFamily: tokens.bodyFont }}>
                            <Clock size={9} /> {event.date}
                          </span>
                        )}
                      </div>
                    </div>
                  </Link>
                ))}
                {visibleVenues.length > 0 && (
                  <p className="text-[10px] uppercase tracking-wider pt-2 pb-0.5" style={{ color: cardTextMuted, fontFamily: tokens.headingFont, fontWeight: 600 }}>
                    Venues ({visibleVenues.length})
                  </p>
                )}
              </>
            )}
            {!isLifestyle && visibleVenues.map((venue) => (
              <div key={venue.id}>{renderVenueCard(venue, 'split')}</div>
            ))}
            {!isLifestyle && visibleVenues.length === 0 && savedEvents.length === 0 && (
              <div className="text-center py-12">
                <span className="text-2xl mb-2 block">&#x1F4CD;</span>
                <p className="text-xs" style={{ color: cardTextMuted }}>{t('map.noPlacesFound')}</p>
              </div>
            )}
          </div>
        </div>

        {/* Right: Map — on mobile takes 40% */}
        <div className="flex-1 relative order-1 sm:order-2 h-[40%] sm:h-full">
          {renderMap('h-full w-full')}

          <AnimatePresence>
            {isTransitioning && (
              <motion.div
                key={`mode-transition-${currentMode}`}
                initial={{ opacity: 0.7 }}
                animate={{ opacity: 0 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.6, ease: 'easeOut' }}
                className="absolute inset-0 z-[999] pointer-events-none"
                style={{ backgroundColor: tokens.pageBg }}
              />
            )}
          </AnimatePresence>

          {/* Floating controls on map */}
          <div className="absolute top-4 left-3 right-3 z-[1000] flex items-start justify-between gap-2 pointer-events-none">
            <div className="pointer-events-auto hidden sm:block">
              <div
                className="backdrop-blur-xl p-2"
                style={{ background: overlayBg, border: `1px solid ${overlayBorder}`, borderRadius: overlayRadius, boxShadow: overlayShadow }}
              >
                <ModeSelector compact />
              </div>
            </div>
            <div className="pointer-events-auto flex gap-2">
              <div className="backdrop-blur-xl flex overflow-hidden" style={{ background: overlayBg, border: `1px solid ${overlayBorder}`, borderRadius: overlayRadius, boxShadow: overlayShadow }}>
                {(['dark', 'light', 'satellite'] as const).map((style) => (
                  <button
                    key={style}
                    onClick={() => setMapStyle(style)}
                    className="px-2.5 py-1.5 text-[10px] transition-all"
                    style={{
                      background: mapStyle === style ? (isDegen ? 'rgba(0,0,0,0.9)' : light ? 'rgba(0,0,0,0.08)' : 'rgba(255,255,255,0.15)') : 'transparent',
                      color: mapStyle === style ? (isDegen ? '#EDFF00' : overlayText) : overlayTextMuted,
                      fontFamily: tokens.headingFont,
                      fontWeight: isDegen ? 700 : 400,
                    }}
                  >
                    {style === 'dark' ? 'D' : style === 'light' ? 'L' : 'S'}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Venue info panel slides over map */}
          <AnimatePresence>
            {selectedVenue && (
              <VenueInfoPanel
                venue={selectedVenue}
                onClose={() => setSelectedVenue(null)}
                onStreetView={() => handleStreetView(selectedVenue)}
              />
            )}
          </AnimatePresence>
          {/* Lifestyle event detail panel */}
          <AnimatePresence>
            {selectedLifestyleEvent && (
              <LifestyleEventPanel event={selectedLifestyleEvent} onClose={() => setSelectedLifestyleEvent(null)} />
            )}
          </AnimatePresence>
        </div>

        {/* Mobile: mode selector + view toggle floating at top */}
        <div className="absolute top-2 left-2 right-2 z-[1001] sm:hidden pointer-events-none">
          <div className="pointer-events-auto flex gap-2 justify-between">
            <div
              className="backdrop-blur-xl p-1.5 overflow-x-auto scrollbar-hide flex-1"
              style={{ background: overlayBg, border: `1px solid ${overlayBorder}`, borderRadius: overlayRadius, boxShadow: overlayShadow }}
            >
              <ModeSelector compact />
            </div>
            <div className="backdrop-blur-xl flex overflow-hidden flex-shrink-0" style={{ background: overlayBg, border: `1px solid ${overlayBorder}`, borderRadius: overlayRadius, boxShadow: overlayShadow }}>
              {viewToggleItems.map((item) => (
                <button
                  key={item.key}
                  onClick={() => setViewMode(item.key)}
                  className="p-2 transition-all cursor-pointer"
                  style={{
                    background: viewMode === item.key ? (isDegen ? 'rgba(0,0,0,0.9)' : light ? 'rgba(0,0,0,0.08)' : 'rgba(255,255,255,0.15)') : 'transparent',
                    color: viewMode === item.key ? (isDegen ? '#EDFF00' : overlayText) : overlayTextMuted,
                  }}
                >
                  <item.icon size={14} />
                </button>
              ))}
            </div>
          </div>
        </div>

        <AnimatePresence>
          {streetViewVenue && (
            <StreetViewPanel venue={streetViewVenue} onClose={() => setStreetViewVenue(null)} />
          )}
        </AnimatePresence>

        <style>{sharedStyles}</style>
      </div>
    );
  }

  // ═════════════════════════════════════════════
  // MAP VIEW (original full-screen)
  // ═════════════════════════════════════════════
  return (
    <div className="relative h-[calc(100vh-64px)] overflow-hidden" data-nav-theme={light ? 'dark' : 'light'}>
      {renderMap()}

      <AnimatePresence>
        {isTransitioning && (
          <motion.div
            key={`mode-transition-${currentMode}`}
            initial={{ opacity: 0.7 }}
            animate={{ opacity: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.6, ease: 'easeOut' }}
            className="absolute inset-0 z-[999] pointer-events-none"
            style={{ backgroundColor: tokens.pageBg }}
          />
        )}
      </AnimatePresence>

      {/* ── DESKTOP top bar overlay ── */}
      <motion.div
        key={`topbar-${currentMode}`}
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
        className="absolute top-4 left-4 right-4 z-[1000] hidden sm:flex flex-col gap-2 pointer-events-none"
      >
        <div className="flex flex-row items-start justify-between">
          <div className="pointer-events-auto">
            <div
              className="backdrop-blur-xl p-2"
              style={{ background: overlayBg, border: `1px solid ${overlayBorder}`, borderRadius: overlayRadius, boxShadow: overlayShadow }}
            >
              <ModeSelector compact />
            </div>
          </div>

          <div className="pointer-events-auto flex gap-2 flex-wrap">
            {renderViewToggle()}
            <button
              onClick={() => setShowSavedOnly(!showSavedOnly)}
              className="backdrop-blur-xl flex items-center gap-1.5 px-3 py-2 text-xs transition-all hover:opacity-80 cursor-pointer"
              style={{
                background: showSavedOnly ? `${modeColor}15` : overlayBg,
                border: `1px solid ${showSavedOnly ? modeColor + '40' : overlayBorder}`,
                borderRadius: overlayRadius,
                color: showSavedOnly ? modeColor : overlayTextMuted,
                boxShadow: overlayShadow,
                fontFamily: tokens.headingFont,
                fontWeight: showSavedOnly ? 600 : 400,
              }}
            >
              <Heart size={14} fill={showSavedOnly ? modeColor : 'none'} />
              <span className="hidden sm:inline">Saved</span>
              {showSavedOnly && allSavedIds.size > 0 && (
                <span className="text-[10px] px-1.5 py-0.5 rounded-full" style={{ backgroundColor: `${modeColor}20`, color: modeColor }}>{allSavedIds.size}</span>
              )}
            </button>
            <button
              onClick={() => setFilterOpen(!filterOpen)}
              className="backdrop-blur-xl p-2.5 transition-all hover:opacity-80"
              style={{ background: overlayBg, border: `1px solid ${overlayBorder}`, borderRadius: overlayRadius, color: overlayTextMuted, boxShadow: overlayShadow }}
            >
              <Filter size={16} />
            </button>
            <div className="backdrop-blur-xl flex overflow-hidden" style={{ background: overlayBg, border: `1px solid ${overlayBorder}`, borderRadius: overlayRadius, boxShadow: overlayShadow }}>
              {(['dark', 'light', 'satellite'] as const).map((style) => (
                <button
                  key={style}
                  onClick={() => setMapStyle(style)}
                  className="px-3 py-2 text-xs transition-all"
                  style={{
                    background: mapStyle === style ? (isDegen ? 'rgba(0,0,0,0.9)' : light ? 'rgba(0,0,0,0.08)' : 'rgba(255,255,255,0.15)') : 'transparent',
                    color: mapStyle === style ? (isDegen ? '#EDFF00' : overlayText) : overlayTextMuted,
                    fontFamily: tokens.headingFont,
                    fontWeight: isDegen ? 700 : 400,
                  }}
                >
                  {style === 'dark' ? 'Dark' : style === 'light' ? 'Light' : 'Satellite'}
                </button>
              ))}
            </div>
          </div>
        </div>

        {isLifestyle ? (
          <div className="pointer-events-auto self-start flex items-center gap-2">
            <div className="backdrop-blur-xl p-1.5 overflow-x-auto scrollbar-hide inline-flex" style={{ background: 'rgba(18,42,32,0.85)', borderRadius: '12px', border: `1px solid ${LC.deepForestBorder}` }}>
              {renderLifestyleCategoryPills('floating')}
            </div>
          </div>
        ) : (
          <div className="pointer-events-auto self-start">
            <div
              className="backdrop-blur-xl p-1.5"
              style={{ background: overlayBg, border: `1px solid ${overlayBorder}`, borderRadius: overlayRadius, boxShadow: overlayShadow }}
            >
              <TimePeriodFilter variant="overlay" />
            </div>
          </div>
        )}
      </motion.div>

      {/* ── MOBILE compact top bar ── */}
      <div className="absolute top-3 left-3 right-3 z-[1000] sm:hidden pointer-events-none">
        {/* Row 1: Mode pills + compact controls */}
        <div className="pointer-events-auto flex gap-1.5 items-center mb-1.5">
          <div
            className="backdrop-blur-xl p-1.5 overflow-x-auto scrollbar-hide flex-1 min-w-0"
            style={{ background: overlayBg, border: `1px solid ${overlayBorder}`, borderRadius: overlayRadius, boxShadow: overlayShadow }}
          >
            <ModeSelector compact />
          </div>
          {/* Compact icon-only controls */}
          <div className="flex gap-1 flex-shrink-0">
            {renderViewToggle()}
            <button
              onClick={() => setMobileControlsOpen(!mobileControlsOpen)}
              className="backdrop-blur-xl p-2 transition-all cursor-pointer"
              style={{
                background: mobileControlsOpen ? (isDegen ? 'rgba(0,0,0,0.9)' : `${modeColor}15`) : overlayBg,
                border: `1px solid ${overlayBorder}`,
                borderRadius: overlayRadius,
                color: mobileControlsOpen ? (isDegen ? '#EDFF00' : modeColor) : overlayTextMuted,
                boxShadow: overlayShadow,
              }}
            >
              {mobileControlsOpen ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
            </button>
          </div>
        </div>

        {/* Row 2: Collapsible panel with time filter + map style */}
        <AnimatePresence>
          {mobileControlsOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.2 }}
              className="pointer-events-auto overflow-hidden"
            >
              <div
                className="backdrop-blur-xl p-2 flex flex-col gap-2"
                style={{ background: overlayBg, border: `1px solid ${overlayBorder}`, borderRadius: overlayRadius, boxShadow: overlayShadow }}
              >
                <div className="overflow-x-auto scrollbar-hide">
                  <TimePeriodFilter variant="overlay" />
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex overflow-hidden flex-1" style={{ borderRadius: overlayRadius, border: `1px solid ${overlayBorder}` }}>
                    {(['dark', 'light', 'satellite'] as const).map((style) => (
                      <button
                        key={style}
                        onClick={() => setMapStyle(style)}
                        className="flex-1 px-2 py-1.5 text-[10px] transition-all cursor-pointer"
                        style={{
                          background: mapStyle === style ? (isDegen ? 'rgba(0,0,0,0.9)' : light ? 'rgba(0,0,0,0.08)' : 'rgba(255,255,255,0.15)') : 'transparent',
                          color: mapStyle === style ? (isDegen ? '#EDFF00' : overlayText) : overlayTextMuted,
                          fontFamily: tokens.headingFont,
                          fontWeight: isDegen ? 700 : 400,
                        }}
                      >
                        {style === 'dark' ? 'Dark' : style === 'light' ? 'Light' : 'Sat'}
                      </button>
                    ))}
                  </div>
                  <button
                    onClick={() => { setFilterOpen(!filterOpen); setMobileControlsOpen(false); }}
                    className="p-1.5 transition-all cursor-pointer"
                    style={{ color: overlayTextMuted }}
                  >
                    <Filter size={14} />
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Map legend — only show when there are community events */}
      {mapVenues.some(v => v.id?.startsWith('sub_')) && (
        <div className="absolute bottom-24 sm:bottom-20 left-4 z-[1000] pointer-events-auto">
          <div className="backdrop-blur-xl px-3 py-2 flex flex-col gap-1.5" style={{ background: overlayBg, border: `1px solid ${overlayBorder}`, borderRadius: '10px', boxShadow: overlayShadow }}>
            <div className="flex items-center gap-2">
              <div style={{ width: 12, height: 12, borderRadius: '50%', border: `2px solid ${modeColor}`, background: `${modeColor}20` }} />
              <span className="text-[10px]" style={{ color: overlayTextMuted, fontFamily: tokens.bodyFont }}>Venue</span>
            </div>
            <div className="flex items-center gap-2">
              <div style={{ width: 12, height: 12, borderRadius: '50%', border: `2.5px solid ${modeColor}`, background: `linear-gradient(135deg, ${modeColor}18, ${modeColor}30)`, position: 'relative' }}>
                <span style={{ position: 'absolute', top: -3, right: -3, fontSize: '6px', background: '#10b981', color: 'white', borderRadius: '50%', width: 7, height: 7, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>·</span>
              </div>
              <span className="text-[10px]" style={{ color: overlayTextMuted, fontFamily: tokens.bodyFont }}>Community Event</span>
            </div>
          </div>
        </div>
      )}

      {/* Bottom venue carousel */}
      <motion.div
        key={`bottombar-${currentMode}`}
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
        className="absolute bottom-4 left-0 right-0 z-[1000] px-4 pointer-events-none"
      >
        {/* Search banner */}
        {renderSearchBanner('floating')}
        {/* Search as I move toggle + count badge */}
        <div className="pointer-events-auto flex items-center gap-2 mb-2">
          <button
            onClick={() => setSearchAsMove(!searchAsMove)}
            className="backdrop-blur-xl flex items-center gap-2 px-3 py-1.5 text-[11px] transition-all cursor-pointer"
            style={{
              background: overlayBg,
              border: `1px solid ${searchAsMove ? modeColor + '40' : overlayBorder}`,
              borderRadius: overlayRadius,
              boxShadow: overlayShadow,
              color: searchAsMove ? overlayText : overlayTextMuted,
              fontFamily: tokens.bodyFont,
            }}
          >
            <Search size={12} />
            <span>Search as I move</span>
            <div
              className="relative w-7 h-[16px] rounded-full transition-colors"
              style={{ backgroundColor: searchAsMove ? modeColor : (isDegen ? 'rgba(0,0,0,0.2)' : 'rgba(0,0,0,0.12)') }}
            >
              <div
                className="absolute top-[2px] w-[12px] h-[12px] rounded-full bg-white transition-all shadow-sm"
                style={{ left: searchAsMove ? '13px' : '2px' }}
              />
            </div>
          </button>
          {searchAsMove && mapBounds && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="backdrop-blur-xl px-2.5 py-1 text-[11px]"
              style={{
                background: overlayBg,
                border: `1px solid ${overlayBorder}`,
                borderRadius: overlayRadius,
                boxShadow: overlayShadow,
                color: overlayText,
                fontFamily: tokens.headingFont,
                fontWeight: 600,
              }}
            >
              {mapVenues.length + savedEventsWithCoords.length} place{(mapVenues.length + savedEventsWithCoords.length) !== 1 ? 's' : ''} in view
            </motion.div>
          )}
        </div>
        <div className="pointer-events-auto flex gap-3 overflow-x-auto pb-2 scrollbar-hide snap-x snap-mandatory">
          {/* Lifestyle event cards in carousel */}
          {isLifestyle && lifestyleEventsWithCoords.map((event) => (
            <motion.button
              key={`ls-event-${event.id}`}
              whileHover={{ y: -2 }}
              onClick={() => selectLifestyleEvent(event)}
              className="flex-shrink-0 flex items-center gap-3 backdrop-blur-xl p-3 transition-all snap-start cursor-pointer"
              style={{ borderRadius: '16px', background: cardBg, border: selectedLifestyleEvent?.id === event.id ? `2px solid ${LC.forest}` : `1px solid ${cardBorder}`, boxShadow: overlayShadow }}
            >
              <div className="h-12 w-12 overflow-hidden flex-shrink-0" style={{ borderRadius: '12px' }}>
                <ImageWithFallback src={event.image} alt={event.title} className="h-full w-full object-cover" />
              </div>
              <div className="text-left">
                <span className="text-sm block" style={{ color: cardText, fontFamily: LF.heading, fontWeight: 800, fontSize: '0.875rem' }}>{event.title}</span>
                <div className="flex items-center gap-2">
                  <span className="text-[10px]" style={{ color: cardTextMuted, fontFamily: LF.body }}>{event.district}</span>
                  <ViewsBadge eventId={event.id} size="xs" />
                </div>
              </div>
            </motion.button>
          ))}
          {/* Saved event cards in carousel */}
          {savedEventsWithCoords.map((event) => (
            <motion.div
              key={`carousel-event-${event.id}`}
              whileHover={{ y: -2 }}
              className="flex-shrink-0 flex items-center gap-3 backdrop-blur-xl p-3 transition-all snap-start cursor-pointer"
              style={{
                borderRadius: overlayRadius,
                background: cardBg,
                border: `1px solid ${cardBorder}`,
                boxShadow: overlayShadow,
              }}
              onClick={() => {
                if ((event as any).sourceUrl) window.open((event as any).sourceUrl, '_blank');
              }}
            >
              <div className="h-12 w-12 overflow-hidden flex-shrink-0 flex items-center justify-center" style={{ borderRadius: imgRadius, backgroundColor: `${modeColor}15` }}>
                {event.image ? (
                  <ImageWithFallback src={event.image} alt={getBilingualField(event, 'title', i18n.language)} className="h-full w-full object-cover" />
                ) : (
                  <Calendar size={18} style={{ color: modeColor }} />
                )}
              </div>
              <div className="text-left">
                <div className="flex items-center gap-1.5">
                  <Calendar size={12} style={{ color: modeColor }} />
                  <span className="text-sm" style={{ color: cardText, fontFamily: tokens.headingFont, fontWeight: 500, fontSize: '0.875rem' }}>
                    {getBilingualField(event, 'title', i18n.language)}
                  </span>
                  <Heart size={10} fill={modeColor} style={{ color: modeColor, flexShrink: 0 }} />
                  <ViewsBadge eventId={event.id} size="xs" />
                </div>
                <span className="text-[10px]" style={{ color: cardTextMuted, fontFamily: tokens.bodyFont }}>
                  {getBilingualField(event, 'venueName', i18n.language) || event.district}
                </span>
              </div>
            </motion.div>
          ))}
          {mapVenues.map((venue) => {
            const isSelected = selectedVenue?.id === venue.id;
            return (
              <motion.button
                key={venue.id}
                onClick={() => setSelectedVenue(venue)}
                whileHover={{ y: -2 }}
                className="flex-shrink-0 flex items-center gap-3 backdrop-blur-xl p-3 transition-all snap-start cursor-pointer"
                onMouseEnter={() => setHoveredVenueId(venue.id)}
                onMouseLeave={() => setHoveredVenueId(null)}
                style={{
                  borderRadius: overlayRadius,
                  background: isSelected ? (isDegen ? 'rgba(10,10,10,0.95)' : cardBg) : cardBg,
                  border: isSelected ? `2px solid ${isDegen ? '#EDFF00' : `${modeColor}40`}` : `1px solid ${cardBorder}`,
                  boxShadow: overlayShadow,
                }}
              >
                <div className="h-12 w-12 overflow-hidden flex-shrink-0" style={{ borderRadius: imgRadius }}>
                  <ImageWithFallback src={venue.image} alt={venue.name} className="h-full w-full object-cover" />
                </div>
                <div className="text-left">
                  <div className="flex items-center gap-1.5">
                    <CIcon id={venue.category} size={14} mode="auto" />
                    <span
                      className="text-sm"
                      style={{ color: cardText, fontFamily: tokens.headingFont, fontWeight: isDegen ? 700 : 500, textTransform: isDegen ? 'uppercase' : 'none', fontSize: isDegen ? '0.75rem' : '0.875rem' }}
                    >
                      {venue.name}
                    </span>
                    {allSavedIds.has(venue.id) && (
                      <Heart size={10} fill={modeColor} style={{ color: modeColor, flexShrink: 0 }} />
                    )}
                  </div>
                  <span className="text-[10px]" style={{ color: cardTextMuted, fontFamily: tokens.bodyFont }}>{venue.district}</span>
                </div>
                {currentMode && currentMode !== 'lifestyle' && (
                  <div
                    className="px-2 py-0.5 text-[10px] ml-2"
                    style={{
                      backgroundColor: isDegen ? 'rgba(237,255,0,0.15)' : `${modeColor}20`,
                      color: isDegen ? '#EDFF00' : modeColor,
                      borderRadius: isDegen ? '2px' : isArtsy ? '0' : '9999px',
                      fontFamily: tokens.headingFont,
                      fontWeight: isDegen ? 700 : 400,
                    }}
                  >
                    {Math.round((venue.modeScores[currentMode] || 0) * 100)}%
                  </div>
                )}
              </motion.button>
            );
          })}
        </div>
      </motion.div>

      <AnimatePresence>
        {selectedVenue && (
          <VenueInfoPanel
            venue={selectedVenue}
            onClose={() => setSelectedVenue(null)}
            onStreetView={() => handleStreetView(selectedVenue)}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {selectedLifestyleEvent && (
          <LifestyleEventPanel event={selectedLifestyleEvent} onClose={() => setSelectedLifestyleEvent(null)} />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {streetViewVenue && (
          <StreetViewPanel venue={streetViewVenue} onClose={() => setStreetViewVenue(null)} />
        )}
      </AnimatePresence>

      <style>{sharedStyles}</style>
    </div>
  );
}