import { useState, useMemo, useEffect, useCallback } from 'react';
import { Link, useNavigate } from 'react-router';
import { useTranslation } from 'react-i18next';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowUpRight, ArrowLeft, Sun, Moon, Sparkles, X } from 'lucide-react';
import { useData } from '../context/DataContext';
import { useMode } from '../context/ModeContext';
import type { UIMode } from '../context/ModeContext';
import { useAuth } from '../context/AuthContext';
import { parseEventDate } from '../utils/date-helpers';
import { getEventLink } from '../utils/event-helpers';
import { getBilingualField } from '../utils/bilingual';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import { useNeutralTheme, NeutralThemeProvider } from '../context/NeutralThemeContext';
import { getTasteProfile, OnboardingQuiz, type TasteProfile } from '../components/OnboardingQuiz';
import { scoreEventsRaw } from '../utils/score-events';

// ═══════════════════════════════════════════════════════════════════
// WHAT'S ON — Expanded mobile browse page
//
// 3-tab layout: What's On | Filter | Thematic
// Accessible from the homepage "Explore" link
// ════════════════════════════════════════════════════════════════════

const PAD = '5vw';

const labelStyle: React.CSSProperties = {
  fontSize: '0.55rem',
  fontWeight: 600,
  letterSpacing: '0.18em',
  textTransform: 'uppercase',
  color: 'var(--n-muted)',
};

type Tab = 'whats-on' | 'filter' | 'thematic';

const CATEGORIES = [
  { id: 'art', en: 'Art', zh: '藝術' },
  { id: 'food', en: 'Food', zh: '美食' },
  { id: 'music', en: 'Music', zh: '音樂' },
  { id: 'design', en: 'Design', zh: '設計' },
  { id: 'film', en: 'Film', zh: '電影' },
  { id: 'theatre', en: 'Theatre', zh: '戲劇' },
  { id: 'wellness', en: 'Wellness', zh: '身心' },
];

const SUBCATEGORIES: Record<string, { en: string; zh: string }[]> = {
  art: [
    { en: 'Gallery', zh: '畫廊' },
    { en: 'Exhibition', zh: '展覽' },
    { en: 'Workshop', zh: '工作坊' },
  ],
  food: [
    { en: 'Pop-up', zh: '快閃' },
    { en: 'Market', zh: '市集' },
    { en: 'Tasting', zh: '品嚐' },
  ],
  music: [
    { en: 'Live', zh: '現場' },
    { en: 'DJ', zh: 'DJ' },
    { en: 'Festival', zh: '音樂節' },
  ],
  design: [
    { en: 'Talk', zh: '講座' },
    { en: 'Fair', zh: '展覽' },
    { en: 'Studio', zh: '工作室' },
  ],
  film: [
    { en: 'Screening', zh: '放映' },
    { en: 'Festival', zh: '影展' },
  ],
  theatre: [
    { en: 'Play', zh: '話劇' },
    { en: 'Dance', zh: '舞蹈' },
  ],
  wellness: [
    { en: 'Yoga', zh: '瑜伽' },
    { en: 'Outdoor', zh: '戶外' },
  ],
};

const THEMATIC_MODES: { key: UIMode; en: string; zh: string; categories: string[] }[] = [
  { key: 'foodie', en: 'Food &\nDrink', zh: '美食', categories: ['food', 'coffee-raves'] },
  { key: 'artsy', en: 'Gallery\nTour', zh: '藝術探索', categories: ['art'] },
  { key: 'degen', en: 'Weekend\nRager', zh: '週末派對', categories: ['nightlife'] },
  { key: 'family', en: 'Family\nFun', zh: '親子活動', categories: ['family'] },
  { key: 'lifestyle', en: 'Wellness\nDay', zh: '身心靈', categories: ['wellness', 'run-clubs', 'hikes'] },
  { key: 'artsy', en: 'Design\nWalk', zh: '設計漫步', categories: ['art', 'workshops'] },
];

function formatTime(time?: string, dateStr?: string): string {
  if (time) return time;
  const d = parseEventDate(dateStr || '');
  if (!d) return '';
  return d.toLocaleTimeString('en', { hour: 'numeric', minute: '2-digit', hour12: true });
}

// ─── Event Row ───
function EventRow({ event, lang, isZh }: { event: any; lang: string; isZh: boolean }) {
  const title = getBilingualField(event, 'title', lang);
  const district = getBilingualField(event, 'district', lang) || event.district || '';
  const venueName = getBilingualField(event, 'venueName', lang) || event.venueName || '';

  return (
    <Link to={getEventLink(event)} className="block group">
      <div
        className="flex items-stretch gap-0"
        style={{ borderBottom: '1px solid var(--n-border)' }}
      >
        {/* Time */}
        <div
          className="flex items-center justify-center flex-shrink-0"
          style={{ width: '54px', padding: '12px 6px', borderRight: '1px solid var(--n-border)' }}
        >
          <span style={{ fontSize: '0.6rem', fontWeight: 600, color: 'var(--n-muted)', textAlign: 'center', lineHeight: 1.3 }}>
            {formatTime(event.time, event.date) || '—'}
          </span>
        </div>

        {/* Thumbnail */}
        <div
          className="flex-shrink-0 flex items-center justify-center"
          style={{ width: '56px', padding: '8px', borderRight: '1px solid var(--n-border)' }}
        >
          <div className="w-10 h-10 rounded overflow-hidden" style={{ backgroundColor: 'var(--n-bg-alt)' }}>
            {event.image ? (
              <ImageWithFallback src={event.image} alt={title} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <span style={{ fontSize: '0.5rem', color: 'var(--n-muted)' }}>IMG</span>
              </div>
            )}
          </div>
        </div>

        {/* Details */}
        <div className="flex-1 min-w-0 py-2.5 px-3 flex flex-col justify-center">
          <h4
            className="truncate group-hover:opacity-60 transition-opacity"
            style={{
              fontFamily: "'Archivo Black', sans-serif",
              fontSize: '0.8rem',
              color: 'var(--n-text)',
              letterSpacing: '-0.02em',
              lineHeight: 1.2,
              marginBottom: '2px',
            }}
          >
            {title}
          </h4>
          <p className="truncate" style={{ fontSize: '0.6rem', color: 'var(--n-secondary)', lineHeight: 1.4 }}>
            {event.category}{district ? ` · ${district}` : ''}
          </p>
          <p className="truncate" style={{ fontSize: '0.55rem', color: 'var(--n-muted)', lineHeight: 1.4, marginTop: '1px' }}>
            {venueName}
          </p>
        </div>
      </div>
    </Link>
  );
}

// ─── What's On tab ───
function WhatsOnTab({ lang, isZh }: { lang: string; isZh: boolean }) {
  const { events } = useData();
  const { user, savedEventIds } = useAuth();
  const [tasteProfile, setTasteProfile] = useState<TasteProfile | null>(() => getTasteProfile());
  const [showQuizInline, setShowQuizInline] = useState(false);

  const refreshProfile = useCallback(() => {
    setTasteProfile(getTasteProfile());
    setShowQuizInline(false);
  }, []);

  const isPersonalized = !!tasteProfile || (!!user && savedEventIds.length > 0);

  const activeEvents = useMemo(() => {
    const pool = events.filter(e => e.status === 'upcoming' || e.status === 'ongoing');

    if (isPersonalized) {
      // Score and sort by relevance
      const scored = scoreEventsRaw(pool, tasteProfile, user ? savedEventIds : [], events);
      return scored.map(s => s.event).slice(0, 30);
    }

    // Default: just show upcoming, capped
    return pool.slice(0, 20);
  }, [events, tasteProfile, user, savedEventIds, isPersonalized]);

  if (activeEvents.length === 0) {
    return (
      <div className="flex items-center justify-center py-16">
        <p style={{ fontSize: '0.75rem', color: 'var(--n-muted)' }}>{isZh ? '暫無活動' : 'No events right now'}</p>
      </div>
    );
  }

  return (
    <div style={{ borderTop: '1px solid var(--n-border)' }}>
      {/* Personalization banner */}
      {isPersonalized ? (
        <div
          className="flex items-center gap-2 px-3 py-2.5"
          style={{ borderBottom: '1px solid var(--n-border)', backgroundColor: 'var(--n-bg-alt)' }}
        >
          <Sparkles size={11} style={{ color: 'var(--n-secondary)', flexShrink: 0 }} />
          <span style={{ fontSize: '0.6rem', color: 'var(--n-secondary)', fontWeight: 500 }}>
            {isZh ? '根據你的口味排序' : 'Sorted by your taste profile'}
          </span>
          <button
            onClick={() => setShowQuizInline(true)}
            className="ml-auto cursor-pointer transition-opacity hover:opacity-60"
            style={{ ...labelStyle, border: 'none', background: 'none', fontSize: '0.5rem', color: 'var(--n-muted)' }}
          >
            {isZh ? '更新' : 'Update'}
          </button>
        </div>
      ) : (
        <button
          onClick={() => setShowQuizInline(true)}
          className="w-full flex items-center gap-2 px-3 py-3 cursor-pointer transition-colors hover:opacity-80"
          style={{ borderBottom: '1px solid var(--n-border)', background: 'none', border: 'none', borderBottomWidth: 1, borderBottomStyle: 'solid', borderBottomColor: 'var(--n-border)' }}
        >
          <Sparkles size={11} style={{ color: 'var(--n-muted)', flexShrink: 0 }} />
          <span style={{ fontSize: '0.6rem', color: 'var(--n-secondary)', fontWeight: 500 }}>
            {isZh ? '回答幾個問題，為你個人化排序' : 'Take a quick quiz to personalize this list'}
          </span>
          <ArrowUpRight size={10} style={{ color: 'var(--n-muted)', marginLeft: 'auto' }} />
        </button>
      )}

      {/* Inline quiz */}
      <AnimatePresence>
        {showQuizInline && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25 }}
            style={{ overflow: 'hidden', borderBottom: '1px solid var(--n-border)' }}
          >
            <div className="py-3 px-1">
              <div className="flex items-center justify-between mb-2">
                <span style={{ ...labelStyle, fontSize: '0.5rem' }}>{isZh ? '口味測驗' : 'Taste Quiz'}</span>
                <button
                  onClick={() => setShowQuizInline(false)}
                  className="cursor-pointer"
                  style={{ background: 'none', border: 'none', color: 'var(--n-muted)', padding: '0.25rem' }}
                >
                  <X size={12} />
                </button>
              </div>
              <OnboardingQuiz
                onComplete={refreshProfile}
                compact
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {activeEvents.map(event => (
        <EventRow key={event.id} event={event} lang={lang} isZh={isZh} />
      ))}
      <Link
        to="/events"
        className="flex items-center justify-center gap-1.5 py-4 transition-opacity hover:opacity-60"
        style={{ ...labelStyle, color: 'var(--n-secondary)' }}
      >
        {isZh ? '查看全部活動' : 'View all events'}
        <ArrowUpRight size={10} />
      </Link>
    </div>
  );
}

// ─── Filter tab ───
function FilterTab({
  lang, isZh, selectedCategory, setSelectedCategory, selectedDateRange, setSelectedDateRange, onApply,
}: {
  lang: string; isZh: boolean;
  selectedCategory: string | null; setSelectedCategory: (c: string | null) => void;
  selectedDateRange: string; setSelectedDateRange: (d: string) => void;
  onApply: () => void;
}) {
  const subs = selectedCategory ? SUBCATEGORIES[selectedCategory] || [] : [];
  const dateOptions = [
    { id: 'today', en: 'Today', zh: '今天' },
    { id: 'tomorrow', en: 'Tomorrow', zh: '明天' },
    { id: 'weekend', en: 'This Weekend', zh: '週末' },
    { id: 'week', en: 'This Week', zh: '本週' },
    { id: 'month', en: 'This Month', zh: '本月' },
  ];

  return (
    <div style={{ borderTop: '1px solid var(--n-border)' }}>
      <div className="flex" style={{ minHeight: '280px' }}>
        {/* Dates */}
        <div className="flex-shrink-0" style={{ width: '30%', borderRight: '1px solid var(--n-border)', padding: '12px' }}>
          <p style={{ ...labelStyle, marginBottom: '10px', fontSize: '0.5rem' }}>{isZh ? '日期' : 'Dates'}</p>
          {dateOptions.map(d => (
            <button
              key={d.id}
              onClick={() => setSelectedDateRange(d.id)}
              className="block w-full text-left py-2 px-1 cursor-pointer rounded"
              style={{
                fontSize: '0.7rem',
                color: selectedDateRange === d.id ? 'var(--n-text)' : 'var(--n-secondary)',
                fontWeight: selectedDateRange === d.id ? 600 : 400,
                background: selectedDateRange === d.id ? 'var(--n-bg-alt)' : 'none',
                border: 'none',
              }}
            >
              {isZh ? d.zh : d.en}
            </button>
          ))}
        </div>

        {/* Categories */}
        <div className="flex-1" style={{ borderRight: subs.length > 0 ? '1px solid var(--n-border)' : 'none', padding: '12px' }}>
          <p style={{ ...labelStyle, marginBottom: '10px', fontSize: '0.5rem' }}>{isZh ? '類型' : 'Category'}</p>
          <ul className="space-y-0.5">
            {CATEGORIES.map(cat => (
              <li key={cat.id}>
                <button
                  onClick={() => setSelectedCategory(selectedCategory === cat.id ? null : cat.id)}
                  className="flex items-center gap-2 w-full text-left py-2 px-1 cursor-pointer rounded"
                  style={{
                    fontSize: '0.7rem',
                    color: selectedCategory === cat.id ? 'var(--n-text)' : 'var(--n-secondary)',
                    fontWeight: selectedCategory === cat.id ? 600 : 400,
                    background: selectedCategory === cat.id ? 'var(--n-bg-alt)' : 'none',
                    border: 'none',
                  }}
                >
                  <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{
                    backgroundColor: selectedCategory === cat.id ? 'var(--n-text)' : 'transparent',
                    border: `1px solid ${selectedCategory === cat.id ? 'var(--n-text)' : 'var(--n-border)'}`,
                  }} />
                  {isZh ? cat.zh : cat.en}
                </button>
              </li>
            ))}
          </ul>
        </div>

        {/* Subcategories */}
        {subs.length > 0 && (
          <div className="flex-1" style={{ padding: '12px' }}>
            <p style={{ ...labelStyle, marginBottom: '10px', fontSize: '0.5rem' }}>{isZh ? '子分類' : 'Subcategory'}</p>
            <ul className="space-y-0.5">
              {subs.map((sub, i) => (
                <li key={i}>
                  <button
                    onClick={onApply}
                    className="block w-full text-left py-2 px-1 cursor-pointer rounded"
                    style={{ fontSize: '0.7rem', color: 'var(--n-secondary)', border: 'none', background: 'none' }}
                  >
                    {isZh ? sub.zh : sub.en}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      <div className="flex items-center justify-between px-4 py-3" style={{ borderTop: '1px solid var(--n-border)' }}>
        <button
          onClick={() => { setSelectedCategory(null); setSelectedDateRange(''); }}
          className="cursor-pointer"
          style={{ ...labelStyle, border: 'none', background: 'none', color: 'var(--n-muted)' }}
        >
          {isZh ? '清除' : 'Clear all'}
        </button>
        <button
          onClick={onApply}
          className="px-5 py-2 cursor-pointer transition-opacity hover:opacity-80"
          style={{ backgroundColor: 'var(--n-cta-bg)', color: 'var(--n-cta-text)', fontSize: '0.7rem', fontWeight: 600, borderRadius: '2px', border: 'none' }}
        >
          {isZh ? '套用' : 'Apply'}
        </button>
      </div>
    </div>
  );
}

// ─── Thematic tab ───
function ThematicTab({ lang, isZh }: { lang: string; isZh: boolean }) {
  const { events } = useData();
  const [selectedIndices, setSelectedIndices] = useState<Set<number>>(new Set());

  const toggleMode = useCallback((index: number) => {
    setSelectedIndices(prev => {
      const next = new Set(prev);
      if (next.has(index)) next.delete(index);
      else next.add(index);
      return next;
    });
  }, []);

  const filteredEvents = useMemo(() => {
    const pool = events.filter(e => e.status === 'upcoming' || e.status === 'ongoing');
    if (selectedIndices.size === 0) return pool.slice(0, 8);

    // Collect all categories from selected thematic modes
    const activeCats = new Set<string>();
    selectedIndices.forEach(i => {
      THEMATIC_MODES[i]?.categories.forEach(c => activeCats.add(c));
    });

    return pool.filter(e => {
      const cat = (e.category || '').toLowerCase();
      return activeCats.has(cat);
    }).slice(0, 20);
  }, [events, selectedIndices]);

  return (
    <div style={{ borderTop: '1px solid var(--n-border)' }}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '6px', padding: '12px 0' }}>
        {THEMATIC_MODES.map((mode, i) => {
          const isActive = selectedIndices.has(i);
          return (
            <button
              key={`${mode.key}-${i}`}
              onClick={() => toggleMode(i)}
              className="cursor-pointer transition-all active:scale-95"
              style={{
                border: isActive ? '1.5px solid var(--n-text)' : '1px solid var(--n-border)',
                borderRadius: '4px',
                padding: '14px 8px',
                textAlign: 'center',
                background: isActive ? 'var(--n-bg-alt)' : 'none',
              }}
            >
              <span style={{
                fontFamily: "'Archivo Black', sans-serif",
                fontSize: '0.65rem',
                color: 'var(--n-text)',
                lineHeight: 1.25,
                letterSpacing: '-0.02em',
                display: 'block',
                whiteSpace: 'pre-line',
              }}>
                {isZh ? mode.zh : mode.en}
              </span>
            </button>
          );
        })}
      </div>

      {filteredEvents.length === 0 ? (
        <div className="flex items-center justify-center py-12">
          <p style={{ fontSize: '0.75rem', color: 'var(--n-muted)' }}>
            {isZh ? '沒有符合的活動' : 'No matching events'}
          </p>
        </div>
      ) : (
        filteredEvents.map(event => (
          <EventRow key={event.id} event={event} lang={lang} isZh={isZh} />
        ))
      )}

      <Link
        to="/events"
        className="flex items-center justify-center gap-1.5 py-4 transition-opacity hover:opacity-60"
        style={{ ...labelStyle, color: 'var(--n-secondary)' }}
      >
        {isZh ? '查看全部活動' : 'View all events'}
        <ArrowUpRight size={10} />
      </Link>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════
// PAGE EXPORT
// ═══════════════════════════════════════════════════════════════════

function WhatsOnPageInner() {
  const { i18n } = useTranslation();
  const lang = i18n.language;
  const isZh = lang?.startsWith('zh');
  const navigate = useNavigate();
  const { palette, theme, toggleTheme } = useNeutralTheme();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const [activeTab, setActiveTab] = useState<Tab>('whats-on');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedDateRange, setSelectedDateRange] = useState('');

  const tabs: { id: Tab; en: string; zh: string }[] = [
    { id: 'whats-on', en: "What's On", zh: '最新活動' },
    { id: 'filter', en: 'Filter', zh: '篩選' },
    { id: 'thematic', en: 'Thematic', zh: '主題' },
  ];

  const handleFilterApply = () => {
    const params = new URLSearchParams();
    if (selectedCategory) params.set('category', selectedCategory);
    if (selectedDateRange) params.set('date', selectedDateRange);
    navigate(`/events?${params.toString()}`);
  };

  const cssVars = {
    '--n-bg': palette.bg,
    '--n-bg-alt': palette.bgAlt,
    '--n-text': palette.text,
    '--n-secondary': palette.textSecondary,
    '--n-muted': palette.textMuted,
    '--n-border': palette.border,
    '--n-border-subtle': palette.borderSubtle,
    '--n-card-bg': palette.cardBg,
    '--n-number': palette.numberColor,
    '--n-cta-bg': palette.ctaBg,
    '--n-cta-text': palette.ctaText,
    '--n-cta-border': palette.ctaBorder,
    '--n-input-bg': palette.inputBg,
    '--n-input-border': palette.inputBorder,
  } as React.CSSProperties;

  return (
    <div style={{ ...cssVars, backgroundColor: palette.bg, minHeight: '100vh', transition: 'background-color 0.3s ease' }}>
      {/* Back link + page title */}
      <div className="flex items-center justify-between" style={{ padding: `1rem ${PAD} 0.5rem` }}>
        <Link
          to="/"
          className="inline-flex items-center gap-1 transition-opacity hover:opacity-60"
          style={{ ...labelStyle, color: 'var(--n-secondary)' }}
        >
          <ArrowLeft size={10} />
          {isZh ? '首頁' : 'Home'}
        </Link>
        <button
          onClick={toggleTheme}
          className="cursor-pointer transition-opacity hover:opacity-60"
          style={{ background: 'none', border: 'none', color: 'var(--n-muted)', padding: '0.25rem' }}
          aria-label={theme === 'light' ? 'Switch to dark mode' : 'Switch to light mode'}
        >
          {theme === 'light' ? <Moon size={13} /> : <Sun size={13} />}
        </button>
      </div>

      {/* Tab bar */}
      <nav
        className="flex"
        style={{
          margin: `0 ${PAD}`,
          borderTop: '1px solid var(--n-text)',
          borderBottom: '1px solid var(--n-border)',
        }}
      >
        {tabs.map(tab => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className="flex-1 py-2.5 cursor-pointer transition-colors"
              style={{
                fontSize: '0.7rem',
                fontWeight: isActive ? 700 : 500,
                color: isActive ? 'var(--n-text)' : 'var(--n-muted)',
                background: isActive ? 'var(--n-bg-alt)' : 'none',
                border: 'none',
                borderLeft: tab.id !== 'whats-on' ? '1px solid var(--n-border)' : 'none',
              }}
            >
              {isZh ? tab.zh : tab.en}
            </button>
          );
        })}
      </nav>

      {/* Tab content */}
      <div style={{ margin: `0 ${PAD}`, paddingBottom: '3rem' }}>
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.15 }}
          >
            {activeTab === 'whats-on' && <WhatsOnTab lang={lang} isZh={isZh} />}
            {activeTab === 'filter' && (
              <FilterTab
                lang={lang} isZh={isZh}
                selectedCategory={selectedCategory} setSelectedCategory={setSelectedCategory}
                selectedDateRange={selectedDateRange} setSelectedDateRange={setSelectedDateRange}
                onApply={handleFilterApply}
              />
            )}
            {activeTab === 'thematic' && <ThematicTab lang={lang} isZh={isZh} />}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}

export function WhatsOnPage() {
  return <WhatsOnPageInner />;
}