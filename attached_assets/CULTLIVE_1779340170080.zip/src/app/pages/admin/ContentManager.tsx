import { useState, useEffect, useCallback, useMemo } from 'react';
import { useParams, useOutletContext } from 'react-router';
import { motion, AnimatePresence } from 'motion/react';
import {
  Search, Plus, Trash2, Save, X, Check, Loader2, ChevronLeft,
  Grid3X3, List, Database, Image as ImageIcon, AlertCircle,
  ToggleLeft, ToggleRight, Upload, MapPin, Building2, ExternalLink,
  CheckSquare, Square,
} from 'lucide-react';
import { getContentType } from './contentTypes';
import type { ContentType, FieldDef } from './contentTypes';
import { projectId, publicAnonKey } from '../../config/supabase';
import { useData } from '../../context/DataContext';
import { ImageWithFallback } from '../../components/figma/ImageWithFallback';
import { GooglePlacesAutocomplete, type PlaceResult } from '../../components/admin/GooglePlacesAutocomplete';
import { VenueLinker, DuplicateWarning, invalidateVenueCache, type VenueRecord } from '../../components/admin/VenueLinker';
import { fireWebhook } from '../../config/webhooks';

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-d507b98c/cms`;
const SERVER_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-d507b98c`;

const N = {
  pageBg: '#FAFAF8',
  surface: '#FFFFFF',
  surfaceMuted: '#F3F3F0',
  border: 'rgba(0,0,0,0.06)',
  borderFocus: 'rgba(0,0,0,0.15)',
  text: '#1A1A1A',
  textSecondary: '#5A5A5A',
  textMuted: '#9A9A9A',
  dark: '#1A1A1A',
  green: '#16A34A',
  greenBg: 'rgba(22,163,74,0.06)',
  amber: '#D97706',
  amberBg: 'rgba(217,119,6,0.06)',
  red: '#DC2626',
  redBg: 'rgba(220,38,38,0.05)',
  blue: '#2563EB',
  blueBg: 'rgba(37,99,235,0.05)',
  font: "'Inter', 'Noto Sans HK', system-ui, sans-serif",
};

function authHeaders(accessToken: string) {
  return {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${publicAnonKey}`,
    'X-Auth-Token': accessToken,
  };
}

export function ContentManager() {
  const { type } = useParams<{ type: string }>();
  const { accessToken } = useOutletContext<{ accessToken: string }>();
  const contentType = type ? getContentType(type) : undefined;

  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'list' | 'grid'>('list');
  const [selectedItem, setSelectedItem] = useState<any | null>(null);
  const [editData, setEditData] = useState<Record<string, any>>({});
  const [saving, setSaving] = useState(false);
  const [saveResult, setSaveResult] = useState<'success' | 'error' | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [isNew, setIsNew] = useState(false);
  const [seeding, setSeeding] = useState(false);
  const [selectedPlace, setSelectedPlace] = useState<PlaceResult | null>(null);
  const [creatingVenue, setCreatingVenue] = useState(false);
  const [venueCreated, setVenueCreated] = useState(false);
  const [bulkIds, setBulkIds] = useState<Set<string>>(new Set());
  const [bulkDeleting, setBulkDeleting] = useState(false);
  const [bulkConfirm, setBulkConfirm] = useState(false);
  const { refresh: refreshData } = useData();

  const loadItems = useCallback(async () => {
    if (!accessToken || !type) return;
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/content/${type}`, {
        headers: authHeaders(accessToken),
      });
      const data = await res.json();
      setItems(data.items || []);
    } catch (err) {
      console.log(`Failed to load ${type} items:`, err);
    }
    setLoading(false);
  }, [accessToken, type]);

  useEffect(() => {
    loadItems();
    setSelectedItem(null);
    setIsNew(false);
    setSearchQuery('');
  }, [loadItems, type]);

  const filteredItems = useMemo(() => {
    if (!searchQuery || !contentType) return items;
    const q = searchQuery.toLowerCase();
    return items.filter(item => {
      return contentType.fields.some(f => {
        const val = item[f.key];
        if (typeof val === 'string') return val.toLowerCase().includes(q);
        if (Array.isArray(val)) return val.some(v => String(v).toLowerCase().includes(q));
        return false;
      });
    });
  }, [items, searchQuery, contentType]);

  const selectItem = useCallback((item: any) => {
    setSelectedItem(item);
    setEditData({ ...item });
    setIsNew(false);
    setDeleteConfirm(null);
    setSaveResult(null);
    setSelectedPlace(null);
    setVenueCreated(false);
  }, []);

  const createNew = useCallback(() => {
    if (!contentType) return;
    const newItem = {
      ...contentType.defaultValues,
      id: `${type}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`,
    };
    setSelectedItem(newItem);
    setEditData(newItem);
    setIsNew(true);
    setDeleteConfirm(null);
    setSaveResult(null);
    setSelectedPlace(null);
    setVenueCreated(false);
  }, [contentType, type]);

  const handleFieldChange = useCallback((key: string, value: any) => {
    setEditData(prev => ({ ...prev, [key]: value }));
  }, []);

  const handleSave = useCallback(async () => {
    if (!accessToken || !type || !contentType) return;
    setSaving(true);
    setSaveResult(null);
    try {
      const id = editData[contentType.idField];
      const method = isNew ? 'POST' : 'PUT';
      const url = isNew ? `${API_BASE}/content/${type}` : `${API_BASE}/content/${type}/${id}`;
      const res = await fetch(url, {
        method,
        headers: authHeaders(accessToken),
        body: JSON.stringify(editData),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Save failed');
      }
      setSaveResult('success');
      setTimeout(() => setSaveResult(null), 2000);
      await loadItems();
      if (isNew) {
        setIsNew(false);
        setSelectedItem(editData);
      }
      // Fire webhook for content create/update
      fireWebhook(isNew ? 'content.created' : 'content.updated', {
        contentType: type,
        id: editData[contentType.idField],
        title: editData[contentType.titleField],
      });
    } catch (err: any) {
      console.log('Save error:', err);
      setSaveResult('error');
    }
    setSaving(false);
  }, [accessToken, type, contentType, editData, isNew, loadItems]);

  const handleDelete = useCallback(async (id: string) => {
    if (!accessToken || !type) return;
    try {
      await fetch(`${API_BASE}/content/${type}/${id}`, {
        method: 'DELETE',
        headers: authHeaders(accessToken),
      });
      // Fire webhook for content deletion
      fireWebhook('content.deleted', { contentType: type, id });
      setSelectedItem(null);
      setDeleteConfirm(null);
      await loadItems();
      try { sessionStorage.removeItem('cultive_data_cache'); } catch {}
      refreshData();
    } catch (err) {
      console.log('Delete error:', err);
    }
  }, [accessToken, type, loadItems, refreshData]);

  const handleSeed = useCallback(async () => {
    if (!accessToken || !type) return;
    setSeeding(true);
    try {
      const res = await fetch(`${API_BASE}/content/${type}/seed`, {
        method: 'POST',
        headers: authHeaders(accessToken),
      });
      const data = await res.json();
      console.log('Seed result:', data);
      await loadItems();
    } catch (err) {
      console.log('Seed error:', err);
    }
    setSeeding(false);
  }, [accessToken, type, loadItems]);

  const handleBulkDelete = useCallback(async () => {
    if (!accessToken || !type || !contentType || !bulkIds.size) return;
    setBulkDeleting(true);
    try {
      for (const id of bulkIds) {
        await fetch(`${API_BASE}/content/${type}/${id}`, {
          method: 'DELETE',
          headers: authHeaders(accessToken),
        });
      }
      setBulkIds(new Set());
      setBulkConfirm(false);
      setSelectedItem(null);
      await loadItems();
      try { sessionStorage.removeItem('cultive_data_cache'); } catch {}
      refreshData();
    } catch (err: any) {
      console.log('Bulk delete error:', err);
    }
    setBulkDeleting(false);
  }, [accessToken, type, contentType, bulkIds, loadItems, refreshData]);

  if (!contentType) {
    return (
      <div className="p-8 text-center" style={{ fontFamily: N.font }}>
        <AlertCircle size={24} className="mx-auto mb-2" style={{ color: N.textMuted }} />
        <p className="text-[14px]" style={{ color: N.textMuted }}>Content type "{type}" not found</p>
      </div>
    );
  }

  return (
    <div className="h-full overflow-hidden flex flex-col lg:flex-row" style={{ fontFamily: N.font }}>
      {/* ═══ Left Panel — Item List ═══ */}
      <div className="lg:w-[340px] xl:w-[380px] flex-shrink-0 flex flex-col border-r overflow-hidden"
        style={{ borderColor: N.border, backgroundColor: N.pageBg }}>
        {/* Header — always visible */}
        <div className="flex-shrink-0 p-4 pb-3" style={{ borderBottom: `1px solid ${N.border}` }}>
          <div className="flex items-center justify-between mb-3">
            <div>
              <p className="text-[11px] font-medium uppercase tracking-wider"
                style={{ color: N.textMuted }}>{contentType.page}</p>
              <h2 className="text-[1.1rem] font-semibold tracking-tight" style={{ color: N.text }}>
                {contentType.labelPlural}
              </h2>
            </div>
            <div className="flex items-center gap-1.5">
              <button onClick={() => setViewMode(viewMode === 'list' ? 'grid' : 'list')}
                className="p-1.5 cursor-pointer" style={{ color: N.textMuted, borderRadius: '6px' }}
                title={viewMode === 'list' ? 'Grid view' : 'List view'}>
                {viewMode === 'list' ? <Grid3X3 size={15} /> : <List size={15} />}
              </button>
              <button onClick={handleSeed} disabled={seeding}
                className="p-1.5 cursor-pointer" style={{ color: N.textMuted, borderRadius: '6px' }}
                title="Seed from static data">
                {seeding ? <Loader2 size={15} className="animate-spin" /> : <Database size={15} />}
              </button>
              <button onClick={createNew}
                className="flex items-center gap-1 px-2.5 py-1.5 text-[12px] font-medium cursor-pointer"
                style={{ backgroundColor: N.dark, color: '#fff', borderRadius: '8px' }}>
                <Plus size={13} /> New
              </button>
            </div>
          </div>
          {/* Search */}
          <div className="relative">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: N.textMuted }} />
            <input
              type="text" value={searchQuery} onChange={e => setSearchQuery(e.target.value)}
              placeholder={`Search ${contentType.labelPlural.toLowerCase()}...`}
              className="w-full pl-9 pr-3 py-2 text-[13px] outline-none"
              style={{ backgroundColor: N.surface, border: `1px solid ${N.border}`, borderRadius: '8px', color: N.text }}
            />
          </div>
          <p className="text-[11px] mt-2" style={{ color: N.textMuted }}>
            {filteredItems.length} item{filteredItems.length !== 1 ? 's' : ''}
          </p>

          {/* Bulk select bar */}
          {filteredItems.length > 0 && (
            <div className="flex items-center justify-between mt-2 pt-2" style={{ borderTop: `1px solid ${N.border}` }}>
              <button
                onClick={() => {
                  if (!contentType) return;
                  if (bulkIds.size === filteredItems.length) {
                    setBulkIds(new Set());
                  } else {
                    setBulkIds(new Set(filteredItems.map(i => i[contentType.idField])));
                  }
                }}
                className="flex items-center gap-1.5 text-[11px] cursor-pointer"
                style={{ color: bulkIds.size > 0 ? N.blue : N.textMuted }}
              >
                {bulkIds.size > 0 && bulkIds.size === filteredItems.length
                  ? <CheckSquare size={13} />
                  : <Square size={13} />
                }
                {bulkIds.size > 0 ? `${bulkIds.size} selected` : 'Select all'}
              </button>
              {bulkIds.size > 0 && (
                <div className="flex items-center gap-1.5">
                  {!bulkConfirm ? (
                    <button
                      onClick={() => setBulkConfirm(true)}
                      className="flex items-center gap-1 px-2 py-1 text-[11px] font-medium cursor-pointer transition-colors hover:opacity-80"
                      style={{ backgroundColor: N.redBg, color: N.red, borderRadius: '6px' }}
                    >
                      <Trash2 size={11} /> Delete {bulkIds.size}
                    </button>
                  ) : (
                    <>
                      <button
                        onClick={() => setBulkConfirm(false)}
                        className="px-2 py-1 text-[11px] cursor-pointer"
                        style={{ color: N.textMuted }}
                      >
                        Cancel
                      </button>
                      <button
                        onClick={handleBulkDelete}
                        disabled={bulkDeleting}
                        className="flex items-center gap-1 px-2 py-1 text-[11px] font-semibold cursor-pointer"
                        style={{ backgroundColor: N.red, color: '#fff', borderRadius: '6px' }}
                      >
                        {bulkDeleting ? <Loader2 size={11} className="animate-spin" /> : <Trash2 size={11} />}
                        {bulkDeleting ? 'Deleting...' : 'Confirm'}
                      </button>
                    </>
                  )}
                  <button
                    onClick={() => { setBulkIds(new Set()); setBulkConfirm(false); }}
                    className="p-0.5 cursor-pointer"
                    style={{ color: N.textMuted }}
                  >
                    <X size={12} />
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Item List — scrolls independently */}
        <div className="flex-1 overflow-y-auto min-h-0">
          {loading ? (
            <div className="flex items-center justify-center py-16">
              <Loader2 size={18} className="animate-spin" style={{ color: N.textMuted }} />
            </div>
          ) : filteredItems.length === 0 ? (
            <div className="text-center py-12 px-4">
              <p className="text-[13px]" style={{ color: N.textMuted }}>
                {items.length === 0 ? `No ${contentType.labelPlural.toLowerCase()} yet` : 'No matches'}
              </p>
              {items.length === 0 && (
                <button onClick={handleSeed}
                  className="mt-3 flex items-center gap-1.5 mx-auto px-3 py-1.5 text-[12px] cursor-pointer"
                  style={{ backgroundColor: N.blueBg, color: N.blue, borderRadius: '8px' }}>
                  <Database size={12} /> Seed from static data
                </button>
              )}
            </div>
          ) : viewMode === 'list' ? (
            <div className="py-1">
              {filteredItems.map(item => {
                const isSelected = selectedItem?.[contentType.idField] === item[contentType.idField];
                const thumb = contentType.imageField ? item[contentType.imageField] : null;
                const itemId = item[contentType.idField];
                const isBulkChecked = bulkIds.has(itemId);
                return (
                  <div key={itemId}
                    className="w-full text-left flex items-center gap-1 px-2 py-2.5 transition-colors"
                    style={{
                      backgroundColor: isBulkChecked ? 'rgba(37,99,235,0.04)' : isSelected ? 'rgba(0,0,0,0.04)' : 'transparent',
                      borderLeft: isSelected ? '2px solid #1A1A1A' : '2px solid transparent',
                    }}>
                    <button
                      onClick={() => {
                        setBulkIds(prev => {
                          const next = new Set(prev);
                          if (next.has(itemId)) next.delete(itemId); else next.add(itemId);
                          return next;
                        });
                      }}
                      className="p-1 flex-shrink-0 cursor-pointer"
                      style={{ color: isBulkChecked ? N.blue : N.textMuted }}
                    >
                      {isBulkChecked ? <CheckSquare size={14} /> : <Square size={14} />}
                    </button>
                    <button
                      onClick={() => selectItem(item)}
                      className="flex-1 min-w-0 flex items-center gap-3 cursor-pointer text-left"
                    >
                    {thumb ? (
                      <div className="w-9 h-9 flex-shrink-0 overflow-hidden rounded-lg">
                        <ImageWithFallback src={thumb} alt="" className="w-full h-full object-cover" />
                      </div>
                    ) : (
                      <div className="w-9 h-9 flex-shrink-0 flex items-center justify-center rounded-lg"
                        style={{ backgroundColor: 'rgba(0,0,0,0.03)' }}>
                        <ImageIcon size={13} style={{ color: N.textMuted }} />
                      </div>
                    )}
                    <div className="min-w-0 flex-1">
                      <p className="text-[13px] font-medium truncate" style={{ color: N.text }}>
                        {item[contentType.titleField] || 'Untitled'}
                      </p>
                      <p className="text-[11px] truncate" style={{ color: N.textMuted }}>
                        {item[contentType.subtitleField] || '—'}
                      </p>
                    </div>
                    {(item._source === 'mock' || /^[evr]\d+$/.test(item.id || '')) && (
                      <span className="text-[9px] px-1.5 py-0.5 font-semibold flex-shrink-0" style={{
                        backgroundColor: '#FEF3C7', color: '#92400E', borderRadius: '4px', border: '1px solid #FDE68A',
                      }}>MOCK</span>
                    )}
                    {(item._source === 'ra_import' || (item.id || '').startsWith('ra_')) && (
                      <span className="text-[9px] px-1.5 py-0.5 font-semibold flex-shrink-0" style={{
                        backgroundColor: 'rgba(37,99,235,0.08)', color: N.blue, borderRadius: '4px',
                      }}>RA</span>
                    )}
                    {(item._source === 'lsa' || (item.id || '').startsWith('lsa_')) && (
                      <span className="text-[9px] px-1.5 py-0.5 font-semibold flex-shrink-0" style={{
                        backgroundColor: '#CCFBF1', color: '#0F766E', borderRadius: '4px',
                      }}>LSA</span>
                    )}
                    {(item._source === 'apify' || (item.id || '').startsWith('apify_')) && (
                      <span className="text-[9px] px-1.5 py-0.5 font-semibold flex-shrink-0" style={{
                        backgroundColor: '#F0F9FF', color: '#06B6D4', borderRadius: '4px',
                      }}>APIFY</span>
                    )}
                    {item.status === 'draft' && (
                      <span className="text-[9px] px-1.5 py-0.5 font-medium" style={{
                        backgroundColor: N.amberBg, color: N.amber, borderRadius: '4px',
                      }}>DRAFT</span>
                    )}
                    </button>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-2 p-3">
              {filteredItems.map(item => {
                const isSelected = selectedItem?.[contentType.idField] === item[contentType.idField];
                const thumb = contentType.imageField ? item[contentType.imageField] : null;
                return (
                  <button key={item[contentType.idField]}
                    onClick={() => selectItem(item)}
                    className="text-left cursor-pointer transition-all overflow-hidden"
                    style={{
                      backgroundColor: N.surface,
                      border: `1.5px solid ${isSelected ? N.dark : N.border}`,
                      borderRadius: '10px',
                    }}>
                    {thumb ? (
                      <div className="w-full aspect-[4/3] overflow-hidden">
                        <ImageWithFallback src={thumb} alt="" className="w-full h-full object-cover" />
                      </div>
                    ) : (
                      <div className="w-full aspect-[4/3] flex items-center justify-center"
                        style={{ backgroundColor: N.surfaceMuted }}>
                        <ImageIcon size={20} style={{ color: N.textMuted }} />
                      </div>
                    )}
                    <div className="p-2.5">
                      <div className="flex items-center gap-1">
                        <p className="text-[12px] font-medium truncate flex-1" style={{ color: N.text }}>
                          {item[contentType.titleField] || 'Untitled'}
                        </p>
                        {(item._source === 'mock' || /^[evr]\d+$/.test(item.id || '')) && (
                          <span className="text-[8px] px-1 py-0.5 font-semibold flex-shrink-0" style={{
                            backgroundColor: '#FEF3C7', color: '#92400E', borderRadius: '3px', border: '1px solid #FDE68A',
                          }}>MOCK</span>
                        )}
                      </div>
                      <p className="text-[10px] truncate" style={{ color: N.textMuted }}>
                        {item[contentType.subtitleField] || '—'}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* ═══ Right Panel — Edit Form ═══ */}
      <div className="flex-1 min-w-0 overflow-hidden flex flex-col" style={{ backgroundColor: N.pageBg }}>
        <AnimatePresence mode="wait">
          {selectedItem ? (
            <motion.div
              key={selectedItem[contentType.idField] || 'new'}
              initial={{ opacity: 0, x: 12 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -12 }}
              transition={{ duration: 0.15 }}
              className="flex flex-col h-full"
            >
              {/* ── Sticky header — pinned, never scrolls ── */}
              <div className="flex-shrink-0 flex items-center justify-between px-5 sm:px-7 lg:px-8 py-4"
                style={{
                  backgroundColor: N.pageBg,
                  borderBottom: `1px solid ${N.border}`,
                }}>
                <div className="flex items-center gap-3">
                  <button onClick={() => { setSelectedItem(null); setIsNew(false); }}
                    className="p-1.5 cursor-pointer lg:hidden" style={{ color: N.textMuted }}>
                    <ChevronLeft size={18} />
                  </button>
                  <div>
                    <p className="text-[11px] font-medium uppercase tracking-wider"
                      style={{ color: N.textMuted }}>{isNew ? 'New' : 'Edit'} {contentType.label}</p>
                    <h2 className="text-[1.25rem] font-semibold tracking-tight" style={{ color: N.text }}>
                      {editData[contentType.titleField] || 'Untitled'}
                    </h2>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {saveResult === 'success' && (
                    <motion.span initial={{ opacity: 0, x: 8 }} animate={{ opacity: 1, x: 0 }}
                      className="flex items-center gap-1 text-[12px] font-medium" style={{ color: N.green }}>
                      <Check size={13} /> Saved
                    </motion.span>
                  )}
                  {/* View on Website — only for content types with a public page */}
                  {!isNew && contentType.viewUrlPattern && editData[contentType.idField] && (
                    <a
                      href={contentType.viewUrlPattern.replace(':id', editData[contentType.idField])}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-1.5 px-3 py-2 text-[12px] font-medium cursor-pointer transition-opacity hover:opacity-80"
                      style={{
                        backgroundColor: N.blueBg,
                        color: N.blue,
                        borderRadius: '8px',
                        border: `1px solid ${N.blue}20`,
                        textDecoration: 'none',
                      }}
                    >
                      <ExternalLink size={13} /> View on Website
                    </a>
                  )}
                  <button onClick={handleSave} disabled={saving}
                    className="flex items-center gap-1.5 px-4 py-2 text-[13px] font-medium cursor-pointer transition-opacity disabled:opacity-50 hover:opacity-90"
                    style={{ backgroundColor: N.dark, color: '#fff', borderRadius: '8px' }}>
                    {saving ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />}
                    {saving ? 'Saving...' : 'Save'}
                  </button>
                </div>
              </div>

              {/* ── Scrollable form body ── */}
              <div className="flex-1 overflow-y-auto min-h-0 p-5 sm:p-7 lg:p-8">
                <div className="max-w-[720px]">
                  {/* Form Fields */}
                  <div className="p-5 sm:p-6" style={{
                    backgroundColor: N.surface, border: `1px solid ${N.border}`, borderRadius: '14px',
                  }}>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-5">
                      {contentType.fields
                        .filter(field => {
                          if (field.key === contentType.idField && isNew) return false;
                          return true;
                        })
                        .map(field => {
                          const isIdField = field.key === contentType.idField && !isNew;
                          return (
                            <div key={field.key} className={field.half ? '' : 'sm:col-span-2'}>
                              {isIdField ? (
                                <div>
                                  <label className="block text-[12px] font-medium mb-1.5" style={{ color: N.textMuted }}>
                                    {field.label}
                                  </label>
                                  <div
                                    className="px-3 py-2 text-[13px] select-all"
                                    style={{
                                      backgroundColor: N.surfaceMuted,
                                      border: `1px solid ${N.border}`,
                                      borderRadius: '8px',
                                      color: N.textMuted,
                                      fontFamily: 'monospace',
                                      fontSize: '12px',
                                    }}
                                  >
                                    {editData[field.key] || '—'}
                                  </div>
                                </div>
                              ) : (
                                <FieldRenderer
                                  field={field}
                                  value={editData[field.key]}
                                  onChange={(val) => handleFieldChange(field.key, val)}
                                  accessToken={accessToken}
                                />
                              )}
                            </div>
                          );
                        })}
                    </div>
                  </div>

                  {/* ── Location Lookup (for event content type) ── */}
                  {type === 'event' && (
                    <LocationLookupSection
                      editData={editData}
                      onFieldChange={(key, val) => handleFieldChange(key, val)}
                      onMultiFieldChange={(updates) => setEditData(prev => ({ ...prev, ...updates }))}
                      accessToken={accessToken}
                      selectedPlace={selectedPlace}
                      setSelectedPlace={setSelectedPlace}
                      creatingVenue={creatingVenue}
                      setCreatingVenue={setCreatingVenue}
                      venueCreated={venueCreated}
                      setVenueCreated={setVenueCreated}
                    />
                  )}

                  {/* ── Location Lookup (for venue content type) ── */}
                  {type === 'venue' && (
                    <VenueLocationLookup
                      editData={editData}
                      onMultiFieldChange={(updates) => setEditData(prev => ({ ...prev, ...updates }))}
                      selectedPlace={selectedPlace}
                      setSelectedPlace={setSelectedPlace}
                    />
                  )}

                  {/* Delete zone */}
                  {!isNew && (
                    <div className="mt-6 pt-5" style={{ borderTop: `1px solid ${N.border}` }}>
                      {deleteConfirm === selectedItem[contentType.idField] ? (
                        <motion.div initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }}
                          className="flex items-center gap-3 p-3" style={{ backgroundColor: N.redBg, borderRadius: '10px' }}>
                          <p className="flex-1 text-[13px]" style={{ color: N.red }}>
                            Delete this {contentType.label.toLowerCase()} permanently?
                          </p>
                          <button onClick={() => handleDelete(selectedItem[contentType.idField])}
                            className="flex items-center gap-1 px-3 py-1.5 text-[12px] font-medium cursor-pointer"
                            style={{ backgroundColor: N.red, color: '#fff', borderRadius: '7px' }}>
                            <Trash2 size={12} /> Delete
                          </button>
                          <button onClick={() => setDeleteConfirm(null)}
                            className="p-1.5 cursor-pointer" style={{ color: N.textMuted }}>
                            <X size={14} />
                          </button>
                        </motion.div>
                      ) : (
                        <button onClick={() => setDeleteConfirm(selectedItem[contentType.idField])}
                          className="flex items-center gap-1.5 text-[12px] cursor-pointer hover:underline"
                          style={{ color: N.red }}>
                          <Trash2 size={12} /> Delete this {contentType.label.toLowerCase()}
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="empty"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex flex-col items-center justify-center h-full py-24 px-6 text-center"
            >
              <div className="w-14 h-14 flex items-center justify-center mb-4"
                style={{ backgroundColor: 'rgba(0,0,0,0.03)', borderRadius: '16px' }}>
                <ImageIcon size={22} style={{ color: N.textMuted }} />
              </div>
              <p className="text-[15px] font-medium" style={{ color: N.text }}>
                Select a {contentType.label.toLowerCase()} to edit
              </p>
              <p className="text-[13px] mt-1 mb-5" style={{ color: N.textMuted }}>
                Or create a new one to get started
              </p>
              <button onClick={createNew}
                className="flex items-center gap-1.5 px-4 py-2 text-[13px] font-medium cursor-pointer"
                style={{ backgroundColor: N.dark, color: '#fff', borderRadius: '8px' }}>
                <Plus size={14} /> New {contentType.label}
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════
// FIELD RENDERER — renders appropriate input per type
// ═══════════════════════════════════════════════════

function FieldRenderer({ field, value, onChange, accessToken }: {
  field: FieldDef;
  value: any;
  onChange: (val: any) => void;
  accessToken: string;
}) {
  const inputStyle: React.CSSProperties = {
    backgroundColor: N.surfaceMuted,
    border: `1px solid ${N.border}`,
    borderRadius: '10px',
    color: N.text,
    fontFamily: N.font,
  };

  const [uploading, setUploading] = useState(false);

  const handleImageUpload = async (files: FileList) => {
    const file = files[0];
    if (!file) return;
    setUploading(true);
    try {
      const formData = new FormData();
      formData.append('files', file);
      const res = await fetch(`${API_BASE}/upload`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${publicAnonKey}` },
        body: formData,
      });
      const data = await res.json();
      if (data.uploaded?.[0]?.url) {
        onChange(data.uploaded[0].url);
      }
    } catch (err) {
      console.log('Upload error:', err);
    }
    setUploading(false);
  };

  return (
    <div>
      <label className="block text-[12px] font-medium mb-1.5" style={{ color: N.textSecondary }}>
        {field.label}
        {field.required && <span style={{ color: N.red }}> *</span>}
      </label>

      {field.type === 'text' && (
        <input
          type="text" value={value || ''} onChange={e => onChange(e.target.value)}
          placeholder={field.placeholder}
          className="w-full px-3.5 py-2.5 text-[13px] outline-none"
          style={inputStyle}
        />
      )}

      {field.type === 'url' && (
        <input
          type="url" value={value || ''} onChange={e => onChange(e.target.value)}
          placeholder={field.placeholder || 'https://...'}
          className="w-full px-3.5 py-2.5 text-[13px] outline-none"
          style={inputStyle}
        />
      )}

      {field.type === 'textarea' && (
        <textarea
          value={value || ''} onChange={e => onChange(e.target.value)}
          placeholder={field.placeholder} rows={4}
          className="w-full px-3.5 py-2.5 text-[13px] outline-none resize-none"
          style={inputStyle}
        />
      )}

      {field.type === 'number' && (
        <input
          type="number" value={value ?? ''} onChange={e => onChange(e.target.value ? Number(e.target.value) : '')}
          placeholder={field.placeholder}
          className="w-full px-3.5 py-2.5 text-[13px] outline-none"
          style={inputStyle}
        />
      )}

      {field.type === 'date' && (
        <input
          type="date" value={value || ''} onChange={e => onChange(e.target.value)}
          className="w-full px-3.5 py-2.5 text-[13px] outline-none"
          style={inputStyle}
        />
      )}

      {field.type === 'select' && (
        <select
          value={value || ''} onChange={e => onChange(e.target.value)}
          className="w-full px-3.5 py-2.5 text-[13px] outline-none appearance-none cursor-pointer"
          style={inputStyle}
        >
          <option value="">Select...</option>
          {field.options?.map(opt => (
            <option key={opt.value} value={opt.value}>{opt.label}</option>
          ))}
        </select>
      )}

      {field.type === 'toggle' && (
        <button
          onClick={() => onChange(!value)}
          className="flex items-center gap-2 py-1 cursor-pointer"
        >
          {value ? (
            <ToggleRight size={24} style={{ color: N.green }} />
          ) : (
            <ToggleLeft size={24} style={{ color: N.textMuted }} />
          )}
          <span className="text-[13px]" style={{ color: value ? N.green : N.textMuted }}>
            {value ? 'On' : 'Off'}
          </span>
        </button>
      )}

      {field.type === 'image' && (
        <div>
          <div className="flex gap-2 mb-2">
            <input
              type="text" value={value || ''} onChange={e => onChange(e.target.value)}
              placeholder={field.placeholder || 'Paste URL or upload'}
              className="flex-1 px-3.5 py-2.5 text-[13px] outline-none"
              style={inputStyle}
            />
            <label className="flex items-center gap-1 px-3 py-2 text-[12px] font-medium cursor-pointer"
              style={{ backgroundColor: N.surfaceMuted, border: `1px solid ${N.border}`, borderRadius: '10px', color: N.textSecondary }}>
              {uploading ? <Loader2 size={13} className="animate-spin" /> : <Upload size={13} />}
              <input type="file" accept="image/*" className="hidden"
                onChange={e => e.target.files && handleImageUpload(e.target.files)} />
            </label>
          </div>
          {value && (
            <div className="relative w-full max-w-[200px] aspect-video overflow-hidden"
              style={{ borderRadius: '8px', border: `1px solid ${N.border}` }}>
              <ImageWithFallback src={value} alt="" className="w-full h-full object-cover" />
            </div>
          )}
        </div>
      )}

      {field.type === 'tags' && (
        <TagsInput value={value || []} onChange={onChange} placeholder={field.placeholder} />
      )}

      {field.type === 'json' && (
        <textarea
          value={typeof value === 'object' ? JSON.stringify(value, null, 2) : value || ''}
          onChange={e => {
            try { onChange(JSON.parse(e.target.value)); } catch { onChange(e.target.value); }
          }}
          placeholder={field.placeholder || '{}'}
          rows={5}
          className="w-full px-3.5 py-2.5 text-[12px] outline-none resize-none font-mono"
          style={inputStyle}
        />
      )}

      {field.type === 'color' && (
        <div className="flex items-center gap-2">
          <input
            type="color" value={value || '#000000'} onChange={e => onChange(e.target.value)}
            className="w-9 h-9 cursor-pointer border-0"
          />
          <input
            type="text" value={value || ''} onChange={e => onChange(e.target.value)}
            placeholder="#000000"
            className="flex-1 px-3.5 py-2.5 text-[13px] outline-none"
            style={inputStyle}
          />
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════
// TAGS INPUT
// ═══════════════════════════════════════════════════

function TagsInput({ value, onChange, placeholder }: {
  value: string[];
  onChange: (val: string[]) => void;
  placeholder?: string;
}) {
  const [input, setInput] = useState('');

  const addTag = () => {
    const tag = input.trim();
    if (tag && !value.includes(tag)) {
      onChange([...value, tag]);
    }
    setInput('');
  };

  const removeTag = (tag: string) => {
    onChange(value.filter(t => t !== tag));
  };

  return (
    <div>
      <div className="flex flex-wrap gap-1.5 mb-2">
        {value.map(tag => (
          <span key={tag} className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium"
            style={{ backgroundColor: 'rgba(0,0,0,0.04)', borderRadius: '6px', color: N.textSecondary }}>
            {tag}
            <button onClick={() => removeTag(tag)} className="cursor-pointer hover:opacity-70">
              <X size={10} />
            </button>
          </span>
        ))}
      </div>
      <input
        type="text" value={input} onChange={e => setInput(e.target.value)}
        placeholder={placeholder || 'Type and press Enter'}
        className="w-full px-3.5 py-2.5 text-[13px] outline-none"
        style={{
          backgroundColor: N.surfaceMuted, border: `1px solid ${N.border}`,
          borderRadius: '10px', color: N.text, fontFamily: N.font,
        }}
        onKeyDown={e => {
          if (e.key === 'Enter') { e.preventDefault(); addTag(); }
          if (e.key === ',' && input.trim()) { e.preventDefault(); addTag(); }
        }}
      />
    </div>
  );
}

// ═══════════════════════════════════════════════════
// LOCATION LOOKUP SECTION
// ═══════════════════════════════════════════════════

function LocationLookupSection({
  editData,
  onFieldChange,
  onMultiFieldChange,
  accessToken,
  selectedPlace,
  setSelectedPlace,
  creatingVenue,
  setCreatingVenue,
  venueCreated,
  setVenueCreated,
}: {
  editData: Record<string, any>;
  onFieldChange: (key: string, val: any) => void;
  onMultiFieldChange: (updates: Record<string, any>) => void;
  accessToken: string;
  selectedPlace: PlaceResult | null;
  setSelectedPlace: (place: PlaceResult | null) => void;
  creatingVenue: boolean;
  setCreatingVenue: (creating: boolean) => void;
  venueCreated: boolean;
  setVenueCreated: (created: boolean) => void;
}) {
  const [localShowDuplicateCheck, setLocalShowDuplicateCheck] = useState(false);

  const handlePlaceSelect = (place: PlaceResult) => {
    setSelectedPlace(place);
    setVenueCreated(false);
    setLocalShowDuplicateCheck(false);
    // Auto-fill event fields from place details
    onMultiFieldChange({
      venueName: place.name,
      district: place.district || editData.district || '',
      lat: place.lat,
      lng: place.lng,
    });
  };

  const doCreateVenue = async () => {
    if (!accessToken || !selectedPlace) return;
    setCreatingVenue(true);
    setLocalShowDuplicateCheck(false);
    try {
      const venueId = `venue_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`;
      const venueData = {
        id: venueId,
        name: editData.venueName || selectedPlace.name,
        description: '',
        category: editData.category || 'other',
        subcategory: '',
        lat: selectedPlace.lat,
        lng: selectedPlace.lng,
        district: selectedPlace.district || editData.district || '',
        address: selectedPlace.formattedAddress,
        image: editData.image || '',
        vibeTags: [],
        priceRange: 2,
        modeScores: { degen: 0.5, artsy: 0.5, foodie: 0.5, family: 0.5, lifestyle: 0.5 },
        upcomingEvents: 1,
        pastRecaps: 0,
      };

      const res = await fetch(`${API_BASE}/content/venue`, {
        method: 'POST',
        headers: authHeaders(accessToken),
        body: JSON.stringify(venueData),
      });

      if (res.ok) {
        onFieldChange('venueId', venueId);
        setVenueCreated(true);
        invalidateVenueCache();
      } else {
        const err = await res.text();
        console.error('Failed to create venue:', err);
      }
    } catch (err) {
      console.error('Create venue error:', err);
    }
    setCreatingVenue(false);
  };

  const handleLinkExisting = (venue: VenueRecord) => {
    onMultiFieldChange({
      venueId: venue.id,
      venueName: venue.name || editData.venueName || '',
      district: venue.district || editData.district || '',
      lat: venue.lat ?? editData.lat,
      lng: venue.lng ?? editData.lng,
    });
    setVenueCreated(true);
    setLocalShowDuplicateCheck(false);
  };

  const hasCoords = editData.lat && editData.lng;

  return (
    <div
      className="mt-4 p-5 sm:p-6"
      style={{
        backgroundColor: N.surface,
        border: `1.5px solid ${selectedPlace ? `${N.green}30` : `${N.blue}20`}`,
        borderRadius: '14px',
      }}
    >
      {/* Section header */}
      <div className="flex items-center gap-2 mb-4">
        <div className="w-7 h-7 flex items-center justify-center rounded-lg" style={{ backgroundColor: N.blueBg }}>
          <MapPin size={14} style={{ color: N.blue }} />
        </div>
        <div>
          <h3 className="text-[13px] font-semibold" style={{ color: N.text }}>Location Lookup</h3>
          <p className="text-[11px]" style={{ color: N.textMuted }}>Search Google Maps to set exact venue coordinates</p>
        </div>
      </div>

      {/* Google Places Autocomplete */}
      <GooglePlacesAutocomplete
        value={editData.venueName || ''}
        onSelect={handlePlaceSelect}
        placeholder="Search venue or address on Google Maps..."
        selectedPlace={selectedPlace}
      />

      {/* Coordinate display */}
      {hasCoords && (
        <div className="mt-3 grid grid-cols-2 gap-3">
          <div className="px-3 py-2 rounded-lg" style={{ backgroundColor: N.surfaceMuted, border: `1px solid ${N.border}` }}>
            <span className="text-[10px] uppercase tracking-wider font-semibold block" style={{ color: N.textMuted }}>Latitude</span>
            <span className="text-[13px] font-mono" style={{ color: N.text }}>{Number(editData.lat).toFixed(6)}</span>
          </div>
          <div className="px-3 py-2 rounded-lg" style={{ backgroundColor: N.surfaceMuted, border: `1px solid ${N.border}` }}>
            <span className="text-[10px] uppercase tracking-wider font-semibold block" style={{ color: N.textMuted }}>Longitude</span>
            <span className="text-[13px] font-mono" style={{ color: N.text }}>{Number(editData.lng).toFixed(6)}</span>
          </div>
        </div>
      )}

      {/* Auto-filled info */}
      {selectedPlace && (
        <motion.div
          initial={{ opacity: 0, y: -4 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-3 space-y-3"
        >
          {/* Auto-filled district */}
          {editData.district && (
            <div className="flex items-center gap-2 text-[12px]">
              <span style={{ color: N.textMuted }}>District auto-filled:</span>
              <span className="px-2 py-0.5 font-medium rounded" style={{ backgroundColor: `${N.blue}10`, color: N.blue }}>
                {editData.district}
              </span>
            </div>
          )}

          {/* Create Venue button */}
          <div className="flex items-center gap-3 pt-2" style={{ borderTop: `1px solid ${N.border}` }}>
            {!localShowDuplicateCheck && !venueCreated && (
              <button
                onClick={() => setLocalShowDuplicateCheck(true)}
                disabled={creatingVenue}
                className="flex items-center gap-1.5 px-4 py-2 text-[12px] font-medium cursor-pointer transition-all disabled:opacity-60"
                style={{ backgroundColor: N.dark, color: '#fff', borderRadius: '8px' }}
              >
                {creatingVenue ? (
                  <><Loader2 size={13} className="animate-spin" /> Creating venue...</>
                ) : (
                  <><Building2 size={13} /> Create venue from this location</>
                )}
              </button>
            )}

            {venueCreated && (
              <div className="flex items-center gap-2">
                <span className="flex items-center gap-1.5 px-4 py-2 text-[12px] font-medium"
                  style={{ backgroundColor: N.greenBg, color: N.green, borderRadius: '8px', border: `1px solid ${N.green}30` }}>
                  <Check size={13} /> Venue linked
                </span>
                {editData.venueId && (
                  <span className="text-[11px] font-mono" style={{ color: N.textMuted }}>
                    ID: {editData.venueId}
                  </span>
                )}
              </div>
            )}
          </div>

          {/* Duplicate detection flow */}
          {localShowDuplicateCheck && !venueCreated && (
            <div className="mt-2">
              <DuplicateWarning
                venueName={editData.venueName || selectedPlace?.name || ''}
                lat={selectedPlace?.lat}
                lng={selectedPlace?.lng}
                onLinkExisting={handleLinkExisting}
                onCreateAnyway={doCreateVenue}
                onCancel={() => setLocalShowDuplicateCheck(false)}
              />
            </div>
          )}

          {/* Link existing venue */}
          {!venueCreated && (
            <VenueLinker
              venueName={editData.venueName || ''}
              lat={editData.lat}
              lng={editData.lng}
              venueId={editData.venueId || undefined}
              onLink={handleLinkExisting}
              onUnlink={() => {
                onMultiFieldChange({ venueId: '' });
                setVenueCreated(false);
              }}
            />
          )}

          {/* Show linked venue when linked */}
          {venueCreated && editData.venueId && (
            <VenueLinker
              venueName={editData.venueName || ''}
              venueId={editData.venueId}
              onLink={() => {}}
              onUnlink={() => {
                onMultiFieldChange({ venueId: '' });
                setVenueCreated(false);
              }}
            />
          )}

          {!venueCreated && !localShowDuplicateCheck && (
            <p className="text-[10px] mt-2" style={{ color: N.textMuted }}>
              Creates a new venue in Site Content &gt; Venues with exact Google Maps coordinates
            </p>
          )}
        </motion.div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════
// VENUE LOCATION LOOKUP
// ═══════════════════════════════════════════════════

function VenueLocationLookup({
  editData,
  onMultiFieldChange,
  selectedPlace,
  setSelectedPlace,
}: {
  editData: Record<string, any>;
  onMultiFieldChange: (updates: Record<string, any>) => void;
  selectedPlace: PlaceResult | null;
  setSelectedPlace: (place: PlaceResult | null) => void;
}) {
  const handlePlaceSelect = (place: PlaceResult) => {
    setSelectedPlace(place);
    // Auto-fill venue fields from place details
    onMultiFieldChange({
      name: place.name,
      district: place.district || editData.district || '',
      lat: place.lat,
      lng: place.lng,
      address: place.formattedAddress,
    });
  };

  const hasCoords = editData.lat && editData.lng;

  return (
    <div
      className="mt-4 p-5 sm:p-6"
      style={{
        backgroundColor: N.surface,
        border: `1.5px solid ${selectedPlace ? `${N.green}30` : `${N.blue}20`}`,
        borderRadius: '14px',
      }}
    >
      {/* Section header */}
      <div className="flex items-center gap-2 mb-4">
        <div className="w-7 h-7 flex items-center justify-center rounded-lg" style={{ backgroundColor: N.blueBg }}>
          <MapPin size={14} style={{ color: N.blue }} />
        </div>
        <div>
          <h3 className="text-[13px] font-semibold" style={{ color: N.text }}>Location Lookup</h3>
          <p className="text-[11px]" style={{ color: N.textMuted }}>Search Google Maps to set exact venue coordinates</p>
        </div>
      </div>

      {/* Google Places Autocomplete */}
      <GooglePlacesAutocomplete
        value={editData.name || ''}
        onSelect={handlePlaceSelect}
        placeholder="Search venue or address on Google Maps..."
        selectedPlace={selectedPlace}
      />

      {/* Coordinate display */}
      {hasCoords && (
        <div className="mt-3 grid grid-cols-2 gap-3">
          <div className="px-3 py-2 rounded-lg" style={{ backgroundColor: N.surfaceMuted, border: `1px solid ${N.border}` }}>
            <span className="text-[10px] uppercase tracking-wider font-semibold block" style={{ color: N.textMuted }}>Latitude</span>
            <span className="text-[13px] font-mono" style={{ color: N.text }}>{Number(editData.lat).toFixed(6)}</span>
          </div>
          <div className="px-3 py-2 rounded-lg" style={{ backgroundColor: N.surfaceMuted, border: `1px solid ${N.border}` }}>
            <span className="text-[10px] uppercase tracking-wider font-semibold block" style={{ color: N.textMuted }}>Longitude</span>
            <span className="text-[13px] font-mono" style={{ color: N.text }}>{Number(editData.lng).toFixed(6)}</span>
          </div>
        </div>
      )}

      {/* Auto-filled info */}
      {selectedPlace && (
        <motion.div
          initial={{ opacity: 0, y: -4 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-3 space-y-3"
        >
          {/* Auto-filled district */}
          {editData.district && (
            <div className="flex items-center gap-2 text-[12px]">
              <span style={{ color: N.textMuted }}>District auto-filled:</span>
              <span className="px-2 py-0.5 font-medium rounded" style={{ backgroundColor: `${N.blue}10`, color: N.blue }}>
                {editData.district}
              </span>
            </div>
          )}
        </motion.div>
      )}
    </div>
  );
}