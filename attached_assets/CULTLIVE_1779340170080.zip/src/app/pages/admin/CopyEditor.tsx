import { useState, useEffect, useCallback, useMemo } from 'react';
import { useOutletContext } from 'react-router';
import { motion, AnimatePresence } from 'motion/react';
import {
  Search, Save, Loader2, Check, ChevronDown, ChevronRight,
  Sparkles, RotateCcw, Globe, Edit3, Info,
} from 'lucide-react';
import { projectId, publicAnonKey } from '../../config/supabase';

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-d507b98c/cms`;

const N = {
  pageBg: '#FAFAF8',
  surface: '#FFFFFF',
  surfaceMuted: '#F3F3F0',
  border: 'rgba(0,0,0,0.06)',
  text: '#1A1A1A',
  textSecondary: '#5A5A5A',
  textMuted: '#9A9A9A',
  dark: '#1A1A1A',
  green: '#16A34A',
  greenBg: 'rgba(22,163,74,0.06)',
  amber: '#D97706',
  amberBg: 'rgba(217,119,6,0.06)',
  blue: '#2563EB',
  blueBg: 'rgba(37,99,235,0.05)',
  font: "'Inter', 'Noto Sans HK', system-ui, sans-serif",
};

function authHeaders(accessToken: string) {
  return {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${publicAnonKey}`,
    'X-Auth-Token': accessToken,
  };
}

// Default locale data — structured by section
const defaultLocale: Record<string, Record<string, string>> = {
  'nav': {
    'home': 'Home',
    'events': 'Events',
    'map': 'Map',
    'about': 'About',
    'contribute': 'Contribute',
  },
  'home': {
    'hero.title': 'Discover Hong Kong Culture',
    'hero.subtitle': 'Your guide to the city\'s vibrant cultural scene',
    'vibe.heading': 'Choose your vibe',
    'vibe.subheading': 'Each mode transforms how you experience the city',
    'cta.explore': 'Explore Events',
    'cta.map': 'Open Map',
  },
  'events': {
    'heading': 'What\'s Happening',
    'search.placeholder': 'Search events...',
    'empty': 'No events found',
    'filter.all': 'All',
    'featured': 'Featured',
    'ongoing': 'Now',
  },
  'map': {
    'heading': 'Explore the Map',
    'search.placeholder': 'Search venues...',
    'empty': 'No venues found',
    'details': 'View Details',
  },
  'contribute': {
    'hero.title': 'Share Your Story',
    'hero.subtitle': 'Found an amazing event, run club, or hidden gem in Hong Kong? Submit it.',
    'step.source': 'How would you like to submit?',
    'step.details': 'Event Details',
    'step.review': 'Review & Submit',
    'track.title': 'Track Your Submission',
    'cta.submit': 'Submit',
    'cta.parse': 'Parse',
  },
  'about': {
    'heading': 'About CULTIVE',
    'mission': 'Building Hong Kong\'s cultural map, together.',
    'description': 'CULTIVE is a community-powered platform for discovering cultural events and experiences across Hong Kong.',
  },
  'footer': {
    'copyright': '© 2026 CULTIVE 文化活',
    'tagline': 'Hong Kong\'s Cultural Events Platform',
  },
  'modes': {
    'night.label': 'Night',
    'night.tagline': 'After dark culture & underground scenes',
    'family.label': 'Family',
    'family.tagline': 'Kid-friendly adventures & experiences',
    'art.label': 'Art & Design',
    'art.tagline': 'Galleries, exhibitions & creative spaces',
    'food.label': 'Food',
    'food.tagline': 'Culinary events, markets & tastings',
    'lifestyle.label': 'Lifestyle',
    'lifestyle.tagline': 'Wellness, outdoors & community',
  },
};

// Chinese defaults
const defaultLocaleZh: Record<string, Record<string, string>> = {
  'nav': {
    'home': '首頁',
    'events': '活動',
    'map': '地圖',
    'about': '關於',
    'contribute': '投稿',
  },
  'home': {
    'hero.title': '探索香港文化',
    'hero.subtitle': '你的城市文化生活指南',
    'vibe.heading': '選擇你的風格',
    'vibe.subheading': '每種模式帶給你不同的城市體驗',
    'cta.explore': '探索活動',
    'cta.map': '打開地圖',
  },
  'events': {
    'heading': '最新活動',
    'search.placeholder': '搜尋活動...',
    'empty': '找不到活動',
    'filter.all': '全部',
    'featured': '精選',
    'ongoing': '進行中',
  },
  'modes': {
    'night.label': '夜生活',
    'family.label': '親子',
    'art.label': '藝術設計',
    'food.label': '美食',
    'lifestyle.label': '生活方式',
  },
};

interface CopyOverride {
  key: string; // e.g. "nav.home"
  en?: string;
  zh?: string;
  updatedAt?: string;
}

export function CopyEditor() {
  const { accessToken } = useOutletContext<{ accessToken: string }>();
  const [overrides, setOverrides] = useState<Record<string, CopyOverride>>({});
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set(['nav', 'home']));
  const [editingKey, setEditingKey] = useState<string | null>(null);
  const [editEn, setEditEn] = useState('');
  const [editZh, setEditZh] = useState('');
  const [saving, setSaving] = useState(false);
  const [translating, setTranslating] = useState<string | null>(null);
  const [batchTranslating, setBatchTranslating] = useState(false);

  // Load overrides from KV
  const loadOverrides = useCallback(async () => {
    if (!accessToken) return;
    try {
      const res = await fetch(`${API_BASE}/copy`, {
        headers: authHeaders(accessToken),
      });
      const data = await res.json();
      const map: Record<string, CopyOverride> = {};
      (data.overrides || []).forEach((o: CopyOverride) => {
        map[o.key] = o;
      });
      setOverrides(map);
    } catch (err) {
      console.log('Failed to load copy overrides:', err);
    }
    setLoading(false);
  }, [accessToken]);

  useEffect(() => { loadOverrides(); }, [loadOverrides]);

  // All sections from default locale
  const sections = useMemo(() => Object.keys(defaultLocale), []);

  // Flatten for search
  const allKeys = useMemo(() => {
    const keys: { section: string; key: string; fullKey: string; en: string; zh: string }[] = [];
    for (const section of sections) {
      for (const key of Object.keys(defaultLocale[section])) {
        const fullKey = `${section}.${key}`;
        const override = overrides[fullKey];
        keys.push({
          section,
          key,
          fullKey,
          en: override?.en || defaultLocale[section][key],
          zh: override?.zh || defaultLocaleZh[section]?.[key] || '',
        });
      }
    }
    return keys;
  }, [sections, overrides]);

  const filteredKeys = useMemo(() => {
    if (!searchQuery) return allKeys;
    const q = searchQuery.toLowerCase();
    return allKeys.filter(k =>
      k.fullKey.toLowerCase().includes(q) ||
      k.en.toLowerCase().includes(q) ||
      k.zh.toLowerCase().includes(q)
    );
  }, [allKeys, searchQuery]);

  const startEdit = (fullKey: string) => {
    const item = allKeys.find(k => k.fullKey === fullKey);
    if (!item) return;
    setEditingKey(fullKey);
    setEditEn(item.en);
    setEditZh(item.zh);
  };

  const handleSave = async () => {
    if (!editingKey || !accessToken) return;
    setSaving(true);
    try {
      await fetch(`${API_BASE}/copy/${encodeURIComponent(editingKey)}`, {
        method: 'PUT',
        headers: authHeaders(accessToken),
        body: JSON.stringify({ en: editEn, zh: editZh }),
      });
      await loadOverrides();
      setEditingKey(null);
    } catch (err) {
      console.log('Save copy error:', err);
    }
    setSaving(false);
  };

  const handleTranslate = async (fullKey: string) => {
    if (!accessToken) return;
    setTranslating(fullKey);
    try {
      const item = allKeys.find(k => k.fullKey === fullKey);
      if (!item?.en) return;
      const res = await fetch(`${API_BASE}/translate`, {
        method: 'POST',
        headers: authHeaders(accessToken),
        body: JSON.stringify({ text: item.en, from: 'en', to: 'zh-HK' }),
      });
      const data = await res.json();
      if (data.translated) {
        // Save the translation
        await fetch(`${API_BASE}/copy/${encodeURIComponent(fullKey)}`, {
          method: 'PUT',
          headers: authHeaders(accessToken),
          body: JSON.stringify({ en: item.en, zh: data.translated }),
        });
        await loadOverrides();
      }
    } catch (err) {
      console.log('Translate error:', err);
    }
    setTranslating(null);
  };

  const handleBatchTranslate = async (section: string) => {
    if (!accessToken) return;
    setBatchTranslating(true);
    const sectionKeys = allKeys.filter(k => k.section === section && !k.zh);
    for (const item of sectionKeys) {
      await handleTranslate(item.fullKey);
    }
    setBatchTranslating(false);
  };

  const toggleSection = (section: string) => {
    const next = new Set(expandedSections);
    if (next.has(section)) next.delete(section);
    else next.add(section);
    setExpandedSections(next);
  };

  const sectionLabels: Record<string, string> = {
    nav: 'Navigation',
    home: 'Homepage',
    events: 'Events Page',
    map: 'Map Page',
    contribute: 'Contribute Page',
    about: 'About Page',
    footer: 'Footer',
    modes: 'Mode Labels',
  };

  return (
    <div className="p-5 sm:p-8 lg:p-10 max-w-[860px] mx-auto" style={{ fontFamily: N.font }}>
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="mb-6">
        <p className="text-[11px] font-medium uppercase tracking-wider mb-1.5"
          style={{ color: N.textMuted }}>Tools</p>
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-[1.5rem] font-semibold tracking-tight" style={{ color: N.text }}>
              Copy Editor
            </h1>
            <p className="mt-1 text-[14px]" style={{ color: N.textMuted }}>
              Edit site copy and translations. Changes override static defaults.
            </p>
          </div>
          <div className="flex items-center gap-1.5">
            <Globe size={15} style={{ color: N.blue }} />
            <span className="text-[12px] font-medium" style={{ color: N.blue }}>EN / 中文</span>
          </div>
        </div>
      </motion.div>

      {/* Info */}
      <div className="flex items-start gap-2.5 p-3.5 mb-6" style={{
        backgroundColor: N.blueBg, borderRadius: '10px', border: '1px solid rgba(37,99,235,0.08)',
      }}>
        <Info size={15} className="flex-shrink-0 mt-0.5" style={{ color: N.blue }} />
        <p className="text-[12px] leading-relaxed" style={{ color: N.textSecondary }}>
          Each key has an English and Chinese (Traditional) value. The site displays English by default.
          Click the sparkle icon to auto-translate a field, or "Translate Missing" to batch-translate an entire section.
        </p>
      </div>

      {/* Search */}
      <div className="relative mb-5">
        <Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2" style={{ color: N.textMuted }} />
        <input type="text" value={searchQuery} onChange={e => setSearchQuery(e.target.value)}
          placeholder="Search keys, values..."
          className="w-full pl-10 pr-4 py-2.5 text-[14px] outline-none"
          style={{ backgroundColor: N.surface, border: `1px solid ${N.border}`, borderRadius: '10px', color: N.text }}
        />
      </div>

      {/* Sections */}
      {loading ? (
        <div className="flex items-center justify-center py-16">
          <Loader2 size={20} className="animate-spin" style={{ color: N.textMuted }} />
        </div>
      ) : (
        <div className="space-y-3">
          {sections.map(section => {
            const sectionKeys = filteredKeys.filter(k => k.section === section);
            if (sectionKeys.length === 0 && searchQuery) return null;
            const isExpanded = expandedSections.has(section);
            const modifiedCount = sectionKeys.filter(k => overrides[k.fullKey]).length;
            const missingZh = sectionKeys.filter(k => !k.zh).length;

            return (
              <div key={section} style={{ backgroundColor: N.surface, border: `1px solid ${N.border}`, borderRadius: '14px' }}>
                {/* Section header */}
                <button onClick={() => toggleSection(section)}
                  className="w-full flex items-center gap-3 px-4 py-3.5 cursor-pointer">
                  {isExpanded ? <ChevronDown size={14} style={{ color: N.textMuted }} /> : <ChevronRight size={14} style={{ color: N.textMuted }} />}
                  <span className="text-[13px] font-semibold flex-1 text-left" style={{ color: N.text }}>
                    {sectionLabels[section] || section}
                  </span>
                  <span className="text-[11px]" style={{ color: N.textMuted }}>{sectionKeys.length} keys</span>
                  {modifiedCount > 0 && (
                    <span className="text-[10px] px-1.5 py-0.5 font-medium" style={{
                      backgroundColor: N.blueBg, color: N.blue, borderRadius: '4px',
                    }}>{modifiedCount} modified</span>
                  )}
                  {missingZh > 0 && (
                    <button onClick={(e) => { e.stopPropagation(); handleBatchTranslate(section); }}
                      disabled={batchTranslating}
                      className="flex items-center gap-1 px-2 py-1 text-[10px] font-medium cursor-pointer"
                      style={{ backgroundColor: N.amberBg, color: N.amber, borderRadius: '5px' }}>
                      {batchTranslating ? <Loader2 size={10} className="animate-spin" /> : <Sparkles size={10} />}
                      Translate {missingZh} missing
                    </button>
                  )}
                </button>

                {/* Keys */}
                <AnimatePresence>
                  {isExpanded && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.2 }}
                      className="overflow-hidden">
                      <div style={{ borderTop: `1px solid ${N.border}` }}>
                        {sectionKeys.map(item => {
                          const isModified = !!overrides[item.fullKey];
                          const isEditing = editingKey === item.fullKey;

                          return (
                            <div key={item.fullKey} className="px-4 py-3"
                              style={{ borderBottom: `1px solid ${N.border}` }}>
                              {isEditing ? (
                                /* Edit mode */
                                <div>
                                  <div className="flex items-center gap-2 mb-2">
                                    <code className="text-[11px] px-1.5 py-0.5" style={{
                                      backgroundColor: N.surfaceMuted, borderRadius: '4px', color: N.textSecondary,
                                    }}>{item.fullKey}</code>
                                  </div>
                                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-3">
                                    <div>
                                      <label className="text-[10px] font-medium uppercase tracking-wider mb-1 block"
                                        style={{ color: N.textMuted }}>English</label>
                                      <input type="text" value={editEn} onChange={e => setEditEn(e.target.value)}
                                        className="w-full px-3 py-2 text-[13px] outline-none"
                                        style={{ backgroundColor: N.surfaceMuted, border: `1px solid ${N.border}`, borderRadius: '8px', color: N.text }} />
                                    </div>
                                    <div>
                                      <label className="text-[10px] font-medium uppercase tracking-wider mb-1 block"
                                        style={{ color: N.textMuted }}>中文 (繁體)</label>
                                      <div className="flex gap-1.5">
                                        <input type="text" value={editZh} onChange={e => setEditZh(e.target.value)}
                                          className="flex-1 px-3 py-2 text-[13px] outline-none"
                                          style={{ backgroundColor: N.surfaceMuted, border: `1px solid ${N.border}`, borderRadius: '8px', color: N.text }} />
                                        <button onClick={() => handleTranslate(item.fullKey)}
                                          disabled={translating === item.fullKey}
                                          className="p-2 cursor-pointer" style={{ backgroundColor: N.amberBg, borderRadius: '8px' }}
                                          title="Auto-translate">
                                          {translating === item.fullKey
                                            ? <Loader2 size={13} className="animate-spin" style={{ color: N.amber }} />
                                            : <Sparkles size={13} style={{ color: N.amber }} />}
                                        </button>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="flex gap-2">
                                    <button onClick={handleSave} disabled={saving}
                                      className="flex items-center gap-1 px-3 py-1.5 text-[12px] font-medium cursor-pointer"
                                      style={{ backgroundColor: N.dark, color: '#fff', borderRadius: '7px' }}>
                                      {saving ? <Loader2 size={12} className="animate-spin" /> : <Save size={12} />}
                                      Save
                                    </button>
                                    <button onClick={() => setEditingKey(null)}
                                      className="px-3 py-1.5 text-[12px] cursor-pointer"
                                      style={{ color: N.textMuted }}>
                                      Cancel
                                    </button>
                                  </div>
                                </div>
                              ) : (
                                /* Display mode */
                                <div className="flex items-center gap-3 group">
                                  {isModified && (
                                    <div className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: N.blue }} />
                                  )}
                                  <div className="flex-1 min-w-0">
                                    <code className="text-[11px] block truncate" style={{ color: N.textMuted }}>
                                      {item.key}
                                    </code>
                                    <div className="flex items-center gap-4 mt-0.5">
                                      <span className="text-[13px] truncate" style={{ color: N.text }}>{item.en}</span>
                                      {item.zh ? (
                                        <span className="text-[13px] truncate" style={{ color: N.textSecondary }}>{item.zh}</span>
                                      ) : (
                                        <span className="text-[11px] italic" style={{ color: N.textMuted }}>No translation</span>
                                      )}
                                    </div>
                                  </div>
                                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                    {!item.zh && (
                                      <button onClick={() => handleTranslate(item.fullKey)}
                                        disabled={translating === item.fullKey}
                                        className="p-1.5 cursor-pointer" title="Auto-translate">
                                        {translating === item.fullKey
                                          ? <Loader2 size={12} className="animate-spin" style={{ color: N.amber }} />
                                          : <Sparkles size={12} style={{ color: N.amber }} />}
                                      </button>
                                    )}
                                    <button onClick={() => startEdit(item.fullKey)}
                                      className="p-1.5 cursor-pointer" style={{ color: N.textMuted }}>
                                      <Edit3 size={12} />
                                    </button>
                                  </div>
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
