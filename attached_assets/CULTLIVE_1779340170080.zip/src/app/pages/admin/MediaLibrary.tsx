import { useState, useEffect, useCallback } from 'react';
import { useOutletContext } from 'react-router';
import { motion, AnimatePresence } from 'motion/react';
import {
  Upload, Trash2, Loader2, Image as ImageIcon, FileText,
  Copy, Check, ExternalLink, Search, Grid3X3, List, X,
  RefreshCw, Download,
} from 'lucide-react';
import { projectId, publicAnonKey } from '../../config/supabase';
import { ImageWithFallback } from '../../components/figma/ImageWithFallback';

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-d507b98c/cms`;

const N = {
  pageBg: '#FAFAF8',
  surface: '#FFFFFF',
  surfaceMuted: '#F3F3F0',
  border: 'rgba(0,0,0,0.06)',
  text: '#1A1A1A',
  textSecondary: '#5A5A5A',
  textMuted: '#9A9A9A',
  dark: '#1A1A1A',
  green: '#16A34A',
  greenBg: 'rgba(22,163,74,0.06)',
  red: '#DC2626',
  redBg: 'rgba(220,38,38,0.05)',
  blue: '#2563EB',
  blueBg: 'rgba(37,99,235,0.05)',
  font: "'Inter', 'Noto Sans HK', system-ui, sans-serif",
};

interface MediaFile {
  name: string;
  path: string;
  url: string;
  size: number;
  type: string;
  createdAt: string;
}

export function MediaLibrary() {
  const { accessToken } = useOutletContext<{ accessToken: string }>();
  const [files, setFiles] = useState<MediaFile[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [searchQuery, setSearchQuery] = useState('');
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState('');
  const [selectedFile, setSelectedFile] = useState<MediaFile | null>(null);
  const [copied, setCopied] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [dragOver, setDragOver] = useState(false);

  const loadFiles = useCallback(async () => {
    if (!accessToken) return;
    try {
      const res = await fetch(`${API_BASE}/media`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'X-Auth-Token': accessToken,
        },
      });
      const data = await res.json();
      setFiles(data.files || []);
    } catch (err) {
      console.log('Failed to load media:', err);
    }
    setLoading(false);
  }, [accessToken]);

  useEffect(() => { loadFiles(); }, [loadFiles]);

  const handleUpload = useCallback(async (fileList: FileList | File[]) => {
    const imageFiles = Array.from(fileList).filter(f => f.type.startsWith('image/'));
    if (imageFiles.length === 0) return;

    setUploading(true);
    setUploadProgress(`Uploading ${imageFiles.length} file${imageFiles.length > 1 ? 's' : ''}...`);

    try {
      const formData = new FormData();
      imageFiles.forEach(f => formData.append('files', f));

      const res = await fetch(`${API_BASE}/upload`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${publicAnonKey}` },
        body: formData,
      });
      const data = await res.json();
      setUploadProgress(`${data.count || 0} file${data.count !== 1 ? 's' : ''} uploaded`);
      await loadFiles();
    } catch (err: any) {
      console.log('Upload error:', err);
      setUploadProgress('Upload failed');
    }

    setUploading(false);
    setTimeout(() => setUploadProgress(''), 3000);
  }, [loadFiles]);

  const handleDelete = useCallback(async (path: string) => {
    if (!accessToken) return;
    try {
      await fetch(`${API_BASE}/media`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`,
          'X-Auth-Token': accessToken,
        },
        body: JSON.stringify({ paths: [path] }),
      });
      setDeleteConfirm(null);
      setSelectedFile(null);
      await loadFiles();
    } catch (err) {
      console.log('Delete error:', err);
    }
  }, [accessToken, loadFiles]);

  const handleRefreshUrls = useCallback(async () => {
    if (!accessToken) return;
    setRefreshing(true);
    try {
      const res = await fetch(`${API_BASE}/media/refresh-urls`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`,
          'X-Auth-Token': accessToken,
        },
      });
      await res.json();
      await loadFiles();
    } catch (err) {
      console.log('Refresh error:', err);
    }
    setRefreshing(false);
  }, [accessToken, loadFiles]);

  const copyUrl = (url: string) => {
    navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const formatSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  const filtered = files.filter(f =>
    !searchQuery || f.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="p-5 sm:p-8 lg:p-10 max-w-[1100px] mx-auto" style={{ fontFamily: N.font }}>
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="mb-6">
        <p className="text-[11px] font-medium uppercase tracking-wider mb-1.5"
          style={{ color: N.textMuted }}>Tools</p>
        <div className="flex items-center justify-between">
          <h1 className="text-[1.5rem] font-semibold tracking-tight" style={{ color: N.text }}>
            Media Library
          </h1>
          <div className="flex items-center gap-2">
            <button onClick={handleRefreshUrls} disabled={refreshing}
              className="flex items-center gap-1.5 px-3 py-1.5 text-[12px] font-medium cursor-pointer"
              style={{ backgroundColor: N.blueBg, color: N.blue, borderRadius: '8px' }}
              title="Refresh signed URLs (extend 7-day expiry)">
              {refreshing ? <Loader2 size={13} className="animate-spin" /> : <RefreshCw size={13} />}
              Refresh URLs
            </button>
            <span className="text-[13px]" style={{ color: N.textMuted }}>
              {files.length} file{files.length !== 1 ? 's' : ''}
            </span>
          </div>
        </div>
      </motion.div>

      {/* Upload Zone */}
      <div
        onDrop={e => { e.preventDefault(); setDragOver(false); handleUpload(e.dataTransfer.files); }}
        onDragOver={e => { e.preventDefault(); setDragOver(true); }}
        onDragLeave={() => setDragOver(false)}
        className="relative mb-6 transition-all"
        style={{
          border: `2px dashed ${dragOver ? N.dark : N.border}`,
          borderRadius: '14px',
          backgroundColor: dragOver ? 'rgba(0,0,0,0.02)' : N.surface,
          padding: '24px 16px',
        }}
      >
        <input type="file" accept="image/*" multiple
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" style={{ zIndex: 2 }}
          onChange={e => e.target.files && handleUpload(e.target.files)} />
        <div className="text-center pointer-events-none">
          {uploading ? (
            <div className="flex items-center justify-center gap-2">
              <Loader2 size={18} className="animate-spin" style={{ color: N.dark }} />
              <span className="text-[14px] font-medium" style={{ color: N.text }}>{uploadProgress}</span>
            </div>
          ) : uploadProgress ? (
            <div className="flex items-center justify-center gap-2">
              <Check size={16} style={{ color: N.green }} />
              <span className="text-[14px]" style={{ color: N.green }}>{uploadProgress}</span>
            </div>
          ) : (
            <>
              <Upload size={22} className="mx-auto mb-2" style={{ color: N.textMuted }} />
              <p className="text-[14px] font-medium" style={{ color: N.text }}>
                Drop images here or click to upload
              </p>
              <p className="text-[12px] mt-1" style={{ color: N.textMuted }}>
                JPEG, PNG, WebP, GIF up to 10 MB
              </p>
            </>
          )}
        </div>
      </div>

      {/* Toolbar */}
      <div className="flex items-center gap-3 mb-4">
        <div className="relative flex-1">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: N.textMuted }} />
          <input type="text" value={searchQuery} onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search files..."
            className="w-full pl-9 pr-3 py-2 text-[13px] outline-none"
            style={{ backgroundColor: N.surface, border: `1px solid ${N.border}`, borderRadius: '8px', color: N.text }}
          />
        </div>
        <button onClick={() => setViewMode(viewMode === 'grid' ? 'list' : 'grid')}
          className="p-2 cursor-pointer" style={{ color: N.textMuted }}>
          {viewMode === 'grid' ? <List size={16} /> : <Grid3X3 size={16} />}
        </button>
      </div>

      {/* Content */}
      {loading ? (
        <div className="flex items-center justify-center py-16">
          <Loader2 size={20} className="animate-spin" style={{ color: N.textMuted }} />
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16" style={{
          backgroundColor: N.surface, borderRadius: '16px', border: `1px solid ${N.border}`,
        }}>
          <ImageIcon size={28} style={{ color: N.textMuted }} className="mx-auto mb-2 opacity-40" />
          <p className="text-[14px]" style={{ color: N.textMuted }}>
            {files.length === 0 ? 'No files uploaded yet' : 'No files match your search'}
          </p>
        </div>
      ) : viewMode === 'grid' ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
          {filtered.map(file => (
            <button key={file.path} onClick={() => setSelectedFile(file)}
              className="text-left cursor-pointer transition-all overflow-hidden group"
              style={{
                backgroundColor: N.surface,
                border: `1.5px solid ${selectedFile?.path === file.path ? N.dark : N.border}`,
                borderRadius: '10px',
              }}>
              <div className="w-full aspect-square overflow-hidden relative">
                <ImageWithFallback src={file.url} alt={file.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
              </div>
              <div className="p-2">
                <p className="text-[11px] font-medium truncate" style={{ color: N.text }}>{file.name}</p>
                <p className="text-[10px]" style={{ color: N.textMuted }}>{formatSize(file.size)}</p>
              </div>
            </button>
          ))}
        </div>
      ) : (
        <div className="space-y-1">
          {filtered.map(file => (
            <button key={file.path} onClick={() => setSelectedFile(file)}
              className="w-full flex items-center gap-3 px-4 py-2.5 text-left cursor-pointer transition-colors"
              style={{
                backgroundColor: selectedFile?.path === file.path ? 'rgba(0,0,0,0.03)' : N.surface,
                border: `1px solid ${N.border}`, borderRadius: '10px',
              }}>
              <div className="w-10 h-10 flex-shrink-0 overflow-hidden rounded-lg">
                <ImageWithFallback src={file.url} alt={file.name} className="w-full h-full object-cover" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-[13px] font-medium truncate" style={{ color: N.text }}>{file.name}</p>
                <p className="text-[11px]" style={{ color: N.textMuted }}>{formatSize(file.size)}</p>
              </div>
              <p className="text-[11px] hidden sm:block" style={{ color: N.textMuted }}>
                {file.createdAt ? new Date(file.createdAt).toLocaleDateString() : '—'}
              </p>
            </button>
          ))}
        </div>
      )}

      {/* ═══ File Detail Panel ═══ */}
      <AnimatePresence>
        {selectedFile && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
            onClick={() => setSelectedFile(null)}
          >
            <div className="absolute inset-0 bg-black/30" />
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              onClick={e => e.stopPropagation()}
              className="relative w-full max-w-[500px] max-h-[85vh] overflow-y-auto"
              style={{ backgroundColor: N.surface, borderRadius: '16px', boxShadow: '0 24px 48px rgba(0,0,0,0.15)' }}
            >
              {/* Preview */}
              <div className="relative aspect-video overflow-hidden" style={{ borderRadius: '16px 16px 0 0' }}>
                <ImageWithFallback src={selectedFile.url} alt={selectedFile.name} className="w-full h-full object-contain"
                  style={{ backgroundColor: '#f0f0f0' }} />
                <button onClick={() => setSelectedFile(null)}
                  className="absolute top-3 right-3 p-1.5 cursor-pointer"
                  style={{ backgroundColor: 'rgba(0,0,0,0.5)', borderRadius: '8px' }}>
                  <X size={16} color="#fff" />
                </button>
              </div>

              <div className="p-5">
                <p className="text-[15px] font-medium mb-1" style={{ color: N.text }}>{selectedFile.name}</p>
                <p className="text-[12px] mb-4" style={{ color: N.textMuted }}>
                  {formatSize(selectedFile.size)}
                  {selectedFile.createdAt && ` · ${new Date(selectedFile.createdAt).toLocaleDateString()}`}
                </p>

                {/* URL Copy */}
                <div className="flex gap-2 mb-4">
                  <input type="text" readOnly value={selectedFile.url}
                    className="flex-1 px-3 py-2 text-[12px] outline-none truncate"
                    style={{ backgroundColor: N.surfaceMuted, border: `1px solid ${N.border}`, borderRadius: '8px', color: N.textMuted }}
                  />
                  <button onClick={() => copyUrl(selectedFile.url)}
                    className="flex items-center gap-1 px-3 py-2 text-[12px] font-medium cursor-pointer"
                    style={{ backgroundColor: N.dark, color: '#fff', borderRadius: '8px' }}>
                    {copied ? <Check size={12} /> : <Copy size={12} />}
                    {copied ? 'Copied' : 'Copy'}
                  </button>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2">
                  <a href={selectedFile.url} target="_blank" rel="noopener noreferrer"
                    className="flex items-center gap-1.5 px-3 py-2 text-[12px] font-medium cursor-pointer"
                    style={{ backgroundColor: N.blueBg, color: N.blue, borderRadius: '8px' }}>
                    <ExternalLink size={12} /> Open
                  </a>

                  {deleteConfirm === selectedFile.path ? (
                    <div className="flex items-center gap-2">
                      <button onClick={() => handleDelete(selectedFile.path)}
                        className="flex items-center gap-1 px-3 py-2 text-[12px] font-medium cursor-pointer"
                        style={{ backgroundColor: N.red, color: '#fff', borderRadius: '8px' }}>
                        <Trash2 size={12} /> Confirm
                      </button>
                      <button onClick={() => setDeleteConfirm(null)}
                        className="text-[12px] cursor-pointer" style={{ color: N.textMuted }}>Cancel</button>
                    </div>
                  ) : (
                    <button onClick={() => setDeleteConfirm(selectedFile.path)}
                      className="flex items-center gap-1.5 px-3 py-2 text-[12px] cursor-pointer"
                      style={{ color: N.red }}>
                      <Trash2 size={12} /> Delete
                    </button>
                  )}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
