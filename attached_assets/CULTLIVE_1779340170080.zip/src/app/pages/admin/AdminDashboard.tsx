import { useState, useEffect } from 'react';
import { Link, useOutletContext } from 'react-router';
import { motion } from 'motion/react';
import {
  Inbox, CheckCircle2, AlertTriangle, XCircle, Eye,
  Users, ArrowRight, Sparkles, ArrowUpRight, Trash2, Loader2, Database, Zap,
} from 'lucide-react';
import { fetchSubmissions, fetchContributors } from '../../hooks/useAdminApi';
import { CategoryAnalytics } from '../../components/admin/CategoryAnalytics';
import { projectId, publicAnonKey } from '../../config/supabase';
import { useData } from '../../context/DataContext';
import { getWebhooks, getRetryQueueSize } from '../../config/webhooks';

const N = {
  pageBg: '#FAFAF8',
  surface: '#FFFFFF',
  border: 'rgba(0,0,0,0.06)',
  text: '#1A1A1A',
  textSecondary: '#5A5A5A',
  textMuted: '#9A9A9A',
  dark: '#1A1A1A',
  green: '#16A34A',
  greenBg: 'rgba(22,163,74,0.06)',
  amber: '#D97706',
  amberBg: 'rgba(217,119,6,0.06)',
  red: '#DC2626',
  redBg: 'rgba(220,38,38,0.05)',
  blue: '#2563EB',
  blueBg: 'rgba(37,99,235,0.05)',
  font: "'Inter', 'Noto Sans HK', system-ui, sans-serif",
};

export function AdminDashboard() {
  const { accessToken } = useOutletContext<{ accessToken: string }>();
  const [counts, setCounts] = useState<Record<string, number>>({});
  const [recentSubmissions, setRecentSubmissions] = useState<any[]>([]);
  const [allSubmissions, setAllSubmissions] = useState<any[]>([]);
  const [contributorCount, setContributorCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [mockStats, setMockStats] = useState<{ venues: { mock: number; real: number }; events: { mock: number; real: number }; recaps: { mock: number; real: number } } | null>(null);
  const [purging, setPurging] = useState(false);
  const [purgeConfirm, setPurgeConfirm] = useState(false);
  const [purgeResult, setPurgeResult] = useState<{ venues: number; events: number; recaps: number; total: number } | null>(null);

  const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-d507b98c`;
  const { refresh: refreshData } = useData();

  const loadMockStats = async () => {
    try {
      const res = await fetch(`${API_BASE}/admin/mock-data/stats`, {
        headers: { 'Authorization': `Bearer ${publicAnonKey}` },
      });
      const data = await res.json();
      if (data.stats) setMockStats(data.stats);
    } catch (err) {
      console.log('Failed to load mock stats:', err);
    }
  };

  const purgeMockData = async () => {
    setPurging(true);
    setPurgeResult(null);
    try {
      const res = await fetch(`${API_BASE}/admin/mock-data`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${publicAnonKey}` },
      });
      const data = await res.json();
      if (data.status === 'purged') {
        setPurgeResult(data);
        setPurgeConfirm(false);
        loadMockStats();
        // Clear session cache and refresh DataContext so site content updates immediately
        try { sessionStorage.removeItem('cultive_data_cache'); } catch {}
        await refreshData();
      }
    } catch (err) {
      console.log('Failed to purge mock data:', err);
    }
    setPurging(false);
  };

  useEffect(() => {
    if (!accessToken) return;
    const load = async () => {
      try {
        const [subData, conData] = await Promise.all([
          fetchSubmissions(accessToken),
          fetchContributors(accessToken).catch(() => ({ contributors: [] })),
        ]);
        setCounts(subData.counts || {});
        setRecentSubmissions((subData.submissions || []).slice(0, 5));
        setAllSubmissions(subData.submissions || []);
        setContributorCount(conData.contributors?.length || 0);

        // Auto-sync hidden IDs blacklist to catch any previously rejected/deleted items
        fetch(`https://${projectId}.supabase.co/functions/v1/make-server-d507b98c/cms/hidden-ids/sync`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'X-Auth-Token': accessToken },
        }).then(r => r.json()).then(res => {
          if (res.added > 0) console.log(`[CULTIVE] Auto-synced ${res.added} rejected items to hidden blacklist`);
        }).catch(() => {});
      } catch (err) {
        console.log('Dashboard load error:', err);
      }
      setLoading(false);
    };
    load();
    loadMockStats();
  }, [accessToken]);

  const statCards = [
    { label: 'Pending Review', value: (counts['ai-approved'] || 0) + (counts['ai-flagged'] || 0), icon: AlertTriangle, color: N.amber, bg: N.amberBg, link: '/admin/submissions/pending' },
    { label: 'Approved', value: counts.approved || 0, icon: CheckCircle2, color: N.green, bg: N.greenBg, link: '/admin/submissions/approved' },
    { label: 'Published', value: counts.published || 0, icon: Eye, color: N.blue, bg: N.blueBg, link: '/admin/submissions/published' },
    { label: 'Rejected', value: counts.rejected || 0, icon: XCircle, color: N.red, bg: N.redBg, link: '/admin/submissions/rejected' },
    { label: 'Total Submissions', value: counts.total || 0, icon: Inbox, color: N.textMuted, bg: 'rgba(0,0,0,0.03)', link: '/admin/submissions' },
    { label: 'Contributors', value: contributorCount, icon: Users, color: N.blue, bg: N.blueBg, link: '/admin/contributors' },
  ];

  return (
    <div className="p-5 sm:p-8 lg:p-10 max-w-[1100px] mx-auto" style={{ fontFamily: N.font }}>
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
        className="mb-8">
        <p className="text-[11px] font-medium uppercase tracking-wider mb-1.5"
          style={{ color: N.textMuted }}>Overview</p>
        <h1 className="text-[1.75rem] font-semibold tracking-tight" style={{ color: N.text }}>
          Dashboard
        </h1>
        <p className="mt-1 text-[15px]" style={{ color: N.textMuted }}>
          Here's what's happening with your submissions today.
        </p>
      </motion.div>

      {/* Stat Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-8">
        {statCards.map((card, i) => (
          <motion.div key={card.label}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.04 }}>
            <Link to={card.link}
              className="block p-4 sm:p-5 transition-shadow hover:shadow-sm group"
              style={{ backgroundColor: N.surface, border: `1px solid ${N.border}`, borderRadius: '16px' }}>
              <div className="flex items-center justify-between mb-3">
                <div className="w-8 h-8 flex items-center justify-center"
                  style={{ backgroundColor: card.bg, borderRadius: '10px' }}>
                  <card.icon size={15} style={{ color: card.color }} />
                </div>
                <ArrowUpRight size={13}
                  className="opacity-0 group-hover:opacity-100 transition-opacity"
                  style={{ color: N.textMuted }} />
              </div>
              <p className="text-2xl sm:text-[1.75rem] font-semibold" style={{ color: N.text }}>
                {loading ? '—' : card.value}
              </p>
              <p className="text-[13px] mt-0.5" style={{ color: N.textMuted }}>
                {card.label}
              </p>
            </Link>
          </motion.div>
        ))}
      </div>

      {/* Quick Actions + Recent */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-8">
        {/* Quick Actions */}
        <div className="p-5" style={{
          backgroundColor: N.surface, border: `1px solid ${N.border}`, borderRadius: '16px',
        }}>
          <p className="text-[11px] font-medium uppercase tracking-wider mb-4"
            style={{ color: N.textMuted }}>Quick Actions</p>
          <div className="space-y-2">
            <Link to="/admin/submissions/pending"
              className="flex items-center justify-between p-3 transition-colors group"
              style={{ backgroundColor: N.amberBg, borderRadius: '10px' }}>
              <div className="flex items-center gap-2.5">
                <AlertTriangle size={14} style={{ color: N.amber }} />
                <span className="text-[13px] font-medium" style={{ color: N.text }}>Review pending submissions</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="text-[13px] font-semibold" style={{ color: N.amber }}>
                  {(counts['ai-approved'] || 0) + (counts['ai-flagged'] || 0)}
                </span>
                <ArrowRight size={13} style={{ color: N.amber }}
                  className="group-hover:translate-x-0.5 transition-transform" />
              </div>
            </Link>
            <Link to="/admin/submissions/approved"
              className="flex items-center justify-between p-3 transition-colors group"
              style={{ backgroundColor: N.greenBg, borderRadius: '10px' }}>
              <div className="flex items-center gap-2.5">
                <CheckCircle2 size={14} style={{ color: N.green }} />
                <span className="text-[13px] font-medium" style={{ color: N.text }}>Publish approved items</span>
              </div>
              <ArrowRight size={13} style={{ color: N.green }}
                className="group-hover:translate-x-0.5 transition-transform" />
            </Link>
            <Link to="/contribute" target="_blank"
              className="flex items-center justify-between p-3 transition-colors group"
              style={{ backgroundColor: N.blueBg, borderRadius: '10px' }}>
              <div className="flex items-center gap-2.5">
                <Sparkles size={14} style={{ color: N.blue }} />
                <span className="text-[13px] font-medium" style={{ color: N.text }}>View contributor portal</span>
              </div>
              <ArrowRight size={13} style={{ color: N.blue }}
                className="group-hover:translate-x-0.5 transition-transform" />
            </Link>
            <Link to="/admin/webhooks"
              className="flex items-center justify-between p-3 transition-colors group"
              style={{ backgroundColor: 'rgba(178,72,58,0.05)', borderRadius: '10px' }}>
              <div className="flex items-center gap-2.5">
                <Zap size={14} style={{ color: '#B2483A' }} />
                <span className="text-[13px] font-medium" style={{ color: N.text }}>Manage webhooks</span>
              </div>
              <div className="flex items-center gap-1.5">
                {(() => {
                  const hookCount = getWebhooks().length;
                  const retries = getRetryQueueSize();
                  return (
                    <>
                      <span className="text-[13px] font-semibold" style={{ color: '#B2483A' }}>
                        {hookCount}
                      </span>
                      {retries > 0 && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded" style={{ backgroundColor: 'rgba(217,119,6,0.1)', color: N.amber }}>
                          {retries} retrying
                        </span>
                      )}
                    </>
                  );
                })()}
                <ArrowRight size={13} style={{ color: '#B2483A' }}
                  className="group-hover:translate-x-0.5 transition-transform" />
              </div>
            </Link>
          </div>
        </div>

        {/* Recent */}
        <div className="p-5" style={{
          backgroundColor: N.surface, border: `1px solid ${N.border}`, borderRadius: '16px',
        }}>
          <div className="flex items-center justify-between mb-4">
            <p className="text-[11px] font-medium uppercase tracking-wider"
              style={{ color: N.textMuted }}>Recent Submissions</p>
            <Link to="/admin/submissions" className="text-[13px] hover:underline"
              style={{ color: N.blue }}>View all</Link>
          </div>
          {recentSubmissions.length === 0 ? (
            <div className="text-center py-10">
              <Inbox size={24} style={{ color: N.textMuted }} className="mx-auto mb-2 opacity-40" />
              <p className="text-[13px]" style={{ color: N.textMuted }}>No submissions yet</p>
              <p className="text-[12px] mt-1" style={{ color: N.textMuted }}>
                Share the <Link to="/contribute" className="underline" style={{ color: N.blue }}>contributor portal</Link> to get started
              </p>
            </div>
          ) : (
            <div className="space-y-1">
              {recentSubmissions.map(sub => (
                <div key={sub.id} className="flex items-center gap-3 p-2 rounded-lg">
                  {sub.images?.[0] ? (
                    <div className="w-9 h-9 flex-shrink-0 overflow-hidden rounded-lg">
                      <img src={sub.images[0]} alt="" className="w-full h-full object-cover" />
                    </div>
                  ) : (
                    <div className="w-9 h-9 flex-shrink-0 flex items-center justify-center rounded-lg"
                      style={{ backgroundColor: 'rgba(0,0,0,0.03)' }}>
                      <Inbox size={13} style={{ color: N.textMuted }} />
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <p className="text-[13px] font-medium truncate" style={{ color: N.text }}>
                      {sub.title || 'Untitled'}
                    </p>
                    <p className="text-[12px]" style={{ color: N.textMuted }}>
                      {sub.contributorName || 'Anonymous'} · <StatusBadge status={sub.status} />
                    </p>
                  </div>
                  <span className="text-[12px] flex-shrink-0 font-semibold" style={{
                    color: sub.aiScore >= 70 ? N.green : sub.aiScore >= 40 ? N.amber : N.red,
                  }}>
                    {sub.aiScore}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Mock Data Management */}
      {mockStats && (mockStats.venues.mock > 0 || mockStats.events.mock > 0 || mockStats.recaps.mock > 0) && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
          className="mb-8 p-5" style={{
            backgroundColor: '#FFFBEB', border: '1px solid #FDE68A', borderRadius: '16px',
          }}>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 flex items-center justify-center" style={{ backgroundColor: '#FEF3C7', borderRadius: '10px' }}>
                <Database size={15} style={{ color: '#92400E' }} />
              </div>
              <div>
                <p className="text-[13px] font-semibold" style={{ color: '#92400E' }}>Mock Data</p>
                <p className="text-[11px]" style={{ color: '#B45309' }}>
                  {mockStats.venues.mock + mockStats.events.mock + mockStats.recaps.mock} mock items in database
                </p>
              </div>
            </div>
            {!purgeConfirm ? (
              <button
                onClick={() => setPurgeConfirm(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 text-[12px] font-medium cursor-pointer transition-colors hover:bg-red-100"
                style={{ color: '#DC2626', backgroundColor: '#FEF2F2', borderRadius: '8px', border: '1px solid #FECACA' }}>
                <Trash2 size={12} /> Purge All Mock Data
              </button>
            ) : (
              <div className="flex items-center gap-2">
                <button onClick={() => setPurgeConfirm(false)}
                  className="px-3 py-1.5 text-[12px] font-medium cursor-pointer transition-colors"
                  style={{ color: N.textMuted, borderRadius: '8px' }}>
                  Cancel
                </button>
                <button onClick={purgeMockData} disabled={purging}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-[12px] font-semibold cursor-pointer transition-colors"
                  style={{ color: '#fff', backgroundColor: '#DC2626', borderRadius: '8px' }}>
                  {purging ? <Loader2 size={12} className="animate-spin" /> : <Trash2 size={12} />}
                  {purging ? 'Purging...' : 'Confirm Purge'}
                </button>
              </div>
            )}
          </div>

          <div className="grid grid-cols-3 gap-3">
            {[
              { label: 'Venues', mock: mockStats.venues.mock, real: mockStats.venues.real },
              { label: 'Events', mock: mockStats.events.mock, real: mockStats.events.real },
              { label: 'Recaps', mock: mockStats.recaps.mock, real: mockStats.recaps.real },
            ].map(item => (
              <div key={item.label} className="p-3" style={{ backgroundColor: 'rgba(255,255,255,0.7)', borderRadius: '10px', border: '1px solid rgba(253,230,138,0.5)' }}>
                <p className="text-[11px] font-medium mb-1" style={{ color: '#B45309' }}>{item.label}</p>
                <div className="flex items-baseline gap-2">
                  <span className="text-lg font-semibold" style={{ color: '#92400E' }}>{item.mock}</span>
                  <span className="text-[11px]" style={{ color: '#B45309' }}>mock</span>
                  <span className="text-[11px]" style={{ color: '#059669' }}>· {item.real} real</span>
                </div>
              </div>
            ))}
          </div>

          {purgeResult && (
            <div className="mt-3 p-3 flex items-center gap-2" style={{ backgroundColor: 'rgba(22,163,74,0.08)', borderRadius: '10px' }}>
              <CheckCircle2 size={14} style={{ color: N.green }} />
              <p className="text-[12px] font-medium" style={{ color: N.green }}>
                Purged {purgeResult.total} mock items: {purgeResult.venues} venues, {purgeResult.events} events, {purgeResult.recaps} recaps
              </p>
            </div>
          )}
        </motion.div>
      )}

      {/* Category Analytics */}
      {!loading && allSubmissions.length > 0 && (
        <div className="mb-8">
          <p className="text-[11px] font-medium uppercase tracking-wider mb-4"
            style={{ color: N.textMuted }}>Category Analytics</p>
          <CategoryAnalytics submissions={allSubmissions} />
        </div>
      )}
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const config: Record<string, { color: string; bg: string; label: string }> = {
    'pending': { color: '#9A9A9A', bg: 'rgba(0,0,0,0.04)', label: 'Pending' },
    'ai-approved': { color: '#16A34A', bg: 'rgba(22,163,74,0.06)', label: 'AI Approved' },
    'ai-flagged': { color: '#D97706', bg: 'rgba(217,119,6,0.06)', label: 'Flagged' },
    'approved': { color: '#16A34A', bg: 'rgba(22,163,74,0.08)', label: 'Approved' },
    'published': { color: '#2563EB', bg: 'rgba(37,99,235,0.06)', label: 'Published' },
    'rejected': { color: '#DC2626', bg: 'rgba(220,38,38,0.06)', label: 'Rejected' },
  };
  const c = config[status] || config.pending;
  return (
    <span className="inline-flex px-1.5 py-0.5 text-[10px] font-medium" style={{
      backgroundColor: c.bg, color: c.color, borderRadius: '4px',
    }}>{c.label}</span>
  );
}