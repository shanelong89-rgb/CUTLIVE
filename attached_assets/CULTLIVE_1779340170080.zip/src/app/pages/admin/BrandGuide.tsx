/**
 * BrandGuide — /admin/brand-guide
 * Interactive brand & design-system reference for all 6 CULTIVE visual modes.
 * Lives inside the admin CMS under the "Tools" group.
 */
import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Palette, Type, Layers, Copy, Check, ChevronDown,
  Sparkles, Globe2, Ruler, Frame, BookOpen,
  PaintBucket, Eye, Minus, MousePointerClick,
  Download,
} from 'lucide-react';

// ═══════════════════════════════════════════════════════════════════
// DATA
// ═══════════════════════════════════════════════════════════════════

type ModeKey = 'default' | 'degen' | 'artsy' | 'foodie' | 'family' | 'lifestyle';

interface ModeSpec {
  key: ModeKey;
  name: string;
  nameZh: string;
  tagline: string;
  aesthetic: string;
  accentColor: string;
  pageBg: string;
  surfaceBg: string;
  cardBg: string;
  cardBorder: string;
  textPrimary: string;
  textSecondary: string;
  textMuted: string;
  headingFont: string;
  headingFontName: string;
  bodyFont: string;
  bodyFontName: string;
  borderRadius: string;
  cardRadius: string;
  imageRadius: string;
  spacingScale: number;
  navBg: string;
  isDark: boolean;
  markerColor: string;
  gradient: string;
  designLanguage: string[];
  doList: string[];
  dontList: string[];
}

const modes: ModeSpec[] = [
  {
    key: 'default',
    name: 'Default / Editorial',
    nameZh: '預設',
    tagline: 'Warm, minimal editorial — the neutral canvas',
    aesthetic: 'editorial-minimal',
    accentColor: '#1A1A1A',
    pageBg: '#FAFAF8',
    surfaceBg: '#F3F3F0',
    cardBg: '#FFFFFF',
    cardBorder: 'rgba(0,0,0,0.06)',
    textPrimary: '#1A1A1A',
    textSecondary: '#5A5A5A',
    textMuted: '#9A9A9A',
    headingFont: "'Archivo Black', sans-serif",
    headingFontName: 'Archivo Black',
    bodyFont: "'Inter', sans-serif",
    bodyFontName: 'Inter',
    borderRadius: '4px',
    cardRadius: '4px',
    imageRadius: '4px',
    spacingScale: 1,
    navBg: 'rgba(250,250,248,0.92)',
    isDark: false,
    markerColor: '#1A1A1A',
    gradient: 'none',
    designLanguage: [
      'Rule-of-thirds grid layouts (1fr / 2fr)',
      'Hairline dividers: 1px rgba(0,0,0,0.06)',
      'Uppercase micro-labels: 0.55rem · 600 weight · 0.18em tracking',
      'Warm off-white palette (#FAFAF8)',
      'Sharper 4px border radii — editorial precision',
      'Oversized numbering for editorial hierarchy',
      'Light/dark toggle via NeutralThemeContext',
    ],
    doList: [
      'Use Archivo Black for hero headlines only',
      'Pair with Inter for all body and UI text',
      'Use hairline borders (1px), never thick dividers',
      'Keep micro-labels uppercase with 0.18em spacing',
      'Embrace generous whitespace',
    ],
    dontList: [
      'Use rounded corners > 4px in editorial sections',
      'Mix heading fonts from other modes',
      'Use saturated or bright accent colors',
      'Overuse bold — reserve weight for hierarchy',
    ],
  },
  {
    key: 'degen',
    name: 'Night / Degen',
    nameZh: '夜行者',
    tagline: 'Bold poster energy — after-dark culture',
    aesthetic: 'bold-poster',
    accentColor: '#D600FF',
    pageBg: '#EDFF00',
    surfaceBg: '#E5F500',
    cardBg: '#0A0A0A',
    cardBorder: 'rgba(0,0,0,0.08)',
    textPrimary: '#0A0A0A',
    textSecondary: '#333333',
    textMuted: '#666666',
    headingFont: "'Space Grotesk', sans-serif",
    headingFontName: 'Space Grotesk',
    bodyFont: "'Inter', sans-serif",
    bodyFontName: 'Inter',
    borderRadius: '4px',
    cardRadius: '6px',
    imageRadius: '4px',
    spacingScale: 1,
    navBg: 'rgba(237,255,0,0.94)',
    isDark: false,
    markerColor: '#D600FF',
    gradient: 'from-fuchsia-500 to-purple-600',
    designLanguage: [
      'Acid yellow (#EDFF00) background — poster aesthetic',
      'Fuchsia (#D600FF) accent for interactive elements',
      'All-caps headings with tight tracking',
      'Dark cards (#0A0A0A) on bright backgrounds — high contrast',
      'Brutalist sharp 4-6px border radii',
      'Sticker / badge UI elements with rotate() transforms',
    ],
    doList: [
      'Use Space Grotesk for headings',
      'Keep acid-yellow + fuchsia pairing consistent',
      'Cards = dark (#0A0A0A) on yellow backgrounds',
      'Uppercase, bold typography for energy',
      'Use transform: rotate() for sticker effects',
    ],
    dontList: [
      'Use pastel or muted colors',
      'Use serif fonts — geometric sans only',
      'Add rounded corners > 6px',
      'Mix with other mode aesthetics',
    ],
  },
  {
    key: 'artsy',
    name: 'Art & Design',
    nameZh: '藝術',
    tagline: 'Gallery-white minimalism — editorial refinement',
    aesthetic: 'editorial-minimal',
    accentColor: '#8338EC',
    pageBg: '#F5F1EB',
    surfaceBg: '#EFEBE4',
    cardBg: '#FFFFFF',
    cardBorder: 'rgba(0,0,0,0.08)',
    textPrimary: '#1a1a1a',
    textSecondary: '#4a4a4a',
    textMuted: '#8a8a8a',
    headingFont: "'Playfair Display', serif",
    headingFontName: 'Playfair Display',
    bodyFont: "'Cormorant Garamond', serif",
    bodyFontName: 'Cormorant Garamond',
    borderRadius: '2px',
    cardRadius: '0px',
    imageRadius: '0px',
    spacingScale: 1.5,
    navBg: 'rgba(245,241,235,0.92)',
    isDark: false,
    markerColor: '#8338EC',
    gradient: 'from-violet-500 to-indigo-700',
    designLanguage: [
      'Gallery-white, zero-radius cards — like museum walls',
      'Generous spacing (1.5× scale) for breathing room',
      'Serif-only typography — Playfair headings + Cormorant body',
      'Deep violet (#8338EC / #3d2b7a) accent',
      'Minimal chrome — content IS the interface',
      'Full-bleed images, no visible borders on imagery',
    ],
    doList: [
      'Use Playfair Display for headings, Cormorant Garamond for body',
      'Set border-radius to 0px for cards and images',
      'Use 1.5× spacing everywhere',
      'Let images speak — minimal overlays',
      'Use italic Playfair for elegant emphasis',
    ],
    dontList: [
      'Add rounded corners',
      'Use sans-serif fonts in content areas',
      'Crowd elements — spacing is critical',
      'Use bright, saturated backgrounds',
    ],
  },
  {
    key: 'foodie',
    name: 'Food & Dining',
    nameZh: '美食',
    tagline: 'Dark luxury — rich magazine editorial',
    aesthetic: 'rich-magazine',
    accentColor: '#2563EB',
    pageBg: '#0A1220',
    surfaceBg: '#0E1A2E',
    cardBg: '#122240',
    cardBorder: 'rgba(37,99,235,0.12)',
    textPrimary: '#E8F0FF',
    textSecondary: 'rgba(232,240,255,0.7)',
    textMuted: 'rgba(232,240,255,0.4)',
    headingFont: "'DM Sans', sans-serif",
    headingFontName: 'DM Sans',
    bodyFont: "'DM Sans', sans-serif",
    bodyFontName: 'DM Sans',
    borderRadius: '24px',
    cardRadius: '24px',
    imageRadius: '20px',
    spacingScale: 1,
    navBg: 'rgba(10,18,32,0.92)',
    isDark: true,
    markerColor: '#2563EB',
    gradient: 'from-blue-500 to-blue-700',
    designLanguage: [
      'Deep navy (#0A1220) — luxury magazine feel',
      'Blue accent (#2563EB) for CTAs and interactive',
      'Generous 24px border-radii — soft premium surfaces',
      'Glassmorphic overlays with backdrop-blur',
      'Full DM Sans for cohesive modern typography',
      'Star ratings & price indicators as visual currency',
    ],
    doList: [
      'Use DM Sans for everything',
      'Keep backgrounds dark, text #E8F0FF',
      'Use semi-transparent borders (rgba blue)',
      'Apply backdrop-blur for layered glass',
      'Use 24px radii consistently',
    ],
    dontList: [
      'Use light backgrounds — always dark',
      'Mix serif fonts',
      'Use sharp corners',
      'Use pure white text — prefer #E8F0FF',
    ],
  },
  {
    key: 'family',
    name: 'Family',
    nameZh: '親子',
    tagline: 'Warm, playful, rounded — inviting & friendly',
    aesthetic: 'warm-playful',
    accentColor: '#FF8C42',
    pageBg: '#FFF8F0',
    surfaceBg: '#FFF2E8',
    cardBg: '#FFFFFF',
    cardBorder: 'rgba(0,0,0,0.06)',
    textPrimary: '#2D2A32',
    textSecondary: '#6B6574',
    textMuted: '#A39DAE',
    headingFont: "'Nunito', sans-serif",
    headingFontName: 'Nunito',
    bodyFont: "'Nunito', sans-serif",
    bodyFontName: 'Nunito',
    borderRadius: '28px',
    cardRadius: '32px',
    imageRadius: '28px',
    spacingScale: 1.2,
    navBg: 'rgba(255,248,240,0.92)',
    isDark: false,
    markerColor: '#FF8C42',
    gradient: 'from-orange-400 to-amber-500',
    designLanguage: [
      'Peachy warmth (#FFF8F0) — soft & approachable',
      'Very generous radii (28-32px) — pill-shaped, friendly',
      'Orange accent (#FF8C42) — energetic but warm',
      'Nunito throughout — rounded letterforms match the UI',
      'Age-group badges and activity icons',
      'Slightly increased spacing (1.2×)',
    ],
    doList: [
      'Use Nunito for all text',
      'Keep corners very rounded (28-32px)',
      'Use warm oranges and peach tones',
      'Add playful emoji/icon accents where appropriate',
      'Optimize readability for quick parent scanning',
    ],
    dontList: [
      'Use dark or moody palettes',
      'Use sharp corners or angular design',
      'Use condensed or overly stylized fonts',
      'Create dense, information-heavy layouts',
    ],
  },
  {
    key: 'lifestyle',
    name: 'Lifestyle',
    nameZh: '生活',
    tagline: 'Organic, earthy, editorial — community-first',
    aesthetic: 'lifestyle-bold',
    accentColor: '#2D6A4F',
    pageBg: '#FAFAF5',
    surfaceBg: '#F2EDE4',
    cardBg: '#1C1C1C',
    cardBorder: 'rgba(45,106,79,0.12)',
    textPrimary: '#0A0A0A',
    textSecondary: '#5A5A5A',
    textMuted: '#8A8580',
    headingFont: "'Playfair Display', serif",
    headingFontName: 'Playfair Display',
    bodyFont: "'DM Sans', sans-serif",
    bodyFontName: 'DM Sans',
    borderRadius: '16px',
    cardRadius: '20px',
    imageRadius: '16px',
    spacingScale: 1,
    navBg: 'rgba(250,250,245,0.94)',
    isDark: false,
    markerColor: '#2D6A4F',
    gradient: 'from-green-500 to-emerald-600',
    designLanguage: [
      'Cream + forest green (#2D6A4F) — natural, organic',
      'Serif headings (Playfair) + sans body (DM Sans) — editorial contrast',
      'Paper-texture backgrounds for warmth',
      'Dark cards (#1C1C1C) on light backgrounds for events',
      'Category pills with single-word italic labels ("run.", "feel.")',
      'Community-first language and participatory CTAs',
      'Extended lifestyle tokens in LC/LF objects (lifestyle-data.ts)',
    ],
    doList: [
      'Use Playfair Display headings + DM Sans body',
      'Pair cream backgrounds with forest green accents',
      'Use lowercase italic single-word labels',
      'Add paper texture overlay for warmth',
      'Keep the tone community-oriented',
    ],
    dontList: [
      'Use bright or neon colors — stay earthy',
      'Use uppercase aggressive typography',
      'Mix in other mode accent colors',
      'Forget the serif/sans pairing — it defines this mode',
    ],
  },
];

const FONT_STACK = [
  { name: 'Archivo Black', usage: 'Default mode hero headlines', weights: ['400'], style: 'Display / Impact' },
  { name: 'Inter', usage: 'Default body, UI elements, system font', weights: ['300','400','500','600'], style: 'Swiss / Neutral' },
  { name: 'Space Grotesk', usage: 'Night mode headings', weights: ['300','400','500','600','700'], style: 'Geometric / Tech' },
  { name: 'Playfair Display', usage: 'Art & Lifestyle headings', weights: ['400','500','600','700','800','900'], style: 'Transitional Serif' },
  { name: 'Cormorant Garamond', usage: 'Art mode body text', weights: ['300','400','500','600'], style: 'Classical Serif' },
  { name: 'DM Sans', usage: 'Food & Lifestyle body', weights: ['300','400','500','600','700','800'], style: 'Geometric / Clean' },
  { name: 'Nunito', usage: 'Family mode — all text', weights: ['400','500','600','700','800'], style: 'Rounded / Friendly' },
  { name: 'Noto Sans HK', usage: 'Chinese 繁體中文 across all modes', weights: ['300','400','500','700'], style: 'CJK Sans-serif' },
  { name: 'Instrument Serif', usage: 'Accent / editorial italic', weights: ['400'], style: 'Elegant Serif' },
  { name: 'DM Serif Display', usage: 'Accent display headers', weights: ['400'], style: 'Display Serif' },
  { name: 'Sora', usage: 'Alternative UI font', weights: ['300','400','500','600'], style: 'Geometric Sans' },
];

const SPACING = [
  { token: 'Micro-label', value: '0.55rem / 600 / 0.18em / uppercase', usage: 'Section labels, category badges, mode labels' },
  { token: 'Card padding', value: '16px (default) · 20px (artsy) · 12px (compact)', usage: 'Interior card spacing' },
  { token: 'Section gap', value: '48–64px between major sections', usage: 'Vertical rhythm on home pages' },
  { token: 'Grid system', value: '1fr / 2fr rule-of-thirds · max-width: 1200px', usage: 'Content layout grids' },
  { token: 'Hairline divider', value: '1px solid rgba(0,0,0,0.06)', usage: 'Section separators in light modes' },
  { token: 'Nav height', value: '64px desktop · 56px mobile', usage: 'Fixed top navigation bar' },
  { token: 'Bottom nav', value: '64px + safe-area-inset-bottom', usage: 'Mobile bottom navigation' },
  { token: 'Map sidebar', value: '400px fixed · 100% mobile', usage: 'Desktop map layout' },
];

// ═══════════════════════════════════════════════════════════════════
// UTILITIES
// ═══════════════════════════════════════════════════════════════════

const N = {
  pageBg: '#FAFAF8',
  surface: '#FFFFFF',
  text: '#1A1A1A',
  textMuted: '#9A9A9A',
  border: 'rgba(0,0,0,0.06)',
  font: "'Inter', 'Noto Sans HK', system-ui, sans-serif",
};

function Cp({ text }: { text: string }) {
  const [ok, setOk] = useState(false);
  return (
    <button
      onClick={() => { navigator.clipboard.writeText(text).catch(() => {}); setOk(true); setTimeout(() => setOk(false), 1200); }}
      className="p-0.5 rounded cursor-pointer hover:bg-black/5 transition-colors inline-flex"
      title="Copy"
    >
      {ok ? <Check size={11} className="text-green-600" /> : <Copy size={11} className="text-gray-400" />}
    </button>
  );
}

function Swatch({ color, label, sub }: { color: string; label: string; sub?: string }) {
  return (
    <div className="flex items-center gap-2 min-w-0">
      <div className="w-8 h-8 rounded-lg flex-shrink-0 border border-black/10" style={{ backgroundColor: color }} />
      <div className="min-w-0">
        <div className="text-[11px] font-medium text-gray-800 truncate">{label}</div>
        <div className="flex items-center gap-1">
          <code className="text-[10px] text-gray-500 font-mono truncate">{color}</code>
          <Cp text={color} />
        </div>
        {sub && <div className="text-[9px] text-gray-400">{sub}</div>}
      </div>
    </div>
  );
}

function Sec({ icon: Icon, title, sub }: { icon: any; title: string; sub: string }) {
  return (
    <div className="flex items-start gap-3 mb-6">
      <div className="w-9 h-9 rounded-xl bg-gray-100 flex items-center justify-center flex-shrink-0 mt-0.5">
        <Icon size={16} className="text-gray-500" />
      </div>
      <div>
        <h2 className="text-lg font-bold text-gray-900">{title}</h2>
        <p className="text-xs text-gray-500 mt-0.5">{sub}</p>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════
// MODE CARD
// ═══════════════════════════════════════════════════════════════════

function ModeCard({ m, open, toggle }: { m: ModeSpec; open: boolean; toggle: () => void }) {
  return (
    <div className="rounded-xl overflow-hidden border border-gray-200 bg-white">
      <button onClick={toggle} className="w-full flex items-center gap-3 px-4 py-3 cursor-pointer hover:bg-gray-50/50 transition-colors">
        <div className="flex items-center gap-1.5 flex-shrink-0">
          <div className="w-4 h-4 rounded-full" style={{ backgroundColor: m.accentColor }} />
          <div className="w-4 h-4 rounded" style={{ backgroundColor: m.pageBg, border: '1px solid rgba(0,0,0,0.1)' }} />
        </div>
        <div className="flex-1 text-left min-w-0">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-[13px] text-gray-900">{m.name}</span>
            <span className="text-[11px] text-gray-400">{m.nameZh}</span>
          </div>
          <span className="text-[11px] text-gray-500">{m.tagline}</span>
        </div>
        <motion.div animate={{ rotate: open ? 180 : 0 }} transition={{ duration: 0.2 }}>
          <ChevronDown size={14} className="text-gray-400" />
        </motion.div>
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25, ease: [0.4,0,0.2,1] }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-5" style={{ borderTop: '1px solid rgba(0,0,0,0.06)' }}>
              {/* Live preview */}
              <div className="mt-4 mb-5">
                <div className="rounded-xl overflow-hidden p-4" style={{
                  backgroundColor: m.pageBg,
                  border: `1px solid ${m.isDark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.06)'}`,
                }}>
                  <div className="flex items-start gap-3">
                    <div className="flex-1" style={{
                      backgroundColor: m.key === 'degen' ? m.cardBg : m.surfaceBg,
                      borderRadius: m.cardRadius,
                      padding: '14px',
                      border: `1px solid ${m.cardBorder}`,
                    }}>
                      <div style={{
                        fontSize: '0.55rem', fontWeight: 600, letterSpacing: '0.18em',
                        textTransform: 'uppercase' as const,
                        color: m.key === 'degen' ? '#fff' : m.textMuted, marginBottom: 6,
                      }}>MICRO LABEL</div>
                      <div style={{
                        fontFamily: m.headingFont, fontSize: '1rem', fontWeight: 700,
                        color: m.key === 'degen' ? '#fff' : m.textPrimary, marginBottom: 4, lineHeight: 1.2,
                      }}>Sample Heading</div>
                      <div style={{
                        fontFamily: m.bodyFont, fontSize: '0.75rem',
                        color: m.key === 'degen' ? 'rgba(255,255,255,0.7)' : m.textSecondary, lineHeight: 1.5,
                      }}>Body text shows the reading experience in this mode.</div>
                      <div className="mt-2.5 flex gap-2">
                        <span style={{
                          backgroundColor: m.accentColor, color: '#fff', fontSize: '0.65rem',
                          fontWeight: 600, padding: '5px 12px', borderRadius: m.borderRadius, fontFamily: m.bodyFont,
                        }}>Primary CTA</span>
                        <span style={{
                          backgroundColor: 'transparent',
                          color: m.key === 'degen' ? '#fff' : m.textPrimary,
                          fontSize: '0.65rem', fontWeight: 500, padding: '5px 12px',
                          borderRadius: m.borderRadius, border: `1px solid ${m.cardBorder}`, fontFamily: m.bodyFont,
                        }}>Secondary</span>
                      </div>
                    </div>
                    <div className="w-32 flex-shrink-0 space-y-1">
                      <div className="text-[9px] font-semibold text-gray-400 uppercase tracking-widest">Radii</div>
                      <div className="flex items-center gap-1.5">
                        <div style={{ width: 20, height: 20, borderRadius: m.cardRadius, border: `2px solid ${m.accentColor}` }} />
                        <code className="text-[10px] text-gray-500 font-mono">{m.cardRadius}</code>
                      </div>
                      <div className="text-[9px] font-semibold text-gray-400 uppercase tracking-widest mt-2">Spacing</div>
                      <div className="text-[11px] text-gray-600">{m.spacingScale}× scale</div>
                    </div>
                  </div>
                </div>
              </div>
              {/* Palette */}
              <h4 className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-2">Color Palette</h4>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-4">
                <Swatch color={m.accentColor} label="Accent" sub="CTAs, links" />
                <Swatch color={m.pageBg} label="Page BG" />
                <Swatch color={m.surfaceBg} label="Surface" />
                <Swatch color={m.cardBg} label="Card BG" />
                <Swatch color={m.textPrimary} label="Text Primary" />
                <Swatch color={m.textSecondary} label="Text Secondary" />
                <Swatch color={m.textMuted} label="Text Muted" />
                <Swatch color={m.navBg} label="Nav BG" />
              </div>
              {/* Typography */}
              <h4 className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-2">Typography</h4>
              <div className="grid grid-cols-2 gap-2 mb-4">
                <div className="bg-gray-50 rounded-lg p-2.5">
                  <div className="text-[9px] font-semibold text-gray-400 uppercase tracking-wider mb-0.5">Heading</div>
                  <div style={{ fontFamily: m.headingFont, fontSize: '1.1rem', fontWeight: 700, color: '#1a1a1a', lineHeight: 1.2 }}>{m.headingFontName}</div>
                  <code className="text-[9px] text-gray-400 font-mono">{m.headingFont}</code>
                </div>
                <div className="bg-gray-50 rounded-lg p-2.5">
                  <div className="text-[9px] font-semibold text-gray-400 uppercase tracking-wider mb-0.5">Body</div>
                  <div style={{ fontFamily: m.bodyFont, fontSize: '0.95rem', fontWeight: 400, color: '#1a1a1a', lineHeight: 1.3 }}>{m.bodyFontName}</div>
                  <code className="text-[9px] text-gray-400 font-mono">{m.bodyFont}</code>
                </div>
              </div>
              {/* Design language */}
              <h4 className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-2">Design Language</h4>
              <div className="space-y-1 mb-4">
                {m.designLanguage.map((r, i) => (
                  <div key={i} className="flex items-start gap-1.5 text-[11px] text-gray-700">
                    <div className="w-1 h-1 rounded-full bg-gray-400 mt-1.5 flex-shrink-0" />{r}
                  </div>
                ))}
              </div>
              {/* Do / Don't */}
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-green-50 rounded-lg p-3">
                  <div className="text-[10px] font-bold text-green-700 uppercase tracking-wider mb-1.5 flex items-center gap-1"><Check size={10} /> Do</div>
                  {m.doList.map((d, i) => (
                    <div key={i} className="text-[11px] text-green-800 flex items-start gap-1 mb-0.5"><span className="text-green-500 mt-0.5">✓</span>{d}</div>
                  ))}
                </div>
                <div className="bg-red-50 rounded-lg p-3">
                  <div className="text-[10px] font-bold text-red-700 uppercase tracking-wider mb-1.5 flex items-center gap-1"><Minus size={10} /> Don't</div>
                  {m.dontList.map((d, i) => (
                    <div key={i} className="text-[11px] text-red-800 flex items-start gap-1 mb-0.5"><span className="text-red-400 mt-0.5">✕</span>{d}</div>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════
// MAIN PAGE
// ═══════════════════════════════════════════════════════════════════

export function BrandGuide() {
  const [expanded, setExpanded] = useState<Set<ModeKey>>(new Set(['default']));
  const [activeTab, setActiveTab] = useState('identity');

  const toggle = (k: ModeKey) => setExpanded(p => { const n = new Set(p); n.has(k) ? n.delete(k) : n.add(k); return n; });
  const expandAll = () => setExpanded(new Set(modes.map(m => m.key)));
  const collapseAll = () => setExpanded(new Set());

  const exportJson = () => {
    const payload = {
      name: 'CULTIVE 文化活 — Brand Guidelines',
      version: '2.0',
      exportedAt: new Date().toISOString(),
      modes: modes.map(m => ({ ...m })),
      typography: FONT_STACK,
      spacing: SPACING,
      semanticColors: {
        success: '#2D6A4F',
        warning: '#FF8C42',
        error: '#EF4444',
        info: '#2563EB',
      },
      opacityConventions: {
        borders: 'rgba(0,0,0,0.06)',
        cardBorders: 'rgba(0,0,0,0.08)',
        tintedBg: '{accent}10',
        activeState: '{accent}40',
        badgeOverlay: '{accent}cc',
      },
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'cultive-brand-guidelines.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  const tabs = [
    { id: 'identity', label: 'Identity', icon: Sparkles },
    { id: 'modes', label: 'Modes', icon: Layers },
    { id: 'typography', label: 'Type', icon: Type },
    { id: 'colors', label: 'Colors', icon: Palette },
    { id: 'spacing', label: 'Layout', icon: Ruler },
    { id: 'components', label: 'Components', icon: Frame },
    { id: 'editorial', label: 'Editorial', icon: BookOpen },
    { id: 'bilingual', label: 'i18n', icon: Globe2 },
  ];

  const scrollTo = (id: string) => {
    setActiveTab(id);
    document.getElementById(`bg-${id}`)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  return (
    <div className="p-6 md:p-8 max-w-5xl mx-auto" style={{ fontFamily: N.font }}>
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-2 mb-3">
          <div className="text-[0.55rem] font-semibold uppercase tracking-[0.18em] text-gray-400">INTERNAL REFERENCE</div>
          <div className="h-px flex-1 bg-gray-200" />
          <div className="text-[11px] text-gray-400">v2.0 · March 2026</div>
        </div>
        <h1 className="text-2xl md:text-3xl font-black text-gray-900 mb-2" style={{ fontFamily: "'Archivo Black', sans-serif", lineHeight: 1.1 }}>
          Brand Guidelines
        </h1>
        <p className="text-sm text-gray-500 max-w-2xl leading-relaxed">
          The complete design system for CULTIVE 文化活 — covering identity, the 5-mode visual system,
          typography, color palettes, spacing rules, component patterns, and bilingual standards.
        </p>
        <div className="flex items-center gap-3 mt-3 text-[11px] text-gray-400">
          <span>6 visual modes</span><span className="text-gray-300">&middot;</span>
          <span>11 typefaces</span><span className="text-gray-300">&middot;</span>
          <span>Full bilingual</span><span className="text-gray-300">&middot;</span>
          <span>Light / Dark variants</span>
          <span className="text-gray-300">&middot;</span>
          <button onClick={exportJson} className="inline-flex items-center gap-1 text-blue-600 hover:text-blue-700 font-medium cursor-pointer">
            <Download size={11} /> Export JSON
          </button>
        </div>
      </div>

      {/* Tab nav */}
      <div className="sticky top-0 z-10 bg-[#FAFAF8]/95 backdrop-blur-sm -mx-6 md:-mx-8 px-6 md:px-8 border-b border-gray-100 mb-8">
        <div className="flex gap-0.5 overflow-x-auto scrollbar-hide py-2">
          {tabs.map(t => (
            <button key={t.id} onClick={() => scrollTo(t.id)}
              className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-[11px] font-medium whitespace-nowrap transition-all cursor-pointer ${
                activeTab === t.id ? 'bg-gray-900 text-white' : 'text-gray-500 hover:bg-gray-100'
              }`}>
              <t.icon size={12} />{t.label}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-16">

        {/* ─── Identity ─── */}
        <section id="bg-identity">
          <Sec icon={Sparkles} title="Brand Identity" sub="The foundation of CULTIVE's visual language" />
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
            <div className="bg-[#FAFAF8] rounded-xl p-6 border border-gray-100 flex flex-col items-center justify-center min-h-[160px]">
              <div className="text-2xl font-black tracking-tight text-gray-900" style={{ fontFamily: "'Archivo Black', sans-serif" }}>CULTIVE</div>
              <div className="text-base text-gray-400 mt-0.5" style={{ fontFamily: "'Noto Sans HK', sans-serif", fontWeight: 500 }}>文化活</div>
              <div className="text-[9px] text-gray-400 mt-2 uppercase tracking-[0.15em]">Primary lockup — Light</div>
            </div>
            <div className="bg-[#0A0A0A] rounded-xl p-6 border border-gray-800 flex flex-col items-center justify-center min-h-[160px]">
              <div className="text-2xl font-black tracking-tight text-white" style={{ fontFamily: "'Archivo Black', sans-serif" }}>CULTIVE</div>
              <div className="text-base text-gray-500 mt-0.5" style={{ fontFamily: "'Noto Sans HK', sans-serif", fontWeight: 500 }}>文化活</div>
              <div className="text-[9px] text-gray-600 mt-2 uppercase tracking-[0.15em]">Primary lockup — Dark</div>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-6">
            {[
              { l: 'Brand Name', v: 'CULT(ure) + (act)IVE = 文化 + 活' },
              { l: 'Tagline EN', v: "Hong Kong's Cultural Discovery Platform" },
              { l: 'Tagline ZH', v: '香港文化探索平台' },
            ].map((x, i) => (
              <div key={i} className="bg-gray-50 rounded-lg p-3">
                <div className="text-[9px] font-semibold text-gray-400 uppercase tracking-wider mb-0.5">{x.l}</div>
                <div className="text-[13px] font-medium text-gray-800">{x.v}</div>
              </div>
            ))}
          </div>
          <div className="bg-gray-50 rounded-xl p-5 border border-gray-100">
            <h3 className="text-xs font-bold text-gray-600 uppercase tracking-wider mb-2">The 5-Mode System</h3>
            <p className="text-[13px] text-gray-600 leading-relaxed mb-3">
              CULTIVE's defining feature is its adaptive visual identity. The entire platform — typography,
              palette, layout, radii, spacing, content curation — transforms based on the active mode.
              Each mode represents a cultural lens through which to experience Hong Kong. A 6th "default" mode
              provides the neutral editorial baseline.
            </p>
            <div className="flex flex-wrap gap-1.5">
              {modes.filter(m => m.key !== 'default').map(m => (
                <div key={m.key} className="flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-medium bg-white border border-gray-200">
                  <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: m.accentColor }} />
                  {m.name}
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ─── Modes ─── */}
        <section id="bg-modes">
          <Sec icon={Layers} title="Mode Design Systems" sub="Complete token reference for each of the 6 visual modes" />
          <div className="flex items-center gap-2 mb-4">
            <button onClick={expandAll} className="text-[11px] font-medium text-blue-600 hover:text-blue-700 cursor-pointer">Expand all</button>
            <span className="text-gray-300">·</span>
            <button onClick={collapseAll} className="text-[11px] font-medium text-blue-600 hover:text-blue-700 cursor-pointer">Collapse all</button>
          </div>
          <div className="space-y-2">
            {modes.map(m => <ModeCard key={m.key} m={m} open={expanded.has(m.key)} toggle={() => toggle(m.key)} />)}
          </div>
        </section>

        {/* ─── Typography ─── */}
        <section id="bg-typography">
          <Sec icon={Type} title="Typography System" sub="11 typefaces — each serving a specific mode and purpose" />
          <div className="space-y-2 mb-6">
            {FONT_STACK.map((f, i) => (
              <div key={i} className="bg-white rounded-lg border border-gray-200 p-3 hover:border-gray-300 transition-colors">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5 mb-0.5">
                      <span className="text-[13px] font-bold text-gray-900">{f.name}</span>
                      <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-gray-100 text-gray-500 font-medium">{f.style}</span>
                    </div>
                    <div className="text-[11px] text-gray-500 mb-1.5">{f.usage}</div>
                    <div className="text-base text-gray-800" style={{ fontFamily: `'${f.name}', serif`, lineHeight: 1.2 }}>
                      CULTIVE 文化活 — Discover Hong Kong
                    </div>
                  </div>
                  <div className="flex-shrink-0 text-right">
                    <div className="text-[9px] text-gray-400 uppercase tracking-wider mb-0.5">Weights</div>
                    <div className="flex gap-0.5 justify-end flex-wrap">
                      {f.weights.map(w => (
                        <span key={w} className="text-[9px] px-1 py-0.5 rounded bg-gray-100 text-gray-500 font-mono">{w}</span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          {/* Micro-label spec */}
          <div className="bg-gray-50 rounded-xl p-4 border border-gray-100">
            <h3 className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-3">Micro-Label Specification</h3>
            <div className="bg-white rounded-lg p-3 border border-gray-200">
              <div style={{ fontSize: '0.55rem', fontWeight: 600, letterSpacing: '0.18em', textTransform: 'uppercase' as const, color: '#9A9A9A' }} className="mb-2">
                THIS IS A MICRO LABEL
              </div>
              <div className="flex flex-wrap gap-x-4 gap-y-1">
                {[
                  { p: 'font-size', v: '0.55rem' },
                  { p: 'font-weight', v: '600' },
                  { p: 'letter-spacing', v: '0.18em' },
                  { p: 'text-transform', v: 'uppercase' },
                ].map((s, i) => (
                  <div key={i} className="flex items-center gap-1">
                    <code className="text-[9px] font-mono text-gray-400">{s.p}:</code>
                    <code className="text-[9px] font-mono text-gray-700 font-medium">{s.v}</code>
                    <Cp text={`${s.p}: ${s.v}`} />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* ─── Colors ─── */}
        <section id="bg-colors">
          <Sec icon={Palette} title="Color System" sub="Every mode owns its complete palette — here's the accent matrix" />
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 mb-6">
            {modes.map(m => (
              <div key={m.key} className="text-center">
                <div className="w-full aspect-square rounded-xl mb-1.5 border border-black/5" style={{ backgroundColor: m.accentColor }} />
                <div className="text-[11px] font-medium text-gray-700">{m.key}</div>
                <code className="text-[9px] text-gray-400 font-mono">{m.accentColor}</code>
              </div>
            ))}
          </div>
          {/* BG strip */}
          <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-2">Background Comparison</h4>
          <div className="flex gap-0.5 rounded-xl overflow-hidden border border-gray-200 mb-6">
            {modes.map(m => (
              <div key={m.key} className="flex-1 h-16 flex items-end justify-center pb-1.5" style={{ backgroundColor: m.pageBg }}>
                <span className="text-[8px] font-medium" style={{ color: m.textMuted }}>{m.key}</span>
              </div>
            ))}
          </div>
          {/* Semantic & opacity */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="bg-gray-50 rounded-lg p-3 border border-gray-100">
              <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-2">Semantic Colors</h4>
              {[
                { role: 'Success', color: '#2D6A4F', ex: 'Published, saved' },
                { role: 'Warning', color: '#FF8C42', ex: 'Pending, almost full' },
                { role: 'Error', color: '#EF4444', ex: 'Delete, failed' },
                { role: 'Info', color: '#2563EB', ex: 'Links, badges' },
              ].map((s, i) => (
                <div key={i} className="flex items-center gap-2 mb-1.5">
                  <div className="w-3.5 h-3.5 rounded" style={{ backgroundColor: s.color }} />
                  <div className="text-[11px] text-gray-600"><strong className="text-gray-800">{s.role}</strong> — {s.ex}</div>
                </div>
              ))}
            </div>
            <div className="bg-gray-50 rounded-lg p-3 border border-gray-100">
              <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-2">Opacity Conventions</h4>
              <div className="space-y-1 text-[11px] text-gray-600">
                <div><code className="font-mono text-[9px] bg-white px-1 rounded border border-gray-200">rgba(0,0,0,0.06)</code> — Borders, dividers</div>
                <div><code className="font-mono text-[9px] bg-white px-1 rounded border border-gray-200">rgba(0,0,0,0.08)</code> — Card borders</div>
                <div><code className="font-mono text-[9px] bg-white px-1 rounded border border-gray-200">{'{accent}'}10</code> — Tinted backgrounds</div>
                <div><code className="font-mono text-[9px] bg-white px-1 rounded border border-gray-200">{'{accent}'}40</code> — Active state borders</div>
                <div><code className="font-mono text-[9px] bg-white px-1 rounded border border-gray-200">{'{accent}'}cc</code> — Badge overlays</div>
              </div>
            </div>
          </div>
        </section>

        {/* ─── Layout ─── */}
        <section id="bg-spacing">
          <Sec icon={Ruler} title="Spacing & Layout" sub="Consistent rhythm across all modes" />
          <div className="space-y-2 mb-6">
            {SPACING.map((r, i) => (
              <div key={i} className="bg-white rounded-lg border border-gray-200 p-3">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="text-[13px] font-semibold text-gray-800">{r.token}</div>
                    <div className="text-[11px] text-gray-500">{r.usage}</div>
                  </div>
                  <div className="flex items-center gap-1 flex-shrink-0">
                    <code className="text-[10px] font-mono text-gray-600 bg-gray-50 px-1.5 py-0.5 rounded border border-gray-200">{r.value}</code>
                    <Cp text={r.value} />
                  </div>
                </div>
              </div>
            ))}
          </div>
          <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-3">Border Radius Comparison</h4>
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-3">
            {modes.map(m => (
              <div key={m.key} className="text-center">
                <div className="w-14 h-14 bg-gray-100 border-2 mx-auto mb-1.5" style={{ borderRadius: m.cardRadius, borderColor: m.accentColor }} />
                <div className="text-[10px] font-medium text-gray-600">{m.key}</div>
                <code className="text-[9px] text-gray-400 font-mono">{m.cardRadius}</code>
              </div>
            ))}
          </div>
        </section>

        {/* ─── Components ─── */}
        <section id="bg-components">
          <Sec icon={Frame} title="Component Patterns" sub="Recurring UI patterns that adapt across modes" />
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
            {[
              { n: 'Venue Card', d: 'Adapts radius, font, color per mode. Image + name + district + mode score badge.', t: 'cardRadius, headingFont, accentColor' },
              { n: 'Event Grid Card', d: 'Date badge, category pill, save heart. Links to /event/:id.', t: 'imageRadius, bodyFont, textMuted' },
              { n: 'Mode Selector', d: '5-mode picker with color chip + label + emoji. Triggers full transform.', t: 'modeConfig.color, label, labelZh' },
              { n: 'Map Markers', d: 'Custom SVG markers per mode. Heart badge for saved. Cluster at zoom.', t: 'modeConfig.markerColor' },
              { n: 'Quick Save Heart', d: 'Venue cards, map markers, detail pages. Animated fill. Syncs across systems.', t: 'accentColor (filled), textMuted (outline)' },
              { n: 'Navigation Bar', d: '64px fixed. Glassmorphic backdrop-blur. Mode-aware colors.', t: 'navBg, navBorder, navText, navTextActive' },
              { n: 'Collection Modal', d: 'Slide-up for adding items to collections. Create new option.', t: 'cardRadius, surfaceBg, accentColor' },
              { n: 'Micro-label Badge', d: 'Uppercase 0.55rem for section headers, category tags, status indicators.', t: '0.55rem / 600 / 0.18em / uppercase' },
            ].map((c, i) => (
              <div key={i} className="bg-white rounded-lg border border-gray-200 p-3 hover:border-gray-300 transition-colors">
                <div className="text-[13px] font-semibold text-gray-800 mb-0.5">{c.n}</div>
                <div className="text-[11px] text-gray-500 mb-2 leading-relaxed">{c.d}</div>
                <div className="flex items-center gap-1">
                  <PaintBucket size={9} className="text-gray-400" />
                  <code className="text-[9px] font-mono text-gray-400">{c.t}</code>
                </div>
              </div>
            ))}
          </div>
          {/* Button showcase */}
          <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-3">Button Variants</h4>
          <div className="bg-gray-50 rounded-xl p-4 border border-gray-100">
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-3">
              {modes.map(m => (
                <div key={m.key} className="space-y-1.5">
                  <div className="text-[9px] font-semibold text-gray-400 uppercase tracking-wider text-center">{m.key}</div>
                  <div className="w-full py-1.5 text-[10px] font-semibold text-white text-center" style={{ backgroundColor: m.accentColor, borderRadius: m.borderRadius }}>Primary</div>
                  <div className="w-full py-1.5 text-[10px] font-medium text-center border" style={{ color: m.accentColor, borderColor: m.accentColor + '40', borderRadius: m.borderRadius }}>Secondary</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ─── Editorial ─── */}
        <section id="bg-editorial">
          <Sec icon={BookOpen} title="Editorial Rules" sub="Voice, tone, content guidelines" />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <div className="bg-white rounded-lg border border-gray-200 p-4">
                <h4 className="text-[13px] font-bold text-gray-800 mb-2">Brand Voice</h4>
                <div className="space-y-1.5 text-[11px] text-gray-600 leading-relaxed">
                  <p><strong className="text-gray-800">Tone:</strong> Confident but approachable. We know our city, not gatekeepers.</p>
                  <p><strong className="text-gray-800">Perspective:</strong> First-person plural ("we discover", "our city").</p>
                  <p><strong className="text-gray-800">Energy:</strong> Adapts per mode — irreverent for Night, warm for Family, refined for Art.</p>
                </div>
              </div>
              <div className="bg-white rounded-lg border border-gray-200 p-4">
                <h4 className="text-[13px] font-bold text-gray-800 mb-2">Content Hierarchy</h4>
                <div className="space-y-1.5 text-[11px] text-gray-600">
                  {[
                    ['01', 'Headline', 'Mode-specific font. Short, punchy. Max 6-8 words.'],
                    ['02', 'Subhead', 'Context or qualifier. One line.'],
                    ['03', 'Body', 'Mode body font. 14-16px. 1.5-1.7 line height.'],
                    ['04', 'Micro-label', '0.55rem uppercase. Section markers only.'],
                  ].map(([n, l, d]) => (
                    <div key={n} className="flex items-start gap-2">
                      <span className="font-bold text-gray-300 text-sm leading-none">{n}</span>
                      <div><strong className="text-gray-800">{l}:</strong> {d}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <div className="space-y-3">
              <div className="bg-white rounded-lg border border-gray-200 p-4">
                <h4 className="text-[13px] font-bold text-gray-800 mb-2">Mode-Specific Voice</h4>
                {[
                  { m: 'Night', v: '"WHERE CULTURE COMES ALIVE AFTER MIDNIGHT" — All-caps, urgent, underground.', c: '#D600FF' },
                  { m: 'Art', v: '"Where Art Lives" — Quiet confidence. Gallery restraint.', c: '#8338EC' },
                  { m: 'Food', v: '"Taste the Culture" — Evocative, sensory. Magazine editorial.', c: '#2563EB' },
                  { m: 'Family', v: '"Weekend Fun for Little Explorers" — Warm, encouraging.', c: '#FF8C42' },
                  { m: 'Lifestyle', v: '"What\'s Happening" — Community-first. "Join" over "attend".', c: '#2D6A4F' },
                ].map((x, i) => (
                  <div key={i} className="flex items-start gap-1.5 mb-1.5">
                    <div className="w-2 h-2 rounded-full mt-1 flex-shrink-0" style={{ backgroundColor: x.c }} />
                    <div className="text-[11px] text-gray-600"><strong className="text-gray-800">{x.m}:</strong> {x.v}</div>
                  </div>
                ))}
              </div>
              <div className="bg-white rounded-lg border border-gray-200 p-4">
                <h4 className="text-[13px] font-bold text-gray-800 mb-2">Photography Guidelines</h4>
                <div className="space-y-1 text-[11px] text-gray-600">
                  <p>• <strong>Night:</strong> Low light, neon, DJ booths, candid moments</p>
                  <p>• <strong>Art:</strong> Gallery installations, white walls, artwork close-ups</p>
                  <p>• <strong>Food:</strong> Overhead plating, ambient lighting, market stalls</p>
                  <p>• <strong>Family:</strong> Natural light, children exploring, outdoor workshops</p>
                  <p>• <strong>Lifestyle:</strong> Morning runs, yoga, workshop hands, circles</p>
                  <p className="text-gray-400 italic mt-1.5">Always source via platform Unsplash tool. No stock clichés.</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ─── Bilingual ─── */}
        <section id="bg-bilingual">
          <Sec icon={Globe2} title="Bilingual Standards" sub="English / Traditional Chinese (繁體中文) implementation" />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-white rounded-lg border border-gray-200 p-4">
              <h4 className="text-[13px] font-bold text-gray-800 mb-2">Implementation</h4>
              <div className="space-y-2 text-[11px] text-gray-600">
                <div className="bg-gray-50 rounded p-2.5">
                  <div className="text-[9px] font-bold text-gray-400 uppercase tracking-wider mb-0.5">Static UI Strings</div>
                  <p><code className="font-mono bg-white px-1 rounded border border-gray-200 text-[10px]">react-i18next</code> with <code className="font-mono bg-white px-1 rounded border border-gray-200 text-[10px]">t('ns.key')</code></p>
                  <p className="text-gray-400 mt-0.5">Files: <code className="font-mono text-[10px]">/locales/en.json</code> + <code className="font-mono text-[10px]">/locales/zh-Hant.json</code></p>
                </div>
                <div className="bg-gray-50 rounded p-2.5">
                  <div className="text-[9px] font-bold text-gray-400 uppercase tracking-wider mb-0.5">Dynamic Content</div>
                  <p>Bilingual fields: <code className="font-mono bg-white px-1 rounded border border-gray-200 text-[10px]">title</code> + <code className="font-mono bg-white px-1 rounded border border-gray-200 text-[10px]">title_zh</code></p>
                </div>
                <div className="bg-gray-50 rounded p-2.5">
                  <div className="text-[9px] font-bold text-gray-400 uppercase tracking-wider mb-0.5">Toggle</div>
                  <p>Top nav EN / 繁 toggle → <code className="font-mono bg-white px-1 rounded border border-gray-200 text-[10px]">localStorage('cultive:lang')</code></p>
                </div>
              </div>
            </div>
            <div className="bg-white rounded-lg border border-gray-200 p-4">
              <h4 className="text-[13px] font-bold text-gray-800 mb-2">Chinese Typography</h4>
              <div className="space-y-1 text-[11px] text-gray-600">
                <p>• <strong>Font:</strong> Noto Sans HK (300, 400, 500, 700)</p>
                <p>• <strong>Fallback:</strong> 'Noto Sans HK', system-ui, sans-serif</p>
                <p>• <strong>Punctuation:</strong> CJK (，。「」⋯) not Western (,..."")</p>
                <p>• <strong>Line height:</strong> +10% for CJK blocks (1.7 vs 1.5)</p>
                <p>• <strong>Date locale:</strong> <code className="font-mono bg-gray-50 px-1 rounded text-[10px]">zh-HK</code> when <code className="font-mono bg-gray-50 px-1 rounded text-[10px]">isZh</code></p>
                <p>• <strong>Admin CMS:</strong> English-only (internal tool)</p>
              </div>
              <div className="mt-3 bg-gray-50 rounded p-2.5">
                <div className="text-[9px] font-bold text-gray-400 uppercase tracking-wider mb-1">Example — Event Card</div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <div className="text-[8px] text-gray-400">EN</div>
                    <div className="text-[13px] font-semibold text-gray-800">Weekend Workshop</div>
                    <div className="text-[11px] text-gray-500">Central, Hong Kong</div>
                  </div>
                  <div>
                    <div className="text-[8px] text-gray-400">ZH</div>
                    <div className="text-[13px] font-semibold text-gray-800" style={{ fontFamily: "'Noto Sans HK', sans-serif" }}>週末工作坊</div>
                    <div className="text-[11px] text-gray-500" style={{ fontFamily: "'Noto Sans HK', sans-serif" }}>中環，香港</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Key Files Reference */}
        <section>
          <Sec icon={MousePointerClick} title="Key Source Files" sub="Where design tokens and mode logic live in the codebase" />
          <div className="bg-gray-50 rounded-xl p-4 border border-gray-100">
            <div className="space-y-1.5 text-[11px] text-gray-600 font-mono">
              {[
                ['/src/app/data/mode-styles.ts', 'ModeDesignTokens interface + all mode token objects'],
                ['/src/app/data/mock-data.ts', 'modeConfig — labels, colors, gradients, markerColors'],
                ['/src/app/data/lifestyle-data.ts', 'LC/LF extended tokens for Lifestyle mode'],
                ['/src/app/context/ModeContext.tsx', 'Global mode state + getDesignTokens()'],
                ['/src/app/context/NeutralThemeContext.tsx', 'Light/dark palette for default editorial mode'],
                ['/src/styles/fonts.css', 'Google Fonts import for all 11 typefaces'],
                ['/src/styles/theme.css', 'CSS custom properties, Tailwind theme, base typography'],
                ['/locales/en.json + zh-Hant.json', 'Full bilingual translation strings'],
              ].map(([f, d], i) => (
                <div key={i} className="flex items-start gap-3">
                  <code className="text-[10px] text-blue-600 flex-shrink-0 whitespace-nowrap">{f}</code>
                  <span className="text-gray-500 font-sans text-[11px]">{d}</span>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Footer */}
        <div className="pt-8 border-t border-gray-200 text-center">
          <div className="text-[0.55rem] font-semibold uppercase tracking-[0.18em] text-gray-400 mb-1">
            CULTIVE 文化活 · BRAND GUIDELINES v2.0
          </div>
          <div className="text-[11px] text-gray-400">
            Last updated March 2026 · Internal reference
          </div>
        </div>
      </div>
    </div>
  );
}