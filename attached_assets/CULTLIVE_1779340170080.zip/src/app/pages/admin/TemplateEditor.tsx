import { useState, useEffect, useCallback, useRef } from 'react';
import { useOutletContext } from 'react-router';
import { motion, AnimatePresence } from 'motion/react';
import {
  ChevronDown, ChevronRight, GripVertical, Save,
  Loader2, Check, Image as ImageIcon, Upload, Film, Type,
  Palette, Link2, ToggleLeft, ToggleRight,
  RotateCcw, AlertCircle, X, Layers,
  Globe, PanelLeft, ExternalLink, Crosshair,
} from 'lucide-react';
import { projectId, publicAnonKey } from '../../config/supabase';
import { ImageWithFallback } from '../../components/figma/ImageWithFallback';
import { compressVideo, shouldCompress } from '../../utils/compressVideo';
import { staticSiteImages, PAGE_LABELS } from '../../data/site-images';
import { invalidateSiteImageCache } from '../../hooks/useSiteImages';
import { invalidateTemplateCache } from '../../hooks/useTemplateData';

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-d507b98c/cms`;

// ═══════════════════════════════════════════════════
// DESIGN TOKENS
// ═══════════════════════════════════════════════════

const N = {
  pageBg: '#FAFAF8',
  surface: '#FFFFFF',
  surfaceMuted: '#F5F5F3',
  surfaceHover: '#F0F0ED',
  border: 'rgba(0,0,0,0.06)',
  borderFocus: 'rgba(0,0,0,0.12)',
  text: '#1A1A1A',
  textSecondary: '#5A5A5A',
  textMuted: '#9A9A9A',
  dark: '#1A1A1A',
  blue: '#2563EB',
  blueBg: 'rgba(37,99,235,0.06)',
  blueLight: 'rgba(37,99,235,0.1)',
  green: '#16A34A',
  greenBg: 'rgba(22,163,74,0.06)',
  amber: '#D97706',
  amberBg: 'rgba(217,119,6,0.06)',
  red: '#DC2626',
  redBg: 'rgba(220,38,38,0.05)',
  font: "'Inter', 'Noto Sans HK', system-ui, sans-serif",
};

// ═══════════════════════════════════════════════════
// SECTION DEFINITIONS — the "template schema"
// ═══════════════════════════════════════════════════

interface SectionField {
  key: string;
  label: string;
  type: 'text' | 'textarea' | 'image' | 'video' | 'url' | 'color' | 'select' | 'toggle' | 'number';
  placeholder?: string;
  hint?: string;
  options?: { label: string; value: string }[];
}

interface SectionDef {
  id: string;
  label: string;
  icon: string;
  description: string;
  fields: SectionField[];
  defaultValues: Record<string, any>;
}

interface PageDef {
  id: string;
  label: string;
  description: string;
  sections: SectionDef[];
  previewPath: string;
}

const PAGES: PageDef[] = [
  {
    id: 'home',
    label: 'Homepage',
    description: 'Main landing page with hero, mode cards, and discovery sections',
    previewPath: '/',
    sections: [
      {
        id: 'hero',
        label: 'Hero Section',
        icon: 'film',
        description: 'Full-screen video/image hero at the top of the page',
        fields: [
          { key: 'heroType', label: 'Hero Type', type: 'select', options: [
            { label: 'Video Background', value: 'video' },
            { label: 'Static Image', value: 'image' },
          ]},
          { key: 'videoUrl', label: 'Video URL', type: 'video', placeholder: 'https://...mp4', hint: 'Videos over 8MB are auto-compressed for faster loading. Upload any MP4/WebM/MOV.' },
          { key: 'posterImage', label: 'Poster / Fallback Image', type: 'image', placeholder: 'https://...', hint: 'Shown while video loads, or as the hero if type is image' },
          { key: 'headline', label: 'Headline', type: 'text', placeholder: "Discover what's happening in HK" },
          { key: 'subheadline', label: 'Subheadline', type: 'text', placeholder: "Hong Kong's Cultural Discovery Platform" },
          { key: 'description', label: 'Description', type: 'textarea', placeholder: 'Explore cultural events, venues, and experiences...' },
          { key: 'ctaPrimary', label: 'Primary CTA Text', type: 'text', placeholder: 'Browse Events' },
          { key: 'ctaSecondary', label: 'Secondary CTA Text', type: 'text', placeholder: 'Explore Map' },
          { key: 'overlayOpacity', label: 'Overlay Darkness', type: 'number', placeholder: '0.35', hint: '0 = no overlay, 1 = fully dark' },
        ],
        defaultValues: {
          heroType: 'video',
          videoUrl: 'https://videos.pexels.com/video-files/3129671/3129671-uhd_2560_1440_30fps.mp4',
          posterImage: '',
          headline: "Discover what's\nhappening in HK",
          subheadline: "Hong Kong's Cultural Discovery Platform",
          description: 'Explore cultural events, venues, and experiences curated for every vibe.',
          ctaPrimary: 'Browse Events',
          ctaSecondary: 'Explore Map',
          overlayOpacity: 0.35,
        },
      },
      {
        id: 'mode-cards',
        label: 'Choose Your Vibe',
        icon: 'palette',
        description: 'The 5-mode selection cards (Night, Art & Design, Food, Family, Lifestyle)',
        fields: [
          { key: 'sectionTitle', label: 'Section Title', type: 'text', placeholder: 'Choose your vibe' },
          { key: 'sectionSubtitle', label: 'Section Subtitle', type: 'text', placeholder: 'Five curated modes...' },
          { key: 'showArrows', label: 'Show Scroll Arrows (Mobile)', type: 'toggle' },
          { key: 'cardHeight', label: 'Card Height', type: 'select', options: [
            { label: 'Short (360px)', value: 'short' },
            { label: 'Medium (420px)', value: 'medium' },
            { label: 'Tall (520px)', value: 'tall' },
          ]},
          // Card images managed in Site Images tab to avoid duplicates
        ],
        defaultValues: {
          sectionTitle: 'Choose your vibe',
          sectionSubtitle: 'Five curated modes transform everything — colours, fonts, map filters and recommendations.',
          showArrows: true,
          cardHeight: 'short',
        },
      },
      {
        id: 'things-to-do',
        label: 'Things To Do',
        icon: 'layers',
        description: 'Featured events and activities carousel',
        fields: [
          { key: 'sectionTitle', label: 'Section Title', type: 'text', placeholder: 'Things to do' },
          { key: 'maxItems', label: 'Max Items Shown', type: 'number', placeholder: '8' },
          { key: 'showFeaturedOnly', label: 'Show Featured Only', type: 'toggle' },
        ],
        defaultValues: { sectionTitle: 'Things to do', maxItems: 8, showFeaturedOnly: false },
      },
      {
        id: 'upcoming-events',
        label: 'Upcoming Events',
        icon: 'calendar',
        description: 'Grid of upcoming events with date and venue info',
        fields: [
          { key: 'sectionTitle', label: 'Section Title', type: 'text', placeholder: 'Upcoming Events' },
          { key: 'maxItems', label: 'Max Items', type: 'number', placeholder: '6' },
          { key: 'layout', label: 'Layout', type: 'select', options: [
            { label: 'Grid (3 columns)', value: 'grid-3' },
            { label: 'Grid (2 columns)', value: 'grid-2' },
            { label: 'List', value: 'list' },
          ]},
        ],
        defaultValues: { sectionTitle: 'Upcoming Events', maxItems: 6, layout: 'grid-3' },
      },
      {
        id: 'popular-venues',
        label: 'Popular Venues',
        icon: 'map-pin',
        description: 'Showcase of popular venues across Hong Kong',
        fields: [
          { key: 'sectionTitle', label: 'Section Title', type: 'text', placeholder: 'Popular Venues' },
          { key: 'maxItems', label: 'Max Items', type: 'number', placeholder: '5' },
        ],
        defaultValues: { sectionTitle: 'Popular Venues', maxItems: 5 },
      },
      {
        id: 'map-cta',
        label: 'Map CTA',
        icon: 'globe',
        description: 'Call-to-action section linking to the interactive map',
        fields: [
          { key: 'headline', label: 'Headline', type: 'text', placeholder: 'Explore the map' },
          { key: 'description', label: 'Description', type: 'textarea' },
          { key: 'backgroundImage', label: 'Background Image', type: 'image' },
        ],
        defaultValues: { headline: 'Explore the map', description: '', backgroundImage: '' },
      },
      {
        id: 'footer',
        label: 'Footer',
        icon: 'type',
        description: 'Site footer with links and branding',
        fields: [
          { key: 'tagline', label: 'Tagline', type: 'text', placeholder: 'Discover. Connect. Experience.' },
          { key: 'copyrightText', label: 'Copyright Text', type: 'text', placeholder: '2026 CULTIVE. All rights reserved.' },
          { key: 'showSocials', label: 'Show Social Links', type: 'toggle' },
        ],
        defaultValues: { tagline: 'Discover. Connect. Experience.', copyrightText: '2026 CULTIVE. All rights reserved.', showSocials: true },
      },
    ],
  },
  {
    id: 'events',
    label: 'Events Page',
    description: 'Event listing and filtering page',
    previewPath: '/events',
    sections: [
      {
        id: 'hero',
        label: 'Page Header',
        icon: 'type',
        description: 'Top section with title and filters',
        fields: [
          { key: 'pageTitle', label: 'Page Title', type: 'text', placeholder: 'Events' },
          { key: 'pageSubtitle', label: 'Page Subtitle', type: 'text', placeholder: 'Discover cultural events...' },
          { key: 'heroImage', label: 'Header Background', type: 'image' },
        ],
        defaultValues: { pageTitle: 'Events', pageSubtitle: '', heroImage: '' },
      },
    ],
  },
  {
    id: 'about',
    label: 'About Page',
    description: 'About CULTIVE, team, and mission',
    previewPath: '/about',
    sections: [
      {
        id: 'hero',
        label: 'Hero Section',
        icon: 'film',
        description: 'Hero banner with title and subtitle',
        fields: [
          { key: 'subtitle', label: 'Subtitle', type: 'text', placeholder: 'About CULTIVE' },
          { key: 'heroTitle', label: 'Hero Title', type: 'text', placeholder: 'Culture is a verb', hint: 'Wrap text in *asterisks* for italic emphasis' },
        ],
        defaultValues: { subtitle: 'About CULTIVE', heroTitle: 'Culture is a *verb*' },
      },
      {
        id: 'manifesto',
        label: 'Manifesto & Stats',
        icon: 'type',
        description: 'Main manifesto text and statistics bar',
        fields: [
          { key: 'manifesto', label: 'Manifesto Headline', type: 'textarea', placeholder: 'A hyper-local cultural events platform...', hint: 'Use *asterisks* for italic emphasis' },
          { key: 'manifestoBody', label: 'Manifesto Body', type: 'textarea', placeholder: 'Hong Kong is one of the most culturally dense cities...' },
          { key: 'showStats', label: 'Show Statistics Bar', type: 'toggle' },
          { key: 'stat1Value', label: 'Stat 1 Value', type: 'text', placeholder: '25+' },
          { key: 'stat1Label', label: 'Stat 1 Label', type: 'text', placeholder: 'Cultural Venues' },
          { key: 'stat2Value', label: 'Stat 2 Value', type: 'text', placeholder: '40+' },
          { key: 'stat2Label', label: 'Stat 2 Label', type: 'text', placeholder: 'Events Monthly' },
          { key: 'stat3Value', label: 'Stat 3 Value', type: 'text', placeholder: '9' },
          { key: 'stat3Label', label: 'Stat 3 Label', type: 'text', placeholder: 'HK Districts' },
          { key: 'stat4Value', label: 'Stat 4 Value', type: 'text', placeholder: '5' },
          { key: 'stat4Label', label: 'Stat 4 Label', type: 'text', placeholder: 'Discovery Modes' },
        ],
        defaultValues: {
          manifesto: 'A hyper-local cultural events platform for Hong Kong — where *how* you discover is as important as *what* you discover.',
          manifestoBody: "Hong Kong is one of the most culturally dense cities on earth. No single platform captured this energy. We believe the way you discover a late-night speakeasy should feel fundamentally different from finding a weekend family workshop — and the platform should reflect that.",
          showStats: true,
          stat1Value: '25+', stat1Label: 'Cultural Venues',
          stat2Value: '40+', stat2Label: 'Events Monthly',
          stat3Value: '9', stat3Label: 'HK Districts',
          stat4Value: '5', stat4Label: 'Discovery Modes',
        },
      },
      {
        id: 'five-lenses',
        label: 'Five Lenses',
        icon: 'type',
        description: 'Mode descriptions accordion section',
        fields: [
          { key: 'sectionLabel', label: 'Section Label', type: 'text', placeholder: 'Five Lenses' },
          { key: 'sectionTitle', label: 'Section Title', type: 'text', placeholder: 'One city, five ways to see it.' },
          { key: 'nightTagline', label: 'Night Mode Tagline', type: 'textarea', placeholder: 'After-dark culture...' },
          { key: 'familyTagline', label: 'Family Mode Tagline', type: 'textarea', placeholder: 'Kid-friendly workshops...' },
          { key: 'artTagline', label: 'Art & Design Tagline', type: 'textarea', placeholder: 'Exhibitions, gallery openings...' },
          { key: 'foodTagline', label: 'Food Mode Tagline', type: 'textarea', placeholder: 'Culinary experiences...' },
          { key: 'lifestyleTagline', label: 'Lifestyle Tagline', type: 'textarea', placeholder: 'Run clubs, wellness...' },
        ],
        defaultValues: {
          sectionLabel: 'Five Lenses',
          sectionTitle: 'One city, five ways to see it.',
          nightTagline: 'After-dark culture, underground scenes, and late-night energy.',
          familyTagline: 'Kid-friendly workshops, outdoor adventures, and weekend fun.',
          artTagline: 'Exhibitions, gallery openings, and the creative pulse of the city.',
          foodTagline: 'Culinary experiences, night markets, and the flavours of Hong Kong.',
          lifestyleTagline: 'Run clubs, wellness, workshops, and community — the living side of culture.',
        },
      },
      {
        id: 'quote',
        label: 'Parallax Quote',
        icon: 'type',
        description: 'Full-width quote banner over background image',
        fields: [
          { key: 'quoteText', label: 'Quote Text', type: 'textarea', placeholder: 'The same city, the same venues...' },
        ],
        defaultValues: {
          quoteText: "The same city, the same venues — experienced through your chosen lens.",
        },
      },
      {
        id: 'how-it-works',
        label: 'How It Works',
        icon: 'type',
        description: 'Step-by-step guide accordion',
        fields: [
          { key: 'sectionLabel', label: 'Section Label', type: 'text', placeholder: 'How It Works' },
          { key: 'step01Title', label: 'Step 1 Title', type: 'text', placeholder: 'Choose Your Lens' },
          { key: 'step01Body', label: 'Step 1 Body', type: 'textarea' },
          { key: 'step02Title', label: 'Step 2 Title', type: 'text', placeholder: 'Explore the Map' },
          { key: 'step02Body', label: 'Step 2 Body', type: 'textarea' },
          { key: 'step03Title', label: 'Step 3 Title', type: 'text', placeholder: 'Discover Events' },
          { key: 'step03Body', label: 'Step 3 Body', type: 'textarea' },
          { key: 'step04Title', label: 'Step 4 Title', type: 'text', placeholder: 'Experience & Share' },
          { key: 'step04Body', label: 'Step 4 Body', type: 'textarea' },
        ],
        defaultValues: {
          sectionLabel: 'How It Works',
          step01Title: 'Choose Your Lens',
          step01Body: 'Pick a mode that matches your mood. The entire platform — typography, palette, layout, and content curation — transforms to match.',
          step02Title: 'Explore the Map',
          step02Body: "An interactive map highlights venues scored and filtered by your chosen mode, with custom markers and district-level discovery.",
          step03Title: 'Discover Events',
          step03Body: "Browse upcoming events filtered and ranked by your mode. See what's happening today, this week, or this month across Hong Kong.",
          step04Title: 'Experience & Share',
          step04Body: 'Visit venues, attend events, and contribute to the community through recaps, reviews, and recommendations.',
        },
      },
      {
        id: 'get-involved',
        label: 'Get Involved',
        icon: 'type',
        description: 'Collaboration and submission cards',
        fields: [
          { key: 'sectionLabel', label: 'Section Label', type: 'text', placeholder: 'Get Involved' },
          { key: 'sectionTitle', label: 'Section Title', type: 'text', placeholder: "Let's build Hong Kong's cultural future, together", hint: 'Use *asterisks* for italic emphasis' },
          { key: 'collabTitle', label: 'Collaboration Title', type: 'text', placeholder: 'Collaboration' },
          { key: 'collabDesc', label: 'Collaboration Subtitle', type: 'text', placeholder: 'Partner with us on events, venues & cultural projects' },
          { key: 'collabBody', label: 'Collaboration Body', type: 'textarea' },
          { key: 'collabEmail', label: 'Contact Email', type: 'text', placeholder: 'info@cultive.city' },
          { key: 'submitTitle', label: 'Submit a Story Title', type: 'text', placeholder: 'Submit a Story' },
          { key: 'submitDesc', label: 'Submit a Story Subtitle', type: 'text', placeholder: 'Share a venue, event, or narrative...' },
          { key: 'submitBody', label: 'Submit a Story Body', type: 'textarea' },
        ],
        defaultValues: {
          sectionLabel: 'Get Involved',
          sectionTitle: "Let's build Hong Kong's cultural future, *together*",
          collabTitle: 'Collaboration',
          collabDesc: 'Partner with us on events, venues & cultural projects',
          collabBody: "We partner with venues, event organizers, brands, and cultural institutions across Hong Kong. Whether you're hosting an exhibition, launching a pop-up, or curating a community experience — we'd love to help you reach the right audience.",
          collabEmail: 'info@cultive.city',
          submitTitle: 'Submit a Story',
          submitDesc: 'Share a venue, event, or narrative with our community',
          submitBody: "CULTIVE is built on community-driven content. If you know a hidden gem, run a cultural space, or are organizing something extraordinary in Hong Kong, we want to hear from you.",
        },
      },
      {
        id: 'cta',
        label: 'Call to Action',
        icon: 'type',
        description: 'Bottom CTA section with links',
        fields: [
          { key: 'headline', label: 'Headline', type: 'text', placeholder: 'Ready to explore?' },
          { key: 'description', label: 'Description', type: 'textarea', placeholder: "Discover Hong Kong's most vibrant cultural experiences." },
          { key: 'ctaPrimaryLabel', label: 'Primary CTA Label', type: 'text', placeholder: 'Open Map' },
          { key: 'ctaSecondaryLabel', label: 'Secondary CTA Label', type: 'text', placeholder: 'Events' },
        ],
        defaultValues: {
          headline: 'Ready to explore?',
          description: "Discover Hong Kong's most vibrant cultural experiences.",
          ctaPrimaryLabel: 'Open Map',
          ctaSecondaryLabel: 'Events',
        },
      },
      // About page images managed in Site Images tab to avoid duplicates
    ],
  },
  {
    id: 'modes',
    label: 'Mode Pages',
    description: 'Hero images and settings for each of the 5 mode experiences',
    previewPath: '/',
    sections: [
      {
        id: 'night',
        label: 'Night / Degen',
        icon: 'film',
        description: 'Night mode page hero and imagery',
        fields: [
          { key: 'mode-hero-night', label: 'Hero Image', type: 'image', hint: 'Full-width hero image for the Night mode page (neon streets, nightlife)' },
        ],
        defaultValues: { 'mode-hero-night': '' },
      },
      {
        id: 'art',
        label: 'Art & Design',
        icon: 'palette',
        description: 'Art mode page hero and imagery',
        fields: [
          { key: 'mode-hero-art', label: 'Hero Image', type: 'image', hint: 'Editorial image for the Art & Design mode page (galleries, architecture)' },
        ],
        defaultValues: { 'mode-hero-art': '' },
      },
      {
        id: 'food',
        label: 'Food & Drink',
        icon: 'layers',
        description: 'Food mode page hero and imagery',
        fields: [
          { key: 'mode-hero-food', label: 'Hero Image', type: 'image', hint: 'Hero image for the Food mode page (markets, restaurants, dim sum)' },
        ],
        defaultValues: { 'mode-hero-food': '' },
      },
      {
        id: 'family',
        label: 'Family',
        icon: 'image',
        description: 'Family mode page hero and imagery',
        fields: [
          { key: 'mode-hero-family', label: 'Hero Image', type: 'image', hint: 'Hero image for the Family mode page (kids activities, parks)' },
        ],
        defaultValues: { 'mode-hero-family': '' },
      },
      {
        id: 'lifestyle',
        label: 'Lifestyle',
        icon: 'globe',
        description: 'Lifestyle mode page hero and texture imagery',
        fields: [
          { key: 'mode-hero-lifestyle', label: 'Hero Image', type: 'image', hint: 'Hero image for the Lifestyle mode page (wellness, outdoor)' },
          { key: 'lifestyle-texture', label: 'Paper Texture Background', type: 'image', hint: 'Background texture used behind the Lifestyle page content' },
        ],
        defaultValues: { 'mode-hero-lifestyle': '', 'lifestyle-texture': '' },
      },
    ],
  },
  {
    id: 'map',
    label: 'Map Page',
    description: 'Interactive venue discovery map',
    previewPath: '/map',
    sections: [
      {
        id: 'settings',
        label: 'Map Settings',
        icon: 'globe',
        description: 'Default map view and behavior',
        fields: [
          { key: 'defaultZoom', label: 'Default Zoom Level', type: 'number', placeholder: '13' },
          { key: 'centerLat', label: 'Center Latitude', type: 'number', placeholder: '22.2783' },
          { key: 'centerLng', label: 'Center Longitude', type: 'number', placeholder: '114.1747' },
          { key: 'showClusters', label: 'Cluster Nearby Pins', type: 'toggle' },
        ],
        defaultValues: { defaultZoom: 13, centerLat: 22.2783, centerLng: 114.1747, showClusters: true },
      },
    ],
  },
  // ─── Site Images (auto-generated from registry) ───
  (() => {
    const groups: Record<string, typeof staticSiteImages> = {};
    for (const si of staticSiteImages) {
      if (!groups[si.page]) groups[si.page] = [];
      groups[si.page].push(si);
    }
    return {
      id: 'site-images',
      label: 'Site Images',
      description: 'Override any hardcoded image across the site. Changes apply immediately.',
      previewPath: '/',
      sections: Object.entries(groups).map(([pageKey, slots]) => ({
        id: pageKey,
        label: PAGE_LABELS[pageKey] || pageKey,
        icon: 'image',
        description: `${slots.length} image${slots.length > 1 ? 's' : ''} in this section`,
        fields: slots.map(slot => ({
          key: slot.id,
          label: slot.slot,
          type: (slot.type === 'video' ? 'video' : 'image') as SectionField['type'],
          placeholder: '',
          hint: `Default: ${slot.alt}`,
        })),
        defaultValues: Object.fromEntries(slots.map(s => [s.id, s.url])),
      })),
    } satisfies PageDef;
  })(),
];

// ══════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════

function authHeaders(accessToken: string) {
  return {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${publicAnonKey}`,
    'X-Auth-Token': accessToken,
  };
}

const ICON_MAP: Record<string, React.ReactNode> = {
  film: <Film size={15} />,
  image: <ImageIcon size={15} />,
  palette: <Palette size={15} />,
  layers: <Layers size={15} />,
  calendar: <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" /><line x1="16" y1="2" x2="16" y2="6" /><line x1="8" y1="2" x2="8" y2="6" /><line x1="3" y1="10" x2="21" y2="10" /></svg>,
  'map-pin': <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0116 0z" /><circle cx="12" cy="10" r="3" /></svg>,
  globe: <Globe size={15} />,
  type: <Type size={15} />,
};

// ═══════════════════════════════════════════════════
// MAIN COMPONENT
// ═══════════════════════════════════════════════════

export function TemplateEditor() {
  const { accessToken } = useOutletContext<{ accessToken: string }>();

  // State
  const [selectedPage, setSelectedPage] = useState<string>('home');
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set(['hero']));
  const [selectedSectionId, setSelectedSectionId] = useState<string | null>(null);
  const [sectionData, setSectionData] = useState<Record<string, Record<string, any>>>({});
  const [sectionVisibility, setSectionVisibility] = useState<Record<string, boolean>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saveResult, setSaveResult] = useState<'success' | 'error' | null>(null);
  const [hasChanges, setHasChanges] = useState(false);
  // (preview device removed — using live preview link instead)
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [error, setError] = useState('');

  const page = PAGES.find(p => p.id === selectedPage)!;

  // Load saved template data
  const loadData = useCallback(async () => {
    if (!accessToken) return;
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/content/template-${selectedPage}`, {
        headers: authHeaders(accessToken),
      });
      if (res.ok) {
        const data = await res.json();
        const items = data.items || [];
        const loaded: Record<string, Record<string, any>> = {};
        const visibility: Record<string, boolean> = {};
        items.forEach((item: any) => {
          const sectionId = item.id?.replace(`template-${selectedPage}-`, '') || item.sectionId;
          if (sectionId) {
            loaded[sectionId] = item.data || item;
            visibility[sectionId] = item.visible !== false;
          }
        });
        setSectionData(loaded);
        setSectionVisibility(visibility);
      }
    } catch (err) {
      console.log('Template load (expected on first use):', err);
    }
    setLoading(false);
    setHasChanges(false);
  }, [accessToken, selectedPage]);

  useEffect(() => {
    loadData();
    setExpandedSections(new Set(['hero']));
    setSelectedSectionId(page.sections[0]?.id || null);
  }, [loadData, selectedPage]);

  // Get effective value for a section field
  const getValue = useCallback((sectionId: string, fieldKey: string) => {
    const sectionDef = page.sections.find(s => s.id === sectionId);
    const saved = sectionData[sectionId]?.[fieldKey];
    return saved !== undefined ? saved : (sectionDef?.defaultValues[fieldKey] ?? '');
  }, [sectionData, page]);

  // Update a field value
  const updateField = useCallback((sectionId: string, fieldKey: string, value: any) => {
    setSectionData(prev => ({
      ...prev,
      [sectionId]: {
        ...(prev[sectionId] || {}),
        [fieldKey]: value,
      },
    }));
    setHasChanges(true);
  }, []);

  // Toggle section visibility
  const toggleVisibility = useCallback((sectionId: string) => {
    setSectionVisibility(prev => ({
      ...prev,
      [sectionId]: !(prev[sectionId] !== false),
    }));
    setHasChanges(true);
  }, []);

  // Toggle section expansion
  const toggleExpanded = useCallback((sectionId: string) => {
    setExpandedSections(prev => {
      const next = new Set(prev);
      if (next.has(sectionId)) next.delete(sectionId);
      else next.add(sectionId);
      return next;
    });
  }, []);

  // Save all template data
  const handleSave = useCallback(async () => {
    if (!accessToken) return;
    setSaving(true);
    setError('');
    try {
      // Save each section as a separate KV item
      const errors: string[] = [];
      for (const section of page.sections) {
        // Merge defaults with any overrides so we always persist a complete section
        const data = { ...section.defaultValues, ...(sectionData[section.id] || {}) };
        const visible = sectionVisibility[section.id] !== false;
        const payload = {
          id: `template-${selectedPage}-${section.id}`,
          sectionId: section.id,
          data,
          visible,
          updatedAt: new Date().toISOString(),
        };
        const res = await fetch(`${API_BASE}/content/template-${selectedPage}/${payload.id}`, {
          method: 'PUT',
          headers: authHeaders(accessToken),
          body: JSON.stringify(payload),
        });
        if (!res.ok) {
          const body = await res.text().catch(() => '');
          console.error(`[TemplateEditor] PUT failed for ${section.id}:`, res.status, body);
          errors.push(`${section.label}: ${res.status} ${body.slice(0, 100)}`);
        }
      }
      if (errors.length > 0) {
        setError(`Save failed for ${errors.length} section(s): ${errors[0]}`);
        setSaveResult('error');
      } else {
        setSaveResult('success');
      }
      setHasChanges(false);
      // Invalidate image cache for any page that might contain image overrides
      invalidateSiteImageCache();
      invalidateTemplateCache();
      setTimeout(() => setSaveResult(null), 2500);
    } catch (err: any) {
      console.log('Save error:', err);
      setError(err.message || 'Save failed');
      setSaveResult('error');
    }
    setSaving(false);
  }, [accessToken, selectedPage, page, sectionData, sectionVisibility]);

  // Reset section to defaults
  const resetSection = useCallback((sectionId: string) => {
    const sectionDef = page.sections.find(s => s.id === sectionId);
    if (!sectionDef) return;
    setSectionData(prev => ({
      ...prev,
      [sectionId]: { ...sectionDef.defaultValues },
    }));
    setHasChanges(true);
  }, [page]);

  // Image upload handler
  const handleImageUpload = useCallback(async (sectionId: string, fieldKey: string, file: File) => {
    try {
      const formData = new FormData();
      formData.append('files', file);
      const res = await fetch(`${API_BASE}/upload`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${publicAnonKey}` },
        body: formData,
      });
      const data = await res.json();
      if (data.uploaded?.[0]?.url) {
        // Convert signed URL → public URL so images don't expire
        let url = data.uploaded[0].url;
        if (url.includes('/object/sign/')) {
          url = url.replace('/object/sign/', '/object/public/').replace(/\?token=.*$/, '');
        }
        updateField(sectionId, fieldKey, url);
      }
    } catch (err) {
      console.log('Upload error:', err);
    }
  }, [updateField]);



  return (
    <div className="h-screen flex flex-col" style={{ fontFamily: N.font, backgroundColor: '#F0F0ED' }}>
      {/* ═══ Top Bar ═══ */}
      <header
        className="flex items-center justify-between h-[52px] px-4 flex-shrink-0"
        style={{ backgroundColor: N.dark, color: '#fff' }}
      >
        <div className="flex items-center gap-3">
          <button
            onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
            className="p-1.5 rounded-md transition-colors hover:bg-white/10 cursor-pointer"
          >
            <PanelLeft size={16} />
          </button>
          <div className="h-5 w-px bg-white/15" />
          {/* Page selector */}
          <select
            value={selectedPage}
            onChange={e => setSelectedPage(e.target.value)}
            className="bg-white/10 text-white text-[13px] font-medium px-3 py-1.5 rounded-lg border border-white/10 outline-none cursor-pointer appearance-none"
            style={{ minWidth: '140px' }}
          >
            {PAGES.map(p => (
              <option key={p.id} value={p.id} className="text-gray-900 bg-white">{p.label}</option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-2">
          {/* Save */}
          <div className="flex items-center gap-2">
            {saveResult === 'success' && (
              <motion.span
                initial={{ opacity: 0, x: 8 }} animate={{ opacity: 1, x: 0 }}
                className="flex items-center gap-1 text-[12px] text-emerald-400"
              >
                <Check size={13} /> Saved
              </motion.span>
            )}
            <button
              onClick={handleSave}
              disabled={saving || !hasChanges}
              className="flex items-center gap-1.5 px-4 py-1.5 text-[13px] font-medium cursor-pointer transition-all rounded-lg disabled:opacity-40"
              style={{
                backgroundColor: hasChanges ? N.blue : 'rgba(255,255,255,0.1)',
                color: '#fff',
              }}
            >
              {saving ? <Loader2 size={13} className="animate-spin" /> : <Save size={13} />}
              {saving ? 'Saving...' : 'Save'}
            </button>
          </div>
        </div>
      </header>

      {/* ═══ Body: Sidebar + Preview ═══ */}
      <div className="flex flex-1 overflow-hidden">
        {/* ─── Left Sidebar: Section Editor ─── */}
        <AnimatePresence mode="wait">
          {!sidebarCollapsed && (
            <motion.aside
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: 260, opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              transition={{ duration: 0.2, ease: [0.22, 1, 0.36, 1] }}
              className="flex-shrink-0 h-full flex flex-col overflow-hidden"
              style={{ backgroundColor: N.surface, borderRight: `1px solid ${N.border}` }}
            >
              {/* Page info */}
              <div className="px-4 py-3 flex-shrink-0" style={{ borderBottom: `1px solid ${N.border}` }}>
                <h2 className="text-[14px] font-semibold" style={{ color: N.text }}>{page.label}</h2>
                <p className="text-[11px] mt-0.5" style={{ color: N.textMuted }}>{page.description}</p>
              </div>

              {/* Sections */}
              <div className="flex-1 overflow-y-auto">
                <div className="p-2">
                  <p className="px-2 pt-2 pb-1.5 text-[10px] font-semibold uppercase tracking-wider" style={{ color: N.textMuted }}>
                    Sections
                  </p>

                  {page.sections.map((section) => {
                    const isSelected = selectedSectionId === section.id;
                    const isVisible = sectionVisibility[section.id] !== false;
                    const fieldsWithValues = section.fields.filter(f => {
                      const val = getValue(section.id, f.key);
                      return val !== undefined && val !== '' && val !== section.defaultValues[f.key];
                    });

                    return (
                      <button
                        key={section.id}
                        onClick={() => setSelectedSectionId(section.id)}
                        className="w-full flex items-center gap-2 px-2.5 py-2.5 text-left cursor-pointer transition-colors rounded-lg mb-0.5"
                        style={{
                          backgroundColor: isSelected ? N.blueBg : 'transparent',
                          borderLeft: isSelected ? `2px solid ${N.blue}` : '2px solid transparent',
                        }}
                      >
                        <span style={{ color: isSelected ? N.blue : N.textMuted }}>
                          {ICON_MAP[section.icon] || <Layers size={15} />}
                        </span>
                        <span className="flex-1 text-[13px] font-medium truncate" style={{ color: isSelected ? N.text : N.textSecondary }}>
                          {section.label}
                        </span>
                        {fieldsWithValues.length > 0 && (
                          <span className="text-[8px] px-1.5 py-0.5 rounded-full flex-shrink-0" style={{ backgroundColor: N.blueBg, color: N.blue }}>
                            {fieldsWithValues.length}
                          </span>
                        )}
                        {!isVisible && (
                          <span className="text-[8px] px-1 py-0.5 rounded font-bold uppercase flex-shrink-0" style={{ backgroundColor: N.amberBg, color: N.amber }}>
                            Off
                          </span>
                        )}
                        <ChevronRight size={12} style={{ color: N.textMuted, flexShrink: 0 }} />
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* View Live */}
              <div className="px-3 py-2.5 flex-shrink-0" style={{ borderTop: `1px solid ${N.border}` }}>
                <a
                  href={page.previewPath}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 w-full px-3 py-2 rounded-lg text-[11px] font-medium transition-colors hover:opacity-80"
                  style={{ backgroundColor: N.surfaceMuted, color: N.textSecondary, border: `1px solid ${N.border}` }}
                >
                  <ExternalLink size={12} /> View Live Page
                </a>
              </div>

              {/* Bottom actions */}
              {hasChanges && (
                <div className="px-4 py-3 flex-shrink-0" style={{ borderTop: `1px solid ${N.border}`, backgroundColor: N.surfaceMuted }}>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                    <span className="text-[11px] font-medium flex-1" style={{ color: N.textSecondary }}>Unsaved changes</span>
                    <button
                      onClick={handleSave}
                      disabled={saving}
                      className="flex items-center gap-1 px-3 py-1.5 text-[12px] font-medium cursor-pointer rounded-lg transition-opacity disabled:opacity-50"
                      style={{ backgroundColor: N.blue, color: '#fff' }}
                    >
                      {saving ? <Loader2 size={11} className="animate-spin" /> : <Save size={11} />}
                      Save
                    </button>
                  </div>
                </div>
              )}
            </motion.aside>
          )}
        </AnimatePresence>

        {/* ─── Right: Section Editor Workspace ─── */}
        <div className="flex-1 flex flex-col overflow-auto" style={{ backgroundColor: '#E8E8E4' }}>
          {error && (
            <div className="flex items-center gap-2 bg-red-50 border border-red-200 text-red-700 text-[12px] rounded-lg px-3 py-2 shadow-lg m-4 mb-0">
              <AlertCircle size={13} />
              {error}
              <button onClick={() => setError('')} className="ml-1 text-red-400 hover:text-red-600 cursor-pointer"><X size={12} /></button>
            </div>
          )}

          {(() => {
            const activeSection = page.sections.find(s => s.id === selectedSectionId);
            if (!activeSection) {
              return (
                <div className="flex-1 flex items-center justify-center">
                  <div className="text-center">
                    <Layers size={32} style={{ color: N.textMuted, margin: '0 auto 12px' }} />
                    <p className="text-[13px] font-medium" style={{ color: N.textSecondary }}>Select a section to edit</p>
                    <p className="text-[11px] mt-1" style={{ color: N.textMuted }}>Choose from the sidebar on the left</p>
                  </div>
                </div>
              );
            }

            const isVisible = sectionVisibility[activeSection.id] !== false;
            const imageFields = activeSection.fields.filter(f => f.type === 'image' || f.type === 'video');
            const nonImageFields = activeSection.fields.filter(f => f.type !== 'image' && f.type !== 'video');

            return (
              <div className="p-5 lg:p-8 max-w-[900px] mx-auto w-full">
                {/* Section header */}
                <div className="flex items-start justify-between mb-6">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ backgroundColor: N.blueBg }}>
                      <span style={{ color: N.blue }}>{ICON_MAP[activeSection.icon] || <Layers size={17} />}</span>
                    </div>
                    <div>
                      <h3 className="text-[16px] font-semibold" style={{ color: N.text }}>{activeSection.label}</h3>
                      <p className="text-[12px] mt-0.5" style={{ color: N.textMuted }}>{activeSection.description}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg" style={{ backgroundColor: N.surface, border: `1px solid ${N.border}` }}>
                      <span className="text-[11px] font-medium" style={{ color: N.textSecondary }}>Visible</span>
                      <button onClick={() => toggleVisibility(activeSection.id)} className="cursor-pointer">
                        {isVisible
                          ? <ToggleRight size={22} style={{ color: N.green }} />
                          : <ToggleLeft size={22} style={{ color: N.textMuted }} />
                        }
                      </button>
                    </div>
                    <button
                      onClick={() => resetSection(activeSection.id)}
                      className="flex items-center gap-1.5 px-3 py-1.5 text-[11px] cursor-pointer rounded-lg transition-colors hover:bg-white"
                      style={{ color: N.textMuted, border: `1px solid ${N.border}`, backgroundColor: N.surface }}
                    >
                      <RotateCcw size={11} /> Reset
                    </button>
                  </div>
                </div>

                {/* Fields — two-column layout for non-image fields, then images below */}
                {nonImageFields.length > 0 && (
                  <div className="rounded-xl p-5 mb-5 shadow-sm" style={{ backgroundColor: N.surface, border: `1px solid ${N.border}` }}>
                    <div className={`grid gap-4 ${nonImageFields.length > 2 ? 'grid-cols-1 sm:grid-cols-2' : 'grid-cols-1'}`}>
                      {nonImageFields.map(field => (
                        <div key={field.key} className={field.type === 'textarea' ? 'sm:col-span-2' : ''}>
                          <SectionFieldInput
                            field={field}
                            value={getValue(activeSection.id, field.key)}
                            onChange={(val) => updateField(activeSection.id, field.key, val)}
                            onUpload={(file) => handleImageUpload(activeSection.id, field.key, file)}
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Image/video fields — larger cards */}
                {imageFields.length > 0 && (
                  <div className="rounded-xl p-5 shadow-sm" style={{ backgroundColor: N.surface, border: `1px solid ${N.border}` }}>
                    <p className="text-[10px] font-semibold uppercase tracking-wider mb-4" style={{ color: N.textMuted }}>
                      Media ({imageFields.length})
                    </p>
                    <div className={`grid gap-5 ${imageFields.length === 1 ? 'grid-cols-1' : 'grid-cols-1 sm:grid-cols-2'}`}>
                      {imageFields.map(field => (
                        <SectionFieldInput
                          key={field.key}
                          field={field}
                          value={getValue(activeSection.id, field.key)}
                          onChange={(val) => updateField(activeSection.id, field.key, val)}
                          onUpload={(file) => handleImageUpload(activeSection.id, field.key, file)}
                          focalPoint={getValue(activeSection.id, `${field.key}-focal`)}
                          onFocalPointChange={(val) => updateField(activeSection.id, `${field.key}-focal`, val)}
                        />
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })()}
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════
// SECTION FIELD INPUT — individual field editor
// ═══════════════════════════════════════════════════

function SectionFieldInput({ field, value, onChange, onUpload, focalPoint, onFocalPointChange }: {
  field: SectionField;
  value: any;
  onChange: (val: any) => void;
  onUpload: (file: File) => void;
  focalPoint?: { x: number, y: number };
  onFocalPointChange?: (val: { x: number, y: number }) => void;
}) {
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState('');
  const [dragOver, setDragOver] = useState(false);
  const [focalMode, setFocalMode] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const focalRef = useRef<HTMLDivElement>(null);

  const inputStyle: React.CSSProperties = {
    backgroundColor: N.surfaceMuted,
    border: `1px solid ${N.border}`,
    borderRadius: '8px',
    color: N.text,
    fontFamily: N.font,
    fontSize: '12px',
  };

  const handleFileSelect = async (file: File) => {
    const isVideo = file.type.startsWith('video/');
    const isImage = file.type.startsWith('image/');
    const maxSize = isVideo ? 200 * 1024 * 1024 : 10 * 1024 * 1024;

    if (!isVideo && !isImage) {
      setUploadProgress('Unsupported file type');
      setTimeout(() => setUploadProgress(''), 3000);
      return;
    }
    if (file.size > maxSize) {
      setUploadProgress(`File too large (max ${maxSize / 1024 / 1024}MB)`);
      setTimeout(() => setUploadProgress(''), 3000);
      return;
    }

    setUploading(true);
    let fileToUpload = file;

    // ── Compress video if it's large enough to benefit ──
    if (shouldCompress(file, 10)) {
      const originalMB = (file.size / 1024 / 1024).toFixed(1);
      setUploadProgress(`Compressing video (${originalMB}MB)… preparing…`);
      try {
        let compressStart = 0;
        fileToUpload = await compressVideo(file, {
          targetBitrate: 4_000_000, // 4 Mbps — high quality for web
          maxWidth: 1280,
          maxHeight: 720,
          fps: 30,
          onProgress: (pct) => {
            if (!compressStart && pct > 0) compressStart = Date.now();
            const pctInt = Math.round(pct * 100);
            let eta = '';
            if (compressStart && pct > 0.05) {
              const elapsed = (Date.now() - compressStart) / 1000;
              const remaining = Math.round((elapsed / pct) * (1 - pct));
              eta = remaining > 1 ? ` · ~${remaining}s left` : ' · almost done';
            }
            setUploadProgress(`Compressing video (${originalMB}MB)… ${pctInt}%${eta}`);
          },
        });
        const compressedMB = (fileToUpload.size / 1024 / 1024).toFixed(1);
        const savings = Math.round((1 - fileToUpload.size / file.size) * 100);
        if (savings > 5) {
          setUploadProgress(`Compressed ${originalMB}MB → ${compressedMB}MB (${savings}% smaller). Uploading…`);
        } else {
          // Compression didn't help much — use original
          console.log('[TemplateEditor] Compression only saved', savings, '% — using original');
          fileToUpload = file;
        }
      } catch (compressErr) {
        // Compression failed — fall back to uploading the original file
        console.warn('[TemplateEditor] Video compression failed, uploading original:', compressErr);
        fileToUpload = file;
      }
    }

    const sizeMB = (fileToUpload.size / 1024 / 1024).toFixed(1);
    setUploadProgress(`Uploading ${fileToUpload.name} (${sizeMB}MB)...`);

    try {
      const formData = new FormData();
      formData.append('files', fileToUpload);
      const res = await fetch(`${API_BASE}/upload`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${publicAnonKey}` },
        body: formData,
      });
      const data = await res.json();

      if (data.errors?.length) {
        setUploadProgress(`Error: ${data.errors[0]}`);
        setTimeout(() => setUploadProgress(''), 4000);
      } else if (data.uploaded?.[0]?.url) {
        // Convert signed URL → public URL so images don't expire
        let url = data.uploaded[0].url;
        if (url.includes('/object/sign/')) {
          url = url.replace('/object/sign/', '/object/public/').replace(/\?token=.*$/, '');
        }
        onChange(url);
        const savedMB = ((file.size - fileToUpload.size) / 1024 / 1024).toFixed(1);
        const msg = fileToUpload !== file
          ? `Upload complete! Saved ${savedMB}MB with compression.`
          : 'Upload complete!';
        setUploadProgress(msg);
        setTimeout(() => setUploadProgress(''), 3000);
      } else {
        setUploadProgress('Upload failed — no URL returned');
        setTimeout(() => setUploadProgress(''), 3000);
      }
    } catch (err: any) {
      setUploadProgress(`Upload failed: ${err.message}`);
      setTimeout(() => setUploadProgress(''), 4000);
    }
    setUploading(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFileSelect(file);
  };

  const isErrorStatus = uploadProgress.startsWith('Error') || uploadProgress.startsWith('Upload failed') || uploadProgress.startsWith('Unsupported') || uploadProgress.startsWith('File too');
  const isSuccessStatus = uploadProgress === 'Upload complete!';

  return (
    <div>
      <label className="block text-[11px] font-medium mb-1" style={{ color: N.textSecondary }}>
        {field.label}
      </label>

      {field.type === 'text' && (
        <input
          type="text" value={value || ''} onChange={e => onChange(e.target.value)}
          placeholder={field.placeholder}
          className="w-full px-3 py-2 outline-none transition-colors focus:border-blue-300"
          style={inputStyle}
        />
      )}

      {field.type === 'textarea' && (
        <textarea
          value={value || ''} onChange={e => onChange(e.target.value)}
          placeholder={field.placeholder} rows={3}
          className="w-full px-3 py-2 outline-none resize-none transition-colors focus:border-blue-300"
          style={inputStyle}
        />
      )}

      {field.type === 'number' && (
        <input
          type="number" value={value ?? ''} onChange={e => onChange(e.target.value ? Number(e.target.value) : '')}
          placeholder={field.placeholder}
          className="w-full px-3 py-2 outline-none transition-colors focus:border-blue-300"
          style={inputStyle}
        />
      )}

      {field.type === 'select' && (
        <select
          value={value || ''} onChange={e => onChange(e.target.value)}
          className="w-full px-3 py-2 outline-none appearance-none cursor-pointer"
          style={inputStyle}
        >
          {field.options?.map(opt => (
            <option key={opt.value} value={opt.value}>{opt.label}</option>
          ))}
        </select>
      )}

      {field.type === 'toggle' && (
        <button onClick={() => onChange(!value)} className="flex items-center gap-2 py-1 cursor-pointer">
          {value
            ? <ToggleRight size={22} style={{ color: N.green }} />
            : <ToggleLeft size={22} style={{ color: N.textMuted }} />
          }
          <span className="text-[12px]" style={{ color: value ? N.green : N.textMuted }}>
            {value ? 'On' : 'Off'}
          </span>
        </button>
      )}

      {(field.type === 'image' || field.type === 'video') && (
        <div className="space-y-2">
          {/* Hidden file input */}
          <input
            ref={fileInputRef}
            type="file"
            accept={field.type === 'video' ? 'video/mp4,video/webm,video/quicktime,video/*' : 'image/*'}
            className="hidden"
            onChange={e => {
              const file = e.target.files?.[0];
              if (file) handleFileSelect(file);
              e.target.value = '';
            }}
          />

          {/* URL input + upload button */}
          <div className="flex gap-1.5">
            <input
              type="text" value={value || ''} onChange={e => onChange(e.target.value)}
              placeholder={field.placeholder || (field.type === 'video' ? 'https://...mp4' : 'https://...')}
              className="flex-1 px-3 py-2 outline-none transition-colors focus:border-blue-300 min-w-0"
              style={inputStyle}
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={uploading}
              className="flex items-center gap-1 px-2.5 py-2 cursor-pointer transition-colors rounded-lg hover:bg-gray-100 disabled:opacity-50"
              style={{ border: `1px solid ${N.border}`, color: N.textMuted }}
            >
              {uploading ? <Loader2 size={13} className="animate-spin" /> : <Upload size={13} />}
            </button>
          </div>

          {/* Upload progress / status */}
          {uploadProgress && (
            <div className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-[11px]" style={{
              backgroundColor: isErrorStatus ? N.redBg : isSuccessStatus ? N.greenBg : N.blueBg,
              color: isErrorStatus ? N.red : isSuccessStatus ? N.green : N.blue,
            }}>
              {uploading && <Loader2 size={11} className="animate-spin" />}
              {isSuccessStatus && <Check size={11} />}
              <span className="flex-1 min-w-0 truncate">{uploadProgress}</span>
            </div>
          )}

          {/* Drag & drop zone — shown when no media is set */}
          {!value && !uploading && (
            <div
              onDragOver={e => { e.preventDefault(); setDragOver(true); }}
              onDragLeave={() => setDragOver(false)}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className="w-full rounded-xl border-2 border-dashed flex flex-col items-center justify-center gap-2 py-5 cursor-pointer transition-all"
              style={{
                borderColor: dragOver ? N.blue : N.border,
                backgroundColor: dragOver ? N.blueBg : N.surfaceMuted,
              }}
            >
              <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: 'rgba(0,0,0,0.04)' }}>
                {field.type === 'video'
                  ? <Film size={18} style={{ color: N.textMuted }} />
                  : <ImageIcon size={18} style={{ color: N.textMuted }} />
                }
              </div>
              <div className="text-center">
                <p className="text-[11px] font-medium" style={{ color: N.textSecondary }}>
                  {dragOver ? 'Drop to upload' : `Drag & drop ${field.type === 'video' ? 'video' : 'image'} here`}
                </p>
                <p className="text-[10px]" style={{ color: N.textMuted }}>
                  or click to browse · {field.type === 'video' ? 'MP4, WebM, MOV up to 200MB · auto-compressed' : 'JPG, PNG, WebP, GIF up to 10MB'}
                </p>
              </div>
            </div>
          )}

          {/* Preview — Image with Focal Point */}
          {value && field.type === 'image' && (() => {
            const fp = focalPoint && typeof focalPoint === 'object' ? focalPoint : { x: 50, y: 50 };
            const objectPos = `${fp.x}% ${fp.y}%`;
            const handleFocalClick = (e: React.MouseEvent<HTMLDivElement>) => {
              if (!focalMode || !onFocalPointChange) return;
              const rect = e.currentTarget.getBoundingClientRect();
              const x = Math.round(((e.clientX - rect.left) / rect.width) * 100);
              const y = Math.round(((e.clientY - rect.top) / rect.height) * 100);
              onFocalPointChange({ x: Math.max(0, Math.min(100, x)), y: Math.max(0, Math.min(100, y)) });
            };
            return (
              <div className="space-y-2">
                <div
                  ref={focalRef}
                  className="relative group w-full aspect-video rounded-lg overflow-hidden"
                  style={{ border: `1px solid ${focalMode ? N.blue : N.border}`, cursor: focalMode ? 'crosshair' : 'default' }}
                  onClick={handleFocalClick}
                >
                  <ImageWithFallback src={value} alt="" className="w-full h-full object-cover" style={{ objectPosition: objectPos }} />
                  {focalMode && (
                    <>
                      <div className="absolute inset-0 pointer-events-none" style={{ opacity: 0.3 }}>
                        <div className="absolute" style={{ left: `${fp.x}%`, top: 0, bottom: 0, width: '1px', backgroundColor: '#fff', boxShadow: '0 0 2px rgba(0,0,0,0.5)' }} />
                        <div className="absolute" style={{ top: `${fp.y}%`, left: 0, right: 0, height: '1px', backgroundColor: '#fff', boxShadow: '0 0 2px rgba(0,0,0,0.5)' }} />
                      </div>
                      <div
                        className="absolute pointer-events-none"
                        style={{
                          left: `${fp.x}%`, top: `${fp.y}%`,
                          transform: 'translate(-50%, -50%)',
                          width: 18, height: 18, borderRadius: '50%',
                          border: '2px solid #fff',
                          boxShadow: '0 0 0 1px rgba(0,0,0,0.3), 0 2px 8px rgba(0,0,0,0.3)',
                          backgroundColor: 'rgba(37,99,235,0.6)',
                        }}
                      />
                      <div className="absolute top-2 left-2 px-2 py-1 bg-blue-600/90 rounded text-[10px] text-white flex items-center gap-1">
                        <Crosshair size={10} /> Click to set focal point
                      </div>
                    </>
                  )}
                  {!focalMode && (
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-colors flex items-center justify-center gap-2 opacity-0 group-hover:opacity-100">
                      <button
                        onClick={(e) => { e.stopPropagation(); fileInputRef.current?.click(); }}
                        className="px-2.5 py-1.5 bg-white/90 text-gray-900 text-[10px] font-medium rounded-md flex items-center gap-1 cursor-pointer hover:bg-white transition-colors"
                      >
                        <Upload size={10} /> Replace
                      </button>
                      <button
                        onClick={(e) => { e.stopPropagation(); onChange(''); }}
                        className="px-2.5 py-1.5 bg-red-500/90 text-white text-[10px] font-medium rounded-md flex items-center gap-1 cursor-pointer hover:bg-red-600 transition-colors"
                      >
                        <X size={10} /> Remove
                      </button>
                    </div>
                  )}
                </div>
                {onFocalPointChange && (
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setFocalMode(!focalMode)}
                      className="flex items-center gap-1.5 px-2.5 py-1.5 text-[10px] font-medium rounded-md cursor-pointer transition-all"
                      style={{
                        backgroundColor: focalMode ? N.blue : N.surfaceMuted,
                        color: focalMode ? '#fff' : N.textSecondary,
                        border: `1px solid ${focalMode ? N.blue : N.border}`,
                      }}
                    >
                      <Crosshair size={10} />
                      {focalMode ? 'Done' : 'Adjust Focus'}
                    </button>
                    {(fp.x !== 50 || fp.y !== 50) && (
                      <>
                        <span className="text-[10px] tabular-nums" style={{ color: N.textMuted }}>{fp.x}% {fp.y}%</span>
                        <button
                          onClick={() => onFocalPointChange({ x: 50, y: 50 })}
                          className="text-[10px] cursor-pointer hover:underline"
                          style={{ color: N.textMuted }}
                        >
                          Reset
                        </button>
                      </>
                    )}
                  </div>
                )}
                {focalMode && (fp.x !== 50 || fp.y !== 50) && (
                  <div className="flex gap-2">
                    {[
                      { label: 'Wide (hero)', ratio: '3/1' },
                      { label: 'Card', ratio: '4/3' },
                      { label: 'Square', ratio: '1/1' },
                    ].map(({ label, ratio }) => (
                      <div key={label} className="flex-1">
                        <p className="text-[9px] font-medium mb-1" style={{ color: N.textMuted }}>{label}</p>
                        <div className="w-full rounded overflow-hidden" style={{ aspectRatio: ratio, border: `1px solid ${N.border}` }}>
                          <ImageWithFallback src={value} alt="" className="w-full h-full object-cover" style={{ objectPosition: objectPos }} />
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })()}

          {/* Preview — Video */}
          {value && field.type === 'video' && (
            <div className="relative group w-full aspect-video rounded-lg overflow-hidden bg-black" style={{ border: `1px solid ${N.border}` }}>
              <video
                src={value}
                muted
                playsInline
                loop
                autoPlay
                className="w-full h-full object-cover"
              />
              <div className="absolute top-2 left-2 flex items-center gap-1 px-2 py-0.5 bg-black/60 rounded text-[10px] text-white/80">
                <Film size={10} /> Video
              </div>
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-colors flex items-center justify-center gap-2 opacity-0 group-hover:opacity-100">
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="px-2.5 py-1.5 bg-white/90 text-gray-900 text-[10px] font-medium rounded-md flex items-center gap-1 cursor-pointer hover:bg-white transition-colors"
                >
                  <Upload size={10} /> Replace
                </button>
                <button
                  onClick={() => onChange('')}
                  className="px-2.5 py-1.5 bg-red-500/90 text-white text-[10px] font-medium rounded-md flex items-center gap-1 cursor-pointer hover:bg-red-600 transition-colors"
                >
                  <X size={10} /> Remove
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {field.type === 'color' && (
        <div className="flex items-center gap-2">
          <input
            type="color" value={value || '#000000'} onChange={e => onChange(e.target.value)}
            className="w-8 h-8 cursor-pointer rounded border-0"
          />
          <input
            type="text" value={value || ''} onChange={e => onChange(e.target.value)}
            placeholder="#000000"
            className="flex-1 px-3 py-2 outline-none"
            style={inputStyle}
          />
        </div>
      )}

      {field.type === 'url' && (
        <div className="flex items-center gap-1.5">
          <Link2 size={12} style={{ color: N.textMuted }} className="flex-shrink-0" />
          <input
            type="url" value={value || ''} onChange={e => onChange(e.target.value)}
            placeholder={field.placeholder || 'https://...'}
            className="flex-1 px-3 py-2 outline-none min-w-0"
            style={inputStyle}
          />
        </div>
      )}

      {field.hint && (
        <p className="text-[10px] mt-1 px-0.5" style={{ color: N.textMuted }}>{field.hint}</p>
      )}
    </div>
  );
}