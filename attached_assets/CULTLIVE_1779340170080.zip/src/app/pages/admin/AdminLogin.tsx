import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { motion } from 'motion/react';
import { Loader2, Eye, EyeOff, AlertCircle, ArrowRight } from 'lucide-react';
import { useAdminAuth } from '../../hooks/useAdminApi';

const N = {
  pageBg: '#FAFAF8',
  surface: '#FFFFFF',
  surfaceMuted: '#F3F3F0',
  dark: '#1A1A1A',
  darkSoft: '#2A2A2A',
  text: '#1A1A1A',
  textSecondary: '#5A5A5A',
  textMuted: '#9A9A9A',
  border: 'rgba(0,0,0,0.06)',
  borderFocus: 'rgba(0,0,0,0.15)',
  error: '#DC2626',
  errorBg: 'rgba(220,38,38,0.05)',
  font: "'Inter', 'Noto Sans HK', system-ui, sans-serif",
};

export function AdminLogin() {
  const { user, signIn, signUp, checkAdminExists } = useAdminAuth();
  const navigate = useNavigate();
  const [isSignup, setIsSignup] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    if (user) navigate('/admin');
  }, [user, navigate]);

  useEffect(() => {
    checkAdminExists().then(hasAdmin => {
      setIsSignup(!hasAdmin);
      setChecking(false);
    }).catch(() => setChecking(false));
  }, [checkAdminExists]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      if (isSignup) {
        await signUp(email, password, name);
        await signIn(email, password);
      } else {
        await signIn(email, password);
      }
      navigate('/admin');
    } catch (err: any) {
      setError(err.message || 'Authentication failed');
    }
    setLoading(false);
  };

  if (checking) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: N.pageBg }}>
        <Loader2 size={20} className="animate-spin" style={{ color: N.textMuted }} />
      </div>
    );
  }

  const inputStyle: React.CSSProperties = {
    backgroundColor: N.surfaceMuted,
    border: `1px solid ${N.border}`,
    borderRadius: '12px',
    color: N.text,
    fontFamily: N.font,
  };

  return (
    <div className="min-h-screen flex" style={{ backgroundColor: N.pageBg, fontFamily: N.font }}>
      {/* Left — dark brand panel */}
      <div className="hidden lg:flex flex-col justify-between relative w-[44%] p-12 xl:p-16"
        style={{ backgroundColor: N.dark }}>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        >
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[15px] font-bold tracking-tight" style={{ color: '#fff' }}>
              CULTIVE
            </span>
            <span className="text-[11px]" style={{ color: 'rgba(255,255,255,0.35)' }}>文化活</span>
          </div>
          <div className="h-px my-8" style={{ backgroundColor: 'rgba(255,255,255,0.08)' }} />
          <h1 className="text-[2.8rem] xl:text-[3.2rem] font-semibold leading-[1.05] tracking-tight"
            style={{ color: '#fff' }}>
            Content<br />Management
          </h1>
        </motion.div>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4, duration: 0.6 }}
          className="text-sm leading-relaxed"
          style={{ color: 'rgba(255,255,255,0.4)' }}
        >
          Manage submissions, review community contributions, and curate Hong Kong's cultural events.
        </motion.p>
      </div>

      {/* Right — form */}
      <div className="flex-1 flex items-center justify-center p-6 sm:p-12">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="w-full max-w-[380px]"
        >
          {/* Mobile logo */}
          <div className="lg:hidden mb-10">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[15px] font-bold tracking-tight" style={{ color: N.text }}>CULTIVE</span>
              <span className="text-[11px]" style={{ color: N.textMuted }}>文化活</span>
            </div>
          </div>

          <div className="mb-8">
            <h2 className="text-2xl font-semibold tracking-tight" style={{ color: N.text }}>
              {isSignup ? 'Create your account' : 'Welcome back'}
            </h2>
            <p className="mt-2 text-[15px]" style={{ color: N.textMuted }}>
              {isSignup ? 'Set up the first admin account to get started.' : 'Sign in to continue to the CMS.'}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {isSignup && (
              <div>
                <label className="block text-[13px] font-medium mb-1.5" style={{ color: N.textSecondary }}>Name</label>
                <input
                  type="text" value={name} onChange={e => setName(e.target.value)}
                  placeholder="Your name"
                  className="w-full px-4 py-3 text-[15px] outline-none transition-colors focus:border-[rgba(0,0,0,0.2)]"
                  style={inputStyle}
                />
              </div>
            )}

            <div>
              <label className="block text-[13px] font-medium mb-1.5" style={{ color: N.textSecondary }}>Email</label>
              <input
                type="email" value={email} onChange={e => setEmail(e.target.value)}
                placeholder="admin@cultive.city" required
                className="w-full px-4 py-3 text-[15px] outline-none transition-colors focus:border-[rgba(0,0,0,0.2)]"
                style={inputStyle}
              />
            </div>

            <div>
              <label className="block text-[13px] font-medium mb-1.5" style={{ color: N.textSecondary }}>Password</label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••" required minLength={6}
                  className="w-full px-4 py-3 pr-11 text-[15px] outline-none transition-colors focus:border-[rgba(0,0,0,0.2)]"
                  style={inputStyle}
                />
                <button type="button" onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 cursor-pointer p-1"
                  style={{ color: N.textMuted }}>
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {error && (
              <motion.div
                initial={{ opacity: 0, y: -4 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex items-center gap-2.5 p-3 text-[13px]"
                style={{
                  backgroundColor: N.errorBg, border: '1px solid rgba(220,38,38,0.1)',
                  borderRadius: '10px', color: N.error,
                }}
              >
                <AlertCircle size={15} className="flex-shrink-0" />
                <span>{error}</span>
              </motion.div>
            )}

            <button
              type="submit" disabled={loading}
              className="w-full py-3 flex items-center justify-center gap-2 text-[15px] font-medium transition-opacity cursor-pointer disabled:opacity-50 hover:opacity-90"
              style={{ backgroundColor: N.dark, color: '#fff', borderRadius: '12px' }}
            >
              {loading ? (
                <Loader2 size={16} className="animate-spin" />
              ) : (
                <>
                  {isSignup ? 'Create Account' : 'Sign In'}
                  <ArrowRight size={16} />
                </>
              )}
            </button>
          </form>

          <p className="mt-10 text-center text-[13px]" style={{ color: N.textMuted }}>
            CULTIVE · Content Management System
          </p>
        </motion.div>
      </div>
    </div>
  );
}