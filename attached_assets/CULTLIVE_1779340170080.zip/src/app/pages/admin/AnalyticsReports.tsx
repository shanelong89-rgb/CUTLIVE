/**
 * AnalyticsReports — Admin analytics dashboard + client report generator.
 * 
 * Sections:
 *  1. Platform Overview — KPI cards (total views, saves, events, conversion rate)
 *  2. Top Events — sortable table by views or saves
 *  3. Category / Venue / Contributor breakdowns
 *  4. Report Generator — create shareable reports for venues, contributors, or platform-wide
 */
import { useState, useEffect, useRef, useCallback } from 'react';
import { useOutletContext } from 'react-router';
import { motion, AnimatePresence } from 'motion/react';
import {
  BarChart3, Eye, Users, TrendingUp, Calendar, Download,
  FileText, Loader2, ChevronDown, ChevronUp, Printer,
  Building2, UserCircle2, Globe, ArrowUpRight, Hash,
  RefreshCcw, Copy, CheckCircle2, AlertCircle,
} from 'lucide-react';
import { projectId, publicAnonKey } from '../../config/supabase';

const API = `https://${projectId}.supabase.co/functions/v1/make-server-d507b98c`;

const N = {
  pageBg: '#FAFAF8',
  surface: '#FFFFFF',
  border: 'rgba(0,0,0,0.06)',
  text: '#1A1A1A',
  textSec: '#5A5A5A',
  textMuted: '#9A9A9A',
  accent: '#1A1A1A',
  green: '#16A34A',
  greenBg: 'rgba(22,163,74,0.06)',
  blue: '#2563EB',
  blueBg: 'rgba(37,99,235,0.05)',
  amber: '#D97706',
  amberBg: 'rgba(217,119,6,0.06)',
  purple: '#7C3AED',
  purpleBg: 'rgba(124,58,237,0.05)',
  font: "'Inter', 'Noto Sans HK', system-ui, sans-serif",
};

interface OverviewData {
  overview: { totalEvents: number; totalViews: number; totalSaves: number; avgViewsPerEvent: number; avgSavesPerEvent: number };
  topByViews: any[];
  topBySaves: any[];
  categoryBreakdown: Record<string, { views: number; saves: number; count: number }>;
  venueBreakdown: { name: string; views: number; saves: number; count: number }[];
  contributorBreakdown: { name: string; views: number; saves: number; count: number }[];
}

interface ReportData {
  reportType: string;
  targetName: string;
  generatedAt: string;
  summary: { totalEvents: number; totalViews: number; totalSaves: number; avgViews: number; avgSaves: number; conversionRate: number };
  topEvents: any[];
  allEvents: any[];
}

type Tab = 'overview' | 'reports';
type ReportType = 'platform' | 'venue' | 'contributor';

export function AnalyticsReports() {
  const { accessToken } = useOutletContext<{ accessToken: string }>();
  const [tab, setTab] = useState<Tab>('overview');
  const [data, setData] = useState<OverviewData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Report generator
  const [reportType, setReportType] = useState<ReportType>('platform');
  const [reportTarget, setReportTarget] = useState('');
  const [reportLoading, setReportLoading] = useState(false);
  const [report, setReport] = useState<ReportData | null>(null);
  const [copied, setCopied] = useState(false);
  const reportRef = useRef<HTMLDivElement>(null);

  const headers = { 'Authorization': `Bearer ${publicAnonKey}`, 'X-Auth-Token': accessToken };

  const loadOverview = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const res = await fetch(`${API}/admin/analytics/overview`, { headers });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const d = await res.json();
      setData(d);
    } catch (err: any) {
      console.log('Analytics load error:', err);
      setError(err.message || 'Failed to load analytics');
    } finally {
      setLoading(false);
    }
  }, [accessToken]);

  useEffect(() => { loadOverview(); }, [loadOverview]);

  const generateReport = async () => {
    setReportLoading(true);
    setReport(null);
    try {
      const body: any = { type: reportType };
      if (reportType !== 'platform') body.targetName = reportTarget;
      const res = await fetch(`${API}/admin/analytics/report`, {
        method: 'POST', headers: { ...headers, 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const d = await res.json();
      setReport(d.report);
    } catch (err: any) {
      console.log('Report generation error:', err);
      setError(err.message);
    } finally {
      setReportLoading(false);
    }
  };

  const handlePrint = () => {
    if (!reportRef.current) return;
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;
    printWindow.document.write(`
      <html><head><title>CULTIVE Report — ${report?.targetName || 'Platform'}</title>
      <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', 'Helvetica Neue', sans-serif; color: #1A1A1A; padding: 40px; }
        .header { border-bottom: 2px solid #1A1A1A; padding-bottom: 16px; margin-bottom: 32px; }
        .header h1 { font-size: 24px; font-weight: 700; letter-spacing: -0.02em; }
        .header p { font-size: 12px; color: #9A9A9A; margin-top: 4px; }
        .kpi-row { display: flex; gap: 16px; margin-bottom: 32px; }
        .kpi { flex: 1; padding: 16px; border: 1px solid #eee; border-radius: 8px; }
        .kpi .value { font-size: 28px; font-weight: 700; }
        .kpi .label { font-size: 11px; color: #9A9A9A; text-transform: uppercase; letter-spacing: 0.1em; margin-top: 4px; }
        table { width: 100%; border-collapse: collapse; margin-top: 16px; }
        th, td { text-align: left; padding: 8px 12px; font-size: 13px; border-bottom: 1px solid #eee; }
        th { font-size: 10px; text-transform: uppercase; letter-spacing: 0.1em; color: #9A9A9A; }
        .section-title { font-size: 14px; font-weight: 600; margin-top: 32px; margin-bottom: 8px; }
        .footer { margin-top: 40px; padding-top: 16px; border-top: 1px solid #eee; font-size: 10px; color: #9A9A9A; }
        @media print { body { padding: 20px; } }
      </style></head><body>
      ${reportRef.current.innerHTML}
      </body></html>
    `);
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => printWindow.print(), 300);
  };

  const copyJSON = () => {
    if (!report) return;
    navigator.clipboard.writeText(JSON.stringify(report, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadCSV = () => {
    if (!report) return;
    const rows = report.allEvents || [];
    const csvHeader = 'Event,Views,Saves,Date,Category\n';
    const csvBody = rows.map((r: any) =>
      `"${(r.title || '').replace(/"/g, '""')}",${r.views},${r.saves},"${r.date || ''}","${r.category || ''}"`
    ).join('\n');
    const blob = new Blob([csvHeader + csvBody], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `cultive-report-${report.reportType}-${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // ─── RENDER ───

  return (
    <div className="max-w-6xl mx-auto" style={{ fontFamily: N.font }}>
      {/* Page header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold" style={{ color: N.text, letterSpacing: '-0.02em' }}>
            Analytics & Reports
          </h1>
          <p className="text-sm mt-1" style={{ color: N.textMuted }}>
            Platform metrics, engagement tracking, and client-facing report generation
          </p>
        </div>
        <button
          onClick={loadOverview}
          disabled={loading}
          className="flex items-center gap-2 px-4 py-2 text-sm font-medium cursor-pointer hover:opacity-80 transition-opacity disabled:opacity-50"
          style={{ backgroundColor: N.surface, border: `1px solid ${N.border}`, borderRadius: '8px', color: N.text }}
        >
          <RefreshCcw size={14} className={loading ? 'animate-spin' : ''} /> Refresh
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 mb-6 p-1" style={{ backgroundColor: N.surface, border: `1px solid ${N.border}`, borderRadius: '10px', display: 'inline-flex' }}>
        {([
          { key: 'overview', label: 'Platform Overview', icon: BarChart3 },
          { key: 'reports', label: 'Report Generator', icon: FileText },
        ] as const).map(t => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className="flex items-center gap-2 px-4 py-2 text-sm font-medium cursor-pointer transition-all"
            style={{
              backgroundColor: tab === t.key ? N.accent : 'transparent',
              color: tab === t.key ? '#fff' : N.textMuted,
              borderRadius: '8px',
            }}
          >
            <t.icon size={14} /> {t.label}
          </button>
        ))}
      </div>

      {error && !loading && (
        <div className="flex items-center gap-2 px-4 py-3 mb-6 text-sm" style={{ backgroundColor: 'rgba(239,68,68,0.06)', color: '#EF4444', borderRadius: '10px' }}>
          <AlertCircle size={14} /> {error}
        </div>
      )}

      {/* ═══ OVERVIEW TAB ═══ */}
      {tab === 'overview' && (
        <div>
          {loading ? (
            <div className="flex items-center justify-center py-20">
              <Loader2 size={20} className="animate-spin" style={{ color: N.textMuted }} />
            </div>
          ) : data ? (
            <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
              {/* KPI Cards */}
              <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 mb-8">
                <KPICard icon={Calendar} label="Total Events" value={data.overview.totalEvents.toLocaleString()} color={N.text} bg={N.surface} />
                <KPICard icon={Eye} label="Total Views" value={data.overview.totalViews.toLocaleString()} color={N.blue} bg={N.blueBg} />
                <KPICard icon={Users} label="Total Saves" value={data.overview.totalSaves.toLocaleString()} color={N.green} bg={N.greenBg} sub={`≈ people "going"`} />
                <KPICard icon={TrendingUp} label="Avg Views/Event" value={String(data.overview.avgViewsPerEvent)} color={N.amber} bg={N.amberBg} />
                <KPICard icon={ArrowUpRight} label="Save Rate" value={data.overview.totalViews > 0 ? `${(data.overview.totalSaves / data.overview.totalViews * 100).toFixed(1)}%` : '—'} color={N.purple} bg={N.purpleBg} sub="saves ÷ views" />
              </div>

              {/* Top Events by Views */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
                <RankTable title="Top Events by Views" icon={Eye} rows={data.topByViews} metricKey="views" metricLabel="Views" />
                <RankTable title="Most Saved Events" icon={Users} rows={data.topBySaves} metricKey="saves" metricLabel="Saves" />
              </div>

              {/* Category Breakdown */}
              <SectionTitle>Category Breakdown</SectionTitle>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 mb-8">
                {Object.entries(data.categoryBreakdown)
                  .sort((a, b) => b[1].views - a[1].views)
                  .map(([cat, stats]) => (
                    <div key={cat} className="p-4" style={{ backgroundColor: N.surface, border: `1px solid ${N.border}`, borderRadius: '10px' }}>
                      <p className="text-[10px] font-semibold uppercase tracking-wider mb-2" style={{ color: N.textMuted }}>{cat}</p>
                      <p className="text-lg font-bold" style={{ color: N.text }}>{stats.views.toLocaleString()}</p>
                      <div className="flex items-center gap-3 mt-1">
                        <span className="text-[11px]" style={{ color: N.textMuted }}><Eye size={9} className="inline mr-0.5" /> views</span>
                        <span className="text-[11px]" style={{ color: N.green }}><Users size={9} className="inline mr-0.5" /> {stats.saves}</span>
                        <span className="text-[11px]" style={{ color: N.textMuted }}><Hash size={9} className="inline mr-0.5" /> {stats.count} events</span>
                      </div>
                    </div>
                  ))}
              </div>

              {/* Venue Breakdown */}
              {data.venueBreakdown.length > 0 && (
                <>
                  <SectionTitle>Venue Performance</SectionTitle>
                  <div className="overflow-x-auto mb-8" style={{ backgroundColor: N.surface, border: `1px solid ${N.border}`, borderRadius: '10px' }}>
                    <table className="w-full">
                      <thead>
                        <tr>
                          <TH>Venue</TH><TH align="right">Events</TH><TH align="right">Views</TH><TH align="right">Saves</TH><TH align="right">Save Rate</TH>
                        </tr>
                      </thead>
                      <tbody>
                        {data.venueBreakdown.map((v, i) => (
                          <tr key={v.name} style={{ backgroundColor: i % 2 === 0 ? 'transparent' : 'rgba(0,0,0,0.015)' }}>
                            <TD><Building2 size={12} className="inline mr-1.5 opacity-40" />{v.name}</TD>
                            <TD align="right">{v.count}</TD>
                            <TD align="right" bold>{v.views.toLocaleString()}</TD>
                            <TD align="right" color={N.green}>{v.saves.toLocaleString()}</TD>
                            <TD align="right">{v.views > 0 ? `${(v.saves / v.views * 100).toFixed(1)}%` : '—'}</TD>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </>
              )}

              {/* Contributor Breakdown */}
              {data.contributorBreakdown.length > 0 && (
                <>
                  <SectionTitle>Contributor Reach</SectionTitle>
                  <div className="overflow-x-auto mb-8" style={{ backgroundColor: N.surface, border: `1px solid ${N.border}`, borderRadius: '10px' }}>
                    <table className="w-full">
                      <thead>
                        <tr>
                          <TH>Contributor</TH><TH align="right">Events</TH><TH align="right">Views</TH><TH align="right">Saves</TH><TH align="right">Save Rate</TH>
                        </tr>
                      </thead>
                      <tbody>
                        {data.contributorBreakdown.map((c, i) => (
                          <tr key={c.name} style={{ backgroundColor: i % 2 === 0 ? 'transparent' : 'rgba(0,0,0,0.015)' }}>
                            <TD><UserCircle2 size={12} className="inline mr-1.5 opacity-40" />{c.name}</TD>
                            <TD align="right">{c.count}</TD>
                            <TD align="right" bold>{c.views.toLocaleString()}</TD>
                            <TD align="right" color={N.green}>{c.saves.toLocaleString()}</TD>
                            <TD align="right">{c.views > 0 ? `${(c.saves / c.views * 100).toFixed(1)}%` : '—'}</TD>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </>
              )}
            </motion.div>
          ) : null}
        </div>
      )}

      {/* ═══ REPORTS TAB ═══ */}
      {tab === 'reports' && (
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
          <div className="p-6 mb-6" style={{ backgroundColor: N.surface, border: `1px solid ${N.border}`, borderRadius: '12px' }}>
            <h2 className="text-sm font-semibold mb-1" style={{ color: N.text }}>Generate Client Report</h2>
            <p className="text-xs mb-5" style={{ color: N.textMuted }}>
              Create shareable performance reports for venues, event contributors, or a full platform overview. Reports include reach metrics, save rates, and event-level breakdowns.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-5">
              {([
                { key: 'platform', label: 'Platform Report', desc: 'Full CULTIVE metrics', icon: Globe },
                { key: 'venue', label: 'Venue Report', desc: 'Performance for a specific venue', icon: Building2 },
                { key: 'contributor', label: 'Contributor Report', desc: 'Reach for an event contributor', icon: UserCircle2 },
              ] as const).map(rt => (
                <button
                  key={rt.key}
                  onClick={() => { setReportType(rt.key); setReport(null); }}
                  className="p-4 text-left cursor-pointer transition-all hover:opacity-80"
                  style={{
                    backgroundColor: reportType === rt.key ? `${N.blue}08` : 'transparent',
                    border: `1.5px solid ${reportType === rt.key ? N.blue : N.border}`,
                    borderRadius: '10px',
                  }}
                >
                  <rt.icon size={18} style={{ color: reportType === rt.key ? N.blue : N.textMuted, marginBottom: 8 }} />
                  <p className="text-sm font-semibold" style={{ color: N.text }}>{rt.label}</p>
                  <p className="text-[11px] mt-0.5" style={{ color: N.textMuted }}>{rt.desc}</p>
                </button>
              ))}
            </div>

            {reportType !== 'platform' && (
              <div className="mb-5">
                <label className="block text-[11px] font-semibold uppercase tracking-wider mb-1.5" style={{ color: N.textMuted }}>
                  {reportType === 'venue' ? 'Venue Name' : 'Contributor Name'}
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={reportTarget}
                    onChange={e => setReportTarget(e.target.value)}
                    placeholder={reportType === 'venue' ? 'e.g. Oma, Terrible Baby, Eaton HK…' : 'e.g. John Doe…'}
                    className="w-full px-3.5 py-2.5 text-sm outline-none"
                    style={{ backgroundColor: N.pageBg, border: `1px solid ${N.border}`, borderRadius: '8px', color: N.text }}
                  />
                  {/* Autocomplete from loaded data */}
                  {data && reportTarget.length >= 2 && (
                    <AutoSuggest
                      items={reportType === 'venue'
                        ? data.venueBreakdown.map(v => v.name)
                        : data.contributorBreakdown.map(c => c.name)
                      }
                      query={reportTarget}
                      onSelect={v => setReportTarget(v)}
                    />
                  )}
                </div>
              </div>
            )}

            <button
              onClick={generateReport}
              disabled={reportLoading || (reportType !== 'platform' && !reportTarget.trim())}
              className="flex items-center gap-2 px-5 py-2.5 text-sm font-semibold cursor-pointer hover:opacity-80 transition-opacity disabled:opacity-40"
              style={{ backgroundColor: N.accent, color: '#fff', borderRadius: '8px' }}
            >
              {reportLoading ? <Loader2 size={14} className="animate-spin" /> : <FileText size={14} />}
              Generate Report
            </button>
          </div>

          {/* Generated Report */}
          <AnimatePresence>
            {report && (
              <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                {/* Export toolbar */}
                <div className="flex items-center gap-2 mb-4">
                  <button onClick={handlePrint} className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium cursor-pointer hover:opacity-80 transition-opacity" style={{ backgroundColor: N.surface, border: `1px solid ${N.border}`, borderRadius: '6px', color: N.text }}>
                    <Printer size={12} /> Print / PDF
                  </button>
                  <button onClick={downloadCSV} className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium cursor-pointer hover:opacity-80 transition-opacity" style={{ backgroundColor: N.surface, border: `1px solid ${N.border}`, borderRadius: '6px', color: N.text }}>
                    <Download size={12} /> Export CSV
                  </button>
                  <button onClick={copyJSON} className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium cursor-pointer hover:opacity-80 transition-opacity" style={{ backgroundColor: N.surface, border: `1px solid ${N.border}`, borderRadius: '6px', color: N.text }}>
                    {copied ? <CheckCircle2 size={12} style={{ color: N.green }} /> : <Copy size={12} />}
                    {copied ? 'Copied!' : 'Copy JSON'}
                  </button>
                </div>

                {/* Printable report body */}
                <div ref={reportRef} className="p-8" style={{ backgroundColor: N.surface, border: `1px solid ${N.border}`, borderRadius: '12px' }}>
                  {/* Report Header */}
                  <div className="header" style={{ borderBottom: `2px solid ${N.text}`, paddingBottom: 16, marginBottom: 32 }}>
                    <div className="flex items-center justify-between">
                      <div>
                        <h1 className="text-2xl font-bold" style={{ color: N.text, letterSpacing: '-0.02em' }}>
                          CULTIVE 文化活
                        </h1>
                        <p className="text-xs mt-0.5" style={{ color: N.textMuted }}>Performance Report</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-semibold" style={{ color: N.text }}>{report.targetName}</p>
                        <p className="text-[10px]" style={{ color: N.textMuted }}>
                          Generated {new Date(report.generatedAt).toLocaleDateString('en-HK', { year: 'numeric', month: 'long', day: 'numeric' })}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Summary KPIs */}
                  <div className="grid grid-cols-3 sm:grid-cols-6 gap-3 mb-8">
                    <ReportKPI label="Events" value={report.summary.totalEvents} />
                    <ReportKPI label="Total Views" value={report.summary.totalViews} />
                    <ReportKPI label="Total Saves" value={report.summary.totalSaves} />
                    <ReportKPI label="Avg Views" value={report.summary.avgViews} />
                    <ReportKPI label="Avg Saves" value={report.summary.avgSaves} />
                    <ReportKPI label="Save Rate" value={`${report.summary.conversionRate}%`} highlight />
                  </div>

                  {/* Top Events Table */}
                  {report.topEvents.length > 0 && (
                    <div className="mb-8">
                      <p className="text-xs font-semibold uppercase tracking-wider mb-3" style={{ color: N.textMuted }}>Top Performing Events</p>
                      <table className="w-full" style={{ borderCollapse: 'collapse' }}>
                        <thead>
                          <tr>
                            <th className="text-left text-[10px] font-semibold uppercase tracking-wider px-3 py-2" style={{ color: N.textMuted, borderBottom: `1px solid ${N.border}` }}>#</th>
                            <th className="text-left text-[10px] font-semibold uppercase tracking-wider px-3 py-2" style={{ color: N.textMuted, borderBottom: `1px solid ${N.border}` }}>Event</th>
                            <th className="text-right text-[10px] font-semibold uppercase tracking-wider px-3 py-2" style={{ color: N.textMuted, borderBottom: `1px solid ${N.border}` }}>Views</th>
                            <th className="text-right text-[10px] font-semibold uppercase tracking-wider px-3 py-2" style={{ color: N.textMuted, borderBottom: `1px solid ${N.border}` }}>Saves</th>
                            <th className="text-right text-[10px] font-semibold uppercase tracking-wider px-3 py-2" style={{ color: N.textMuted, borderBottom: `1px solid ${N.border}` }}>Rate</th>
                            <th className="text-left text-[10px] font-semibold uppercase tracking-wider px-3 py-2" style={{ color: N.textMuted, borderBottom: `1px solid ${N.border}` }}>Date</th>
                          </tr>
                        </thead>
                        <tbody>
                          {report.topEvents.map((e: any, i: number) => (
                            <tr key={e.id} style={{ backgroundColor: i % 2 === 0 ? 'transparent' : 'rgba(0,0,0,0.015)' }}>
                              <td className="px-3 py-2 text-xs" style={{ color: N.textMuted }}>{i + 1}</td>
                              <td className="px-3 py-2 text-sm font-medium" style={{ color: N.text }}>{e.title}</td>
                              <td className="px-3 py-2 text-sm text-right font-semibold" style={{ color: N.text }}>{e.views.toLocaleString()}</td>
                              <td className="px-3 py-2 text-sm text-right" style={{ color: N.green }}>{e.saves.toLocaleString()}</td>
                              <td className="px-3 py-2 text-xs text-right" style={{ color: N.textMuted }}>{e.views > 0 ? `${(e.saves / e.views * 100).toFixed(1)}%` : '—'}</td>
                              <td className="px-3 py-2 text-xs" style={{ color: N.textMuted }}>{e.date || '—'}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}

                  {/* Full Event List */}
                  {report.allEvents.length > report.topEvents.length && (
                    <ExpandableSection title={`All Events (${report.allEvents.length})`}>
                      <table className="w-full" style={{ borderCollapse: 'collapse' }}>
                        <thead>
                          <tr>
                            <th className="text-left text-[10px] font-semibold uppercase tracking-wider px-3 py-2" style={{ color: N.textMuted, borderBottom: `1px solid ${N.border}` }}>Event</th>
                            <th className="text-right text-[10px] font-semibold uppercase tracking-wider px-3 py-2" style={{ color: N.textMuted, borderBottom: `1px solid ${N.border}` }}>Views</th>
                            <th className="text-right text-[10px] font-semibold uppercase tracking-wider px-3 py-2" style={{ color: N.textMuted, borderBottom: `1px solid ${N.border}` }}>Saves</th>
                            <th className="text-left text-[10px] font-semibold uppercase tracking-wider px-3 py-2" style={{ color: N.textMuted, borderBottom: `1px solid ${N.border}` }}>Category</th>
                          </tr>
                        </thead>
                        <tbody>
                          {report.allEvents.map((e: any, i: number) => (
                            <tr key={e.id} style={{ backgroundColor: i % 2 === 0 ? 'transparent' : 'rgba(0,0,0,0.015)' }}>
                              <td className="px-3 py-1.5 text-xs" style={{ color: N.text }}>{e.title}</td>
                              <td className="px-3 py-1.5 text-xs text-right font-medium" style={{ color: N.text }}>{e.views}</td>
                              <td className="px-3 py-1.5 text-xs text-right" style={{ color: N.green }}>{e.saves}</td>
                              <td className="px-3 py-1.5 text-[11px]" style={{ color: N.textMuted }}>{e.category || '—'}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </ExpandableSection>
                  )}

                  {/* Footer */}
                  <div className="footer" style={{ marginTop: 40, paddingTop: 16, borderTop: `1px solid ${N.border}` }}>
                    <p className="text-[10px]" style={{ color: N.textMuted }}>
                      CULTIVE 文化活 — Cultural Events Discovery Platform for Hong Kong · Generated via CULTIVE Admin · {new Date(report.generatedAt).toISOString()}
                    </p>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      )}
    </div>
  );
}

// ─── Sub-components ──────────────────────────────────────────────────────────

function KPICard({ icon: Icon, label, value, color, bg, sub }: { icon: any; label: string; value: string; color: string; bg: string; sub?: string }) {
  return (
    <div className="p-4" style={{ backgroundColor: bg, border: `1px solid ${N.border}`, borderRadius: '10px' }}>
      <Icon size={16} style={{ color, marginBottom: 8 }} />
      <p className="text-2xl font-bold" style={{ color: N.text }}>{value}</p>
      <p className="text-[10px] font-semibold uppercase tracking-wider mt-1" style={{ color: N.textMuted }}>{label}</p>
      {sub && <p className="text-[10px] mt-0.5" style={{ color: N.textMuted }}>{sub}</p>}
    </div>
  );
}

function RankTable({ title, icon: Icon, rows, metricKey, metricLabel }: { title: string; icon: any; rows: any[]; metricKey: string; metricLabel: string }) {
  return (
    <div style={{ backgroundColor: N.surface, border: `1px solid ${N.border}`, borderRadius: '10px' }}>
      <div className="flex items-center gap-2 px-4 py-3" style={{ borderBottom: `1px solid ${N.border}` }}>
        <Icon size={14} style={{ color: N.textMuted }} />
        <p className="text-xs font-semibold uppercase tracking-wider" style={{ color: N.textMuted }}>{title}</p>
      </div>
      <div className="max-h-[400px] overflow-y-auto">
        {rows.slice(0, 15).map((r, i) => (
          <div key={r.id} className="flex items-center gap-3 px-4 py-2.5" style={{ borderBottom: i < rows.length - 1 ? `1px solid ${N.border}` : undefined }}>
            <span className="text-[10px] font-bold w-5 text-center" style={{ color: N.textMuted }}>{i + 1}</span>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate" style={{ color: N.text }}>{r.title}</p>
              <div className="flex items-center gap-2 mt-0.5">
                {r.category && <span className="text-[10px]" style={{ color: N.textMuted }}>{r.category}</span>}
                {r.date && <span className="text-[10px]" style={{ color: N.textMuted }}>{r.date}</span>}
              </div>
            </div>
            <span className="text-sm font-bold" style={{ color: N.text }}>{(r[metricKey] || 0).toLocaleString()}</span>
            <span className="text-[10px]" style={{ color: N.textMuted }}>{metricLabel}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function ReportKPI({ label, value, highlight }: { label: string; value: string | number; highlight?: boolean }) {
  return (
    <div className="p-3 text-center" style={{ backgroundColor: highlight ? N.blueBg : 'transparent', border: `1px solid ${N.border}`, borderRadius: '8px' }}>
      <p className="text-lg font-bold" style={{ color: highlight ? N.blue : N.text }}>{typeof value === 'number' ? value.toLocaleString() : value}</p>
      <p className="text-[9px] font-semibold uppercase tracking-wider mt-0.5" style={{ color: N.textMuted }}>{label}</p>
    </div>
  );
}

function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <p className="text-[11px] font-semibold uppercase tracking-wider mb-3" style={{ color: N.textMuted }}>{children}</p>
  );
}

function TH({ children, align }: { children: React.ReactNode; align?: 'right' | 'left' }) {
  return (
    <th className={`text-[10px] font-semibold uppercase tracking-wider px-3 py-2.5 ${align === 'right' ? 'text-right' : 'text-left'}`} style={{ color: N.textMuted, borderBottom: `1px solid ${N.border}` }}>
      {children}
    </th>
  );
}

function TD({ children, align, bold, color }: { children: React.ReactNode; align?: 'right'; bold?: boolean; color?: string }) {
  return (
    <td className={`px-3 py-2.5 text-sm ${align === 'right' ? 'text-right' : ''}`} style={{ color: color || N.text, fontWeight: bold ? 600 : 400, borderBottom: `1px solid ${N.border}` }}>
      {children}
    </td>
  );
}

function ExpandableSection({ title, children }: { title: string; children: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  return (
    <div>
      <button onClick={() => setOpen(!open)} className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider cursor-pointer hover:opacity-80 transition-opacity mb-2" style={{ color: N.textMuted }}>
        {open ? <ChevronUp size={12} /> : <ChevronDown size={12} />} {title}
      </button>
      {open && children}
    </div>
  );
}

function AutoSuggest({ items, query, onSelect }: { items: string[]; query: string; onSelect: (v: string) => void }) {
  const q = query.toLowerCase();
  const matches = items.filter(i => i.toLowerCase().includes(q)).slice(0, 8);
  if (matches.length === 0 || matches.some(m => m.toLowerCase() === q)) return null;
  return (
    <div className="absolute z-50 left-0 right-0 top-full mt-1 overflow-hidden" style={{ backgroundColor: N.surface, border: `1px solid ${N.border}`, borderRadius: '8px', boxShadow: '0 8px 24px rgba(0,0,0,0.1)' }}>
      {matches.map(m => (
        <button key={m} onClick={() => onSelect(m)} className="w-full text-left px-3 py-2 text-sm cursor-pointer hover:bg-black/[0.03] transition-colors" style={{ color: N.text }}>
          {m}
        </button>
      ))}
    </div>
  );
}
