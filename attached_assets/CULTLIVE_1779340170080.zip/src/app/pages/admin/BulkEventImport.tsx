/**
 * BulkEventImport — /admin/events-import
 *
 * 4-step RA JSON import wizard:
 *   1 Paste JSON → 2 Review & Edit → 3 Enrich (CULTIVE fields) → 4 Done
 *
 * + "Previous Imports" history panel with quality scores & per-event delete.
 */

import { useState, useCallback, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  FileJson, Upload, CheckCircle2, AlertCircle, ChevronDown, ChevronUp,
  Trash2, RotateCcw, ArrowRight, ArrowLeft, Download, Tag, MapPin,
  Calendar, Clock, DollarSign, Link, Music, User, Loader2, Sparkles,
  ClipboardPaste, FolderOpen, X, Star, History, Eye, EyeOff,
  LayoutGrid, ListChecks, Zap, CheckSquare, Square,
} from 'lucide-react';
import { useOutletContext } from 'react-router';
import { projectId, publicAnonKey } from '../../config/supabase';
import { fireWebhook } from '../../config/webhooks';

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-d507b98c`;

// ── Design tokens ──────────────────────────────────────────────────────────
const N = {
  pageBg:    '#FAFAF8',
  surface:   '#FFFFFF',
  surface2:  '#F4F4F0',
  surface3:  '#EEECEA',
  dark:      '#1A1A1A',
  text:      '#1A1A1A',
  textMuted: '#6B7280',
  border:    'rgba(0,0,0,0.08)',
  borderMid: 'rgba(0,0,0,0.14)',
  green:     '#16A34A',
  greenBg:   'rgba(22,163,74,0.08)',
  orange:    '#EA580C',
  orangeBg:  'rgba(234,88,12,0.07)',
  red:       '#DC2626',
  redBg:     'rgba(220,38,38,0.07)',
  blue:      '#2563EB',
  blueBg:    'rgba(37,99,235,0.07)',
  purple:    '#7C3AED',
  purpleBg:  'rgba(124,58,237,0.07)',
  font:      "'Inter', 'Noto Sans HK', system-ui, sans-serif",
};

// ── CULTIVE-specific constants ────────────────────────────────────────────
const CULTIVE_CATEGORIES = [
  'nightlife', 'music', 'art', 'exhibition', 'food', 'wellness',
  'workshop', 'family', 'sports', 'festival', 'film', 'theatre', 'other',
];

const CULTIVE_MODES = [
  { id: 'degen',     label: 'Night',     color: '#D600FF' },
  { id: 'artsy',     label: 'Art',       color: '#8338EC' },
  { id: 'foodie',    label: 'Food',      color: '#2563EB' },
  { id: 'family',    label: 'Family',    color: '#FF8C42' },
  { id: 'lifestyle', label: 'Lifestyle', color: '#2D6A4F' },
];

const VIBE_OPTIONS = [
  'underground', 'rooftop', 'intimate', 'free-entry', 'weekend-vibe',
  'late-night', 'all-ages', 'lgbtq+', 'outdoor', 'members-only',
];

// ── Types ─────────────────────────────────────────────────────────────────
interface ParsedEvent {
  id: string;
  title: string;
  date: string;
  time: string;
  venueName: string;
  venueId: string;
  address: string;
  district: string;
  description: string;
  image: string;
  price: string;
  ticketUrl: string;
  artists: string[];
  genres: string[];
  // CULTIVE-specific
  modeTags: string[];
  modes: string[];
  vibes: string[];
  category: string;
  status: 'upcoming' | 'ongoing' | 'past';
  featured: boolean;
  // RA metadata
  raId: string;
  lat?: number;
  lng?: number;
  minimumAge?: number;
  selected: boolean;
  _raw?: unknown;
}

interface ImportBatch {
  id: string;
  timestamp: string;
  created: number;
  updated: number;
  invalid: number;
  skipped: number; // legacy field — kept for backwards compat
  total: number;
  eventIds: string[];
  avgQuality: number;
  label?: string;
}

// ── Quality score for an event (0-100) ───────────────────────────────────
function getQuality(ev: ParsedEvent): number {
  const checks = [
    !!ev.title,
    !!ev.image,
    typeof ev.description === 'string' && ev.description.length > 30,
    !!ev.date,
    !!ev.time,
    !!(ev.venueName || ev.venueId),
    !!ev.price && ev.price !== 'Check event page',
    !!(ev.lat && ev.lng),
    (ev.modeTags?.length > 0 || ev.modes?.length > 0),
    !!ev.category,
    ev.artists?.length > 0,
  ];
  return Math.round((checks.filter(Boolean).length / checks.length) * 100);
}

function getMissingFields(ev: ParsedEvent): string[] {
  const m: string[] = [];
  if (!ev.image)                                  m.push('image');
  if (!ev.description || ev.description.length < 30) m.push('description');
  if (!ev.date)                                   m.push('date');
  if (!ev.time)                                   m.push('time');
  if (!ev.venueName && !ev.venueId)               m.push('venue');
  if (!ev.price || ev.price === 'Check event page') m.push('price');
  if (!ev.lat || !ev.lng)                         m.push('GPS');
  if (!ev.modeTags?.length && !ev.modes?.length)  m.push('modes');
  if (!ev.category)                               m.push('category');
  if (!ev.artists?.length)                        m.push('artists');
  return m;
}

// ── HK district inference ──────────────────────────────────────────────
const DISTRICT_KEYWORDS: [string, string][] = [
  ['Central', 'Central'], ['Admiralty', 'Admiralty'], ['Wan Chai', 'Wan Chai'],
  ['Wanchai', 'Wan Chai'], ['Causeway Bay', 'Causeway Bay'], ['North Point', 'North Point'],
  ['Sheung Wan', 'Sheung Wan'], ['Sai Ying Pun', 'Sai Ying Pun'],
  ['Kennedy Town', 'Kennedy Town'], ['Tai Hang', 'Tai Hang'],
  ['Happy Valley', 'Happy Valley'], ['Tsim Sha Tsui', 'Tsim Sha Tsui'],
  ['TST', 'Tsim Sha Tsui'], ['Yau Ma Tei', 'Yau Ma Tei'], ['Mong Kok', 'Mong Kok'],
  ['Sham Shui Po', 'Sham Shui Po'], ['Kowloon', 'Kowloon City'],
  ['Quarry Bay', 'Quarry Bay'], ['Wong Chuk Hang', 'Wong Chuk Hang'],
  ['Aberdeen', 'Aberdeen'], ['Stanley', 'Stanley'], ['Sai Kung', 'Sai Kung'],
];
function inferDistrict(text: string): string {
  const h = text.toLowerCase();
  for (const [kw, label] of DISTRICT_KEYWORDS)
    if (h.includes(kw.toLowerCase())) return label;
  return 'Hong Kong';
}

function inferModes(genres: string[], title: string): string[] {
  const all = [...genres, title].join(' ');
  const m: string[] = [];
  if (/techno|house|rave|club|dj|electronic|dance|bass|drum|party|nightlife/i.test(all)) m.push('degen');
  if (/jazz|blues|soul|folk|classical|live music|acoustic/i.test(all)) m.push('lifestyle');
  if (/art|gallery|exhibition|design|photo|film|cinema|theatre|cultural/i.test(all)) m.push('artsy');
  if (/food|dining|dinner|brunch|tasting|culinary|chef/i.test(all)) m.push('foodie');
  if (/family|kids|children|outdoor|nature|hike|wellness|yoga/i.test(all)) m.push('family');
  return m.length ? m : ['lifestyle'];
}

function inferCategory(genres: string[], title: string, modes: string[]): string {
  const all = [...genres, title].join(' ').toLowerCase();
  if (/techno|house|rave|club|dj|electronic|dance/i.test(all)) return 'nightlife';
  if (/art|gallery|exhibition/i.test(all)) return 'exhibition';
  if (/food|dining|tasting|culinary/i.test(all)) return 'food';
  if (/film|cinema/i.test(all)) return 'film';
  if (/theatre|theater/i.test(all)) return 'theatre';
  if (/workshop|class|learn/i.test(all)) return 'workshop';
  if (/wellness|yoga|meditation/i.test(all)) return 'wellness';
  if (/family|kids|children/i.test(all)) return 'family';
  if (modes.includes('degen')) return 'nightlife';
  if (modes.includes('artsy')) return 'art';
  if (modes.includes('foodie')) return 'food';
  return 'music';
}

function slug(str: string): string {
  return str.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
}

function parseDateTime(raw: string | undefined): { date: string; time: string } {
  if (!raw) return { date: '', time: '' };
  try {
    const d = new Date(raw);
    if (isNaN(d.getTime())) return { date: raw.slice(0, 10), time: '' };
    const date = d.toISOString().slice(0, 10);
    const hkt = new Date(d.getTime() + 8 * 60 * 60 * 1000);
    const h = String(hkt.getUTCHours()).padStart(2, '0');
    const m = String(hkt.getUTCMinutes()).padStart(2, '0');
    const time = h === '00' && m === '00' ? '' : `${h}:${m}`;
    return { date, time };
  } catch { return { date: raw.slice(0, 10), time: '' }; }
}

const USD_TO_HKD = 7.8;
function usdToHkd(usd: number): number { return Math.round(usd * USD_TO_HKD / 10) * 10; }

function parseCostToHKD(costStr: string, ticketPriceUSD?: number): string {
  const cleaned = costStr.trim();
  if (cleaned) {
    const nums = cleaned.match(/\d+(\.\d+)?/g);
    if (nums && nums.length > 0) {
      const values = nums.map(Number);
      const needsConvert = values.every(v => v < 150);
      if (needsConvert) return values.map(v => `HK$${usdToHkd(v)}`).join(' / ');
      return values.map(v => `HK$${Math.round(v)}`).join(' / ');
    }
    return cleaned;
  }
  if (ticketPriceUSD && ticketPriceUSD > 0) return `HK$${usdToHkd(ticketPriceUSD)} (advance)`;
  return 'Check event page';
}

// ── JSON parser (all RA formats) ──────────────────────────────────────────
function parseRAJson(raw: unknown): { events: ParsedEvent[]; warnings: string[] } {
  const warnings: string[] = [];
  let arr: unknown[] = [];
  if (Array.isArray(raw)) arr = raw;
  else if (raw && typeof raw === 'object') {
    const o = raw as Record<string, unknown>;
    if (Array.isArray(o.listings)) arr = o.listings;
    else if (Array.isArray(o.events)) arr = o.events;
    else if (Array.isArray(o.data)) arr = o.data;
    else if (Array.isArray(o.results)) arr = o.results;
    else arr = [raw];
  }
  if (arr.length === 0) { warnings.push('No event items found.'); return { events: [], warnings }; }

  const events: ParsedEvent[] = [];
  arr.forEach((item, idx) => {
    if (!item || typeof item !== 'object') return;
    const ev = item as Record<string, unknown>;
    const isRaScraper = 'start_time' in ev || 'flyer_image' in ev;
    const isCultive   = 'venueId' in ev && 'modeTags' in ev;
    const isListing   = 'event' in ev && typeof ev.event === 'object';
    const isFlatRA    = !isRaScraper && !isCultive && !isListing && ('startTime' in ev || 'contentUrl' in ev || 'interestedCount' in ev);

    let title = '', dateRaw = '', venueName = '', address = '', description = '',
        image = '', price = '', ticketUrl = '', artists: string[] = [],
        genres: string[] = [], raId = '', lat = 0, lng = 0, minAge: number | undefined;

    if (isCultive) {
      const { date, time } = parseDateTime(ev.date as string);
      const modes = Array.isArray(ev.modeTags) ? ev.modeTags.map(String) : Array.isArray(ev.modes) ? ev.modes.map(String) : [];
      const category = String(ev.category || inferCategory([], String(ev.title || ''), modes));
      events.push({
        id: String(ev.id || `cultive_${idx}`), title: String(ev.title || ''),
        date, time, venueName: String(ev.venueName || ''), venueId: String(ev.venueId || ''),
        address: String(ev.address || ''), district: String(ev.district || inferDistrict(String(ev.address || ''))),
        description: String(ev.description || ''), image: String(ev.image || ''),
        price: String(ev.price || ''), ticketUrl: String(ev.ticketUrl || ''),
        artists: Array.isArray(ev.artists) ? ev.artists.map(String) : [],
        genres: Array.isArray(ev.genres) ? ev.genres.map(String) : [],
        modeTags: modes, modes, vibes: Array.isArray(ev.vibes) ? ev.vibes.map(String) : [],
        category, status: 'upcoming', featured: false,
        raId: String(ev.raId || ev.id || ''), selected: true, _raw: item,
      });
      return;
    }

    if (isFlatRA || isRaScraper || isListing) {
      let inner = ev;
      let venueO: Record<string, unknown> = {};

      if (isListing) {
        inner = ev.event as Record<string, unknown>;
        venueO = ((ev.venue || inner.venue || {}) as Record<string, unknown>);
      } else if (isFlatRA || isRaScraper) {
        venueO = ((ev.venue || {}) as Record<string, unknown>);
      }

      title = String(inner.title || ev.title || inner.name || '');
      dateRaw = String(inner.startTime || inner.start_time || inner.date || ev.startTime || ev.start_time || ev.date || '');
      venueName = String(venueO.name || inner.venueName || ev.venue || ev.venue_name || '');
      address = String(venueO.address || inner.address || ev.venue_address || ev.address || '');
      description = String(inner.content || inner.description || ev.content || ev.description || '')
        .replace(/<[^>]*>/g, '').trim();

      // Image: prefer FLYERFRONT
      const imgArr = Array.isArray(inner.images || ev.images)
        ? ((inner.images || ev.images) as Record<string, unknown>[]) : [];
      const frontImg = imgArr.find(i => i.type === 'FLYERFRONT') || imgArr[0];
      image = frontImg ? String(frontImg.filename || '') : String(inner.flyer_image || ev.flyer_image || inner.flyer || '');
      if (image && !image.startsWith('http')) image = `https://static.ra.co/images/events/flyer/${image}`;

      // Price: tickets array → USD→HKD, then cost string
      const ticketArr = Array.isArray(inner.tickets || ev.tickets)
        ? ((inner.tickets || ev.tickets) as Record<string, unknown>[]) : [];
      const usdTicket = ticketArr.find(t => String((t.currency as any)?.code) === 'USD') || ticketArr[0];
      const ticketUSD = usdTicket && String((usdTicket.currency as any)?.code) === 'USD'
        ? Number(usdTicket.priceRetail) : undefined;
      price = parseCostToHKD(String(inner.cost || ev.cost || ''), ticketUSD);

      // Ticket URL
      const promoLinks = Array.isArray(inner.promotionalLinks || ev.promotionalLinks)
        ? ((inner.promotionalLinks || ev.promotionalLinks) as Record<string, unknown>[]) : [];
      const bestPromo = promoLinks.find(l => /ticket|ra\.co|plvr|circle/i.test(String(l.url || ''))) || promoLinks[0];
      ticketUrl = bestPromo ? String(bestPromo.url || '')
        : inner.contentUrl ? `https://ra.co${inner.contentUrl}`
        : ev.contentUrl ? `https://ra.co${ev.contentUrl}` : '';

      // Artists
      const artistsArr = Array.isArray(inner.artists || ev.artists)
        ? ((inner.artists || ev.artists) as Record<string, unknown>[]) : [];
      artists = artistsArr.map(a => String(a.name || a));

      // Genres
      const genresArr = Array.isArray(inner.genres || ev.genres)
        ? ((inner.genres || ev.genres) as Record<string, unknown>[]) : [];
      genres = genresArr.map(g => String(g.name || g));

      // GPS
      const locO = (venueO.location || {}) as Record<string, unknown>;
      lat = Number(locO.latitude || locO.lat || 0);
      lng = Number(locO.longitude || locO.lng || 0);

      minAge = inner.minimumAge ? Number(inner.minimumAge) : ev.minimumAge ? Number(ev.minimumAge) : undefined;
      raId = String(inner.id || ev.id || `json_${idx}`);
    } else {
      // generic best-effort
      title   = String(ev.title || ev.name || ev.eventName || '');
      dateRaw = String(ev.date || ev.startDate || ev.start_time || ev.startTime || '');
      venueName = String(ev.venue || ev.venueName || ev.venue_name || ev.location || '');
      address   = String(ev.address || ev.venue_address || '');
      description = String(ev.description || ev.about || ev.content || '');
      image     = String(ev.image || ev.flyer || ev.cover || '');
      price     = parseCostToHKD(String(ev.price || ev.cost || ev.ticket_price || ''));
      ticketUrl = String(ev.url || ev.ticket_url || ev.ticketUrl || ev.link || '');
      raId      = String(ev.id || ev.ra_id || `json_${idx}`);
    }

    if (!title) { warnings.push(`Item #${idx + 1} has no title — skipped.`); return; }

    const { date, time } = parseDateTime(dateRaw);
    const district = inferDistrict(`${venueName} ${address}`);
    const modes    = inferModes(genres, title);
    const category = inferCategory(genres, title, modes);
    const id       = `ra_${slug(title)}_${raId}`.slice(0, 60);

    events.push({
      id, title, date, time, venueName, venueId: '', address, district,
      description, image, price, ticketUrl, artists, genres,
      modeTags: modes, modes, vibes: [],
      category, status: 'upcoming', featured: false,
      source: 'ra', _source: 'ra',
      raId, ...(lat && lng ? { lat, lng } : {}),
      minimumAge: minAge, selected: true, _raw: item,
    });
  });

  if (events.length === 0) warnings.push('Parser produced 0 events. Check the JSON structure.');
  return { events, warnings };
}

// ── Quality Bar ──────────────────────────────────────────────────────────
function QualityBar({ value, size = 'md' }: { value: number; size?: 'sm' | 'md' }) {
  const color = value >= 80 ? N.green : value >= 55 ? N.orange : N.red;
  return (
    <div className={`flex items-center gap-${size === 'sm' ? '1.5' : '2'}`}>
      <div className={`flex-1 h-${size === 'sm' ? '1' : '1.5'} rounded-full overflow-hidden`}
           style={{ background: N.border }}>
        <div className="h-full rounded-full transition-all" style={{ width: `${value}%`, background: color }} />
      </div>
      <span className="text-[11px] font-semibold tabular-nums" style={{ color, minWidth: 28 }}>{value}%</span>
    </div>
  );
}

function MissingChips({ fields }: { fields: string[] }) {
  if (fields.length === 0) return <span className="text-[10px] font-medium" style={{ color: N.green }}>All fields complete</span>;
  return (
    <div className="flex flex-wrap gap-1">
      {fields.slice(0, 5).map(f => (
        <span key={f} className="px-1.5 py-0.5 text-[10px] rounded" style={{ background: N.orangeBg, color: N.orange }}>{f}</span>
      ))}
      {fields.length > 5 && <span className="px-1.5 py-0.5 text-[10px] rounded" style={{ background: N.border, color: N.textMuted }}>+{fields.length - 5}</span>}
    </div>
  );
}

// ── Steps indicator (4 steps) ────────────────────────────────────────────
function Steps({ step }: { step: number }) {
  const labels = ['Paste JSON', 'Review', 'Enrich', 'Done'];
  return (
    <div className="flex items-center gap-0 mb-8">
      {labels.map((label, i) => {
        const n = i + 1;
        const done = step > n; const active = step === n;
        return (
          <div key={n} className="flex items-center flex-1 gap-0">
            <div className="flex items-center gap-2 flex-shrink-0">
              <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 transition-all"
                style={{ background: done ? N.green : active ? N.dark : 'transparent', color: done || active ? '#fff' : N.textMuted, border: done || active ? 'none' : `1.5px solid ${N.borderMid}` }}>
                {done ? <CheckCircle2 size={14} /> : n}
              </div>
              <span className="text-xs font-medium whitespace-nowrap hidden sm:inline"
                style={{ color: active ? N.dark : done ? N.green : N.textMuted }}>{label}</span>
            </div>
            {i < labels.length - 1 && <div className="flex-1 h-px mx-2 sm:mx-3" style={{ background: step > n ? N.green : N.border }} />}
          </div>
        );
      })}
    </div>
  );
}

// ── Step 2: Editable event card ───────────────────────────────────────────
function EventCard({ ev, idx, onChange, onRemove }: {
  ev: ParsedEvent; idx: number;
  onChange: (idx: number, patch: Partial<ParsedEvent>) => void;
  onRemove: (idx: number) => void;
}) {
  const [open, setOpen] = useState(false);
  const quality = getQuality(ev);
  const missing = getMissingFields(ev);

  const field = (key: keyof ParsedEvent, label: string, icon: React.ReactNode, type: 'text'|'date'|'time'|'url'|'textarea' = 'text') => (
    <div className="flex flex-col gap-1">
      <label className="flex items-center gap-1.5 text-xs font-medium" style={{ color: N.textMuted }}>{icon}{label}</label>
      {type === 'textarea' ? (
        <textarea rows={3} className="w-full rounded-lg px-3 py-2 text-sm resize-none outline-none"
          style={{ background: N.surface2, border: `1px solid ${N.border}`, color: N.text, fontFamily: N.font }}
          value={String(ev[key] || '')} onChange={e => onChange(idx, { [key]: e.target.value } as any)} />
      ) : (
        <input type={type} className="w-full rounded-lg px-3 py-2 text-sm outline-none"
          style={{ background: N.surface2, border: `1px solid ${N.border}`, color: N.text, fontFamily: N.font }}
          value={String(ev[key] || '')} onChange={e => onChange(idx, { [key]: e.target.value } as any)} />
      )}
    </div>
  );

  return (
    <motion.div layout initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
      className="rounded-xl overflow-hidden"
      style={{ border: `1px solid ${ev.selected ? N.borderMid : N.border}`, background: ev.selected ? N.surface : N.surface2, opacity: ev.selected ? 1 : 0.55 }}>
      <div className="flex items-start gap-3 p-4">
        <button onClick={() => onChange(idx, { selected: !ev.selected })}
          className="flex-shrink-0 mt-0.5 w-5 h-5 rounded flex items-center justify-center transition-colors"
          style={{ background: ev.selected ? N.dark : 'transparent', border: `2px solid ${ev.selected ? N.dark : N.borderMid}` }}>
          {ev.selected && <CheckCircle2 size={12} color="#fff" />}
        </button>
        {ev.image && (
          <div className="flex-shrink-0 w-14 h-14 rounded-lg overflow-hidden" style={{ background: N.surface2 }}>
            <img src={ev.image} alt={ev.title} className="w-full h-full object-cover"
              onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }} />
          </div>
        )}
        <div className="flex-1 min-w-0">
          <p className="font-semibold text-sm leading-tight truncate" style={{ color: N.text }}>{ev.title}</p>
          <div className="flex flex-wrap gap-x-3 gap-y-0.5 mt-1">
            {ev.date && <span className="text-xs flex items-center gap-1" style={{ color: N.textMuted }}><Calendar size={11} />{ev.date}{ev.time && ` · ${ev.time}`}</span>}
            {ev.venueName && <span className="text-xs flex items-center gap-1 truncate max-w-[180px]" style={{ color: N.textMuted }}><MapPin size={11} />{ev.venueName}</span>}
          </div>
          <div className="mt-2"><QualityBar value={quality} size="sm" /></div>
        </div>
        <div className="flex items-center gap-1 flex-shrink-0">
          <button onClick={() => setOpen(o => !o)} className="p-1.5 rounded-lg hover:bg-gray-100 transition">
            {open ? <ChevronUp size={16} style={{ color: N.textMuted }} /> : <ChevronDown size={16} style={{ color: N.textMuted }} />}
          </button>
          <button onClick={() => onRemove(idx)} className="p-1.5 rounded-lg hover:bg-red-50 transition">
            <Trash2 size={15} style={{ color: N.red }} />
          </button>
        </div>
      </div>
      <AnimatePresence initial={false}>
        {open && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.2 }}
            style={{ overflow: 'hidden', borderTop: `1px solid ${N.border}` }}>
            <div className="p-4 grid grid-cols-1 md:grid-cols-2 gap-4">
              {field('title', 'Title', <Music size={12} />)}
              {field('date', 'Date', <Calendar size={12} />, 'date')}
              {field('time', 'Time', <Clock size={12} />, 'time')}
              {field('venueName', 'Venue Name', <MapPin size={12} />)}
              {field('address', 'Address', <MapPin size={12} />)}
              {field('district', 'District', <MapPin size={12} />)}
              {field('price', 'Price (HKD)', <DollarSign size={12} />)}
              {field('ticketUrl', 'Ticket URL', <Link size={12} />, 'url')}
              {field('image', 'Image URL', <FolderOpen size={12} />, 'url')}
              <div className="md:col-span-2">{field('description', 'Description', <Sparkles size={12} />, 'textarea')}</div>
              <div className="md:col-span-2 flex flex-col gap-1">
                <label className="flex items-center gap-1.5 text-xs font-medium" style={{ color: N.textMuted }}><User size={12} />Artists (comma-sep)</label>
                <input type="text" className="w-full rounded-lg px-3 py-2 text-sm outline-none"
                  style={{ background: N.surface2, border: `1px solid ${N.border}`, color: N.text }}
                  value={ev.artists.join(', ')} onChange={e => onChange(idx, { artists: e.target.value.split(',').map(s => s.trim()).filter(Boolean) })} />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

// ── Step 3: Enrich panel ─────────────────────────────────────────────────
function EnrichCard({ ev, idx, onChange }: {
  ev: ParsedEvent; idx: number;
  onChange: (idx: number, patch: Partial<ParsedEvent>) => void;
}) {
  const quality = getQuality(ev);
  const missing = getMissingFields(ev);
  const [open, setOpen] = useState(quality < 70);

  const toggleMode = (modeId: string) => {
    const cur = ev.modeTags || [];
    const next = cur.includes(modeId) ? cur.filter(m => m !== modeId) : [...cur, modeId];
    onChange(idx, { modeTags: next, modes: next });
  };
  const toggleVibe = (v: string) => {
    const cur = ev.vibes || [];
    const next = cur.includes(v) ? cur.filter(x => x !== v) : [...cur, v];
    onChange(idx, { vibes: next });
  };

  return (
    <div className="rounded-xl overflow-hidden" style={{ border: `1px solid ${N.borderMid}`, background: N.surface }}>
      <div className="flex items-center gap-3 p-3 cursor-pointer" onClick={() => setOpen(o => !o)}>
        {ev.image ? (
          <div className="flex-shrink-0 w-10 h-10 rounded-lg overflow-hidden">
            <img src={ev.image} alt="" className="w-full h-full object-cover" onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }} />
          </div>
        ) : <div className="flex-shrink-0 w-10 h-10 rounded-lg" style={{ background: N.surface2 }} />}
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold truncate" style={{ color: N.text }}>{ev.title}</p>
          <div className="flex items-center gap-2 mt-0.5">
            {ev.category && <span className="text-[10px] px-1.5 py-0.5 rounded font-medium" style={{ background: N.surface2, color: N.textMuted }}>{ev.category}</span>}
            {(ev.modeTags || []).map(m => {
              const mc = CULTIVE_MODES.find(x => x.id === m);
              return mc ? <span key={m} className="text-[10px] px-1.5 py-0.5 rounded font-medium" style={{ background: mc.color + '18', color: mc.color }}>{mc.label}</span> : null;
            })}
          </div>
        </div>
        <div className="flex-shrink-0 flex items-center gap-2">
          <div className="w-20"><QualityBar value={quality} size="sm" /></div>
          {open ? <ChevronUp size={15} style={{ color: N.textMuted }} /> : <ChevronDown size={15} style={{ color: N.textMuted }} />}
        </div>
      </div>

      <AnimatePresence initial={false}>
        {open && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.2 }}
            style={{ borderTop: `1px solid ${N.border}`, overflow: 'hidden' }}>
            <div className="p-4 space-y-4">
              {/* Missing chips */}
              {missing.length > 0 && (
                <div className="flex items-start gap-2">
                  <AlertCircle size={13} className="flex-shrink-0 mt-0.5" style={{ color: N.orange }} />
                  <MissingChips fields={missing} />
                </div>
              )}

              {/* Category */}
              <div>
                <p className="text-xs font-semibold mb-2" style={{ color: N.textMuted }}>Category</p>
                <div className="flex flex-wrap gap-1.5">
                  {CULTIVE_CATEGORIES.map(cat => (
                    <button key={cat} onClick={() => onChange(idx, { category: cat })}
                      className="px-2.5 py-1 rounded-lg text-xs font-medium transition-all"
                      style={{ background: ev.category === cat ? N.dark : N.surface2, color: ev.category === cat ? '#fff' : N.textMuted }}>
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              {/* Modes */}
              <div>
                <p className="text-xs font-semibold mb-2" style={{ color: N.textMuted }}>CULTIVE Modes</p>
                <div className="flex flex-wrap gap-2">
                  {CULTIVE_MODES.map(m => {
                    const active = (ev.modeTags || []).includes(m.id);
                    return (
                      <button key={m.id} onClick={() => toggleMode(m.id)}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all"
                        style={{ background: active ? m.color : N.surface2, color: active ? '#fff' : N.textMuted, border: `1.5px solid ${active ? m.color : N.border}` }}>
                        {active ? <CheckCircle2 size={11} /> : <div className="w-2.5 h-2.5 rounded-full" style={{ background: m.color + '60' }} />}
                        {m.label}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Vibes */}
              <div>
                <p className="text-xs font-semibold mb-2" style={{ color: N.textMuted }}>Vibe Tags</p>
                <div className="flex flex-wrap gap-1.5">
                  {VIBE_OPTIONS.map(v => {
                    const active = (ev.vibes || []).includes(v);
                    return (
                      <button key={v} onClick={() => toggleVibe(v)}
                        className="px-2.5 py-1 rounded-lg text-xs font-medium transition-all"
                        style={{ background: active ? N.dark + '12' : N.surface2, color: active ? N.dark : N.textMuted, border: `1px solid ${active ? N.borderMid : N.border}` }}>
                        {v}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Status + Featured row */}
              <div className="flex gap-4 items-center">
                <div>
                  <p className="text-xs font-semibold mb-2" style={{ color: N.textMuted }}>Status</p>
                  <div className="flex gap-1">
                    {(['upcoming', 'ongoing', 'past'] as const).map(s => (
                      <button key={s} onClick={() => onChange(idx, { status: s })}
                        className="px-2.5 py-1 rounded-lg text-xs font-medium transition-all"
                        style={{ background: ev.status === s ? N.dark : N.surface2, color: ev.status === s ? '#fff' : N.textMuted }}>
                        {s}
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <p className="text-xs font-semibold mb-2" style={{ color: N.textMuted }}>Featured</p>
                  <button onClick={() => onChange(idx, { featured: !ev.featured })}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all"
                    style={{ background: ev.featured ? '#FEF08A' : N.surface2, color: ev.featured ? '#854D0E' : N.textMuted, border: `1px solid ${ev.featured ? '#FDE047' : N.border}` }}>
                    <Star size={11} fill={ev.featured ? 'currentColor' : 'none'} /> Featured
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ── Import History ────────────────────────────────────────────────────────
function ImportHistory({ accessToken }: { accessToken: string | null }) {
  const [batches, setBatches] = useState<ImportBatch[]>([]);
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState<string | null>(null);
  const [deleting, setDeleting] = useState<string | null>(null);

  const fetchHistory = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/events/bulk/history`, {
        headers: { Authorization: `Bearer ${publicAnonKey}` },
      });
      const data = await res.json();
      setBatches(data.batches || []);
    } catch (err) {
      console.log('Failed to fetch import history:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchHistory(); }, [fetchHistory]);

  const handleDeleteEvent = async (eventId: string, batchId: string) => {
    setDeleting(eventId);
    try {
      await fetch(`${API_BASE}/events/${encodeURIComponent(eventId)}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${publicAnonKey}`, 'X-Auth-Token': accessToken || '' },
      });
      // Remove from local batch state
      setBatches(bs => bs.map(b => b.id === batchId
        ? { ...b, eventIds: b.eventIds.filter(id => id !== eventId), created: b.created - 1 }
        : b
      ));
    } catch (err) {
      console.log('Delete event error:', err);
    } finally {
      setDeleting(null);
    }
  };

  const qualityColor = (q: number) => q >= 80 ? N.green : q >= 55 ? N.orange : N.red;
  const fmtDate = (ts: string) => {
    try { const d = new Date(ts); return `${d.toLocaleDateString('en-HK', { day: 'numeric', month: 'short', year: 'numeric' })} ${d.toLocaleTimeString('en-HK', { hour: '2-digit', minute: '2-digit' })}`; }
    catch { return ts; }
  };

  return (
    <div className="mt-12 pt-8" style={{ borderTop: `1px solid ${N.border}` }}>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <History size={18} style={{ color: N.textMuted }} />
          <h2 className="text-base font-bold" style={{ color: N.text }}>Previous Imports</h2>
          {batches.length > 0 && (
            <span className="text-xs px-2 py-0.5 rounded-full font-medium" style={{ background: N.surface2, color: N.textMuted }}>
              {batches.length} batch{batches.length !== 1 ? 'es' : ''}
            </span>
          )}
        </div>
        <button onClick={fetchHistory} className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg transition"
          style={{ background: N.surface2, color: N.textMuted }}>
          <RotateCcw size={12} />Refresh
        </button>
      </div>

      {loading ? (
        <div className="flex items-center gap-2 py-8 justify-center" style={{ color: N.textMuted }}>
          <Loader2 size={16} className="animate-spin" /><span className="text-sm">Loading history…</span>
        </div>
      ) : batches.length === 0 ? (
        <div className="text-center py-12 rounded-xl" style={{ border: `1px dashed ${N.borderMid}` }}>
          <FileJson size={32} className="mx-auto mb-3" style={{ color: N.borderMid }} />
          <p className="text-sm font-medium" style={{ color: N.textMuted }}>No imports yet</p>
          <p className="text-xs mt-1" style={{ color: N.borderMid }}>Import events above to see history here</p>
        </div>
      ) : (
        <div className="space-y-3">
          {batches.map(batch => (
            <div key={batch.id} className="rounded-xl overflow-hidden" style={{ border: `1px solid ${N.border}`, background: N.surface }}>
              {/* Batch header */}
              <div className="flex items-center gap-4 p-4 cursor-pointer" onClick={() => setExpanded(e => e === batch.id ? null : batch.id)}>
                {/* Quality ring */}
                <div className="flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center"
                  style={{ background: qualityColor(batch.avgQuality) + '15', border: `2px solid ${qualityColor(batch.avgQuality)}30` }}>
                  <span className="text-xs font-bold tabular-nums" style={{ color: qualityColor(batch.avgQuality) }}>
                    {batch.avgQuality}
                  </span>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-semibold" style={{ color: N.text }}>
                      {batch.label || fmtDate(batch.timestamp)}
                    </span>
                    {batch.label && <span className="text-xs" style={{ color: N.textMuted }}>{fmtDate(batch.timestamp)}</span>}
                  </div>
                  <div className="flex gap-3 mt-0.5 flex-wrap">
                    {batch.created > 0 && (
                      <span className="text-xs flex items-center gap-1" style={{ color: N.green }}>
                        <CheckCircle2 size={11} />{batch.created} new
                      </span>
                    )}
                    {(batch.updated || 0) > 0 && (
                      <span className="text-xs flex items-center gap-1" style={{ color: N.blue }}>
                        <RotateCcw size={11} />{batch.updated} updated
                      </span>
                    )}
                    {/* legacy "skipped" shown as invalid */}
                    {((batch.invalid || 0) + (batch.skipped || 0)) > 0 && (
                      <span className="text-xs flex items-center gap-1" style={{ color: N.textMuted }}>
                        <X size={11} />{(batch.invalid || 0) + (batch.skipped || 0)} invalid
                      </span>
                    )}
                    <span className="text-xs" style={{ color: N.textMuted }}>
                      quality: <span style={{ color: qualityColor(batch.avgQuality) }}>{batch.avgQuality}%</span>
                    </span>
                  </div>
                </div>
                <div className="flex-shrink-0">
                  {expanded === batch.id ? <ChevronUp size={16} style={{ color: N.textMuted }} /> : <ChevronDown size={16} style={{ color: N.textMuted }} />}
                </div>
              </div>

              {/* Expanded event IDs */}
              <AnimatePresence initial={false}>
                {expanded === batch.id && (
                  <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.2 }}
                    style={{ borderTop: `1px solid ${N.border}`, overflow: 'hidden' }}>
                    <div className="p-4">
                      {batch.eventIds.length === 0 ? (
                        <p className="text-xs text-center py-4" style={{ color: N.textMuted }}>All events from this batch have been deleted</p>
                      ) : (
                        <div className="space-y-1.5">
                          {batch.eventIds.map(eventId => (
                            <div key={eventId} className="flex items-center gap-3 px-3 py-2 rounded-lg group"
                              style={{ background: N.surface2 }}>
                              <span className="flex-1 text-xs font-mono truncate" style={{ color: N.textMuted }}>{eventId}</span>
                              <button
                                onClick={() => handleDeleteEvent(eventId, batch.id)}
                                disabled={deleting === eventId}
                                className="opacity-0 group-hover:opacity-100 flex items-center gap-1 px-2 py-1 rounded text-xs transition-all"
                                style={{ background: N.redBg, color: N.red }}>
                                {deleting === eventId ? <Loader2 size={10} className="animate-spin" /> : <Trash2 size={10} />}
                                Delete
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Main component ────────────────────────────────────────────────────────
export function BulkEventImport() {
  const { accessToken } = useOutletContext<{ accessToken: string }>();

  const [step, setStep]         = useState(1);
  const [jsonText, setJsonText] = useState('');
  const [parseErr, setParseErr] = useState('');
  const [warnings, setWarnings] = useState<string[]>([]);
  const [events, setEvents]     = useState<ParsedEvent[]>([]);
  const [importing, setImporting]       = useState(false);
  const [importResult, setImportResult] = useState<{ created: number; updated: number; invalid: number; avgQuality: number } | null>(null);
  const [importErr, setImportErr] = useState('');
  const [batchLabel, setBatchLabel] = useState('');

  // Bulk-enrich controls (step 3)
  const [bulkCategory, setBulkCategory] = useState('');
  const [bulkModes, setBulkModes]       = useState<string[]>([]);
  const [bulkStatus, setBulkStatus]     = useState<'upcoming'|'ongoing'|'past'>('upcoming');

  const fileRef = useRef<HTMLInputElement>(null);

  const handleFileDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => setJsonText(String(ev.target?.result || ''));
    reader.readAsText(file);
  }, []);

  const handleFileInput = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => setJsonText(String(ev.target?.result || ''));
    reader.readAsText(file);
  }, []);

  const handleParse = useCallback(() => {
    setParseErr(''); setWarnings([]);
    if (!jsonText.trim()) { setParseErr('Please paste or upload JSON first.'); return; }
    let parsed: unknown;
    try { parsed = JSON.parse(jsonText.trim()); }
    catch (e) { setParseErr(`Invalid JSON: ${(e as Error).message}`); return; }
    const { events: evs, warnings: wrns } = parseRAJson(parsed);
    setWarnings(wrns); setEvents(evs);
    if (evs.length > 0) setStep(2);
    else setParseErr('No events could be parsed.');
  }, [jsonText]);

  const handleChange = useCallback((idx: number, patch: Partial<ParsedEvent>) => {
    setEvents(evs => evs.map((e, i) => i === idx ? { ...e, ...patch } : e));
  }, []);
  const handleRemove = useCallback((idx: number) => {
    setEvents(evs => evs.filter((_, i) => i !== idx));
  }, []);

  // Apply bulk enrich to all selected events
  const applyBulk = () => {
    setEvents(evs => evs.map(ev => {
      if (!ev.selected) return ev;
      const patch: Partial<ParsedEvent> = { status: bulkStatus };
      if (bulkCategory) patch.category = bulkCategory;
      if (bulkModes.length > 0) { patch.modeTags = bulkModes; patch.modes = bulkModes; }
      return { ...ev, ...patch };
    }));
  };

  const selectedEvents = events.filter(e => e.selected);
  const avgQualityPreview = selectedEvents.length > 0
    ? Math.round(selectedEvents.reduce((s, e) => s + getQuality(e), 0) / selectedEvents.length)
    : 0;

  const handleImport = useCallback(async () => {
    if (selectedEvents.length === 0) return;
    setImporting(true); setImportErr('');
    try {
      const payload = selectedEvents.map(({ _raw, selected, ...rest }) => rest);
      const res = await fetch(`${API_BASE}/events/bulk`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${publicAnonKey}` },
        body: JSON.stringify({ events: payload, batchMeta: { label: batchLabel } }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
      setImportResult({ created: data.created, updated: data.updated || 0, invalid: data.invalid || 0, avgQuality: data.avgQuality });
      setStep(4);
      fireWebhook('bulk_import.completed', {
        source: 'ra', batchLabel, created: data.created,
        updated: data.updated || 0, invalid: data.invalid || 0,
      });
    } catch (err) {
      setImportErr(`Import failed: ${(err as Error).message}`);
    } finally {
      setImporting(false);
    }
  }, [selectedEvents, batchLabel]);

  const handleReset = () => {
    setStep(1); setJsonText(''); setParseErr(''); setWarnings([]);
    setEvents([]); setImportResult(null); setImportErr('');
    setBatchLabel(''); setBulkCategory(''); setBulkModes([]); setBulkStatus('upcoming');
  };

  const EXAMPLE = `[
  {
    "title": "Peggy Gou",
    "startTime": "2026-03-20T22:00:00",
    "venue": { "name": "Oma", "address": "79 Wyndham St, Central", "location": { "latitude": 22.28, "longitude": 114.15 } },
    "cost": "350",
    "contentUrl": "/events/12345",
    "artists": [{ "name": "Peggy Gou" }],
    "genres": [{ "name": "House" }, { "name": "Techno" }],
    "images": [{ "filename": "https://...", "type": "FLYERFRONT" }]
  }
]`;

  return (
    <div className="min-h-screen p-6 md:p-10" style={{ background: N.pageBg, fontFamily: N.font }}>
      <div className="max-w-3xl mx-auto">

        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-1">
            <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: N.dark }}>
              <FileJson size={18} color="#fff" />
            </div>
            <div>
              <h1 className="text-xl font-bold" style={{ color: N.text }}>RA Event Import</h1>
              <p className="text-xs" style={{ color: N.textMuted }}>Import Resident Advisor events via JSON — parse, enrich, publish</p>
            </div>
          </div>
        </div>

        <Steps step={step} />

        {/* ── STEP 1: Paste JSON ─────────────────────────────────────── */}
        {step === 1 && (
          <motion.div key="s1" initial={{ opacity: 0, x: -16 }} animate={{ opacity: 1, x: 0 }}>
            <div className="rounded-xl p-4 mb-5 flex items-start gap-3"
              style={{ background: N.blueBg, border: `1px solid rgba(37,99,235,0.2)` }}>
              <Sparkles size={15} className="flex-shrink-0 mt-0.5" style={{ color: N.blue }} />
              <div>
                <p className="text-xs font-semibold mb-1" style={{ color: N.blue }}>Supported RA JSON formats</p>
                <ul className="text-xs space-y-0.5" style={{ color: N.blue }}>
                  <li>• <strong>Flat RA / Apify</strong> — camelCase with <code>startTime</code>, <code>venue.name</code>, <code>images[]</code></li>
                  <li>• <strong>ra-scraper</strong> — snake_case with <code>start_time</code>, <code>flyer_image</code></li>
                  <li>• <strong>RA GraphQL listing</strong> — <code>{'{ listings: [...] }'}</code> wrapper</li>
                  <li>• <strong>CULTIVE native</strong> — events with <code>venueId</code> + <code>modeTags</code> pass-through</li>
                </ul>
              </div>
            </div>

            <div className="rounded-xl mb-4 flex flex-col items-center justify-center gap-2 cursor-pointer transition-colors"
              style={{ border: `2px dashed ${N.borderMid}`, background: N.surface, minHeight: 90, padding: '20px' }}
              onDragOver={e => e.preventDefault()} onDrop={handleFileDrop} onClick={() => fileRef.current?.click()}>
              <Upload size={20} style={{ color: N.textMuted }} />
              <p className="text-sm font-medium" style={{ color: N.text }}>Drop a <code>.json</code> file here or click to browse</p>
              <input ref={fileRef} type="file" accept=".json,application/json" className="hidden" onChange={handleFileInput} />
            </div>

            <div className="relative mb-1">
              <textarea rows={13} className="w-full rounded-xl px-4 py-3 text-sm font-mono outline-none resize-none"
                style={{ background: N.surface, border: `1px solid ${N.borderMid}`, color: N.text, fontFamily: 'ui-monospace, monospace' }}
                placeholder={`Paste your RA JSON here…\n\nExample:\n${EXAMPLE}`}
                value={jsonText} onChange={e => setJsonText(e.target.value)} />
              {jsonText && (
                <button onClick={() => setJsonText('')} className="absolute top-3 right-3 p-1 rounded-lg hover:bg-gray-100 transition">
                  <X size={14} style={{ color: N.textMuted }} />
                </button>
              )}
            </div>
            <p className="text-xs mb-5" style={{ color: N.textMuted }}>
              {jsonText ? `${jsonText.length.toLocaleString()} characters` : 'No content yet'}
            </p>
            {parseErr && (
              <div className="rounded-lg px-4 py-3 mb-4 flex items-start gap-2"
                style={{ background: N.redBg, border: `1px solid rgba(220,38,38,0.2)` }}>
                <AlertCircle size={15} className="flex-shrink-0 mt-0.5" style={{ color: N.red }} />
                <p className="text-sm" style={{ color: N.red }}>{parseErr}</p>
              </div>
            )}
            <button onClick={handleParse}
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-semibold hover:opacity-90 transition-opacity"
              style={{ background: N.dark, color: '#fff' }}>
              <ClipboardPaste size={15} />Parse JSON<ArrowRight size={15} />
            </button>
          </motion.div>
        )}

        {/* ── STEP 2: Review & Edit ───────────────────────────────────── */}
        {step === 2 && (
          <motion.div key="s2" initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }}>
            {warnings.length > 0 && (
              <div className="rounded-lg px-4 py-3 mb-4" style={{ background: N.orangeBg, border: `1px solid rgba(234,88,12,0.2)` }}>
                <p className="text-xs font-semibold mb-1" style={{ color: N.orange }}>Parser warnings</p>
                {warnings.map((w, i) => <p key={i} className="text-xs" style={{ color: N.orange }}>• {w}</p>)}
              </div>
            )}
            <div className="rounded-xl px-4 py-3 mb-4 flex items-center justify-between"
              style={{ background: N.surface, border: `1px solid ${N.border}` }}>
              <div className="flex items-center gap-4">
                <span className="text-sm font-semibold" style={{ color: N.text }}>{events.length} parsed</span>
                <span className="text-sm" style={{ color: N.green }}>{selectedEvents.length} selected</span>
              </div>
              <div className="flex gap-2">
                <button onClick={() => setEvents(evs => evs.map(e => ({ ...e, selected: true })))}
                  className="text-xs px-3 py-1 rounded-lg" style={{ background: N.surface2, color: N.textMuted }}>Select all</button>
                <button onClick={() => setEvents(evs => evs.map(e => ({ ...e, selected: false })))}
                  className="text-xs px-3 py-1 rounded-lg" style={{ background: N.surface2, color: N.textMuted }}>None</button>
              </div>
            </div>

            <div className="flex flex-col gap-3 mb-6">
              <AnimatePresence initial={false}>
                {events.map((ev, idx) => (
                  <EventCard key={ev.id + idx} ev={ev} idx={idx} onChange={handleChange} onRemove={handleRemove} />
                ))}
              </AnimatePresence>
            </div>

            <div className="flex gap-3">
              <button onClick={() => setStep(1)}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold transition"
                style={{ background: N.surface2, color: N.text, border: `1px solid ${N.border}` }}>
                <ArrowLeft size={15} />Back
              </button>
              <button onClick={() => setStep(3)} disabled={selectedEvents.length === 0}
                className="flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-semibold hover:opacity-90 transition-opacity disabled:opacity-40"
                style={{ background: N.dark, color: '#fff' }}>
                Enrich {selectedEvents.length} event{selectedEvents.length !== 1 ? 's' : ''}<ArrowRight size={15} />
              </button>
            </div>
          </motion.div>
        )}

        {/* ── STEP 3: Enrich ─────────────────────────────────────────── */}
        {step === 3 && (
          <motion.div key="s3" initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }}>
            {/* Quality overview */}
            <div className="rounded-xl p-4 mb-5 flex items-center gap-6"
              style={{ background: N.surface, border: `1px solid ${N.border}` }}>
              <div className="flex-1">
                <p className="text-xs font-semibold mb-2" style={{ color: N.textMuted }}>Average quality score</p>
                <QualityBar value={avgQualityPreview} />
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold tabular-nums" style={{ color: avgQualityPreview >= 70 ? N.green : N.orange }}>
                  {avgQualityPreview}%
                </p>
                <p className="text-xs" style={{ color: N.textMuted }}>{selectedEvents.length} events</p>
              </div>
            </div>

            {/* Bulk apply bar */}
            <div className="rounded-xl p-4 mb-5" style={{ background: N.purpleBg, border: `1px solid rgba(124,58,237,0.15)` }}>
              <div className="flex items-center gap-2 mb-3">
                <Zap size={14} style={{ color: N.purple }} />
                <p className="text-xs font-semibold" style={{ color: N.purple }}>Bulk apply to all selected events</p>
              </div>
              <div className="flex flex-wrap gap-3 items-end">
                {/* Bulk category */}
                <div className="flex flex-col gap-1">
                  <label className="text-xs" style={{ color: N.purple }}>Category</label>
                  <select value={bulkCategory} onChange={e => setBulkCategory(e.target.value)}
                    className="rounded-lg px-3 py-1.5 text-xs outline-none"
                    style={{ background: N.surface, border: `1px solid rgba(124,58,237,0.3)`, color: N.text, fontFamily: N.font }}>
                    <option value="">— keep individual —</option>
                    {CULTIVE_CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                {/* Bulk status */}
                <div className="flex flex-col gap-1">
                  <label className="text-xs" style={{ color: N.purple }}>Status</label>
                  <select value={bulkStatus} onChange={e => setBulkStatus(e.target.value as any)}
                    className="rounded-lg px-3 py-1.5 text-xs outline-none"
                    style={{ background: N.surface, border: `1px solid rgba(124,58,237,0.3)`, color: N.text, fontFamily: N.font }}>
                    <option value="upcoming">upcoming</option>
                    <option value="ongoing">ongoing</option>
                    <option value="past">past</option>
                  </select>
                </div>
                {/* Bulk modes */}
                <div className="flex flex-col gap-1">
                  <label className="text-xs" style={{ color: N.purple }}>Add Modes</label>
                  <div className="flex gap-1">
                    {CULTIVE_MODES.map(m => {
                      const active = bulkModes.includes(m.id);
                      return (
                        <button key={m.id} onClick={() => setBulkModes(prev => active ? prev.filter(x => x !== m.id) : [...prev, m.id])}
                          className="px-2 py-1 rounded text-[11px] font-semibold transition-all"
                          style={{ background: active ? m.color : N.surface, color: active ? '#fff' : N.textMuted, border: `1px solid ${active ? m.color : N.borderMid}` }}>
                          {m.label}
                        </button>
                      );
                    })}
                  </div>
                </div>
                <button onClick={applyBulk}
                  className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-xs font-semibold transition"
                  style={{ background: N.purple, color: '#fff' }}>
                  <ListChecks size={12} />Apply to all
                </button>
              </div>
            </div>

            {/* Batch label */}
            <div className="mb-4">
              <label className="text-xs font-semibold mb-1 block" style={{ color: N.textMuted }}>Import label (optional)</label>
              <input type="text" placeholder="e.g. RA HK March 2026 weekend"
                value={batchLabel} onChange={e => setBatchLabel(e.target.value)}
                className="w-full rounded-xl px-4 py-2.5 text-sm outline-none"
                style={{ background: N.surface, border: `1px solid ${N.borderMid}`, color: N.text }} />
            </div>

            {/* Per-event enrich cards */}
            <div className="flex flex-col gap-3 mb-6">
              {selectedEvents.map((ev, idx) => {
                const realIdx = events.findIndex(e => e.id === ev.id);
                return <EnrichCard key={ev.id} ev={ev} idx={realIdx} onChange={handleChange} />;
              })}
            </div>

            {importErr && (
              <div className="rounded-lg px-4 py-3 mb-4 flex items-start gap-2"
                style={{ background: N.redBg, border: `1px solid rgba(220,38,38,0.2)` }}>
                <AlertCircle size={15} className="flex-shrink-0 mt-0.5" style={{ color: N.red }} />
                <p className="text-sm" style={{ color: N.red }}>{importErr}</p>
              </div>
            )}

            <div className="flex gap-3">
              <button onClick={() => setStep(2)}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold transition"
                style={{ background: N.surface2, color: N.text, border: `1px solid ${N.border}` }}>
                <ArrowLeft size={15} />Back
              </button>
              <button onClick={handleImport} disabled={importing}
                className="flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-semibold hover:opacity-90 transition-opacity disabled:opacity-40"
                style={{ background: N.dark, color: '#fff' }}>
                {importing
                  ? <><Loader2 size={15} className="animate-spin" />Importing…</>
                  : <><Download size={15} />Import {selectedEvents.length} event{selectedEvents.length !== 1 ? 's' : ''}<ArrowRight size={15} /></>
                }
              </button>
            </div>
          </motion.div>
        )}

        {/* ── STEP 4: Done ────────────────────────────────────────────── */}
        {step === 4 && importResult && (
          <motion.div key="s4" initial={{ opacity: 0, scale: 0.97 }} animate={{ opacity: 1, scale: 1 }}
            className="text-center py-10">
            <div className="w-16 h-16 rounded-full mx-auto mb-6 flex items-center justify-center" style={{ background: N.greenBg }}>
              <CheckCircle2 size={32} style={{ color: N.green }} />
            </div>
            <h2 className="text-2xl font-bold mb-2" style={{ color: N.text }}>Import Complete</h2>
            <p className="mb-6" style={{ color: N.textMuted }}>Events saved to CULTIVE's database and will appear on the site immediately.</p>
            <div className="flex gap-3 justify-center flex-wrap mb-8">
              {importResult.created > 0 && (
                <div className="rounded-2xl px-7 py-4 text-center" style={{ background: N.greenBg, border: `1px solid rgba(22,163,74,0.2)` }}>
                  <p className="text-3xl font-bold" style={{ color: N.green }}>{importResult.created}</p>
                  <p className="text-xs font-medium mt-1" style={{ color: N.green }}>New</p>
                </div>
              )}
              {importResult.updated > 0 && (
                <div className="rounded-2xl px-7 py-4 text-center" style={{ background: N.blueBg, border: `1px solid rgba(37,99,235,0.2)` }}>
                  <p className="text-3xl font-bold" style={{ color: N.blue }}>{importResult.updated}</p>
                  <p className="text-xs font-medium mt-1" style={{ color: N.blue }}>Updated</p>
                </div>
              )}
              {importResult.invalid > 0 && (
                <div className="rounded-2xl px-7 py-4 text-center" style={{ background: N.redBg, border: `1px solid rgba(220,38,38,0.15)` }}>
                  <p className="text-3xl font-bold" style={{ color: N.red }}>{importResult.invalid}</p>
                  <p className="text-xs font-medium mt-1" style={{ color: N.red }}>Invalid</p>
                </div>
              )}
              <div className="rounded-2xl px-7 py-4 text-center"
                style={{ background: (importResult.avgQuality >= 70 ? N.greenBg : N.orangeBg), border: `1px solid ${importResult.avgQuality >= 70 ? 'rgba(22,163,74,0.2)' : 'rgba(234,88,12,0.2)'}` }}>
                <p className="text-3xl font-bold" style={{ color: importResult.avgQuality >= 70 ? N.green : N.orange }}>{importResult.avgQuality}%</p>
                <p className="text-xs font-medium mt-1" style={{ color: importResult.avgQuality >= 70 ? N.green : N.orange }}>Avg Quality</p>
              </div>
            </div>
            {importResult.created === 0 && importResult.updated === 0 && (
              <div className="rounded-xl px-5 py-4 mb-6 text-sm" style={{ background: N.orangeBg, border: `1px solid rgba(234,88,12,0.2)`, color: N.orange }}>
                ⚠️ No events were saved. Check that each event has a valid <code>id</code> and <code>title</code>.
              </div>
            )}
            <div className="flex gap-3 justify-center">
              <button onClick={handleReset}
                className="flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-semibold transition"
                style={{ background: N.surface2, color: N.text, border: `1px solid ${N.border}` }}>
                <RotateCcw size={15} />Import another batch
              </button>
              <a href="/events"
                className="flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-semibold hover:opacity-90 transition-opacity"
                style={{ background: N.dark, color: '#fff' }}>
                View Events<ArrowRight size={15} />
              </a>
            </div>
          </motion.div>
        )}

        {/* ── Import History (always visible below wizard) ────────────── */}
        <ImportHistory accessToken={accessToken} />
      </div>
    </div>
  );
}
