/**
 * PitchDeckEditor — /admin/pitch-deck
 * Editable pitch deck with inline copy editing, JSON export, PDF export, and slide preview.
 */
import { useState, useCallback, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Download, ChevronDown, ChevronLeft, ChevronRight, Pencil, Check,
  X, Presentation, Copy, RotateCcw, Eye, Grid, FileDown, Loader2,
} from 'lucide-react';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';

// ═══════════════════════════════════════════════════════════════════
// TYPES & DATA
// ═══════════════════════════════════════════════════════════════════

interface SlideField {
  key: string;
  label: string;
  type: 'text' | 'textarea' | 'list' | 'table';
  value: string | string[] | string[][];
}

interface Slide {
  id: number;
  title: string;
  subtitle: string;
  fields: SlideField[];
}

const INITIAL_SLIDES: Slide[] = [
  {
    id: 1, title: 'Cover', subtitle: 'Opening slide',
    fields: [
      { key: 'brand', label: 'Brand Name', type: 'text', value: 'CULTIVE 文化活' },
      { key: 'tagline', label: 'Tagline', type: 'text', value: 'Cultural Discovery, Reinvented for Asia' },
      { key: 'hook', label: 'Hook Line', type: 'text', value: '5 modes. 6 cities. 170M people who can\'t find what\'s happening tonight.' },
      { key: 'round', label: 'Round', type: 'text', value: 'Seed Round — HK$3,000,000' },
      { key: 'date', label: 'Date', type: 'text', value: 'March 2026' },
    ],
  },
  {
    id: 2, title: 'The Problem', subtitle: 'Event discovery in Asia is broken',
    fields: [
      { key: 'headline', label: 'Headline', type: 'text', value: 'Event discovery in Asia is broken' },
      { key: 'subhead', label: 'Subheadline', type: 'text', value: 'Every major Asian city has a world-class cultural scene. None of them have a world-class way to discover it.' },
      { key: 'platforms', label: 'Where events live today', type: 'list', value: [
        'Instagram Stories → gone in 24 hours',
        'Facebook Events → buried by algorithm',
        'WhatsApp groups → invite-only, unsearchable',
        'PR newsletters → promotional bias',
        'Venue websites → one venue at a time',
        'Time Out / Tatler → slow editorial, no interactivity',
      ]},
      { key: 'stats', label: 'Key Stats', type: 'list', value: [
        '62% of HK residents say they "miss events they would have attended"',
        '3-5 platforms checked per person to plan a weekend',
        'Zero platforms offer mood-based discovery + bilingual + community',
      ]},
      { key: 'quote', label: 'Pull Quote', type: 'textarea', value: '"I spent 45 minutes across 4 apps trying to find something to do this Saturday. I gave up and stayed home." — Every person in every dense Asian city' },
    ],
  },
  {
    id: 3, title: 'The Solution', subtitle: 'One app, five moods, every vibe',
    fields: [
      { key: 'headline', label: 'Headline', type: 'text', value: 'CULTIVE: One app, five moods, every vibe' },
      { key: 'description', label: 'Description', type: 'textarea', value: 'CULTIVE is a cultural events platform with a 5-mode adaptive UI that transforms the entire experience based on how you feel — not just what category you pick.' },
      { key: 'modes', label: 'Mode Table', type: 'table', value: [
        ['Saturday night out', 'Night 🟣', 'Dark UI, neon markers, club listings, DJ lineups'],
        ['Gallery hopping', 'Art 🟪', 'Clean whites, serif fonts, exhibition focus'],
        ['Where should we eat?', 'Food 🔵', 'Rich photography, price ranges, booking links'],
        ['Sunday with the kids', 'Family 🟠', 'Rounded UI, age tags, safety info'],
        ['Morning run club', 'Lifestyle 🟢', 'Organic feel, community markers, difficulty levels'],
      ]},
      { key: 'notAFilter', label: 'Key Point', type: 'textarea', value: 'This is not a filter. The colours, fonts, map tiles, markers, layout, recommendations, and content all transform. It\'s 5 products in one.' },
      { key: 'editorial', label: 'Editorial Default', type: 'text', value: 'When no mode is selected → sophisticated editorial default (warm off-white, Archivo Black, hairline dividers). CULTIVE feels like a premium cultural publication.' },
    ],
  },
  {
    id: 4, title: 'Demo / Product', subtitle: 'The product is live',
    fields: [
      { key: 'headline', label: 'Headline', type: 'text', value: 'The product is live' },
      { key: 'features', label: 'Built & Working', type: 'list', value: [
        '5-mode adaptive UI with full theme transformation',
        'Interactive map (Leaflet) with 3 views: Map / Split / Grid',
        'Bilingual platform (English + Traditional Chinese 繁體中文)',
        'Automated event scraping pipeline (Clawbot / Apify)',
        'Admin CMS with 15+ modules',
        'Community recap submission → admin review → public gallery',
        'Quick Save collections with heart badges across all surfaces',
        'Webhook system for AI agent orchestration',
        'Weekly curated picks editor',
        'Quality scoring for imported events (0-100%)',
      ]},
      { key: 'stack', label: 'Tech Stack', type: 'text', value: 'React 18, Tailwind v4, Supabase (Edge Functions + KV + Auth + Storage), Apify, Leaflet' },
    ],
  },
  {
    id: 5, title: 'User Journey', subtitle: 'How it works',
    fields: [
      { key: 'steps', label: 'User Journey Steps', type: 'list', value: [
        'Open CULTIVE',
        'Choose your vibe (or browse editorial default)',
        'Discover events on map, in lists, or via curated picks',
        'Save to collections ("Date Night", "Weekend with Kids")',
        'Attend the event',
        'Submit a recap (photos, rating, description)',
        'Recap published → drives discovery for the next person',
      ]},
      { key: 'flywheel', label: 'The Flywheel', type: 'text', value: 'Events listed → Users discover → Users attend → Users submit recaps → Recaps drive SEO + social → New users discover → More events listed → ...' },
    ],
  },
  {
    id: 6, title: 'Technical Moat', subtitle: 'Clawbot + Modes + Bilingual',
    fields: [
      { key: 'headline', label: 'Headline', type: 'text', value: 'Our moat: Clawbot + Modes + Bilingual' },
      { key: 'clawbot', label: 'Clawbot Description', type: 'textarea', value: 'While competitors rely on editorial teams or user submissions, our Apify scraping pipeline can ingest events from any website. Auto-maps 15+ field name variations, auto-detects district, auto-assigns mode tags. 3 input methods: paste JSON, dataset ID, or run actor directly from admin.' },
      { key: 'clawbotResult', label: 'Clawbot Result', type: 'text', value: '1 person can curate what takes competitors a 10-person editorial team.' },
      { key: 'modesMoat', label: '5-Mode System', type: 'text', value: 'Not a filter — a full UI metamorphosis. Requires ground-up architecture. Can\'t be bolted onto an existing platform.' },
      { key: 'bilingual', label: 'Bilingual from Day One', type: 'text', value: 'EN + ZH-Hant built into every component. Not a Google Translate layer. Taipei expansion requires near-zero localisation work.' },
    ],
  },
  {
    id: 7, title: 'Market Opportunity', subtitle: 'HK$48.7B arts & entertainment market',
    fields: [
      { key: 'headline', label: 'Headline', type: 'text', value: 'Hong Kong: HK$48.7B arts & entertainment market' },
      { key: 'metrics', label: 'Market Metrics', type: 'table', value: [
        ['Population', '7.5M'],
        ['Expats', '690K'],
        ['Annual tourists', '46M'],
        ['Culturally active residents (20-45)', '1.8M'],
        ['Annual arts & entertainment spending', 'HK$48.7B'],
        ['Monthly cultural events', '800-1,200+'],
        ['Smartphone penetration', '96%'],
      ]},
      { key: 'competitors', label: 'No One Owns This Space', type: 'list', value: [
        'Time Out HK — editorial, slow, no community, limited bilingual',
        'Resident Advisor — music only, no Chinese, no map',
        'Facebook Events — zero curation, algorithm-buried',
        'Eventbrite — ticketed events only, no discovery',
      ]},
      { key: 'unique', label: 'CULTIVE Unique Position', type: 'text', value: 'CULTIVE is the only platform with: all verticals + mood-based UI + full bilingual + community recaps + automated scraping' },
    ],
  },
  {
    id: 8, title: 'Business Model', subtitle: 'Three revenue engines',
    fields: [
      { key: 'sponsorship', label: 'Engine 1: Sponsored Discovery (60%)', type: 'table', value: [
        ['Featured Event Listing', '$2,000-8,000/event'],
        ['Mode Takeover', '$15,000-30,000/week'],
        ['Venue Spotlight', '$5,000-12,000/month'],
        ['Newsletter Sponsorship', '$5,000-15,000/send'],
      ]},
      { key: 'sponsorWhy', label: 'Why Modes Unlock Premium', type: 'text', value: 'A spirits brand sponsoring Night mode reaches exactly the right audience. Zero waste. Hyper-contextual. Commands 3-5x standard display CPMs.' },
      { key: 'membership', label: 'Engine 2: Premium Membership (25%)', type: 'table', value: [
        ['Free', '$0', 'Browse, save, map'],
        ['Explorer', '$39/mo', 'Early access, ad-lite'],
        ['Culturalist', '$79/mo', 'Exclusive events, 15% discounts'],
        ['Insider', '$149/mo', 'VIP events, concierge'],
      ]},
      { key: 'data', label: 'Engine 3: Data & Services (15%)', type: 'list', value: [
        'Cultural Insights API (trend data for real estate, F&B, tourism)',
        'Event marketing packages for organisers',
        'White-label licensing for tourism boards',
      ]},
    ],
  },
  {
    id: 9, title: 'Traction', subtitle: 'Where we are today',
    fields: [
      { key: 'current', label: 'Current Status', type: 'table', value: [
        ['Product', 'Live — full 5-mode system, CMS, map, recaps, collections'],
        ['Events in DB', '100+ (mock + imported via Clawbot)'],
        ['Venues in DB', '80+ (GPS-tagged with mode scores)'],
        ['Languages', '2 (EN, ZH-Hant)'],
        ['CMS modules', '15+ (template editor, pipeline, import wizard, webhooks)'],
        ['Scraping pipeline', 'Working — Apify/Clawbot with 3 input methods'],
        ['Webhook system', 'Working — 9 event types, HMAC-signed, auto-retry'],
        ['Import sources', '3+ (Resident Advisor, Lifestyle Asia, custom Apify actors)'],
      ]},
      { key: 'milestones', label: 'Next 6 Months', type: 'table', value: [
        ['Seed 200+ real events', 'Month 1-2'],
        ['10-15 anchor venue partners', 'Month 2-3'],
        ['15,000 MAU', 'Month 6'],
        ['5 brand sponsors', 'Month 6'],
        ['Mobile PWA', 'Month 4'],
        ['Premium membership launch', 'Month 5'],
      ]},
    ],
  },
  {
    id: 10, title: 'Financials', subtitle: 'Path to HK$8M revenue by Year 3',
    fields: [
      { key: 'projections', label: 'Revenue Projections', type: 'table', value: [
        ['Revenue', '$660K', '$3.06M', '$8.04M'],
        ['Sponsorship', '$480K', '$1.8M', '$4.2M'],
        ['Membership', '$120K', '$720K', '$1.92M'],
        ['Services + API', '$60K', '$540K', '$1.92M'],
        ['Costs', '$2.76M', '$2.8M', '$5.5M'],
        ['Net', '-$2.1M', '+$260K', '+$2.54M'],
      ]},
      { key: 'unitEcon', label: 'Unit Economics at Scale', type: 'table', value: [
        ['CAC', 'HK$25-40'],
        ['LTV (paid user)', 'HK$800-1,200'],
        ['LTV/CAC', '20-30x'],
        ['Gross margin (sponsorship)', '85%+'],
        ['Payback period', '< 2 months'],
      ]},
    ],
  },
  {
    id: 11, title: 'Expansion', subtitle: 'Pan-Asian: 6 cities, 170M people',
    fields: [
      { key: 'timeline', label: 'Expansion Timeline', type: 'text', value: '2026: HK → 2027 Q1: Tokyo → 2027 Q3: Taipei, Seoul → 2028: Bangkok, Ho Chi Minh City' },
      { key: 'cities', label: 'City Details', type: 'table', value: [
        ['Hong Kong', '7.5M', '46M', 'Live now. Proof of concept'],
        ['Taipei', '2.6M', '12M', 'ZH-Hant already built. Fastest expansion'],
        ['Tokyo', '14M', '30M', 'World\'s largest city, most fragmented discovery'],
        ['Seoul', '9.7M', '18M', 'K-culture global demand, strong local scene'],
        ['Bangkok', '11M', '35M', 'Most-visited city globally, zero cultural platform'],
        ['HCMC', '9M', '10M', 'Fastest-growing scene in SE Asia, first-mover'],
      ]},
      { key: 'tam', label: 'TAM', type: 'text', value: '6 cities: 19.8M culturally active residents + 151M tourists = 170.8M combined. At 2-3% penetration × HK$120/user/year = HK$408M-612M annual revenue potential' },
    ],
  },
  {
    id: 12, title: 'Competitive Position', subtitle: 'Why we win',
    fields: [
      { key: 'matrix', label: 'Competitive Matrix', type: 'table', value: [
        ['All verticals', 'Yes', 'No', 'Yes', 'No', 'Yes'],
        ['Mood-based UI', 'No', 'No', 'No', 'No', '5 modes'],
        ['Full bilingual', 'Partial', 'No', 'No', 'Partial', 'Yes'],
        ['Interactive map', 'Basic', 'No', 'No', 'No', '3 views'],
        ['Community recaps', 'No', 'No', 'Basic', 'No', 'Yes'],
        ['Auto scraping', 'No', 'No', 'No', 'No', 'Clawbot'],
        ['Webhook/API', 'No', 'No', 'No', 'Yes', 'Yes'],
        ['Free listings', 'No', 'Yes', 'Yes', 'No', 'Yes'],
      ]},
      { key: 'defensibility', label: 'Defensibility', type: 'list', value: [
        'Mode System — Novel interaction pattern. Requires ground-up architecture to replicate',
        'Clawbot Pipeline — 10x content scaling vs. editorial competitors',
        'Bilingual-first — Not bolted on. Critical for Asian markets',
        'Content flywheel — Recaps → SEO → users → recaps',
        'Webhook architecture — AI agent orchestration competitors can\'t retrofit',
      ]},
    ],
  },
  {
    id: 13, title: 'Team', subtitle: 'Two co-founders, zero fluff',
    fields: [
      { key: 'team', label: 'Team', type: 'table', value: [
        ['Focus', 'Product & Engineering', 'Clawbot & Operations'],
        ['Owns', '5-mode system, CMS, backend, infrastructure', 'Apify actors, content sourcing, partnerships, BD'],
        ['Built', 'Full-stack platform (live and working)', 'Scraping pipeline, data normalisation'],
      ]},
      { key: 'hires', label: 'Hiring Plan', type: 'table', value: [
        ['Content Lead (bilingual)', 'Month 2', 'Seed real events, establish editorial voice'],
        ['Community Manager', 'Month 4', 'Ambassador programme, social media'],
        ['Mobile Developer', 'Month 6', 'React Native iOS + Android'],
        ['Growth Marketing', 'Month 6', 'User acquisition, brand partnerships'],
        ['Sales (Sponsorship)', 'Month 8', 'Mode Takeover + Featured Listings revenue'],
      ]},
    ],
  },
  {
    id: 14, title: 'The Ask', subtitle: 'HK$3,000,000 Seed Round',
    fields: [
      { key: 'headline', label: 'Headline', type: 'text', value: 'Raising HK$3,000,000 Seed Round' },
      { key: 'funds', label: 'Use of Funds (18-month runway)', type: 'table', value: [
        ['Engineering + Product', '$1,200,000', '40%'],
        ['Content & Editorial', '$600,000', '20%'],
        ['Marketing & User Acquisition', '$480,000', '16%'],
        ['Operations', '$420,000', '14%'],
        ['Contingency', '$300,000', '10%'],
      ]},
      { key: 'milestones', label: 'Milestones This Round Unlocks', type: 'table', value: [
        ['50,000 MAU in Hong Kong', 'Month 12'],
        ['30 brand sponsors', 'Month 12'],
        ['2,000 paid members', 'Month 12'],
        ['Mobile apps launched', 'Month 8'],
        ['800+ events/month (automated)', 'Month 12'],
        ['Break-even', 'Month 18'],
        ['Tokyo market entry', 'Month 14'],
        ['Series A ready', 'Month 16-18'],
      ]},
      { key: 'seriesA', label: 'Series A Trigger', type: 'text', value: 'At 50K MAU + $3M ARR + Tokyo launched → raise HK$15M Series A for full pan-Asian expansion.' },
    ],
  },
  {
    id: 15, title: 'Vision', subtitle: 'The end state',
    fields: [
      { key: 'headline', label: 'Headline', type: 'text', value: 'The end state' },
      { key: 'vision', label: 'Vision Statements', type: 'list', value: [
        'For users: One app to discover everything happening in your city, in your language, matched to your mood.',
        'For organisers: The default place to list events and reach the right audience — for free.',
        'For brands: Hyper-contextual sponsorship that reaches people in the exact moment they\'re deciding what to do tonight.',
        'For cities: A cultural data layer that helps tourism boards, urban planners, and cultural institutions understand what\'s working.',
      ]},
      { key: 'closer', label: 'Closing Line', type: 'textarea', value: '170 million people across 6 Asian cities can\'t find what\'s happening tonight. We\'re fixing that. One mode at a time.' },
      { key: 'contact', label: 'Contact', type: 'text', value: 'contact@cultive.hk' },
      { key: 'confidential', label: 'Confidentiality Notice', type: 'text', value: 'Confidential — for investor discussions only' },
    ],
  },
];

// ═══════════════════════════════════════════════════════════════════
// DESIGN TOKENS
// ═══════════════════════════════════════════════════════════════════

const N = {
  pageBg: '#FAFAF8',
  font: "'Inter', 'Noto Sans HK', system-ui, sans-serif",
};

// ═══════════════════════════════════════════════════════════════════
// EDITABLE FIELD COMPONENTS
// ═══════════════════════════════════════════════════════════════════

function EditableText({ value, onChange, type = 'text' }: {
  value: string; onChange: (v: string) => void; type?: 'text' | 'textarea';
}) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(value);
  const save = () => { onChange(draft); setEditing(false); };
  const cancel = () => { setDraft(value); setEditing(false); };
  if (editing) {
    return (
      <div className="flex items-start gap-1.5">
        {type === 'textarea' ? (
          <textarea value={draft} onChange={e => setDraft(e.target.value)} onKeyDown={e => { if (e.key === 'Escape') cancel(); }} rows={3} className="flex-1 text-[13px] text-gray-800 bg-white border border-blue-300 rounded px-2 py-1.5 focus:outline-none focus:ring-2 focus:ring-blue-200 resize-y" autoFocus />
        ) : (
          <input value={draft} onChange={e => setDraft(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') save(); if (e.key === 'Escape') cancel(); }} className="flex-1 text-[13px] text-gray-800 bg-white border border-blue-300 rounded px-2 py-1.5 focus:outline-none focus:ring-2 focus:ring-blue-200" autoFocus />
        )}
        <button onClick={save} className="p-1 rounded hover:bg-green-50 cursor-pointer"><Check size={13} className="text-green-600" /></button>
        <button onClick={cancel} className="p-1 rounded hover:bg-red-50 cursor-pointer"><X size={13} className="text-red-400" /></button>
      </div>
    );
  }
  return (
    <div className="group flex items-start gap-1.5 cursor-pointer" onClick={() => { setDraft(value); setEditing(true); }}>
      <div className="flex-1 text-[13px] text-gray-800 leading-relaxed">{value}</div>
      <Pencil size={11} className="text-gray-300 group-hover:text-gray-500 mt-1 flex-shrink-0 transition-colors" />
    </div>
  );
}

function EditableList({ items, onChange }: { items: string[]; onChange: (v: string[]) => void }) {
  const [editIdx, setEditIdx] = useState<number | null>(null);
  const [draft, setDraft] = useState('');
  return (
    <div className="space-y-1">
      {items.map((item, i) => (
        <div key={i} className="flex items-start gap-1.5">
          <div className="w-1 h-1 rounded-full bg-gray-400 mt-2 flex-shrink-0" />
          {editIdx === i ? (
            <div className="flex-1 flex items-center gap-1">
              <input value={draft} onChange={e => setDraft(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') { const n = [...items]; n[i] = draft; onChange(n); setEditIdx(null); } if (e.key === 'Escape') setEditIdx(null); }} className="flex-1 text-[12px] bg-white border border-blue-300 rounded px-1.5 py-0.5 focus:outline-none" autoFocus />
              <button onClick={() => { const n = [...items]; n[i] = draft; onChange(n); setEditIdx(null); }} className="cursor-pointer"><Check size={11} className="text-green-600" /></button>
              <button onClick={() => setEditIdx(null)} className="cursor-pointer"><X size={11} className="text-red-400" /></button>
            </div>
          ) : (
            <div className="group flex items-start gap-1 flex-1 cursor-pointer" onClick={() => { setDraft(item); setEditIdx(i); }}>
              <span className="text-[12px] text-gray-700 leading-relaxed flex-1">{item}</span>
              <Pencil size={9} className="text-gray-200 group-hover:text-gray-400 mt-1 flex-shrink-0 transition-colors" />
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

function EditableTable({ rows, onChange }: { rows: string[][]; onChange: (v: string[][]) => void }) {
  const [editCell, setEditCell] = useState<[number, number] | null>(null);
  const [draft, setDraft] = useState('');
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-[11px]">
        <tbody>
          {rows.map((row, ri) => (
            <tr key={ri} className="border-b border-gray-100 last:border-0">
              {row.map((cell, ci) => (
                <td key={ci} className="py-1.5 px-2 first:pl-0">
                  {editCell?.[0] === ri && editCell?.[1] === ci ? (
                    <input value={draft} onChange={e => setDraft(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') { const n = rows.map(r => [...r]); n[ri][ci] = draft; onChange(n); setEditCell(null); } if (e.key === 'Escape') setEditCell(null); }} onBlur={() => { const n = rows.map(r => [...r]); n[ri][ci] = draft; onChange(n); setEditCell(null); }} className="w-full text-[11px] bg-white border border-blue-300 rounded px-1 py-0.5 focus:outline-none" autoFocus />
                  ) : (
                    <span className={`cursor-pointer hover:bg-blue-50 rounded px-1 py-0.5 -mx-1 transition-colors ${ci === 0 ? 'font-medium text-gray-800' : 'text-gray-600'}`} onClick={() => { setDraft(cell); setEditCell([ri, ci]); }}>{cell}</span>
                  )}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════
// SLIDE CARD (EDITOR)
// ═══════════════════════════════════════════════════════════════════

function SlideCard({ slide, onUpdate, open, toggle }: {
  slide: Slide; onUpdate: (fields: SlideField[]) => void; open: boolean; toggle: () => void;
}) {
  const updateField = (key: string, value: any) => {
    onUpdate(slide.fields.map(f => f.key === key ? { ...f, value } : f));
  };
  return (
    <div className="rounded-xl overflow-hidden border border-gray-200 bg-white">
      <button onClick={toggle} className="w-full flex items-center gap-3 px-4 py-3 cursor-pointer hover:bg-gray-50/50 transition-colors">
        <div className="w-7 h-7 rounded-lg bg-gray-900 text-white flex items-center justify-center text-[11px] font-bold flex-shrink-0">{slide.id}</div>
        <div className="flex-1 text-left min-w-0">
          <div className="font-semibold text-[13px] text-gray-900">{slide.title}</div>
          <div className="text-[11px] text-gray-500">{slide.subtitle}</div>
        </div>
        <div className="text-[10px] text-gray-400 mr-1">{slide.fields.length} fields</div>
        <motion.div animate={{ rotate: open ? 180 : 0 }} transition={{ duration: 0.2 }}><ChevronDown size={14} className="text-gray-400" /></motion.div>
      </button>
      <AnimatePresence>
        {open && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.25, ease: [0.4, 0, 0.2, 1] }} className="overflow-hidden">
            <div className="px-4 pb-4 space-y-4" style={{ borderTop: '1px solid rgba(0,0,0,0.06)' }}>
              {slide.fields.map(field => (
                <div key={field.key} className="pt-3">
                  <div className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-1.5">{field.label}</div>
                  {field.type === 'text' && <EditableText value={field.value as string} onChange={v => updateField(field.key, v)} />}
                  {field.type === 'textarea' && <EditableText value={field.value as string} onChange={v => updateField(field.key, v)} type="textarea" />}
                  {field.type === 'list' && <EditableList items={field.value as string[]} onChange={v => updateField(field.key, v)} />}
                  {field.type === 'table' && <EditableTable rows={field.value as string[][]} onChange={v => updateField(field.key, v)} />}
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════
// SLIDE PREVIEW COMPONENTS
// ═══════════════════════════════════════════════════════════════════

function getField(slide: Slide, key: string): string | string[] | string[][] | undefined {
  return slide.fields.find(f => f.key === key)?.value;
}

function PTable({ rows, headers, dark = false }: { rows: string[][]; headers?: string[]; dark?: boolean }) {
  const txt = dark ? 'text-white/60' : 'text-gray-600';
  const txtH = dark ? 'text-white/80' : 'text-gray-800';
  const border = dark ? 'border-white/8' : 'border-gray-200';
  return (
    <table className="w-full text-left" style={{ fontSize: 'min(1.2vw, 11px)' }}>
      {headers && (
        <thead><tr>{headers.map((h, i) => (
          <th key={i} className={`pb-1.5 pr-3 font-semibold ${txtH} border-b ${border}`} style={{ fontSize: 'min(0.9vw, 8px)', letterSpacing: '0.1em', textTransform: 'uppercase' }}>{h}</th>
        ))}</tr></thead>
      )}
      <tbody>{rows.map((row, ri) => (
        <tr key={ri} className={`border-b last:border-0 ${border}`}>
          {row.map((cell, ci) => (
            <td key={ci} className={`py-1.5 pr-3 ${ci === 0 ? `font-medium ${txtH}` : txt}`}>{cell}</td>
          ))}
        </tr>
      ))}</tbody>
    </table>
  );
}

function PBullets({ items, dark = false, numbered = false }: { items: string[]; dark?: boolean; numbered?: boolean }) {
  const txt = dark ? 'text-white/70' : 'text-gray-700';
  return (
    <div className="space-y-1">
      {items.map((item, i) => (
        <div key={i} className="flex items-start gap-2" style={{ fontSize: 'min(1.2vw, 11px)' }}>
          {numbered
            ? <span className={`font-bold ${dark ? 'text-white/25' : 'text-gray-300'} flex-shrink-0 w-4 text-right`}>{i + 1}.</span>
            : <span className={`mt-1.5 w-1 h-1 rounded-full flex-shrink-0 ${dark ? 'bg-white/25' : 'bg-gray-400'}`} />
          }
          <span className={`${txt} leading-relaxed`}>{item}</span>
        </div>
      ))}
    </div>
  );
}

/* ── Slide wrapper with chrome ── */
function SlideFrame({ slide, total, children }: { slide: Slide; total: number; children: React.ReactNode }) {
  const isDark = [1, 15].includes(slide.id);
  const bg = isDark ? '#0F0F0F' : '#FFFFFF';
  const muted = isDark ? 'rgba(255,255,255,0.3)' : '#BBB';
  return (
    <div className="relative w-full shadow-lg overflow-hidden" style={{ aspectRatio: '16/9', backgroundColor: bg, color: isDark ? '#fff' : '#1A1A1A', fontFamily: "'Inter', sans-serif", borderRadius: '6px', border: isDark ? '1px solid rgba(255,255,255,0.06)' : '1px solid rgba(0,0,0,0.1)' }}>
      <div className="absolute inset-0 flex flex-col" style={{ padding: 'min(5%, 40px)' }}>
        {/* Top bar */}
        <div className="flex items-center gap-2 mb-3" style={{ fontSize: 'min(0.85vw, 8px)', color: muted, letterSpacing: '0.15em', textTransform: 'uppercase', fontWeight: 600 }}>
          <span>SLIDE {slide.id} / {total}</span>
          <div className="h-px flex-1" style={{ backgroundColor: isDark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.06)' }} />
          <span>{slide.title}</span>
        </div>
        {/* Content */}
        <div className="flex-1 flex flex-col min-h-0 overflow-hidden">
          {children}
        </div>
        {/* Footer */}
        <div className="flex items-center justify-between mt-3" style={{ fontSize: 'min(0.7vw, 7px)', color: muted }}>
          <span style={{ fontFamily: "'Archivo Black', sans-serif", letterSpacing: '0.1em' }}>CULTIVE 文化活</span>
          <span>Confidential</span>
        </div>
      </div>
    </div>
  );
}

/* ── Individual slide renderers ── */

function renderSlideContent(slide: Slide) {
  const f = (k: string) => getField(slide, k);

  switch (slide.id) {
    case 1: return (
      <div className="flex flex-col items-center justify-center text-center flex-1">
        <div style={{ fontFamily: "'Archivo Black', sans-serif", fontSize: 'min(4vw, 36px)', letterSpacing: '-0.02em', lineHeight: 1.1 }}>{f('brand') as string}</div>
        <div className="mt-3" style={{ fontSize: 'min(1.6vw, 14px)', color: 'rgba(255,255,255,0.55)', fontWeight: 300 }}>{f('tagline') as string}</div>
        <div className="mt-6 px-5 py-2 rounded-full" style={{ fontSize: 'min(1.1vw, 10px)', color: 'rgba(255,255,255,0.8)', border: '1px solid rgba(255,255,255,0.12)', background: 'rgba(255,255,255,0.04)' }}>{f('hook') as string}</div>
        <div className="mt-4" style={{ fontSize: 'min(0.9vw, 9px)', color: 'rgba(255,255,255,0.3)' }}>{f('round') as string} · {f('date') as string}</div>
      </div>
    );

    case 2: return (
      <div className="flex-1 flex flex-col overflow-hidden">
        <h2 style={{ fontFamily: "'Archivo Black', sans-serif", fontSize: 'min(2.3vw, 20px)', lineHeight: 1.15, marginBottom: 'min(1%, 8px)' }}>{f('headline') as string}</h2>
        <p style={{ fontSize: 'min(1.1vw, 10px)', color: '#777', lineHeight: 1.6, marginBottom: 'min(1.5%, 10px)', maxWidth: '80%' }}>{f('subhead') as string}</p>
        <div className="grid grid-cols-2 gap-x-6 flex-1 min-h-0 overflow-hidden">
          <div>
            <div style={{ fontSize: 'min(0.8vw, 7px)', fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: '#999', marginBottom: '4px' }}>WHERE EVENTS LIVE</div>
            <PBullets items={(f('platforms') as string[]) || []} />
          </div>
          <div>
            <div style={{ fontSize: 'min(0.8vw, 7px)', fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: '#999', marginBottom: '4px' }}>THE RESULT</div>
            <PBullets items={(f('stats') as string[]) || []} />
            <div className="mt-2 pl-3" style={{ borderLeft: '2px solid #E5E7EB', fontSize: 'min(1vw, 9px)', color: '#999', fontStyle: 'italic', lineHeight: 1.5 }}>{f('quote') as string}</div>
          </div>
        </div>
      </div>
    );

    case 3: return (
      <div className="flex-1 flex flex-col overflow-hidden">
        <h2 style={{ fontFamily: "'Archivo Black', sans-serif", fontSize: 'min(2vw, 18px)', lineHeight: 1.15, marginBottom: 'min(0.8%, 6px)' }}>{f('headline') as string}</h2>
        <p style={{ fontSize: 'min(1vw, 9px)', color: '#777', lineHeight: 1.5, marginBottom: 'min(1%, 8px)', maxWidth: '75%' }}>{f('description') as string}</p>
        <PTable rows={(f('modes') as string[][]) || []} headers={['Your Mood', 'Mode', 'What Changes']} />
        <p className="mt-2" style={{ fontSize: 'min(1vw, 9px)', color: '#444', fontWeight: 600 }}>{f('notAFilter') as string}</p>
      </div>
    );

    case 4: return (
      <div className="flex-1 flex flex-col overflow-hidden">
        <h2 style={{ fontFamily: "'Archivo Black', sans-serif", fontSize: 'min(2.3vw, 20px)', lineHeight: 1.15, marginBottom: 'min(1.5%, 10px)' }}>{f('headline') as string}</h2>
        <div className="flex-1 min-h-0">
          <div style={{ fontSize: 'min(0.8vw, 7px)', fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: '#999', marginBottom: '6px' }}>BUILT & WORKING</div>
          <div className="space-y-0.5">
            {((f('features') as string[]) || []).map((item, i) => (
              <div key={i} className="flex items-start gap-1.5" style={{ fontSize: 'min(1.1vw, 10px)' }}>
                <span className="text-green-500 flex-shrink-0">&#10003;</span>
                <span className="text-gray-700">{item}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="mt-2 px-3 py-1.5 rounded" style={{ background: '#F8F8F6', fontSize: 'min(0.9vw, 8px)', color: '#888' }}>
          <strong className="text-gray-600">Stack:</strong> {f('stack') as string}
        </div>
      </div>
    );

    case 5: {
      const steps = (f('steps') as string[]) || [];
      return (
        <div className="flex-1 flex flex-col overflow-hidden">
          <h2 style={{ fontFamily: "'Archivo Black', sans-serif", fontSize: 'min(2vw, 18px)', lineHeight: 1.15, marginBottom: 'min(1.5%, 12px)' }}>User Journey</h2>
          <div className="flex-1">
            {steps.map((step, i) => (
              <div key={i} className="flex items-center gap-2.5 mb-1.5">
                <div className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 text-white font-bold" style={{ fontSize: 'min(0.9vw, 8px)', background: `hsl(${260 - i * 15}, 55%, ${45 + i * 3}%)` }}>{i + 1}</div>
                <div className="flex-1 py-1 px-2.5 rounded" style={{ fontSize: 'min(1.1vw, 10px)', background: '#F8F8F6', color: '#444' }}>{step}</div>
              </div>
            ))}
          </div>
          <div className="mt-2 px-3 py-1.5 rounded" style={{ background: '#F0EDE8', fontSize: 'min(0.9vw, 8px)', color: '#666' }}><strong>Flywheel:</strong> {f('flywheel') as string}</div>
        </div>
      );
    }

    case 6: return (
      <div className="flex-1 flex flex-col overflow-hidden">
        <h2 style={{ fontFamily: "'Archivo Black', sans-serif", fontSize: 'min(2vw, 18px)', lineHeight: 1.15, marginBottom: 'min(1.5%, 10px)' }}>{f('headline') as string}</h2>
        <div className="grid grid-cols-3 gap-3 flex-1">
          {[
            { num: '1', title: 'Clawbot', body: f('clawbot') as string, hl: f('clawbotResult') as string },
            { num: '2', title: '5-Mode System', body: f('modesMoat') as string },
            { num: '3', title: 'Bilingual-first', body: f('bilingual') as string },
          ].map(item => (
            <div key={item.num} className="rounded-lg p-2.5 flex flex-col" style={{ border: '1px solid #E8E4DE', background: '#FAFAF8' }}>
              <div className="font-black text-gray-200 mb-0.5" style={{ fontSize: 'min(2.5vw, 24px)', lineHeight: 1 }}>{item.num}</div>
              <div className="font-bold text-gray-800 mb-1.5" style={{ fontSize: 'min(1.1vw, 10px)' }}>{item.title}</div>
              <div className="text-gray-600 leading-relaxed flex-1" style={{ fontSize: 'min(0.9vw, 8px)' }}>{item.body}</div>
              {item.hl && <div className="mt-1.5 pt-1.5 font-semibold text-gray-800" style={{ borderTop: '1px solid #E8E4DE', fontSize: 'min(0.9vw, 8px)' }}>{item.hl}</div>}
            </div>
          ))}
        </div>
      </div>
    );

    case 7: return (
      <div className="flex-1 flex flex-col overflow-hidden">
        <h2 style={{ fontFamily: "'Archivo Black', sans-serif", fontSize: 'min(2vw, 18px)', lineHeight: 1.15, marginBottom: 'min(1.5%, 10px)' }}>{f('headline') as string}</h2>
        <div className="grid grid-cols-2 gap-5 flex-1 min-h-0 overflow-hidden">
          <PTable rows={(f('metrics') as string[][]) || []} headers={['Metric', 'Value']} />
          <div>
            <div style={{ fontSize: 'min(0.8vw, 7px)', fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: '#999', marginBottom: '6px' }}>NO ONE OWNS THIS SPACE</div>
            <PBullets items={(f('competitors') as string[]) || []} />
            <div className="mt-3 px-2.5 py-1.5 rounded font-semibold" style={{ background: '#F0EDE8', fontSize: 'min(1vw, 9px)', color: '#333' }}>{f('unique') as string}</div>
          </div>
        </div>
      </div>
    );

    case 8: return (
      <div className="flex-1 flex flex-col overflow-hidden">
        <h2 style={{ fontFamily: "'Archivo Black', sans-serif", fontSize: 'min(2vw, 18px)', lineHeight: 1.15, marginBottom: 'min(1%, 8px)' }}>Three Revenue Engines</h2>
        <div className="grid grid-cols-3 gap-2.5 flex-1 min-h-0 overflow-hidden">
          <div className="rounded-lg p-2.5 flex flex-col" style={{ border: '1px solid #E8E4DE' }}>
            <div style={{ fontSize: 'min(0.75vw, 7px)', fontWeight: 700, letterSpacing: '0.1em', color: '#7C3AED', marginBottom: '4px' }}>ENGINE 1 — 60%</div>
            <div className="font-bold mb-1.5" style={{ fontSize: 'min(1vw, 9px)' }}>Sponsored Discovery</div>
            <PTable rows={(f('sponsorship') as string[][]) || []} />
          </div>
          <div className="rounded-lg p-2.5 flex flex-col" style={{ border: '1px solid #E8E4DE' }}>
            <div style={{ fontSize: 'min(0.75vw, 7px)', fontWeight: 700, letterSpacing: '0.1em', color: '#2563EB', marginBottom: '4px' }}>ENGINE 2 — 25%</div>
            <div className="font-bold mb-1.5" style={{ fontSize: 'min(1vw, 9px)' }}>Membership</div>
            <PTable rows={(f('membership') as string[][]) || []} headers={['Tier', 'Price', 'Benefit']} />
          </div>
          <div className="rounded-lg p-2.5 flex flex-col" style={{ border: '1px solid #E8E4DE' }}>
            <div style={{ fontSize: 'min(0.75vw, 7px)', fontWeight: 700, letterSpacing: '0.1em', color: '#2D6A4F', marginBottom: '4px' }}>ENGINE 3 — 15%</div>
            <div className="font-bold mb-1.5" style={{ fontSize: 'min(1vw, 9px)' }}>Data & Services</div>
            <PBullets items={(f('data') as string[]) || []} />
          </div>
        </div>
      </div>
    );

    case 9: return (
      <div className="flex-1 flex flex-col overflow-hidden">
        <h2 style={{ fontFamily: "'Archivo Black', sans-serif", fontSize: 'min(2vw, 18px)', lineHeight: 1.15, marginBottom: 'min(1.5%, 10px)' }}>Where We Are Today</h2>
        <div className="grid grid-cols-2 gap-5 flex-1 min-h-0 overflow-hidden">
          <div>
            <div style={{ fontSize: 'min(0.8vw, 7px)', fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: '#999', marginBottom: '6px' }}>CURRENT STATUS</div>
            <PTable rows={(f('current') as string[][]) || []} headers={['What', 'Status']} />
          </div>
          <div>
            <div style={{ fontSize: 'min(0.8vw, 7px)', fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: '#999', marginBottom: '6px' }}>NEXT 6 MONTHS</div>
            <PTable rows={(f('milestones') as string[][]) || []} headers={['Milestone', 'Target']} />
          </div>
        </div>
      </div>
    );

    case 10: return (
      <div className="flex-1 flex flex-col overflow-hidden">
        <h2 style={{ fontFamily: "'Archivo Black', sans-serif", fontSize: 'min(2vw, 18px)', lineHeight: 1.15, marginBottom: 'min(1.5%, 10px)' }}>Path to HK$8M Revenue by Year 3</h2>
        <div className="grid grid-cols-2 gap-5 flex-1 min-h-0 overflow-hidden">
          <div>
            <div style={{ fontSize: 'min(0.8vw, 7px)', fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: '#999', marginBottom: '6px' }}>PROJECTIONS (HKD)</div>
            <PTable rows={(f('projections') as string[][]) || []} headers={['', 'Year 1', 'Year 2', 'Year 3']} />
          </div>
          <div>
            <div style={{ fontSize: 'min(0.8vw, 7px)', fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: '#999', marginBottom: '6px' }}>UNIT ECONOMICS</div>
            <PTable rows={(f('unitEcon') as string[][]) || []} headers={['Metric', 'Target']} />
          </div>
        </div>
      </div>
    );

    case 11: return (
      <div className="flex-1 flex flex-col overflow-hidden">
        <h2 style={{ fontFamily: "'Archivo Black', sans-serif", fontSize: 'min(2vw, 18px)', lineHeight: 1.15, marginBottom: 'min(0.8%, 6px)' }}>Pan-Asian Expansion: 6 Cities, 170M People</h2>
        <div className="mb-2 px-3 py-1.5 rounded text-center font-mono" style={{ background: '#F8F8F6', fontSize: 'min(1vw, 9px)', color: '#555', letterSpacing: '0.03em' }}>{f('timeline') as string}</div>
        <PTable rows={(f('cities') as string[][]) || []} headers={['City', 'Population', 'Tourists/yr', 'Key Advantage']} />
        <div className="mt-2 px-2.5 py-1.5 rounded font-semibold" style={{ background: '#F0EDE8', fontSize: 'min(0.9vw, 8px)', color: '#333' }}>{f('tam') as string}</div>
      </div>
    );

    case 12: return (
      <div className="flex-1 flex flex-col overflow-hidden">
        <h2 style={{ fontFamily: "'Archivo Black', sans-serif", fontSize: 'min(2vw, 18px)', lineHeight: 1.15, marginBottom: 'min(1.5%, 10px)' }}>Why We Win</h2>
        <PTable rows={(f('matrix') as string[][]) || []} headers={['', 'Time Out', 'RA', 'Facebook', 'Eventbrite', 'CULTIVE']} />
        <div className="mt-3">
          <div style={{ fontSize: 'min(0.8vw, 7px)', fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: '#999', marginBottom: '4px' }}>DEFENSIBILITY</div>
          <PBullets items={(f('defensibility') as string[]) || []} numbered />
        </div>
      </div>
    );

    case 13: return (
      <div className="flex-1 flex flex-col overflow-hidden">
        <h2 style={{ fontFamily: "'Archivo Black', sans-serif", fontSize: 'min(2vw, 18px)', lineHeight: 1.15, marginBottom: 'min(1.5%, 10px)' }}>Two Co-founders, Zero Fluff</h2>
        <div className="grid grid-cols-2 gap-5 flex-1 min-h-0 overflow-hidden">
          <div>
            <div style={{ fontSize: 'min(0.8vw, 7px)', fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: '#999', marginBottom: '6px' }}>FOUNDING TEAM</div>
            <PTable rows={(f('team') as string[][]) || []} headers={['', 'Co-founder 1', 'Co-founder 2']} />
          </div>
          <div>
            <div style={{ fontSize: 'min(0.8vw, 7px)', fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: '#999', marginBottom: '6px' }}>HIRING PLAN</div>
            <PTable rows={(f('hires') as string[][]) || []} headers={['Role', 'When', 'Why']} />
          </div>
        </div>
      </div>
    );

    case 14: return (
      <div className="flex-1 flex flex-col overflow-hidden">
        <h2 style={{ fontFamily: "'Archivo Black', sans-serif", fontSize: 'min(2.2vw, 20px)', lineHeight: 1.15, marginBottom: 'min(1.5%, 10px)' }}>{f('headline') as string}</h2>
        <div className="grid grid-cols-2 gap-5 flex-1 min-h-0 overflow-hidden">
          <div>
            <div style={{ fontSize: 'min(0.8vw, 7px)', fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: '#999', marginBottom: '6px' }}>USE OF FUNDS</div>
            <PTable rows={(f('funds') as string[][]) || []} headers={['Category', 'Amount', '%']} />
            <div className="mt-2 text-gray-500" style={{ fontSize: 'min(0.9vw, 8px)' }}>{f('seriesA') as string}</div>
          </div>
          <div>
            <div style={{ fontSize: 'min(0.8vw, 7px)', fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: '#999', marginBottom: '6px' }}>MILESTONES</div>
            <PTable rows={(f('milestones') as string[][]) || []} headers={['Milestone', 'Timeline']} />
          </div>
        </div>
      </div>
    );

    case 15: {
      const visions = (f('vision') as string[]) || [];
      return (
        <div className="flex-1 flex flex-col items-center justify-center text-center">
          <h2 style={{ fontFamily: "'Archivo Black', sans-serif", fontSize: 'min(2.3vw, 20px)', lineHeight: 1.15, marginBottom: 'min(1.5%, 10px)' }}>{f('headline') as string}</h2>
          <div className="mb-4" style={{ fontSize: 'min(1.5vw, 13px)', color: 'rgba(255,255,255,0.6)', fontWeight: 300, fontStyle: 'italic' }}>
            CULTIVE becomes the cultural operating system for Asia.
          </div>
          <div className="grid grid-cols-2 gap-2.5 max-w-[85%] text-left mb-4">
            {visions.map((v, i) => {
              const colonIdx = v.indexOf(': ');
              const label = colonIdx > -1 ? v.slice(0, colonIdx) : '';
              const body = colonIdx > -1 ? v.slice(colonIdx + 2) : v;
              return (
                <div key={i} className="rounded-lg px-2.5 py-2" style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.07)' }}>
                  <div className="font-bold mb-0.5" style={{ fontSize: 'min(0.85vw, 8px)', color: 'rgba(255,255,255,0.4)', textTransform: 'uppercase', letterSpacing: '0.1em' }}>{label}</div>
                  <div style={{ fontSize: 'min(1vw, 9px)', color: 'rgba(255,255,255,0.7)', lineHeight: 1.5 }}>{body}</div>
                </div>
              );
            })}
          </div>
          <div style={{ fontSize: 'min(1.1vw, 10px)', color: 'rgba(255,255,255,0.35)' }}>{f('closer') as string}</div>
          <div className="mt-2" style={{ fontSize: 'min(0.9vw, 9px)', color: 'rgba(255,255,255,0.25)' }}>{f('contact') as string}</div>
        </div>
      );
    }

    default: return <div className="flex-1 flex items-center justify-center text-gray-400">No preview available</div>;
  }
}

// ═══════════════════════════════════════════════════════════════════
// DECK PREVIEW MODE
// ═══════════════════════════════════════════════════════════════════

function DeckPreview({ slides, onBack, onExportPdf }: { slides: Slide[]; onBack: () => void; onExportPdf: () => void }) {
  const [current, setCurrent] = useState(0);
  const [layout, setLayout] = useState<'single' | 'grid'>('single');

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (layout !== 'single') return;
      if (e.key === 'ArrowRight' || e.key === 'ArrowDown') { e.preventDefault(); setCurrent(p => Math.min(p + 1, slides.length - 1)); }
      if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') { e.preventDefault(); setCurrent(p => Math.max(p - 1, 0)); }
      if (e.key === 'Escape') onBack();
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [layout, slides.length, onBack]);

  return (
    <div className="min-h-screen" style={{ background: '#1A1A1A', fontFamily: N.font }}>
      {/* Toolbar */}
      <div className="sticky top-0 z-10 flex items-center gap-3 px-4 py-2.5" style={{ background: 'rgba(26,26,26,0.95)', backdropFilter: 'blur(12px)', borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
        <button onClick={onBack} className="flex items-center gap-1.5 text-white/50 hover:text-white text-[12px] cursor-pointer transition-colors">
          <ChevronLeft size={14} /> Back to Editor
        </button>
        <div className="h-4 w-px bg-white/10" />
        <div className="flex-1 text-center">
          <span className="text-white/35 text-[11px] font-medium tracking-wider uppercase">CULTIVE Pitch Deck</span>
          {layout === 'single' && <span className="text-white/20 text-[11px] ml-2">— Slide {current + 1} of {slides.length}</span>}
        </div>
        <div className="h-4 w-px bg-white/10" />
        <button onClick={onExportPdf} className="flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-medium cursor-pointer transition-colors bg-white/8 text-white/60 hover:text-white hover:bg-white/12" title="Export as PDF">
          <FileDown size={13} /> PDF
        </button>
        <div className="h-4 w-px bg-white/10" />
        <div className="flex items-center gap-1">
          <button onClick={() => setLayout('single')} className={`p-1.5 rounded cursor-pointer transition-colors ${layout === 'single' ? 'bg-white/10 text-white' : 'text-white/35 hover:text-white/60'}`} title="Single slide"><Presentation size={14} /></button>
          <button onClick={() => setLayout('grid')} className={`p-1.5 rounded cursor-pointer transition-colors ${layout === 'grid' ? 'bg-white/10 text-white' : 'text-white/35 hover:text-white/60'}`} title="Grid view"><Grid size={14} /></button>
        </div>
      </div>

      {layout === 'single' ? (
        <div className="flex flex-col items-center justify-center px-4 py-8" style={{ minHeight: 'calc(100vh - 48px)' }}>
          <div className="w-full" style={{ maxWidth: '960px' }}>
            <AnimatePresence mode="wait">
              <motion.div key={current} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} transition={{ duration: 0.2 }}>
                <SlideFrame slide={slides[current]} total={slides.length}>
                  {renderSlideContent(slides[current])}
                </SlideFrame>
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Navigation */}
          <div className="flex items-center gap-4 mt-6">
            <button onClick={() => setCurrent(p => Math.max(p - 1, 0))} disabled={current === 0} className="p-2 rounded-lg text-white/40 hover:text-white hover:bg-white/5 disabled:opacity-15 disabled:cursor-not-allowed cursor-pointer transition-all">
              <ChevronLeft size={20} />
            </button>
            <div className="flex items-center gap-1.5">
              {slides.map((_, i) => (
                <button key={i} onClick={() => setCurrent(i)} className="cursor-pointer transition-all" style={{ width: current === i ? 18 : 6, height: 6, borderRadius: 3, background: current === i ? 'rgba(255,255,255,0.75)' : 'rgba(255,255,255,0.15)', transition: 'all 0.2s ease' }} />
              ))}
            </div>
            <button onClick={() => setCurrent(p => Math.min(p + 1, slides.length - 1))} disabled={current === slides.length - 1} className="p-2 rounded-lg text-white/40 hover:text-white hover:bg-white/5 disabled:opacity-15 disabled:cursor-not-allowed cursor-pointer transition-all">
              <ChevronRight size={20} />
            </button>
          </div>
          <div className="mt-3 text-white/25 text-[11px]">{slides[current].title} — {slides[current].subtitle}</div>
          <div className="mt-1.5 text-white/12 text-[10px]">Use arrow keys to navigate · ESC to exit</div>

          {/* Thumbnail strip */}
          <div className="mt-6 w-full overflow-x-auto" style={{ maxWidth: '960px' }}>
            <div className="flex gap-2 pb-2">
              {slides.map((s, i) => (
                <button key={s.id} onClick={() => setCurrent(i)} className={`flex-shrink-0 rounded overflow-hidden cursor-pointer transition-all ${current === i ? 'ring-2 ring-white/30 ring-offset-2 ring-offset-[#1A1A1A]' : 'opacity-35 hover:opacity-60'}`} style={{ width: 96, aspectRatio: '16/9' }}>
                  <div className="w-full h-full flex items-center justify-center" style={{ background: [1, 15].includes(s.id) ? '#0F0F0F' : '#fff', border: '1px solid rgba(255,255,255,0.08)' }}>
                    <div style={{ fontSize: 7, color: [1, 15].includes(s.id) ? 'rgba(255,255,255,0.4)' : '#888', fontWeight: 600 }}>{s.id}. {s.title}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      ) : (
        <div className="px-6 py-8 max-w-[1400px] mx-auto">
          <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
            {slides.map((s, i) => (
              <motion.button key={s.id} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }} onClick={() => { setCurrent(i); setLayout('single'); }} className="text-left cursor-pointer group">
                <div className="transition-transform group-hover:scale-[1.02]">
                  <SlideFrame slide={s} total={slides.length}>{renderSlideContent(s)}</SlideFrame>
                </div>
                <div className="mt-2 flex items-center gap-2">
                  <span className="text-white/25 text-[10px] font-bold">{s.id}</span>
                  <span className="text-white/45 text-[11px]">{s.title}</span>
                </div>
              </motion.button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════
// PDF PROGRESS OVERLAY
// ═══════════════════════════════════════════════════════════════════

/**
 * Convert an oklch/oklab/color() CSS value to rgb() by painting onto a
 * 1×1 canvas and reading back the pixel. Cached canvas for performance.
 */
let _cvtCanvas: HTMLCanvasElement | null = null;
let _cvtCtx: CanvasRenderingContext2D | null = null;
function convertToRgb(cssColor: string): string {
  try {
    if (!_cvtCanvas) {
      _cvtCanvas = document.createElement('canvas');
      _cvtCanvas.width = 1;
      _cvtCanvas.height = 1;
      _cvtCtx = _cvtCanvas.getContext('2d', { willReadFrequently: true });
    }
    const ctx = _cvtCtx!;
    ctx.clearRect(0, 0, 1, 1);
    ctx.fillStyle = cssColor;
    ctx.fillRect(0, 0, 1, 1);
    const [r, g, b, a] = ctx.getImageData(0, 0, 1, 1).data;
    return a < 255 ? `rgba(${r},${g},${b},${(a / 255).toFixed(3)})` : `rgb(${r},${g},${b})`;
  } catch {
    return cssColor;
  }
}

function PdfProgressOverlay({ current, total }: { current: number; total: number }) {
  const pct = total > 0 ? Math.round((current / total) * 100) : 0;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center" style={{ background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(8px)' }}>
      <div className="bg-white rounded-2xl p-8 shadow-2xl text-center" style={{ minWidth: 320 }}>
        <Loader2 size={28} className="text-purple-600 animate-spin mx-auto mb-4" />
        <div className="font-bold text-gray-900 text-[15px] mb-1">Generating PDF</div>
        <div className="text-gray-500 text-[12px] mb-4">Rendering slide {current} of {total}</div>
        <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
          <div className="h-full bg-purple-600 rounded-full transition-all duration-300 ease-out" style={{ width: `${pct}%` }} />
        </div>
        <div className="text-gray-400 text-[11px] mt-2">{pct}%</div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════
// MAIN PAGE
// ═══════════════════════════════════════════════════════════════════

export function PitchDeckEditor() {
  const [slides, setSlides] = useState<Slide[]>(INITIAL_SLIDES);
  const [expanded, setExpanded] = useState<Set<number>>(new Set([1]));
  const [copied, setCopied] = useState(false);
  const [viewMode, setViewMode] = useState<'edit' | 'preview'>('edit');
  const [pdfExporting, setPdfExporting] = useState(false);
  const [pdfProgress, setPdfProgress] = useState({ current: 0, total: 0 });
  const [pdfRendering, setPdfRendering] = useState(false);
  const pdfContainerRef = useRef<HTMLDivElement>(null);

  const exportPdf = useCallback(async () => {
    setPdfExporting(true);
    setPdfProgress({ current: 0, total: slides.length });
    setPdfRendering(true);
    await new Promise(r => setTimeout(r, 800));
    try {
      const container = pdfContainerRef.current;
      if (!container) throw new Error('PDF render container not found');

      // html2canvas cannot parse oklch/oklab colors (Tailwind v4 defaults).
      // Bake all computed colors into inline rgb styles before capture.
      const COLOR_PROPS = [
        'color', 'background-color', 'border-color',
        'border-top-color', 'border-right-color', 'border-bottom-color', 'border-left-color',
        'outline-color', 'text-decoration-color',
      ];
      const allEls = container.querySelectorAll<HTMLElement>('*');
      const saved: { el: HTMLElement; prop: string; orig: string }[] = [];
      allEls.forEach(el => {
        const cs = getComputedStyle(el);
        COLOR_PROPS.forEach(prop => {
          const val = cs.getPropertyValue(prop);
          if (val && (val.includes('oklch') || val.includes('oklab') || val.includes('color('))) {
            saved.push({ el, prop, orig: el.style.getPropertyValue(prop) });
            el.style.setProperty(prop, convertToRgb(val), 'important');
          }
        });
      });

      const slideEls = container.querySelectorAll<HTMLElement>('[data-pdf-slide]');
      if (slideEls.length === 0) throw new Error('No slide elements found');

      const SLIDE_W = slideEls[0].offsetWidth;
      const SLIDE_H = slideEls[0].offsetHeight;
      const pdf = new jsPDF({ orientation: 'landscape', unit: 'px', format: [SLIDE_W, SLIDE_H], compress: true });

      for (let i = 0; i < slideEls.length; i++) {
        setPdfProgress({ current: i + 1, total: slides.length });
        const canvas = await html2canvas(slideEls[i], {
          width: SLIDE_W,
          height: SLIDE_H,
          scale: 2,
          useCORS: true,
          backgroundColor: null,
          logging: false,
        });
        if (i > 0) pdf.addPage([SLIDE_W, SLIDE_H], 'landscape');
        pdf.addImage(canvas.toDataURL('image/jpeg', 0.92), 'JPEG', 0, 0, SLIDE_W, SLIDE_H);
      }

      // Restore original inline styles
      saved.forEach(({ el, prop, orig }) => {
        if (orig) el.style.setProperty(prop, orig);
        else el.style.removeProperty(prop);
      });

      pdf.save('CULTIVE-Pitch-Deck.pdf');
    } catch (err) {
      console.error('PDF export failed:', err);
      alert('PDF export failed. Check the browser console for details.');
    } finally {
      setPdfExporting(false);
      setPdfRendering(false);
      setPdfProgress({ current: 0, total: 0 });
    }
  }, [slides]);

  const toggle = (id: number) => setExpanded(p => { const n = new Set(p); n.has(id) ? n.delete(id) : n.add(id); return n; });
  const expandAll = () => setExpanded(new Set(slides.map(s => s.id)));
  const collapseAll = () => setExpanded(new Set());
  const updateSlide = useCallback((id: number, fields: SlideField[]) => { setSlides(prev => prev.map(s => s.id === id ? { ...s, fields } : s)); }, []);

  const resetAll = () => {
    if (confirm('Reset all slides to original content? This cannot be undone.')) setSlides(INITIAL_SLIDES);
  };

  const buildExport = () => ({
    name: 'CULTIVE 文化活 — Investor Pitch Deck',
    version: '1.0',
    exportedAt: new Date().toISOString(),
    slideCount: slides.length,
    slides: slides.map(s => ({ slideNumber: s.id, title: s.title, subtitle: s.subtitle, content: Object.fromEntries(s.fields.map(f => [f.key, f.value])) })),
  });

  const exportJson = () => {
    const blob = new Blob([JSON.stringify(buildExport(), null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'cultive-pitch-deck.json'; a.click();
    URL.revokeObjectURL(url);
  };

  const copyJson = () => {
    navigator.clipboard.writeText(JSON.stringify(buildExport(), null, 2)).catch(() => {});
    setCopied(true); setTimeout(() => setCopied(false), 2000);
  };

  const editedCount = slides.reduce((acc, s, si) => {
    const orig = INITIAL_SLIDES[si];
    if (!orig) return acc;
    return s.fields.some((f, fi) => JSON.stringify(f.value) !== JSON.stringify(orig.fields[fi]?.value)) ? acc + 1 : acc;
  }, 0);

  // Hidden container that renders all slides for PDF capture (only when exporting)
  const pdfRenderContainer = pdfRendering ? (
    <div ref={pdfContainerRef} aria-hidden style={{ position: 'fixed', left: '-9999px', top: 0, width: 1280, zIndex: -1 }}>
      {slides.map(s => (
        <div key={s.id} data-pdf-slide={s.id} style={{ width: 1280, height: 720, marginBottom: 4 }}>
          <SlideFrame slide={s} total={slides.length}>
            {renderSlideContent(s)}
          </SlideFrame>
        </div>
      ))}
    </div>
  ) : null;

  if (viewMode === 'preview') {
    return (
      <>
        <DeckPreview slides={slides} onBack={() => setViewMode('edit')} onExportPdf={exportPdf} />
        {pdfExporting && <PdfProgressOverlay current={pdfProgress.current} total={pdfProgress.total} />}
        {pdfRenderContainer}
      </>
    );
  }

  return (
    <div className="p-6 md:p-8 max-w-5xl mx-auto" style={{ fontFamily: N.font }}>
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-2 mb-3">
          <div className="text-[0.55rem] font-semibold uppercase tracking-[0.18em] text-gray-400">INVESTOR MATERIALS</div>
          <div className="h-px flex-1 bg-gray-200" />
          <div className="text-[11px] text-gray-400">v1.0 · March 2026</div>
        </div>
        <h1 className="text-2xl md:text-3xl font-black text-gray-900 mb-2" style={{ fontFamily: "'Archivo Black', sans-serif", lineHeight: 1.1 }}>
          Pitch Deck Editor
        </h1>
        <p className="text-sm text-gray-500 max-w-2xl leading-relaxed">
          Edit all copy for the CULTIVE investor pitch deck. Click any text to edit inline.
          Export the final deck content as JSON for use in presentation tools.
        </p>
        <div className="flex items-center flex-wrap gap-3 mt-3 text-[11px] text-gray-400">
          <span>{slides.length} slides</span>
          <span className="text-gray-300">&middot;</span>
          <span>{editedCount > 0 ? `${editedCount} modified` : 'No changes'}</span>
          <span className="text-gray-300">&middot;</span>
          <span>Seed Round — HK$3M</span>
          <span className="text-gray-300">&middot;</span>
          <button onClick={exportJson} className="inline-flex items-center gap-1 text-blue-600 hover:text-blue-700 font-medium cursor-pointer"><Download size={11} /> Export JSON</button>
          <span className="text-gray-300">&middot;</span>
          <button onClick={copyJson} className="inline-flex items-center gap-1 text-blue-600 hover:text-blue-700 font-medium cursor-pointer">
            {copied ? <Check size={11} className="text-green-600" /> : <Copy size={11} />}
            {copied ? 'Copied!' : 'Copy JSON'}
          </button>
          <span className="text-gray-300">&middot;</span>
          <button onClick={() => setViewMode('preview')} className="inline-flex items-center gap-1 text-purple-600 hover:text-purple-700 font-medium cursor-pointer">
            <Eye size={11} /> Preview Deck
          </button>
          <span className="text-gray-300">&middot;</span>
          <button onClick={exportPdf} disabled={pdfExporting} className="inline-flex items-center gap-1 text-red-600 hover:text-red-700 font-medium cursor-pointer disabled:opacity-50">
            {pdfExporting ? <Loader2 size={11} className="animate-spin" /> : <FileDown size={11} />}
            {pdfExporting ? 'Exporting...' : 'Export PDF'}
          </button>
        </div>
      </div>

      {/* Controls */}
      <div className="flex items-center gap-2 mb-4">
        <button onClick={expandAll} className="text-[11px] font-medium text-blue-600 hover:text-blue-700 cursor-pointer">Expand all</button>
        <span className="text-gray-300">&middot;</span>
        <button onClick={collapseAll} className="text-[11px] font-medium text-blue-600 hover:text-blue-700 cursor-pointer">Collapse all</button>
        {editedCount > 0 && (
          <>
            <span className="text-gray-300">&middot;</span>
            <button onClick={resetAll} className="text-[11px] font-medium text-red-500 hover:text-red-600 cursor-pointer inline-flex items-center gap-1"><RotateCcw size={10} /> Reset all</button>
          </>
        )}
      </div>

      {/* Slides */}
      <div className="space-y-2">
        {slides.map(slide => (
          <SlideCard key={slide.id} slide={slide} onUpdate={fields => updateSlide(slide.id, fields)} open={expanded.has(slide.id)} toggle={() => toggle(slide.id)} />
        ))}
      </div>

      {/* Footer */}
      <div className="pt-8 mt-8 border-t border-gray-200 flex items-center justify-between">
        <div className="text-[0.55rem] font-semibold uppercase tracking-[0.18em] text-gray-400">CULTIVE 文化活 · PITCH DECK v1.0</div>
        <div className="flex items-center gap-2">
          <button onClick={exportJson} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gray-900 text-white text-[11px] font-medium hover:bg-gray-800 transition-colors cursor-pointer">
            <Download size={12} /> Export as JSON
          </button>
          <button onClick={() => setViewMode('preview')} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-purple-600 text-white text-[11px] font-medium hover:bg-purple-700 transition-colors cursor-pointer">
            <Presentation size={12} /> Preview Deck
          </button>
          <button onClick={exportPdf} disabled={pdfExporting} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-600 text-white text-[11px] font-medium hover:bg-red-700 transition-colors cursor-pointer disabled:opacity-50">
            {pdfExporting ? <Loader2 size={12} className="animate-spin" /> : <FileDown size={12} />}
            {pdfExporting ? 'Exporting...' : 'Export PDF'}
          </button>
        </div>
      </div>
      {pdfExporting && <PdfProgressOverlay current={pdfProgress.current} total={pdfProgress.total} />}
      {pdfRenderContainer}
    </div>
  );
}
