/**
 * EventManager — Admin event management dashboard
 * View, edit, delete, filter events by source, category, mode
 */
import { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Search, Trash2, RefreshCw, MapPin, ChevronDown, ChevronUp,
  CheckSquare, Square, Loader2, ExternalLink, AlertTriangle,
  X, Calendar, Tag, Filter, ArrowUpDown, Eye, Pencil, Save,
  Music, Globe, Users, Clock, DollarSign, Image as ImageIcon,
  Ticket, Instagram, BarChart3, Sparkles, Upload, Check,
  Zap, Database, ArrowRight, Building2, Navigation,
} from 'lucide-react';
import { useOutletContext } from 'react-router';
import { projectId, publicAnonKey } from '../../config/supabase';
import { GooglePlacesAutocomplete, type PlaceResult } from '../../components/admin/GooglePlacesAutocomplete';
import { VenueLinker, DuplicateWarning, invalidateVenueCache, type VenueRecord } from '../../components/admin/VenueLinker';
import { parseCoordinates, reverseDistrictFromCoords } from '../../utils/coord-parser';
import { useData } from '../../context/DataContext';

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-d507b98c`;
const CMS_BASE = `${API_BASE}/cms`;

// Design tokens
const T = {
  bg: '#FAFAF8',
  surface: '#FFFFFF',
  border: '#E8E6E1',
  text: '#1A1A1A',
  textMuted: '#8C8C8C',
  accent: '#2D5A27',
  accentLight: '#E8F0E7',
  danger: '#DC2626',
  dangerLight: '#FEF2F2',
  warning: '#F59E0B',
  warningLight: '#FFFBEB',
  info: '#3B82F6',
  infoLight: '#EFF6FF',
  purple: '#7C3AED',
  purpleLight: '#F5F3FF',
  font: "'Inter', system-ui, sans-serif",
};

// Source colors
const SOURCE_COLORS: Record<string, { bg: string; color: string; label: string }> = {
  mock: { bg: '#FEF3C7', color: '#92400E', label: 'MOCK' },
  ra: { bg: '#DBEAFE', color: '#1E40AF', label: 'RA' },
  lsa: { bg: '#CCFBF1', color: '#0F766E', label: 'LSA' },
  apify: { bg: '#F0F9FF', color: '#06B6D4', label: 'APIFY' },
  community: { bg: '#E0E7FF', color: '#4338CA', label: 'COMMUNITY' },
  cms: { bg: '#D1FAE5', color: '#065F46', label: 'CMS' },
  imported: { bg: '#FCE7F3', color: '#9D174D', label: 'IMPORTED' },
  unknown: { bg: '#F3F4F6', color: '#6B7280', label: 'OTHER' },
};

const MODE_COLORS: Record<string, string> = {
  degen: '#EDFF00',
  artsy: '#1A1A1A',
  foodie: '#2563EB',
  family: '#FF8C42',
  lifestyle: '#2D6A4F',
};

/** Display-friendly date: strip ISO time portion → yyyy-mm-dd */
function displayDate(raw?: string): string {
  if (!raw) return '';
  const s = raw.trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
  const m = s.match(/^(\d{4}-\d{2}-\d{2})T/);
  if (m) return m[1];
  try {
    const d = new Date(s);
    if (!isNaN(d.getTime())) {
      const yyyy = d.getFullYear();
      const mm = String(d.getMonth() + 1).padStart(2, '0');
      const dd = String(d.getDate()).padStart(2, '0');
      return `${yyyy}-${mm}-${dd}`;
    }
  } catch {}
  return s;
}

/** Map category slug to human label */
const CATEGORY_LABELS: Record<string, string> = {
  'run-clubs': 'Run Clubs', 'wellness': 'Wellness', 'hikes': 'Hikes',
  'coffee-raves': 'Coffee Raves', 'workshops': 'Workshops', 'meetups': 'Meetups',
  'nightlife': 'Nightlife', 'art': 'Art', 'food': 'Food & Markets',
  'family': 'Family', 'other': 'Other',
};
function displayCategory(raw?: string): string {
  if (!raw) return '';
  return CATEGORY_LABELS[raw] || raw;
}

interface EventItem {
  id: string;
  title: string;
  description?: string;
  date?: string;
  endDate?: string;
  time?: string;
  category?: string;
  categories?: string[];
  image?: string;
  venueName?: string;
  venueId?: string;
  district?: string;
  price?: string;
  lat?: number;
  lng?: number;
  modeTags?: string[];
  artists?: string[];
  vibes?: string[];
  ticketUrl?: string;
  sourceUrl?: string;
  source?: string;
  status?: string;
  featured?: boolean;
  _source?: string;
  qualityScore?: number;
  _createdAt?: string;
  editorialHook?: string;
  editorialHook_zh?: string;
}

type SortField = 'title' | 'date' | 'category' | 'district' | 'quality' | 'dateAdded';
type SortDir = 'asc' | 'desc';
type SourceFilter = 'all' | 'mock' | 'ra' | 'lsa' | 'apify' | 'community' | 'cms' | 'unknown';

function authHeaders(token: string | null) {
  return {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${publicAnonKey}`,
    'X-Auth-Token': token || '',
  };
}

/** Determine event source */
function getEventSource(e: EventItem): string {
  if (e._source === 'mock') return 'mock';
  if (e._source === 'lsa') return 'lsa';
  if (e._source === 'apify') return 'apify';
  if (e.id?.startsWith('ra_')) return 'ra';
  if (e.id?.startsWith('lsa_')) return 'lsa';
  if (e.id?.startsWith('apify_')) return 'apify';
  if (e.id?.startsWith('sub_')) return 'community';
  if (e.id?.startsWith('cms_')) return 'cms';
  if (e._source) return e._source;
  // Fallback: detect mock seed events by ID pattern (e1, e2, ... e38)
  if (e.id && /^e\d+$/.test(e.id)) return 'mock';
  return 'unknown';
}

/** Calculate quality score for an event (0-100) */
function getQualityScore(e: EventItem): number {
  const checks = [
    !!e.title,
    !!e.image,
    typeof e.description === 'string' && e.description.length > 30,
    !!e.date,
    !!e.time,
    !!(e.venueName || e.venueId),
    !!e.price && e.price !== 'Check event page',
    !!(e.lat && e.lng),
    Array.isArray(e.modeTags) && e.modeTags.length > 0,
    !!e.category,
    Array.isArray(e.artists) && e.artists.length > 0,
  ];
  return Math.round((checks.filter(Boolean).length / checks.length) * 100);
}

/** Source badge */
function SourceBadge({ source }: { source: string }) {
  const cfg = SOURCE_COLORS[source] || SOURCE_COLORS.unknown;
  return (
    <span
      className="inline-block px-1.5 py-0.5 text-[10px] font-bold rounded"
      style={{ backgroundColor: cfg.bg, color: cfg.color, letterSpacing: '0.03em' }}
    >
      {cfg.label}
    </span>
  );
}

/** Quality bar */
function QualityBar({ value }: { value: number }) {
  const color = value >= 80 ? T.accent : value >= 50 ? T.warning : T.danger;
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-1.5 rounded-full overflow-hidden" style={{ backgroundColor: T.border }}>
        <div className="h-full rounded-full transition-all" style={{ width: `${value}%`, backgroundColor: color }} />
      </div>
      <span className="text-[11px] font-medium tabular-nums" style={{ color, minWidth: 28 }}>{value}%</span>
    </div>
  );
}

/** Mode tag pills */
function ModeTagPills({ tags }: { tags: string[] }) {
  if (!tags || tags.length === 0) return <span className="text-[11px]" style={{ color: T.textMuted }}>—</span>;
  return (
    <div className="flex flex-wrap gap-1">
      {tags.map(tag => (
        <span
          key={tag}
          className="px-1.5 py-0.5 text-[10px] font-semibold rounded"
          style={{
            backgroundColor: MODE_COLORS[tag] ? `${MODE_COLORS[tag]}15` : '#F3F4F6',
            color: MODE_COLORS[tag] || T.textMuted,
            border: tag === 'degen' ? `1px solid ${MODE_COLORS[tag]}40` : undefined,
          }}
        >
          {tag}
        </span>
      ))}
    </div>
  );
}

// ─── Event Detail / Edit Panel ───
function EventDetailPanel({ event, onUpdate, onClose, onDelete, accessToken }: {
  event: EventItem;
  onUpdate: (updated: EventItem) => void;
  onClose: () => void;
  onDelete: () => void;
  accessToken: string | null;
}) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState<Partial<EventItem>>({});
  const [saving, setSaving] = useState(false);
  const [selectedPlace, setSelectedPlace] = useState<PlaceResult | null>(null);
  const [creatingVenue, setCreatingVenue] = useState(false);
  const [venueCreated, setVenueCreated] = useState(false);
  const [showDuplicateCheck, setShowDuplicateCheck] = useState(false);

  // Normalize ISO dates to yyyy-mm-dd for form inputs
  const normDate = (raw?: string): string => {
    if (!raw) return '';
    const s = raw.trim();
    if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
    const m = s.match(/^(\d{4}-\d{2}-\d{2})T/);
    if (m) return m[1];
    try {
      const d = new Date(s);
      if (!isNaN(d.getTime())) {
        const yyyy = d.getFullYear();
        const mm = String(d.getMonth() + 1).padStart(2, '0');
        const dd = String(d.getDate()).padStart(2, '0');
        return `${yyyy}-${mm}-${dd}`;
      }
    } catch {}
    return s;
  };

  // Normalize category to CMS slug
  const CAT_SLUG_MAP: Record<string, string> = {
    'music': 'nightlife', 'nightlife': 'nightlife', 'club': 'nightlife', 'concert': 'nightlife',
    'party': 'nightlife', 'electronic': 'nightlife', 'live music': 'nightlife', 'festival': 'nightlife',
    'art': 'art', 'arts': 'art', 'exhibition': 'art', 'gallery': 'art', 'art & exhibitions': 'art',
    'theatre': 'art', 'film': 'art', 'performance': 'art', 'design': 'art', 'culture': 'art',
    'food': 'food', 'food & drink': 'food', 'dining': 'food', 'food & markets': 'food',
    'market': 'food', 'brunch': 'food', 'culinary': 'food',
    'wellness': 'wellness', 'yoga': 'wellness', 'meditation': 'wellness', 'fitness': 'wellness',
    'run': 'run-clubs', 'running': 'run-clubs', 'run club': 'run-clubs',
    'hike': 'hikes', 'hiking': 'hikes', 'outdoors': 'hikes', 'nature': 'hikes',
    'coffee': 'coffee-raves', 'coffee rave': 'coffee-raves',
    'workshop': 'workshops', 'workshops': 'workshops', 'class': 'workshops',
    'meetup': 'meetups', 'community': 'meetups', 'networking': 'meetups',
    'family': 'family', 'kids': 'family',
  };
  const CAT_VALID = ['run-clubs', 'wellness', 'hikes', 'coffee-raves', 'workshops', 'meetups', 'nightlife', 'art', 'food', 'family', 'other'];
  const normCat = (raw?: string): string => {
    if (!raw) return '';
    const s = raw.trim().toLowerCase();
    if (CAT_VALID.includes(s)) return s;
    if (CAT_SLUG_MAP[s]) return CAT_SLUG_MAP[s];
    for (const [kw, slug] of Object.entries(CAT_SLUG_MAP)) {
      if (s.includes(kw)) return slug;
    }
    return raw;
  };

  const startEdit = () => {
    setEditing(true);
    // If the event already has coordinates, pre-confirm the place so the UI shows them
    if (event.lat && event.lng && (Number(event.lat) !== 0 || Number(event.lng) !== 0)) {
      setSelectedPlace({
        name: event.venueName || event.title || '',
        formattedAddress: event.address || '',
        lat: Number(event.lat),
        lng: Number(event.lng),
        district: event.district || '',
        placeId: '',
      });
    } else {
      setSelectedPlace(null);
    }
    setVenueCreated(false);
    setShowDuplicateCheck(false);
    setDraft({
      title: event.title,
      description: event.description || '',
      date: normDate(event.date),
      endDate: normDate(event.endDate),
      time: event.time || '',
      category: normCat(event.category),
      venueName: event.venueName || '',
      venueId: event.venueId || '',
      district: event.district || '',
      price: event.price || '',
      lat: event.lat,
      lng: event.lng,
      modeTags: event.modeTags || [],
      vibes: event.vibes || [],
      artists: event.artists || [],
      ticketUrl: event.ticketUrl || '',
      sourceUrl: event.sourceUrl || '',
      editorialHook: event.editorialHook || '',
      editorialHook_zh: event.editorialHook_zh || '',
    });
  };

  const saveEdit = async () => {
    setSaving(true);
    try {
      const updated = { ...event, ...draft };
      const res = await fetch(`${API_BASE}/events/${encodeURIComponent(event.id)}`, {
        method: 'PUT',
        headers: authHeaders(accessToken),
        body: JSON.stringify(updated),
      });
      if (res.ok) {
        const data = await res.json();
        onUpdate(data.event || updated);
        setEditing(false);
      } else {
        console.error('Failed to save event:', await res.text());
      }
    } catch (err) {
      console.error('Error saving event:', err);
    }
    setSaving(false);
  };

  const source = getEventSource(event);
  const quality = getQualityScore(event);

  return (
    <motion.div
      initial={{ opacity: 0, height: 0 }}
      animate={{ opacity: 1, height: 'auto' }}
      exit={{ opacity: 0, height: 0 }}
      className="border-t overflow-hidden"
      style={{ borderColor: T.border, backgroundColor: '#FAFAFA' }}
    >
      <div className="p-5 space-y-4">
        {/* Header row */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <SourceBadge source={source} />
            <span className="text-xs" style={{ color: T.textMuted }}>ID: {event.id}</span>
          </div>
          <div className="flex items-center gap-2">
            {!editing ? (
              <button onClick={startEdit} className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-all hover:opacity-80" style={{ backgroundColor: T.infoLight, color: T.info }}>
                <Pencil size={12} /> Edit
              </button>
            ) : (
              <div className="flex gap-2">
                <button onClick={saveEdit} disabled={saving} className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-all hover:opacity-80" style={{ backgroundColor: T.accentLight, color: T.accent }}>
                  {saving ? <Loader2 size={12} className="animate-spin" /> : <Save size={12} />} Save
                </button>
                <button onClick={() => setEditing(false)} className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-all hover:opacity-80" style={{ backgroundColor: '#F3F4F6', color: T.textMuted }}>
                  <X size={12} /> Cancel
                </button>
              </div>
            )}
            <button onClick={onDelete} className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-all hover:opacity-80" style={{ backgroundColor: T.dangerLight, color: T.danger }}>
              <Trash2 size={12} /> Delete
            </button>
            <button onClick={onClose} className="p-1 rounded" style={{ color: T.textMuted }}>
              <X size={14} />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          {/* Left: Image + quick info */}
          <div className="space-y-3">
            {event.image && (
              <div className="rounded-lg overflow-hidden border" style={{ borderColor: T.border }}>
                <img src={event.image} alt={event.title} className="w-full h-48 object-cover" />
              </div>
            )}
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-xs" style={{ color: T.textMuted }}>
                <BarChart3 size={12} /> Quality Score
              </div>
              <QualityBar value={quality} />
            </div>
            {!editing && (
              <>
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2 text-xs" style={{ color: T.textMuted }}>
                    <Tag size={12} /> Mode Tags
                  </div>
                  <ModeTagPills tags={event.modeTags || []} />
                </div>
                {event.artists && event.artists.length > 0 && (
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-2 text-xs" style={{ color: T.textMuted }}>
                      <Music size={12} /> Artists
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {event.artists.map(a => (
                        <span key={a} className="px-2 py-0.5 text-[11px] rounded-full" style={{ backgroundColor: T.purpleLight, color: T.purple }}>{a}</span>
                      ))}
                    </div>
                  </div>
                )}
              </>
            )}
          </div>

          {/* Middle: Core fields */}
          <div className="space-y-3">
            {editing ? (
              <>
                <Field label="Title" value={draft.title || ''} onChange={v => setDraft(d => ({ ...d, title: v }))} />
                <Field label="Description" value={draft.description || ''} onChange={v => setDraft(d => ({ ...d, description: v }))} multiline />
                <div className="pt-1 pb-1 border-t border-b" style={{ borderColor: '#FEF3C7' }}>
                  <Field label="Editorial Hook (EN)" value={draft.editorialHook || ''} onChange={v => setDraft(d => ({ ...d, editorialHook: v }))} />
                  <div className="mt-1.5">
                    <Field label="Editorial Hook (繁)" value={draft.editorialHook_zh || ''} onChange={v => setDraft(d => ({ ...d, editorialHook_zh: v }))} />
                  </div>
                  <p className="text-[10px] mt-1" style={{ color: T.textMuted, fontStyle: 'italic' }}>One-liner personal voice, e.g. "Feels like someone's living room. Not LKF chaos."</p>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Date" value={draft.date || ''} onChange={v => setDraft(d => ({ ...d, date: v }))} />
                  <Field label="Time" value={draft.time || ''} onChange={v => setDraft(d => ({ ...d, time: v }))} />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <Field label="End Date" value={draft.endDate || ''} onChange={v => setDraft(d => ({ ...d, endDate: v }))} />
                  <Field label="Price" value={draft.price || ''} onChange={v => setDraft(d => ({ ...d, price: v }))} />
                </div>
                {/* Category dropdown */}
                <div>
                  <span className="text-[10px] uppercase tracking-wider font-semibold block mb-1" style={{ color: T.textMuted }}>Category</span>
                  <select
                    value={draft.category || ''}
                    onChange={e => setDraft(d => ({ ...d, category: e.target.value }))}
                    className="w-full px-2.5 py-1.5 text-xs rounded-md outline-none"
                    style={{ border: `1px solid ${T.border}`, backgroundColor: T.surface, color: T.text, fontFamily: T.font }}
                  >
                    <option value="">— Select category —</option>
                    <option value="run-clubs">Run Clubs</option>
                    <option value="wellness">Wellness & Yoga</option>
                    <option value="hikes">Hikes & Outdoors</option>
                    <option value="coffee-raves">Coffee Raves & Social</option>
                    <option value="workshops">Workshops & Classes</option>
                    <option value="meetups">Meetups & Community</option>
                    <option value="nightlife">Nightlife & Music</option>
                    <option value="art">Art & Exhibitions</option>
                    <option value="food">Food & Markets</option>
                    <option value="family">Family & Kids</option>
                    <option value="other">Other</option>
                  </select>
                </div>
                {/* Mode Tags */}
                <EditableTagField
                  label="Mode Tags"
                  icon={<Tag size={11} />}
                  tags={draft.modeTags || []}
                  onChange={tags => setDraft(d => ({ ...d, modeTags: tags }))}
                  presets={['degen', 'artsy', 'foodie', 'family', 'lifestyle']}
                  colorMap={MODE_COLORS}
                />
                {/* Vibes */}
                <EditableTagField
                  label="Vibes"
                  icon={<Sparkles size={11} />}
                  tags={draft.vibes || []}
                  onChange={tags => setDraft(d => ({ ...d, vibes: tags }))}
                  placeholder="Add vibe…"
                />
                {/* Artists */}
                <EditableTagField
                  label="Artists / Performers"
                  icon={<Music size={11} />}
                  tags={draft.artists || []}
                  onChange={tags => setDraft(d => ({ ...d, artists: tags }))}
                  placeholder="Add artist…"
                  tagColor={{ bg: T.purpleLight, text: T.purple }}
                />
              </>
            ) : (
              <>
                <div>
                  <span className="text-[10px] uppercase tracking-wider font-semibold" style={{ color: T.textMuted }}>Title</span>
                  <p className="text-sm font-medium" style={{ color: T.text }}>{event.title}</p>
                </div>
                {event.description && (
                  <div>
                    <span className="text-[10px] uppercase tracking-wider font-semibold" style={{ color: T.textMuted }}>Description</span>
                    <p className="text-xs leading-relaxed line-clamp-4" style={{ color: T.textMuted }}>{event.description}</p>
                  </div>
                )}
                {(event.editorialHook || event.editorialHook_zh) && (
                  <div className="px-2.5 py-2 rounded-md" style={{ backgroundColor: '#FFFBEB', border: '1px solid #FEF3C7' }}>
                    <span className="text-[10px] uppercase tracking-wider font-semibold" style={{ color: '#92400E' }}>Editorial Hook</span>
                    {event.editorialHook && <p className="text-xs italic mt-0.5" style={{ color: '#78350F' }}>"{event.editorialHook}"</p>}
                    {event.editorialHook_zh && <p className="text-xs italic mt-0.5" style={{ color: '#92400E' }}>"{event.editorialHook_zh}"</p>}
                  </div>
                )}
                <div className="grid grid-cols-2 gap-3">
                  <InfoCell icon={Calendar} label="Date" value={displayDate(event.date) || '—'} />
                  <InfoCell icon={Clock} label="Time" value={event.time || '—'} />
                  <InfoCell icon={Tag} label="Category" value={displayCategory(event.category) || '—'} />
                  <InfoCell icon={DollarSign} label="Price" value={event.price || 'Free'} />
                </div>
                {event.endDate && (
                  <InfoCell icon={Calendar} label="End Date" value={displayDate(event.endDate)} />
                )}
              </>
            )}
          </div>

          {/* Right: Location + links */}
          <div className="space-y-3">
            {editing ? (
              <>
                <Field label="Venue Name" value={draft.venueName || ''} onChange={v => setDraft(d => ({ ...d, venueName: v }))} />
                <Field label="District" value={draft.district || ''} onChange={v => setDraft(d => ({ ...d, district: v }))} />

                {/* Google Maps Address Lookup */}
                <div className="pt-2 border-t" style={{ borderColor: T.border }}>
                  <div className="flex items-center gap-1.5 mb-1.5">
                    <MapPin size={11} style={{ color: T.info }} />
                    <span className="text-[10px] uppercase tracking-wider font-semibold" style={{ color: T.info }}>Address Lookup</span>
                  </div>
                  <GooglePlacesAutocomplete
                    value={draft.venueName || ''}
                    onSelect={(place) => {
                      setSelectedPlace(place);
                      setVenueCreated(false);
                      setDraft(d => ({
                        ...d,
                        venueName: place.name,
                        district: place.district || d.district || '',
                        lat: place.lat,
                        lng: place.lng,
                      }));
                    }}
                    placeholder="Search address on Google Maps..."
                    compact
                    selectedPlace={selectedPlace}
                  />

                  {/* Coordinates display / manual entry */}
                  {draft.lat && draft.lng && (
                    <div className="flex gap-2 mt-1.5">
                      <div className="flex-1 px-2 py-1 rounded text-[10px] font-mono flex items-center gap-1.5" style={{ backgroundColor: '#F0FDF4', border: `1px solid ${T.border}`, color: T.accent }}>
                        <Navigation size={9} />
                        {Number(draft.lat).toFixed(5)}, {Number(draft.lng).toFixed(5)}
                        {(() => { const d = reverseDistrictFromCoords(Number(draft.lat), Number(draft.lng)); return d ? <span style={{ color: T.textMuted }}> &middot; {d}</span> : null; })()}
                      </div>
                    </div>
                  )}

                  {/* Manual coordinate entry */}
                  <CoordInput
                    onApply={(lat, lng, district) => {
                      setDraft(d => ({ ...d, lat, lng, district: district || d.district || '' }));
                      setSelectedPlace({
                        name: draft.venueName || '',
                        formattedAddress: '',
                        lat, lng,
                        district: district || '',
                        placeId: '',
                      });
                      setVenueCreated(false);
                    }}
                  />

                  {/* Create Venue button */}
                  {selectedPlace && !showDuplicateCheck && !venueCreated && (
                    <button
                      onClick={() => setShowDuplicateCheck(true)}
                      className="mt-2 flex items-center gap-1.5 px-3 py-1.5 text-[10px] font-medium rounded-md transition-all cursor-pointer"
                      style={{ backgroundColor: T.infoLight, color: T.info }}
                    >
                      <MapPin size={10} /> Create venue from this address
                    </button>
                  )}

                  {/* Duplicate detection flow */}
                  {showDuplicateCheck && !venueCreated && (
                    <div className="mt-2">
                      <DuplicateWarning
                        venueName={draft.venueName || selectedPlace?.name || ''}
                        lat={selectedPlace?.lat}
                        lng={selectedPlace?.lng}
                        compact
                        onLinkExisting={(venue) => {
                          setDraft(d => ({
                            ...d,
                            venueId: venue.id,
                            venueName: venue.name || d.venueName,
                            district: venue.district || d.district || '',
                            lat: venue.lat ?? d.lat,
                            lng: venue.lng ?? d.lng,
                          }));
                          setVenueCreated(true);
                          setShowDuplicateCheck(false);
                        }}
                        onCreateAnyway={async () => {
                          setShowDuplicateCheck(false);
                          if (!accessToken || !selectedPlace) return;
                          setCreatingVenue(true);
                          try {
                            const venueId = `venue_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`;
                            const venueData = {
                              id: venueId,
                              name: draft.venueName || selectedPlace.name,
                              description: '',
                              category: draft.category || event.category || 'other',
                              subcategory: '',
                              lat: selectedPlace.lat,
                              lng: selectedPlace.lng,
                              district: selectedPlace.district || draft.district || '',
                              address: selectedPlace.formattedAddress,
                              image: event.image || '',
                              vibeTags: [],
                              priceRange: 2,
                              modeScores: { degen: 0.5, artsy: 0.5, foodie: 0.5, family: 0.5, lifestyle: 0.5 },
                              upcomingEvents: 1,
                              pastRecaps: 0,
                            };
                            const res = await fetch(`${CMS_BASE}/content/venue`, {
                              method: 'POST',
                              headers: authHeaders(accessToken),
                              body: JSON.stringify(venueData),
                            });
                            if (res.ok) {
                              setDraft(d => ({ ...d, venueId }));
                              setVenueCreated(true);
                              invalidateVenueCache();
                            } else {
                              console.error('Failed to create venue:', await res.text());
                            }
                          } catch (err) {
                            console.error('Create venue error:', err);
                          }
                          setCreatingVenue(false);
                        }}
                        onCancel={() => setShowDuplicateCheck(false)}
                      />
                    </div>
                  )}

                  {/* Creating indicator */}
                  {creatingVenue && (
                    <div className="mt-2 flex items-center gap-1.5 px-3 py-1.5 text-[10px] font-medium rounded-md" style={{ backgroundColor: T.infoLight, color: T.info }}>
                      <Loader2 size={10} className="animate-spin" /> Creating venue…
                    </div>
                  )}

                  {/* Venue created confirmation */}
                  {venueCreated && (
                    <div className="mt-2 flex items-center gap-1.5 px-3 py-1.5 text-[10px] font-medium rounded-md" style={{ backgroundColor: '#E8F0E7', color: T.accent }}>
                      <CheckSquare size={10} /> Venue linked: {draft.venueId}
                    </div>
                  )}
                </div>

                {/* Link Existing Venue */}
                {!venueCreated && (
                  <VenueLinker
                    venueName={draft.venueName || ''}
                    lat={draft.lat}
                    lng={draft.lng}
                    venueId={draft.venueId || undefined}
                    compact
                    onLink={(venue) => {
                      setDraft(d => ({
                        ...d,
                        venueId: venue.id,
                        venueName: venue.name || d.venueName,
                        district: venue.district || d.district || '',
                        lat: venue.lat ?? d.lat,
                        lng: venue.lng ?? d.lng,
                      }));
                      setVenueCreated(true);
                    }}
                    onUnlink={() => {
                      setDraft(d => ({ ...d, venueId: '' }));
                      setVenueCreated(false);
                    }}
                  />
                )}

                {/* Show linked venue status when already linked */}
                {venueCreated && draft.venueId && (
                  <VenueLinker
                    venueName={draft.venueName || ''}
                    venueId={draft.venueId}
                    compact
                    onLink={() => {}}
                    onUnlink={() => {
                      setDraft(d => ({ ...d, venueId: '' }));
                      setVenueCreated(false);
                    }}
                  />
                )}
              </>
            ) : (
              <>
                <InfoCell icon={MapPin} label="Venue" value={event.venueName || '—'} />
                <InfoCell icon={MapPin} label="District" value={event.district || '—'} />
                {event.lat && event.lng && (
                  <InfoCell icon={Globe} label="Coordinates" value={`${event.lat.toFixed(4)}, ${event.lng.toFixed(4)}`} />
                )}
              </>
            )}
            {editing ? (
              <>
                <Field label="Ticket URL" value={draft.ticketUrl || ''} onChange={v => setDraft(d => ({ ...d, ticketUrl: v }))} placeholder="https://..." />
                <Field label="Source URL" value={draft.sourceUrl || ''} onChange={v => setDraft(d => ({ ...d, sourceUrl: v }))} placeholder="https://..." />
              </>
            ) : (
              <>
                {event.ticketUrl && (
                  <a href={event.ticketUrl} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-xs font-medium transition-opacity hover:opacity-70" style={{ color: T.info }}>
                    <Ticket size={12} /> Get Tickets <ExternalLink size={10} />
                  </a>
                )}
                {event.sourceUrl && (
                  <a href={event.sourceUrl} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-xs font-medium transition-opacity hover:opacity-70" style={{ color: T.purple }}>
                    <Instagram size={12} /> View Source <ExternalLink size={10} />
                  </a>
                )}
                {event.vibes && event.vibes.length > 0 && (
                  <div className="space-y-1.5">
                    <span className="text-[10px] uppercase tracking-wider font-semibold" style={{ color: T.textMuted }}>Vibes</span>
                    <div className="flex flex-wrap gap-1">
                      {event.vibes.map(v => (
                        <span key={v} className="px-2 py-0.5 text-[10px] rounded-full" style={{ backgroundColor: '#F3F4F6', color: T.textMuted }}>{v}</span>
                      ))}
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function InfoCell({ icon: Icon, label, value }: { icon: typeof Calendar; label: string; value: string }) {
  return (
    <div>
      <div className="flex items-center gap-1.5 mb-0.5">
        <Icon size={11} style={{ color: T.textMuted }} />
        <span className="text-[10px] uppercase tracking-wider font-semibold" style={{ color: T.textMuted }}>{label}</span>
      </div>
      <p className="text-xs font-medium" style={{ color: T.text }}>{value}</p>
    </div>
  );
}

function Field({ label, value, onChange, multiline, placeholder }: {
  label: string; value: string; onChange: (v: string) => void; multiline?: boolean; placeholder?: string;
}) {
  return (
    <div>
      <label className="text-[10px] uppercase tracking-wider font-semibold block mb-1" style={{ color: T.textMuted }}>{label}</label>
      {multiline ? (
        <textarea
          value={value}
          onChange={e => onChange(e.target.value)}
          rows={3}
          placeholder={placeholder}
          className="w-full px-2.5 py-1.5 text-xs rounded-md border focus:outline-none focus:ring-2"
          style={{ borderColor: T.border, color: T.text, fontFamily: T.font, resize: 'vertical' }}
        />
      ) : (
        <input
          type="text"
          value={value}
          onChange={e => onChange(e.target.value)}
          placeholder={placeholder}
          className="w-full px-2.5 py-1.5 text-xs rounded-md border focus:outline-none focus:ring-2"
          style={{ borderColor: T.border, color: T.text, fontFamily: T.font }}
        />
      )}
    </div>
  );
}

/** Inline coordinate entry for the admin Event Manager */
function CoordInput({ onApply }: { onApply: (lat: number, lng: number, district?: string) => void }) {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState('');
  const [parsed, setParsed] = useState<{ lat: number; lng: number } | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleChange = (val: string) => {
    setInput(val);
    const coords = parseCoordinates(val);
    setParsed(coords);
  };

  const handleApply = () => {
    if (!parsed) return;
    const district = reverseDistrictFromCoords(parsed.lat, parsed.lng);
    onApply(parsed.lat, parsed.lng, district);
    setInput('');
    setParsed(null);
    setOpen(false);
  };

  if (!open) {
    return (
      <button
        type="button"
        onClick={() => { setOpen(true); setTimeout(() => inputRef.current?.focus(), 50); }}
        className="mt-1.5 flex items-center gap-1.5 px-2 py-1 text-[10px] font-medium rounded transition-all cursor-pointer hover:opacity-80"
        style={{ backgroundColor: '#F5F3FF', color: '#7C3AED', border: '1px solid #EDE9FE' }}
      >
        <Navigation size={9} />
        Enter coordinates manually
      </button>
    );
  }

  return (
    <div className="mt-1.5 p-2 rounded-md" style={{ backgroundColor: '#F5F3FF', border: '1px solid #EDE9FE' }}>
      <div className="flex items-center gap-1.5 mb-1.5">
        <Navigation size={10} style={{ color: '#7C3AED' }} />
        <span className="text-[10px] uppercase tracking-wider font-semibold" style={{ color: '#7C3AED' }}>Manual Coordinates</span>
        <button
          type="button"
          onClick={() => { setOpen(false); setInput(''); setParsed(null); }}
          className="ml-auto p-0.5 rounded hover:bg-black/5 cursor-pointer"
        >
          <X size={10} style={{ color: T.textMuted }} />
        </button>
      </div>
      <div className="flex gap-1.5">
        <input
          ref={inputRef}
          type="text"
          value={input}
          onChange={e => handleChange(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter' && parsed) handleApply(); }}
          placeholder={'22°19\'41.5"N 114°09\'36.4"E  or  22.3282, 114.1601'}
          className="flex-1 px-2 py-1 text-[11px] rounded border focus:outline-none focus:ring-1"
          style={{ borderColor: T.border, color: T.text, fontFamily: 'monospace', fontSize: '10px' }}
        />
        <button
          type="button"
          onClick={handleApply}
          disabled={!parsed}
          className="px-2 py-1 text-[10px] font-medium rounded transition-all cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
          style={{ backgroundColor: parsed ? T.accent : T.border, color: '#fff' }}
        >
          Apply
        </button>
      </div>
      {input && parsed && (
        <p className="text-[10px] mt-1 flex items-center gap-1" style={{ color: T.accent }}>
          <Navigation size={8} />
          {parsed.lat.toFixed(5)}, {parsed.lng.toFixed(5)}
          {(() => { const d = reverseDistrictFromCoords(parsed.lat, parsed.lng); return d ? <span style={{ color: T.textMuted }}> &middot; {d}</span> : null; })()}
        </p>
      )}
      {input && !parsed && input.length >= 3 && (
        <p className="text-[10px] mt-1 flex items-center gap-1" style={{ color: T.textMuted }}>
          <AlertTriangle size={8} />
          Couldn't parse. Try: 22°19'41.5"N 114°09'36.4"E or 22.3282, 114.1601
        </p>
      )}
    </div>
  );
}

/** Editable tag field with presets and free-form input */
function EditableTagField({ label, icon, tags, onChange, presets, colorMap, placeholder, tagColor }: {
  label: string;
  icon?: React.ReactNode;
  tags: string[];
  onChange: (tags: string[]) => void;
  presets?: string[];
  colorMap?: Record<string, string>;
  placeholder?: string;
  tagColor?: { bg: string; text: string };
}) {
  const [input, setInput] = useState('');

  const addTag = (tag: string) => {
    const t = tag.trim().toLowerCase();
    if (t && !tags.includes(t)) onChange([...tags, t]);
    setInput('');
  };

  const removeTag = (tag: string) => {
    onChange(tags.filter(t => t !== tag));
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault();
      addTag(input);
    }
  };

  return (
    <div>
      <div className="flex items-center gap-1.5 mb-1">
        {icon}
        <span className="text-[10px] uppercase tracking-wider font-semibold" style={{ color: T.textMuted }}>{label}</span>
      </div>
      <div className="flex flex-wrap gap-1 mb-1.5">
        {tags.map(tag => {
          const bgColor = colorMap?.[tag]
            ? (tag === 'artsy' ? colorMap[tag] : `${colorMap[tag]}22`)
            : tagColor?.bg || '#F3F4F6';
          const txtColor = colorMap?.[tag]
            ? (tag === 'artsy' ? '#FFFFFF' : colorMap[tag])
            : tagColor?.text || T.textMuted;
          return (
            <span
              key={tag}
              className="inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-medium rounded-full cursor-pointer transition-opacity hover:opacity-70"
              style={{ backgroundColor: bgColor, color: txtColor }}
              onClick={() => removeTag(tag)}
              title="Click to remove"
            >
              {tag}
              <X size={8} />
            </span>
          );
        })}
      </div>
      {/* Preset chips for quick add */}
      {presets && presets.length > 0 && (
        <div className="flex flex-wrap gap-1 mb-1.5">
          {presets.filter(p => !tags.includes(p)).map(p => {
            const bgColor = colorMap?.[p] ? `${colorMap[p]}11` : '#FAFAFA';
            const borderColor = colorMap?.[p] || T.border;
            return (
              <button
                key={p}
                onClick={() => addTag(p)}
                className="px-2 py-0.5 text-[10px] rounded-full border transition-all hover:opacity-80 cursor-pointer"
                style={{ borderColor, color: T.textMuted, backgroundColor: bgColor }}
              >
                + {p}
              </button>
            );
          })}
        </div>
      )}
      <input
        type="text"
        value={input}
        onChange={e => setInput(e.target.value)}
        onKeyDown={handleKeyDown}
        onBlur={() => input.trim() && addTag(input)}
        placeholder={placeholder || 'Type and press Enter…'}
        className="w-full px-2.5 py-1 text-[11px] rounded-md border focus:outline-none focus:ring-1"
        style={{ borderColor: T.border, color: T.text, fontFamily: T.font }}
      />
    </div>
  );
}

// ─── Main EventManager ───
export function EventManager() {
  const { accessToken } = useOutletContext<{ accessToken: string }>();
  const { refresh: refreshData } = useData();
  const [events, setEvents] = useState<EventItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [sourceFilter, setSourceFilter] = useState<SourceFilter>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [modeFilter, setModeFilter] = useState<string>('all');
  const [sortField, setSortField] = useState<SortField>('date');
  const [sortDir, setSortDir] = useState<SortDir>('desc');
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [deleting, setDeleting] = useState(false);
  const [stats, setStats] = useState<Record<string, number>>({});

  // Bulk AI Enrich & Push to CMS
  const [showBulkModal, setShowBulkModal] = useState<'enrich' | 'push' | null>(null);
  const [recovering, setRecovering] = useState(false);
  const [autoCreatingVenues, setAutoCreatingVenues] = useState(false);
  const [bulkProgress, setBulkProgress] = useState<{
    phase: 'idle' | 'processing' | 'done';
    current: number;
    total: number;
    results: { id: string; title: string; status: string; fieldsEnriched?: string[]; error?: string; duplicateOf?: string }[];
  }>({ phase: 'idle', current: 0, total: 0, results: [] });

  const fetchEvents = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/events`, {
        headers: { Authorization: `Bearer ${publicAnonKey}` },
      });
      const data = await res.json();
      const evts = (data.events || []) as EventItem[];
      setEvents(evts);

      // Calculate stats
      const s: Record<string, number> = { total: evts.length, mock: 0, ra: 0, lsa: 0, apify: 0, community: 0, cms: 0, unknown: 0 };
      evts.forEach(e => { s[getEventSource(e)] = (s[getEventSource(e)] || 0) + 1; });
      setStats(s);
    } catch (err) {
      console.error('Failed to fetch events:', err);
    }
    setLoading(false);
  }, []);

  // Attempt to recover imported events from CMS content store
  const recoverEvents = useCallback(async () => {
    setRecovering(true);
    try {
      const res = await fetch(`${API_BASE}/admin/recover-events`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${publicAnonKey}` },
      });
      const data = await res.json();
      console.log('[EventManager] Recovery result:', data);
      if (data.restored > 0) {
        alert(`Recovered ${data.restored} imported events from CMS store! Refreshing...`);
        await fetchEvents();
      } else {
        alert(`No recoverable events found. ${data.message || `Skipped: ${data.skipped || 0}`}`);
      }
    } catch (err) {
      console.error('Recovery failed:', err);
      alert('Recovery failed — check console for details.');
    }
    setRecovering(false);
  }, [fetchEvents]);

  // Auto-create venues from imported events via Google Places
  const autoCreateVenues = useCallback(async () => {
    if (!accessToken) {
      alert('Not authenticated. Please log in first.');
      return;
    }
    setAutoCreatingVenues(true);
    try {
      const res = await fetch(`${CMS_BASE}/venues/auto-create-from-events`, {
        method: 'POST',
        headers: authHeaders(accessToken),
      });
      const data = await res.json();
      console.log('[EventManager] Auto-create venues result:', data);
      if (data.error) {
        alert(`Error: ${data.error}`);
      } else {
        const s = data.summary;
        const lines = [
          `✅ ${s.created} venue${s.created !== 1 ? 's' : ''} created via Google Places`,
          s.existing > 0 ? `⏭️ ${s.existing} already existed (skipped)` : '',
          s.notFound > 0 ? `❌ ${s.notFound} not found on Google` : '',
          s.errors > 0 ? `⚠️ ${s.errors} errors` : '',
          `📍 ${s.googleLookups} Google Places API calls made`,
          s.eventsLinked > 0 ? `🔗 ${s.eventsLinked} events linked to venues (with confirmed coordinates)` : '',
        ].filter(Boolean);
        alert(lines.join('\n'));
        invalidateVenueCache();
      }
    } catch (err) {
      console.error('Auto-create venues failed:', err);
      alert('Auto-create venues failed — check console for details.');
    }
    setAutoCreatingVenues(false);
  }, [accessToken]);

  useEffect(() => { fetchEvents(); }, [fetchEvents]);

  // Get unique categories and modes
  const categories = useMemo(() => {
    const cats = new Set<string>();
    events.forEach(e => {
      if (e.category) cats.add(e.category);
      (e.categories || []).forEach(c => cats.add(c));
    });
    return [...cats].sort();
  }, [events]);

  const modes = useMemo(() => {
    const m = new Set<string>();
    events.forEach(e => (e.modeTags || []).forEach(t => m.add(t)));
    return [...m].sort();
  }, [events]);

  // Filtered + sorted events
  const filteredEvents = useMemo(() => {
    let result = [...events];

    // Source filter
    if (sourceFilter !== 'all') {
      result = result.filter(e => getEventSource(e) === sourceFilter);
    }

    // Category filter
    if (categoryFilter !== 'all') {
      result = result.filter(e =>
        e.category === categoryFilter ||
        (e.categories || []).includes(categoryFilter)
      );
    }

    // Mode filter
    if (modeFilter !== 'all') {
      result = result.filter(e => (e.modeTags || []).includes(modeFilter));
    }

    // Search
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(e =>
        e.title?.toLowerCase().includes(q) ||
        e.venueName?.toLowerCase().includes(q) ||
        e.district?.toLowerCase().includes(q) ||
        e.id?.toLowerCase().includes(q) ||
        (e.artists || []).some(a => a.toLowerCase().includes(q)) ||
        e.description?.toLowerCase().includes(q)
      );
    }

    // Sort
    result.sort((a, b) => {
      let cmp = 0;
      switch (sortField) {
        case 'title': cmp = (a.title || '').localeCompare(b.title || ''); break;
        case 'date': cmp = (a.date || '').localeCompare(b.date || ''); break;
        case 'category': cmp = (a.category || '').localeCompare(b.category || ''); break;
        case 'district': cmp = (a.district || '').localeCompare(b.district || ''); break;
        case 'quality': cmp = getQualityScore(a) - getQualityScore(b); break;
        case 'dateAdded': cmp = (a._createdAt || '').localeCompare(b._createdAt || ''); break;
      }
      return sortDir === 'asc' ? cmp : -cmp;
    });

    return result;
  }, [events, sourceFilter, categoryFilter, modeFilter, searchQuery, sortField, sortDir]);

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDir('asc');
    }
  };

  const toggleSelect = (id: string) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const toggleSelectAll = () => {
    if (selectedIds.size === filteredEvents.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filteredEvents.map(e => e.id)));
    }
  };

  const deleteEvent = async (id: string) => {
    try {
      await fetch(`${API_BASE}/events/${encodeURIComponent(id)}`, {
        method: 'DELETE',
        headers: authHeaders(accessToken),
      });
      setEvents(prev => prev.filter(e => e.id !== id));
      if (expandedId === id) setExpandedId(null);
      selectedIds.delete(id);
      setSelectedIds(new Set(selectedIds));
      // Refresh site-wide DataContext cache
      try { sessionStorage.removeItem('cultive_data_cache'); } catch {}
      refreshData();
    } catch (err) {
      console.error('Failed to delete event:', err);
    }
  };

  const bulkDelete = async () => {
    if (selectedIds.size === 0) return;
    if (!confirm(`Delete ${selectedIds.size} event${selectedIds.size > 1 ? 's' : ''}? This cannot be undone.`)) return;
    setDeleting(true);
    for (const id of selectedIds) {
      await deleteEvent(id);
    }
    setSelectedIds(new Set());
    setDeleting(false);
    // Refresh site-wide DataContext cache
    try { sessionStorage.removeItem('cultive_data_cache'); } catch {}
    await refreshData();
    fetchEvents();
  };

  const handleUpdate = (updated: EventItem) => {
    setEvents(prev => prev.map(e => e.id === updated.id ? updated : e));
  };

  // ─── Bulk AI Enrich ───
  const bulkEnrich = async () => {
    const ids = [...selectedIds];
    if (ids.length === 0) return;
    setShowBulkModal('enrich');
    setBulkProgress({ phase: 'processing', current: 0, total: ids.length, results: [] });

    // Process in batches of 25 (server handles internal batching with Gemini)
    const BATCH = 25;
    const allResults: typeof bulkProgress.results = [];

    for (let i = 0; i < ids.length; i += BATCH) {
      const batch = ids.slice(i, i + BATCH);
      try {
        const res = await fetch(`${CMS_BASE}/events/bulk-enrich`, {
          method: 'POST',
          headers: authHeaders(accessToken),
          body: JSON.stringify({ eventIds: batch }),
        });
        if (!res.ok) {
          const errData = await res.json().catch(() => ({ error: `HTTP ${res.status}` }));
          console.error('Bulk enrich batch HTTP error:', res.status, errData);
          batch.forEach(id => allResults.push({ id, title: events.find(e => e.id === id)?.title || id, status: 'error', error: errData.error || `HTTP ${res.status}` }));
        } else {
          const data = await res.json();
          if (data.results) {
            const mapped = data.results.map((r: any) => ({
              ...r,
              title: events.find(e => e.id === r.id)?.title || r.id,
            }));
            allResults.push(...mapped);
          } else if (data.error) {
            console.error('Bulk enrich server error:', data.error);
            batch.forEach(id => allResults.push({ id, title: events.find(e => e.id === id)?.title || id, status: 'error', error: data.error }));
          }
        }
      } catch (err) {
        console.error('Bulk enrich batch error:', err);
        batch.forEach(id => allResults.push({ id, title: events.find(e => e.id === id)?.title || id, status: 'error', error: String(err) }));
      }
      setBulkProgress({ phase: 'processing', current: Math.min(i + BATCH, ids.length), total: ids.length, results: [...allResults] });
    }

    setBulkProgress({ phase: 'done', current: ids.length, total: ids.length, results: allResults });
    // Refresh events to show updated data
    fetchEvents();
  };

  // ─── Bulk Push to CMS ───
  const bulkPushToCms = async () => {
    const ids = [...selectedIds];
    if (ids.length === 0) return;
    setShowBulkModal('push');
    setBulkProgress({ phase: 'processing', current: 0, total: ids.length, results: [] });

    try {
      const res = await fetch(`${CMS_BASE}/events/bulk-push`, {
        method: 'POST',
        headers: authHeaders(accessToken),
        body: JSON.stringify({ eventIds: ids }),
      });
      const data = await res.json();
      if (data.results) {
        const mapped = data.results.map((r: any) => ({
          ...r,
          title: events.find(e => e.id === r.id)?.title || r.id,
        }));
        setBulkProgress({ phase: 'done', current: ids.length, total: ids.length, results: mapped });
      } else if (data.error) {
        console.error('Bulk push error:', data.error);
        setBulkProgress({ phase: 'done', current: 0, total: ids.length, results: [{ id: '', title: 'Error', status: 'error', error: data.error }] });
      }
    } catch (err) {
      console.error('Bulk push error:', err);
      setBulkProgress({ phase: 'done', current: 0, total: ids.length, results: [{ id: '', title: 'Error', status: 'error', error: String(err) }] });
    }
  };

  const SortHeader = ({ field, children, className }: { field: SortField; children: React.ReactNode; className?: string }) => (
    <button
      onClick={() => toggleSort(field)}
      className={`flex items-center gap-1 text-[10px] uppercase tracking-wider font-semibold transition-colors hover:opacity-70 ${className || ''}`}
      style={{ color: sortField === field ? T.text : T.textMuted }}
    >
      {children}
      {sortField === field && (sortDir === 'asc' ? <ChevronUp size={10} /> : <ChevronDown size={10} />)}
    </button>
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center py-32">
        <div className="text-center">
          <Loader2 size={24} className="animate-spin mx-auto mb-3" style={{ color: T.textMuted }} />
          <p className="text-sm" style={{ color: T.textMuted }}>Loading events…</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6" style={{ fontFamily: T.font }}>
      {/* Page header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold" style={{ color: T.text }}>Event Manager</h1>
          <p className="text-sm mt-1" style={{ color: T.textMuted }}>
            {events.length} total event{events.length !== 1 ? 's' : ''} · {filteredEvents.length} shown
          </p>
        </div>
        <div className="flex items-center gap-2">
          {selectedIds.size > 0 && (
            <>
              <button
                onClick={bulkEnrich}
                className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg transition-all hover:opacity-80"
                style={{ backgroundColor: T.purpleLight, color: T.purple }}
              >
                <Sparkles size={12} />
                AI Enrich {selectedIds.size}
              </button>
              <button
                onClick={bulkPushToCms}
                className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg transition-all hover:opacity-80"
                style={{ backgroundColor: T.accentLight, color: T.accent }}
              >
                <Database size={12} />
                Push to CMS {selectedIds.size}
              </button>
              <button
                onClick={bulkDelete}
                disabled={deleting}
                className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg transition-all hover:opacity-80"
                style={{ backgroundColor: T.dangerLight, color: T.danger }}
              >
                {deleting ? <Loader2 size={12} className="animate-spin" /> : <Trash2 size={12} />}
                Delete {selectedIds.size}
              </button>
            </>
          )}
          <button
            onClick={recoverEvents}
            disabled={recovering}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg transition-all hover:opacity-80"
            style={{ backgroundColor: '#DBEAFE', color: '#1E40AF' }}
            title="Scan CMS content store for imported events and restore them to the main event store"
          >
            {recovering ? <Loader2 size={12} className="animate-spin" /> : <Database size={12} />}
            Recover Imports
          </button>
          <button
            onClick={autoCreateVenues}
            disabled={autoCreatingVenues}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg transition-all hover:opacity-80"
            style={{ backgroundColor: '#D1FAE5', color: '#065F46' }}
            title="Scan all imported events, extract unique venue names, look them up on Google Places, and auto-create venue records with confirmed coordinates"
          >
            {autoCreatingVenues ? <Loader2 size={12} className="animate-spin" /> : <Building2 size={12} />}
            Auto-Create Venues
          </button>
          <button
            onClick={fetchEvents}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg transition-all hover:opacity-80"
            style={{ backgroundColor: T.accentLight, color: T.accent }}
          >
            <RefreshCw size={12} /> Refresh
          </button>
        </div>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {[
          { label: 'Total', value: stats.total || 0, color: T.text, bg: T.surface },
          { label: 'Mock', value: stats.mock || 0, color: '#92400E', bg: '#FEF3C7' },
          { label: 'RA Imports', value: stats.ra || 0, color: '#1E40AF', bg: '#DBEAFE' },
          { label: 'LSA Imports', value: stats.lsa || 0, color: '#0F766E', bg: '#CCFBF1' },
          { label: 'Apify Imports', value: stats.apify || 0, color: '#06B6D4', bg: '#F0F9FF' },
          { label: 'Community', value: stats.community || 0, color: '#4338CA', bg: '#E0E7FF' },
          { label: 'CMS', value: stats.cms || 0, color: '#065F46', bg: '#D1FAE5' },
          { label: 'Other', value: stats.unknown || 0, color: '#6B7280', bg: '#F3F4F6' },
        ].map(s => (
          <div
            key={s.label}
            className="p-3 rounded-xl border cursor-pointer transition-all hover:shadow-sm"
            style={{ borderColor: T.border, backgroundColor: sourceFilter === s.label.toLowerCase().replace(' imports', '') ? `${s.color}08` : T.surface }}
            onClick={() => setSourceFilter(s.label === 'Total' ? 'all' : s.label.toLowerCase().replace(' imports', '') as SourceFilter)}
          >
            <p className="text-lg font-semibold" style={{ color: s.color }}>{s.value}</p>
            <p className="text-[10px] font-medium uppercase tracking-wider" style={{ color: T.textMuted }}>{s.label}</p>
          </div>
        ))}
      </div>

      {/* Filters bar */}
      <div className="flex flex-wrap items-center gap-3 p-3 rounded-xl border" style={{ borderColor: T.border, backgroundColor: T.surface }}>
        {/* Search */}
        <div className="relative flex-1 min-w-[200px]">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: T.textMuted }} />
          <input
            type="text"
            placeholder="Search title, venue, artist, district…"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs rounded-lg border focus:outline-none focus:ring-2"
            style={{ borderColor: T.border, color: T.text, fontFamily: T.font }}
          />
        </div>

        {/* Source filter */}
        <div className="flex items-center gap-1.5">
          <Filter size={12} style={{ color: T.textMuted }} />
          <select
            value={sourceFilter}
            onChange={e => setSourceFilter(e.target.value as SourceFilter)}
            className="text-xs py-2 px-2 rounded-lg border focus:outline-none"
            style={{ borderColor: T.border, color: T.text, fontFamily: T.font }}
          >
            <option value="all">All Sources</option>
            <option value="mock">Mock</option>
            <option value="ra">RA</option>
            <option value="lsa">LSA</option>
            <option value="apify">Apify</option>
            <option value="community">Community</option>
            <option value="cms">CMS</option>
          </select>
        </div>

        {/* Category filter */}
        <select
          value={categoryFilter}
          onChange={e => setCategoryFilter(e.target.value)}
          className="text-xs py-2 px-2 rounded-lg border focus:outline-none"
          style={{ borderColor: T.border, color: T.text, fontFamily: T.font }}
        >
          <option value="all">All Categories</option>
          {categories.map(c => <option key={c} value={c}>{c}</option>)}
        </select>

        {/* Mode filter */}
        <select
          value={modeFilter}
          onChange={e => setModeFilter(e.target.value)}
          className="text-xs py-2 px-2 rounded-lg border focus:outline-none"
          style={{ borderColor: T.border, color: T.text, fontFamily: T.font }}
        >
          <option value="all">All Modes</option>
          {modes.map(m => <option key={m} value={m}>{m}</option>)}
        </select>

        {(sourceFilter !== 'all' || categoryFilter !== 'all' || modeFilter !== 'all' || searchQuery) && (
          <button
            onClick={() => { setSourceFilter('all'); setCategoryFilter('all'); setModeFilter('all'); setSearchQuery(''); }}
            className="flex items-center gap-1 px-2 py-1.5 text-[10px] font-medium rounded-md"
            style={{ color: T.danger, backgroundColor: T.dangerLight }}
          >
            <X size={10} /> Clear
          </button>
        )}
      </div>

      {/* Event table */}
      <div className="border rounded-xl overflow-hidden" style={{ borderColor: T.border, backgroundColor: T.surface }}>
        {/* Table header */}
        <div className="grid grid-cols-[32px_1fr_100px_90px_100px_80px_90px_80px] gap-3 px-4 py-3 border-b items-center" style={{ borderColor: T.border, backgroundColor: '#FAFAFA' }}>
          <div>
            <button onClick={toggleSelectAll} className="p-0.5" style={{ color: T.textMuted }}>
              {selectedIds.size === filteredEvents.length && filteredEvents.length > 0 ? <CheckSquare size={14} /> : <Square size={14} />}
            </button>
          </div>
          <SortHeader field="title">Event</SortHeader>
          <SortHeader field="date">Date</SortHeader>
          <SortHeader field="dateAdded">Added</SortHeader>
          <SortHeader field="category">Category</SortHeader>
          <SortHeader field="district">District</SortHeader>
          <span className="text-[10px] uppercase tracking-wider font-semibold" style={{ color: T.textMuted }}>Source</span>
          <SortHeader field="quality">Quality</SortHeader>
        </div>

        {/* Event rows */}
        {filteredEvents.length === 0 ? (
          <div className="text-center py-16">
            <Calendar size={24} className="mx-auto mb-3" style={{ color: T.textMuted }} />
            <p className="text-sm" style={{ color: T.textMuted }}>No events match your filters</p>
          </div>
        ) : (
          <div className="divide-y" style={{ borderColor: T.border }}>
            {filteredEvents.map(event => {
              const source = getEventSource(event);
              const quality = getQualityScore(event);
              const isExpanded = expandedId === event.id;

              return (
                <div key={event.id}>
                  <div
                    className="grid grid-cols-[32px_1fr_100px_90px_100px_80px_90px_80px] gap-3 px-4 py-3 items-center transition-colors hover:bg-gray-50 cursor-pointer"
                    onClick={() => setExpandedId(isExpanded ? null : event.id)}
                  >
                    {/* Select */}
                    <div onClick={e => { e.stopPropagation(); toggleSelect(event.id); }}>
                      {selectedIds.has(event.id) ? (
                        <CheckSquare size={14} style={{ color: T.accent }} />
                      ) : (
                        <Square size={14} style={{ color: T.textMuted }} />
                      )}
                    </div>

                    {/* Title + venue */}
                    <div className="flex items-center gap-3 min-w-0">
                      {event.image ? (
                        <img src={event.image} alt="" className="w-10 h-10 rounded-lg object-cover flex-shrink-0" />
                      ) : (
                        <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: '#F3F4F6' }}>
                          <ImageIcon size={14} style={{ color: T.textMuted }} />
                        </div>
                      )}
                      <div className="min-w-0">
                        <p className="text-xs font-medium truncate" style={{ color: T.text }}>{event.title}</p>
                        <p className="text-[11px] truncate" style={{ color: T.textMuted }}>{event.venueName || '—'}</p>
                      </div>
                    </div>

                    {/* Date */}
                    <span className="text-xs" style={{ color: T.textMuted }}>{displayDate(event.date) || '—'}</span>

                    {/* Date Added */}
                    <span className="text-[11px]" style={{ color: T.textMuted }} title={event._createdAt || ''}>
                      {event._createdAt ? new Date(event._createdAt).toLocaleDateString('en-GB', { day: '2-digit', month: 'short' }) : '—'}
                    </span>

                    {/* Category */}
                    <span className="text-xs truncate" style={{ color: T.textMuted }}>{displayCategory(event.category) || '—'}</span>

                    {/* District */}
                    <span className="text-xs truncate" style={{ color: T.textMuted }}>{event.district || '—'}</span>

                    {/* Source */}
                    <SourceBadge source={source} />

                    {/* Quality */}
                    <div className="w-full">
                      <QualityBar value={quality} />
                    </div>
                  </div>

                  {/* Expanded detail */}
                  <AnimatePresence>
                    {isExpanded && (
                      <EventDetailPanel
                        event={event}
                        onUpdate={handleUpdate}
                        onClose={() => setExpandedId(null)}
                        onDelete={() => deleteEvent(event.id)}
                        accessToken={accessToken}
                      />
                    )}
                  </AnimatePresence>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Footer stats */}
      <div className="text-center py-4">
        <p className="text-xs" style={{ color: T.textMuted }}>
          Showing {filteredEvents.length} of {events.length} events
          {selectedIds.size > 0 && ` · ${selectedIds.size} selected`}
        </p>
      </div>

      {/* ─── Bulk Action Modal ─── */}
      <AnimatePresence>
        {showBulkModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center"
            style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}
            onClick={(e) => { if (bulkProgress.phase === 'done') { setShowBulkModal(null); setBulkProgress({ phase: 'idle', current: 0, total: 0, results: [] }); } }}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-2xl max-h-[80vh] overflow-hidden rounded-2xl border shadow-2xl flex flex-col"
              style={{ backgroundColor: T.surface, borderColor: T.border, fontFamily: T.font }}
            >
              {/* Modal Header */}
              <div className="px-6 py-4 border-b flex items-center justify-between" style={{ borderColor: T.border }}>
                <div className="flex items-center gap-3">
                  {showBulkModal === 'enrich' ? (
                    <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ backgroundColor: T.purpleLight }}>
                      <Sparkles size={18} style={{ color: T.purple }} />
                    </div>
                  ) : (
                    <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ backgroundColor: T.accentLight }}>
                      <Database size={18} style={{ color: T.accent }} />
                    </div>
                  )}
                  <div>
                    <h2 className="text-sm font-semibold" style={{ color: T.text }}>
                      {showBulkModal === 'enrich' ? 'AI Bulk Enrichment' : 'Push to Site Content'}
                    </h2>
                    <p className="text-[11px]" style={{ color: T.textMuted }}>
                      {showBulkModal === 'enrich'
                        ? 'Gemini AI fills missing descriptions, mode tags, categories, vibes & more'
                        : 'Copy selected events to CMS so they appear on the live website'}
                    </p>
                  </div>
                </div>
                {bulkProgress.phase === 'done' && (
                  <button
                    onClick={() => { setShowBulkModal(null); setBulkProgress({ phase: 'idle', current: 0, total: 0, results: [] }); }}
                    className="p-1.5 rounded-md transition-colors hover:bg-gray-100"
                    style={{ color: T.textMuted }}
                  >
                    <X size={16} />
                  </button>
                )}
              </div>

              {/* Progress Bar */}
              {bulkProgress.phase === 'processing' && (
                <div className="px-6 py-3 border-b" style={{ borderColor: T.border }}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-medium" style={{ color: T.text }}>
                      Processing {bulkProgress.current} of {bulkProgress.total}…
                    </span>
                    <span className="text-xs font-medium tabular-nums" style={{ color: T.purple }}>
                      {Math.round((bulkProgress.current / bulkProgress.total) * 100)}%
                    </span>
                  </div>
                  <div className="h-2 rounded-full overflow-hidden" style={{ backgroundColor: T.border }}>
                    <motion.div
                      className="h-full rounded-full"
                      style={{ backgroundColor: showBulkModal === 'enrich' ? T.purple : T.accent }}
                      initial={{ width: 0 }}
                      animate={{ width: `${(bulkProgress.current / bulkProgress.total) * 100}%` }}
                      transition={{ duration: 0.3 }}
                    />
                  </div>
                  <div className="flex items-center gap-2 mt-2">
                    <Loader2 size={12} className="animate-spin" style={{ color: T.purple }} />
                    <span className="text-[11px]" style={{ color: T.textMuted }}>
                      {showBulkModal === 'enrich' ? 'Sending to Gemini AI…' : 'Writing to CMS…'}
                    </span>
                  </div>
                </div>
              )}

              {/* Done Summary */}
              {bulkProgress.phase === 'done' && (
                <div className="px-6 py-3 border-b" style={{ borderColor: T.border, backgroundColor: '#FAFAFA' }}>
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ backgroundColor: T.accentLight }}>
                      <Check size={16} style={{ color: T.accent }} />
                    </div>
                    <div>
                      <p className="text-sm font-medium" style={{ color: T.text }}>
                        {showBulkModal === 'enrich' ? 'Enrichment Complete' : 'Push Complete'}
                      </p>
                      <p className="text-[11px]" style={{ color: T.textMuted }}>
                        {(() => {
                          const success = bulkProgress.results.filter(r => r.status === 'enriched' || r.status === 'pushed').length;
                          const duplicates = bulkProgress.results.filter(r => r.status === 'duplicate').length;
                          const skipped = bulkProgress.results.filter(r => r.status === 'already_complete' || r.status === 'no_changes').length;
                          const failed = bulkProgress.results.filter(r => ['error', 'parse_error', 'gemini_failed', 'not_found'].includes(r.status)).length;
                          const parts = [];
                          if (success) parts.push(`${success} succeeded`);
                          if (duplicates) parts.push(`${duplicates} duplicate${duplicates !== 1 ? 's' : ''} blocked`);
                          if (skipped) parts.push(`${skipped} skipped`);
                          if (failed) parts.push(`${failed} failed`);
                          return parts.join(' · ') || 'Done';
                        })()}
                      </p>
                    </div>
                    {showBulkModal === 'enrich' && (() => {
                      const failedIds = bulkProgress.results
                        .filter(r => ['error', 'gemini_failed', 'parse_error'].includes(r.status))
                        .map(r => r.id);
                      return (
                        <div className="ml-auto flex items-center gap-2">
                          {failedIds.length > 0 && (
                            <button
                              onClick={() => {
                                // Select only failed events and re-run enrichment
                                setSelectedIds(new Set(failedIds));
                                setShowBulkModal(null);
                                setBulkProgress({ phase: 'idle', current: 0, total: 0, results: [] });
                                // Wait longer before retrying to let Gemini rate limits clear
                                setTimeout(() => bulkEnrich(), 2000);
                              }}
                              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition-all hover:opacity-80"
                              style={{ backgroundColor: T.dangerLight, color: T.danger }}
                            >
                              <RefreshCw size={12} /> Retry {failedIds.length} Failed
                            </button>
                          )}
                          <button
                            onClick={() => {
                              setShowBulkModal(null);
                              setBulkProgress({ phase: 'idle', current: 0, total: 0, results: [] });
                              // Auto-start push to CMS
                              setTimeout(() => bulkPushToCms(), 100);
                            }}
                            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition-all hover:opacity-80"
                            style={{ backgroundColor: T.accentLight, color: T.accent }}
                          >
                            <ArrowRight size={12} /> Push to CMS
                          </button>
                        </div>
                      );
                    })()}
                  </div>
                </div>
              )}

              {/* Results List */}
              <div className="flex-1 overflow-y-auto px-6 py-3 space-y-1" style={{ maxHeight: '50vh' }}>
                {bulkProgress.results.length === 0 && bulkProgress.phase === 'processing' && (
                  <div className="text-center py-8">
                    <Sparkles size={20} className="mx-auto mb-2 animate-pulse" style={{ color: T.purple }} />
                    <p className="text-xs" style={{ color: T.textMuted }}>Processing events…</p>
                  </div>
                )}
                {bulkProgress.results.map((result, idx) => (
                  <div
                    key={result.id || idx}
                    className="flex items-center gap-3 px-3 py-2 rounded-lg"
                    style={{ backgroundColor: result.status === 'enriched' || result.status === 'pushed' ? '#F0FDF4' : result.status === 'duplicate' ? '#FFFBEB' : result.status === 'already_complete' || result.status === 'no_changes' ? '#F9FAFB' : result.status === 'error' || result.status === 'gemini_failed' || result.status === 'parse_error' || result.status === 'not_found' ? '#FEF2F2' : '#F9FAFB' }}
                  >
                    {/* Status icon */}
                    {result.status === 'enriched' || result.status === 'pushed' ? (
                      <Check size={14} style={{ color: T.accent }} />
                    ) : result.status === 'duplicate' ? (
                      <AlertTriangle size={14} style={{ color: '#D97706' }} />
                    ) : result.status === 'already_complete' || result.status === 'no_changes' ? (
                      <CheckSquare size={14} style={{ color: T.textMuted }} />
                    ) : result.status === 'not_found' ? (
                      <AlertTriangle size={14} style={{ color: T.warning }} />
                    ) : (
                      <X size={14} style={{ color: T.danger }} />
                    )}

                    {/* Title */}
                    <span className="flex-1 text-xs font-medium truncate" style={{ color: T.text }}>
                      {result.title}
                    </span>

                    {/* Status */}
                    <span className="text-[10px] font-medium px-1.5 py-0.5 rounded" style={{
                      backgroundColor: result.status === 'enriched' || result.status === 'pushed' ? T.accentLight : result.status === 'duplicate' ? '#FEF3C7' : result.status === 'already_complete' || result.status === 'no_changes' ? '#F3F4F6' : T.dangerLight,
                      color: result.status === 'enriched' || result.status === 'pushed' ? T.accent : result.status === 'duplicate' ? '#92400E' : result.status === 'already_complete' || result.status === 'no_changes' ? T.textMuted : T.danger,
                    }}>
                      {result.status === 'enriched' ? 'Enriched' : result.status === 'pushed' ? 'Pushed' : result.status === 'duplicate' ? 'Duplicate' : result.status === 'already_complete' || result.status === 'no_changes' ? 'Complete' : result.status === 'not_found' ? 'Not Found' : result.status === 'gemini_failed' ? 'AI Failed' : result.status === 'parse_error' ? 'Parse Error' : 'Error'}
                    </span>

                    {/* Duplicate detail */}
                    {result.duplicateOf && (
                      <span className="text-[9px] truncate max-w-[180px]" style={{ color: '#92400E' }} title={`Already exists as ${result.duplicateOf}`}>
                        matches {result.duplicateOf.slice(0, 20)}{result.duplicateOf.length > 20 ? '…' : ''}
                      </span>
                    )}

                    {/* Fields enriched */}
                    {result.fieldsEnriched && result.fieldsEnriched.length > 0 && (
                      <div className="flex gap-1">
                        {result.fieldsEnriched.map(f => (
                          <span key={f} className="text-[9px] px-1 py-0.5 rounded" style={{ backgroundColor: T.purpleLight, color: T.purple }}>
                            {f}
                          </span>
                        ))}
                      </div>
                    )}

                    {/* Error detail */}
                    {result.error && (
                      <span className="text-[9px] truncate max-w-[200px]" style={{ color: T.danger }} title={result.error}>
                        {result.error.slice(0, 60)}{result.error.length > 60 ? '...' : ''}
                      </span>
                    )}
                  </div>
                ))}
              </div>

              {/* Modal Footer */}
              {bulkProgress.phase === 'done' && (
                <div className="px-6 py-3 border-t flex justify-end" style={{ borderColor: T.border }}>
                  <button
                    onClick={() => { setShowBulkModal(null); setBulkProgress({ phase: 'idle', current: 0, total: 0, results: [] }); setSelectedIds(new Set()); }}
                    className="flex items-center gap-1.5 px-4 py-2 text-xs font-medium rounded-lg transition-all hover:opacity-80"
                    style={{ backgroundColor: T.text, color: '#FFFFFF' }}
                  >
                    Done
                  </button>
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}