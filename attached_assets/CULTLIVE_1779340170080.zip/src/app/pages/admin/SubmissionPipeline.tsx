import { useState, useEffect, useCallback } from 'react';
import { useParams, useOutletContext } from 'react-router';
import { motion, AnimatePresence } from 'motion/react';
import {
  Check, X, Eye, Inbox, AlertTriangle, Sparkles, MapPin, Clock,
  Calendar, User, Instagram, Link2, ChevronDown, Search,
  CheckCircle2, XCircle, Loader2, Trash2, ExternalLink,
  LayoutList, Columns3, Tag, Plus, Camera, Film, Star,
} from 'lucide-react';
import { fetchSubmissions, updateSubmissionStatus, bulkAction, deleteSubmission, updateSubmissionFields } from '../../hooks/useAdminApi';
import { useData } from '../../context/DataContext';
import { fireWebhook } from '../../config/webhooks';
import { ImageWithFallback } from '../../components/figma/ImageWithFallback';
import { CategoryPills, resolveCategories, getCategoryLabel, getCategoryColor } from '../../components/CategoryPills';
import { CategoryEditor } from '../../components/CategoryEditor';
import { isVideoUrl } from '../../utils/media-helpers';

const N = {
  pageBg: '#FAFAF8',
  surface: '#FFFFFF',
  surfaceMuted: '#F3F3F0',
  border: 'rgba(0,0,0,0.06)',
  text: '#1A1A1A',
  textSecondary: '#5A5A5A',
  textMuted: '#9A9A9A',
  dark: '#1A1A1A',
  green: '#16A34A',
  greenBg: 'rgba(22,163,74,0.06)',
  greenBorder: 'rgba(22,163,74,0.1)',
  amber: '#D97706',
  amberBg: 'rgba(217,119,6,0.06)',
  red: '#DC2626',
  redBg: 'rgba(220,38,38,0.05)',
  blue: '#2563EB',
  blueBg: 'rgba(37,99,235,0.05)',
  font: "'Inter', 'Noto Sans HK', system-ui, sans-serif",
};

const STATUS_CONFIG: Record<string, { label: string; color: string; bg: string; icon: typeof Inbox }> = {
  'all': { label: 'All Submissions', color: N.text, bg: 'rgba(0,0,0,0.03)', icon: Inbox },
  'pending': { label: 'Pending', color: N.amber, bg: N.amberBg, icon: AlertTriangle },
  'ai-approved': { label: 'AI Approved', color: N.green, bg: N.greenBg, icon: Sparkles },
  'ai-flagged': { label: 'AI Flagged', color: N.amber, bg: N.amberBg, icon: AlertTriangle },
  'approved': { label: 'Approved', color: N.green, bg: N.greenBg, icon: CheckCircle2 },
  'published': { label: 'Published', color: N.blue, bg: N.blueBg, icon: Eye },
  'rejected': { label: 'Rejected', color: N.red, bg: N.redBg, icon: XCircle },
};

export function SubmissionPipeline() {
  const { status: statusParam } = useParams();
  const { accessToken } = useOutletContext<{ accessToken: string }>();
  const [submissions, setSubmissions] = useState<any[]>([]);
  const [counts, setCounts] = useState<Record<string, number>>({});
  const [loading, setLoading] = useState(true);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'list' | 'kanban'>('list');
  const [typeFilter, setTypeFilter] = useState<'all' | 'event' | 'recap'>('all');
  const [toast, setToast] = useState<{ msg: string; type: 'ok' | 'err' } | null>(null);
  const [detailSub, setDetailSub] = useState<any>(null);
  const [backfillLoading, setBackfillLoading] = useState(false);
  const [venueSearch, setVenueSearch] = useState('');
  const [venueDropdownOpen, setVenueDropdownOpen] = useState<string | null>(null);
  const { venues, allEvents } = useData();

  const showToast = useCallback((msg: string, type: 'ok' | 'err' = 'ok') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3000);
  }, []);

  const statusFilter = statusParam === 'pending' ? undefined : statusParam || undefined;
  const isPendingView = statusParam === 'pending';
  const pageTitle = statusParam === 'pending' ? 'Pending Review' : statusParam ? (STATUS_CONFIG[statusParam]?.label || 'Submissions') : 'All Submissions';

  const loadData = useCallback(async () => {
    if (!accessToken) return;
    try {
      const data = await fetchSubmissions(accessToken, statusFilter);
      let subs = data.submissions || [];
      if (isPendingView) {
        subs = subs.filter((s: any) => s.status === 'ai-approved' || s.status === 'ai-flagged');
      }
      setSubmissions(subs);
      setCounts(data.counts || {});
    } catch (err) {
      console.log('Failed to load submissions:', err);
    }
    setLoading(false);
  }, [accessToken, statusFilter, isPendingView]);

  useEffect(() => { loadData(); }, [loadData]);

  const handleStatusChange = useCallback(async (id: string, newStatus: string) => {
    setActionLoading(id);
    try {
      await updateSubmissionStatus(accessToken!, id, newStatus);
      await loadData();
      const label = newStatus === 'published' ? 'Published!' : newStatus === 'approved' ? 'Approved!' : newStatus === 'rejected' ? 'Rejected' : 'Updated';
      showToast(`${label} Submission status updated to "${newStatus}".`);

      // Fire webhooks for status transitions
      const sub = submissions.find(s => s.id === id);
      const eventData = { submissionId: id, status: newStatus, title: sub?.title || '' };
      fireWebhook('submission.status_changed', eventData);
      if (newStatus === 'published') fireWebhook('submission.published', eventData);
      if (newStatus === 'rejected') fireWebhook('submission.rejected', eventData);
    } catch (err) {
      console.log('Status update failed:', err);
      showToast(`Failed to update status: ${err}`, 'err');
    }
    setActionLoading(null);
  }, [accessToken, loadData, showToast, submissions]);

  const handleBulkAction = useCallback(async (action: string) => {
    if (selectedIds.size === 0) return;
    setActionLoading('bulk');
    try {
      await bulkAction(accessToken!, Array.from(selectedIds), action);
      setSelectedIds(new Set());
      await loadData();
    } catch (err) {
      console.log('Bulk action failed:', err);
    }
    setActionLoading(null);
  }, [accessToken, selectedIds, loadData]);

  const handleDelete = useCallback(async (id: string) => {
    setActionLoading(id);
    try {
      await deleteSubmission(accessToken!, id);
      await loadData();
    } catch (err) {
      console.log('Delete failed:', err);
    }
    setActionLoading(null);
  }, [accessToken, loadData]);

  const toggleSelect = (id: string) => {
    const next = new Set(selectedIds);
    if (next.has(id)) next.delete(id); else next.add(id);
    setSelectedIds(next);
  };

  const toggleSelectAll = () => {
    if (selectedIds.size === filtered.length) setSelectedIds(new Set());
    else setSelectedIds(new Set(filtered.map(s => s.id)));
  };

  const filtered = submissions.filter(s => {
    // Type filter
    if (typeFilter === 'recap' && s.type !== 'recap') return false;
    if (typeFilter === 'event' && s.type === 'recap') return false;
    // Search filter
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return s.title?.toLowerCase().includes(q) ||
        s.contributorName?.toLowerCase().includes(q) ||
        s.location?.toLowerCase().includes(q) ||
        s.eventTitle?.toLowerCase().includes(q);
    }
    return true;
  });

  const recapCount = submissions.filter(s => s.type === 'recap').length;
  const eventCount = submissions.filter(s => s.type !== 'recap').length;

  return (
    <div className="p-5 sm:p-8 lg:p-10 max-w-[1100px] mx-auto" style={{ fontFamily: N.font }}>
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="mb-6">
        <p className="text-[11px] font-medium uppercase tracking-wider mb-1.5"
          style={{ color: N.textMuted }}>Pipeline</p>
        <div className="flex items-center justify-between">
          <h1 className="text-[1.5rem] font-semibold tracking-tight" style={{ color: N.text }}>
            {pageTitle}
          </h1>
          <p className="text-[13px]" style={{ color: N.textMuted }}>
            {filtered.length} item{filtered.length !== 1 ? 's' : ''}
          </p>
        </div>
      </motion.div>

      {/* Type Filter */}
      <div className="flex items-center gap-1.5 mb-4">
        {([
          { key: 'all' as const, label: 'All', icon: Inbox, count: submissions.length },
          { key: 'event' as const, label: 'Events', icon: Calendar, count: eventCount },
          { key: 'recap' as const, label: 'Recaps', icon: Camera, count: recapCount },
        ]).map(tf => (
          <button
            key={tf.key}
            onClick={() => { setTypeFilter(tf.key); setSelectedIds(new Set()); }}
            className="flex items-center gap-1.5 px-3 py-1.5 text-[12px] font-medium cursor-pointer transition-all"
            style={{
              backgroundColor: typeFilter === tf.key ? N.dark : N.surface,
              color: typeFilter === tf.key ? '#fff' : N.textMuted,
              borderRadius: '8px',
              border: typeFilter === tf.key ? 'none' : `1px solid ${N.border}`,
            }}
          >
            <tf.icon size={12} />
            {tf.label}
            {tf.count > 0 && (
              <span className="text-[10px] px-1 py-0.5 ml-0.5" style={{
                backgroundColor: typeFilter === tf.key ? 'rgba(255,255,255,0.2)' : 'rgba(0,0,0,0.04)',
                borderRadius: '4px',
              }}>{tf.count}</span>
            )}
          </button>
        ))}
      </div>

      {/* Search + Bulk */}
      <div className="flex flex-col sm:flex-row gap-3 mb-5">
        <div className="relative flex-1">
          <Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2" style={{ color: N.textMuted }} />
          <input
            type="text" value={searchQuery} onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search submissions..."
            className="w-full pl-10 pr-4 py-2.5 text-[14px] outline-none"
            style={{ backgroundColor: N.surface, border: `1px solid ${N.border}`, borderRadius: '10px', color: N.text }}
          />
        </div>

        {/* View Toggle */}
        {!statusParam && (
          <div className="flex items-center" style={{ borderRadius: '10px', border: `1px solid ${N.border}`, backgroundColor: N.surface }}>
            <button onClick={() => setViewMode('list')}
              className="flex items-center gap-1.5 px-3 py-2 text-[12px] font-medium cursor-pointer transition-colors"
              style={{ backgroundColor: viewMode === 'list' ? 'rgba(0,0,0,0.05)' : 'transparent', color: viewMode === 'list' ? N.text : N.textMuted, borderRadius: '8px' }}>
              <LayoutList size={14} /> List
            </button>
            <button onClick={() => setViewMode('kanban')}
              className="flex items-center gap-1.5 px-3 py-2 text-[12px] font-medium cursor-pointer transition-colors"
              style={{ backgroundColor: viewMode === 'kanban' ? 'rgba(0,0,0,0.05)' : 'transparent', color: viewMode === 'kanban' ? N.text : N.textMuted, borderRadius: '8px' }}>
              <Columns3 size={14} /> Board
            </button>
          </div>
        )}

        {selectedIds.size > 0 && (
          <motion.div initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} className="flex gap-2">
            <button onClick={() => handleBulkAction('approved')}
              className="flex items-center gap-1.5 px-4 py-2.5 text-[13px] font-medium cursor-pointer"
              style={{ backgroundColor: N.dark, color: '#fff', borderRadius: '10px' }}>
              <Check size={14} /> Approve ({selectedIds.size})
            </button>
            <button onClick={() => handleBulkAction('published')}
              className="flex items-center gap-1.5 px-4 py-2.5 text-[13px] font-medium cursor-pointer"
              style={{ backgroundColor: N.blue, color: '#fff', borderRadius: '10px' }}>
              <Eye size={14} /> Publish
            </button>
            <button onClick={() => handleBulkAction('rejected')}
              className="flex items-center gap-1.5 px-4 py-2.5 text-[13px] font-medium cursor-pointer"
              style={{ backgroundColor: N.red, color: '#fff', borderRadius: '10px' }}>
              <X size={14} /> Reject
            </button>
          </motion.div>
        )}

        {/* Backfill venues for orphaned recaps */}
        {typeFilter === 'recap' && (() => {
          const orphanedRecaps = submissions.filter(s =>
            s.type === 'recap' && !s.venueId && (s.status === 'published' || s.status === 'approved')
          );
          if (orphanedRecaps.length === 0) return null;
          return (
            <button
              disabled={backfillLoading}
              onClick={async () => {
                setBackfillLoading(true);
                let fixed = 0;
                const venueNameMap = new Map<string, string>();
                venues.forEach((v: any) => {
                  if (v.name) venueNameMap.set(v.name.toLowerCase().trim(), v.id);
                  if (v.nameZh) venueNameMap.set(v.nameZh.toLowerCase().trim(), v.id);
                });
                for (const sub of orphanedRecaps) {
                  const linkedEvent = sub.eventId ? allEvents.find((e: any) => e.id === sub.eventId) : null;
                  let resolvedVenueId = linkedEvent?.venueId || '';
                  if (!resolvedVenueId) {
                    const name = sub.eventVenue || sub.venueName || linkedEvent?.venueName || '';
                    if (name) resolvedVenueId = venueNameMap.get(name.toLowerCase().trim()) || '';
                  }
                  if (resolvedVenueId) {
                    try {
                      await updateSubmissionFields(accessToken!, sub.id, { venueId: resolvedVenueId });
                      setSubmissions(prev => prev.map(s => s.id === sub.id ? { ...s, venueId: resolvedVenueId } : s));
                      fixed++;
                    } catch {}
                  }
                }
                showToast(fixed > 0 ? `Backfilled ${fixed} recap${fixed > 1 ? 's' : ''} with venue links` : 'No venues could be auto-matched — assign manually');
                setBackfillLoading(false);
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 text-[12px] font-medium cursor-pointer ml-auto transition-all hover:opacity-80"
              style={{
                backgroundColor: N.amberBg,
                color: N.amber,
                borderRadius: '8px',
                border: '1px solid rgba(217,119,6,0.12)',
              }}
            >
              {backfillLoading ? <Loader2 size={12} className="animate-spin" /> : <MapPin size={12} />}
              Backfill Venues ({orphanedRecaps.length} orphaned)
            </button>
          );
        })()}
      </div>

      {/* Content */}
      {loading ? (
        <div className="flex items-center justify-center py-16">
          <Loader2 size={20} className="animate-spin" style={{ color: N.textMuted }} />
        </div>
      ) : viewMode === 'kanban' && !statusParam ? (
        <KanbanBoard
          submissions={filtered}
          onStatusChange={handleStatusChange}
          actionLoading={actionLoading}
        />
      ) : filtered.length === 0 ? (
        <div className="text-center py-16"
          style={{ backgroundColor: N.surface, borderRadius: '16px', border: `1px solid ${N.border}` }}>
          <Inbox size={28} style={{ color: N.textMuted }} className="mx-auto mb-2 opacity-40" />
          <p className="text-[14px]" style={{ color: N.textMuted }}>No submissions found</p>
        </div>
      ) : (
        <div className="space-y-2">
          <div className="flex items-center gap-3 px-4 py-1.5">
            <input type="checkbox" checked={selectedIds.size === filtered.length && filtered.length > 0}
              onChange={toggleSelectAll} className="w-3.5 h-3.5 accent-[#1A1A1A] cursor-pointer" />
            <span className="text-[11px] font-medium uppercase tracking-wider" style={{ color: N.textMuted }}>
              Select all
            </span>
          </div>

          {filtered.map(sub => (
            <motion.div key={sub.id} layout
              initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }}
              className="overflow-hidden"
              style={{ backgroundColor: N.surface, border: `1px solid ${N.border}`, borderRadius: '12px' }}>

              <div className="flex items-center gap-3 p-3 sm:p-4">
                <input type="checkbox" checked={selectedIds.has(sub.id)}
                  onChange={() => toggleSelect(sub.id)}
                  className="w-3.5 h-3.5 accent-[#1A1A1A] cursor-pointer flex-shrink-0" />

                {sub.images?.[0] ? (
                  <div className="w-11 h-11 sm:w-12 sm:h-12 flex-shrink-0 overflow-hidden rounded-lg">
                    <ImageWithFallback src={sub.images[0]} alt="" className="w-full h-full object-cover" />
                  </div>
                ) : (
                  <div className="w-11 h-11 sm:w-12 sm:h-12 flex-shrink-0 flex items-center justify-center rounded-lg"
                    style={{ backgroundColor: 'rgba(0,0,0,0.03)' }}>
                    <Inbox size={16} style={{ color: N.textMuted }} />
                  </div>
                )}

                <div className="flex-1 min-w-0 cursor-pointer"
                  onClick={() => setExpandedId(expandedId === sub.id ? null : sub.id)}>
                  <div className="flex items-center gap-2">
                    <p className="text-[14px] font-medium truncate" style={{ color: N.text }}>
                      {sub.title || 'Untitled'}
                    </p>
                    {sub.type === 'recap' && (
                      <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wider flex-shrink-0"
                        style={{ backgroundColor: 'rgba(139,92,246,0.08)', color: '#7C3AED', borderRadius: '4px' }}>
                        <Camera size={8} /> Recap
                      </span>
                    )}
                    <StatusPill status={sub.status} />
                    {resolveCategories(sub).length > 0 && (
                      <div className="hidden sm:flex flex-shrink-0">
                        <CategoryPills categories={resolveCategories(sub)} size="xs" showPrimary maxVisible={3} />
                      </div>
                    )}
                  </div>
                  <div className="flex items-center gap-3 mt-0.5">
                    <span className="text-[12px]" style={{ color: N.textMuted }}>
                      <User size={10} className="inline mr-1" />{sub.contributorName || 'Anonymous'}
                    </span>
                    {sub.source !== 'manual' && (
                      <span className="text-[12px]" style={{ color: N.textMuted }}>
                        {sub.source === 'instagram' ? <Instagram size={10} className="inline mr-1" /> : <Link2 size={10} className="inline mr-1" />}
                        {sub.source}
                      </span>
                    )}
                    {sub.location && (
                      <span className="text-[12px] hidden sm:inline" style={{ color: N.textMuted }}>
                        <MapPin size={10} className="inline mr-1" />{sub.location}
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex-shrink-0 text-center hidden sm:block">
                  <div className="text-[17px] font-semibold" style={{
                    color: sub.aiScore >= 70 ? N.green : sub.aiScore >= 40 ? N.amber : N.red,
                  }}>{sub.aiScore}</div>
                  <p className="text-[10px]" style={{ color: N.textMuted }}>score</p>
                </div>

                <div className="flex items-center gap-1 flex-shrink-0">
                  {(sub.status === 'ai-approved' || sub.status === 'ai-flagged' || sub.status === 'pending') && (
                    <>
                      <button onClick={() => handleStatusChange(sub.id, 'approved')}
                        disabled={actionLoading === sub.id}
                        className="p-2 cursor-pointer transition-all hover:scale-105"
                        style={{ backgroundColor: N.greenBg, borderRadius: '8px' }} title="Approve">
                        {actionLoading === sub.id
                          ? <Loader2 size={14} className="animate-spin" style={{ color: N.green }} />
                          : <Check size={14} style={{ color: N.green }} />}
                      </button>
                      <button onClick={() => handleStatusChange(sub.id, 'rejected')}
                        disabled={actionLoading === sub.id}
                        className="p-2 cursor-pointer transition-all hover:scale-105"
                        style={{ backgroundColor: N.redBg, borderRadius: '8px' }} title="Reject">
                        <X size={14} style={{ color: N.red }} />
                      </button>
                    </>
                  )}
                  {sub.status === 'approved' && (
                    <button onClick={() => handleStatusChange(sub.id, 'published')}
                      disabled={actionLoading === sub.id}
                      className="flex items-center gap-1 px-3 py-1.5 text-[12px] font-medium cursor-pointer"
                      style={{ backgroundColor: N.dark, color: '#fff', borderRadius: '8px' }}>
                      {actionLoading === sub.id ? <Loader2 size={12} className="animate-spin" /> : <Eye size={12} />}
                      Publish
                    </button>
                  )}
                  {sub.status === 'published' && (
                    <a href={sub.type === 'recap' ? `/recaps/${sub.id}` : `/event/${sub.id}`} target="_blank" rel="noopener noreferrer"
                      className="flex items-center gap-1 px-3 py-1.5 text-[12px] font-medium cursor-pointer no-underline transition-all hover:opacity-80"
                      style={{ backgroundColor: N.blueBg, color: N.blue, borderRadius: '8px', border: `1px solid rgba(37,99,235,0.12)` }}>
                      <ExternalLink size={12} />
                      View on site
                    </a>
                  )}
                  <button onClick={() => setExpandedId(expandedId === sub.id ? null : sub.id)}
                    className="p-2 cursor-pointer" style={{ color: N.textMuted }}>
                    <ChevronDown size={14} className={`transition-transform ${expandedId === sub.id ? 'rotate-180' : ''}`} />
                  </button>
                </div>
              </div>

              <AnimatePresence>
                {expandedId === sub.id && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="overflow-hidden">
                    <div className="px-4 pb-4 pt-1" style={{ borderTop: `1px solid ${N.border}` }}>
                      {/* Category Editor */}
                      <CategoryEditor
                        submission={sub}
                        accessToken={accessToken!}
                        onUpdate={loadData}
                        onToast={showToast}
                      />

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-3">
                        <div className="space-y-3">
                          {/* Linked event info for recaps */}
                          {sub.type === 'recap' && sub.eventId && (
                            <div className="p-3" style={{
                              backgroundColor: 'rgba(139,92,246,0.04)',
                              borderRadius: '10px',
                              border: '1px solid rgba(139,92,246,0.1)',
                            }}>
                              <p className="text-[10px] font-medium uppercase tracking-wider mb-1.5"
                                style={{ color: '#7C3AED' }}>
                                <Camera size={9} className="inline mr-1" />Linked Event
                              </p>
                              <p className="text-[14px] font-medium" style={{ color: N.text }}>
                                {sub.eventTitle || 'Unknown event'}
                              </p>
                              <div className="flex items-center gap-3 mt-0.5">
                                {sub.eventDate && (
                                  <span className="text-[11px]" style={{ color: N.textMuted }}>
                                    <Calendar size={9} className="inline mr-1" />{sub.eventDate}
                                  </span>
                                )}
                                {sub.eventVenue && (
                                  <span className="text-[11px]" style={{ color: N.textMuted }}>
                                    <MapPin size={9} className="inline mr-1" />{sub.eventVenue}
                                  </span>
                                )}
                              </div>
                              {sub.eventId && (
                                <a href={`/event/${sub.eventId}`} target="_blank" rel="noopener noreferrer"
                                  className="inline-flex items-center gap-1 text-[11px] mt-1.5 hover:underline no-underline"
                                  style={{ color: '#7C3AED' }}>
                                  <ExternalLink size={10} /> View event
                                </a>
                              )}
                            </div>
                          )}

                          {/* Venue assignment for recaps */}
                          {sub.type === 'recap' && (() => {
                            const linkedEvent = sub.eventId ? allEvents.find((e: any) => e.id === sub.eventId) : null;
                            const resolvedVenueId = sub.venueId || linkedEvent?.venueId || '';
                            const resolvedVenue = resolvedVenueId ? venues.find((v: any) => v.id === resolvedVenueId) : null;
                            return (
                              <div className="p-3" style={{
                                backgroundColor: resolvedVenue ? 'rgba(22,163,74,0.04)' : 'rgba(220,38,38,0.04)',
                                borderRadius: '10px',
                                border: `1px solid ${resolvedVenue ? 'rgba(22,163,74,0.1)' : 'rgba(220,38,38,0.1)'}`,
                              }}>
                                <p className="text-[10px] font-medium uppercase tracking-wider mb-1.5"
                                  style={{ color: resolvedVenue ? N.green : N.red }}>
                                  <MapPin size={9} className="inline mr-1" />
                                  {resolvedVenue ? 'Linked Venue' : '⚠ No Venue Linked'}
                                </p>
                                {resolvedVenue && (
                                  <p className="text-[13px] font-medium mb-1" style={{ color: N.text }}>
                                    {resolvedVenue.name}
                                    {resolvedVenue.district && <span className="font-normal" style={{ color: N.textMuted }}> · {resolvedVenue.district}</span>}
                                  </p>
                                )}
                                <div className="relative mt-1.5">
                                  <div className="relative">
                                    <Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" style={{ color: N.textMuted }} />
                                    <input
                                      type="text"
                                      placeholder={resolvedVenue ? resolvedVenue.name : 'Search venues...'}
                                      value={venueDropdownOpen === sub.id ? venueSearch : ''}
                                      onFocus={() => { setVenueDropdownOpen(sub.id); setVenueSearch(''); }}
                                      onChange={(e) => setVenueSearch(e.target.value)}
                                      className="w-full pl-7 pr-8 py-1.5 text-[12px] outline-none"
                                      style={{
                                        backgroundColor: N.surface,
                                        border: `1px solid ${venueDropdownOpen === sub.id ? 'rgba(37,99,235,0.3)' : N.border}`,
                                        borderRadius: '7px',
                                        color: N.text,
                                      }}
                                    />
                                    {resolvedVenueId && (
                                      <button
                                        onClick={async () => {
                                          try {
                                            setActionLoading(sub.id);
                                            await updateSubmissionFields(accessToken, sub.id, { venueId: '' });
                                            setSubmissions(prev => prev.map(s => s.id === sub.id ? { ...s, venueId: '' } : s));
                                            showToast('Venue unlinked');
                                          } catch (err: any) {
                                            showToast(err.message || 'Failed', 'err');
                                          } finally {
                                            setActionLoading(null);
                                          }
                                        }}
                                        className="absolute right-2 top-1/2 -translate-y-1/2 cursor-pointer p-0.5 rounded hover:bg-black/5"
                                        style={{ color: N.textMuted }}
                                      >
                                        <X size={12} />
                                      </button>
                                    )}
                                  </div>
                                  {venueDropdownOpen === sub.id && (() => {
                                    const q = venueSearch.toLowerCase().trim();
                                    const filteredVenues = venues.filter((v: any) =>
                                      !q || v.name?.toLowerCase().includes(q) || v.nameZh?.toLowerCase().includes(q) || v.district?.toLowerCase().includes(q)
                                    ).slice(0, 8);
                                    return (
                                      <>
                                        <div className="fixed inset-0 z-10" onClick={() => setVenueDropdownOpen(null)} />
                                        <div className="absolute z-20 left-0 right-0 mt-1 py-1 max-h-[200px] overflow-y-auto shadow-lg"
                                          style={{ backgroundColor: N.surface, border: `1px solid ${N.border}`, borderRadius: '8px' }}>
                                          {filteredVenues.length === 0 ? (
                                            <p className="text-[11px] text-center py-3" style={{ color: N.textMuted }}>No venues match "{venueSearch}"</p>
                                          ) : filteredVenues.map((v: any) => (
                                            <button
                                              key={v.id}
                                              onClick={async () => {
                                                try {
                                                  setActionLoading(sub.id);
                                                  await updateSubmissionFields(accessToken, sub.id, { venueId: v.id });
                                                  setSubmissions(prev => prev.map(s => s.id === sub.id ? { ...s, venueId: v.id } : s));
                                                  showToast(`Venue linked: ${v.name}`);
                                                } catch (err: any) {
                                                  showToast(err.message || 'Failed to update venue', 'err');
                                                } finally {
                                                  setActionLoading(null);
                                                  setVenueDropdownOpen(null);
                                                  setVenueSearch('');
                                                }
                                              }}
                                              className="w-full text-left px-3 py-2 text-[12px] cursor-pointer hover:bg-black/3 flex items-center gap-2 transition-colors"
                                              style={{
                                                color: N.text,
                                                backgroundColor: v.id === resolvedVenueId ? 'rgba(22,163,74,0.06)' : 'transparent',
                                              }}
                                            >
                                              <MapPin size={10} style={{ color: v.id === resolvedVenueId ? N.green : N.textMuted, flexShrink: 0 }} />
                                              <span className="truncate">{v.name}</span>
                                              {v.district && <span className="text-[10px] flex-shrink-0" style={{ color: N.textMuted }}>{v.district}</span>}
                                              {v.id === resolvedVenueId && <Check size={10} style={{ color: N.green, flexShrink: 0, marginLeft: 'auto' }} />}
                                            </button>
                                          ))}
                                        </div>
                                      </>
                                    );
                                  })()}
                                </div>
                                {!resolvedVenue && linkedEvent?.venueName && (
                                  <p className="text-[11px] mt-1" style={{ color: N.amber }}>
                                    Event mentions: "{linkedEvent.venueName}" — match to a venue above
                                  </p>
                                )}
                              </div>
                            );
                          })()}

                          {sub.description && (
                            <div>
                              <p className="text-[11px] font-medium uppercase tracking-wider mb-1"
                                style={{ color: N.textMuted }}>Description</p>
                              <p className="text-[14px] leading-relaxed" style={{ color: N.textSecondary }}>
                                {sub.description}
                              </p>
                            </div>
                          )}
                          <div className="flex flex-wrap gap-4 text-[13px]">
                            {sub.date && <span style={{ color: N.textMuted }}><Calendar size={12} className="inline mr-1" />{sub.date}</span>}
                            {sub.time && <span style={{ color: N.textMuted }}><Clock size={12} className="inline mr-1" />{sub.time}</span>}
                            {sub.district && <span style={{ color: N.textMuted }}><MapPin size={12} className="inline mr-1" />{sub.district}</span>}
                          </div>
                          {sub.sourceUrl && (
                            <a href={sub.sourceUrl} target="_blank" rel="noopener noreferrer"
                              className="inline-flex items-center gap-1 text-[12px] hover:underline"
                              style={{ color: N.blue }}>
                              <ExternalLink size={12} /> View source
                            </a>
                          )}
                          {(sub.status === 'published' || sub.status === 'approved') && (
                            <a href={sub.type === 'recap' ? `/recaps/${sub.id}` : `/event/${sub.id}`} target="_blank" rel="noopener noreferrer"
                              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-[12px] font-medium no-underline transition-all hover:opacity-80"
                              style={{ backgroundColor: N.blueBg, color: N.blue, borderRadius: '7px', border: `1px solid rgba(37,99,235,0.12)` }}>
                              <ExternalLink size={12} /> View on site
                            </a>
                          )}
                          {sub.contributorEmail && (
                            <p className="text-[12px]" style={{ color: N.textMuted }}>{sub.contributorEmail}</p>
                          )}
                        </div>

                        <div className="space-y-3">
                          <div className="p-3.5" style={{
                            backgroundColor: N.greenBg, borderRadius: '10px', border: `1px solid ${N.greenBorder}`,
                          }}>
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-[10px] font-medium uppercase tracking-wider" style={{ color: N.green }}>
                                <Sparkles size={10} className="inline mr-1" />AI Analysis
                              </span>
                              <span className="text-[14px] font-semibold" style={{
                                color: sub.aiScore >= 70 ? N.green : sub.aiScore >= 40 ? N.amber : N.red,
                              }}>{sub.aiScore}/100</span>
                            </div>
                            {sub.aiReasons?.map((reason: string, i: number) => (
                              <p key={i} className="text-[12px] mb-0.5" style={{ color: N.textSecondary }}>* {reason}</p>
                            ))}
                            {sub.aiChecks && (
                              <div className="flex flex-wrap gap-1.5 mt-2">
                                {Object.entries(sub.aiChecks).map(([key, passed]) => (
                                  <span key={key} className="inline-flex items-center gap-0.5 px-1.5 py-0.5 text-[10px] font-medium" style={{
                                    backgroundColor: passed ? 'rgba(22,163,74,0.08)' : 'rgba(220,38,38,0.06)',
                                    color: passed ? N.green : N.red, borderRadius: '4px',
                                  }}>
                                    {passed ? <Check size={8} /> : <X size={8} />}
                                    {key.replace(/_/g, ' ')}
                                  </span>
                                ))}
                              </div>
                            )}
                          </div>

                          {sub.images?.length > 0 && (
                            <div>
                              <p className="text-[10px] font-medium uppercase tracking-wider mb-1.5" style={{ color: N.textMuted }}>
                                <Star size={9} className="inline mr-1" />
                                Cover Image {sub.heroImage && <span style={{ color: N.green }}>✓ set</span>}
                              </p>
                              <div className="flex gap-2 flex-wrap">
                                {sub.images.map((img: string, i: number) => {
                                  const isHero = img === sub.heroImage;
                                  const isVid = isVideoUrl(img);
                                  return (
                                    <button
                                      key={i}
                                      onClick={async () => {
                                        if (isVid) return; // can't set video as hero
                                        try {
                                          setActionLoading(sub.id);
                                          await updateSubmissionFields(accessToken, sub.id, { heroImage: img });
                                          setSubmissions(prev => prev.map(s => s.id === sub.id ? { ...s, heroImage: img } : s));
                                          showToast('Cover image updated');
                                        } catch (err: any) {
                                          showToast(err.message || 'Failed', 'err');
                                        } finally {
                                          setActionLoading(null);
                                        }
                                      }}
                                      className="relative w-14 h-14 overflow-hidden rounded-lg cursor-pointer p-0 transition-all hover:opacity-80"
                                      style={{
                                        border: isHero ? `2.5px solid ${N.blue}` : `1px solid ${N.border}`,
                                        background: 'none',
                                        opacity: isVid ? 0.6 : 1,
                                      }}
                                      title={isVid ? 'Video — cannot set as cover' : (isHero ? 'Current cover' : 'Click to set as cover')}
                                    >
                                      {isVid ? (
                                        <div className="relative w-full h-full">
                                          <video src={img} muted preload="metadata" className="w-full h-full object-cover" />
                                          <div className="absolute inset-0 flex items-center justify-center" style={{ backgroundColor: 'rgba(0,0,0,0.3)' }}>
                                            <Film size={10} color="#fff" />
                                          </div>
                                        </div>
                                      ) : (
                                        <ImageWithFallback src={img} alt="" className="w-full h-full object-cover" />
                                      )}
                                      {isHero && (
                                        <div className="absolute top-0.5 left-0.5 w-3.5 h-3.5 flex items-center justify-center"
                                          style={{ backgroundColor: N.blue, borderRadius: '50%' }}>
                                          <Star size={7} fill="#fff" color="#fff" />
                                        </div>
                                      )}
                                    </button>
                                  );
                                })}
                              </div>
                              {sub.heroImage && (
                                <button
                                  onClick={async () => {
                                    try {
                                      setActionLoading(sub.id);
                                      await updateSubmissionFields(accessToken, sub.id, { heroImage: '' });
                                      setSubmissions(prev => prev.map(s => s.id === sub.id ? { ...s, heroImage: '' } : s));
                                      showToast('Cover image cleared');
                                    } catch (err: any) {
                                      showToast(err.message || 'Failed', 'err');
                                    } finally {
                                      setActionLoading(null);
                                    }
                                  }}
                                  className="text-[11px] mt-1.5 cursor-pointer hover:underline"
                                  style={{ color: N.textMuted, border: 'none', background: 'none', padding: 0 }}
                                >
                                  <X size={9} className="inline mr-0.5" /> Clear cover
                                </button>
                              )}
                            </div>
                          )}

                          <button onClick={() => handleDelete(sub.id)}
                            className="flex items-center gap-1 text-[12px] cursor-pointer mt-2 hover:underline"
                            style={{ color: N.red }}>
                            <Trash2 size={12} /> Delete permanently
                          </button>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>
      )}
      {toast && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 20 }}
          className="fixed bottom-5 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 px-5 py-3 shadow-lg"
          style={{
            backgroundColor: toast.type === 'ok' ? '#16A34A' : '#DC2626',
            borderRadius: '10px',
            color: '#fff',
            fontSize: '13px',
            fontWeight: 500,
            fontFamily: N.font,
          }}
        >
          {toast.type === 'ok' ? <CheckCircle2 size={16} /> : <XCircle size={16} />}
          {toast.msg}
        </motion.div>
      )}
    </div>
  );
}

function StatusPill({ status }: { status: string }) {
  const c = STATUS_CONFIG[status] || STATUS_CONFIG.pending;
  return (
    <span className="inline-flex items-center gap-1 px-1.5 py-0.5 text-[10px] font-medium flex-shrink-0" style={{
      backgroundColor: c.bg, color: c.color, borderRadius: '5px',
    }}>
      <c.icon size={10} />
      {c.label}
    </span>
  );
}

function KanbanBoard({ submissions, onStatusChange, actionLoading }: {
  submissions: any[];
  onStatusChange: (id: string, newStatus: string) => void;
  actionLoading: string | null;
}) {
  const columns = [
    { status: 'ai-approved', label: 'AI Approved', color: N.green, bg: N.greenBg, nextAction: 'approved', nextLabel: 'Approve' },
    { status: 'ai-flagged', label: 'AI Flagged', color: N.amber, bg: N.amberBg, nextAction: 'approved', nextLabel: 'Approve' },
    { status: 'approved', label: 'Approved', color: N.green, bg: N.greenBg, nextAction: 'published', nextLabel: 'Publish' },
    { status: 'published', label: 'Published', color: N.blue, bg: N.blueBg, nextAction: null, nextLabel: '' },
    { status: 'rejected', label: 'Rejected', color: N.red, bg: N.redBg, nextAction: null, nextLabel: '' },
  ];

  return (
    <div className="flex gap-3 overflow-x-auto pb-4" style={{ minHeight: '400px' }}>
      {columns.map(col => {
        const items = submissions.filter(s => s.status === col.status);
        return (
          <div key={col.status} className="flex-shrink-0 w-[260px] flex flex-col"
            style={{ backgroundColor: N.surface, border: `1px solid ${N.border}`, borderRadius: '14px' }}>
            {/* Column header */}
            <div className="flex items-center gap-2 px-3.5 py-3" style={{ borderBottom: `1px solid ${N.border}` }}>
              <div className="w-2 h-2 rounded-full" style={{ backgroundColor: col.color }} />
              <span className="text-[12px] font-semibold" style={{ color: N.text }}>{col.label}</span>
              <span className="text-[11px] ml-auto px-1.5 py-0.5 font-medium" style={{
                backgroundColor: col.bg, color: col.color, borderRadius: '5px',
              }}>{items.length}</span>
            </div>

            {/* Cards */}
            <div className="flex-1 overflow-y-auto p-2 space-y-2">
              {items.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-[11px]" style={{ color: N.textMuted }}>No items</p>
                </div>
              ) : items.map(sub => (
                <motion.div key={sub.id}
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-3"
                  style={{ backgroundColor: N.pageBg, borderRadius: '10px', border: `1px solid ${N.border}` }}>
                  {/* Thumbnail + title */}
                  <div className="flex items-start gap-2.5 mb-2">
                    {sub.images?.[0] ? (
                      <div className="w-10 h-10 flex-shrink-0 overflow-hidden rounded-lg">
                        <ImageWithFallback src={sub.images[0]} alt="" className="w-full h-full object-cover" />
                      </div>
                    ) : (
                      <div className="w-10 h-10 flex-shrink-0 flex items-center justify-center rounded-lg"
                        style={{ backgroundColor: 'rgba(0,0,0,0.03)' }}>
                        <Inbox size={14} style={{ color: N.textMuted }} />
                      </div>
                    )}
                    <div className="min-w-0 flex-1">
                      <p className="text-[13px] font-medium line-clamp-2 leading-tight" style={{ color: N.text }}>
                        {sub.title || 'Untitled'}
                      </p>
                      <p className="text-[11px] mt-0.5 truncate" style={{ color: N.textMuted }}>
                        {sub.contributorName || 'Anonymous'}
                      </p>
                    </div>
                  </div>

                  {/* Meta row */}
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      {sub.date && (
                        <span className="text-[10px]" style={{ color: N.textMuted }}>
                          <Calendar size={9} className="inline mr-0.5" />{sub.date}
                        </span>
                      )}
                      {sub.district && (
                        <span className="text-[10px]" style={{ color: N.textMuted }}>
                          <MapPin size={9} className="inline mr-0.5" />{sub.district}
                        </span>
                      )}
                    </div>
                    <span className="text-[12px] font-semibold" style={{
                      color: sub.aiScore >= 70 ? N.green : sub.aiScore >= 40 ? N.amber : N.red,
                    }}>{sub.aiScore}</span>
                  </div>

                  {/* Category badges */}
                  {resolveCategories(sub).length > 0 && (
                    <div className="mb-2">
                      <CategoryPills categories={resolveCategories(sub)} size="xs" showPrimary maxVisible={3} />
                    </div>
                  )}

                  {/* Actions */}
                  <div className="flex gap-1.5">
                    {col.nextAction && (
                      <button onClick={() => onStatusChange(sub.id, col.nextAction!)}
                        disabled={actionLoading === sub.id}
                        className="flex-1 flex items-center justify-center gap-1 py-1.5 text-[11px] font-medium cursor-pointer transition-opacity hover:opacity-80"
                        style={{ backgroundColor: N.dark, color: '#fff', borderRadius: '7px' }}>
                        {actionLoading === sub.id ? <Loader2 size={11} className="animate-spin" /> : <Check size={11} />}
                        {col.nextLabel}
                      </button>
                    )}
                    {col.status === 'published' && (
                      <a href={sub.type === 'recap' ? `/recaps/${sub.id}` : `/event/${sub.id}`} target="_blank" rel="noopener noreferrer"
                        className="flex-1 flex items-center justify-center gap-1 py-1.5 text-[11px] font-medium cursor-pointer no-underline transition-opacity hover:opacity-80"
                        style={{ backgroundColor: N.blueBg, color: N.blue, borderRadius: '7px', border: `1px solid rgba(37,99,235,0.12)` }}>
                        <ExternalLink size={11} />
                        View on site
                      </a>
                    )}
                    {(col.status === 'ai-approved' || col.status === 'ai-flagged') && (
                      <button onClick={() => onStatusChange(sub.id, 'rejected')}
                        disabled={actionLoading === sub.id}
                        className="flex items-center justify-center gap-1 px-3 py-1.5 text-[11px] cursor-pointer"
                        style={{ backgroundColor: N.redBg, color: N.red, borderRadius: '7px' }}>
                        <X size={11} />
                      </button>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}