/**
 * VenueManager — Bulk venue editor for admin CMS
 * View, delete, re-parse (Google Places), and AI-enrich imported venues
 */
import { useState, useEffect, useCallback, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Search, Trash2, RefreshCw, Sparkles, MapPin, ChevronDown, ChevronUp,
  CheckSquare, Square, Loader2, ExternalLink, AlertTriangle, Check,
  X, Image as ImageIcon, FileText, Tag, Star, Globe, Phone, Clock,
  Filter, ArrowUpDown, Eye, Pencil, Save, RotateCcw, Copy,
} from 'lucide-react';
import { useOutletContext } from 'react-router';
import { projectId, publicAnonKey } from '../../config/supabase';

const CMS_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-d507b98c/cms`;

// Design tokens
const T = {
  bg: '#FAFAF8',
  surface: '#FFFFFF',
  border: '#E8E6E1',
  text: '#1A1A1A',
  textMuted: '#8C8C8C',
  accent: '#2D5A27',
  accentLight: '#E8F0E7',
  danger: '#DC2626',
  dangerLight: '#FEF2F2',
  warning: '#F59E0B',
  warningLight: '#FFFBEB',
  info: '#3B82F6',
  infoLight: '#EFF6FF',
  font: "'Inter', system-ui, sans-serif",
};

interface Venue {
  id: string;
  name: string;
  nameZh?: string;
  description?: string;
  category?: string;
  subcategory?: string;
  lat?: number;
  lng?: number;
  district?: string;
  address?: string;
  image?: string;
  modeScores?: Record<string, number>;
  vibeTags?: string[];
  priceRange?: number;
  googleRating?: number;
  googleWebsite?: string;
  googlePhone?: string;
  googleMapsUrl?: string;
  googleTypes?: string[];
  openingHours?: string[];
  _createdAt?: string;
  _updatedAt?: string;
  _reparsedAt?: string;
  _enrichedAt?: string;
  _source?: string;
}

type SortField = 'name' | 'district' | 'category' | 'completeness' | '_createdAt';
type SortDir = 'asc' | 'desc';

function authHeaders(token: string | null) {
  return {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${publicAnonKey}`,
    'X-Auth-Token': token || '',
  };
}

/** Calculate completeness score (0-100) for a venue */
function getCompleteness(v: Venue): number {
  let score = 0;
  const checks = [
    !!v.name, !!v.nameZh, !!v.description && v.description.length > 10,
    typeof v.lat === 'number' && v.lat !== 0, typeof v.lng === 'number' && v.lng !== 0,
    !!v.district, !!v.address, !!v.image,
    !!v.modeScores && Object.keys(v.modeScores).length > 0,
    !!v.vibeTags && v.vibeTags.length > 0,
    !!v.category, !!v.priceRange,
  ];
  score = Math.round((checks.filter(Boolean).length / checks.length) * 100);
  return score;
}

/** Get list of missing fields */
function getMissingFields(v: Venue): string[] {
  const missing: string[] = [];
  if (!v.nameZh) missing.push('nameZh');
  if (!v.description || v.description.length < 10) missing.push('description');
  if (typeof v.lat !== 'number' || v.lat === 0) missing.push('coordinates');
  if (!v.district) missing.push('district');
  if (!v.address) missing.push('address');
  if (!v.image) missing.push('image');
  if (!v.modeScores || Object.keys(v.modeScores).length === 0) missing.push('modeScores');
  if (!v.vibeTags || v.vibeTags.length === 0) missing.push('vibeTags');
  return missing;
}

// ─── Completeness Bar ───
function CompletenessBar({ value }: { value: number }) {
  const color = value >= 80 ? T.accent : value >= 50 ? T.warning : T.danger;
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-1.5 rounded-full overflow-hidden" style={{ backgroundColor: T.border }}>
        <div className="h-full rounded-full transition-all" style={{ width: `${value}%`, backgroundColor: color }} />
      </div>
      <span className="text-[11px] font-medium tabular-nums" style={{ color, minWidth: 28 }}>{value}%</span>
    </div>
  );
}

// ─── Missing Fields Chips ───
function MissingChips({ fields }: { fields: string[] }) {
  if (fields.length === 0) return <span className="text-[11px]" style={{ color: T.accent }}>Complete</span>;
  return (
    <div className="flex flex-wrap gap-1">
      {fields.slice(0, 4).map(f => (
        <span key={f} className="px-1.5 py-0.5 text-[10px] rounded" style={{ backgroundColor: T.warningLight, color: '#92400E' }}>
          {f}
        </span>
      ))}
      {fields.length > 4 && (
        <span className="px-1.5 py-0.5 text-[10px] rounded" style={{ backgroundColor: T.border, color: T.textMuted }}>
          +{fields.length - 4}
        </span>
      )}
    </div>
  );
}

// ─── Mode Tags (which modes this venue appears in) ───
const MODE_TAG_CONFIG: Record<string, { label: string; color: string; bg: string; threshold: number }> = {
  degen:     { label: 'Night',     color: '#D600FF', bg: '#FAE8FF', threshold: 0.3 },
  artsy:     { label: 'Art',       color: '#8338EC', bg: '#EDE9FE', threshold: 0.3 },
  foodie:    { label: 'Food',      color: '#2563EB', bg: '#DBEAFE', threshold: 0.3 },
  family:    { label: 'Family',    color: '#FF8C42', bg: '#FFF7ED', threshold: 0.3 },
  lifestyle: { label: 'Lifestyle', color: '#2D6A4F', bg: '#D1FAE5', threshold: 0.3 },
};

function ModeTagChips({ modeScores }: { modeScores?: Record<string, number> }) {
  if (!modeScores || Object.keys(modeScores).length === 0) {
    return <span className="text-[10px] italic" style={{ color: T.textMuted }}>No modes</span>;
  }
  const activeModes = Object.entries(modeScores)
    .filter(([mode, score]) => score >= (MODE_TAG_CONFIG[mode]?.threshold ?? 0.3))
    .sort((a, b) => b[1] - a[1]);

  if (activeModes.length === 0) {
    return <span className="text-[10px] italic" style={{ color: T.textMuted }}>Below threshold</span>;
  }

  return (
    <div className="flex flex-wrap gap-1">
      {activeModes.map(([mode, score]) => {
        const cfg = MODE_TAG_CONFIG[mode];
        if (!cfg) return null;
        return (
          <span
            key={mode}
            className="inline-flex items-center gap-0.5 px-1.5 py-0.5 text-[9px] font-semibold rounded-full"
            style={{ backgroundColor: cfg.bg, color: cfg.color, border: `1px solid ${cfg.color}25` }}
            title={`${cfg.label}: ${Math.round(score * 100)}%`}
          >
            {cfg.label}
            <span className="opacity-60">{Math.round(score * 100)}</span>
          </span>
        );
      })}
    </div>
  );
}

// ─── Expanded Venue Detail Panel ───
function VenueDetailPanel({ venue, onUpdate, onClose, accessToken }: {
  venue: Venue;
  onUpdate: (updated: Venue) => void;
  onClose: () => void;
  accessToken: string | null;
}) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState<Partial<Venue>>({});
  const [saving, setSaving] = useState(false);

  const startEdit = () => {
    setEditing(true);
    setDraft({
      name: venue.name,
      nameZh: venue.nameZh || '',
      description: venue.description || '',
      district: venue.district || '',
      address: venue.address || '',
      category: venue.category || '',
    });
  };

  const saveEdit = async () => {
    setSaving(true);
    try {
      const res = await fetch(`${CMS_BASE}/venues/bulk-update`, {
        method: 'POST',
        headers: authHeaders(accessToken),
        body: JSON.stringify({ id: venue.id, updates: draft }),
      });
      const data = await res.json();
      if (data.venue) {
        onUpdate(data.venue);
        setEditing(false);
      }
    } catch (err) {
      console.error('Save error:', err);
    }
    setSaving(false);
  };

  return (
    <motion.div
      initial={{ height: 0, opacity: 0 }}
      animate={{ height: 'auto', opacity: 1 }}
      exit={{ height: 0, opacity: 0 }}
      className="overflow-hidden"
    >
      <div className="px-4 py-4 border-t" style={{ borderColor: T.border, backgroundColor: '#FAFAF8' }}>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Col 1: Basic Info */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-semibold tracking-wider uppercase" style={{ color: T.textMuted }}>Details</h4>
              {!editing ? (
                <button onClick={startEdit} className="flex items-center gap-1 text-[11px] cursor-pointer hover:opacity-70" style={{ color: T.info }}>
                  <Pencil size={12} /> Edit
                </button>
              ) : (
                <div className="flex gap-1">
                  <button onClick={saveEdit} disabled={saving} className="flex items-center gap-1 text-[11px] cursor-pointer hover:opacity-70" style={{ color: T.accent }}>
                    {saving ? <Loader2 size={12} className="animate-spin" /> : <Save size={12} />} Save
                  </button>
                  <button onClick={() => setEditing(false)} className="flex items-center gap-1 text-[11px] cursor-pointer hover:opacity-70" style={{ color: T.textMuted }}>
                    <X size={12} /> Cancel
                  </button>
                </div>
              )}
            </div>

            {editing ? (
              <div className="space-y-2">
                <input value={draft.name || ''} onChange={e => setDraft({ ...draft, name: e.target.value })}
                  className="w-full px-2 py-1.5 text-sm rounded border" style={{ borderColor: T.border }} placeholder="Name" />
                <input value={draft.nameZh || ''} onChange={e => setDraft({ ...draft, nameZh: e.target.value })}
                  className="w-full px-2 py-1.5 text-sm rounded border" style={{ borderColor: T.border }} placeholder="Chinese name" />
                <textarea value={draft.description || ''} onChange={e => setDraft({ ...draft, description: e.target.value })}
                  className="w-full px-2 py-1.5 text-sm rounded border resize-none" rows={3} style={{ borderColor: T.border }} placeholder="Description" />
                <div className="grid grid-cols-2 gap-2">
                  <input value={draft.district || ''} onChange={e => setDraft({ ...draft, district: e.target.value })}
                    className="w-full px-2 py-1.5 text-sm rounded border" style={{ borderColor: T.border }} placeholder="District" />
                  <input value={draft.category || ''} onChange={e => setDraft({ ...draft, category: e.target.value })}
                    className="w-full px-2 py-1.5 text-sm rounded border" style={{ borderColor: T.border }} placeholder="Category" />
                </div>
                <input value={draft.address || ''} onChange={e => setDraft({ ...draft, address: e.target.value })}
                  className="w-full px-2 py-1.5 text-sm rounded border" style={{ borderColor: T.border }} placeholder="Address" />
              </div>
            ) : (
              <div className="space-y-2 text-sm">
                <div><span style={{ color: T.textMuted }} className="text-[11px]">Name:</span> <span style={{ color: T.text }}>{venue.name}</span></div>
                {venue.nameZh && <div><span style={{ color: T.textMuted }} className="text-[11px]">中文:</span> <span style={{ color: T.text }}>{venue.nameZh}</span></div>}
                <div><span style={{ color: T.textMuted }} className="text-[11px]">Category:</span> <span style={{ color: T.text }}>{venue.category || '—'} / {venue.subcategory || '—'}</span></div>
                <div><span style={{ color: T.textMuted }} className="text-[11px]">District:</span> <span style={{ color: T.text }}>{venue.district || '—'}</span></div>
                <div><span style={{ color: T.textMuted }} className="text-[11px]">Address:</span> <span style={{ color: T.text }}>{venue.address || '—'}</span></div>
                {venue.description && (
                  <div><span style={{ color: T.textMuted }} className="text-[11px]">Description:</span>
                    <p className="text-xs mt-0.5 leading-relaxed" style={{ color: T.text }}>{venue.description}</p>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Col 2: Mode Scores & Tags */}
          <div className="space-y-3">
            <h4 className="text-xs font-semibold tracking-wider uppercase" style={{ color: T.textMuted }}>Mode Scores & Tags</h4>
            <div className="mb-2">
              <span className="text-[11px] block mb-1" style={{ color: T.textMuted }}>Appears in:</span>
              <ModeTagChips modeScores={venue.modeScores} />
            </div>
            <div className="space-y-1.5">
              {Object.entries(venue.modeScores || {}).map(([mode, score]) => {
                const cfg = MODE_TAG_CONFIG[mode];
                return (
                <div key={mode} className="flex items-center gap-2">
                  <span className="text-[11px] w-16" style={{ color: cfg?.color || T.textMuted }}>{cfg?.label || mode}</span>
                  <div className="flex-1 h-1.5 rounded-full overflow-hidden" style={{ backgroundColor: T.border }}>
                    <div className="h-full rounded-full" style={{ width: `${(score as number) * 100}%`, backgroundColor: cfg?.color || T.accent }} />
                  </div>
                  <span className="text-[11px] tabular-nums" style={{ color: T.text }}>{Math.round((score as number) * 100)}%</span>
                </div>
                );
              })}
              {(!venue.modeScores || Object.keys(venue.modeScores).length === 0) && (
                <span className="text-[11px]" style={{ color: T.warning }}>No mode scores set</span>
              )}
            </div>
            <div>
              <span className="text-[11px]" style={{ color: T.textMuted }}>Vibe Tags:</span>
              <div className="flex flex-wrap gap-1 mt-1">
                {(venue.vibeTags || []).map(tag => (
                  <span key={tag} className="px-2 py-0.5 text-[11px] rounded-full" style={{ backgroundColor: T.accentLight, color: T.accent }}>#{tag}</span>
                ))}
                {(!venue.vibeTags || venue.vibeTags.length === 0) && (
                  <span className="text-[11px]" style={{ color: T.warning }}>No tags</span>
                )}
              </div>
            </div>
            <div><span className="text-[11px]" style={{ color: T.textMuted }}>Price:</span> <span className="text-sm">{'$'.repeat(venue.priceRange || 0)}</span></div>
          </div>

          {/* Col 3: Google Data & Image */}
          <div className="space-y-3">
            <h4 className="text-xs font-semibold tracking-wider uppercase" style={{ color: T.textMuted }}>Google Places Data</h4>
            <div className="space-y-1.5 text-[12px]">
              {venue.googleRating && (
                <div className="flex items-center gap-1.5"><Star size={12} style={{ color: T.warning }} /> {venue.googleRating}/5 ({venue.googleUserRatings || 0} reviews)</div>
              )}
              {venue.googleWebsite && (
                <a href={venue.googleWebsite} target="_blank" rel="noopener" className="flex items-center gap-1.5 hover:underline" style={{ color: T.info }}>
                  <Globe size={12} /> Website
                </a>
              )}
              {venue.googlePhone && (
                <div className="flex items-center gap-1.5" style={{ color: T.text }}><Phone size={12} /> {venue.googlePhone}</div>
              )}
              {venue.googleMapsUrl && (
                <a href={venue.googleMapsUrl} target="_blank" rel="noopener" className="flex items-center gap-1.5 hover:underline" style={{ color: T.info }}>
                  <ExternalLink size={12} /> Google Maps
                </a>
              )}
              {venue._reparsedAt && (
                <div className="flex items-center gap-1.5" style={{ color: T.textMuted }}>
                  <Clock size={12} /> Parsed: {new Date(venue._reparsedAt).toLocaleDateString()}
                </div>
              )}
              {venue._enrichedAt && (
                <div className="flex items-center gap-1.5" style={{ color: T.textMuted }}>
                  <Sparkles size={12} /> Enriched: {new Date(venue._enrichedAt).toLocaleDateString()}
                </div>
              )}
            </div>
            {venue.image && (
              <div className="rounded overflow-hidden aspect-video" style={{ border: `1px solid ${T.border}` }}>
                <img src={venue.image} alt={venue.name} className="w-full h-full object-cover" />
              </div>
            )}
            {!venue.image && (
              <div className="rounded flex items-center justify-center aspect-video" style={{ backgroundColor: T.border }}>
                <ImageIcon size={24} style={{ color: T.textMuted }} />
              </div>
            )}
            <div className="text-[10px] font-mono break-all" style={{ color: T.textMuted }}>{venue.id}</div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

// ═══ MAIN COMPONENT ═══
export function VenueManager() {
  const { accessToken } = useOutletContext<{ accessToken: string }>();
  const [venues, setVenues] = useState<Venue[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [sortField, setSortField] = useState<SortField>('name');
  const [sortDir, setSortDir] = useState<SortDir>('asc');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [filterCompleteness, setFilterCompleteness] = useState<string>('all');
  const [filterMode, setFilterMode] = useState<string>('all');

  // Operation states
  const [deleting, setDeleting] = useState(false);
  const [reparsing, setReparsing] = useState<Set<string>>(new Set());
  const [enriching, setEnriching] = useState<Set<string>>(new Set());
  const [bulkReparsing, setBulkReparsing] = useState(false);
  const [bulkEnriching, setBulkEnriching] = useState(false);
  const [showDedupModal, setShowDedupModal] = useState(false);
  const [dedupDeleting, setDedupDeleting] = useState(false);
  const [toast, setToast] = useState<{ msg: string; type: 'success' | 'error' | 'info' } | null>(null);

  const showToast = (msg: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 4000);
  };

  // ─── Fetch venues ───
  const fetchVenues = useCallback(async () => {
    if (!accessToken) return;
    setLoading(true);
    try {
      const res = await fetch(`${CMS_BASE}/content/venue`, {
        headers: authHeaders(accessToken),
      });
      const data = await res.json();
      setVenues(data.items || []);
    } catch (err) {
      console.error('Fetch venues error:', err);
      showToast('Failed to fetch venues', 'error');
    }
    setLoading(false);
  }, [accessToken]);

  useEffect(() => { fetchVenues(); }, [fetchVenues]);

  // ─── Categories ───
  const categories = useMemo(() => {
    const cats = new Set(venues.map(v => v.category || 'uncategorized'));
    return ['all', ...Array.from(cats).sort()];
  }, [venues]);

  // ─── Filter & Sort ───
  const filteredVenues = useMemo(() => {
    let result = venues;

    // Search
    if (search) {
      const q = search.toLowerCase();
      result = result.filter(v =>
        v.name.toLowerCase().includes(q) ||
        (v.nameZh || '').toLowerCase().includes(q) ||
        (v.district || '').toLowerCase().includes(q) ||
        (v.address || '').toLowerCase().includes(q) ||
        (v.category || '').toLowerCase().includes(q)
      );
    }

    // Category filter
    if (filterCategory !== 'all') {
      result = result.filter(v => (v.category || 'uncategorized') === filterCategory);
    }

    // Completeness filter
    if (filterCompleteness === 'incomplete') {
      result = result.filter(v => getCompleteness(v) < 100);
    } else if (filterCompleteness === 'missing-desc') {
      result = result.filter(v => !v.description || v.description.length < 10);
    } else if (filterCompleteness === 'missing-image') {
      result = result.filter(v => !v.image);
    } else if (filterCompleteness === 'missing-tags') {
      result = result.filter(v => !v.vibeTags || v.vibeTags.length === 0);
    }

    // Mode filter
    if (filterMode !== 'all') {
      result = result.filter(v => v.modeScores && v.modeScores[filterMode] >= (MODE_TAG_CONFIG[filterMode]?.threshold ?? 0.3));
    }

    // Sort
    result = [...result].sort((a, b) => {
      let cmp = 0;
      switch (sortField) {
        case 'name': cmp = a.name.localeCompare(b.name); break;
        case 'district': cmp = (a.district || '').localeCompare(b.district || ''); break;
        case 'category': cmp = (a.category || '').localeCompare(b.category || ''); break;
        case 'completeness': cmp = getCompleteness(a) - getCompleteness(b); break;
        case '_createdAt': cmp = (a._createdAt || '').localeCompare(b._createdAt || ''); break;
      }
      return sortDir === 'asc' ? cmp : -cmp;
    });

    return result;
  }, [venues, search, filterCategory, filterCompleteness, filterMode, sortField, sortDir]);

  // ─── Selection helpers ───
  const allSelected = filteredVenues.length > 0 && filteredVenues.every(v => selected.has(v.id));
  const someSelected = selected.size > 0;

  const toggleAll = () => {
    if (allSelected) {
      setSelected(new Set());
    } else {
      setSelected(new Set(filteredVenues.map(v => v.id)));
    }
  };

  const toggleOne = (id: string) => {
    const next = new Set(selected);
    if (next.has(id)) next.delete(id); else next.add(id);
    setSelected(next);
  };

  // ─── Bulk Delete ───
  const bulkDelete = async () => {
    if (selected.size === 0) return;
    if (!confirm(`Delete ${selected.size} venue(s)? This cannot be undone.`)) return;
    setDeleting(true);
    try {
      const res = await fetch(`${CMS_BASE}/venues/bulk-delete`, {
        method: 'POST',
        headers: authHeaders(accessToken),
        body: JSON.stringify({ ids: Array.from(selected) }),
      });
      const data = await res.json();
      if (data.status === 'deleted') {
        setVenues(prev => prev.filter(v => !selected.has(v.id)));
        showToast(`Deleted ${data.count} venue(s)`);
        setSelected(new Set());
      } else {
        showToast(data.error || 'Delete failed', 'error');
      }
    } catch (err) {
      showToast('Delete failed', 'error');
    }
    setDeleting(false);
  };

  // ─── Single Reparse ───
  const reparseVenue = async (id: string) => {
    setReparsing(prev => new Set(prev).add(id));
    try {
      const res = await fetch(`${CMS_BASE}/venues/reparse`, {
        method: 'POST',
        headers: authHeaders(accessToken),
        body: JSON.stringify({ id }),
      });
      const data = await res.json();
      if (data.venue) {
        setVenues(prev => prev.map(v => v.id === id ? data.venue : v));
        showToast(`Re-parsed "${data.venue.name}" — ${data.fieldsUpdated?.length || 0} fields`);
      } else {
        showToast(data.error || 'Reparse failed', 'error');
      }
    } catch (err) {
      showToast('Reparse failed', 'error');
    }
    setReparsing(prev => { const s = new Set(prev); s.delete(id); return s; });
  };

  // ─── Single AI Enrich ───
  const enrichVenue = async (id: string) => {
    setEnriching(prev => new Set(prev).add(id));
    try {
      const res = await fetch(`${CMS_BASE}/venues/ai-enrich`, {
        method: 'POST',
        headers: authHeaders(accessToken),
        body: JSON.stringify({ id }),
      });
      const data = await res.json();
      if (data.venue) {
        setVenues(prev => prev.map(v => v.id === id ? data.venue : v));
        if (data.status === 'no_changes') {
          showToast(`"${data.venue.name}" already complete`, 'info');
        } else {
          showToast(`Enriched "${data.venue.name}" via ${data.engine || 'AI'} — ${data.fieldsEnriched?.join(', ')}`);
        }
      } else {
        showToast(data.error || 'Enrich failed', 'error');
      }
    } catch (err) {
      showToast('Enrich failed', 'error');
    }
    setEnriching(prev => { const s = new Set(prev); s.delete(id); return s; });
  };

  // ─── Bulk Reparse Selected ───
  const bulkReparse = async () => {
    if (selected.size === 0) return;
    setBulkReparsing(true);
    let success = 0;
    const ids = Array.from(selected);
    for (const id of ids) {
      try {
        const res = await fetch(`${CMS_BASE}/venues/reparse`, {
          method: 'POST',
          headers: authHeaders(accessToken),
          body: JSON.stringify({ id }),
        });
        const data = await res.json();
        if (data.venue) {
          setVenues(prev => prev.map(v => v.id === id ? data.venue : v));
          success++;
        }
      } catch {}
      // Small delay to avoid rate limiting
      await new Promise(r => setTimeout(r, 300));
    }
    showToast(`Re-parsed ${success}/${ids.length} venues`);
    setBulkReparsing(false);
  };

  // ─── Bulk AI Enrich Selected ───
  const bulkEnrich = async () => {
    if (selected.size === 0) return;
    setBulkEnriching(true);
    let success = 0;
    const ids = Array.from(selected);
    for (const id of ids) {
      try {
        const res = await fetch(`${CMS_BASE}/venues/ai-enrich`, {
          method: 'POST',
          headers: authHeaders(accessToken),
          body: JSON.stringify({ id }),
        });
        const data = await res.json();
        if (data.venue) {
          setVenues(prev => prev.map(v => v.id === id ? data.venue : v));
          if (data.status !== 'no_changes') success++;
        }
      } catch {}
      await new Promise(r => setTimeout(r, 100));
    }
    showToast(`Enriched ${success}/${ids.length} venues`);
    setBulkEnriching(false);
  };

  // ─── Duplicate Detection ───
  // Normalize name for comparison: lowercase, strip punctuation, collapse whitespace
  const normalizeName = (name: string) =>
    name.toLowerCase().replace(/[''"""`.,!?·\-–—()（）[\]]/g, '').replace(/\s+/g, ' ').trim();

  type DupGroup = { key: string; venues: Venue[] };

  const duplicateGroups = useMemo<DupGroup[]>(() => {
    const groups = new Map<string, Venue[]>();
    for (const v of venues) {
      const norm = normalizeName(v.name);
      if (!norm) continue;
      const list = groups.get(norm) || [];
      list.push(v);
      groups.set(norm, list);
    }
    return Array.from(groups.entries())
      .filter(([, list]) => list.length > 1)
      .map(([key, vlist]) => ({ key, venues: vlist }))
      .sort((a, b) => b.venues.length - a.venues.length);
  }, [venues]);

  const totalDuplicates = duplicateGroups.reduce((sum, g) => sum + g.venues.length - 1, 0);

  // For each dup group, auto-select the "best" venue to keep (highest completeness)
  const [keepIds, setKeepIds] = useState<Record<string, string>>({});

  const getKeepId = (group: DupGroup) => {
    if (keepIds[group.key]) return keepIds[group.key];
    // Default: keep the one with highest completeness, or first if tied
    const sorted = [...group.venues].sort((a, b) => getCompleteness(b) - getCompleteness(a));
    return sorted[0].id;
  };

  const handleDedupDelete = async () => {
    const idsToDelete: string[] = [];
    for (const group of duplicateGroups) {
      const keep = getKeepId(group);
      for (const v of group.venues) {
        if (v.id !== keep) idsToDelete.push(v.id);
      }
    }
    if (idsToDelete.length === 0) { showToast('Nothing to delete', 'info'); return; }
    if (!confirm(`Delete ${idsToDelete.length} duplicate venue(s)? This cannot be undone.`)) return;

    setDedupDeleting(true);
    try {
      const res = await fetch(`${CMS_BASE}/venues/bulk-delete`, {
        method: 'POST',
        headers: authHeaders(accessToken),
        body: JSON.stringify({ ids: idsToDelete }),
      });
      const data = await res.json();
      if (data.status === 'deleted') {
        const deleteSet = new Set(idsToDelete);
        setVenues(prev => prev.filter(v => !deleteSet.has(v.id)));
        showToast(`Removed ${data.count} duplicate(s)`);
        setShowDedupModal(false);
        setKeepIds({});
      } else {
        showToast(data.error || 'Delete failed', 'error');
      }
    } catch (err) {
      showToast('Dedup delete failed', 'error');
    }
    setDedupDeleting(false);
  };

  // ─── Sort toggle ───
  const toggleSort = (field: SortField) => {
    if (sortField === field) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortField(field); setSortDir('asc'); }
  };

  const SortIcon = ({ field }: { field: SortField }) => (
    sortField === field
      ? (sortDir === 'asc' ? <ChevronUp size={12} /> : <ChevronDown size={12} />)
      : <ArrowUpDown size={10} style={{ opacity: 0.3 }} />
  );

  // Stats
  const totalVenues = venues.length;
  const incompleteCount = venues.filter(v => getCompleteness(v) < 100).length;
  const missingDescCount = venues.filter(v => !v.description || v.description.length < 10).length;
  const missingImageCount = venues.filter(v => !v.image).length;

  return (
    <div className="p-5 sm:p-8 lg:p-10 max-w-[1200px] mx-auto space-y-4" style={{ fontFamily: T.font }}>
      {/* ─── Header ─── */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold" style={{ color: T.text }}>Venue Manager</h1>
          <p className="text-sm mt-0.5" style={{ color: T.textMuted }}>
            {totalVenues} venues · {incompleteCount} incomplete · {missingDescCount} missing descriptions
          </p>
        </div>
        <div className="flex items-center gap-2">
          {totalDuplicates > 0 && (
            <button
              onClick={() => setShowDedupModal(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs rounded cursor-pointer hover:opacity-80 transition-opacity"
              style={{ backgroundColor: T.warningLight, border: `1px solid ${T.warning}40`, color: '#92400E' }}
            >
              <Copy size={13} /> {totalDuplicates} Duplicate{totalDuplicates !== 1 ? 's' : ''}
            </button>
          )}
          <button
            onClick={fetchVenues}
            disabled={loading}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs rounded cursor-pointer hover:opacity-80 transition-opacity"
            style={{ backgroundColor: T.surface, border: `1px solid ${T.border}`, color: T.text }}
          >
            <RotateCcw size={13} className={loading ? 'animate-spin' : ''} /> Refresh
          </button>
        </div>
      </div>

      {/* ─── Stats Cards ─── */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: 'Total', value: totalVenues, color: T.text, bg: T.surface },
          { label: 'Incomplete', value: incompleteCount, color: T.warning, bg: T.warningLight },
          { label: 'No Description', value: missingDescCount, color: T.danger, bg: T.dangerLight },
          { label: 'No Image', value: missingImageCount, color: T.info, bg: T.infoLight },
        ].map(s => (
          <div key={s.label} className="p-3 rounded-lg" style={{ backgroundColor: s.bg, border: `1px solid ${T.border}` }}>
            <div className="text-xl font-bold tabular-nums" style={{ color: s.color }}>{s.value}</div>
            <div className="text-[11px] mt-0.5" style={{ color: T.textMuted }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* ─── Search & Filters ─── */}
      <div className="flex flex-col sm:flex-row gap-2">
        <div className="relative flex-1">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: T.textMuted }} />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search venues..."
            className="w-full pl-9 pr-3 py-2 text-sm rounded-lg border focus:outline-none focus:ring-2"
            style={{ borderColor: T.border, backgroundColor: T.surface, color: T.text }}
          />
        </div>
        <select
          value={filterCategory}
          onChange={e => setFilterCategory(e.target.value)}
          className="px-3 py-2 text-sm rounded-lg border cursor-pointer"
          style={{ borderColor: T.border, backgroundColor: T.surface, color: T.text }}
        >
          {categories.map(c => (
            <option key={c} value={c}>{c === 'all' ? 'All Categories' : c}</option>
          ))}
        </select>
        <select
          value={filterCompleteness}
          onChange={e => setFilterCompleteness(e.target.value)}
          className="px-3 py-2 text-sm rounded-lg border cursor-pointer"
          style={{ borderColor: T.border, backgroundColor: T.surface, color: T.text }}
        >
          <option value="all">All Status</option>
          <option value="incomplete">Incomplete Only</option>
          <option value="missing-desc">Missing Description</option>
          <option value="missing-image">Missing Image</option>
          <option value="missing-tags">Missing Tags</option>
        </select>
        <select
          value={filterMode}
          onChange={e => setFilterMode(e.target.value)}
          className="px-3 py-2 text-sm rounded-lg border cursor-pointer"
          style={{ borderColor: T.border, backgroundColor: T.surface, color: T.text }}
        >
          <option value="all">All Modes</option>
          {Object.entries(MODE_TAG_CONFIG).map(([mode, cfg]) => (
            <option key={mode} value={mode}>{cfg.label}</option>
          ))}
        </select>
      </div>

      {/* ─── Bulk Actions Bar ─── */}
      <AnimatePresence>
        {someSelected && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="flex items-center gap-2 p-3 rounded-lg" style={{ backgroundColor: T.accentLight, border: `1px solid ${T.accent}30` }}>
              <span className="text-sm font-medium" style={{ color: T.accent }}>
                {selected.size} selected
              </span>
              <div className="flex-1" />
              <button
                onClick={bulkReparse}
                disabled={bulkReparsing}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs rounded cursor-pointer hover:opacity-80 transition-opacity"
                style={{ backgroundColor: T.surface, border: `1px solid ${T.border}`, color: T.text }}
              >
                {bulkReparsing ? <Loader2 size={13} className="animate-spin" /> : <RefreshCw size={13} />}
                Re-parse{bulkReparsing ? 'ing...' : ' Selected'}
              </button>
              <button
                onClick={bulkEnrich}
                disabled={bulkEnriching}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs rounded cursor-pointer hover:opacity-80 transition-opacity"
                style={{ backgroundColor: T.surface, border: `1px solid ${T.border}`, color: T.text }}
              >
                {bulkEnriching ? <Loader2 size={13} className="animate-spin" /> : <Sparkles size={13} />}
                AI Enrich{bulkEnriching ? 'ing...' : ' Selected'}
              </button>
              <button
                onClick={bulkDelete}
                disabled={deleting}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs rounded cursor-pointer hover:opacity-80 transition-opacity"
                style={{ backgroundColor: T.dangerLight, border: `1px solid ${T.danger}30`, color: T.danger }}
              >
                {deleting ? <Loader2 size={13} className="animate-spin" /> : <Trash2 size={13} />}
                Delete{deleting ? 'ing...' : ' Selected'}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ─── Table ─── */}
      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 size={24} className="animate-spin" style={{ color: T.textMuted }} />
        </div>
      ) : filteredVenues.length === 0 ? (
        <div className="text-center py-16">
          <MapPin size={32} className="mx-auto mb-3" style={{ color: T.textMuted }} />
          <p className="text-sm" style={{ color: T.textMuted }}>
            {venues.length === 0 ? 'No CMS venues found. Use Bulk Import to add venues.' : 'No venues match your filters.'}
          </p>
        </div>
      ) : (
        <div className="rounded-lg overflow-hidden" style={{ border: `1px solid ${T.border}`, backgroundColor: T.surface }}>
          {/* Table Header */}
          <div className="hidden sm:grid grid-cols-[40px_1fr_90px_90px_130px_100px_120px_90px] items-center px-3 py-2 text-[11px] font-semibold tracking-wider uppercase"
            style={{ backgroundColor: '#F5F4F0', color: T.textMuted, borderBottom: `1px solid ${T.border}` }}>
            <div className="flex items-center justify-center">
              <button onClick={toggleAll} className="cursor-pointer hover:opacity-70">
                {allSelected ? <CheckSquare size={16} style={{ color: T.accent }} /> : <Square size={16} />}
              </button>
            </div>
            <button onClick={() => toggleSort('name')} className="flex items-center gap-1 cursor-pointer hover:opacity-70 text-left">
              Venue <SortIcon field="name" />
            </button>
            <button onClick={() => toggleSort('district')} className="flex items-center gap-1 cursor-pointer hover:opacity-70">
              District <SortIcon field="district" />
            </button>
            <button onClick={() => toggleSort('category')} className="flex items-center gap-1 cursor-pointer hover:opacity-70">
              Category <SortIcon field="category" />
            </button>
            <div>Modes</div>
            <button onClick={() => toggleSort('completeness')} className="flex items-center gap-1 cursor-pointer hover:opacity-70">
              Complete <SortIcon field="completeness" />
            </button>
            <div>Missing</div>
            <div className="text-right">Actions</div>
          </div>

          {/* Mobile header */}
          <div className="sm:hidden flex items-center px-3 py-2 text-[11px] font-semibold tracking-wider uppercase"
            style={{ backgroundColor: '#F5F4F0', color: T.textMuted, borderBottom: `1px solid ${T.border}` }}>
            <button onClick={toggleAll} className="cursor-pointer hover:opacity-70 mr-3">
              {allSelected ? <CheckSquare size={16} style={{ color: T.accent }} /> : <Square size={16} />}
            </button>
            <span>Venues ({filteredVenues.length})</span>
          </div>

          {/* Rows */}
          {filteredVenues.map((venue) => {
            const completeness = getCompleteness(venue);
            const missing = getMissingFields(venue);
            const isExpanded = expandedId === venue.id;
            const isParsing = reparsing.has(venue.id);
            const isEnriching = enriching.has(venue.id);

            return (
              <div key={venue.id} style={{ borderBottom: `1px solid ${T.border}` }}>
                {/* Desktop row */}
                <div
                  className="hidden sm:grid grid-cols-[40px_1fr_90px_90px_130px_100px_120px_90px] items-center px-3 py-2.5 hover:bg-black/[0.015] transition-colors cursor-pointer"
                  onClick={() => setExpandedId(isExpanded ? null : venue.id)}
                >
                  {/* Checkbox */}
                  <div className="flex items-center justify-center" onClick={e => e.stopPropagation()}>
                    <button onClick={() => toggleOne(venue.id)} className="cursor-pointer hover:opacity-70">
                      {selected.has(venue.id)
                        ? <CheckSquare size={16} style={{ color: T.accent }} />
                        : <Square size={16} style={{ color: T.textMuted }} />
                      }
                    </button>
                  </div>

                  {/* Name + image thumb */}
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-9 h-9 rounded flex-shrink-0 overflow-hidden" style={{ backgroundColor: T.border }}>
                      {venue.image ? (
                        <img src={venue.image} alt="" className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center"><ImageIcon size={14} style={{ color: T.textMuted }} /></div>
                      )}
                    </div>
                    <div className="min-w-0">
                      <div className="text-sm font-medium truncate flex items-center gap-1.5" style={{ color: T.text }}>
                        {venue.name}
                        {(venue._source === 'mock' || /^v\d+$/.test(venue.id || '')) && (
                          <span className="shrink-0 text-[9px] font-semibold uppercase tracking-wider px-1.5 py-0.5 rounded" style={{ background: '#FEF3C7', color: '#92400E', border: '1px solid #FDE68A' }}>Mock</span>
                        )}
                      </div>
                      {venue.nameZh && <div className="text-[11px] truncate" style={{ color: T.textMuted }}>{venue.nameZh}</div>}
                    </div>
                  </div>

                  {/* District */}
                  <div className="text-xs truncate" style={{ color: T.textMuted }}>{venue.district || '—'}</div>

                  {/* Category */}
                  <div className="text-xs truncate" style={{ color: T.textMuted }}>{venue.category || '—'}</div>

                  {/* Modes */}
                  <div><ModeTagChips modeScores={venue.modeScores} /></div>

                  {/* Completeness */}
                  <div className="pr-2"><CompletenessBar value={completeness} /></div>

                  {/* Missing fields */}
                  <div><MissingChips fields={missing} /></div>

                  {/* Actions */}
                  <div className="flex items-center justify-end gap-1" onClick={e => e.stopPropagation()}>
                    <button
                      onClick={() => reparseVenue(venue.id)}
                      disabled={isParsing}
                      title="Re-parse from Google"
                      className="p-1.5 rounded cursor-pointer hover:bg-black/5 transition-colors"
                      style={{ color: T.info }}
                    >
                      {isParsing ? <Loader2 size={14} className="animate-spin" /> : <RefreshCw size={14} />}
                    </button>
                    <button
                      onClick={() => enrichVenue(venue.id)}
                      disabled={isEnriching}
                      title="AI Enrich"
                      className="p-1.5 rounded cursor-pointer hover:bg-black/5 transition-colors"
                      style={{ color: T.warning }}
                    >
                      {isEnriching ? <Loader2 size={14} className="animate-spin" /> : <Sparkles size={14} />}
                    </button>
                    <button
                      onClick={() => setExpandedId(isExpanded ? null : venue.id)}
                      title="Details"
                      className="p-1.5 rounded cursor-pointer hover:bg-black/5 transition-colors"
                      style={{ color: T.textMuted }}
                    >
                      {isExpanded ? <ChevronUp size={14} /> : <Eye size={14} />}
                    </button>
                  </div>
                </div>

                {/* Mobile row */}
                <div
                  className="sm:hidden flex items-center gap-3 px-3 py-3 hover:bg-black/[0.015] transition-colors cursor-pointer"
                  onClick={() => setExpandedId(isExpanded ? null : venue.id)}
                >
                  <div onClick={e => e.stopPropagation()}>
                    <button onClick={() => toggleOne(venue.id)} className="cursor-pointer hover:opacity-70">
                      {selected.has(venue.id)
                        ? <CheckSquare size={16} style={{ color: T.accent }} />
                        : <Square size={16} style={{ color: T.textMuted }} />
                      }
                    </button>
                  </div>
                  <div className="w-10 h-10 rounded flex-shrink-0 overflow-hidden" style={{ backgroundColor: T.border }}>
                    {venue.image ? (
                      <img src={venue.image} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center"><ImageIcon size={14} style={{ color: T.textMuted }} /></div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium truncate" style={{ color: T.text }}>{venue.name}</div>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-[11px]" style={{ color: T.textMuted }}>{venue.district || '—'}</span>
                      <span className="text-[11px]" style={{ color: T.textMuted }}>·</span>
                      <CompletenessBar value={completeness} />
                    </div>
                    <div className="mt-1"><ModeTagChips modeScores={venue.modeScores} /></div>
                  </div>
                  <div className="flex items-center gap-1" onClick={e => e.stopPropagation()}>
                    <button onClick={() => reparseVenue(venue.id)} disabled={isParsing}
                      className="p-1.5 rounded cursor-pointer" style={{ color: T.info }}>
                      {isParsing ? <Loader2 size={14} className="animate-spin" /> : <RefreshCw size={14} />}
                    </button>
                    <button onClick={() => enrichVenue(venue.id)} disabled={isEnriching}
                      className="p-1.5 rounded cursor-pointer" style={{ color: T.warning }}>
                      {isEnriching ? <Loader2 size={14} className="animate-spin" /> : <Sparkles size={14} />}
                    </button>
                  </div>
                </div>

                {/* Expanded detail panel */}
                <AnimatePresence>
                  {isExpanded && (
                    <VenueDetailPanel
                      venue={venue}
                      onUpdate={(updated) => setVenues(prev => prev.map(v => v.id === updated.id ? updated : v))}
                      onClose={() => setExpandedId(null)}
                      accessToken={accessToken}
                    />
                  )}
                </AnimatePresence>
              </div>
            );
          })}

          {/* Footer */}
          <div className="px-3 py-2 text-[11px] flex items-center justify-between" style={{ backgroundColor: '#F5F4F0', color: T.textMuted }}>
            <span>Showing {filteredVenues.length} of {totalVenues} venues</span>
            <span>{selected.size > 0 ? `${selected.size} selected` : ''}</span>
          </div>
        </div>
      )}

      {/* ─── Dedup Modal ─── */}
      <AnimatePresence>
        {showDedupModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4"
            onClick={() => setShowDedupModal(false)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-2xl max-h-[80vh] overflow-hidden rounded-xl shadow-2xl flex flex-col"
              style={{ backgroundColor: T.surface, fontFamily: T.font }}
              onClick={e => e.stopPropagation()}
            >
              {/* Modal header */}
              <div className="flex items-center justify-between px-5 py-4 border-b" style={{ borderColor: T.border }}>
                <div>
                  <h2 className="text-base font-bold" style={{ color: T.text }}>
                    Remove Duplicates
                  </h2>
                  <p className="text-xs mt-0.5" style={{ color: T.textMuted }}>
                    {duplicateGroups.length} group{duplicateGroups.length !== 1 ? 's' : ''} · {totalDuplicates} duplicate{totalDuplicates !== 1 ? 's' : ''} to remove
                  </p>
                </div>
                <button onClick={() => setShowDedupModal(false)} className="p-1.5 rounded hover:bg-black/5 cursor-pointer" style={{ color: T.textMuted }}>
                  <X size={18} />
                </button>
              </div>

              {/* Modal body */}
              <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
                {duplicateGroups.length === 0 ? (
                  <div className="text-center py-10">
                    <Check size={32} className="mx-auto mb-2" style={{ color: T.accent }} />
                    <p className="text-sm" style={{ color: T.textMuted }}>No duplicates found!</p>
                  </div>
                ) : (
                  duplicateGroups.map(group => {
                    const keepId = getKeepId(group);
                    return (
                      <div key={group.key} className="rounded-lg border overflow-hidden" style={{ borderColor: T.border }}>
                        <div className="px-3 py-2 text-xs font-semibold" style={{ backgroundColor: T.warningLight, color: '#92400E' }}>
                          <Copy size={12} className="inline mr-1.5" />
                          "{group.venues[0].name}" — {group.venues.length} copies
                        </div>
                        <div className="divide-y" style={{ borderColor: T.border }}>
                          {group.venues.map(v => {
                            const comp = getCompleteness(v);
                            const isKept = v.id === keepId;
                            return (
                              <div
                                key={v.id}
                                className="flex items-center gap-3 px-3 py-2.5 cursor-pointer hover:bg-black/[0.02] transition-colors"
                                onClick={() => setKeepIds(prev => ({ ...prev, [group.key]: v.id }))}
                                style={{ backgroundColor: isKept ? T.accentLight : undefined }}
                              >
                                {/* Radio indicator */}
                                <div
                                  className="w-4 h-4 rounded-full border-2 flex items-center justify-center flex-shrink-0"
                                  style={{
                                    borderColor: isKept ? T.accent : T.border,
                                    backgroundColor: isKept ? T.accent : 'transparent',
                                  }}
                                >
                                  {isKept && <div className="w-1.5 h-1.5 rounded-full bg-white" />}
                                </div>

                                {/* Thumbnail */}
                                <div className="w-8 h-8 rounded flex-shrink-0 overflow-hidden" style={{ backgroundColor: T.border }}>
                                  {v.image ? (
                                    <img src={v.image} alt="" className="w-full h-full object-cover" />
                                  ) : (
                                    <div className="w-full h-full flex items-center justify-center"><ImageIcon size={10} style={{ color: T.textMuted }} /></div>
                                  )}
                                </div>

                                {/* Info */}
                                <div className="flex-1 min-w-0">
                                  <div className="flex items-center gap-2">
                                    <span className="text-sm font-medium truncate" style={{ color: T.text }}>
                                      {v.name}
                                    </span>
                                    {isKept && (
                                      <span className="text-[9px] font-bold uppercase px-1.5 py-0.5 rounded" style={{ backgroundColor: T.accent, color: '#fff' }}>
                                        KEEP
                                      </span>
                                    )}
                                    {!isKept && (
                                      <span className="text-[9px] font-bold uppercase px-1.5 py-0.5 rounded" style={{ backgroundColor: T.dangerLight, color: T.danger }}>
                                        REMOVE
                                      </span>
                                    )}
                                  </div>
                                  <div className="flex items-center gap-3 mt-0.5">
                                    <span className="text-[10px]" style={{ color: T.textMuted }}>{v.district || 'No district'}</span>
                                    <span className="text-[10px]" style={{ color: T.textMuted }}>{v.category || 'No category'}</span>
                                    <span className="text-[10px] font-medium" style={{ color: comp >= 80 ? T.accent : comp >= 50 ? T.warning : T.danger }}>
                                      {comp}% complete
                                    </span>
                                  </div>
                                  <div className="text-[9px] font-mono mt-0.5" style={{ color: T.textMuted }}>{v.id}</div>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              {/* Modal footer */}
              {duplicateGroups.length > 0 && (
                <div className="flex items-center justify-between px-5 py-3 border-t" style={{ borderColor: T.border, backgroundColor: '#F5F4F0' }}>
                  <p className="text-xs" style={{ color: T.textMuted }}>
                    Click a row to change which venue to keep. The best one is pre-selected.
                  </p>
                  <button
                    onClick={handleDedupDelete}
                    disabled={dedupDeleting}
                    className="flex items-center gap-1.5 px-4 py-2 text-xs font-medium rounded-lg cursor-pointer hover:opacity-90 transition-opacity"
                    style={{ backgroundColor: T.danger, color: '#fff' }}
                  >
                    {dedupDeleting ? <Loader2 size={13} className="animate-spin" /> : <Trash2 size={13} />}
                    Remove {totalDuplicates} Duplicate{totalDuplicates !== 1 ? 's' : ''}
                  </button>
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ─── Toast ─── */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-6 right-6 z-50 flex items-center gap-2 px-4 py-3 rounded-lg shadow-lg"
            style={{
              backgroundColor: toast.type === 'error' ? T.danger : toast.type === 'info' ? T.info : T.accent,
              color: '#fff',
              fontFamily: T.font,
              maxWidth: 400,
            }}
          >
            {toast.type === 'error' ? <AlertTriangle size={16} /> : toast.type === 'info' ? <RefreshCw size={16} /> : <Check size={16} />}
            <span className="text-sm">{toast.msg}</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}