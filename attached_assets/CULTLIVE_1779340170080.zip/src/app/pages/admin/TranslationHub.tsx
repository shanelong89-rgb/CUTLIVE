import { useState, useCallback } from 'react';
import { useOutletContext } from 'react-router';
import { motion } from 'motion/react';
import {
  Globe, Sparkles, Loader2, Copy, Check, ArrowRight,
  RefreshCw, Info, Languages,
} from 'lucide-react';
import { projectId, publicAnonKey } from '../../config/supabase';

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-d507b98c/cms`;

const N = {
  pageBg: '#FAFAF8',
  surface: '#FFFFFF',
  surfaceMuted: '#F3F3F0',
  border: 'rgba(0,0,0,0.06)',
  text: '#1A1A1A',
  textSecondary: '#5A5A5A',
  textMuted: '#9A9A9A',
  dark: '#1A1A1A',
  green: '#16A34A',
  greenBg: 'rgba(22,163,74,0.06)',
  amber: '#D97706',
  amberBg: 'rgba(217,119,6,0.06)',
  blue: '#2563EB',
  blueBg: 'rgba(37,99,235,0.05)',
  purple: '#7C3AED',
  purpleBg: 'rgba(124,58,237,0.05)',
  font: "'Inter', 'Noto Sans HK', system-ui, sans-serif",
};

function authHeaders(accessToken: string) {
  return {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${publicAnonKey}`,
    'X-Auth-Token': accessToken,
  };
}

interface TranslationEntry {
  source: string;
  translated: string;
  lang: string;
  timestamp: string;
}

const LANG_OPTIONS = [
  { value: 'zh-HK', label: '繁體中文 (HK)', flag: '🇭🇰' },
  { value: 'zh-CN', label: '简体中文', flag: '🇨🇳' },
  { value: 'ja', label: '日本語', flag: '🇯🇵' },
  { value: 'ko', label: '한국어', flag: '🇰🇷' },
  { value: 'en', label: 'English', flag: '🇬🇧' },
];

export function TranslationHub() {
  const { accessToken } = useOutletContext<{ accessToken: string }>();
  const [sourceText, setSourceText] = useState('');
  const [targetLang, setTargetLang] = useState('zh-HK');
  const [translating, setTranslating] = useState(false);
  const [result, setResult] = useState('');
  const [copied, setCopied] = useState(false);
  const [history, setHistory] = useState<TranslationEntry[]>([]);

  // Batch translate
  const [batchInput, setBatchInput] = useState('');
  const [batchResult, setBatchResult] = useState<{ key: string; translated: string }[]>([]);
  const [batchTranslating, setBatchTranslating] = useState(false);

  const handleTranslate = useCallback(async () => {
    if (!sourceText.trim() || !accessToken) return;
    setTranslating(true);
    setResult('');
    try {
      const res = await fetch(`${API_BASE}/translate`, {
        method: 'POST',
        headers: authHeaders(accessToken),
        body: JSON.stringify({ text: sourceText, from: 'en', to: targetLang }),
      });
      const data = await res.json();
      if (data.translated) {
        setResult(data.translated);
        setHistory(prev => [{
          source: sourceText,
          translated: data.translated,
          lang: targetLang,
          timestamp: new Date().toISOString(),
        }, ...prev].slice(0, 20));
      } else if (data.error) {
        setResult(`Error: ${data.error}`);
      }
    } catch (err: any) {
      setResult(`Translation failed: ${err.message}`);
    }
    setTranslating(false);
  }, [sourceText, targetLang, accessToken]);

  const handleBatchTranslate = useCallback(async () => {
    if (!batchInput.trim() || !accessToken) return;
    setBatchTranslating(true);
    setBatchResult([]);
    try {
      // Parse input: one phrase per line, or key=value pairs
      const lines = batchInput.trim().split('\n').filter(Boolean);
      const items = lines.map(line => {
        const parts = line.split('=');
        if (parts.length >= 2) {
          return { key: parts[0].trim(), text: parts.slice(1).join('=').trim() };
        }
        return { key: line.trim().slice(0, 30), text: line.trim() };
      });

      const res = await fetch(`${API_BASE}/translate/batch`, {
        method: 'POST',
        headers: authHeaders(accessToken),
        body: JSON.stringify({ items: items.map(i => i.text), from: 'en', to: targetLang }),
      });
      const data = await res.json();
      if (data.translations) {
        setBatchResult(items.map((item, i) => ({
          key: item.key,
          translated: data.translations[i] || '',
        })));
      } else if (data.error) {
        setBatchResult([{ key: 'Error', translated: data.error }]);
      }
    } catch (err: any) {
      setBatchResult([{ key: 'Error', translated: err.message }]);
    }
    setBatchTranslating(false);
  }, [batchInput, targetLang, accessToken]);

  const copyText = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="p-5 sm:p-8 lg:p-10 max-w-[860px] mx-auto" style={{ fontFamily: N.font }}>
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="mb-6">
        <p className="text-[11px] font-medium uppercase tracking-wider mb-1.5"
          style={{ color: N.textMuted }}>Tools</p>
        <h1 className="text-[1.5rem] font-semibold tracking-tight" style={{ color: N.text }}>
          Translation Hub
        </h1>
        <p className="mt-1 text-[14px]" style={{ color: N.textMuted }}>
          AI-powered translation for site copy, event descriptions, and content.
        </p>
      </motion.div>

      {/* Info notice */}
      <div className="flex items-start gap-2.5 p-3.5 mb-6" style={{
        backgroundColor: N.purpleBg, borderRadius: '10px', border: '1px solid rgba(124,58,237,0.08)',
      }}>
        <Info size={15} className="flex-shrink-0 mt-0.5" style={{ color: N.purple }} />
        <p className="text-[12px] leading-relaxed" style={{ color: N.textSecondary }}>
          Translations use a rule-based approach with common HK Chinese patterns. For production,
          connect a Google Gemini API key in Settings to enable AI-powered translations with cultural context.
        </p>
      </div>

      {/* Target language selector */}
      <div className="flex items-center gap-3 mb-6">
        <span className="text-[12px] font-medium" style={{ color: N.textMuted }}>Target:</span>
        <div className="flex gap-1.5">
          {LANG_OPTIONS.map(lang => (
            <button key={lang.value} onClick={() => setTargetLang(lang.value)}
              className="flex items-center gap-1.5 px-3 py-1.5 text-[12px] cursor-pointer transition-colors"
              style={{
                backgroundColor: targetLang === lang.value ? N.dark : N.surface,
                color: targetLang === lang.value ? '#fff' : N.textSecondary,
                border: `1px solid ${targetLang === lang.value ? N.dark : N.border}`,
                borderRadius: '8px',
              }}>
              <span>{lang.flag}</span>
              <span className="hidden sm:inline">{lang.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* ═══ Single Translation ═══ */}
      <div className="mb-8 p-5 sm:p-6" style={{
        backgroundColor: N.surface, border: `1px solid ${N.border}`, borderRadius: '14px',
      }}>
        <div className="flex items-center gap-2 mb-4">
          <Languages size={16} style={{ color: N.blue }} />
          <h2 className="text-[14px] font-semibold" style={{ color: N.text }}>Single Translation</h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
          <div>
            <label className="block text-[11px] font-medium uppercase tracking-wider mb-1.5"
              style={{ color: N.textMuted }}>Source (English)</label>
            <textarea value={sourceText} onChange={e => setSourceText(e.target.value)}
              placeholder="Type or paste English text..."
              rows={4} className="w-full px-3.5 py-3 text-[13px] outline-none resize-none"
              style={{ backgroundColor: N.surfaceMuted, border: `1px solid ${N.border}`, borderRadius: '10px', color: N.text }}
            />
          </div>
          <div>
            <label className="block text-[11px] font-medium uppercase tracking-wider mb-1.5"
              style={{ color: N.textMuted }}>Translation</label>
            <div className="relative">
              <textarea value={result} readOnly
                placeholder="Translation will appear here..."
                rows={4} className="w-full px-3.5 py-3 text-[13px] outline-none resize-none"
                style={{ backgroundColor: result ? 'rgba(22,163,74,0.04)' : N.surfaceMuted, border: `1px solid ${result ? 'rgba(22,163,74,0.15)' : N.border}`, borderRadius: '10px', color: N.text }}
              />
              {result && (
                <button onClick={() => copyText(result)}
                  className="absolute top-2 right-2 p-1.5 cursor-pointer"
                  style={{ backgroundColor: N.surface, borderRadius: '6px', border: `1px solid ${N.border}` }}>
                  {copied ? <Check size={12} style={{ color: N.green }} /> : <Copy size={12} style={{ color: N.textMuted }} />}
                </button>
              )}
            </div>
          </div>
        </div>

        <button onClick={handleTranslate} disabled={translating || !sourceText.trim()}
          className="flex items-center gap-2 px-5 py-2.5 text-[13px] font-medium cursor-pointer transition-opacity disabled:opacity-40 hover:opacity-90"
          style={{ backgroundColor: N.dark, color: '#fff', borderRadius: '10px' }}>
          {translating ? <Loader2 size={14} className="animate-spin" /> : <Sparkles size={14} />}
          {translating ? 'Translating...' : 'Translate'}
        </button>
      </div>

      {/* ═══ Batch Translation ═══ */}
      <div className="mb-8 p-5 sm:p-6" style={{
        backgroundColor: N.surface, border: `1px solid ${N.border}`, borderRadius: '14px',
      }}>
        <div className="flex items-center gap-2 mb-4">
          <RefreshCw size={16} style={{ color: N.amber }} />
          <h2 className="text-[14px] font-semibold" style={{ color: N.text }}>Batch Translation</h2>
        </div>

        <p className="text-[12px] mb-3" style={{ color: N.textMuted }}>
          Paste multiple lines (one phrase per line). Optionally use <code className="px-1 py-0.5" style={{ backgroundColor: N.surfaceMuted, borderRadius: '3px' }}>key=value</code> format.
        </p>

        <textarea value={batchInput} onChange={e => setBatchInput(e.target.value)}
          placeholder={`home.hero.title=Discover Hong Kong Culture\nhome.hero.subtitle=Your guide to the city's vibrant cultural scene\nExplore Events`}
          rows={6} className="w-full px-3.5 py-3 text-[13px] outline-none resize-none mb-3 font-mono"
          style={{ backgroundColor: N.surfaceMuted, border: `1px solid ${N.border}`, borderRadius: '10px', color: N.text }}
        />

        <button onClick={handleBatchTranslate} disabled={batchTranslating || !batchInput.trim()}
          className="flex items-center gap-2 px-5 py-2.5 text-[13px] font-medium cursor-pointer transition-opacity disabled:opacity-40 hover:opacity-90 mb-4"
          style={{ backgroundColor: N.amber, color: '#fff', borderRadius: '10px' }}>
          {batchTranslating ? <Loader2 size={14} className="animate-spin" /> : <Sparkles size={14} />}
          {batchTranslating ? 'Translating...' : `Translate ${batchInput.trim().split('\n').filter(Boolean).length} items`}
        </button>

        {batchResult.length > 0 && (
          <div className="space-y-1">
            {batchResult.map((item, i) => (
              <div key={i} className="flex items-center gap-3 px-3 py-2 text-[12px]"
                style={{ backgroundColor: N.surfaceMuted, borderRadius: '8px' }}>
                <code className="flex-shrink-0 truncate max-w-[120px]" style={{ color: N.textMuted }}>{item.key}</code>
                <ArrowRight size={10} style={{ color: N.textMuted }} />
                <span className="flex-1 truncate" style={{ color: N.text }}>{item.translated}</span>
                <button onClick={() => copyText(item.translated)} className="cursor-pointer p-1 flex-shrink-0">
                  <Copy size={10} style={{ color: N.textMuted }} />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* ═══ Recent Translations ═══ */}
      {history.length > 0 && (
        <div className="p-5 sm:p-6" style={{
          backgroundColor: N.surface, border: `1px solid ${N.border}`, borderRadius: '14px',
        }}>
          <h2 className="text-[14px] font-semibold mb-3" style={{ color: N.text }}>Recent Translations</h2>
          <div className="space-y-2">
            {history.map((entry, i) => (
              <div key={i} className="flex items-center gap-3 px-3 py-2.5"
                style={{ backgroundColor: N.surfaceMuted, borderRadius: '8px' }}>
                <span className="text-[12px]">
                  {LANG_OPTIONS.find(l => l.value === entry.lang)?.flag || '🌐'}
                </span>
                <div className="flex-1 min-w-0">
                  <p className="text-[12px] truncate" style={{ color: N.textMuted }}>{entry.source}</p>
                  <p className="text-[13px] truncate font-medium" style={{ color: N.text }}>{entry.translated}</p>
                </div>
                <button onClick={() => copyText(entry.translated)} className="cursor-pointer p-1.5 flex-shrink-0">
                  <Copy size={12} style={{ color: N.textMuted }} />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
