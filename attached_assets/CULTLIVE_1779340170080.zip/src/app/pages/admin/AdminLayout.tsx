import { Outlet, Link, useLocation, useNavigate } from 'react-router';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  LayoutDashboard, Inbox, CheckCircle2, AlertTriangle, XCircle, Eye,
  Users, Settings, LogOut, Menu, X, ChevronLeft, Loader2,
  Calendar, MapPin, Camera, Image, FolderOpen, FileText, Languages,
  PaintBucket, Upload, Store, FileJson,
  Box, Sparkles, Zap,
  Presentation, BarChart3,
} from 'lucide-react';
import { useAdminAuth, fetchSubmissions } from '../../hooks/useAdminApi';
import { contentTypes } from './contentTypes';

// Neutral design tokens — matches the main site's no-mode state
const N = {
  pageBg: '#FAFAF8',
  surface: '#FFFFFF',
  dark: '#1A1A1A',
  darkHover: '#2A2A2A',
  darkBorder: 'rgba(255,255,255,0.08)',
  darkText: 'rgba(255,255,255,0.45)',
  darkTextActive: '#FFFFFF',
  text: '#1A1A1A',
  textMuted: '#9A9A9A',
  border: 'rgba(0,0,0,0.06)',
  accent: '#1A1A1A',
  font: "'Inter', 'Noto Sans HK', system-ui, sans-serif",
};

interface NavItem {
  path: string;
  label: string;
  icon: typeof LayoutDashboard;
  badge?: number;
  group: string;
}

export function AdminLayout() {
  const { user, loading, signOut, accessToken } = useAdminAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  const [counts, setCounts] = useState<Record<string, number>>({});

  useEffect(() => {
    if (!loading && !user) navigate('/admin/login');
  }, [loading, user, navigate]);

  useEffect(() => {
    if (!accessToken) return;
    const fetchCounts = async () => {
      try {
        const data = await fetchSubmissions(accessToken);
        if (data.counts) setCounts(data.counts);
      } catch (err) {
        console.log('Failed to fetch counts:', err);
      }
    };
    fetchCounts();
    const interval = setInterval(fetchCounts, 30000);
    return () => clearInterval(interval);
  }, [accessToken]);

  const iconMap: Record<string, typeof LayoutDashboard> = {
    Calendar, MapPin, Camera, Image, Upload,
  };

  const navItems: NavItem[] = [
    { path: '/admin', label: 'Dashboard', icon: LayoutDashboard, group: 'overview' },
    { path: '/admin/submissions', label: 'All Submissions', icon: Inbox, badge: counts.total, group: 'pipeline' },
    { path: '/admin/submissions/pending', label: 'Pending Review', icon: AlertTriangle, badge: (counts['ai-flagged'] || 0) + (counts['ai-approved'] || 0), group: 'pipeline' },
    { path: '/admin/submissions/approved', label: 'Approved', icon: CheckCircle2, badge: counts.approved, group: 'pipeline' },
    { path: '/admin/submissions/published', label: 'Published', icon: Eye, badge: counts.published, group: 'pipeline' },
    { path: '/admin/submissions/rejected', label: 'Rejected', icon: XCircle, badge: counts.rejected, group: 'pipeline' },
    // Content types from registry
    ...contentTypes.map(ct => ({
      path: `/admin/content/${ct.key}`,
      label: ct.labelPlural,
      icon: iconMap[ct.icon] || Calendar,
      group: 'content',
    })),
    { path: '/admin/contributors', label: 'Contributors', icon: Users, group: 'community' },
    { path: '/admin/media', label: 'Media Library', icon: FolderOpen, group: 'tools' },
    { path: '/admin/import', label: 'Bulk Venues', icon: Upload, group: 'tools' },
    { path: '/admin/events-import', label: 'RA Events', icon: FileJson, group: 'tools' },
    { path: '/admin/apify-import', label: 'Apify Import', icon: Box, group: 'tools' },
    { path: '/admin/events', label: 'Event Manager', icon: Calendar, group: 'tools' },
    { path: '/admin/venues', label: 'Venue Manager', icon: Store, group: 'tools' },
    { path: '/admin/weekly-picks', label: 'Weekly Picks', icon: Sparkles, group: 'tools' },
    { path: '/admin/template', label: 'Template Editor', icon: PaintBucket, group: 'tools' },
    { path: '/admin/copy', label: 'Copy Editor', icon: FileText, group: 'tools' },
    { path: '/admin/translation', label: 'Translation Hub', icon: Languages, group: 'tools' },
    { path: '/admin/webhooks', label: 'Webhooks', icon: Zap, group: 'tools' },
    { path: '/admin/brand-guide', label: 'Brand Guide', icon: Eye, group: 'tools' },
    { path: '/admin/pitch-deck', label: 'Pitch Deck', icon: Presentation, group: 'tools' },
    { path: '/admin/analytics', label: 'Analytics & Reports', icon: BarChart3, group: 'tools' },
    { path: '/admin/settings', label: 'Settings', icon: Settings, group: 'configure' },
  ];

  const groups = [
    { key: 'overview', label: '' },
    { key: 'pipeline', label: 'Pipeline' },
    { key: 'content', label: 'Site Content' },
    { key: 'community', label: 'Community' },
    { key: 'tools', label: 'Tools' },
    { key: 'configure', label: 'Configure' },
  ];

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: N.pageBg }}>
        <Loader2 size={20} className="animate-spin" style={{ color: N.textMuted }} />
      </div>
    );
  }

  if (!user) return null;

  const isActive = (path: string) => {
    if (path === '/admin') return location.pathname === '/admin';
    if (path === '/admin/submissions') return location.pathname === '/admin/submissions';
    return location.pathname === path || location.pathname.startsWith(path + '/');
  };

  return (
    <div className="h-screen overflow-hidden flex" style={{ backgroundColor: N.pageBg, fontFamily: N.font }}>
      {/* ═══ Desktop Sidebar ═══ */}
      <aside
        className={`fixed top-0 left-0 h-full z-50 transition-all duration-300 hidden md:flex flex-col ${collapsed ? 'w-[68px]' : 'w-[220px]'}`}
        style={{ backgroundColor: N.dark }}
      >
        {/* Logo */}
        <div className="flex items-center justify-between px-4 h-14"
          style={{ borderBottom: `1px solid ${N.darkBorder}` }}>
          {!collapsed ? (
            <div className="flex items-center gap-1.5">
              <span className="text-[13px] font-bold tracking-tight" style={{ color: '#fff' }}>CULTIVE</span>
              <span className="text-[10px]" style={{ color: N.darkText }}>CMS</span>
            </div>
          ) : (
            <span className="text-[14px] font-bold mx-auto" style={{ color: '#fff' }}>C</span>
          )}
          <button onClick={() => setCollapsed(!collapsed)}
            className="p-1 cursor-pointer transition-opacity hover:opacity-100"
            style={{ color: N.darkText }}>
            <ChevronLeft size={14} className={`transition-transform ${collapsed ? 'rotate-180' : ''}`} />
          </button>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto py-3 px-2">
          {groups.map(group => {
            const items = navItems.filter(n => n.group === group.key);
            if (items.length === 0) return null;
            return (
              <div key={group.key} className="mb-1">
                {group.label && !collapsed && (
                  <p className="px-3 pt-3 pb-1.5 text-[11px] font-medium uppercase tracking-wide"
                    style={{ color: N.darkText }}>
                    {group.label}
                  </p>
                )}
                {group.label && collapsed && (
                  <div className="h-px mx-2 my-2" style={{ backgroundColor: N.darkBorder }} />
                )}
                {items.map(item => {
                  const active = isActive(item.path);
                  return (
                    <Link
                      key={item.path}
                      to={item.path}
                      className="flex items-center gap-2.5 px-3 py-[7px] mb-px text-[13px] transition-colors"
                      style={{
                        borderRadius: '8px',
                        backgroundColor: active ? 'rgba(255,255,255,0.1)' : 'transparent',
                        color: active ? N.darkTextActive : N.darkText,
                        fontWeight: active ? 500 : 400,
                      }}
                      title={collapsed ? item.label : undefined}
                    >
                      <item.icon size={16} />
                      {!collapsed && (
                        <>
                          <span className="flex-1">{item.label}</span>
                          {item.badge !== undefined && item.badge > 0 && (
                            <span className="text-[11px] px-1.5 py-0.5 font-medium" style={{
                              backgroundColor: active ? 'rgba(255,255,255,0.12)' : 'rgba(255,255,255,0.06)',
                              color: active ? '#fff' : 'rgba(255,255,255,0.5)',
                              borderRadius: '5px',
                            }}>
                              {item.badge}
                            </span>
                          )}
                        </>
                      )}
                    </Link>
                  );
                })}
              </div>
            );
          })}
        </nav>

        {/* User */}
        <div className="px-2 py-3" style={{ borderTop: `1px solid ${N.darkBorder}` }}>
          {!collapsed && (
            <p className="px-3 mb-1.5 text-[11px] truncate" style={{ color: N.darkText }}>
              {user.email}
            </p>
          )}
          <button
            onClick={signOut}
            className="flex items-center gap-2 w-full px-3 py-[7px] text-[13px] cursor-pointer transition-colors hover:opacity-100"
            style={{ borderRadius: '8px', color: N.darkText }}
          >
            <LogOut size={15} />
            {!collapsed && 'Sign Out'}
          </button>
        </div>
      </aside>

      {/* ═══ Mobile Header ═══ */}
      <div className="fixed top-0 left-0 right-0 z-40 md:hidden flex items-center justify-between h-13 px-4"
        style={{ backgroundColor: N.dark }}>
        <div className="flex items-center gap-1.5">
          <span className="text-[13px] font-bold tracking-tight" style={{ color: '#fff' }}>CULTIVE</span>
          <span className="text-[10px]" style={{ color: N.darkText }}>CMS</span>
        </div>
        <button onClick={() => setSidebarOpen(!sidebarOpen)} className="p-2 cursor-pointer" style={{ color: N.darkText }}>
          {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      {/* ═══ Mobile Sidebar Overlay ═══ */}
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div
            initial={{ opacity: 0, x: -260 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -260 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className="fixed inset-0 z-50 md:hidden"
          >
            <div className="absolute inset-0 bg-black/25" onClick={() => setSidebarOpen(false)} />
            <div className="relative w-[240px] h-full flex flex-col" style={{ backgroundColor: N.dark }}>
              <div className="flex items-center gap-1.5 px-5 h-13"
                style={{ borderBottom: `1px solid ${N.darkBorder}` }}>
                <span className="text-[13px] font-bold tracking-tight leading-[52px]" style={{ color: '#fff' }}>CULTIVE</span>
                <span className="text-[10px]" style={{ color: N.darkText }}>CMS</span>
              </div>
              <nav className="flex-1 overflow-y-auto py-3 px-2">
                {groups.map(group => {
                  const items = navItems.filter(n => n.group === group.key);
                  if (items.length === 0) return null;
                  return (
                    <div key={group.key} className="mb-1">
                      {group.label && (
                        <p className="px-3 pt-3 pb-1.5 text-[11px] font-medium uppercase tracking-wide"
                          style={{ color: N.darkText }}>{group.label}</p>
                      )}
                      {items.map(item => {
                        const active = isActive(item.path);
                        return (
                          <Link key={item.path} to={item.path} onClick={() => setSidebarOpen(false)}
                            className="flex items-center gap-2.5 px-3 py-2 mb-px text-[13px]"
                            style={{
                              borderRadius: '8px',
                              backgroundColor: active ? 'rgba(255,255,255,0.1)' : 'transparent',
                              color: active ? '#fff' : N.darkText,
                              fontWeight: active ? 500 : 400,
                            }}>
                            <item.icon size={16} />
                            <span className="flex-1">{item.label}</span>
                            {item.badge !== undefined && item.badge > 0 && (
                              <span className="text-[11px] px-1.5 py-0.5" style={{
                                backgroundColor: 'rgba(255,255,255,0.08)', color: 'rgba(255,255,255,0.5)', borderRadius: '5px',
                              }}>{item.badge}</span>
                            )}
                          </Link>
                        );
                      })}
                    </div>
                  );
                })}
              </nav>
              <div style={{ borderTop: `1px solid ${N.darkBorder}` }}>
                <p className="px-5 pt-3 text-[11px] truncate" style={{ color: N.darkText }}>{user.email}</p>
                <button onClick={signOut} className="flex items-center gap-2 w-full px-5 py-3 text-[13px] cursor-pointer"
                  style={{ color: N.darkText }}>
                  <LogOut size={15} /> Sign Out
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ═══ Main Content ═══ */}
      <main className={`flex-1 min-w-0 transition-all duration-300 ${collapsed ? 'md:ml-[68px]' : 'md:ml-[220px]'} mt-13 md:mt-0 h-full overflow-y-auto`}>
        <Outlet context={{ accessToken, user, counts }} />
      </main>
    </div>
  );
}

export function useAdminContext() {
  return {};
}