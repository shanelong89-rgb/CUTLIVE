/**
 * WebhookManager — /admin/webhooks
 *
 * Register, test, monitor, and manage webhook endpoints.
 * Webhooks fire on CMS state changes for Paperclip-style
 * zero-human AI agent orchestration.
 */
import { useState, useCallback, useEffect, useRef } from 'react';
import { useOutletContext } from 'react-router';
import { motion, AnimatePresence } from 'motion/react';
import {
  Plus, Trash2, X, Check, Loader2, AlertCircle, Zap,
  Send, Globe, ToggleLeft, ToggleRight, Clock, AlertTriangle,
  Copy, Eye, EyeOff, RefreshCw, ChevronDown, ChevronUp, RotateCw,
  Activity, Download,
} from 'lucide-react';
import {
  getWebhooks,
  registerWebhook,
  deleteWebhook,
  toggleWebhook,
  fireWebhook,
  syncFromKV,
  setWebhookAuthToken,
  getRetryQueueSize,
  clearRetryQueue,
  getDeliveryLog,
  syncDeliveryLogFromKV,
  clearDeliveryLog,
  exportDeliveryLog,
  WEBHOOK_EVENTS,
  WEBHOOK_EVENT_INFO,
  type WebhookRegistration,
  type WebhookEvent,
  type DeliveryLogEntry,
} from '../../config/webhooks';

// ─── Design Tokens (matches editorial rebrand) ──────────────────────────

const T = {
  bg: '#FAFAF8',
  surface: '#FFFFFF',
  border: '#E8E6E1',
  text: '#1A1A1A',
  textMuted: '#8C8C8C',
  accent: '#B2483A',
  accentLight: '#B2483A12',
  success: '#16A34A',
  successLight: '#F0FDF4',
  warning: '#D97706',
  warningLight: '#FFFBEB',
  danger: '#DC2626',
  dangerLight: '#FEF2F2',
  font: "'Inter', system-ui, sans-serif",
};

export function WebhookManager() {
  const { accessToken } = useOutletContext<{ accessToken: string }>();
  const [hooks, setHooks] = useState<WebhookRegistration[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [testingId, setTestingId] = useState<string | null>(null);
  const [testResult, setTestResult] = useState<{ id: string; ok: boolean; msg: string } | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [logs, setLogs] = useState<DeliveryLogEntry[]>([]);
  const [showLogs, setShowLogs] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [retryCount, setRetryCount] = useState(0);
  const [logFilter, setLogFilter] = useState<string>('all');

  // ─── Form state ──
  const [formUrl, setFormUrl] = useState('');
  const [formLabel, setFormLabel] = useState('');
  const [formEvents, setFormEvents] = useState<Set<WebhookEvent>>(new Set());
  const [formError, setFormError] = useState('');

  const reload = useCallback(() => {
    setHooks(getWebhooks());
    setLogs(getDeliveryLog());
    setRetryCount(getRetryQueueSize());
  }, []);

  // Sync from KV on mount
  useEffect(() => {
    if (accessToken) {
      setWebhookAuthToken(accessToken);
      setSyncing(true);
      Promise.all([
        syncFromKV(),
        syncDeliveryLogFromKV(),
      ]).then(([syncedHooks, syncedLogs]) => {
        setHooks(syncedHooks);
        setLogs(syncedLogs);
        setSyncing(false);
      }).catch(() => {
        setHooks(getWebhooks());
        setLogs(getDeliveryLog());
        setSyncing(false);
      });
    } else {
      reload();
    }
  }, [accessToken, reload]);

  // Poll retry queue size
  useEffect(() => {
    const interval = setInterval(() => setRetryCount(getRetryQueueSize()), 5000);
    return () => clearInterval(interval);
  }, []);

  // ─── Register ──
  const handleRegister = useCallback(() => {
    setFormError('');
    if (!formUrl.trim()) { setFormError('URL is required'); return; }
    try { new URL(formUrl); } catch { setFormError('Invalid URL format'); return; }
    if (formEvents.size === 0) { setFormError('Select at least one event'); return; }

    registerWebhook(formUrl.trim(), Array.from(formEvents), formLabel.trim() || undefined);
    setFormUrl('');
    setFormLabel('');
    setFormEvents(new Set());
    setShowForm(false);
    reload();
  }, [formUrl, formLabel, formEvents, reload]);

  // ─── Toggle ──
  const handleToggle = useCallback((id: string, active: boolean) => {
    toggleWebhook(id, active);
    reload();
  }, [reload]);

  // ─── Delete ──
  const handleDelete = useCallback((id: string) => {
    deleteWebhook(id);
    setDeleteConfirm(null);
    reload();
  }, [reload]);

  // ─── Test Fire ──
  const handleTest = useCallback(async (hook: WebhookRegistration) => {
    setTestingId(hook.id);
    setTestResult(null);
    try {
      const result = await fireWebhook(hook.events[0] || 'submission.created', {
        _test: true,
        message: `Test delivery from CULTIVE WebhookManager at ${new Date().toISOString()}`,
        webhookId: hook.id,
      });

      if (result.failed === 0) {
        setTestResult({ id: hook.id, ok: true, msg: `Delivered (${result.sent} sent)` });
      } else {
        setTestResult({ id: hook.id, ok: false, msg: `${result.failed} failed, ${result.queued} queued` });
      }
    } catch (err: any) {
      setTestResult({ id: hook.id, ok: false, msg: err.message || 'Failed' });
    }
    setTestingId(null);
    reload();
    setTimeout(() => setTestResult(null), 4000);
  }, [reload]);

  // ─── Toggle event in form ──
  const toggleFormEvent = (ev: WebhookEvent) => {
    setFormEvents(prev => {
      const next = new Set(prev);
      if (next.has(ev)) next.delete(ev); else next.add(ev);
      return next;
    });
  };

  const selectAllEvents = () => setFormEvents(new Set(WEBHOOK_EVENTS));
  const clearAllEvents = () => setFormEvents(new Set());

  const activeCount = hooks.filter(h => h.active).length;
  const totalFails = hooks.reduce((acc, h) => acc + h.failCount, 0);

  return (
    <div className="max-w-4xl mx-auto" style={{ fontFamily: T.font }}>
      {/* Header */}
      <div className="flex items-start justify-between mb-6">
        <div>
          <h1 className="text-xl mb-1" style={{ color: T.text, fontWeight: 700 }}>
            Webhooks
          </h1>
          <p className="text-sm" style={{ color: T.textMuted }}>
            Event-driven callbacks for CMS state changes. Register endpoints for AI agent orchestration.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowLogs(!showLogs)}
            className="flex items-center gap-1.5 px-3 py-2 text-xs rounded-lg cursor-pointer transition-opacity hover:opacity-80"
            style={{ color: T.textMuted, border: `1px solid ${T.border}`, backgroundColor: T.surface }}
          >
            <Clock size={12} /> Logs {logs.length > 0 && `(${logs.length})`}
          </button>
          <button
            onClick={() => { setShowForm(!showForm); setFormError(''); }}
            className="flex items-center gap-1.5 px-4 py-2 text-sm rounded-lg cursor-pointer transition-all hover:opacity-90"
            style={{ backgroundColor: T.accent, color: '#fff', fontWeight: 600, border: 'none' }}
          >
            <Plus size={14} /> Register
          </button>
        </div>
      </div>

      {/* Stats bar */}
      <div
        className="flex items-center gap-6 px-4 py-3 rounded-xl mb-6"
        style={{ backgroundColor: T.surface, border: `1px solid ${T.border}` }}
      >
        <div className="flex items-center gap-2">
          <Zap size={14} style={{ color: T.accent }} />
          <span className="text-xs" style={{ color: T.textMuted }}>
            <strong style={{ color: T.text }}>{hooks.length}</strong> registered
          </span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full" style={{ backgroundColor: T.success }} />
          <span className="text-xs" style={{ color: T.textMuted }}>
            <strong style={{ color: T.text }}>{activeCount}</strong> active
          </span>
        </div>
        {totalFails > 0 && (
          <div className="flex items-center gap-2">
            <AlertTriangle size={12} style={{ color: T.warning }} />
            <span className="text-xs" style={{ color: T.warning }}>
              {totalFails} failure{totalFails !== 1 ? 's' : ''}
            </span>
          </div>
        )}
        {retryCount > 0 && (
          <div className="flex items-center gap-2">
            <RotateCw size={12} className="animate-spin" style={{ color: T.accent, animationDuration: '3s' }} />
            <span className="text-xs" style={{ color: T.accent }}>
              {retryCount} retrying
            </span>
            <button
              onClick={() => { clearRetryQueue(); setRetryCount(0); }}
              className="text-[10px] underline cursor-pointer"
              style={{ color: T.textMuted, border: 'none', backgroundColor: 'transparent' }}
            >
              clear
            </button>
          </div>
        )}
        <div className="flex-1" />
        {syncing && (
          <span className="flex items-center gap-1 text-[10px]" style={{ color: T.textMuted }}>
            <Loader2 size={10} className="animate-spin" /> syncing KV...
          </span>
        )}
        <span className="text-[10px]" style={{ color: T.textMuted }}>
          {WEBHOOK_EVENTS.length} event types supported
        </span>
      </div>

      {/* Registration Form */}
      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden mb-6"
          >
            <div
              className="p-5 rounded-xl"
              style={{ backgroundColor: T.surface, border: `1px solid ${T.border}` }}
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm" style={{ color: T.text, fontWeight: 600 }}>
                  Register New Webhook
                </h3>
                <button
                  onClick={() => setShowForm(false)}
                  className="p-1 cursor-pointer rounded-md hover:bg-gray-100"
                  style={{ border: 'none', backgroundColor: 'transparent', color: T.textMuted }}
                >
                  <X size={14} />
                </button>
              </div>

              {/* URL */}
              <div className="mb-3">
                <label className="text-[10px] uppercase tracking-wider block mb-1" style={{ color: T.textMuted, fontWeight: 600 }}>
                  Endpoint URL *
                </label>
                <div className="relative">
                  <Globe size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: T.textMuted }} />
                  <input
                    value={formUrl}
                    onChange={e => setFormUrl(e.target.value)}
                    placeholder="https://your-agent.example.com/webhook"
                    className="w-full pl-9 pr-3 py-2.5 text-xs rounded-lg outline-none"
                    style={{ border: `1px solid ${T.border}`, backgroundColor: T.bg, color: T.text, fontFamily: 'ui-monospace, monospace' }}
                  />
                </div>
              </div>

              {/* Label */}
              <div className="mb-4">
                <label className="text-[10px] uppercase tracking-wider block mb-1" style={{ color: T.textMuted, fontWeight: 600 }}>
                  Label (optional)
                </label>
                <input
                  value={formLabel}
                  onChange={e => setFormLabel(e.target.value)}
                  placeholder="e.g. Paperclip orchestrator, Slack notifier"
                  className="w-full px-3 py-2.5 text-xs rounded-lg outline-none"
                  style={{ border: `1px solid ${T.border}`, backgroundColor: T.bg, color: T.text, fontFamily: T.font }}
                />
              </div>

              {/* Events */}
              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <label className="text-[10px] uppercase tracking-wider" style={{ color: T.textMuted, fontWeight: 600 }}>
                    Subscribe to Events *
                  </label>
                  <div className="flex gap-2">
                    <button onClick={selectAllEvents} className="text-[10px] cursor-pointer underline" style={{ color: T.accent, border: 'none', backgroundColor: 'transparent' }}>
                      Select All
                    </button>
                    <button onClick={clearAllEvents} className="text-[10px] cursor-pointer underline" style={{ color: T.textMuted, border: 'none', backgroundColor: 'transparent' }}>
                      Clear
                    </button>
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                  {WEBHOOK_EVENTS.map(ev => {
                    const info = WEBHOOK_EVENT_INFO[ev];
                    const selected = formEvents.has(ev);
                    return (
                      <button
                        key={ev}
                        onClick={() => toggleFormEvent(ev)}
                        className="flex items-start gap-2 p-2.5 rounded-lg text-left cursor-pointer transition-all"
                        style={{
                          backgroundColor: selected ? T.accentLight : 'transparent',
                          border: `1px solid ${selected ? T.accent + '40' : T.border}`,
                        }}
                      >
                        <div
                          className="w-3.5 h-3.5 rounded flex-shrink-0 mt-0.5 flex items-center justify-center"
                          style={{
                            border: `1.5px solid ${selected ? T.accent : T.border}`,
                            backgroundColor: selected ? T.accent : 'transparent',
                          }}
                        >
                          {selected && <Check size={8} color="#fff" />}
                        </div>
                        <div className="min-w-0">
                          <span className="text-[11px] block" style={{ color: T.text, fontWeight: selected ? 600 : 400 }}>
                            {info.label}
                          </span>
                          <span className="text-[10px] block mt-0.5 leading-tight" style={{ color: T.textMuted }}>
                            {ev}
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Error */}
              {formError && (
                <div className="flex items-center gap-2 mb-3 px-3 py-2 rounded-lg text-xs" style={{ backgroundColor: T.dangerLight, color: T.danger }}>
                  <AlertCircle size={12} /> {formError}
                </div>
              )}

              {/* Submit */}
              <div className="flex justify-end gap-2">
                <button
                  onClick={() => setShowForm(false)}
                  className="px-4 py-2 text-xs rounded-lg cursor-pointer"
                  style={{ color: T.textMuted, border: `1px solid ${T.border}`, backgroundColor: 'transparent' }}
                >
                  Cancel
                </button>
                <button
                  onClick={handleRegister}
                  className="flex items-center gap-1.5 px-5 py-2 text-xs rounded-lg cursor-pointer transition-all hover:opacity-90"
                  style={{ backgroundColor: T.accent, color: '#fff', fontWeight: 600, border: 'none' }}
                >
                  <Zap size={12} /> Register Webhook
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Delivery Logs Panel */}
      <AnimatePresence>
        {showLogs && logs.length > 0 && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden mb-6"
          >
            <div
              className="p-4 rounded-xl"
              style={{ backgroundColor: T.surface, border: `1px solid ${T.border}` }}
            >
              {/* Header with filter + actions */}
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-xs" style={{ color: T.text, fontWeight: 600 }}>
                  Delivery Log
                </h3>
                <div className="flex items-center gap-2">
                  <span className="text-[10px]" style={{ color: T.textMuted }}>
                    {logs.length} total
                  </span>
                  <button
                    onClick={() => exportDeliveryLog('json')}
                    className="flex items-center gap-1 text-[10px] cursor-pointer hover:opacity-80"
                    style={{ color: T.accent, border: 'none', backgroundColor: 'transparent' }}
                    title="Export as JSON"
                  >
                    <Download size={9} /> JSON
                  </button>
                  <button
                    onClick={() => exportDeliveryLog('csv')}
                    className="flex items-center gap-1 text-[10px] cursor-pointer hover:opacity-80"
                    style={{ color: T.accent, border: 'none', backgroundColor: 'transparent' }}
                    title="Export as CSV"
                  >
                    <Download size={9} /> CSV
                  </button>
                  <button
                    onClick={async () => { await clearDeliveryLog(); setLogs([]); }}
                    className="text-[10px] underline cursor-pointer"
                    style={{ color: T.danger, border: 'none', backgroundColor: 'transparent' }}
                  >
                    Clear
                  </button>
                </div>
              </div>

              {/* Event filter tabs */}
              <div className="flex flex-wrap gap-1 mb-3">
                {(['all', 'success', 'failed', 'submission.*', 'content.*', 'weekly_picks.*', 'bulk_import.*'] as const).map(filter => {
                  const isActive = logFilter === filter;
                  const count = filter === 'all' ? logs.length
                    : filter === 'success' ? logs.filter(l => l.status === 'success').length
                    : filter === 'failed' ? logs.filter(l => l.status === 'failed').length
                    : logs.filter(l => l.event.startsWith(filter.replace('.*', ''))).length;
                  if (count === 0 && filter !== 'all') return null;
                  return (
                    <button
                      key={filter}
                      onClick={() => setLogFilter(filter)}
                      className="px-2 py-1 text-[10px] rounded-md cursor-pointer transition-all"
                      style={{
                        backgroundColor: isActive ? T.accentLight : 'transparent',
                        color: isActive ? T.accent : T.textMuted,
                        border: `1px solid ${isActive ? T.accent + '30' : T.border}`,
                        fontFamily: filter.includes('*') ? 'ui-monospace, monospace' : T.font,
                        fontWeight: isActive ? 600 : 400,
                      }}
                    >
                      {filter === 'all' ? 'All' : filter === 'success' ? 'Success' : filter === 'failed' ? 'Failed' : filter}
                      {' '}({count})
                    </button>
                  );
                })}
              </div>

              {/* Log entries */}
              <div className="space-y-1 max-h-64 overflow-y-auto">
                {logs
                  .filter(log => {
                    if (logFilter === 'all') return true;
                    if (logFilter === 'success') return log.status === 'success';
                    if (logFilter === 'failed') return log.status === 'failed';
                    return log.event.startsWith(logFilter.replace('.*', ''));
                  })
                  .map(log => (
                  <div
                    key={log.id}
                    className="flex items-center gap-3 px-3 py-2 rounded-md text-[11px]"
                    style={{ backgroundColor: log.status === 'success' ? T.successLight : T.dangerLight }}
                  >
                    <div
                      className="w-1.5 h-1.5 rounded-full flex-shrink-0"
                      style={{ backgroundColor: log.status === 'success' ? T.success : T.danger }}
                    />
                    <span style={{ color: T.text, fontFamily: 'ui-monospace, monospace' }}>{log.event}</span>
                    <span className="truncate max-w-[120px]" style={{ color: T.textMuted }}>
                      → {log.webhookLabel || hooks.find(h => h.id === log.webhookId)?.label || log.webhookId.slice(0, 12)}
                    </span>
                    {log.attempt > 1 && (
                      <span className="text-[9px] px-1 py-0.5 rounded" style={{ backgroundColor: T.warningLight, color: T.warning }}>
                        retry #{log.attempt}
                      </span>
                    )}
                    <span className="flex-1" />
                    {log.error && (
                      <span className="text-[9px] truncate max-w-[100px]" style={{ color: T.danger }} title={log.error}>
                        {log.error}
                      </span>
                    )}
                    {log.responseTime > 0 && (
                      <span style={{ color: T.textMuted }}>{log.responseTime}ms</span>
                    )}
                    <span style={{ color: T.textMuted }}>
                      {new Date(log.timestamp).toLocaleTimeString('en-HK', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Webhook List */}
      {hooks.length === 0 ? (
        <div
          className="flex flex-col items-center justify-center py-16 rounded-xl text-center"
          style={{ border: `2px dashed ${T.border}`, backgroundColor: `${T.surface}80` }}
        >
          <Zap size={28} className="mb-3" style={{ color: T.textMuted }} />
          <p className="text-sm mb-1" style={{ color: T.text, fontWeight: 500 }}>
            No webhooks registered
          </p>
          <p className="text-xs mb-4" style={{ color: T.textMuted }}>
            Register an endpoint to receive real-time CMS event notifications.
          </p>
          <button
            onClick={() => setShowForm(true)}
            className="flex items-center gap-1.5 px-4 py-2 text-xs rounded-lg cursor-pointer transition-all hover:opacity-90"
            style={{ backgroundColor: T.accent, color: '#fff', fontWeight: 600, border: 'none' }}
          >
            <Plus size={12} /> Register First Webhook
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          <AnimatePresence mode="popLayout">
            {hooks.map(hook => {
              const isExpanded = expandedId === hook.id;
              const isTesting = testingId === hook.id;
              const result = testResult?.id === hook.id ? testResult : null;
              const isDeleting = deleteConfirm === hook.id;

              return (
                <motion.div
                  key={hook.id}
                  layout
                  initial={{ opacity: 0, y: -8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="rounded-xl overflow-hidden"
                  style={{
                    backgroundColor: T.surface,
                    border: `1px solid ${hook.active ? T.border : T.danger + '30'}`,
                    opacity: hook.active ? 1 : 0.7,
                  }}
                >
                  {/* Card Header */}
                  <div className="flex items-center gap-3 p-4">
                    {/* Status dot */}
                    <div
                      className="w-2.5 h-2.5 rounded-full flex-shrink-0"
                      style={{
                        backgroundColor: !hook.active ? T.textMuted : hook.failCount > 0 ? T.warning : T.success,
                      }}
                    />

                    {/* Info */}
                    <div
                      className="flex-1 min-w-0 cursor-pointer"
                      onClick={() => setExpandedId(isExpanded ? null : hook.id)}
                    >
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm truncate" style={{ color: T.text, fontWeight: 600 }}>
                          {hook.label || 'Untitled Webhook'}
                        </h4>
                        {!hook.active && (
                          <span className="text-[9px] px-1.5 py-0.5 rounded" style={{ backgroundColor: T.dangerLight, color: T.danger }}>
                            DISABLED
                          </span>
                        )}
                        {hook.failCount > 0 && hook.active && (
                          <span className="text-[9px] px-1.5 py-0.5 rounded" style={{ backgroundColor: T.warningLight, color: T.warning }}>
                            {hook.failCount} fail{hook.failCount !== 1 ? 's' : ''}
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span
                          className="text-[11px] truncate max-w-xs"
                          style={{ color: T.textMuted, fontFamily: 'ui-monospace, monospace' }}
                        >
                          {hook.url}
                        </span>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-1.5">
                      {/* Test */}
                      <button
                        onClick={() => handleTest(hook)}
                        disabled={isTesting || !hook.active}
                        className="flex items-center gap-1 px-2.5 py-1.5 text-[10px] rounded-md cursor-pointer transition-all hover:opacity-80 disabled:opacity-40"
                        style={{
                          color: result ? (result.ok ? T.success : T.danger) : T.accent,
                          border: `1px solid ${result ? (result.ok ? T.success + '40' : T.danger + '40') : T.border}`,
                          backgroundColor: result ? (result.ok ? T.successLight : T.dangerLight) : 'transparent',
                        }}
                      >
                        {isTesting ? <Loader2 size={10} className="animate-spin" /> : <Send size={10} />}
                        {result ? result.msg : 'Test'}
                      </button>

                      {/* Toggle */}
                      <button
                        onClick={() => handleToggle(hook.id, !hook.active)}
                        className="p-1.5 cursor-pointer rounded-md hover:bg-gray-50"
                        style={{ border: 'none', backgroundColor: 'transparent', color: hook.active ? T.success : T.textMuted }}
                      >
                        {hook.active ? <ToggleRight size={18} /> : <ToggleLeft size={18} />}
                      </button>

                      {/* Expand */}
                      <button
                        onClick={() => setExpandedId(isExpanded ? null : hook.id)}
                        className="p-1.5 cursor-pointer rounded-md hover:bg-gray-50"
                        style={{ border: 'none', backgroundColor: 'transparent', color: T.textMuted }}
                      >
                        {isExpanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                      </button>
                    </div>
                  </div>

                  {/* Expanded Detail */}
                  <AnimatePresence>
                    {isExpanded && (
                      <motion.div
                        initial={{ height: 0 }}
                        animate={{ height: 'auto' }}
                        exit={{ height: 0 }}
                        className="overflow-hidden"
                      >
                        <div className="px-4 pb-4 pt-0 border-t" style={{ borderColor: T.border }}>
                          <div className="pt-4 space-y-4">
                            {/* Subscribed events */}
                            <div>
                              <label className="text-[10px] uppercase tracking-wider block mb-2" style={{ color: T.textMuted, fontWeight: 600 }}>
                                Subscribed Events ({hook.events.length})
                              </label>
                              <div className="flex flex-wrap gap-1.5">
                                {hook.events.map(ev => (
                                  <span
                                    key={ev}
                                    className="text-[10px] px-2 py-1 rounded-md"
                                    style={{
                                      backgroundColor: T.accentLight,
                                      color: T.accent,
                                      fontFamily: 'ui-monospace, monospace',
                                    }}
                                  >
                                    {ev}
                                  </span>
                                ))}
                              </div>
                            </div>

                            {/* Secret */}
                            <SecretField secret={hook.secret} />

                            {/* Metadata */}
                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <label className="text-[10px] uppercase tracking-wider block mb-1" style={{ color: T.textMuted, fontWeight: 600 }}>
                                  Created
                                </label>
                                <span className="text-xs" style={{ color: T.text }}>
                                  {new Date(hook.createdAt).toLocaleDateString('en-HK', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' })}
                                </span>
                              </div>
                              <div>
                                <label className="text-[10px] uppercase tracking-wider block mb-1" style={{ color: T.textMuted, fontWeight: 600 }}>
                                  Last Triggered
                                </label>
                                <span className="text-xs" style={{ color: T.text }}>
                                  {hook.lastTriggered
                                    ? new Date(hook.lastTriggered).toLocaleDateString('en-HK', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })
                                    : '—'}
                                </span>
                              </div>
                            </div>

                            {/* ID */}
                            <div>
                              <label className="text-[10px] uppercase tracking-wider block mb-1" style={{ color: T.textMuted, fontWeight: 600 }}>
                                Webhook ID
                              </label>
                              <span
                                className="text-[11px]"
                                style={{ color: T.textMuted, fontFamily: 'ui-monospace, monospace' }}
                              >
                                {hook.id}
                              </span>
                            </div>

                            {/* Per-webhook Delivery History */}
                            <WebhookDeliveryHistory hookId={hook.id} hookLabel={hook.label} allLogs={logs} />

                            {/* Delete */}
                            <div className="flex justify-end pt-2 border-t" style={{ borderColor: T.border }}>
                              {isDeleting ? (
                                <div className="flex items-center gap-2">
                                  <span className="text-xs" style={{ color: T.danger }}>
                                    Delete permanently?
                                  </span>
                                  <button
                                    onClick={() => handleDelete(hook.id)}
                                    className="px-3 py-1.5 text-[10px] rounded-md cursor-pointer"
                                    style={{ backgroundColor: T.danger, color: '#fff', border: 'none', fontWeight: 600 }}
                                  >
                                    Confirm
                                  </button>
                                  <button
                                    onClick={() => setDeleteConfirm(null)}
                                    className="px-3 py-1.5 text-[10px] rounded-md cursor-pointer"
                                    style={{ color: T.textMuted, border: `1px solid ${T.border}`, backgroundColor: 'transparent' }}
                                  >
                                    Cancel
                                  </button>
                                </div>
                              ) : (
                                <button
                                  onClick={() => setDeleteConfirm(hook.id)}
                                  className="flex items-center gap-1 px-3 py-1.5 text-[10px] rounded-md cursor-pointer transition-colors hover:bg-red-50"
                                  style={{ color: T.danger, border: 'none', backgroundColor: 'transparent' }}
                                >
                                  <Trash2 size={10} /> Delete
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      )}

      {/* Event Reference */}
      <div className="mt-8">
        <h3 className="text-xs mb-3" style={{ color: T.text, fontWeight: 600 }}>
          Event Reference
        </h3>
        <div
          className="rounded-xl overflow-hidden"
          style={{ border: `1px solid ${T.border}` }}
        >
          {WEBHOOK_EVENTS.map((ev, i) => {
            const info = WEBHOOK_EVENT_INFO[ev];
            return (
              <div
                key={ev}
                className="flex items-start gap-3 px-4 py-3"
                style={{
                  backgroundColor: i % 2 === 0 ? T.surface : T.bg,
                  borderTop: i > 0 ? `1px solid ${T.border}` : 'none',
                }}
              >
                <span
                  className="text-[11px] flex-shrink-0 mt-0.5 px-2 py-0.5 rounded"
                  style={{ backgroundColor: T.accentLight, color: T.accent, fontFamily: 'ui-monospace, monospace' }}
                >
                  {ev}
                </span>
                <span className="text-xs" style={{ color: T.textMuted }}>
                  {info.description}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ─── Secret Field with toggle visibility + copy ──────────────────────────

function SecretField({ secret }: { secret: string }) {
  const [visible, setVisible] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(secret).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <div>
      <label className="text-[10px] uppercase tracking-wider block mb-1" style={{ color: T.textMuted, fontWeight: 600 }}>
        Signing Secret (HMAC-SHA256)
      </label>
      <div className="flex items-center gap-2">
        <span
          className="text-[11px] flex-1"
          style={{ color: T.text, fontFamily: 'ui-monospace, monospace' }}
        >
          {visible ? secret : '•'.repeat(Math.min(secret.length, 32))}
        </span>
        <button
          onClick={() => setVisible(!visible)}
          className="p-1 cursor-pointer rounded hover:bg-gray-50"
          style={{ border: 'none', backgroundColor: 'transparent', color: T.textMuted }}
        >
          {visible ? <EyeOff size={12} /> : <Eye size={12} />}
        </button>
        <button
          onClick={handleCopy}
          className="p-1 cursor-pointer rounded hover:bg-gray-50"
          style={{ border: 'none', backgroundColor: 'transparent', color: copied ? T.success : T.textMuted }}
        >
          {copied ? <Check size={12} /> : <Copy size={12} />}
        </button>
      </div>
    </div>
  );
}

// ─── Per-webhook Delivery History ──────────────────────────

function WebhookDeliveryHistory({ hookId, hookLabel, allLogs }: { hookId: string, hookLabel: string | undefined, allLogs: DeliveryLogEntry[] }) {
  const hookLogs = allLogs.filter(log => log.webhookId === hookId);
  const successCount = hookLogs.filter(l => l.status === 'success').length;
  const failCount = hookLogs.filter(l => l.status === 'failed').length;
  const avgResponseTime = hookLogs.filter(l => l.responseTime > 0).length > 0
    ? Math.round(hookLogs.filter(l => l.responseTime > 0).reduce((sum, l) => sum + l.responseTime, 0) / hookLogs.filter(l => l.responseTime > 0).length)
    : 0;

  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <label className="text-[10px] uppercase tracking-wider flex items-center gap-1.5" style={{ color: T.textMuted, fontWeight: 600 }}>
          <Activity size={10} /> Delivery History ({hookLogs.length})
        </label>
        {hookLogs.length > 0 && (
          <div className="flex items-center gap-3 text-[10px]">
            <span style={{ color: T.success }}>{successCount} ok</span>
            {failCount > 0 && <span style={{ color: T.danger }}>{failCount} failed</span>}
            {avgResponseTime > 0 && <span style={{ color: T.textMuted }}>avg {avgResponseTime}ms</span>}
          </div>
        )}
      </div>
      {hookLogs.length === 0 ? (
        <div className="text-center py-4 rounded-lg" style={{ backgroundColor: T.bg }}>
          <p className="text-[11px]" style={{ color: T.textMuted }}>No deliveries recorded yet. Use the Test button to fire a test event.</p>
        </div>
      ) : (
        <div className="space-y-1 max-h-48 overflow-y-auto rounded-lg" style={{ backgroundColor: T.bg, padding: '4px' }}>
          {hookLogs.map(log => (
            <div
              key={log.id}
              className="flex items-center gap-2 px-2.5 py-1.5 rounded-md text-[10px]"
              style={{ backgroundColor: log.status === 'success' ? T.successLight : T.dangerLight }}
            >
              <div
                className="w-1.5 h-1.5 rounded-full flex-shrink-0"
                style={{ backgroundColor: log.status === 'success' ? T.success : T.danger }}
              />
              <span style={{ color: T.text, fontFamily: 'ui-monospace, monospace' }}>{log.event}</span>
              {log.attempt > 1 && (
                <span className="text-[9px] px-1 py-0.5 rounded" style={{ backgroundColor: T.warningLight, color: T.warning }}>
                  #{log.attempt}
                </span>
              )}
              <span className="flex-1" />
              {log.error && (
                <span className="text-[9px] truncate max-w-[80px]" style={{ color: T.danger }} title={log.error}>
                  {log.error}
                </span>
              )}
              {log.responseTime > 0 && (
                <span style={{ color: T.textMuted }}>{log.responseTime}ms</span>
              )}
              <span style={{ color: T.textMuted }}>
                {new Date(log.timestamp).toLocaleTimeString('en-HK', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}