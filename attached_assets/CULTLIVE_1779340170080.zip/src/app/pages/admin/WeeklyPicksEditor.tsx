/**
 * WeeklyPicksEditor — Admin page for curating the 3 weekly picks
 * Search events, drag to reorder, save to CMS KV store
 */
import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useOutletContext } from 'react-router';
import {
  Search, X, Loader2, Save, Check, Trash2,
  Calendar, MapPin, ArrowUp, ArrowDown, AlertCircle,
} from 'lucide-react';
import { projectId } from '../../config/supabase';
import { authHeaders } from '../../hooks/useAdminApi';
import { fireWebhook } from '../../config/webhooks';

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-d507b98c`;

const T = {
  bg: '#FAFAF8',
  surface: '#FFFFFF',
  border: '#E8E6E1',
  text: '#1A1A1A',
  textMuted: '#8C8C8C',
  accent: '#B2483A',
  accentLight: '#B2483A12',
  success: '#16A34A',
  successLight: '#F0FDF4',
  font: "'Inter', system-ui, sans-serif",
};

interface EventItem {
  id: string;
  title: string;
  date?: string;
  time?: string;
  category?: string;
  district?: string;
  venueName?: string;
  image?: string;
  editorialHook?: string;
  editorialHook_zh?: string;
}

export function WeeklyPicksEditor() {
  const { accessToken } = useOutletContext<{ accessToken: string }>();
  const [allEvents, setAllEvents] = useState<EventItem[]>([]);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [note, setNote] = useState('');
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [saveError, setSaveError] = useState('');
  const [lastUpdated, setLastUpdated] = useState<string | null>(null);
  const [lastUpdatedBy, setLastUpdatedBy] = useState<string | null>(null);

  // Load events + current picks
  useEffect(() => {
    if (!accessToken) return;
    (async () => {
      try {
        // Fetch all event sources in parallel (mirrors DataContext merge logic)
        const [evRes, cmsRes, subRes, picksRes] = await Promise.all([
          fetch(`${API_BASE}/events`, { headers: authHeaders(accessToken) }).then(r => r.ok ? r.json() : { events: [] }),
          fetch(`${API_BASE}/cms/content/event/public`, { headers: authHeaders(accessToken) }).then(r => r.ok ? r.json() : { items: [] }),
          fetch(`${API_BASE}/cms/submissions/published`, { headers: authHeaders(accessToken) }).then(r => r.ok ? r.json() : { submissions: [] }),
          // Weekly picks stored in content KV store (same pattern as Template Editor)
          fetch(`${API_BASE}/cms/content/weekly-picks`, { headers: authHeaders(accessToken) }).then(r => r.ok ? r.json() : { items: [] }),
        ]);

        // Merge: KV events + CMS content + published submissions (same as DataContext)
        const merged: EventItem[] = [...(evRes.events || [])];
        const seenIds = new Set(merged.map(e => e.id));

        // Layer CMS content events
        for (const item of (cmsRes.items || [])) {
          if (!item?.id) continue;
          const idx = merged.findIndex(e => e.id === item.id);
          if (idx >= 0) {
            merged[idx] = { ...merged[idx], ...item };
          } else {
            merged.push(item);
            seenIds.add(item.id);
          }
        }

        // Layer published submissions
        for (const sub of (subRes.submissions || [])) {
          if (!sub?.id || seenIds.has(sub.id)) continue;
          merged.push({
            id: sub.id,
            title: sub.title || sub.eventName || 'Untitled',
            date: sub.date,
            time: sub.time,
            category: sub.category,
            district: sub.district,
            venueName: sub.venueName,
            image: sub.image,
          });
          seenIds.add(sub.id);
        }

        setAllEvents(merged);

        // Set curated picks from content KV store
        const picksItem = (picksRes.items || []).find((i: any) => i.id === 'curated' || i.sectionId === 'curated');
        const picksData = picksItem?.data || picksItem;
        if (picksData?.eventIds?.length > 0) {
          setSelectedIds(picksData.eventIds);
          setNote(picksData.note || '');
          setLastUpdated(picksData.updatedAt || null);
          setLastUpdatedBy(picksData.updatedBy || null);
        }
      } catch (err) {
        console.error('Failed to load:', err);
      }
      setLoading(false);
    })();
  }, [accessToken]);

  const savePicks = useCallback(async () => {
    if (!accessToken) return;
    setSaving(true);
    setSaveError('');
    try {
      const payload = {
        id: 'curated',
        sectionId: 'curated',
        data: {
          eventIds: selectedIds,
          note,
          updatedAt: new Date().toISOString(),
        },
        updatedAt: new Date().toISOString(),
      };
      const res = await fetch(`${API_BASE}/cms/content/weekly-picks/curated`, {
        method: 'PUT',
        headers: authHeaders(accessToken),
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        const errText = await res.text().catch(() => '');
        throw new Error(`Save failed (${res.status}): ${errText}`);
      }
      const data = await res.json();
      setLastUpdated(new Date().toISOString());
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);

      // Fire webhook
      fireWebhook('weekly_picks.updated', {
        eventIds: selectedIds,
        note,
      });
    } catch (err: any) {
      console.error('Failed to save:', err);
      setSaveError(err.message || 'Failed to save picks');
    }
    setSaving(false);
  }, [accessToken, selectedIds, note]);

  const addPick = (id: string) => {
    if (selectedIds.includes(id) || selectedIds.length >= 3) return;
    setSelectedIds(prev => [...prev, id]);
  };

  const removePick = (id: string) => {
    setSelectedIds(prev => prev.filter(i => i !== id));
  };

  const movePick = (idx: number, dir: -1 | 1) => {
    const newIdx = idx + dir;
    if (newIdx < 0 || newIdx >= selectedIds.length) return;
    setSelectedIds(prev => {
      const next = [...prev];
      [next[idx], next[newIdx]] = [next[newIdx], next[idx]];
      return next;
    });
  };

  const clearPicks = () => {
    setSelectedIds([]);
    setNote('');
  };

  // Filter events for search
  const filteredEvents = allEvents.filter(e => {
    if (!search) return true;
    const s = search.toLowerCase();
    return (
      e.title?.toLowerCase().includes(s) ||
      e.category?.toLowerCase().includes(s) ||
      e.district?.toLowerCase().includes(s) ||
      e.venueName?.toLowerCase().includes(s)
    );
  });

  // Selected event details
  const selectedEvents = selectedIds
    .map(id => allEvents.find(e => e.id === id))
    .filter(Boolean) as EventItem[];

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 size={20} className="animate-spin" style={{ color: T.textMuted }} />
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto" style={{ fontFamily: T.font }}>
      {/* Header */}
      <div className="flex items-start justify-between mb-8">
        <div>
          <h1 className="text-xl mb-1" style={{ color: T.text, fontWeight: 700 }}>
            Weekly Picks
          </h1>
          <p className="text-sm" style={{ color: T.textMuted }}>
            Curate 3 events as this week's editorial picks. These override all other pick logic.
          </p>
          {lastUpdated && (
            <p className="text-xs mt-1" style={{ color: T.textMuted }}>
              Last updated: {new Date(lastUpdated).toLocaleDateString('en-HK', { weekday: 'short', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
              {lastUpdatedBy && ` by ${lastUpdatedBy}`}
            </p>
          )}
        </div>
        <div className="flex gap-2">
          {selectedIds.length > 0 && (
            <button
              onClick={clearPicks}
              className="flex items-center gap-1.5 px-3 py-2 text-xs rounded-lg cursor-pointer transition-opacity hover:opacity-80"
              style={{ color: T.textMuted, border: `1px solid ${T.border}`, backgroundColor: T.surface }}
            >
              <Trash2 size={12} /> Clear
            </button>
          )}
          <button
            onClick={savePicks}
            disabled={saving}
            className="flex items-center gap-1.5 px-5 py-2 text-sm rounded-lg cursor-pointer transition-all hover:opacity-90"
            style={{
              backgroundColor: saved ? T.success : T.accent,
              color: '#ffffff',
              fontWeight: 600,
              border: 'none',
            }}
          >
            {saving ? <Loader2 size={14} className="animate-spin" /> : saved ? <Check size={14} /> : <Save size={14} />}
            {saving ? 'Saving...' : saved ? 'Saved!' : 'Save Picks'}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* ─── Left: Selected Picks ─── */}
        <div>
          {saveError && (
            <div className="flex items-center gap-2 px-3 py-2 mb-3 rounded-lg text-xs" style={{ backgroundColor: '#FEF2F2', color: '#DC2626', border: '1px solid #FECACA' }}>
              <AlertCircle size={14} />
              <span>{saveError}</span>
              <button onClick={() => setSaveError('')} className="ml-auto cursor-pointer" style={{ border: 'none', background: 'none', color: '#DC2626' }}><X size={12} /></button>
            </div>
          )}
          <h2 className="text-sm mb-3" style={{ color: T.text, fontWeight: 600 }}>
            Selected Picks ({selectedIds.length}/3)
          </h2>

          {selectedEvents.length === 0 ? (
            <div
              className="flex flex-col items-center justify-center py-12 px-4 rounded-xl text-center"
              style={{ border: `2px dashed ${T.border}`, backgroundColor: `${T.surface}80` }}
            >
              <AlertCircle size={24} className="mb-3" style={{ color: T.textMuted }} />
              <p className="text-sm" style={{ color: T.textMuted }}>
                No picks selected yet. Search and add events from the right panel.
              </p>
              <p className="text-xs mt-1" style={{ color: T.textMuted }}>
                When empty, the system uses quiz-based or default picks.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              <AnimatePresence mode="popLayout">
                {selectedEvents.map((event, idx) => (
                  <motion.div
                    key={event.id}
                    layout
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="flex items-start gap-3 p-4 rounded-xl"
                    style={{ backgroundColor: T.surface, border: `1px solid ${T.border}` }}
                  >
                    <div className="flex flex-col items-center gap-1 pt-1">
                      <span
                        className="w-6 h-6 flex items-center justify-center rounded-full text-xs"
                        style={{ backgroundColor: T.accentLight, color: T.accent, fontWeight: 700 }}
                      >
                        {idx + 1}
                      </span>
                      <button
                        onClick={() => movePick(idx, -1)}
                        disabled={idx === 0}
                        className="p-0.5 cursor-pointer disabled:opacity-20"
                        style={{ color: T.textMuted, border: 'none', backgroundColor: 'transparent' }}
                      >
                        <ArrowUp size={12} />
                      </button>
                      <button
                        onClick={() => movePick(idx, 1)}
                        disabled={idx === selectedEvents.length - 1}
                        className="p-0.5 cursor-pointer disabled:opacity-20"
                        style={{ color: T.textMuted, border: 'none', backgroundColor: 'transparent' }}
                      >
                        <ArrowDown size={12} />
                      </button>
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="text-sm truncate" style={{ color: T.text, fontWeight: 600 }}>
                        {event.title}
                      </h4>
                      <div className="flex items-center gap-3 mt-1">
                        {event.date && (
                          <span className="flex items-center gap-1 text-[10px]" style={{ color: T.textMuted }}>
                            <Calendar size={10} /> {event.date}
                          </span>
                        )}
                        {event.district && (
                          <span className="flex items-center gap-1 text-[10px]" style={{ color: T.textMuted }}>
                            <MapPin size={10} /> {event.district}
                          </span>
                        )}
                      </div>
                      {event.editorialHook && (
                        <p className="text-[11px] italic mt-1.5 line-clamp-1" style={{ color: T.accent }}>
                          "{event.editorialHook}"
                        </p>
                      )}
                      {!event.editorialHook && (
                        <p className="text-[10px] mt-1.5" style={{ color: '#D97706' }}>
                          No editorial hook — consider adding one in Event Manager
                        </p>
                      )}
                    </div>
                    <button
                      onClick={() => removePick(event.id)}
                      className="p-1.5 rounded-md cursor-pointer transition-colors hover:bg-red-50"
                      style={{ color: '#DC2626', border: 'none', backgroundColor: 'transparent' }}
                    >
                      <X size={14} />
                    </button>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          )}

          {/* Editor note */}
          <div className="mt-4">
            <label className="text-[10px] uppercase tracking-wider block mb-1" style={{ color: T.textMuted, fontWeight: 600 }}>
              Editor's Note (internal)
            </label>
            <textarea
              value={note}
              onChange={e => setNote(e.target.value)}
              placeholder="Why these picks? (internal note for team)"
              rows={2}
              className="w-full px-3 py-2 text-xs rounded-lg outline-none resize-none"
              style={{ border: `1px solid ${T.border}`, backgroundColor: T.surface, color: T.text, fontFamily: T.font }}
            />
          </div>
        </div>

        {/* ─── Right: Event Search ─── */}
        <div>
          <h2 className="text-sm mb-3" style={{ color: T.text, fontWeight: 600 }}>
            All Events
          </h2>

          {/* Search */}
          <div className="relative mb-3">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: T.textMuted }} />
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search events by title, category, district..."
              className="w-full pl-9 pr-3 py-2.5 text-xs rounded-lg outline-none"
              style={{ border: `1px solid ${T.border}`, backgroundColor: T.surface, color: T.text, fontFamily: T.font }}
            />
            {search && (
              <button
                onClick={() => setSearch('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 cursor-pointer"
                style={{ color: T.textMuted, border: 'none', backgroundColor: 'transparent' }}
              >
                <X size={12} />
              </button>
            )}
          </div>

          {/* Event list */}
          <div
            className="space-y-1.5 overflow-y-auto pr-1"
            style={{ maxHeight: '500px' }}
          >
            {filteredEvents.length === 0 ? (
              <p className="text-xs py-8 text-center" style={{ color: T.textMuted }}>
                No events found
              </p>
            ) : (
              filteredEvents.map(event => {
                const isSelected = selectedIds.includes(event.id);
                return (
                  <button
                    key={event.id}
                    onClick={() => isSelected ? removePick(event.id) : addPick(event.id)}
                    disabled={!isSelected && selectedIds.length >= 3}
                    className="w-full flex items-center gap-3 p-3 rounded-lg text-left cursor-pointer transition-all hover:opacity-80 disabled:opacity-40 disabled:cursor-not-allowed"
                    style={{
                      backgroundColor: isSelected ? T.accentLight : T.surface,
                      border: `1px solid ${isSelected ? T.accent + '40' : T.border}`,
                    }}
                  >
                    {event.image && (
                      <img
                        src={event.image}
                        alt=""
                        className="w-10 h-10 rounded-md object-cover flex-shrink-0"
                      />
                    )}
                    <div className="flex-1 min-w-0">
                      <h5 className="text-xs truncate" style={{ color: T.text, fontWeight: 500 }}>
                        {event.title}
                      </h5>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-[10px]" style={{ color: T.textMuted }}>
                          {event.category}
                        </span>
                        {event.district && (
                          <span className="text-[10px]" style={{ color: T.textMuted }}>
                            {event.district}
                          </span>
                        )}
                      </div>
                    </div>
                    {isSelected ? (
                      <Check size={14} style={{ color: T.accent }} />
                    ) : (
                      <span className="text-[10px]" style={{ color: T.textMuted }}>+ Add</span>
                    )}
                  </button>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
}