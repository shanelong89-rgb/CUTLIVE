import { useState, useEffect } from 'react';
import { useOutletContext } from 'react-router';
import { motion } from 'motion/react';
import { Save, Loader2, Check, Info } from 'lucide-react';
import { projectId, publicAnonKey } from '../../config/supabase';

const N = {
  pageBg: '#FAFAF8',
  surface: '#FFFFFF',
  surfaceMuted: '#F3F3F0',
  border: 'rgba(0,0,0,0.06)',
  text: '#1A1A1A',
  textSecondary: '#5A5A5A',
  textMuted: '#9A9A9A',
  dark: '#1A1A1A',
  green: '#16A34A',
  greenBg: 'rgba(22,163,74,0.06)',
  greenBorder: 'rgba(22,163,74,0.1)',
  red: '#DC2626',
  blue: '#2563EB',
  blueBg: 'rgba(37,99,235,0.05)',
  font: "'Inter', 'Noto Sans HK', system-ui, sans-serif",
};

const API = `https://${projectId}.supabase.co/functions/v1/make-server-d507b98c/cms`;

interface ModerationSettings {
  autoApproveThreshold: number;
  autoRejectThreshold: number;
  requireImages: boolean;
  requireDescription: boolean;
  requireLocation: boolean;
  blockedKeywords: string[];
}

const DEFAULT_SETTINGS: ModerationSettings = {
  autoApproveThreshold: 70,
  autoRejectThreshold: 40,
  requireImages: true,
  requireDescription: true,
  requireLocation: true,
  blockedKeywords: [],
};

export function AdminSettings() {
  const { accessToken } = useOutletContext<{ accessToken: string }>();
  const [settings, setSettings] = useState<ModerationSettings>(DEFAULT_SETTINGS);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [keywordsText, setKeywordsText] = useState('');

  useEffect(() => {
    if (!accessToken) return;
    fetch(`${API}/settings/moderation`, {
      headers: { 'Authorization': `Bearer ${publicAnonKey}`, 'X-Auth-Token': accessToken },
    })
      .then(r => r.json())
      .then(data => {
        if (data.settings) {
          setSettings(data.settings);
          setKeywordsText((data.settings.blockedKeywords || []).join(', '));
        }
      })
      .catch(err => console.log('Failed to load settings:', err))
      .finally(() => setLoading(false));
  }, [accessToken]);

  const handleSave = async () => {
    setSaving(true);
    try {
      const updated = { ...settings, blockedKeywords: keywordsText.split(',').map(k => k.trim()).filter(Boolean) };
      await fetch(`${API}/settings/moderation`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${publicAnonKey}`, 'X-Auth-Token': accessToken },
        body: JSON.stringify(updated),
      });
      setSettings(updated);
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } catch (err) {
      console.log('Save failed:', err);
    }
    setSaving(false);
  };

  return (
    <div className="p-5 sm:p-8 lg:p-10 max-w-[720px] mx-auto" style={{ fontFamily: N.font }}>
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
        <p className="text-[11px] font-medium uppercase tracking-wider mb-1.5"
          style={{ color: N.textMuted }}>Configure</p>
        <h1 className="text-[1.5rem] font-semibold tracking-tight" style={{ color: N.text }}>
          AI Moderation Settings
        </h1>
        <p className="mt-1 text-[15px]" style={{ color: N.textMuted }}>
          Configure how the scoring system evaluates incoming submissions.
        </p>
      </motion.div>

      <div className="p-5 sm:p-7 mb-4" style={{
        backgroundColor: N.surface, border: `1px solid ${N.border}`, borderRadius: '16px',
      }}>
        {/* Info */}
        <div className="flex items-start gap-2.5 p-3.5 mb-7" style={{
          backgroundColor: N.blueBg, borderRadius: '10px', border: '1px solid rgba(37,99,235,0.08)',
        }}>
          <Info size={15} className="flex-shrink-0 mt-0.5" style={{ color: N.blue }} />
          <p className="text-[12px] leading-relaxed" style={{ color: N.textSecondary }}>
            Submissions are automatically scored by a rule-based system. Items above the auto-approve threshold
            are marked as "AI Approved". Items below the auto-reject threshold are auto-rejected. Everything in between
            is flagged for your review.
          </p>
        </div>

        <div className="space-y-7">
          <div>
            <label className="block text-[13px] font-medium mb-2" style={{ color: N.text }}>
              Auto-Approve Threshold
            </label>
            <div className="flex items-center gap-4">
              <input type="range" min={0} max={100} value={settings.autoApproveThreshold}
                onChange={e => setSettings({ ...settings, autoApproveThreshold: Number(e.target.value) })}
                className="flex-1 accent-[#16A34A]" />
              <span className="text-[18px] font-semibold w-10 text-right" style={{ color: N.green }}>
                {settings.autoApproveThreshold}
              </span>
            </div>
            <p className="text-[12px] mt-1" style={{ color: N.textMuted }}>
              Submissions scoring above this are auto-approved for admin review.
            </p>
          </div>

          <div>
            <label className="block text-[13px] font-medium mb-2" style={{ color: N.text }}>
              Auto-Reject Threshold
            </label>
            <div className="flex items-center gap-4">
              <input type="range" min={0} max={100} value={settings.autoRejectThreshold}
                onChange={e => setSettings({ ...settings, autoRejectThreshold: Number(e.target.value) })}
                className="flex-1 accent-[#DC2626]" />
              <span className="text-[18px] font-semibold w-10 text-right" style={{ color: N.red }}>
                {settings.autoRejectThreshold}
              </span>
            </div>
            <p className="text-[12px] mt-1" style={{ color: N.textMuted }}>
              Submissions scoring below this are auto-rejected.
            </p>
          </div>

          <div className="h-px" style={{ backgroundColor: N.border }} />

          <div>
            <label className="block text-[13px] font-medium mb-3" style={{ color: N.text }}>
              Quality Requirements
            </label>
            <div className="space-y-3">
              {([
                { key: 'requireImages', label: 'Require at least one image' },
                { key: 'requireDescription', label: 'Require description (min 20 chars)' },
                { key: 'requireLocation', label: 'Require location / venue' },
              ] as const).map(req => (
                <label key={req.key} className="flex items-center gap-3 cursor-pointer">
                  <input type="checkbox" checked={settings[req.key]}
                    onChange={e => setSettings({ ...settings, [req.key]: e.target.checked })}
                    className="w-3.5 h-3.5 accent-[#1A1A1A]" />
                  <span className="text-[14px]" style={{ color: N.textSecondary }}>{req.label}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="h-px" style={{ backgroundColor: N.border }} />

          <div>
            <label className="block text-[13px] font-medium mb-2" style={{ color: N.text }}>
              Blocked Keywords
            </label>
            <textarea
              value={keywordsText}
              onChange={e => setKeywordsText(e.target.value)}
              placeholder="test, spam, lorem ipsum (comma-separated)"
              rows={3}
              className="w-full px-4 py-3 text-[14px] outline-none resize-none"
              style={{
                backgroundColor: N.surfaceMuted, border: `1px solid ${N.border}`,
                borderRadius: '10px', color: N.text,
              }}
            />
            <p className="text-[12px] mt-1" style={{ color: N.textMuted }}>
              Submissions containing these keywords will be penalized in scoring.
            </p>
          </div>
        </div>
      </div>

      <button
        onClick={handleSave}
        disabled={saving}
        className="flex items-center gap-2 px-5 py-2.5 text-[14px] font-medium cursor-pointer transition-opacity disabled:opacity-50 hover:opacity-90"
        style={{ backgroundColor: N.dark, color: '#fff', borderRadius: '10px' }}
      >
        {saving ? <Loader2 size={15} className="animate-spin" /> : saved ? <Check size={15} /> : <Save size={15} />}
        {saving ? 'Saving...' : saved ? 'Saved!' : 'Save Settings'}
      </button>
    </div>
  );
}