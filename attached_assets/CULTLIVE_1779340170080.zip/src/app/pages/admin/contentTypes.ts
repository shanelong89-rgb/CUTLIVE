// ═══════════════════════════════════════════════════
// CONTENT TYPE REGISTRY
// The heart of the CMS. Add a new content type here
// and everything auto-discovers it: sidebar, CRUD UI,
// API, preview. Zero other files to touch.
// ═══════════════════════════════════════════════════

export interface FieldDef {
  key: string;
  label: string;
  type: 'text' | 'textarea' | 'number' | 'select' | 'toggle' | 'image' | 'json' | 'tags' | 'color' | 'date' | 'url';
  options?: { label: string; value: string }[];
  placeholder?: string;
  required?: boolean;
  half?: boolean; // render at half-width in forms
}

export interface ContentType {
  key: string;           // URL slug & KV prefix
  label: string;         // Singular
  labelPlural: string;   // Plural
  icon: string;          // Lucide icon name
  idField: string;       // Which field is the unique ID
  titleField: string;    // Which field shows as the item title in lists
  subtitleField: string; // Secondary info in list view
  imageField?: string;   // Which field holds the thumbnail image
  fields: FieldDef[];
  defaultValues: Record<string, any>;
  page: string;          // Sidebar grouping key
  pageHint?: string;
  /** URL pattern for viewing on the public site, e.g. '/event/:id' */
  viewUrlPattern?: string;
}

// ─── Content Type Definitions ───

export const contentTypes: ContentType[] = [
  {
    key: 'event',
    label: 'Event',
    labelPlural: 'Events',
    icon: 'Calendar',
    idField: 'id',
    titleField: 'title',
    subtitleField: 'category',
    imageField: 'image',
    page: 'events',
    pageHint: 'Cultural events shown on the events & map pages',
    viewUrlPattern: '/event/:id',
    fields: [
      { key: 'id', label: 'ID', type: 'text', placeholder: 'auto-generated' },
      { key: 'title', label: 'Title', type: 'text', required: true, placeholder: 'Morning Trail Run at Dragon\'s Back' },
      { key: 'category', label: 'Category', type: 'select', half: true, options: [
        { label: 'Run Clubs', value: 'run-clubs' },
        { label: 'Wellness & Yoga', value: 'wellness' },
        { label: 'Hikes & Outdoors', value: 'hikes' },
        { label: 'Coffee Raves & Social', value: 'coffee-raves' },
        { label: 'Workshops & Classes', value: 'workshops' },
        { label: 'Meetups & Community', value: 'meetups' },
        { label: 'Nightlife & Music', value: 'nightlife' },
        { label: 'Art & Exhibitions', value: 'art' },
        { label: 'Food & Markets', value: 'food' },
        { label: 'Family & Kids', value: 'family' },
        { label: 'Other', value: 'other' },
      ]},
      { key: 'price', label: 'Price', type: 'text', half: true, placeholder: 'Free / $80' },
      { key: 'date', label: 'Date', type: 'date', half: true },
      { key: 'endDate', label: 'End Date', type: 'date', half: true },
      { key: 'time', label: 'Time', type: 'text', half: true, placeholder: '7:00 AM' },
      { key: 'status', label: 'Status', type: 'select', half: true, options: [
        { label: 'Upcoming', value: 'upcoming' },
        { label: 'Ongoing', value: 'ongoing' },
        { label: 'Past', value: 'past' },
      ]},
      { key: 'image', label: 'Image URL', type: 'image', placeholder: 'https://...' },
      { key: 'description', label: 'Description', type: 'textarea', required: true, placeholder: 'What is this event about?' },
      { key: 'featured', label: 'Featured', type: 'toggle' },
      { key: 'venueName', label: 'Venue Name', type: 'text', placeholder: 'Venue or location name' },
      { key: 'venueId', label: 'Venue ID', type: 'text', half: true, placeholder: 'Link to a venue' },
      { key: 'district', label: 'District', type: 'select', half: true, options: [
        { label: 'Central', value: 'Central' },
        { label: 'Wan Chai', value: 'Wan Chai' },
        { label: 'Causeway Bay', value: 'Causeway Bay' },
        { label: 'Sheung Wan', value: 'Sheung Wan' },
        { label: 'Sai Ying Pun', value: 'Sai Ying Pun' },
        { label: 'Kennedy Town', value: 'Kennedy Town' },
        { label: 'Tsim Sha Tsui', value: 'Tsim Sha Tsui' },
        { label: 'Mong Kok', value: 'Mong Kok' },
        { label: 'Sham Shui Po', value: 'Sham Shui Po' },
        { label: 'West Kowloon', value: 'West Kowloon' },
        { label: 'Wong Chuk Hang', value: 'Wong Chuk Hang' },
        { label: 'Stanley', value: 'Stanley' },
        { label: 'Sha Tin', value: 'Sha Tin' },
        { label: 'Tai Po', value: 'Tai Po' },
        { label: 'Sai Kung', value: 'Sai Kung' },
        { label: 'Lantau', value: 'Lantau' },
        { label: 'Other', value: 'Other' },
      ]},
      { key: 'modeTags', label: 'Mode Tags', type: 'tags', placeholder: 'degen, artsy, foodie, family' },
      { key: 'vibes', label: 'Vibes', type: 'tags', placeholder: 'chill, underground, rooftop' },
      { key: 'artists', label: 'Artists / Performers', type: 'tags', placeholder: 'DJ Soda, Bonobo' },
      { key: 'lat', label: 'Latitude', type: 'number', half: true, placeholder: '22.2783' },
      { key: 'lng', label: 'Longitude', type: 'number', half: true, placeholder: '114.1747' },
      { key: 'address', label: 'Address', type: 'text', placeholder: 'Full address' },
      { key: 'sourceUrl', label: 'Source URL', type: 'url', placeholder: 'https://...' },
      { key: 'ticketUrl', label: 'Ticket URL', type: 'url', placeholder: 'https://...' },
    ],
    defaultValues: {
      id: '',
      title: '',
      category: '',
      price: 'Free',
      date: '',
      endDate: '',
      time: '',
      status: 'upcoming',
      image: '',
      description: '',
      featured: false,
      venueName: '',
      venueId: '',
      district: '',
      modeTags: [],
      vibes: [],
      artists: [],
      lat: '',
      lng: '',
      address: '',
      sourceUrl: '',
      ticketUrl: '',
    },
  },
  {
    key: 'venue',
    label: 'Venue',
    labelPlural: 'Venues',
    icon: 'MapPin',
    idField: 'id',
    titleField: 'name',
    subtitleField: 'district',
    imageField: 'image',
    page: 'map',
    pageHint: 'Locations displayed on the interactive map',
    viewUrlPattern: '/venue/:id',
    fields: [
      { key: 'id', label: 'ID', type: 'text' },
      { key: 'name', label: 'Name', type: 'text', required: true, placeholder: 'Venue name' },
      { key: 'nameZh', label: 'Name (Chinese)', type: 'text', placeholder: '中文名稱' },
      { key: 'description', label: 'Description', type: 'textarea', placeholder: 'About this venue...' },
      { key: 'category', label: 'Category', type: 'text', half: true, placeholder: 'bar, gallery, gym...' },
      { key: 'subcategory', label: 'Subcategory', type: 'text', half: true },
      { key: 'lat', label: 'Latitude', type: 'number', half: true, placeholder: '22.2783' },
      { key: 'lng', label: 'Longitude', type: 'number', half: true, placeholder: '114.1747' },
      { key: 'district', label: 'District', type: 'text', half: true, placeholder: 'Central' },
      { key: 'address', label: 'Address', type: 'text', placeholder: 'Full address' },
      { key: 'image', label: 'Image URL', type: 'image' },
      { key: 'vibeTags', label: 'Vibe Tags', type: 'tags', placeholder: 'rooftop, live-music, craft-cocktails' },
      { key: 'priceRange', label: 'Price Range (1-4)', type: 'number', half: true },
    ],
    defaultValues: {
      id: '',
      name: '',
      nameZh: '',
      description: '',
      category: '',
      subcategory: '',
      lat: 0,
      lng: 0,
      district: '',
      address: '',
      image: '',
      vibeTags: [],
      priceRange: 2,
    },
  },
  {
    key: 'recap',
    label: 'Recap',
    labelPlural: 'Recaps',
    icon: 'Camera',
    idField: 'id',
    titleField: 'caption',
    subtitleField: 'source',
    imageField: 'thumbnail',
    page: 'events',
    pageHint: 'Community recaps linked to past events',
    viewUrlPattern: '/event/:eventId',
    fields: [
      { key: 'id', label: 'ID', type: 'text' },
      { key: 'eventId', label: 'Event ID', type: 'text', half: true },
      { key: 'eventTitle', label: 'Event Title', type: 'text' },
      { key: 'venueId', label: 'Venue ID', type: 'text', half: true },
      { key: 'source', label: 'Source', type: 'select', half: true, options: [
        { label: 'Instagram', value: 'instagram' },
        { label: 'TikTok', value: 'tiktok' },
        { label: 'YouTube', value: 'youtube' },
        { label: 'Community', value: 'manual' },
      ]},
      { key: 'thumbnail', label: 'Thumbnail URL', type: 'image' },
      { key: 'caption', label: 'Caption', type: 'textarea', placeholder: 'Recap description...' },
      { key: 'caption_zh', label: 'Caption (Chinese)', type: 'textarea', placeholder: '中文描述...' },
      { key: 'media', label: 'Media URLs', type: 'tags', placeholder: 'Photo/video URLs' },
      { key: 'contributorName', label: 'Contributor', type: 'text', half: true },
      { key: 'engagement', label: 'Engagement Score', type: 'number', half: true },
      { key: 'capturedAt', label: 'Captured Date', type: 'date', half: true },
    ],
    defaultValues: {
      id: '',
      eventId: '',
      eventTitle: '',
      venueId: '',
      source: 'manual',
      thumbnail: '',
      caption: '',
      caption_zh: '',
      media: [],
      contributorName: '',
      engagement: 0,
      capturedAt: '',
    },
  },
  // site-image content type REMOVED — site images are now managed
  // via the Template Editor's "Site Images" tab + useSiteImages() hook.
  // See /src/app/data/site-images.ts for the registry.
];

// ─── Helpers ───

export function getContentType(key: string): ContentType | undefined {
  return contentTypes.find(ct => ct.key === key);
}

export function getContentTypesByPage(page: string): ContentType[] {
  return contentTypes.filter(ct => ct.page === page);
}