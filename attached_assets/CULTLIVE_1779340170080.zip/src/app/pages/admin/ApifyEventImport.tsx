/**
 * ApifyEventImport — /admin/apify-import
 *
 * 4-step Apify scraper + import wizard:
 *   1 Configure  —  Select actor, paste JSON, or fetch from run
 *   2 Review & Edit  —  Inspect, toggle, inline-edit
 *   3 Enrich  —  Add CULTIVE-specific fields (modes, vibes, category)
 *   4 Done  —  Upsert to KV, show stats
 *
 * Uses the same bulk import endpoint, quality scoring, and normalization
 * pipeline as BulkEventImport (RA) and LSAEventImport.
 */

import { useState, useCallback, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Upload, CheckCircle2, AlertCircle, ChevronDown, ChevronUp,
  Trash2, RotateCcw, ArrowRight, ArrowLeft, Download, Tag, MapPin,
  Calendar, Clock, DollarSign, Link, Music, User, Loader2, Sparkles,
  Search, FolderOpen, X, Star, History, Eye, EyeOff,
  LayoutGrid, ListChecks, Zap, ExternalLink, Image as ImageIcon,
  Play, Pause, RefreshCw, FileJson, Box, CloudDownload, Clipboard,
  Activity, Check, Database,
} from 'lucide-react';
import { useOutletContext } from 'react-router';
import { projectId, publicAnonKey } from '../../config/supabase';
import { fireWebhook } from '../../config/webhooks';

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-d507b98c`;

// ── Design tokens ────────────────────────────────────────────────────────────
const N = {
  pageBg:    '#FAFAF8',
  surface:   '#FFFFFF',
  surface2:  '#F4F4F0',
  surface3:  '#EEECEA',
  dark:      '#1A1A1A',
  text:      '#1A1A1A',
  textMuted: '#6B7280',
  border:    'rgba(0,0,0,0.08)',
  borderMid: 'rgba(0,0,0,0.14)',
  green:     '#16A34A',
  greenBg:   'rgba(22,163,74,0.08)',
  orange:    '#EA580C',
  orangeBg:  'rgba(234,88,12,0.07)',
  red:       '#DC2626',
  redBg:     'rgba(220,38,38,0.07)',
  blue:      '#2563EB',
  blueBg:    'rgba(37,99,235,0.07)',
  purple:    '#7C3AED',
  purpleBg:  'rgba(124,58,237,0.07)',
  apify:     '#FF6D00',
  apifyBg:   'rgba(255,109,0,0.08)',
  font:      "'Inter', 'Noto Sans HK', system-ui, sans-serif",
};

// ── CULTIVE constants ────────────────────────────────────────────────────────
const CULTIVE_CATEGORIES = [
  'nightlife', 'music', 'art', 'exhibition', 'food', 'wellness',
  'workshop', 'family', 'sports', 'festival', 'film', 'theatre', 'other',
];

const CULTIVE_MODES = [
  { id: 'degen',     label: 'Night',     color: '#D600FF' },
  { id: 'artsy',     label: 'Art',       color: '#8338EC' },
  { id: 'foodie',    label: 'Food',      color: '#2563EB' },
  { id: 'family',    label: 'Family',    color: '#FF8C42' },
  { id: 'lifestyle', label: 'Lifestyle', color: '#2D6A4F' },
];

const VIBE_OPTIONS = [
  'underground', 'rooftop', 'intimate', 'free-entry', 'weekend-vibe',
  'late-night', 'all-ages', 'lgbtq+', 'outdoor', 'members-only',
];

// ── Types ────────────────────────────────────────────────────────────────────
interface ParsedEvent {
  id: string;
  title: string;
  date: string;
  endDate?: string;
  time: string;
  venueName: string;
  venueId: string;
  address: string;
  district: string;
  description: string;
  image: string;
  price: string;
  ticketUrl: string;
  sourceUrl: string;
  source: string;
  _source: string;
  artists: string[];
  genres: string[];
  modeTags: string[];
  modes: string[];
  vibes: string[];
  category: string;
  status: 'upcoming' | 'ongoing' | 'past';
  featured: boolean;
  tags: string[];
  lat?: number;
  lng?: number;
  selected: boolean;
}

interface ImportBatch {
  id: string;
  timestamp: string;
  created: number;
  updated: number;
  invalid: number;
  skipped: number;
  total: number;
  eventIds: string[];
  avgQuality: number;
  label?: string;
}

// ── Quality scoring ──────────────────────────────────────────────────────────
function getQuality(ev: ParsedEvent): number {
  const checks = [
    !!ev.title,
    !!ev.image,
    typeof ev.description === 'string' && ev.description.length > 30,
    !!ev.date,
    !!ev.time,
    !!(ev.venueName || ev.venueId),
    !!ev.price && ev.price !== 'Check event page',
    !!(ev.lat && ev.lng),
    (ev.modeTags?.length > 0 || ev.modes?.length > 0),
    !!ev.category,
    ev.artists?.length > 0,
  ];
  return Math.round((checks.filter(Boolean).length / checks.length) * 100);
}

function getMissingFields(ev: ParsedEvent): string[] {
  const m: string[] = [];
  if (!ev.image) m.push('image');
  if (!ev.description || ev.description.length < 30) m.push('description');
  if (!ev.date) m.push('date');
  if (!ev.time) m.push('time');
  if (!ev.venueName && !ev.venueId) m.push('venue');
  if (!ev.price || ev.price === 'Check event page') m.push('price');
  if (!ev.lat || !ev.lng) m.push('GPS');
  if (!ev.modeTags?.length && !ev.modes?.length) m.push('modes');
  if (!ev.category) m.push('category');
  if (!ev.artists?.length) m.push('artists');
  return m;
}

// ── Quality bar component ────────────────────────────────────────────────────
function QualityBar({ value }: { value: number }) {
  const color = value >= 70 ? N.green : value >= 45 ? N.orange : N.red;
  return (
    <div className="h-1.5 rounded-full overflow-hidden w-full" style={{ background: N.surface3 }}>
      <motion.div className="h-full rounded-full" style={{ background: color }}
        initial={{ width: 0 }} animate={{ width: `${value}%` }} transition={{ duration: 0.6 }} />
    </div>
  );
}

// ── Steps indicator ──────────────────────────────────────────────────────────
function Steps({ step }: { step: number }) {
  const steps = ['Configure', 'Review & Edit', 'Enrich', 'Done'];
  return (
    <div className="flex items-center gap-2 mb-8">
      {steps.map((label, i) => {
        const num = i + 1;
        const active = num === step;
        const done = num < step;
        return (
          <div key={label} className="flex items-center gap-2">
            <div className="flex items-center gap-1.5">
              <div className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold transition-all"
                style={{
                  background: active ? N.apify : done ? N.green : N.surface3,
                  color: active || done ? '#fff' : N.textMuted,
                }}>
                {done ? <Check size={12} /> : num}
              </div>
              <span className="text-xs font-medium hidden sm:inline"
                style={{ color: active ? N.text : N.textMuted }}>{label}</span>
            </div>
            {i < steps.length - 1 && (
              <div className="w-6 h-px" style={{ background: num < step ? N.green : N.border }} />
            )}
          </div>
        );
      })}
    </div>
  );
}

// ── Event Card (Review step) ─────────────────────────────────────────────────
function EventCard({ ev, idx, onChange, onRemove }: {
  ev: ParsedEvent; idx: number;
  onChange: (idx: number, patch: Partial<ParsedEvent>) => void;
  onRemove: (idx: number) => void;
}) {
  const [open, setOpen] = useState(false);
  const q = getQuality(ev);
  const missing = getMissingFields(ev);

  return (
    <motion.div layout exit={{ opacity: 0, height: 0 }}
      className="rounded-xl overflow-hidden"
      style={{ background: N.surface, border: `1px solid ${ev.selected ? N.apify : N.border}`, opacity: ev.selected ? 1 : 0.5 }}>
      <div className="flex items-center gap-3 p-3 cursor-pointer" onClick={() => setOpen(o => !o)}>
        <input type="checkbox" checked={ev.selected}
          onChange={() => onChange(idx, { selected: !ev.selected })}
          onClick={e => e.stopPropagation()}
          className="rounded accent-orange-500 w-4 h-4 flex-shrink-0" />
        {ev.image ? (
          <img src={ev.image} alt="" className="w-12 h-12 rounded-lg object-cover flex-shrink-0" />
        ) : (
          <div className="w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: N.surface3 }}>
            <ImageIcon size={14} style={{ color: N.textMuted }} />
          </div>
        )}
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold truncate" style={{ color: N.text }}>{ev.title || 'Untitled'}</p>
          <p className="text-xs truncate" style={{ color: N.textMuted }}>
            {ev.venueName || 'No venue'} · {ev.district || '—'} · {ev.date || 'No date'}
          </p>
        </div>
        <div className="flex items-center gap-3 flex-shrink-0">
          <div className="w-16"><QualityBar value={q} /></div>
          <span className="text-xs font-bold tabular-nums w-8 text-right"
            style={{ color: q >= 70 ? N.green : q >= 45 ? N.orange : N.red }}>{q}%</span>
          {open ? <ChevronUp size={14} style={{ color: N.textMuted }} /> : <ChevronDown size={14} style={{ color: N.textMuted }} />}
        </div>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
            <div className="px-4 pb-4 space-y-3" style={{ borderTop: `1px solid ${N.border}` }}>
              {missing.length > 0 && (
                <div className="flex flex-wrap gap-1 pt-3">
                  {missing.map(m => (
                    <span key={m} className="px-2 py-0.5 text-[10px] rounded-full font-medium"
                      style={{ background: N.orangeBg, color: N.orange }}>Missing: {m}</span>
                  ))}
                </div>
              )}
              <div className="grid grid-cols-2 gap-2 pt-2">
                <MiniField label="Title" value={ev.title} onChange={v => onChange(idx, { title: v })} />
                <MiniField label="Venue" value={ev.venueName} onChange={v => onChange(idx, { venueName: v })} />
                <MiniField label="Date" value={ev.date} onChange={v => onChange(idx, { date: v })} />
                <MiniField label="Time" value={ev.time} onChange={v => onChange(idx, { time: v })} />
                <MiniField label="District" value={ev.district} onChange={v => onChange(idx, { district: v })} />
                <MiniField label="Price" value={ev.price} onChange={v => onChange(idx, { price: v })} />
                <MiniField label="Image URL" value={ev.image} onChange={v => onChange(idx, { image: v })} span2 />
                <MiniField label="Description" value={ev.description} onChange={v => onChange(idx, { description: v })} span2 multiline />
              </div>
              <div className="flex justify-end">
                <button onClick={() => onRemove(idx)}
                  className="flex items-center gap-1.5 px-3 py-1 text-xs font-medium rounded-lg transition"
                  style={{ color: N.red, background: N.redBg }}>
                  <Trash2 size={11} /> Remove
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

function MiniField({ label, value, onChange, span2, multiline }: {
  label: string; value: string; onChange: (v: string) => void; span2?: boolean; multiline?: boolean;
}) {
  return (
    <div className={span2 ? 'col-span-2' : ''}>
      <label className="text-[10px] font-medium block mb-0.5" style={{ color: N.textMuted }}>{label}</label>
      {multiline ? (
        <textarea value={value} onChange={e => onChange(e.target.value)} rows={2}
          className="w-full px-2.5 py-1.5 text-xs rounded-lg outline-none resize-none"
          style={{ background: N.surface2, border: `1px solid ${N.border}`, color: N.text, fontFamily: N.font }} />
      ) : (
        <input type="text" value={value} onChange={e => onChange(e.target.value)}
          className="w-full px-2.5 py-1.5 text-xs rounded-lg outline-none"
          style={{ background: N.surface2, border: `1px solid ${N.border}`, color: N.text, fontFamily: N.font }} />
      )}
    </div>
  );
}

// ── Enrich Card (Step 3) ─────────────────────────────────────────────────────
function EnrichCard({ ev, idx, onChange }: {
  ev: ParsedEvent; idx: number; onChange: (idx: number, patch: Partial<ParsedEvent>) => void;
}) {
  const q = getQuality(ev);
  return (
    <div className="rounded-xl p-4 space-y-3"
      style={{ background: N.surface, border: `1px solid ${N.border}` }}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3 min-w-0">
          {ev.image ? (
            <img src={ev.image} alt="" className="w-10 h-10 rounded-lg object-cover flex-shrink-0" />
          ) : (
            <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: N.surface3 }}>
              <ImageIcon size={14} style={{ color: N.textMuted }} />
            </div>
          )}
          <div className="min-w-0">
            <p className="text-sm font-semibold truncate" style={{ color: N.text }}>{ev.title}</p>
            <p className="text-xs" style={{ color: N.textMuted }}>{ev.venueName} · {ev.district}</p>
          </div>
        </div>
        <span className="text-sm font-bold tabular-nums" style={{ color: q >= 70 ? N.green : N.orange }}>{q}%</span>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
        {/* Category */}
        <div>
          <label className="text-[10px] font-medium block mb-0.5" style={{ color: N.textMuted }}>Category</label>
          <select value={ev.category} onChange={e => onChange(idx, { category: e.target.value })}
            className="w-full rounded-lg px-2 py-1.5 text-xs outline-none"
            style={{ background: N.surface2, border: `1px solid ${N.border}`, color: N.text, fontFamily: N.font }}>
            {CULTIVE_CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
        {/* Status */}
        <div>
          <label className="text-[10px] font-medium block mb-0.5" style={{ color: N.textMuted }}>Status</label>
          <select value={ev.status} onChange={e => onChange(idx, { status: e.target.value as any })}
            className="w-full rounded-lg px-2 py-1.5 text-xs outline-none"
            style={{ background: N.surface2, border: `1px solid ${N.border}`, color: N.text, fontFamily: N.font }}>
            <option value="upcoming">upcoming</option>
            <option value="ongoing">ongoing</option>
            <option value="past">past</option>
          </select>
        </div>
        {/* Artists */}
        <div>
          <label className="text-[10px] font-medium block mb-0.5" style={{ color: N.textMuted }}>Artists (comma-separated)</label>
          <input type="text" value={ev.artists.join(', ')}
            onChange={e => onChange(idx, { artists: e.target.value.split(',').map(s => s.trim()).filter(Boolean) })}
            className="w-full px-2.5 py-1.5 text-xs rounded-lg outline-none"
            style={{ background: N.surface2, border: `1px solid ${N.border}`, color: N.text, fontFamily: N.font }} />
        </div>
      </div>

      {/* Mode tags */}
      <div>
        <label className="text-[10px] font-medium block mb-1" style={{ color: N.textMuted }}>Modes</label>
        <div className="flex gap-1 flex-wrap">
          {CULTIVE_MODES.map(m => {
            const active = ev.modeTags.includes(m.id);
            return (
              <button key={m.id}
                onClick={() => onChange(idx, {
                  modeTags: active ? ev.modeTags.filter(x => x !== m.id) : [...ev.modeTags, m.id],
                  modes: active ? ev.modes.filter(x => x !== m.id) : [...ev.modes, m.id],
                })}
                className="px-2 py-0.5 rounded text-[10px] font-semibold transition-all"
                style={{ background: active ? m.color : N.surface2, color: active ? '#fff' : N.textMuted, border: `1px solid ${active ? m.color : N.borderMid}` }}>
                {m.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Vibes */}
      <div>
        <label className="text-[10px] font-medium block mb-1" style={{ color: N.textMuted }}>Vibes</label>
        <div className="flex gap-1 flex-wrap">
          {VIBE_OPTIONS.map(v => {
            const active = ev.vibes?.includes(v);
            return (
              <button key={v}
                onClick={() => onChange(idx, {
                  vibes: active ? ev.vibes.filter(x => x !== v) : [...(ev.vibes || []), v],
                })}
                className="px-2 py-0.5 rounded text-[10px] font-medium transition-all"
                style={{ background: active ? N.apify : N.surface2, color: active ? '#fff' : N.textMuted, border: `1px solid ${active ? N.apify : N.border}` }}>
                {v}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ── Import History ───────────────────────────────────────────────────────────
function ImportHistory({ accessToken }: { accessToken: string | null }) {
  const [batches, setBatches] = useState<ImportBatch[]>([]);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    fetch(`${API_BASE}/events/bulk/history`, {
      headers: { Authorization: `Bearer ${publicAnonKey}` },
    }).then(r => r.json()).then(d => setBatches(d.batches || []))
      .catch(() => {});
  }, []);

  if (batches.length === 0) return null;

  return (
    <div className="mt-10">
      <button onClick={() => setOpen(o => !o)}
        className="flex items-center gap-2 text-xs font-semibold mb-3"
        style={{ color: N.textMuted }}>
        <History size={14} />{open ? 'Hide' : 'Show'} Import History ({batches.length})
        {open ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
      </button>
      {open && (
        <div className="space-y-2">
          {batches.map(b => (
            <div key={b.id} className="rounded-lg px-4 py-3 flex items-center justify-between"
              style={{ background: N.surface, border: `1px solid ${N.border}` }}>
              <div>
                <p className="text-xs font-semibold" style={{ color: N.text }}>{b.label || b.id}</p>
                <p className="text-[11px]" style={{ color: N.textMuted }}>
                  {new Date(b.timestamp).toLocaleDateString('en-HK', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-[11px] font-medium" style={{ color: N.green }}>{b.created} new</span>
                {(b.updated > 0) && <span className="text-[11px] font-medium" style={{ color: N.blue }}>{b.updated} updated</span>}
                {(b.invalid > 0) && <span className="text-[11px] font-medium" style={{ color: N.red }}>{b.invalid} invalid</span>}
                <span className="text-[11px] font-bold tabular-nums"
                  style={{ color: b.avgQuality >= 70 ? N.green : N.orange }}>{b.avgQuality}%</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// ── Main component ═══════════════════════════════════════════════════════════
// ═══════════════════════════════════════════════════════════════════════════════
type InputMode = 'paste' | 'dataset' | 'actor';

export function ApifyEventImport() {
  const { accessToken } = useOutletContext<{ accessToken: string }>();

  const [step, setStep]       = useState(1);
  const [inputMode, setInputMode] = useState<InputMode>('paste');
  const [pasteJson, setPasteJson] = useState('');
  const [datasetId, setDatasetId] = useState('');
  const [actorId, setActorId]     = useState('');
  const [actorInput, setActorInput] = useState('{}');

  const [loading, setLoading]     = useState(false);
  const [error, setError]         = useState('');
  const [events, setEvents]       = useState<ParsedEvent[]>([]);
  const [importing, setImporting] = useState(false);
  const [importResult, setImportResult] = useState<{ created: number; updated: number; invalid: number; avgQuality: number } | null>(null);
  const [importErr, setImportErr] = useState('');
  const [batchLabel, setBatchLabel] = useState('');

  // Run tracking
  const [runId, setRunId]         = useState('');
  const [runStatus, setRunStatus] = useState('');
  const [runDatasetId, setRunDatasetId] = useState('');
  const pollingRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Bulk-enrich controls (step 3)
  const [bulkCategory, setBulkCategory] = useState('');
  const [bulkModes, setBulkModes]       = useState<string[]>([]);
  const [bulkStatus, setBulkStatus]     = useState<'upcoming'|'ongoing'|'past'>('upcoming');

  // ── Paste JSON handler ─────────────────────────────────────────────────
  const handlePasteImport = useCallback(async () => {
    setLoading(true); setError('');
    try {
      let parsed: any;
      try { parsed = JSON.parse(pasteJson); } catch { throw new Error('Invalid JSON — check syntax'); }

      // Accept array or object with .items / .events / .data
      let items: any[];
      if (Array.isArray(parsed)) items = parsed;
      else if (parsed?.items) items = parsed.items;
      else if (parsed?.events) items = parsed.events;
      else if (parsed?.data) items = parsed.data;
      else if (parsed?.results) items = parsed.results;
      else items = [parsed];

      const res = await fetch(`${API_BASE}/apify/normalize`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${publicAnonKey}` },
        body: JSON.stringify({ items }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
      if (!data.events || data.events.length === 0) {
        setError('No events could be extracted from the JSON. Check the data format.');
        return;
      }
      setEvents(data.events);
      setBatchLabel(`Apify Import · ${new Date().toLocaleDateString('en-HK', { day: 'numeric', month: 'short', year: 'numeric' })}`);
      setStep(2);
    } catch (err) {
      setError(`Parse failed: ${(err as Error).message}`);
    } finally {
      setLoading(false);
    }
  }, [pasteJson]);

  // ── Dataset fetch handler ──────────────────────────────────────────────
  const handleDatasetFetch = useCallback(async () => {
    const id = datasetId.trim();
    if (!id) { setError('Enter a dataset ID'); return; }
    setLoading(true); setError('');
    try {
      const res = await fetch(`${API_BASE}/apify/dataset/${encodeURIComponent(id)}`, {
        headers: { Authorization: `Bearer ${publicAnonKey}` },
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
      if (!data.events || data.events.length === 0) {
        setError('Dataset is empty or events could not be extracted.');
        return;
      }
      setEvents(data.events);
      setBatchLabel(`Apify Dataset · ${new Date().toLocaleDateString('en-HK', { day: 'numeric', month: 'short', year: 'numeric' })}`);
      setStep(2);
    } catch (err) {
      setError(`Fetch failed: ${(err as Error).message}`);
    } finally {
      setLoading(false);
    }
  }, [datasetId]);

  // ── Actor run handler ──────────────────────────────────────────────────
  const handleActorRun = useCallback(async () => {
    if (!actorId.trim()) { setError('Enter an Actor ID or username/actor-name'); return; }
    setLoading(true); setError(''); setRunStatus(''); setRunId('');
    try {
      let input = {};
      try { input = JSON.parse(actorInput); } catch { /* empty default */ }

      const res = await fetch(`${API_BASE}/apify/run`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${publicAnonKey}` },
        body: JSON.stringify({ actorId: actorId.trim(), input }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
      setRunId(data.runId);
      setRunStatus(data.status || 'RUNNING');
      // Start polling
      startPolling(data.runId);
    } catch (err) {
      setError(`Actor run failed: ${(err as Error).message}`);
      setLoading(false);
    }
  }, [actorId, actorInput]);

  const startPolling = (rid: string) => {
    if (pollingRef.current) clearInterval(pollingRef.current);
    pollingRef.current = setInterval(async () => {
      try {
        const res = await fetch(`${API_BASE}/apify/run/${rid}`, {
          headers: { Authorization: `Bearer ${publicAnonKey}` },
        });
        const data = await res.json();
        setRunStatus(data.status || 'UNKNOWN');
        if (data.status === 'SUCCEEDED') {
          if (pollingRef.current) clearInterval(pollingRef.current);
          setRunDatasetId(data.defaultDatasetId || '');
          if (data.defaultDatasetId) {
            // Auto-fetch dataset
            setDatasetId(data.defaultDatasetId);
            const dsRes = await fetch(`${API_BASE}/apify/dataset/${data.defaultDatasetId}`, {
              headers: { Authorization: `Bearer ${publicAnonKey}` },
            });
            const dsData = await dsRes.json();
            if (dsData.events && dsData.events.length > 0) {
              setEvents(dsData.events);
              setBatchLabel(`Apify Run · ${new Date().toLocaleDateString('en-HK', { day: 'numeric', month: 'short', year: 'numeric' })}`);
              setStep(2);
            } else {
              setError('Actor finished but no events were extracted from the output.');
            }
          }
          setLoading(false);
        } else if (data.status === 'FAILED' || data.status === 'ABORTED' || data.status === 'TIMED-OUT') {
          if (pollingRef.current) clearInterval(pollingRef.current);
          setError(`Actor run ${data.status.toLowerCase()}. Check Apify console for details.`);
          setLoading(false);
        }
      } catch {
        // Ignore polling errors
      }
    }, 3000);
  };

  useEffect(() => {
    return () => { if (pollingRef.current) clearInterval(pollingRef.current); };
  }, []);

  // ── Event handlers ─────────────────────────────────────────────────────
  const handleChange = useCallback((idx: number, patch: Partial<ParsedEvent>) => {
    setEvents(evs => evs.map((e, i) => i === idx ? { ...e, ...patch } : e));
  }, []);
  const handleRemove = useCallback((idx: number) => {
    setEvents(evs => evs.filter((_, i) => i !== idx));
  }, []);

  const applyBulk = () => {
    setEvents(evs => evs.map(ev => {
      if (!ev.selected) return ev;
      const patch: Partial<ParsedEvent> = { status: bulkStatus };
      if (bulkCategory) patch.category = bulkCategory;
      if (bulkModes.length > 0) { patch.modeTags = bulkModes; patch.modes = bulkModes; }
      return { ...ev, ...patch };
    }));
  };

  const selectedEvents = events.filter(e => e.selected);
  const avgQualityPreview = selectedEvents.length > 0
    ? Math.round(selectedEvents.reduce((s, e) => s + getQuality(e), 0) / selectedEvents.length)
    : 0;

  const handleImport = useCallback(async () => {
    if (selectedEvents.length === 0) return;
    setImporting(true); setImportErr('');
    try {
      const payload = selectedEvents.map(({ selected, tags, ...rest }) => rest);
      const res = await fetch(`${API_BASE}/events/bulk`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${publicAnonKey}` },
        body: JSON.stringify({ events: payload, batchMeta: { label: batchLabel } }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
      setImportResult({ created: data.created, updated: data.updated || 0, invalid: data.invalid || 0, avgQuality: data.avgQuality });
      setStep(4);
      fireWebhook('bulk_import.completed', {
        source: 'apify', batchLabel, created: data.created,
        updated: data.updated || 0, invalid: data.invalid || 0,
      });
    } catch (err) {
      setImportErr(`Import failed: ${(err as Error).message}`);
    } finally {
      setImporting(false);
    }
  }, [selectedEvents, batchLabel]);

  const handleReset = () => {
    setStep(1); setError(''); setEvents([]); setImportResult(null); setImportErr('');
    setBatchLabel(''); setBulkCategory(''); setBulkModes([]); setBulkStatus('upcoming');
    setPasteJson(''); setDatasetId(''); setRunId(''); setRunStatus('');
    if (pollingRef.current) clearInterval(pollingRef.current);
  };

  // ─── Actor code template ───────────────────────────────────────────────
  const ACTOR_CODE = `// CULTIVE HK Events Apify Actor
// Deploy this on Apify to scrape events for the CULTIVE platform.
// Output format matches CULTIVE's import pipeline exactly.

import { CheerioCrawler, Dataset } from '@crawlee/cheerio';
import { Actor } from 'apify';

await Actor.init();

const {
  startUrls = ['https://www.lifestyleasia.com/hk/whats-on/events-whats-on/'],
  maxRequestsPerCrawl = 200,
} = (await Actor.getInput()) ?? {};

const proxyConfiguration = await Actor.createProxyConfiguration();

const crawler = new CheerioCrawler({
  proxyConfiguration,
  maxRequestsPerCrawl,
  async requestHandler({ request, $, log }) {
    log.info(\`Scraping: \${request.url}\`);

    // Adapt selectors per target site — this example handles LSA-style pages
    const events = [];

    // Try common event listing patterns
    $('article, .post-item, .event-card, [class*="event"], [class*="listing"]').each((i, el) => {
      const $el = $(el);
      const title = $el.find('h2, h3, .title, .event-title').first().text().trim();
      if (!title || title.length < 3) return;

      const link = $el.find('a').first().attr('href') || '';
      const image = $el.find('img').first().attr('src') || $el.find('img').first().attr('data-src') || '';
      const dateText = $el.find('[class*="date"], time, .meta').first().text().trim();
      const venue = $el.find('[class*="venue"], [class*="location"]').first().text().trim();
      const description = $el.find('p, .excerpt, .description').first().text().trim();
      const price = $el.find('[class*="price"], [class*="cost"]').first().text().trim();

      events.push({
        title,
        date: dateText,
        venueName: venue,
        description,
        image: image.startsWith('http') ? image : \`https://\${new URL(request.url).host}\${image}\`,
        price: price || '',
        sourceUrl: link.startsWith('http') ? link : \`https://\${new URL(request.url).host}\${link}\`,
        url: request.url,
        // CULTIVE will auto-detect: district, modes, category
      });
    });

    if (events.length > 0) {
      await Dataset.pushData(events);
      log.info(\`Extracted \${events.length} events from \${request.url}\`);
    } else {
      log.warning(\`No events found on \${request.url}\`);
    }
  },
});

await crawler.run(startUrls);
await Actor.exit();`;

  return (
    <div className="min-h-screen p-6 md:p-10" style={{ background: N.pageBg, fontFamily: N.font }}>
      <div className="max-w-3xl mx-auto">

        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-1">
            <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: N.apify }}>
              <Box size={18} color="#fff" />
            </div>
            <div>
              <h1 className="text-xl font-bold" style={{ color: N.text }}>Apify Event Import</h1>
              <p className="text-xs" style={{ color: N.textMuted }}>Import scraped events from Apify actors, datasets, or pasted JSON</p>
            </div>
          </div>
        </div>

        <Steps step={step} />

        {/* ── STEP 1: Configure ─────────────────────────────────────── */}
        {step === 1 && (
          <motion.div key="s1" initial={{ opacity: 0, x: -16 }} animate={{ opacity: 1, x: 0 }}>
            {/* Info box */}
            <div className="rounded-xl p-4 mb-5 flex items-start gap-3"
              style={{ background: N.apifyBg, border: `1px solid rgba(255,109,0,0.2)` }}>
              <Box size={15} className="flex-shrink-0 mt-0.5" style={{ color: N.apify }} />
              <div>
                <p className="text-xs font-semibold mb-1" style={{ color: N.apify }}>How it works</p>
                <ul className="text-xs space-y-0.5" style={{ color: N.apify }}>
                  <li>1. Paste Apify actor output JSON, fetch from a dataset ID, or run an actor directly</li>
                  <li>2. Server normalizes any JSON shape into CULTIVE event format (auto-detects field names)</li>
                  <li>3. Review, enrich with modes/vibes/categories, and import — same flow as RA & LSA</li>
                  <li>4. Events appear on the site, map, and events page with "Apify" source badges</li>
                </ul>
              </div>
            </div>

            {/* Input mode tabs */}
            <div className="flex gap-1 mb-5 p-1 rounded-xl" style={{ background: N.surface2 }}>
              {[
                { id: 'paste' as InputMode, label: 'Paste JSON', icon: Clipboard },
                { id: 'dataset' as InputMode, label: 'Dataset ID', icon: Database },
                { id: 'actor' as InputMode, label: 'Run Actor', icon: Play },
              ].map(tab => (
                <button key={tab.id}
                  onClick={() => { setInputMode(tab.id); setError(''); }}
                  className="flex-1 flex items-center justify-center gap-2 px-3 py-2.5 rounded-lg text-xs font-semibold transition-all"
                  style={{
                    background: inputMode === tab.id ? N.surface : 'transparent',
                    color: inputMode === tab.id ? N.apify : N.textMuted,
                    boxShadow: inputMode === tab.id ? '0 1px 3px rgba(0,0,0,0.08)' : 'none',
                  }}>
                  <tab.icon size={14} />{tab.label}
                </button>
              ))}
            </div>

            {/* Paste JSON mode */}
            {inputMode === 'paste' && (
              <div className="space-y-3">
                <div>
                  <label className="text-xs font-semibold mb-1.5 block" style={{ color: N.textMuted }}>
                    Apify Actor Output JSON
                  </label>
                  <textarea
                    value={pasteJson}
                    onChange={e => setPasteJson(e.target.value)}
                    rows={10}
                    placeholder={`Paste JSON array or object with events...\n\n[\n  {\n    "title": "Art Basel HK 2026",\n    "date": "2026-03-27",\n    "venue": "HKCEC",\n    "description": "...",\n    "image": "https://...",\n    "price": "HK$250"\n  }\n]`}
                    className="w-full rounded-xl px-4 py-3 text-xs outline-none font-mono resize-none"
                    style={{ background: N.surface, border: `1px solid ${N.borderMid}`, color: N.text, fontFamily: "'JetBrains Mono', monospace" }}
                  />
                  <p className="text-[10px] mt-1" style={{ color: N.textMuted }}>
                    Accepts arrays, or objects with <code>items</code>, <code>events</code>, <code>data</code>, or <code>results</code> keys.
                    Field names are auto-mapped (title/name, venue/venueName/place, date/startDate, etc.)
                  </p>
                </div>
                <button onClick={handlePasteImport} disabled={loading || !pasteJson.trim()}
                  className="flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-semibold hover:opacity-90 transition-opacity disabled:opacity-40"
                  style={{ background: N.apify, color: '#fff' }}>
                  {loading
                    ? <><Loader2 size={15} className="animate-spin" />Processing...</>
                    : <><FileJson size={15} />Parse & Normalize<ArrowRight size={15} /></>
                  }
                </button>
              </div>
            )}

            {/* Dataset ID mode */}
            {inputMode === 'dataset' && (
              <div className="space-y-3">
                <div>
                  <label className="text-xs font-semibold mb-1.5 block" style={{ color: N.textMuted }}>
                    Apify Dataset ID
                  </label>
                  <input type="text" value={datasetId} onChange={e => setDatasetId(e.target.value)}
                    placeholder="e.g. 3kWlAo2OFgQbXRZhX"
                    className="w-full rounded-xl px-4 py-2.5 text-sm outline-none font-mono"
                    style={{ background: N.surface, border: `1px solid ${N.borderMid}`, color: N.text }} />
                  <p className="text-[10px] mt-1" style={{ color: N.textMuted }}>
                    Find this in Apify Console → your actor run → Dataset tab. We'll fetch all items and normalize them.
                  </p>
                </div>
                <button onClick={handleDatasetFetch} disabled={loading || !datasetId.trim()}
                  className="flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-semibold hover:opacity-90 transition-opacity disabled:opacity-40"
                  style={{ background: N.apify, color: '#fff' }}>
                  {loading
                    ? <><Loader2 size={15} className="animate-spin" />Fetching...</>
                    : <><CloudDownload size={15} />Fetch Dataset<ArrowRight size={15} /></>
                  }
                </button>
              </div>
            )}

            {/* Run Actor mode */}
            {inputMode === 'actor' && (
              <div className="space-y-3">
                <div>
                  <label className="text-xs font-semibold mb-1.5 block" style={{ color: N.textMuted }}>
                    Actor ID or username/actor-name
                  </label>
                  <input type="text" value={actorId} onChange={e => setActorId(e.target.value)}
                    placeholder="e.g. your-username/cultive-hk-scraper"
                    className="w-full rounded-xl px-4 py-2.5 text-sm outline-none font-mono"
                    style={{ background: N.surface, border: `1px solid ${N.borderMid}`, color: N.text }} />
                </div>
                <div>
                  <label className="text-xs font-semibold mb-1.5 block" style={{ color: N.textMuted }}>
                    Actor Input (JSON)
                  </label>
                  <textarea value={actorInput} onChange={e => setActorInput(e.target.value)}
                    rows={4}
                    placeholder='{"startUrls": ["https://..."], "maxRequestsPerCrawl": 200}'
                    className="w-full rounded-xl px-4 py-3 text-xs outline-none font-mono resize-none"
                    style={{ background: N.surface, border: `1px solid ${N.borderMid}`, color: N.text }} />
                </div>
                <button onClick={handleActorRun} disabled={loading || !actorId.trim()}
                  className="flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-semibold hover:opacity-90 transition-opacity disabled:opacity-40"
                  style={{ background: N.apify, color: '#fff' }}>
                  {loading
                    ? <><Loader2 size={15} className="animate-spin" />Running...</>
                    : <><Play size={15} />Run Actor<ArrowRight size={15} /></>
                  }
                </button>

                {/* Run status */}
                {runId && (
                  <div className="rounded-xl p-4 mt-3" style={{ background: N.surface, border: `1px solid ${N.border}` }}>
                    <div className="flex items-center gap-3 mb-3">
                      <Activity size={16} style={{ color: N.apify }} />
                      <div>
                        <p className="text-sm font-semibold" style={{ color: N.text }}>Actor Run: {runId.slice(0, 12)}...</p>
                        <p className="text-xs" style={{ color: N.textMuted }}>
                          Status: <span className="font-bold" style={{
                            color: runStatus === 'SUCCEEDED' ? N.green :
                              runStatus === 'RUNNING' ? N.apify :
                              runStatus === 'FAILED' ? N.red : N.textMuted
                          }}>{runStatus}</span>
                        </p>
                      </div>
                    </div>
                    {(runStatus === 'RUNNING' || runStatus === 'READY') && (
                      <div className="flex items-center gap-2">
                        <Loader2 size={14} className="animate-spin" style={{ color: N.apify }} />
                        <span className="text-xs" style={{ color: N.textMuted }}>Polling every 3s... waiting for actor to finish</span>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* Actor template */}
            <div className="mt-6">
              <details>
                <summary className="text-xs font-semibold cursor-pointer mb-2 flex items-center gap-2" style={{ color: N.textMuted }}>
                  <FileJson size={13} /> View CULTIVE Apify Actor Template
                </summary>
                <div className="rounded-xl overflow-hidden" style={{ border: `1px solid ${N.border}` }}>
                  <div className="px-4 py-2 flex items-center justify-between" style={{ background: N.surface3 }}>
                    <span className="text-[10px] font-semibold" style={{ color: N.textMuted }}>src/main.ts</span>
                    <button onClick={() => navigator.clipboard.writeText(ACTOR_CODE)}
                      className="text-[10px] px-2 py-1 rounded font-medium"
                      style={{ background: N.surface, color: N.apify }}>
                      Copy
                    </button>
                  </div>
                  <pre className="px-4 py-3 text-[11px] overflow-auto max-h-64" style={{ background: N.surface, color: N.text, fontFamily: "'JetBrains Mono', monospace" }}>
                    {ACTOR_CODE}
                  </pre>
                </div>
              </details>
            </div>

            {/* Field mapping reference */}
            <div className="mt-4">
              <details>
                <summary className="text-xs font-semibold cursor-pointer mb-2 flex items-center gap-2" style={{ color: N.textMuted }}>
                  <Tag size={13} /> Field Mapping Reference
                </summary>
                <div className="rounded-xl p-4 text-xs space-y-1" style={{ background: N.surface, border: `1px solid ${N.border}`, color: N.textMuted }}>
                  <p><strong style={{ color: N.text }}>title</strong> ← title | name | eventTitle</p>
                  <p><strong style={{ color: N.text }}>date</strong> ← date | startDate | eventDate</p>
                  <p><strong style={{ color: N.text }}>time</strong> ← time | startTime</p>
                  <p><strong style={{ color: N.text }}>venueName</strong> ← venueName | venue | locationName | place</p>
                  <p><strong style={{ color: N.text }}>description</strong> ← description | text | content | summary</p>
                  <p><strong style={{ color: N.text }}>image</strong> ← image | imageUrl | photo | thumbnail | flyerFront</p>
                  <p><strong style={{ color: N.text }}>price</strong> ← price | cost | ticketPrice</p>
                  <p><strong style={{ color: N.text }}>address</strong> ← address | location | fullAddress</p>
                  <p><strong style={{ color: N.text }}>lat/lng</strong> ← lat/lng | latitude/longitude | geo.lat/geo.lng | coordinates.lat/coordinates.lng</p>
                  <p><strong style={{ color: N.text }}>artists</strong> ← artists (array or comma-separated string)</p>
                  <p className="pt-2 italic">District, modes, and categories are auto-detected from content if not provided.</p>
                </div>
              </details>
            </div>

            {error && (
              <div className="rounded-lg px-4 py-3 mt-4 flex items-start gap-2"
                style={{ background: N.redBg, border: `1px solid rgba(220,38,38,0.2)` }}>
                <AlertCircle size={15} className="flex-shrink-0 mt-0.5" style={{ color: N.red }} />
                <p className="text-sm" style={{ color: N.red }}>{error}</p>
              </div>
            )}
          </motion.div>
        )}

        {/* ── STEP 2: Review & Edit ─────────────────────────────────── */}
        {step === 2 && (
          <motion.div key="s2" initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }}>
            <div className="rounded-xl px-4 py-3 mb-4 flex items-center justify-between"
              style={{ background: N.surface, border: `1px solid ${N.border}` }}>
              <div className="flex items-center gap-4">
                <span className="text-sm font-semibold" style={{ color: N.text }}>{events.length} extracted</span>
                <span className="text-sm" style={{ color: N.apify }}>{selectedEvents.length} selected</span>
              </div>
              <div className="flex gap-2">
                <button onClick={() => setEvents(evs => evs.map(e => ({ ...e, selected: true })))}
                  className="text-xs px-3 py-1 rounded-lg" style={{ background: N.surface2, color: N.textMuted }}>Select all</button>
                <button onClick={() => setEvents(evs => evs.map(e => ({ ...e, selected: false })))}
                  className="text-xs px-3 py-1 rounded-lg" style={{ background: N.surface2, color: N.textMuted }}>None</button>
              </div>
            </div>

            <div className="flex flex-col gap-3 mb-6">
              <AnimatePresence initial={false}>
                {events.map((ev, idx) => (
                  <EventCard key={ev.id + idx} ev={ev} idx={idx} onChange={handleChange} onRemove={handleRemove} />
                ))}
              </AnimatePresence>
            </div>

            <div className="flex gap-3">
              <button onClick={() => setStep(1)}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold transition"
                style={{ background: N.surface2, color: N.text, border: `1px solid ${N.border}` }}>
                <ArrowLeft size={15} />Back
              </button>
              <button onClick={() => setStep(3)} disabled={selectedEvents.length === 0}
                className="flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-semibold hover:opacity-90 transition-opacity disabled:opacity-40"
                style={{ background: N.apify, color: '#fff' }}>
                Enrich {selectedEvents.length} event{selectedEvents.length !== 1 ? 's' : ''}<ArrowRight size={15} />
              </button>
            </div>
          </motion.div>
        )}

        {/* ── STEP 3: Enrich ───────────────────────────────────────── */}
        {step === 3 && (
          <motion.div key="s3" initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }}>
            {/* Quality overview */}
            <div className="rounded-xl p-4 mb-5 flex items-center gap-6"
              style={{ background: N.surface, border: `1px solid ${N.border}` }}>
              <div className="flex-1">
                <p className="text-xs font-semibold mb-2" style={{ color: N.textMuted }}>Average quality score</p>
                <QualityBar value={avgQualityPreview} />
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold tabular-nums" style={{ color: avgQualityPreview >= 70 ? N.green : N.orange }}>
                  {avgQualityPreview}%
                </p>
                <p className="text-xs" style={{ color: N.textMuted }}>{selectedEvents.length} events</p>
              </div>
            </div>

            {/* Bulk apply bar */}
            <div className="rounded-xl p-4 mb-5" style={{ background: N.purpleBg, border: `1px solid rgba(124,58,237,0.15)` }}>
              <div className="flex items-center gap-2 mb-3">
                <Zap size={14} style={{ color: N.purple }} />
                <p className="text-xs font-semibold" style={{ color: N.purple }}>Bulk apply to all selected events</p>
              </div>
              <div className="flex flex-wrap gap-3 items-end">
                <div className="flex flex-col gap-1">
                  <label className="text-xs" style={{ color: N.purple }}>Category</label>
                  <select value={bulkCategory} onChange={e => setBulkCategory(e.target.value)}
                    className="rounded-lg px-3 py-1.5 text-xs outline-none"
                    style={{ background: N.surface, border: `1px solid rgba(124,58,237,0.3)`, color: N.text, fontFamily: N.font }}>
                    <option value="">-- keep individual --</option>
                    {CULTIVE_CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-xs" style={{ color: N.purple }}>Status</label>
                  <select value={bulkStatus} onChange={e => setBulkStatus(e.target.value as any)}
                    className="rounded-lg px-3 py-1.5 text-xs outline-none"
                    style={{ background: N.surface, border: `1px solid rgba(124,58,237,0.3)`, color: N.text, fontFamily: N.font }}>
                    <option value="upcoming">upcoming</option>
                    <option value="ongoing">ongoing</option>
                    <option value="past">past</option>
                  </select>
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-xs" style={{ color: N.purple }}>Add Modes</label>
                  <div className="flex gap-1">
                    {CULTIVE_MODES.map(m => {
                      const active = bulkModes.includes(m.id);
                      return (
                        <button key={m.id} onClick={() => setBulkModes(prev => active ? prev.filter(x => x !== m.id) : [...prev, m.id])}
                          className="px-2 py-1 rounded text-[11px] font-semibold transition-all"
                          style={{ background: active ? m.color : N.surface, color: active ? '#fff' : N.textMuted, border: `1px solid ${active ? m.color : N.borderMid}` }}>
                          {m.label}
                        </button>
                      );
                    })}
                  </div>
                </div>
                <button onClick={applyBulk}
                  className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-xs font-semibold transition"
                  style={{ background: N.purple, color: '#fff' }}>
                  <ListChecks size={12} />Apply to all
                </button>
              </div>
            </div>

            {/* Batch label */}
            <div className="mb-4">
              <label className="text-xs font-semibold mb-1 block" style={{ color: N.textMuted }}>Import label</label>
              <input type="text" placeholder="e.g. Apify HK Events March 2026"
                value={batchLabel} onChange={e => setBatchLabel(e.target.value)}
                className="w-full rounded-xl px-4 py-2.5 text-sm outline-none"
                style={{ background: N.surface, border: `1px solid ${N.borderMid}`, color: N.text }} />
            </div>

            {/* Per-event enrich cards */}
            <div className="flex flex-col gap-3 mb-6">
              {selectedEvents.map(ev => {
                const realIdx = events.findIndex(e => e.id === ev.id);
                return <EnrichCard key={ev.id} ev={ev} idx={realIdx} onChange={handleChange} />;
              })}
            </div>

            {importErr && (
              <div className="rounded-lg px-4 py-3 mb-4 flex items-start gap-2"
                style={{ background: N.redBg, border: `1px solid rgba(220,38,38,0.2)` }}>
                <AlertCircle size={15} className="flex-shrink-0 mt-0.5" style={{ color: N.red }} />
                <p className="text-sm" style={{ color: N.red }}>{importErr}</p>
              </div>
            )}

            <div className="flex gap-3">
              <button onClick={() => setStep(2)}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold transition"
                style={{ background: N.surface2, color: N.text, border: `1px solid ${N.border}` }}>
                <ArrowLeft size={15} />Back
              </button>
              <button onClick={handleImport} disabled={importing}
                className="flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-semibold hover:opacity-90 transition-opacity disabled:opacity-40"
                style={{ background: N.apify, color: '#fff' }}>
                {importing
                  ? <><Loader2 size={15} className="animate-spin" />Importing...</>
                  : <><Download size={15} />Import {selectedEvents.length} event{selectedEvents.length !== 1 ? 's' : ''}<ArrowRight size={15} /></>
                }
              </button>
            </div>
          </motion.div>
        )}

        {/* ── STEP 4: Done ──────────────────────────────────────────── */}
        {step === 4 && importResult && (
          <motion.div key="s4" initial={{ opacity: 0, scale: 0.97 }} animate={{ opacity: 1, scale: 1 }}
            className="text-center py-10">
            <div className="w-16 h-16 rounded-full mx-auto mb-6 flex items-center justify-center" style={{ background: N.apifyBg }}>
              <CheckCircle2 size={32} style={{ color: N.apify }} />
            </div>
            <h2 className="text-2xl font-bold mb-2" style={{ color: N.text }}>Import Complete</h2>
            <p className="mb-6" style={{ color: N.textMuted }}>Apify events saved to CULTIVE and will appear on the site immediately.</p>
            <div className="flex gap-3 justify-center flex-wrap mb-8">
              {importResult.created > 0 && (
                <div className="rounded-2xl px-7 py-4 text-center" style={{ background: N.greenBg, border: `1px solid rgba(22,163,74,0.2)` }}>
                  <p className="text-3xl font-bold" style={{ color: N.green }}>{importResult.created}</p>
                  <p className="text-xs font-medium mt-1" style={{ color: N.green }}>New</p>
                </div>
              )}
              {importResult.updated > 0 && (
                <div className="rounded-2xl px-7 py-4 text-center" style={{ background: N.blueBg, border: `1px solid rgba(37,99,235,0.2)` }}>
                  <p className="text-3xl font-bold" style={{ color: N.blue }}>{importResult.updated}</p>
                  <p className="text-xs font-medium mt-1" style={{ color: N.blue }}>Updated</p>
                </div>
              )}
              {importResult.invalid > 0 && (
                <div className="rounded-2xl px-7 py-4 text-center" style={{ background: N.redBg, border: `1px solid rgba(220,38,38,0.15)` }}>
                  <p className="text-3xl font-bold" style={{ color: N.red }}>{importResult.invalid}</p>
                  <p className="text-xs font-medium mt-1" style={{ color: N.red }}>Invalid</p>
                </div>
              )}
              <div className="rounded-2xl px-7 py-4 text-center"
                style={{ background: (importResult.avgQuality >= 70 ? N.greenBg : N.orangeBg), border: `1px solid ${importResult.avgQuality >= 70 ? 'rgba(22,163,74,0.2)' : 'rgba(234,88,12,0.2)'}` }}>
                <p className="text-3xl font-bold" style={{ color: importResult.avgQuality >= 70 ? N.green : N.orange }}>{importResult.avgQuality}%</p>
                <p className="text-xs font-medium mt-1" style={{ color: importResult.avgQuality >= 70 ? N.green : N.orange }}>Avg Quality</p>
              </div>
            </div>
            {importResult.created === 0 && importResult.updated === 0 && (
              <div className="rounded-xl px-5 py-4 mb-6 text-sm" style={{ background: N.orangeBg, border: `1px solid rgba(234,88,12,0.2)`, color: N.orange }}>
                No events were saved. Check that each event has a valid id and title.
              </div>
            )}
            <div className="flex gap-3 justify-center">
              <button onClick={handleReset}
                className="flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-semibold transition"
                style={{ background: N.surface2, color: N.text, border: `1px solid ${N.border}` }}>
                <RotateCcw size={15} />Import more
              </button>
              <a href="/admin/events"
                className="flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-semibold hover:opacity-90 transition-opacity"
                style={{ background: N.apify, color: '#fff' }}>
                Event Manager<ArrowRight size={15} />
              </a>
              <a href="/events"
                className="flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-semibold hover:opacity-90 transition-opacity"
                style={{ background: N.surface2, color: N.text, border: `1px solid ${N.border}` }}>
                View Events<ExternalLink size={15} />
              </a>
            </div>
          </motion.div>
        )}

        {/* ── Import History ────────────────────────────────────────── */}
        <ImportHistory accessToken={accessToken} />
      </div>
    </div>
  );
}
