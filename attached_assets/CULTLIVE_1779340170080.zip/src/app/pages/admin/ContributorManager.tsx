import { useState, useEffect } from 'react';
import { useOutletContext } from 'react-router';
import { motion } from 'motion/react';
import { Users, Calendar, Inbox, Loader2 } from 'lucide-react';
import { fetchContributors } from '../../hooks/useAdminApi';

const N = {
  pageBg: '#FAFAF8',
  surface: '#FFFFFF',
  border: 'rgba(0,0,0,0.06)',
  text: '#1A1A1A',
  textSecondary: '#5A5A5A',
  textMuted: '#9A9A9A',
  blue: '#2563EB',
  blueBg: 'rgba(37,99,235,0.05)',
  font: "'Inter', 'Noto Sans HK', system-ui, sans-serif",
};

export function ContributorManager() {
  const { accessToken } = useOutletContext<{ accessToken: string }>();
  const [contributors, setContributors] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!accessToken) return;
    fetchContributors(accessToken)
      .then(data => setContributors(data.contributors || []))
      .catch(err => console.log('Failed to load contributors:', err))
      .finally(() => setLoading(false));
  }, [accessToken]);

  return (
    <div className="p-5 sm:p-8 lg:p-10 max-w-[1100px] mx-auto" style={{ fontFamily: N.font }}>
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
        <p className="text-[11px] font-medium uppercase tracking-wider mb-1.5"
          style={{ color: N.textMuted }}>Community</p>
        <h1 className="text-[1.5rem] font-semibold tracking-tight" style={{ color: N.text }}>
          Contributors
        </h1>
        <p className="mt-1 text-[15px]" style={{ color: N.textMuted }}>
          People who have submitted events to the platform.
        </p>
      </motion.div>

      {loading ? (
        <div className="flex items-center justify-center py-16">
          <Loader2 size={20} className="animate-spin" style={{ color: N.textMuted }} />
        </div>
      ) : contributors.length === 0 ? (
        <div className="text-center py-16" style={{
          backgroundColor: N.surface, borderRadius: '16px', border: `1px solid ${N.border}`,
        }}>
          <Users size={24} style={{ color: N.textMuted }} className="mx-auto mb-2 opacity-40" />
          <p className="text-[14px]" style={{ color: N.textMuted }}>No contributors yet</p>
          <p className="text-[12px] mt-1" style={{ color: N.textMuted }}>
            Contributors appear here after their first submission.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {contributors.map((con: any, i: number) => (
            <motion.div
              key={con.id || i}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.04 }}
              className="p-5"
              style={{ backgroundColor: N.surface, border: `1px solid ${N.border}`, borderRadius: '14px' }}
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="w-9 h-9 flex items-center justify-center rounded-full"
                  style={{ backgroundColor: 'rgba(0,0,0,0.04)' }}>
                  <span className="text-[13px] font-semibold" style={{ color: N.text }}>
                    {(con.name || 'A').charAt(0).toUpperCase()}
                  </span>
                </div>
                <div className="min-w-0">
                  <p className="text-[14px] font-medium truncate" style={{ color: N.text }}>
                    {con.name || 'Anonymous'}
                  </p>
                  <p className="text-[12px] truncate" style={{ color: N.textMuted }}>{con.email}</p>
                </div>
              </div>

              <div className="h-px mb-3" style={{ backgroundColor: N.border }} />

              <div className="flex items-center justify-between text-[12px]" style={{ color: N.textSecondary }}>
                <div className="flex items-center gap-1.5">
                  <Inbox size={12} style={{ color: N.textMuted }} />
                  <span>{con.submissionCount || 0} submission{con.submissionCount !== 1 ? 's' : ''}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Calendar size={12} style={{ color: N.textMuted }} />
                  <span>{new Date(con.firstSubmission).toLocaleDateString()}</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
