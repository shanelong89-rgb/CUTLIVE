/**
 * BulkImport — Multi-step venue import from Google Places
 * Step 1: Paste venue names
 * Step 2: Google Places lookup (with progress)
 * Step 3: Review, sort, edit each venue
 * Step 4: Confirm & save to CMS
 */
import { useState, useCallback, useRef } from 'react';
import { useOutletContext } from 'react-router';
import { motion, AnimatePresence } from 'motion/react';
import {
  Upload, Search, Check, ChevronRight, ChevronDown, ChevronUp,
  Loader2, MapPin, Star, ExternalLink, Trash2,
  AlertCircle, CheckCircle2, ArrowUpDown, Eye, Save, X,
  Globe, Phone, Clock, DollarSign, Tag, Link2, FileUp, Filter,
} from 'lucide-react';
import { projectId, publicAnonKey } from '../../config/supabase';
import { ImageWithFallback } from '../../components/figma/ImageWithFallback';

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-d507b98c`;
const CMS_BASE = `${API_BASE}/cms`;

// ─── Design tokens ───
const N = {
  pageBg: '#FAFAF8',
  surface: '#FFFFFF',
  surfaceMuted: '#F3F3F0',
  border: 'rgba(0,0,0,0.06)',
  borderFocus: 'rgba(0,0,0,0.15)',
  text: '#1A1A1A',
  textSecondary: '#5A5A5A',
  textMuted: '#9A9A9A',
  dark: '#1A1A1A',
  green: '#16A34A',
  greenBg: 'rgba(22,163,74,0.08)',
  amber: '#D97706',
  amberBg: 'rgba(217,119,6,0.08)',
  red: '#DC2626',
  redBg: 'rgba(220,38,38,0.05)',
  blue: '#2563EB',
  blueBg: 'rgba(37,99,235,0.06)',
  purple: '#7C3AED',
  purpleBg: 'rgba(124,58,237,0.06)',
  font: "'Inter', 'Noto Sans HK', system-ui, sans-serif",
};

function authHeaders(accessToken: string) {
  return {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${publicAnonKey}`,
    'X-Auth-Token': accessToken,
  };
}

// ─── Google types → CULTIVE category mapping ───
const TYPE_TO_CATEGORY: Record<string, string> = {
  bar: 'bar', night_club: 'club', restaurant: 'restaurant', cafe: 'cafe',
  museum: 'museum', art_gallery: 'gallery', gym: 'fitness', park: 'outdoor',
  shopping_mall: 'retail', store: 'retail', book_store: 'bookstore',
  movie_theater: 'cinema', spa: 'wellness', bakery: 'cafe',
  tourist_attraction: 'attraction', stadium: 'venue', church: 'heritage',
  hindu_temple: 'heritage', synagogue: 'heritage', mosque: 'heritage',
  library: 'library', university: 'education', school: 'education',
  lodging: 'hotel', food: 'restaurant', meal_delivery: 'restaurant',
  meal_takeaway: 'restaurant', clothing_store: 'retail',
};

const TYPE_TO_SUBCATEGORY: Record<string, string> = {
  bar: 'cocktail-bar', night_club: 'nightclub', cafe: 'specialty-coffee',
  bakery: 'bakery-cafe', art_gallery: 'contemporary', museum: 'cultural',
  gym: 'gym', spa: 'day-spa', restaurant: 'dining', park: 'park',
  book_store: 'bookshop', movie_theater: 'arthouse',
};

function inferCategory(types: string[]): { category: string; subcategory: string } {
  for (const t of types) {
    if (TYPE_TO_CATEGORY[t]) {
      return {
        category: TYPE_TO_CATEGORY[t],
        subcategory: TYPE_TO_SUBCATEGORY[t] || '',
      };
    }
  }
  return { category: 'venue', subcategory: '' };
}

function inferModeScores(types: string[], priceLevel?: number): Record<string, number> {
  const scores: Record<string, number> = {};
  const hasNight = types.some(t => ['bar', 'night_club'].includes(t));
  const hasArt = types.some(t => ['art_gallery', 'museum'].includes(t));
  const hasFood = types.some(t => ['restaurant', 'cafe', 'bakery', 'food'].includes(t));
  const hasFamily = types.some(t => ['park', 'museum', 'tourist_attraction', 'zoo', 'amusement_park'].includes(t));
  const hasLifestyle = types.some(t => ['gym', 'spa', 'yoga', 'book_store', 'shopping_mall'].includes(t));

  if (hasNight) scores.degen = 0.8;
  if (hasArt) scores.artsy = 0.8;
  if (hasFood) scores.foodie = 0.8;
  if (hasFamily) scores.family = 0.6;
  if (hasLifestyle) scores.lifestyle = 0.7;

  // Price level adjustments
  if (priceLevel !== undefined && priceLevel >= 3) {
    scores.degen = Math.max(scores.degen || 0, 0.6);
  }

  // Default: give moderate lifestyle score
  if (Object.keys(scores).length === 0) {
    scores.lifestyle = 0.5;
  }

  return scores;
}

function inferVibeTags(types: string[], rating?: number): string[] {
  const tags: string[] = [];
  if (types.includes('bar')) tags.push('drinks');
  if (types.includes('night_club')) tags.push('nightlife', 'music');
  if (types.includes('restaurant')) tags.push('dining');
  if (types.includes('cafe')) tags.push('coffee');
  if (types.includes('art_gallery') || types.includes('museum')) tags.push('cultural');
  if (types.includes('park')) tags.push('outdoor', 'scenic');
  if (types.includes('gym') || types.includes('spa')) tags.push('wellness');
  if (rating && rating >= 4.5) tags.push('top-rated');
  return tags;
}

// ─── Types ───
interface PlaceResult {
  name: string;
  address: string;
  lat: number;
  lng: number;
  district: string;
  types: string[];
  rating?: number;
  userRatingsTotal?: number;
  priceLevel?: number;
  website?: string;
  phone?: string;
  openingHours?: string[];
  editorialSummary?: string;
  photoUrl?: string;
  googleMapsUrl?: string;
  placeId: string;
}

interface VenueImportItem {
  id: string;
  originalQuery: string;
  found: boolean;
  place?: PlaceResult;
  // Editable CMS fields
  name: string;
  nameZh: string;
  description: string;
  category: string;
  subcategory: string;
  lat: number;
  lng: number;
  district: string;
  address: string;
  image: string;
  vibeTags: string[];
  priceRange: number;
  modeScores: Record<string, number>;
  // UI state
  included: boolean;
  expanded: boolean;
}

// ─── Step indicator ───
const STEPS = [
  { num: 1, label: 'Paste Names', icon: Upload },
  { num: 2, label: 'Lookup', icon: Search },
  { num: 3, label: 'Review & Edit', icon: Eye },
  { num: 4, label: 'Import', icon: Save },
];

function StepIndicator({ current }: { current: number }) {
  return (
    <div className="flex items-center gap-2 mb-8">
      {STEPS.map((step, i) => {
        const done = current > step.num;
        const active = current === step.num;
        const Icon = step.icon;
        return (
          <div key={step.num} className="flex items-center gap-2">
            <div className="flex items-center gap-2">
              <div
                className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium transition-all"
                style={{
                  backgroundColor: done ? N.green : active ? N.dark : N.surfaceMuted,
                  color: done || active ? '#fff' : N.textMuted,
                }}
              >
                {done ? <Check size={14} /> : <Icon size={14} />}
              </div>
              <span
                className="text-sm font-medium hidden sm:inline"
                style={{ color: active ? N.text : N.textMuted }}
              >
                {step.label}
              </span>
            </div>
            {i < STEPS.length - 1 && (
              <div
                className="w-8 h-px mx-1"
                style={{ backgroundColor: done ? N.green : N.border }}
              />
            )}
          </div>
        );
      })}
    </div>
  );
}

// ─── Mode Score Editor ───
const MODES = [
  { key: 'degen', label: 'Night', color: '#8338EC' },
  { key: 'family', label: 'Family', color: '#FF6B35' },
  { key: 'artsy', label: 'Art', color: '#E63946' },
  { key: 'foodie', label: 'Food', color: '#2D6A4F' },
  { key: 'lifestyle', label: 'Life', color: '#457B9D' },
];

function ModeScoreEditor({
  scores,
  onChange,
}: {
  scores: Record<string, number>;
  onChange: (scores: Record<string, number>) => void;
}) {
  return (
    <div className="flex flex-wrap gap-2">
      {MODES.map(m => {
        const val = scores[m.key] || 0;
        return (
          <div key={m.key} className="flex items-center gap-1.5">
            <span className="text-xs font-medium" style={{ color: m.color }}>{m.label}</span>
            <input
              type="range"
              min={0}
              max={10}
              value={val}
              onChange={(e) => {
                const v = parseInt(e.target.value);
                const next = { ...scores };
                if (v === 0) delete next[m.key];
                else next[m.key] = v;
                onChange(next);
              }}
              className="w-16 h-1 accent-current"
              style={{ accentColor: m.color }}
            />
            <span className="text-xs tabular-nums w-4 text-right" style={{ color: N.textMuted }}>
              {val}
            </span>
          </div>
        );
      })}
    </div>
  );
}

// ─── Venue Edit Card ───
function VenueEditCard({
  item,
  index,
  onUpdate,
  onToggle,
  onRemove,
  onMoveUp,
  onMoveDown,
  isFirst,
  isLast,
}: {
  item: VenueImportItem;
  index: number;
  onUpdate: (updates: Partial<VenueImportItem>) => void;
  onToggle: () => void;
  onRemove: () => void;
  onMoveUp: () => void;
  onMoveDown: () => void;
  isFirst: boolean;
  isLast: boolean;
}) {
  if (!item.found) {
    return (
      <div
        className="rounded-xl p-4 flex items-center justify-between"
        style={{ backgroundColor: N.redBg, border: `1px solid rgba(220,38,38,0.15)` }}
      >
        <div className="flex items-center gap-3">
          <AlertCircle size={18} style={{ color: N.red }} />
          <div>
            <p className="text-sm font-medium" style={{ color: N.text }}>
              "{item.originalQuery}" — not found
            </p>
            <p className="text-xs" style={{ color: N.textMuted }}>
              Try a different name or add manually in CMS
            </p>
          </div>
        </div>
        <button onClick={onRemove} className="p-1.5 rounded-lg hover:bg-red-100 transition">
          <X size={16} style={{ color: N.red }} />
        </button>
      </div>
    );
  }

  return (
    <motion.div
      layout
      className="rounded-xl overflow-hidden"
      style={{
        backgroundColor: N.surface,
        border: `1px solid ${item.included ? N.border : 'rgba(220,38,38,0.2)'}`,
        opacity: item.included ? 1 : 0.5,
      }}
    >
      {/* Collapsed header */}
      <div className="flex items-center gap-3 p-4">
        {/* Reorder controls */}
        <div className="flex flex-col gap-0.5">
          <button
            onClick={onMoveUp}
            disabled={isFirst}
            className="p-0.5 rounded hover:bg-gray-100 disabled:opacity-20 transition"
          >
            <ChevronUp size={12} style={{ color: N.textMuted }} />
          </button>
          <button
            onClick={onMoveDown}
            disabled={isLast}
            className="p-0.5 rounded hover:bg-gray-100 disabled:opacity-20 transition"
          >
            <ChevronDown size={12} style={{ color: N.textMuted }} />
          </button>
        </div>

        {/* Include toggle */}
        <button
          onClick={onToggle}
          className="w-5 h-5 rounded flex items-center justify-center flex-shrink-0 transition"
          style={{
            backgroundColor: item.included ? N.green : 'transparent',
            border: `1.5px solid ${item.included ? N.green : N.textMuted}`,
          }}
        >
          {item.included && <Check size={12} color="#fff" />}
        </button>

        {/* Thumbnail */}
        {item.image && (
          <div className="w-12 h-12 rounded-lg overflow-hidden flex-shrink-0">
            <ImageWithFallback
              src={item.image}
              alt={item.name}
              className="w-full h-full object-cover"
            />
          </div>
        )}

        {/* Info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <p className="text-sm font-semibold truncate" style={{ color: N.text }}>
              {index + 1}. {item.name}
            </p>
            {item.place?.rating && (
              <span className="flex items-center gap-0.5 text-xs" style={{ color: N.amber }}>
                <Star size={10} fill="currentColor" />
                {item.place.rating}
              </span>
            )}
          </div>
          <p className="text-xs truncate" style={{ color: N.textMuted }}>
            {item.district && `${item.district} · `}{item.category}
            {item.place?.userRatingsTotal && ` · ${item.place.userRatingsTotal.toLocaleString()} reviews`}
          </p>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-1">
          {item.place?.googleMapsUrl && (
            <a
              href={item.place.googleMapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="p-1.5 rounded-lg hover:bg-gray-100 transition"
            >
              <ExternalLink size={14} style={{ color: N.textMuted }} />
            </a>
          )}
          <button
            onClick={() => onUpdate({ expanded: !item.expanded })}
            className="p-1.5 rounded-lg hover:bg-gray-100 transition"
          >
            <ChevronDown
              size={16}
              style={{
                color: N.textMuted,
                transform: item.expanded ? 'rotate(180deg)' : 'none',
                transition: 'transform 0.2s',
              }}
            />
          </button>
          <button
            onClick={onRemove}
            className="p-1.5 rounded-lg hover:bg-red-50 transition"
          >
            <Trash2 size={14} style={{ color: N.red }} />
          </button>
        </div>
      </div>

      {/* Expanded edit form */}
      <AnimatePresence>
        {item.expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4 space-y-4" style={{ borderTop: `1px solid ${N.border}` }}>
              <div className="pt-4 grid grid-cols-2 gap-3">
                {/* Name */}
                <FieldInput label="Name" value={item.name} onChange={v => onUpdate({ name: v })} />
                <FieldInput label="Name (Chinese)" value={item.nameZh} onChange={v => onUpdate({ nameZh: v })} placeholder="中文名稱" />

                {/* Description */}
                <div className="col-span-2">
                  <FieldLabel label="Description" />
                  <textarea
                    value={item.description}
                    onChange={e => onUpdate({ description: e.target.value })}
                    rows={3}
                    className="w-full rounded-lg px-3 py-2 text-sm outline-none resize-none"
                    style={{ backgroundColor: N.surfaceMuted, border: `1px solid ${N.border}`, color: N.text, fontFamily: N.font }}
                    placeholder={item.place?.editorialSummary || 'About this venue...'}
                  />
                  {item.place?.editorialSummary && !item.description && (
                    <button
                      onClick={() => onUpdate({ description: item.place!.editorialSummary! })}
                      className="text-xs mt-1 hover:underline"
                      style={{ color: N.blue }}
                    >
                      Use Google description
                    </button>
                  )}
                </div>

                {/* Category / Subcategory */}
                <FieldInput label="Category" value={item.category} onChange={v => onUpdate({ category: v })} />
                <FieldInput label="Subcategory" value={item.subcategory} onChange={v => onUpdate({ subcategory: v })} />

                {/* Lat / Lng */}
                <FieldInput label="Latitude" value={String(item.lat)} onChange={v => onUpdate({ lat: parseFloat(v) || 0 })} />
                <FieldInput label="Longitude" value={String(item.lng)} onChange={v => onUpdate({ lng: parseFloat(v) || 0 })} />

                {/* District */}
                <FieldInput label="District" value={item.district} onChange={v => onUpdate({ district: v })} />
                <FieldInput label="Price Range (1-4)" value={String(item.priceRange)} onChange={v => onUpdate({ priceRange: parseInt(v) || 2 })} />

                {/* Address */}
                <div className="col-span-2">
                  <FieldInput label="Address" value={item.address} onChange={v => onUpdate({ address: v })} />
                </div>

                {/* Image */}
                <div className="col-span-2">
                  <FieldLabel label="Image URL" />
                  <div className="flex gap-2">
                    <input
                      value={item.image}
                      onChange={e => onUpdate({ image: e.target.value })}
                      className="flex-1 rounded-lg px-3 py-2 text-sm outline-none"
                      style={{ backgroundColor: N.surfaceMuted, border: `1px solid ${N.border}`, color: N.text, fontFamily: N.font }}
                      placeholder="https://..."
                    />
                  </div>
                  {item.image && (
                    <div className="mt-2 w-32 h-20 rounded-lg overflow-hidden">
                      <ImageWithFallback src={item.image} alt={item.name} className="w-full h-full object-cover" />
                    </div>
                  )}
                </div>

                {/* Vibe Tags */}
                <div className="col-span-2">
                  <FieldLabel label="Vibe Tags" />
                  <div className="flex flex-wrap gap-1.5 mb-2">
                    {item.vibeTags.map((tag, ti) => (
                      <span
                        key={ti}
                        className="px-2 py-0.5 rounded-full text-xs flex items-center gap-1"
                        style={{ backgroundColor: N.surfaceMuted, color: N.text }}
                      >
                        {tag}
                        <button onClick={() => {
                          const next = item.vibeTags.filter((_, j) => j !== ti);
                          onUpdate({ vibeTags: next });
                        }}>
                          <X size={10} style={{ color: N.textMuted }} />
                        </button>
                      </span>
                    ))}
                  </div>
                  <input
                    placeholder="Type tag and press Enter"
                    className="w-full rounded-lg px-3 py-2 text-sm outline-none"
                    style={{ backgroundColor: N.surfaceMuted, border: `1px solid ${N.border}`, color: N.text, fontFamily: N.font }}
                    onKeyDown={e => {
                      if (e.key === 'Enter') {
                        const val = (e.target as HTMLInputElement).value.trim();
                        if (val && !item.vibeTags.includes(val)) {
                          onUpdate({ vibeTags: [...item.vibeTags, val] });
                          (e.target as HTMLInputElement).value = '';
                        }
                        e.preventDefault();
                      }
                    }}
                  />
                </div>

                {/* Mode Scores */}
                <div className="col-span-2">
                  <FieldLabel label="Mode Scores" />
                  <ModeScoreEditor
                    scores={item.modeScores}
                    onChange={modeScores => onUpdate({ modeScores })}
                  />
                </div>
              </div>

              {/* Google info panel */}
              {item.place && (
                <div
                  className="rounded-lg p-3 space-y-2"
                  style={{ backgroundColor: N.blueBg, border: `1px solid rgba(37,99,235,0.1)` }}
                >
                  <p className="text-xs font-semibold flex items-center gap-1.5" style={{ color: N.blue }}>
                    <Globe size={12} /> Google Places Data
                  </p>
                  <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs" style={{ color: N.textSecondary }}>
                    {item.place.website && (
                      <div className="flex items-center gap-1 col-span-2">
                        <Globe size={10} />
                        <a href={item.place.website} target="_blank" rel="noopener" className="hover:underline truncate">
                          {item.place.website}
                        </a>
                      </div>
                    )}
                    {item.place.phone && (
                      <div className="flex items-center gap-1">
                        <Phone size={10} /> {item.place.phone}
                      </div>
                    )}
                    {item.place.priceLevel !== undefined && (
                      <div className="flex items-center gap-1">
                        <DollarSign size={10} /> {'$'.repeat(item.place.priceLevel || 1)}
                      </div>
                    )}
                    {item.place.types && (
                      <div className="flex items-center gap-1 col-span-2">
                        <Tag size={10} />
                        <span className="truncate">{item.place.types.filter(t => !t.startsWith('point_of')).slice(0, 5).join(', ')}</span>
                      </div>
                    )}
                  </div>
                  {item.place.openingHours && (
                    <details className="text-xs" style={{ color: N.textSecondary }}>
                      <summary className="flex items-center gap-1 cursor-pointer">
                        <Clock size={10} /> Opening hours
                      </summary>
                      <ul className="mt-1 ml-4 space-y-0.5">
                        {item.place.openingHours.map((h, i) => (
                          <li key={i}>{h}</li>
                        ))}
                      </ul>
                    </details>
                  )}
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

function FieldLabel({ label }: { label: string }) {
  return <label className="block text-xs font-medium mb-1" style={{ color: N.textSecondary }}>{label}</label>;
}

function FieldInput({
  label, value, onChange, placeholder,
}: {
  label: string; value: string; onChange: (v: string) => void; placeholder?: string;
}) {
  return (
    <div>
      <FieldLabel label={label} />
      <input
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full rounded-lg px-3 py-2 text-sm outline-none"
        style={{ backgroundColor: N.surfaceMuted, border: `1px solid ${N.border}`, color: N.text, fontFamily: N.font }}
      />
    </div>
  );
}

// ═══════════════════════════════════════════
// MAIN COMPONENT
// ═══════════════════════════════════════════

export function BulkImport() {
  const { accessToken } = useOutletContext<{ accessToken: string }>();
  const [step, setStep] = useState(1);
  const [inputText, setInputText] = useState('');
  const [items, setItems] = useState<VenueImportItem[]>([]);
  const [lookupProgress, setLookupProgress] = useState({ current: 0, total: 0, name: '' });
  const [lookupDone, setLookupDone] = useState(false);
  const [importing, setImporting] = useState(false);
  const [importResult, setImportResult] = useState<{ success: number; errors: string[] } | null>(null);
  const [sortBy, setSortBy] = useState<'order' | 'name' | 'district' | 'rating'>('order');

  // ─── URL parsing state ───
  const [listUrl, setListUrl] = useState('');
  const [urlLoading, setUrlLoading] = useState(false);
  const [urlError, setUrlError] = useState('');
  const [urlResult, setUrlResult] = useState<{ names: string[]; candidateNames: string[]; listTitle: string | null } | null>(null);

  // ─── Google Takeout file upload state ───
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [takeoutResult, setTakeoutResult] = useState<{
    total: number;
    withNames: number;
    regions: Record<string, { count: number; names: string[] }>;
  } | null>(null);
  const [takeoutFilter, setTakeoutFilter] = useState<string>('all');
  const [takeoutError, setTakeoutError] = useState('');

  // ─── Region detection from S2 cell hex in Google Maps URLs ───
  const regionFromUrl = (url: string): string => {
    const hexMatch = url.match(/[!?&](?:1s|ftid=)0x([0-9a-f]+):/i);
    if (!hexMatch) return 'Other';
    const hex = hexMatch[1].toLowerCase();
    if (hex.startsWith('3403f') || hex.startsWith('34040') || hex.startsWith('34041') ||
        hex.startsWith('3406a') || hex.startsWith('340157')) return 'Hong Kong';
    if (hex.startsWith('60188') || hex.startsWith('34e5') || hex.startsWith('34e4')) return 'Japan';
    if (hex.startsWith('30e2') || hex.startsWith('311d')) return 'Thailand';
    if (hex.startsWith('3442') || hex.startsWith('3468') || hex.startsWith('346e')) return 'Taiwan';
    if (hex.startsWith('35b2') || hex.startsWith('36ef') || hex.startsWith('34025')) return 'China';
    if (hex.startsWith('34017')) return 'Macau';
    if (hex.startsWith('5485') || hex.startsWith('5486') || hex.startsWith('54867')) return 'Canada';
    if (hex.startsWith('882b') || hex.startsWith('808')) return 'United States';
    return 'Other';
  };

  // ─── Parse CSV (Google Maps list export) ───
  const parseCsv = (text: string): { total: number; withNames: number; regions: Record<string, { count: number; names: string[] }> } => {
    const lines = text.split('\n');
    const regions: Record<string, { count: number; names: string[] }> = {};
    let total = 0;
    let withNames = 0;

    for (let i = 1; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue;

      // Simple CSV parse respecting quoted fields
      const fields: string[] = [];
      let current = '';
      let inQuotes = false;
      for (const ch of line) {
        if (ch === '"') { inQuotes = !inQuotes; continue; }
        if (ch === ',' && !inQuotes) { fields.push(current); current = ''; continue; }
        current += ch;
      }
      fields.push(current);

      const title = fields[0]?.trim();
      const url = fields[2]?.trim() || '';

      total++;
      if (!title) continue;
      if (/^\d+°/.test(title)) continue;
      if (/^\d+\s+[\w\s]+(?:Rd|St|Ave|Dr|Blvd|Pl|Hwy|Way)\b/i.test(title)) continue;
      withNames++;

      const region = url ? regionFromUrl(url) : 'Other';
      if (!regions[region]) regions[region] = { count: 0, names: [] };
      regions[region].count++;
      regions[region].names.push(title);
    }

    return { total, withNames, regions };
  };

  // ─── Handle file upload (GeoJSON or CSV) ───
  const handleTakeoutFile = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setTakeoutError('');
    setTakeoutResult(null);

    const reader = new FileReader();
    reader.onload = (ev) => {
      const text = ev.target?.result as string;
      if (!text) { setTakeoutError('Empty file'); return; }

      const isCsv = file.name.toLowerCase().endsWith('.csv') || text.trimStart().startsWith('Title,');

      if (isCsv) {
        try {
          const result = parseCsv(text);
          if (result.withNames === 0) {
            setTakeoutError('No place names found in CSV. Expected format: Title,Note,URL,Tags,Comment');
            return;
          }
          setTakeoutResult(result);
          setTakeoutFilter(result.regions['Hong Kong'] ? 'Hong Kong' : 'all');
        } catch (err: any) {
          setTakeoutError(`Failed to parse CSV: ${err.message}`);
        }
        return;
      }

      // GeoJSON format (Google Takeout)
      try {
        const json = JSON.parse(text);

        if (json.type !== 'FeatureCollection' || !Array.isArray(json.features)) {
          setTakeoutError('Not a valid GeoJSON or Google Maps CSV. Expected a Takeout .json or Maps list .csv file.');
          return;
        }

        const regions: Record<string, { count: number; names: string[] }> = {};
        let total = 0;
        let withNames = 0;

        for (const feature of json.features) {
          total++;
          const loc = feature.properties?.location;
          if (!loc?.name) continue;
          withNames++;

          const name = loc.name;
          const address = loc.address || '';
          const countryCode = loc.country_code || '';
          const coords = feature.geometry?.coordinates || [0, 0];
          const [lng, lat] = coords;

          let region = 'Other';
          if (address.includes('Hong Kong') || address.includes('香港') ||
              (lat >= 22.1 && lat <= 22.6 && lng >= 113.8 && lng <= 114.5)) {
            region = 'Hong Kong';
          } else if (countryCode === 'JP' || address.includes('Japan')) {
            region = 'Japan';
          } else if (countryCode === 'CA' || address.includes('Canada')) {
            region = 'Canada';
          } else if (countryCode === 'US' || address.includes('United States')) {
            region = 'United States';
          } else if (countryCode === 'FR' || address.includes('France')) {
            region = 'France';
          } else if (countryCode === 'CN' || address.includes('China')) {
            region = 'China';
          } else if (countryCode) {
            region = countryCode;
          }

          if (!regions[region]) regions[region] = { count: 0, names: [] };
          regions[region].count++;
          regions[region].names.push(name);
        }

        setTakeoutResult({ total, withNames, regions });
        setTakeoutFilter(regions['Hong Kong'] ? 'Hong Kong' : 'all');
      } catch (err: any) {
        setTakeoutError(`Failed to parse file: ${err.message}`);
      }
    };
    reader.onerror = () => setTakeoutError('Failed to read file');
    reader.readAsText(file);
  }, []);

  const addTakeoutNames = useCallback((filter: string) => {
    if (!takeoutResult) return;
    const names = filter === 'all'
      ? Object.values(takeoutResult.regions).flatMap(r => r.names)
      : takeoutResult.regions[filter]?.names || [];

    if (names.length === 0) return;

    setInputText(prev => {
      const existing = prev.trim();
      const newNames = names.join('\n');
      return existing ? `${existing}\n${newNames}` : newNames;
    });
  }, [takeoutResult]);

  // ─── Parse Google Maps list URL ───
  const parseListUrl = useCallback(async () => {
    if (!listUrl.trim()) return;
    setUrlLoading(true);
    setUrlError('');
    setUrlResult(null);

    try {
      const res = await fetch(`${API_BASE}/places/parse-list`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${publicAnonKey}` },
        body: JSON.stringify({ url: listUrl.trim() }),
      });
      const data = await res.json();

      if (data.error) {
        setUrlError(data.error);
        setUrlLoading(false);
        return;
      }

      const allNames = [...(data.names || []), ...(data.candidateNames || [])];
      if (allNames.length === 0) {
        const placeIdMsg = data.placeIdsFound
          ? ` We found ${data.placeIdsFound} place ID(s) in the page but couldn't reliably extract names from them.`
          : '';
        setUrlError(`Could not extract venue names from this link.${placeIdMsg} Google Maps shared lists are JavaScript-rendered SPAs — the venue data isn't in the raw HTML. Copy the venue names from your list and paste them in the text box above instead.`);
        setUrlLoading(false);
        return;
      }

      setUrlResult({
        names: data.names || [],
        candidateNames: data.candidateNames || [],
        listTitle: data.listTitle,
      });

      // Auto-fill the primary names into the textarea
      if (data.names?.length > 0) {
        setInputText(prev => {
          const existing = prev.trim();
          const newNames = data.names.join('\n');
          return existing ? `${existing}\n${newNames}` : newNames;
        });
      }
    } catch (err: any) {
      console.log('URL parse error:', err);
      setUrlError(`Failed to fetch list: ${err.message}`);
    }

    setUrlLoading(false);
  }, [listUrl]);

  // ─── Step 1 → Step 2: Parse names and start lookup ───
  const startLookup = useCallback(async () => {
    const names = inputText
      .split('\n')
      .map(n => n.trim())
      .filter(n => n.length > 0);

    if (names.length === 0) return;

    setStep(2);
    setLookupDone(false);
    setLookupProgress({ current: 0, total: names.length, name: '' });

    const results: VenueImportItem[] = [];

    for (let i = 0; i < names.length; i++) {
      const name = names[i];
      setLookupProgress({ current: i + 1, total: names.length, name });

      try {
        const res = await fetch(`${API_BASE}/places/text-search`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${publicAnonKey}` },
          body: JSON.stringify({ query: name }),
        });
        const data = await res.json();

        if (data.found && data.place) {
          const p: PlaceResult = data.place;
          const { category, subcategory } = inferCategory(p.types || []);
          const modeScores = inferModeScores(p.types || [], p.priceLevel);
          const vibeTags = inferVibeTags(p.types || [], p.rating);

          results.push({
            id: `venue_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
            originalQuery: name,
            found: true,
            place: p,
            name: p.name,
            nameZh: '',
            description: p.editorialSummary || '',
            category,
            subcategory,
            lat: p.lat,
            lng: p.lng,
            district: p.district || '',
            address: p.address || '',
            image: p.photoUrl || '',
            vibeTags,
            priceRange: Math.max(1, Math.min(4, (p.priceLevel || 1) + 1)),
            modeScores,
            included: true,
            expanded: false,
          });
        } else {
          results.push({
            id: `nf_${Date.now()}_${i}`,
            originalQuery: name,
            found: false,
            name: name,
            nameZh: '',
            description: '',
            category: '',
            subcategory: '',
            lat: 0,
            lng: 0,
            district: '',
            address: '',
            image: '',
            vibeTags: [],
            priceRange: 2,
            modeScores: {},
            included: false,
            expanded: false,
          });
        }
      } catch (err) {
        console.log(`Lookup error for "${name}":`, err);
        results.push({
          id: `err_${Date.now()}_${i}`,
          originalQuery: name,
          found: false,
          name: name,
          nameZh: '',
          description: '',
          category: '',
          subcategory: '',
          lat: 0,
          lng: 0,
          district: '',
          address: '',
          image: '',
          vibeTags: [],
          priceRange: 2,
          modeScores: {},
          included: false,
          expanded: false,
        });
      }

      // Small delay to avoid rate limiting
      if (i < names.length - 1) {
        await new Promise(r => setTimeout(r, 300));
      }
    }

    setItems(results);
    setLookupDone(true);
  }, [inputText]);

  // ─── Sorting ───
  const sortedItems = [...items].sort((a, b) => {
    if (sortBy === 'name') return a.name.localeCompare(b.name);
    if (sortBy === 'district') return (a.district || 'zzz').localeCompare(b.district || 'zzz');
    if (sortBy === 'rating') return (b.place?.rating || 0) - (a.place?.rating || 0);
    return 0; // order = insertion order
  });

  const updateItem = useCallback((id: string, updates: Partial<VenueImportItem>) => {
    setItems(prev => prev.map(it => it.id === id ? { ...it, ...updates } : it));
  }, []);

  const removeItem = useCallback((id: string) => {
    setItems(prev => prev.filter(it => it.id !== id));
  }, []);

  const moveItem = useCallback((id: string, dir: 'up' | 'down') => {
    setItems(prev => {
      const idx = prev.findIndex(it => it.id === id);
      if (idx < 0) return prev;
      const next = [...prev];
      const swapIdx = dir === 'up' ? idx - 1 : idx + 1;
      if (swapIdx < 0 || swapIdx >= next.length) return prev;
      [next[idx], next[swapIdx]] = [next[swapIdx], next[idx]];
      return next;
    });
  }, []);

  const includedCount = items.filter(it => it.included && it.found).length;
  const foundCount = items.filter(it => it.found).length;

  // ─── Step 4: Import to CMS ───
  const doImport = useCallback(async () => {
    setImporting(true);
    const toImport = items.filter(it => it.included && it.found);
    const errors: string[] = [];
    let success = 0;

    for (const item of toImport) {
      try {
        const venueData = {
          id: item.id,
          name: item.name,
          nameZh: item.nameZh,
          description: item.description,
          category: item.category,
          subcategory: item.subcategory,
          lat: item.lat,
          lng: item.lng,
          district: item.district,
          address: item.address,
          image: item.image,
          modeScores: item.modeScores,
          vibeTags: item.vibeTags,
          priceRange: item.priceRange,
          upcomingEvents: 0,
          pastRecaps: 0,
        };

        const res = await fetch(`${CMS_BASE}/content/venue`, {
          method: 'POST',
          headers: authHeaders(accessToken),
          body: JSON.stringify(venueData),
        });

        if (!res.ok) {
          const err = await res.json().catch(() => ({ error: 'Unknown error' }));
          throw new Error(err.error || `HTTP ${res.status}`);
        }
        success++;
      } catch (err: any) {
        errors.push(`${item.name}: ${err.message}`);
        console.log(`Import error for "${item.name}":`, err);
      }
    }

    setImportResult({ success, errors });
    setImporting(false);
    setStep(4);
  }, [items, accessToken]);

  // ═══ RENDER ═══
  return (
    <div className="min-h-screen" style={{ backgroundColor: N.pageBg, fontFamily: N.font }}>
      <div className="max-w-4xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="mb-2">
          <p className="text-xs uppercase tracking-wider font-semibold" style={{ color: N.textMuted }}>
            Admin Tool
          </p>
          <h1 className="text-2xl font-bold mt-1" style={{ color: N.text }}>
            Bulk Venue Import
          </h1>
          <p className="text-sm mt-1" style={{ color: N.textSecondary }}>
            Import venues from Google Places into the CMS in 4 steps
          </p>
        </div>

        <StepIndicator current={step} />

        {/* ═══ STEP 1: Paste Names ═══ */}
        {step === 1 && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
            <div
              className="rounded-xl p-6"
              style={{ backgroundColor: N.surface, border: `1px solid ${N.border}` }}
            >
              <h2 className="text-lg font-semibold mb-1" style={{ color: N.text }}>
                Paste venue names
              </h2>
              <p className="text-sm mb-4" style={{ color: N.textMuted }}>
                One venue per line. Copy them from your Google Maps list or type them manually.
                We'll look up each one via Google Places API.
              </p>

              <textarea
                value={inputText}
                onChange={e => setInputText(e.target.value)}
                rows={12}
                placeholder={`e.g.\nDarkside\nThe Old Man\nQuinary\nLobster Bar and Grill\nOzone Bar\nFélix\nSevva\nAqua Spirit\nWoolahra\nBar De-Coded`}
                className="w-full rounded-lg px-4 py-3 text-sm outline-none resize-none"
                style={{
                  backgroundColor: N.surfaceMuted,
                  border: `1px solid ${N.border}`,
                  color: N.text,
                  fontFamily: "'JetBrains Mono', monospace",
                  lineHeight: '1.8',
                }}
              />

              <div className="flex items-center justify-between mt-4">
                <p className="text-xs" style={{ color: N.textMuted }}>
                  {inputText.split('\n').filter(l => l.trim()).length} venue(s) detected
                </p>
                <button
                  onClick={startLookup}
                  disabled={!inputText.trim()}
                  className="px-5 py-2.5 rounded-lg text-sm font-semibold text-white flex items-center gap-2 transition disabled:opacity-40"
                  style={{ backgroundColor: N.dark }}
                >
                  <Search size={15} />
                  Look Up All
                  <ChevronRight size={15} />
                </button>
              </div>
            </div>

            {/* Tips */}
            <div
              className="rounded-xl p-5 mt-4"
              style={{ backgroundColor: N.blueBg, border: `1px solid rgba(37,99,235,0.1)` }}
            >
              <p className="text-sm font-semibold mb-2" style={{ color: N.blue }}>
                Tips for best results
              </p>
              <ul className="text-xs space-y-1" style={{ color: N.textSecondary }}>
                <li>Use the venue's official name as listed on Google Maps</li>
                <li>Include specific identifiers if the name is common (e.g. "Ozone Bar Hong Kong" vs just "Ozone")</li>
                <li>The lookup auto-appends "Hong Kong" to each search</li>
                <li>Each lookup uses 2 Google API calls (Text Search + Place Details)</li>
              </ul>
            </div>

            {/* Google Takeout upload */}
            <div
              className="rounded-xl p-5 mt-4"
              style={{ backgroundColor: N.surface, border: `1px solid ${N.border}` }}
            >
              <h3 className="text-sm font-semibold mb-1 flex items-center gap-2" style={{ color: N.text }}>
                <FileUp size={14} />
                Import from Google Maps / Takeout file
              </h3>
              <p className="text-xs mb-3" style={{ color: N.textMuted }}>
                Upload a <code className="px-1 py-0.5 rounded text-xs" style={{ backgroundColor: N.surfaceMuted }}>.json</code> from <a href="https://takeout.google.com" target="_blank" rel="noopener" className="underline" style={{ color: N.blue }}>Google Takeout</a> (Saved → export)
                or a <code className="px-1 py-0.5 rounded text-xs" style={{ backgroundColor: N.surfaceMuted }}>.csv</code> exported from a Google Maps list.
                Region detection auto-filters for Hong Kong using coordinates or URL hex IDs.
              </p>

              <input
                ref={fileInputRef}
                type="file"
                accept=".json,.csv"
                onChange={handleTakeoutFile}
                className="hidden"
              />

              <button
                onClick={() => fileInputRef.current?.click()}
                className="px-4 py-2.5 rounded-lg text-sm font-medium flex items-center gap-2 transition hover:bg-gray-50"
                style={{ border: `1px dashed ${N.textMuted}`, color: N.textSecondary }}
              >
                <FileUp size={15} />
                Choose .json or .csv file...
              </button>

              {takeoutError && (
                <p className="text-xs mt-2" style={{ color: N.red }}>
                  {takeoutError}
                </p>
              )}

              {takeoutResult && (
                <div className="mt-4">
                  <div
                    className="rounded-lg p-3 mb-3"
                    style={{ backgroundColor: N.greenBg, border: `1px solid rgba(22,163,74,0.15)` }}
                  >
                    <p className="text-xs font-medium flex items-center gap-1" style={{ color: N.green }}>
                      <CheckCircle2 size={12} />
                      Parsed {takeoutResult.total} entries, {takeoutResult.withNames} with names
                    </p>
                  </div>

                  {/* Region breakdown */}
                  <p className="text-xs font-medium mb-2 flex items-center gap-1" style={{ color: N.text }}>
                    <Filter size={12} />
                    Filter by region:
                  </p>
                  <div className="flex flex-wrap gap-1.5 mb-3">
                    <button
                      onClick={() => setTakeoutFilter('all')}
                      className="px-2.5 py-1 rounded-full text-xs font-medium transition"
                      style={{
                        backgroundColor: takeoutFilter === 'all' ? N.dark : N.surfaceMuted,
                        color: takeoutFilter === 'all' ? '#fff' : N.textSecondary,
                      }}
                    >
                      All ({takeoutResult.withNames})
                    </button>
                    {Object.entries(takeoutResult.regions)
                      .sort((a, b) => b[1].count - a[1].count)
                      .map(([region, data]) => (
                        <button
                          key={region}
                          onClick={() => setTakeoutFilter(region)}
                          className="px-2.5 py-1 rounded-full text-xs font-medium transition"
                          style={{
                            backgroundColor: takeoutFilter === region
                              ? (region === 'Hong Kong' ? N.green : N.dark)
                              : N.surfaceMuted,
                            color: takeoutFilter === region ? '#fff' : N.textSecondary,
                          }}
                        >
                          {region === 'Hong Kong' ? '🇭🇰 ' : ''}{region} ({data.count})
                        </button>
                      ))}
                  </div>

                  {/* Preview of names */}
                  <div
                    className="rounded-lg p-3 max-h-48 overflow-y-auto"
                    style={{ backgroundColor: N.surfaceMuted }}
                  >
                    {(takeoutFilter === 'all'
                      ? Object.values(takeoutResult.regions).flatMap(r => r.names)
                      : takeoutResult.regions[takeoutFilter]?.names || []
                    ).map((name, i) => (
                      <p key={i} className="text-xs py-0.5" style={{ color: N.text, fontFamily: "'JetBrains Mono', monospace" }}>
                        {name}
                      </p>
                    ))}
                  </div>

                  <button
                    onClick={() => addTakeoutNames(takeoutFilter)}
                    className="mt-3 px-4 py-2 rounded-lg text-sm font-semibold text-white flex items-center gap-2 transition"
                    style={{ backgroundColor: N.green }}
                  >
                    <Check size={14} />
                    Add {takeoutFilter === 'all'
                      ? takeoutResult.withNames
                      : takeoutResult.regions[takeoutFilter]?.count || 0
                    } name{(takeoutFilter === 'all' ? takeoutResult.withNames : takeoutResult.regions[takeoutFilter]?.count || 0) !== 1 ? 's' : ''} to textarea
                  </button>
                </div>
              )}
            </div>

            {/* URL parser */}
            <div
              className="rounded-xl p-5 mt-4"
              style={{ backgroundColor: N.surface, border: `1px solid ${N.border}` }}
            >
              <h3 className="text-sm font-semibold mb-1 flex items-center gap-2" style={{ color: N.text }}>
                <Link2 size={14} />
                Import from Google Maps list link
              </h3>
              <p className="text-xs mb-3" style={{ color: N.textMuted }}>
                Paste a shared Google Maps list URL. We'll try to extract venue names from the page.
                This is experimental — Google Maps pages are JavaScript-rendered, so extraction may not always work.
              </p>
              <div className="flex items-center gap-2">
                <input
                  value={listUrl}
                  onChange={e => setListUrl(e.target.value)}
                  className="flex-1 rounded-lg px-3 py-2 text-sm outline-none"
                  style={{ backgroundColor: N.surfaceMuted, border: `1px solid ${N.border}`, color: N.text, fontFamily: N.font }}
                  placeholder="https://www.google.com/maps/d/u/0/viewer..."
                />
                <button
                  onClick={parseListUrl}
                  disabled={urlLoading}
                  className="px-4 py-2.5 rounded-lg text-sm font-semibold text-white flex items-center gap-2 transition disabled:opacity-40"
                  style={{ backgroundColor: N.blue }}
                >
                  {urlLoading ? (
                    <Loader2 size={15} className="animate-spin" />
                  ) : (
                    <Link2 size={15} />
                  )}
                  Parse URL
                </button>
              </div>
              {urlError && (
                <p className="text-xs mt-2" style={{ color: N.red }}>
                  {urlError}
                </p>
              )}
              {urlResult && (
                <div className="mt-3">
                  {urlResult.listTitle && (
                    <p className="text-xs font-medium mb-1" style={{ color: N.text }}>
                      List: {urlResult.listTitle}
                    </p>
                  )}
                  {urlResult.names.length > 0 && (
                    <div
                      className="rounded-lg p-3 mb-2"
                      style={{ backgroundColor: N.greenBg, border: `1px solid rgba(22,163,74,0.15)` }}
                    >
                      <p className="text-xs font-medium mb-1.5 flex items-center gap-1" style={{ color: N.green }}>
                        <CheckCircle2 size={12} />
                        {urlResult.names.length} name{urlResult.names.length !== 1 ? 's' : ''} auto-added to textarea
                      </p>
                      <div className="flex flex-wrap gap-1">
                        {urlResult.names.map((n, i) => (
                          <span key={i} className="px-2 py-0.5 rounded text-xs" style={{ backgroundColor: 'rgba(22,163,74,0.1)', color: N.green }}>
                            {n}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                  {urlResult.candidateNames.length > 0 && (
                    <div
                      className="rounded-lg p-3"
                      style={{ backgroundColor: N.amberBg, border: `1px solid rgba(217,119,6,0.15)` }}
                    >
                      <p className="text-xs font-medium mb-1.5 flex items-center gap-1" style={{ color: N.amber }}>
                        <AlertCircle size={12} />
                        {urlResult.candidateNames.length} possible name{urlResult.candidateNames.length !== 1 ? 's' : ''} detected — click to add
                      </p>
                      <div className="flex flex-wrap gap-1">
                        {urlResult.candidateNames.map((n, i) => (
                          <button
                            key={i}
                            className="px-2 py-0.5 rounded text-xs hover:opacity-80 transition cursor-pointer"
                            style={{ backgroundColor: 'rgba(217,119,6,0.1)', color: N.amber }}
                            onClick={() => {
                              setInputText(prev => {
                                const existing = prev.trim();
                                return existing ? `${existing}\n${n}` : n;
                              });
                              setUrlResult(prev => prev ? {
                                ...prev,
                                names: [...prev.names, n],
                                candidateNames: prev.candidateNames.filter((_, j) => j !== i),
                              } : prev);
                            }}
                          >
                            + {n}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                  {urlResult.names.length === 0 && urlResult.candidateNames.length === 0 && (
                    <p className="text-xs" style={{ color: N.textMuted }}>
                      No names could be extracted. Try copying venue names manually.
                    </p>
                  )}
                </div>
              )}
            </div>
          </motion.div>
        )}

        {/* ═══ STEP 2: Lookup Progress ═══ */}
        {step === 2 && !lookupDone && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
            <div
              className="rounded-xl p-8 text-center"
              style={{ backgroundColor: N.surface, border: `1px solid ${N.border}` }}
            >
              <Loader2 size={32} className="animate-spin mx-auto mb-4" style={{ color: N.dark }} />
              <h2 className="text-lg font-semibold mb-2" style={{ color: N.text }}>
                Looking up venues...
              </h2>
              <p className="text-sm mb-4" style={{ color: N.textMuted }}>
                Searching Google Places for each venue
              </p>

              {/* Progress bar */}
              <div className="w-full max-w-sm mx-auto">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-medium" style={{ color: N.textSecondary }}>
                    {lookupProgress.current} / {lookupProgress.total}
                  </span>
                  <span className="text-xs" style={{ color: N.textMuted }}>
                    {Math.round((lookupProgress.current / lookupProgress.total) * 100)}%
                  </span>
                </div>
                <div className="h-2 rounded-full overflow-hidden" style={{ backgroundColor: N.surfaceMuted }}>
                  <motion.div
                    className="h-full rounded-full"
                    style={{ backgroundColor: N.green }}
                    animate={{ width: `${(lookupProgress.current / lookupProgress.total) * 100}%` }}
                    transition={{ duration: 0.3 }}
                  />
                </div>
                <p className="text-xs mt-2" style={{ color: N.textMuted }}>
                  Current: {lookupProgress.name}
                </p>
              </div>
            </div>
          </motion.div>
        )}

        {/* ═══ STEP 2 done → STEP 3: Review & Edit ═══ */}
        {step === 2 && lookupDone && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
            {/* Summary bar */}
            <div
              className="rounded-xl p-4 mb-4 flex flex-wrap items-center justify-between gap-3"
              style={{ backgroundColor: N.surface, border: `1px solid ${N.border}` }}
            >
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 size={16} style={{ color: N.green }} />
                  <span className="text-sm font-medium" style={{ color: N.text }}>
                    {foundCount} found
                  </span>
                </div>
                {items.length - foundCount > 0 && (
                  <div className="flex items-center gap-1.5">
                    <AlertCircle size={16} style={{ color: N.red }} />
                    <span className="text-sm font-medium" style={{ color: N.text }}>
                      {items.length - foundCount} not found
                    </span>
                  </div>
                )}
                <div className="flex items-center gap-1.5">
                  <Check size={16} style={{ color: N.blue }} />
                  <span className="text-sm font-medium" style={{ color: N.text }}>
                    {includedCount} selected
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {/* Sort control */}
                <div className="flex items-center gap-1.5">
                  <ArrowUpDown size={14} style={{ color: N.textMuted }} />
                  <select
                    value={sortBy}
                    onChange={e => setSortBy(e.target.value as any)}
                    className="text-sm rounded-lg px-2 py-1.5 outline-none appearance-none cursor-pointer"
                    style={{ backgroundColor: N.surfaceMuted, border: `1px solid ${N.border}`, color: N.text, fontFamily: N.font }}
                  >
                    <option value="order">Input Order</option>
                    <option value="name">Name A-Z</option>
                    <option value="district">District</option>
                    <option value="rating">Rating</option>
                  </select>
                </div>

                {/* Expand/collapse all */}
                <button
                  onClick={() => {
                    const allExpanded = items.every(it => it.expanded || !it.found);
                    setItems(prev => prev.map(it => ({ ...it, expanded: it.found ? !allExpanded : false })));
                  }}
                  className="px-3 py-1.5 rounded-lg text-xs font-medium transition hover:bg-gray-100"
                  style={{ border: `1px solid ${N.border}`, color: N.textSecondary }}
                >
                  {items.every(it => it.expanded || !it.found) ? 'Collapse All' : 'Expand All'}
                </button>

                {/* Select/deselect all */}
                <button
                  onClick={() => {
                    const allIncluded = items.filter(it => it.found).every(it => it.included);
                    setItems(prev => prev.map(it => ({ ...it, included: it.found ? !allIncluded : false })));
                  }}
                  className="px-3 py-1.5 rounded-lg text-xs font-medium transition hover:bg-gray-100"
                  style={{ border: `1px solid ${N.border}`, color: N.textSecondary }}
                >
                  {items.filter(it => it.found).every(it => it.included) ? 'Deselect All' : 'Select All'}
                </button>
              </div>
            </div>

            {/* Venue list */}
            <div className="space-y-2">
              {(sortBy === 'order' ? items : sortedItems).map((item, idx) => (
                <VenueEditCard
                  key={item.id}
                  item={item}
                  index={idx}
                  onUpdate={updates => updateItem(item.id, updates)}
                  onToggle={() => updateItem(item.id, { included: !item.included })}
                  onRemove={() => removeItem(item.id)}
                  onMoveUp={() => moveItem(item.id, 'up')}
                  onMoveDown={() => moveItem(item.id, 'down')}
                  isFirst={idx === 0}
                  isLast={idx === (sortBy === 'order' ? items : sortedItems).length - 1}
                />
              ))}
            </div>

            {/* Action bar */}
            <div
              className="sticky bottom-0 mt-6 rounded-xl p-4 flex items-center justify-between"
              style={{ backgroundColor: N.surface, border: `1px solid ${N.border}`, boxShadow: '0 -4px 20px rgba(0,0,0,0.05)' }}
            >
              <button
                onClick={() => { setStep(1); setLookupDone(false); }}
                className="px-4 py-2 rounded-lg text-sm font-medium transition hover:bg-gray-100"
                style={{ border: `1px solid ${N.border}`, color: N.textSecondary }}
              >
                Back to Edit Names
              </button>

              <div className="flex items-center gap-3">
                <span className="text-sm" style={{ color: N.textMuted }}>
                  {includedCount} venue{includedCount !== 1 ? 's' : ''} will be imported
                </span>
                <button
                  onClick={doImport}
                  disabled={includedCount === 0 || importing}
                  className="px-6 py-2.5 rounded-lg text-sm font-semibold text-white flex items-center gap-2 transition disabled:opacity-40"
                  style={{ backgroundColor: N.green }}
                >
                  {importing ? (
                    <Loader2 size={15} className="animate-spin" />
                  ) : (
                    <Save size={15} />
                  )}
                  Import {includedCount} Venue{includedCount !== 1 ? 's' : ''}
                </button>
              </div>
            </div>
          </motion.div>
        )}

        {/* ═══ STEP 4: Import Complete ═══ */}
        {step === 4 && importResult && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
            <div
              className="rounded-xl p-8 text-center"
              style={{ backgroundColor: N.surface, border: `1px solid ${N.border}` }}
            >
              {importResult.errors.length === 0 ? (
                <>
                  <div
                    className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4"
                    style={{ backgroundColor: N.greenBg }}
                  >
                    <CheckCircle2 size={32} style={{ color: N.green }} />
                  </div>
                  <h2 className="text-xl font-bold mb-2" style={{ color: N.text }}>
                    Import Complete!
                  </h2>
                  <p className="text-sm mb-6" style={{ color: N.textSecondary }}>
                    Successfully imported {importResult.success} venue{importResult.success !== 1 ? 's' : ''} to the CMS.
                    They'll now appear on the map and in the admin venue list.
                  </p>
                </>
              ) : (
                <>
                  <div
                    className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4"
                    style={{ backgroundColor: N.amberBg }}
                  >
                    <AlertCircle size={32} style={{ color: N.amber }} />
                  </div>
                  <h2 className="text-xl font-bold mb-2" style={{ color: N.text }}>
                    Partially Imported
                  </h2>
                  <p className="text-sm mb-4" style={{ color: N.textSecondary }}>
                    {importResult.success} succeeded, {importResult.errors.length} failed
                  </p>
                  <div
                    className="rounded-lg p-3 text-left max-w-md mx-auto mb-6"
                    style={{ backgroundColor: N.redBg }}
                  >
                    {importResult.errors.map((err, i) => (
                      <p key={i} className="text-xs mb-1" style={{ color: N.red }}>{err}</p>
                    ))}
                  </div>
                </>
              )}

              <div className="flex items-center justify-center gap-3">
                <button
                  onClick={() => {
                    setStep(1);
                    setInputText('');
                    setItems([]);
                    setImportResult(null);
                    setLookupDone(false);
                  }}
                  className="px-5 py-2.5 rounded-lg text-sm font-medium transition hover:bg-gray-100"
                  style={{ border: `1px solid ${N.border}`, color: N.textSecondary }}
                >
                  Import More
                </button>
                <a
                  href="/admin/content/venue"
                  className="px-5 py-2.5 rounded-lg text-sm font-semibold text-white flex items-center gap-2 transition"
                  style={{ backgroundColor: N.dark }}
                >
                  <MapPin size={15} />
                  View Venues in CMS
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}