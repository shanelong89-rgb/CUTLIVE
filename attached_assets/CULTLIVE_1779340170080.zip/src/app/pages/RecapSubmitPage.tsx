import { useState, useCallback, useRef, useMemo, useEffect } from 'react';
import { Link, useSearchParams } from 'react-router';
import { motion, AnimatePresence } from 'motion/react';
import {
  Search, Upload, X, Check, ArrowRight, ArrowLeft, Camera,
  Loader2, CheckCircle2, Plus, Film, Image as ImageIcon,
  Calendar, MapPin, Clock, Send, Eye, Star, Scissors,
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { createSubmission, uploadImages } from '../hooks/useAdminApi';
import { fireWebhook } from '../config/webhooks';
import { useData } from '../context/DataContext';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import { isVideoUrl, MEDIA_ACCEPT } from '../utils/media-helpers';

// ─── Neutral Design Tokens (matches ContributePage) ───
const T = {
  bg: '#FAFAF8',
  surface: '#FFFFFF',
  surfaceMuted: '#F5F5F3',
  border: 'rgba(0,0,0,0.06)',
  text: '#1A1A1A',
  textSecondary: '#5A5A5A',
  textMuted: '#9A9A9A',
  accent: '#2563EB',
  accentBg: 'rgba(37,99,235,0.05)',
  accentBorder: 'rgba(37,99,235,0.15)',
  error: '#DC2626',
  errorBg: 'rgba(220,38,38,0.05)',
  green: '#16A34A',
  greenBg: 'rgba(22,163,74,0.06)',
  font: "'Inter', 'Noto Sans HK', system-ui, sans-serif",
};

type Step = 'event' | 'details' | 'review' | 'submitted';

interface RecapForm {
  eventId: string;
  eventTitle: string;
  eventImage: string;
  eventDate: string;
  eventVenue: string;
  description: string;
  description_zh: string;
  media: string[]; // URLs of uploaded images/videos
  heroImage: string; // URL of the hero/thumbnail image (must be an image, not video)
  contributorName: string;
  contributorEmail: string;
  contributorInstagram: string;
}

const emptyForm: RecapForm = {
  eventId: '',
  eventTitle: '',
  eventImage: '',
  eventDate: '',
  eventVenue: '',
  description: '',
  description_zh: '',
  media: [],
  heroImage: '',
  contributorName: '',
  contributorEmail: '',
  contributorInstagram: '',
};

const inputStyle: React.CSSProperties = {
  backgroundColor: T.surface,
  border: `1px solid ${T.border}`,
  borderRadius: '10px',
  padding: '10px 14px',
  fontSize: '14px',
  color: T.text,
  fontFamily: T.font,
  outline: 'none',
  width: '100%',
  transition: 'border-color 0.2s',
};

const labelStyle: React.CSSProperties = {
  fontSize: '12px',
  fontWeight: 500,
  color: T.textSecondary,
  marginBottom: '6px',
  display: 'block',
  letterSpacing: '0.02em',
};

export function RecapSubmitPage() {
  const { t, i18n } = useTranslation();
  const isZh = i18n.language?.startsWith('zh');
  const { allEvents, venues } = useData();

  const [step, setStep] = useState<Step>('event');
  const [form, setForm] = useState<RecapForm>(emptyForm);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [submissionResult, setSubmissionResult] = useState<any>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState('');
  const [dragOver, setDragOver] = useState(false);

  // Event search
  const [eventSearch, setEventSearch] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [searchParams] = useSearchParams();
  const preselectedEventId = searchParams.get('event') || '';
  const didAutoSelect = useRef(false);
  const [frameCapturing, setFrameCapturing] = useState(false);
  const [frameCaptureVideoUrl, setFrameCaptureVideoUrl] = useState('');
  const frameVideoRef = useRef<HTMLVideoElement>(null);
  const frameCanvasRef = useRef<HTMLCanvasElement>(null);

  // Derived: images vs videos in media
  const imageUrls = useMemo(() => form.media.filter(u => !isVideoUrl(u)), [form.media]);
  const videoUrls = useMemo(() => form.media.filter(u => isVideoUrl(u)), [form.media]);
  const hasOnlyVideos = form.media.length > 0 && imageUrls.length === 0;
  const needsHeroImage = form.media.length > 0 && !form.heroImage;

  // Auto-set heroImage: first photo, or keep current if valid
  useEffect(() => {
    if (form.media.length === 0) {
      if (form.heroImage) setForm(prev => ({ ...prev, heroImage: '' }));
      return;
    }
    const imgs = form.media.filter(u => !isVideoUrl(u));
    // If current hero is still in media, keep it
    if (form.heroImage && form.media.includes(form.heroImage)) return;
    // Auto-pick first image
    if (imgs.length > 0) {
      setForm(prev => ({ ...prev, heroImage: imgs[0] }));
    }
    // If only videos, hero stays empty until user captures a frame
  }, [form.media]);

  // Capture a frame from a video and upload it as the hero image
  const captureVideoFrame = useCallback(async () => {
    const video = frameVideoRef.current;
    const canvas = frameCanvasRef.current;
    if (!video || !canvas) return;

    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 360;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    canvas.toBlob(async (blob) => {
      if (!blob) return;
      setFrameCapturing(true);
      try {
        const file = new File([blob], `frame-${Date.now()}.jpg`, { type: 'image/jpeg' });
        const result = await uploadImages([file]);
        if (result.uploaded.length > 0) {
          const frameUrl = result.uploaded[0].url;
          setForm(prev => ({
            ...prev,
            media: [frameUrl, ...prev.media],
            heroImage: frameUrl,
          }));
          setFrameCaptureVideoUrl('');
        }
      } catch (err: any) {
        setErrors(prev => ({ ...prev, media: err.message || 'Frame capture failed' }));
      }
      setFrameCapturing(false);
    }, 'image/jpeg', 0.92);
  }, []);

  const updateForm = useCallback((updates: Partial<RecapForm>) => {
    setForm(prev => ({ ...prev, ...updates }));
    const newErrors = { ...errors };
    Object.keys(updates).forEach(k => delete newErrors[k]);
    setErrors(newErrors);
  }, [errors]);

  // Filter to past/ongoing events for recap
  const pastEvents = useMemo(() => {
    return allEvents
      .filter(e => e.status === 'past' || e.status === 'ongoing')
      .sort((a, b) => {
        // Sort by date descending (most recent first)
        const da = new Date(a.date || '').getTime() || 0;
        const db = new Date(b.date || '').getTime() || 0;
        return db - da;
      });
  }, [allEvents]);

  const filteredEvents = useMemo(() => {
    if (!eventSearch.trim()) return pastEvents.slice(0, 20);
    const q = eventSearch.toLowerCase();
    return pastEvents.filter(e =>
      e.title?.toLowerCase().includes(q) ||
      e.title_zh?.includes(eventSearch) ||
      e.venueName?.toLowerCase().includes(q) ||
      e.venueName_zh?.includes(eventSearch) ||
      e.district?.toLowerCase().includes(q)
    ).slice(0, 20);
  }, [pastEvents, eventSearch]);

  const selectEvent = useCallback((event: any) => {
    const venue = venues.find(v => v.id === event.venueId);
    updateForm({
      eventId: event.id,
      eventTitle: isZh ? (event.title_zh || event.title) : event.title,
      eventImage: event.image || '',
      eventDate: event.date || '',
      eventVenue: isZh
        ? (event.venueName_zh || event.venueName || venue?.nameZh || venue?.name || '')
        : (event.venueName || venue?.name || ''),
    });
  }, [venues, isZh, updateForm]);

  // Auto-select event from ?event= query param
  useEffect(() => {
    if (didAutoSelect.current || !preselectedEventId || allEvents.length === 0) return;
    const event = allEvents.find(e => e.id === preselectedEventId);
    if (event) {
      selectEvent(event);
      didAutoSelect.current = true;
    }
  }, [preselectedEventId, allEvents, selectEvent]);

  // File upload
  const MAX_IMAGE_MB = 10;
  const MAX_VIDEO_MB = 50;

  const handleFileUpload = useCallback(async (files: FileList | File[]) => {
    const fileArray = Array.from(files).filter(f =>
      f.type.startsWith('image/') || f.type.startsWith('video/')
    );
    if (fileArray.length === 0) return;

    // Client-side size validation
    const oversized = fileArray.filter(f => {
      const limitMB = f.type.startsWith('video/') ? MAX_VIDEO_MB : MAX_IMAGE_MB;
      return f.size > limitMB * 1024 * 1024;
    });
    if (oversized.length > 0) {
      const names = oversized.map(f => {
        const limitMB = f.type.startsWith('video/') ? MAX_VIDEO_MB : MAX_IMAGE_MB;
        return `${f.name} (${(f.size / 1024 / 1024).toFixed(1)}MB > ${limitMB}MB)`;
      }).join(', ');
      setErrors(prev => ({ ...prev, media: isZh ? `檔案太大: ${names}` : `File too large: ${names}` }));
      return;
    }

    const remaining = 10 - form.media.length;
    if (remaining <= 0) {
      setErrors(prev => ({ ...prev, media: isZh ? '最多可上傳10個媒體檔案' : 'Maximum 10 media files allowed' }));
      return;
    }
    const toUpload = fileArray.slice(0, remaining);

    setUploading(true);
    setUploadProgress(isZh
      ? `正在上傳 ${toUpload.length} 個檔案...`
      : `Uploading ${toUpload.length} file${toUpload.length > 1 ? 's' : ''}...`
    );

    try {
      const result = await uploadImages(toUpload);
      if (result.uploaded.length > 0) {
        const newUrls = result.uploaded.map(u => u.url);
        updateForm({ media: [...form.media, ...newUrls] });
        setUploadProgress(isZh
          ? `已上傳 ${result.uploaded.length} 個檔案`
          : `${result.uploaded.length} file${result.uploaded.length > 1 ? 's' : ''} uploaded`
        );
      }
      if (result.errors.length > 0) {
        setErrors(prev => ({ ...prev, media: result.errors.join('; ') }));
      }
    } catch (err: any) {
      setErrors(prev => ({ ...prev, media: err.message || 'Upload failed' }));
      setUploadProgress('');
    }

    setUploading(false);
    setTimeout(() => setUploadProgress(''), 3000);
  }, [form.media, updateForm, isZh]);

  const removeMedia = useCallback((idx: number) => {
    updateForm({ media: form.media.filter((_, i) => i !== idx) });
  }, [form.media, updateForm]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    if (e.dataTransfer.files.length > 0) handleFileUpload(e.dataTransfer.files);
  }, [handleFileUpload]);

  const validate = useCallback(() => {
    const errs: Record<string, string> = {};
    if (!form.eventId) errs.eventId = isZh ? '請選擇活動' : 'Please select an event';
    if (!form.description.trim() || form.description.length < 20) errs.description = isZh ? '描述至少需要20個字元' : 'Description must be at least 20 characters';
    if (form.media.length === 0) errs.media = isZh ? '請至少上傳一張照片或影片' : 'Please upload at least one photo or video';
    if (!form.contributorName.trim()) errs.contributorName = isZh ? '請填寫姓名' : 'Your name is required';
    if (!form.contributorEmail.trim()) errs.contributorEmail = isZh ? '請填寫電郵' : 'Email is required';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  }, [form, isZh]);

  const handleSubmit = useCallback(async () => {
    if (!validate()) return;
    setSubmitting(true);
    try {
      const result = await createSubmission({
        type: 'recap',
        title: `Recap: ${form.eventTitle}`,
        description: form.description,
        description_zh: form.description_zh,
        eventId: form.eventId,
        eventTitle: form.eventTitle,
        eventDate: form.eventDate,
        eventVenue: form.eventVenue,
        images: form.media,
        heroImage: form.heroImage || undefined,
        contributorName: form.contributorName,
        contributorEmail: form.contributorEmail,
        contributorInstagram: form.contributorInstagram,
        source: 'manual',
        category: 'recap',
        categories: ['recap'],
      });
      setSubmissionResult(result);
      setStep('submitted');
      fireWebhook('submission.created', {
        submissionId: result.id || result.submission?.id,
        title: `Recap: ${form.eventTitle}`,
        type: 'recap',
        source: 'manual',
      });
    } catch (err: any) {
      setErrors({ submit: err.message || 'Submission failed' });
    }
    setSubmitting(false);
  }, [form, validate]);

  const completeness = (() => {
    let filled = 0;
    const total = 5;
    if (form.eventId) filled++;
    if (form.description.trim() && form.description.length >= 20) filled++;
    if (form.media.length > 0) filled++;
    if (form.contributorName.trim()) filled++;
    if (form.contributorEmail.trim()) filled++;
    return Math.round((filled / total) * 100);
  })();

  const steps: { key: Step; label: string }[] = [
    { key: 'event', label: isZh ? '選擇活動' : 'Select Event' },
    { key: 'details', label: isZh ? '回顧詳情' : 'Recap Details' },
    { key: 'review', label: isZh ? '審閱提交' : 'Review' },
  ];

  return (
    <div className="min-h-screen" data-nav-theme="dark" style={{ backgroundColor: T.bg, fontFamily: T.font }}>
      {/* Header */}
      <div className="px-4 py-16 sm:py-20 max-w-3xl mx-auto">
        <div className="mb-2">
          <span
            className="inline-flex items-center gap-2 px-3 py-1.5 text-[11px] tracking-[0.18em] uppercase"
            style={{
              backgroundColor: 'rgba(0,0,0,0.03)',
              color: '#9A9A9A',
              borderRadius: '4px',
              border: '1px solid rgba(0,0,0,0.05)',
              fontFamily: "'Inter', sans-serif",
              fontWeight: 500,
            }}
          >
            <Camera size={12} />
            {isZh ? '社群回顧' : 'Community Recaps'}
          </span>
        </div>
        <h1
          className="text-3xl sm:text-4xl mt-4"
          style={{ color: T.text, fontFamily: T.font, fontWeight: 600, letterSpacing: '-0.03em' }}
        >
          {isZh ? '提交活動回顧' : 'Submit a Recap'}
        </h1>
        <p className="mt-3 text-[15px]" style={{ color: T.textMuted, lineHeight: 1.7 }}>
          {isZh
            ? '分享你參加過的活動體驗——上傳照片、影片和你的心得。'
            : 'Share your experience from a past event — upload photos, videos, and your thoughts.'}
        </p>
        <div className="mt-4">
          <Link to="/contribute" className="text-[13px] no-underline transition-opacity hover:opacity-70"
            style={{ color: T.accent }}>
            ← {isZh ? '提交活動' : 'Submit an event instead'}
          </Link>
        </div>
        <div className="mt-6 h-px" style={{ backgroundColor: T.border, maxWidth: '200px' }} />
      </div>

      {/* Progress Steps */}
      {step !== 'submitted' && (
        <div className="max-w-3xl mx-auto px-4 mb-8">
          <div className="flex items-center gap-2">
            {steps.map((s, i) => {
              const stepOrder = ['event', 'details', 'review'];
              const currentIdx = stepOrder.indexOf(step);
              const thisIdx = i;
              const isActive = step === s.key;
              const isDone = thisIdx < currentIdx;
              return (
                <div key={s.key} className="flex items-center gap-2 flex-1">
                  <div className="flex items-center gap-2 flex-1">
                    <div
                      className="w-6 h-6 flex items-center justify-center text-[11px] font-semibold flex-shrink-0"
                      style={{
                        borderRadius: '50%',
                        backgroundColor: isDone ? T.green : isActive ? T.text : 'rgba(0,0,0,0.06)',
                        color: isDone || isActive ? '#fff' : T.textMuted,
                      }}
                    >
                      {isDone ? <Check size={12} /> : i + 1}
                    </div>
                    <span className="text-[12px] font-medium hidden sm:inline" style={{
                      color: isActive ? T.text : T.textMuted,
                    }}>{s.label}</span>
                  </div>
                  {i < steps.length - 1 && (
                    <div className="flex-1 h-px" style={{
                      backgroundColor: isDone ? T.green : T.border,
                    }} />
                  )}
                </div>
              );
            })}
          </div>
          {/* Completeness bar */}
          <div className="mt-4 flex items-center gap-3">
            <div className="flex-1 h-1 overflow-hidden" style={{ backgroundColor: 'rgba(0,0,0,0.05)', borderRadius: '2px' }}>
              <motion.div
                className="h-full"
                style={{ backgroundColor: completeness >= 100 ? T.green : T.text, borderRadius: '2px' }}
                animate={{ width: `${completeness}%` }}
                transition={{ duration: 0.5 }}
              />
            </div>
            <span className="text-[11px] font-medium" style={{ color: T.textMuted }}>{completeness}%</span>
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="max-w-3xl mx-auto px-4 pb-20">
        <AnimatePresence mode="wait">
          {/* ──── Step 1: Select Event ──── */}
          {step === 'event' && (
            <motion.div key="event" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -12 }}>
              <div className="space-y-4">
                {/* Selected event preview */}
                {form.eventId && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.97 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="p-4 flex items-center gap-4"
                    style={{ backgroundColor: T.greenBg, border: `1px solid rgba(22,163,74,0.15)`, borderRadius: '14px' }}
                  >
                    {form.eventImage && (
                      <div className="w-16 h-16 flex-shrink-0 overflow-hidden" style={{ borderRadius: '10px' }}>
                        <ImageWithFallback src={form.eventImage} alt="" className="w-full h-full object-cover" />
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="text-[11px] font-medium uppercase tracking-wider mb-1" style={{ color: T.green }}>
                        <CheckCircle2 size={10} className="inline mr-1" />
                        {isZh ? '已選擇活動' : 'Selected Event'}
                      </p>
                      <p className="text-[14px] font-medium truncate" style={{ color: T.text }}>{form.eventTitle}</p>
                      <div className="flex items-center gap-3 mt-0.5">
                        {form.eventDate && (
                          <span className="text-[12px]" style={{ color: T.textMuted }}>
                            <Calendar size={10} className="inline mr-1" />{form.eventDate}
                          </span>
                        )}
                        {form.eventVenue && (
                          <span className="text-[12px]" style={{ color: T.textMuted }}>
                            <MapPin size={10} className="inline mr-1" />{form.eventVenue}
                          </span>
                        )}
                      </div>
                    </div>
                    <button onClick={() => updateForm({ eventId: '', eventTitle: '', eventImage: '', eventDate: '', eventVenue: '' })}
                      className="p-2 cursor-pointer" style={{ color: T.textMuted }} title="Change">
                      <X size={16} />
                    </button>
                  </motion.div>
                )}

                {/* Search */}
                <div className="relative">
                  <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2" style={{ color: T.textMuted }} />
                  <input
                    type="text"
                    value={eventSearch}
                    onChange={e => setEventSearch(e.target.value)}
                    placeholder={isZh ? '搜尋活動名稱、場地或地區...' : 'Search by event name, venue, or district...'}
                    style={{ ...inputStyle, paddingLeft: '42px' }}
                    onFocus={e => e.target.style.borderColor = T.accent}
                    onBlur={e => e.target.style.borderColor = 'rgba(0,0,0,0.06)'}
                  />
                </div>

                {errors.eventId && (
                  <p className="text-[12px]" style={{ color: T.error }}>{errors.eventId}</p>
                )}

                {/* Event list */}
                <div className="space-y-2" style={{ maxHeight: '420px', overflowY: 'auto' }}>
                  {filteredEvents.length === 0 ? (
                    <div className="text-center py-12" style={{ backgroundColor: T.surface, borderRadius: '14px', border: `1px solid ${T.border}` }}>
                      <Calendar size={24} style={{ color: T.textMuted }} className="mx-auto mb-2 opacity-40" />
                      <p className="text-[14px]" style={{ color: T.textMuted }}>
                        {isZh ? '找不到過往活動' : 'No past events found'}
                      </p>
                      <p className="text-[12px] mt-1" style={{ color: T.textMuted }}>
                        {isZh ? '嘗試不同的搜尋字詞' : 'Try a different search term'}
                      </p>
                    </div>
                  ) : filteredEvents.map(event => {
                    const isSelected = form.eventId === event.id;
                    const venue = venues.find(v => v.id === event.venueId);
                    const displayTitle = isZh ? (event.title_zh || event.title) : event.title;
                    const displayVenue = isZh
                      ? (event.venueName_zh || event.venueName || venue?.nameZh || venue?.name || '')
                      : (event.venueName || venue?.name || '');
                    return (
                      <motion.button
                        key={event.id}
                        whileHover={{ scale: 1.005 }}
                        whileTap={{ scale: 0.995 }}
                        onClick={() => selectEvent(event)}
                        className="w-full text-left flex items-center gap-3 p-3 transition-all cursor-pointer"
                        style={{
                          backgroundColor: isSelected ? T.accentBg : T.surface,
                          border: `1px solid ${isSelected ? T.accentBorder : T.border}`,
                          borderRadius: '12px',
                        }}
                      >
                        {event.image ? (
                          <div className="w-12 h-12 flex-shrink-0 overflow-hidden" style={{ borderRadius: '8px' }}>
                            <ImageWithFallback src={event.image} alt="" className="w-full h-full object-cover" />
                          </div>
                        ) : (
                          <div className="w-12 h-12 flex-shrink-0 flex items-center justify-center" style={{
                            borderRadius: '8px', backgroundColor: 'rgba(0,0,0,0.03)',
                          }}>
                            <Calendar size={16} style={{ color: T.textMuted }} />
                          </div>
                        )}
                        <div className="flex-1 min-w-0">
                          <p className="text-[14px] font-medium truncate" style={{ color: T.text }}>{displayTitle}</p>
                          <div className="flex items-center gap-3 mt-0.5">
                            {event.date && (
                              <span className="text-[11px]" style={{ color: T.textMuted }}>
                                <Calendar size={9} className="inline mr-1" />{event.date}
                              </span>
                            )}
                            {displayVenue && (
                              <span className="text-[11px] truncate" style={{ color: T.textMuted }}>
                                <MapPin size={9} className="inline mr-1" />{displayVenue}
                              </span>
                            )}
                          </div>
                        </div>
                        {isSelected && (
                          <div className="w-5 h-5 flex items-center justify-center flex-shrink-0"
                            style={{ backgroundColor: T.accent, borderRadius: '50%' }}>
                            <Check size={12} color="#fff" />
                          </div>
                        )}
                      </motion.button>
                    );
                  })}
                </div>

                {/* Next */}
                <div className="pt-4">
                  <button
                    onClick={() => {
                      if (!form.eventId) {
                        setErrors({ eventId: isZh ? '請選擇活動' : 'Please select an event' });
                        return;
                      }
                      setStep('details');
                    }}
                    className="flex items-center gap-2 px-6 py-3 text-[14px] font-medium cursor-pointer transition-all hover:opacity-90"
                    style={{
                      backgroundColor: form.eventId ? T.text : 'rgba(0,0,0,0.08)',
                      color: form.eventId ? '#fff' : T.textMuted,
                      borderRadius: '12px',
                      border: 'none',
                    }}
                  >
                    {isZh ? '下一步' : 'Next'} <ArrowRight size={16} />
                  </button>
                </div>
              </div>
            </motion.div>
          )}

          {/* ──── Step 2: Recap Details ──── */}
          {step === 'details' && (
            <motion.div key="details" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -12 }}>
              <div className="space-y-5">
                {/* Selected event reminder */}
                <div className="flex items-center gap-3 p-3" style={{
                  backgroundColor: T.surfaceMuted, borderRadius: '10px', border: `1px solid ${T.border}`,
                }}>
                  {form.eventImage && (
                    <div className="w-10 h-10 flex-shrink-0 overflow-hidden" style={{ borderRadius: '8px' }}>
                      <ImageWithFallback src={form.eventImage} alt="" className="w-full h-full object-cover" />
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <p className="text-[12px]" style={{ color: T.textMuted }}>{isZh ? '回顧活動' : 'Recapping'}</p>
                    <p className="text-[14px] font-medium truncate" style={{ color: T.text }}>{form.eventTitle}</p>
                  </div>
                  <button onClick={() => setStep('event')} className="text-[12px] cursor-pointer px-2 py-1 no-underline"
                    style={{ color: T.accent, border: 'none', background: 'none' }}>
                    {isZh ? '更改' : 'Change'}
                  </button>
                </div>

                {/* Description */}
                <div>
                  <label style={labelStyle}>{isZh ? '回顧描述 (English)' : 'Recap Description'} *</label>
                  <textarea
                    value={form.description}
                    onChange={e => updateForm({ description: e.target.value })}
                    placeholder={isZh ? '分享你的體驗...' : 'Share your experience — what was it like, highlights, vibes...'}
                    rows={4}
                    style={{ ...inputStyle, resize: 'vertical', minHeight: '100px' }}
                    onFocus={e => e.target.style.borderColor = T.accent}
                    onBlur={e => e.target.style.borderColor = 'rgba(0,0,0,0.06)'}
                  />
                  {errors.description && <p className="text-[12px] mt-1" style={{ color: T.error }}>{errors.description}</p>}
                </div>

                {/* Description ZH */}
                <div>
                  <label style={labelStyle}>{isZh ? '回顧描述 (中文)' : 'Recap Description (Chinese)'}</label>
                  <textarea
                    value={form.description_zh}
                    onChange={e => updateForm({ description_zh: e.target.value })}
                    placeholder={isZh ? '用中文分享你的體驗（可選）...' : 'Optional: Write in Chinese...'}
                    rows={3}
                    style={{ ...inputStyle, resize: 'vertical', minHeight: '80px' }}
                    onFocus={e => e.target.style.borderColor = T.accent}
                    onBlur={e => e.target.style.borderColor = 'rgba(0,0,0,0.06)'}
                  />
                </div>

                {/* Media Upload */}
                <div>
                  <label style={labelStyle}>
                    {isZh ? '照片 / 影片' : 'Photos / Videos'} *
                    <span className="ml-2" style={{ color: T.textMuted, fontWeight: 400 }}>
                      ({form.media.length}/10)
                    </span>
                  </label>

                  {/* Upload zone */}
                  <div
                    onDrop={handleDrop}
                    onDragOver={e => { e.preventDefault(); setDragOver(true); }}
                    onDragLeave={e => { e.preventDefault(); setDragOver(false); }}
                    onClick={() => fileInputRef.current?.click()}
                    className="flex flex-col items-center justify-center py-8 cursor-pointer transition-all"
                    style={{
                      backgroundColor: dragOver ? T.accentBg : T.surface,
                      border: `2px dashed ${dragOver ? T.accent : T.border}`,
                      borderRadius: '14px',
                    }}
                  >
                    {uploading ? (
                      <>
                        <Loader2 size={24} className="animate-spin mb-2" style={{ color: T.accent }} />
                        <p className="text-[13px]" style={{ color: T.textSecondary }}>{uploadProgress}</p>
                      </>
                    ) : (
                      <>
                        <div className="flex items-center gap-3 mb-2">
                          <ImageIcon size={20} style={{ color: T.textMuted }} />
                          <Film size={20} style={{ color: T.textMuted }} />
                        </div>
                        <p className="text-[13px] font-medium" style={{ color: T.textSecondary }}>
                          {isZh ? '拖放或點擊上傳' : 'Drag & drop or click to upload'}
                        </p>
                        <p className="text-[11px] mt-1" style={{ color: T.textMuted }}>
                          {isZh ? '支援 JPG, PNG, MP4, MOV' : 'JPG, PNG, MP4, MOV supported'}
                        </p>
                        <p className="text-[10px] mt-0.5" style={{ color: T.textMuted, opacity: 0.7 }}>
                          {isZh ? `圖片最大 ${MAX_IMAGE_MB}MB · 影片最大 ${MAX_VIDEO_MB}MB` : `Images max ${MAX_IMAGE_MB}MB · Videos max ${MAX_VIDEO_MB}MB`}
                        </p>
                      </>
                    )}
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept={MEDIA_ACCEPT}
                      multiple
                      onChange={e => e.target.files && handleFileUpload(e.target.files)}
                      className="hidden"
                    />
                  </div>

                  {uploadProgress && !uploading && (
                    <p className="text-[12px] mt-1.5" style={{ color: T.green }}>
                      <CheckCircle2 size={11} className="inline mr-1" />{uploadProgress}
                    </p>
                  )}

                  {errors.media && <p className="text-[12px] mt-1" style={{ color: T.error }}>{errors.media}</p>}

                  {/* Media preview */}
                  {form.media.length > 0 && (
                    <div className="mt-3">
                      {/* Hero image selector label */}
                      <p className="text-[11px] font-medium uppercase tracking-wider mb-2" style={{ color: T.textMuted }}>
                        <Star size={10} className="inline mr-1" />
                        {isZh ? '選擇封面圖片' : 'Choose cover image'}
                        {form.heroImage && <span className="ml-1 normal-case" style={{ color: T.green }}>✓</span>}
                      </p>
                      <div className="flex gap-2 flex-wrap">
                        {form.media.map((url, i) => {
                          const isHero = url === form.heroImage;
                          const isVideo = isVideoUrl(url);
                          return (
                            <div key={i} className="relative group">
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  if (!isVideo) {
                                    setForm(prev => ({ ...prev, heroImage: url }));
                                  } else {
                                    // Open frame capture for this video
                                    setFrameCaptureVideoUrl(url);
                                  }
                                }}
                                className="w-20 h-20 overflow-hidden cursor-pointer p-0"
                                style={{
                                  borderRadius: '10px',
                                  border: isHero ? `2.5px solid ${T.accent}` : `1px solid ${T.border}`,
                                  position: 'relative',
                                  display: 'block',
                                  background: 'none',
                                }}
                                title={isVideo ? (isZh ? '從影片擷取封面' : 'Capture cover from video') : (isZh ? '設為封面' : 'Set as cover')}
                              >
                                {isVideo ? (
                                  <div className="relative w-full h-full">
                                    <video src={url} muted preload="metadata" className="w-full h-full object-cover" />
                                    <div className="absolute inset-0 flex items-center justify-center" style={{ backgroundColor: 'rgba(0,0,0,0.35)' }}>
                                      <Scissors size={14} color="#fff" />
                                    </div>
                                  </div>
                                ) : (
                                  <ImageWithFallback src={url} alt="" className="w-full h-full object-cover" />
                                )}
                                {isHero && (
                                  <div className="absolute top-1 left-1 w-4 h-4 flex items-center justify-center"
                                    style={{ backgroundColor: T.accent, borderRadius: '50%' }}>
                                    <Star size={8} fill="#fff" color="#fff" />
                                  </div>
                                )}
                              </button>
                              <button
                                onClick={(e) => { e.stopPropagation(); removeMedia(i); }}
                                className="absolute -top-1.5 -right-1.5 w-5 h-5 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                                style={{ backgroundColor: T.error, borderRadius: '50%', border: 'none' }}
                              >
                                <X size={10} color="#fff" />
                              </button>
                            </div>
                          );
                        })}
                      </div>
                      {!form.heroImage && form.media.length > 0 && (
                        <p className="text-[11px] mt-2" style={{ color: T.accent }}>
                          {hasOnlyVideos
                            ? (isZh ? '點擊影片以擷取封面圖片' : 'Click a video to capture a cover frame')
                            : (isZh ? '點擊照片設為封面' : 'Click a photo to set as cover')}
                        </p>
                      )}
                    </div>
                  )}

                  {/* Video frame capture modal */}
                  <AnimatePresence>
                    {frameCaptureVideoUrl && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="mt-3 p-4 overflow-hidden"
                        style={{ backgroundColor: T.surfaceMuted, borderRadius: '14px', border: `1px solid ${T.accentBorder}` }}
                      >
                        <div className="flex items-center justify-between mb-3">
                          <p className="text-[12px] font-medium" style={{ color: T.text }}>
                            <Scissors size={12} className="inline mr-1.5" />
                            {isZh ? '從影片擷取封面' : 'Capture cover from video'}
                          </p>
                          <button onClick={() => setFrameCaptureVideoUrl('')}
                            className="p-1 cursor-pointer" style={{ color: T.textMuted, border: 'none', background: 'none' }}>
                            <X size={14} />
                          </button>
                        </div>
                        <p className="text-[11px] mb-3" style={{ color: T.textMuted }}>
                          {isZh ? '播放影片並在想要的畫面暫停，然後點擊「擷取畫面」' : 'Play the video, pause at the frame you want, then click "Capture Frame"'}
                        </p>
                        <video
                          ref={frameVideoRef}
                          src={frameCaptureVideoUrl}
                          controls
                          playsInline
                          preload="auto"
                          className="w-full mb-3"
                          style={{ borderRadius: '10px', maxHeight: '300px', backgroundColor: '#000' }}
                          crossOrigin="anonymous"
                        />
                        <canvas ref={frameCanvasRef} className="hidden" />
                        <button
                          onClick={captureVideoFrame}
                          disabled={frameCapturing}
                          className="flex items-center gap-2 px-4 py-2 text-[13px] font-medium cursor-pointer transition-all hover:opacity-90"
                          style={{ backgroundColor: T.accent, color: '#fff', borderRadius: '10px', border: 'none', opacity: frameCapturing ? 0.6 : 1 }}
                        >
                          {frameCapturing
                            ? <><Loader2 size={14} className="animate-spin" /> {isZh ? '擷取中...' : 'Capturing...'}</>
                            : <><Camera size={14} /> {isZh ? '擷取畫面' : 'Capture Frame'}</>
                          }
                        </button>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                {/* Contributor Info */}
                <div className="pt-2">
                  <p className="text-[13px] font-medium mb-3" style={{ color: T.text }}>
                    {isZh ? '你的資料' : 'Your Info'}
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label style={labelStyle}>{isZh ? '姓名' : 'Name'} *</label>
                      <input
                        type="text"
                        value={form.contributorName}
                        onChange={e => updateForm({ contributorName: e.target.value })}
                        placeholder={isZh ? '你的名字' : 'Your name'}
                        style={inputStyle}
                        onFocus={e => e.target.style.borderColor = T.accent}
                        onBlur={e => e.target.style.borderColor = 'rgba(0,0,0,0.06)'}
                      />
                      {errors.contributorName && <p className="text-[12px] mt-1" style={{ color: T.error }}>{errors.contributorName}</p>}
                    </div>
                    <div>
                      <label style={labelStyle}>{isZh ? '電郵' : 'Email'} *</label>
                      <input
                        type="email"
                        value={form.contributorEmail}
                        onChange={e => updateForm({ contributorEmail: e.target.value })}
                        placeholder="you@example.com"
                        style={inputStyle}
                        onFocus={e => e.target.style.borderColor = T.accent}
                        onBlur={e => e.target.style.borderColor = 'rgba(0,0,0,0.06)'}
                      />
                      {errors.contributorEmail && <p className="text-[12px] mt-1" style={{ color: T.error }}>{errors.contributorEmail}</p>}
                    </div>
                  </div>
                  <div className="mt-3">
                    <label style={labelStyle}>Instagram ({isZh ? '可選' : 'optional'})</label>
                    <input
                      type="text"
                      value={form.contributorInstagram}
                      onChange={e => updateForm({ contributorInstagram: e.target.value })}
                      placeholder="@yourhandle"
                      style={inputStyle}
                      onFocus={e => e.target.style.borderColor = T.accent}
                      onBlur={e => e.target.style.borderColor = 'rgba(0,0,0,0.06)'}
                    />
                  </div>
                </div>

                {/* Navigation */}
                <div className="flex items-center justify-between pt-4">
                  <button onClick={() => setStep('event')}
                    className="flex items-center gap-2 px-4 py-2.5 text-[13px] font-medium cursor-pointer"
                    style={{ backgroundColor: 'transparent', border: `1px solid ${T.border}`, borderRadius: '10px', color: T.textSecondary }}>
                    <ArrowLeft size={14} /> {isZh ? '返回' : 'Back'}
                  </button>
                  <button
                    onClick={() => {
                      if (validate()) setStep('review');
                    }}
                    className="flex items-center gap-2 px-6 py-2.5 text-[14px] font-medium cursor-pointer transition-all hover:opacity-90"
                    style={{ backgroundColor: T.text, color: '#fff', borderRadius: '12px', border: 'none' }}>
                    {isZh ? '審閱' : 'Review'} <ArrowRight size={16} />
                  </button>
                </div>
              </div>
            </motion.div>
          )}

          {/* ──── Step 3: Review ──── */}
          {step === 'review' && (
            <motion.div key="review" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -12 }}>
              <div className="space-y-5">
                <div className="p-5" style={{ backgroundColor: T.surface, borderRadius: '16px', border: `1px solid ${T.border}` }}>
                  {/* Event */}
                  <div className="flex items-center gap-3 pb-4 mb-4" style={{ borderBottom: `1px solid ${T.border}` }}>
                    {form.eventImage && (
                      <div className="w-14 h-14 flex-shrink-0 overflow-hidden" style={{ borderRadius: '10px' }}>
                        <ImageWithFallback src={form.eventImage} alt="" className="w-full h-full object-cover" />
                      </div>
                    )}
                    <div>
                      <p className="text-[11px] font-medium uppercase tracking-wider" style={{ color: T.textMuted }}>
                        {isZh ? '回顧活動' : 'Event Recap'}
                      </p>
                      <p className="text-[16px] font-medium" style={{ color: T.text }}>{form.eventTitle}</p>
                      <div className="flex items-center gap-3 mt-0.5">
                        {form.eventDate && <span className="text-[12px]" style={{ color: T.textMuted }}><Calendar size={10} className="inline mr-1" />{form.eventDate}</span>}
                        {form.eventVenue && <span className="text-[12px]" style={{ color: T.textMuted }}><MapPin size={10} className="inline mr-1" />{form.eventVenue}</span>}
                      </div>
                    </div>
                  </div>

                  {/* Description */}
                  <div className="mb-4">
                    <p className="text-[11px] font-medium uppercase tracking-wider mb-1" style={{ color: T.textMuted }}>
                      {isZh ? '描述' : 'Description'}
                    </p>
                    <p className="text-[14px] leading-relaxed" style={{ color: T.textSecondary }}>{form.description}</p>
                    {form.description_zh && (
                      <p className="text-[14px] leading-relaxed mt-2" style={{ color: T.textMuted }}>{form.description_zh}</p>
                    )}
                  </div>

                  {/* Media */}
                  <div className="mb-4">
                    <p className="text-[11px] font-medium uppercase tracking-wider mb-2" style={{ color: T.textMuted }}>
                      {isZh ? '媒體' : 'Media'} ({form.media.length})
                    </p>
                    {/* Hero image preview */}
                    {form.heroImage && (
                      <div className="mb-2">
                        <p className="text-[10px] font-medium uppercase tracking-wider mb-1" style={{ color: T.accent }}>
                          <Star size={8} className="inline mr-1" />{isZh ? '封面圖片' : 'Cover Image'}
                        </p>
                        <div className="w-32 h-20 overflow-hidden" style={{ borderRadius: '8px', border: `2px solid ${T.accent}` }}>
                          <ImageWithFallback src={form.heroImage} alt="Cover" className="w-full h-full object-cover" />
                        </div>
                      </div>
                    )}
                    {!form.heroImage && form.media.length > 0 && (
                      <div className="mb-2 px-3 py-2" style={{ backgroundColor: 'rgba(234,179,8,0.06)', borderRadius: '8px', border: '1px solid rgba(234,179,8,0.15)' }}>
                        <p className="text-[11px]" style={{ color: '#B45309' }}>
                          ⚠ {isZh ? '未選擇封面圖片 — 將使用第一個媒體作為封面' : 'No cover image selected — first media will be used as thumbnail'}
                        </p>
                      </div>
                    )}
                    <div className="flex gap-2 flex-wrap">
                      {form.media.map((url, i) => (
                        <div key={i} className="relative w-16 h-16 overflow-hidden" style={{ borderRadius: '8px', border: `1px solid ${T.border}` }}>
                          {isVideoUrl(url) ? (
                            <>
                              <video src={url} muted preload="metadata" className="w-full h-full object-cover" />
                              <div className="absolute inset-0 flex items-center justify-center" style={{ backgroundColor: 'rgba(0,0,0,0.3)' }}>
                                <Film size={12} color="#fff" />
                              </div>
                            </>
                          ) : (
                            <ImageWithFallback src={url} alt="" className="w-full h-full object-cover" />
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Contributor */}
                  <div className="pt-3" style={{ borderTop: `1px solid ${T.border}` }}>
                    <p className="text-[11px] font-medium uppercase tracking-wider mb-1" style={{ color: T.textMuted }}>
                      {isZh ? '提交者' : 'Submitted by'}
                    </p>
                    <p className="text-[14px]" style={{ color: T.text }}>{form.contributorName}</p>
                    <p className="text-[12px]" style={{ color: T.textMuted }}>{form.contributorEmail}</p>
                    {form.contributorInstagram && (
                      <p className="text-[12px]" style={{ color: T.textMuted }}>@{form.contributorInstagram.replace(/^@/, '')}</p>
                    )}
                  </div>
                </div>

                {errors.submit && (
                  <div className="p-3" style={{ backgroundColor: T.errorBg, borderRadius: '10px', border: `1px solid rgba(220,38,38,0.15)` }}>
                    <p className="text-[13px]" style={{ color: T.error }}>{errors.submit}</p>
                  </div>
                )}

                {/* Navigation */}
                <div className="flex items-center justify-between pt-2">
                  <button onClick={() => setStep('details')}
                    className="flex items-center gap-2 px-4 py-2.5 text-[13px] font-medium cursor-pointer"
                    style={{ backgroundColor: 'transparent', border: `1px solid ${T.border}`, borderRadius: '10px', color: T.textSecondary }}>
                    <ArrowLeft size={14} /> {isZh ? '返回' : 'Back'}
                  </button>
                  <button
                    onClick={handleSubmit}
                    disabled={submitting}
                    className="flex items-center gap-2 px-6 py-3 text-[14px] font-medium cursor-pointer transition-all hover:opacity-90"
                    style={{ backgroundColor: T.green, color: '#fff', borderRadius: '12px', border: 'none', opacity: submitting ? 0.7 : 1 }}>
                    {submitting ? (
                      <><Loader2 size={16} className="animate-spin" /> {isZh ? '提交中...' : 'Submitting...'}</>
                    ) : (
                      <><Send size={16} /> {isZh ? '提交回顧' : 'Submit Recap'}</>
                    )}
                  </button>
                </div>
              </div>
            </motion.div>
          )}

          {/* ──── Step 4: Submitted ──── */}
          {step === 'submitted' && (
            <motion.div key="submitted" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}>
              <div className="text-center py-12">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: 'spring', delay: 0.1, stiffness: 200 }}
                  className="w-16 h-16 mx-auto mb-5 flex items-center justify-center"
                  style={{ backgroundColor: T.greenBg, borderRadius: '50%' }}
                >
                  <CheckCircle2 size={32} style={{ color: T.green }} />
                </motion.div>
                <h2 className="text-2xl font-semibold mb-2" style={{ color: T.text, letterSpacing: '-0.02em' }}>
                  {isZh ? '回顧已提交！' : 'Recap Submitted!'}
                </h2>
                <p className="text-[15px] max-w-md mx-auto mb-6" style={{ color: T.textMuted, lineHeight: 1.7 }}>
                  {isZh
                    ? '感謝你分享體驗。我們的團隊會審核你的回顧，審核通過後會在網站上發佈。'
                    : 'Thanks for sharing your experience. Our team will review your recap and publish it once approved.'}
                </p>

                {submissionResult?.id && (
                  <div className="p-3 mb-6 max-w-sm mx-auto" style={{ backgroundColor: T.surfaceMuted, borderRadius: '10px', border: `1px solid ${T.border}` }}>
                    <p className="text-[11px] font-medium uppercase tracking-wider" style={{ color: T.textMuted }}>
                      {isZh ? '追蹤編號' : 'Tracking ID'}
                    </p>
                    <p className="text-[14px] font-mono mt-0.5" style={{ color: T.text }}>{submissionResult.id}</p>
                  </div>
                )}

                <div className="flex items-center justify-center gap-3">
                  <button
                    onClick={() => { setForm(emptyForm); setStep('event'); setSubmissionResult(null); setErrors({}); }}
                    className="flex items-center gap-2 px-5 py-2.5 text-[13px] font-medium cursor-pointer"
                    style={{ backgroundColor: T.text, color: '#fff', borderRadius: '10px', border: 'none' }}>
                    <Plus size={14} /> {isZh ? '提交另一個回顧' : 'Submit another recap'}
                  </button>
                  <Link to="/events"
                    className="flex items-center gap-2 px-5 py-2.5 text-[13px] font-medium no-underline"
                    style={{ backgroundColor: T.surface, color: T.text, borderRadius: '10px', border: `1px solid ${T.border}` }}>
                    <Eye size={14} /> {isZh ? '瀏覽活動' : 'Browse events'}
                  </Link>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}