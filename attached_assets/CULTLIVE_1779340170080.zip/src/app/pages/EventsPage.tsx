import { useState, useEffect } from 'react';
import { Link } from 'react-router';
import { motion } from 'motion/react';
import { CalendarDays, MapPin, Clock, Search, ArrowRight, ChevronLeft, ChevronRight, History } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { useMode } from '../context/ModeContext';
import { useData } from '../context/DataContext';
import { useTimePeriod } from '../context/TimePeriodContext';
import { modeConfig, type Mode } from '../data/mock-data';
import { ModeSelector } from '../components/ModeSelector';
import { TimePeriodFilter } from '../components/TimePeriodFilter';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import { getDesignTokens, isLightMode } from '../data/mode-styles';
import { filterEventsByTimePeriod } from '../utils/time-filter';
import { CIcon } from '../components/CIcon';
import { getEventLink, formatPrice } from '../utils/event-helpers';
import { EventGridCard } from '../components/events/EventGridCard';
import { LifestyleEventsView } from '../components/events/LifestyleEventsView';
import { parseEventDate } from '../utils/date-helpers';
import { EventFilters } from '../components/events/EventFilters';
import { computeEventStatus } from '../utils/date-helpers';
import { EventsPageSkeleton } from '../components/LoadingSkeleton';
import { useEventStats } from '../context/EventStatsContext';

// ── Past Events Collapsible Section for Events Page ──
function PastEventsSection({ allEvents, currentMode, modeColor, tokens, searchQuery, categoryFilter }: {
  allEvents: any[];
  currentMode: string | null;
  modeColor: string;
  tokens: ReturnType<typeof getDesignTokens>;
  searchQuery: string;
  categoryFilter: string | null;
}) {
  const { t } = useTranslation();
  const [showPast, setShowPast] = useState(false);
  const [showAll, setShowAll] = useState(false);
  const isArtsy = currentMode === 'artsy';
  const isDegen = currentMode === 'degen';
  const amberColor = '#F59E0B';

  // Filter past events from allEvents, applying current mode, search, and category filters
  const pastEvents = allEvents.filter((e) => {
    // Must be past
    const status = computeEventStatus(e.date, e.endDate);
    if (status !== 'past') return false;
    // Mode filter
    if (currentMode && currentMode !== 'lifestyle') {
      const modeTags = e.modeTags || [];
      const modeScores = e.modeScores || {};
      if (!modeTags.includes(currentMode) && !(modeScores[currentMode] >= 0.3)) {
        if (e.category !== currentMode) return false;
      }
    }
    // Category filter
    if (categoryFilter && e.category !== categoryFilter) return false;
    // Search filter
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      const searchableText = [
        e.title, e.venueName || '', e.district || '', e.description || '',
        ...(e.artists || []), ...(e.categories || []), ...(e.vibes || []),
      ].join(' ').toLowerCase();
      if (!searchableText.includes(q)) return false;
    }
    return true;
  }).sort((a, b) => {
    const da = parseEventDate(a.date);
    const db = parseEventDate(b.date);
    if (!da && !db) return 0;
    if (!da) return 1;
    if (!db) return -1;
    return db.getTime() - da.getTime(); // most recent first
  });

  if (pastEvents.length === 0) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
      className="mt-10 sm:mt-16"
    >
      <button
        onClick={() => setShowPast(!showPast)}
        className="flex items-center gap-2 mb-4 cursor-pointer group transition-all hover:opacity-80"
        style={{ background: 'none', border: 'none', padding: 0 }}
      >
        <History size={16} style={{ color: amberColor }} />
        <h2 style={{
          fontSize: isArtsy ? '0.85rem' : isDegen ? '1.1rem' : '1rem',
          color: tokens.textPrimary,
          fontFamily: tokens.headingFont,
          fontWeight: isDegen ? 700 : isArtsy ? 400 : 600,
          textTransform: isDegen ? 'uppercase' : undefined,
          letterSpacing: isArtsy ? '0.1em' : isDegen ? '-0.02em' : undefined,
          margin: 0,
        }}>
          {t('events.pastEvents')}
        </h2>
        <span className="px-2 py-0.5 text-[10px] font-semibold" style={{
          backgroundColor: `${amberColor}15`,
          color: amberColor,
          borderRadius: isDegen ? '2px' : '9999px',
        }}>
          {pastEvents.length}
        </span>
        <ChevronRight
          size={14}
          style={{
            color: tokens.textMuted,
            transform: showPast ? 'rotate(90deg)' : 'rotate(0deg)',
            transition: 'transform 0.2s ease',
          }}
        />
      </button>
      {showPast && (
        <div className="space-y-2" style={{ opacity: 0.75 }}>
          {pastEvents.slice(0, showAll ? pastEvents.length : 20).map((event: any) => (
            <Link
              key={event.id}
              to={getEventLink(event)}
              className="flex gap-3 p-3 transition-all no-underline hover:opacity-80"
              style={{
                borderRadius: isDegen ? '4px' : isArtsy ? '0' : '12px',
                backgroundColor: tokens.cardBg || tokens.surfaceBg,
                border: `1px solid ${tokens.cardBorder}`,
              }}
            >
              <div className="h-14 w-14 overflow-hidden flex-shrink-0" style={{
                borderRadius: isDegen ? '4px' : isArtsy ? '0' : '8px',
                filter: 'grayscale(40%)',
              }}>
                <ImageWithFallback src={event.image} alt={event.title} className="h-full w-full object-cover" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <h3 className="text-sm truncate" style={{
                    color: tokens.textSecondary,
                    fontWeight: isDegen ? 700 : 500,
                    textTransform: isDegen ? 'uppercase' : undefined,
                    fontFamily: tokens.headingFont,
                  }}>{event.title}</h3>
                  <span className="flex-shrink-0 px-1.5 py-0.5 text-[9px] font-semibold uppercase" style={{
                    backgroundColor: `${amberColor}15`,
                    color: amberColor,
                    borderRadius: isDegen ? '2px' : '4px',
                  }}>
                    {t('events.past')}
                  </span>
                </div>
                <div className="flex items-center gap-2 mt-0.5">
                  <Clock size={11} style={{ color: tokens.textMuted }} />
                  <span className="text-xs" style={{ color: tokens.textMuted }}>{event.date}{event.time ? ` · ${event.time}` : ''}</span>
                </div>
                {event.venueName && (
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <MapPin size={10} style={{ color: tokens.textMuted }} />
                    <span className="text-xs" style={{ color: tokens.textMuted }}>{event.venueName}</span>
                  </div>
                )}
              </div>
            </Link>
          ))}
          {pastEvents.length > 20 && !showAll && (
            <button
              onClick={() => setShowAll(true)}
              className="w-full flex items-center justify-center gap-2 py-3 text-xs font-semibold transition-all hover:opacity-80 cursor-pointer"
              style={{
                color: amberColor,
                backgroundColor: `${amberColor}08`,
                borderRadius: isDegen ? '4px' : isArtsy ? '0' : '12px',
                border: `1px dashed ${amberColor}40`,
              }}
            >
              <History size={12} />
              {t('events.viewAll')} ({pastEvents.length})
              <ChevronRight size={12} />
            </button>
          )}
          {showAll && pastEvents.length > 20 && (
            <button
              onClick={() => setShowAll(false)}
              className="w-full flex items-center justify-center gap-2 py-2 text-xs transition-all hover:opacity-80 cursor-pointer"
              style={{ color: tokens.textMuted }}
            >
              {t('events.showLess')}
            </button>
          )}
        </div>
      )}
    </motion.div>
  );
}

export function EventsPage() {
  const { t } = useTranslation();
  const { currentMode } = useMode();
  const { events, allEvents, hidePastEvents, loading, refresh } = useData();

  // Re-fetch data when the events page mounts (picks up newly published submissions)
  useEffect(() => { refresh(); }, []);

  // Show skeleton during initial load (no data yet)
  if (loading && events.length === 0) {
    return <EventsPageSkeleton />;
  }

  const modeColor = currentMode && currentMode !== 'lifestyle' ? modeConfig[currentMode].color : currentMode === 'lifestyle' ? '#2D6A4F' : '#8338EC';
  const tokens = getDesignTokens(currentMode);
  const light = isLightMode(currentMode);
  const isArtsy = currentMode === 'artsy';
  const isFoodie = currentMode === 'foodie';
  const isDegen = currentMode === 'degen';
  const isFamily = currentMode === 'family';
  const isLifestyle = currentMode === 'lifestyle';
  
  const [categoryFilter, setCategoryFilter] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [dateRange, setDateRange] = useState<{ start: Date | null; end: Date | null }>({ start: null, end: null });
  const [priceRange, setPriceRange] = useState<{ min: number; max: number }>({ min: 0, max: 500 });
  const [sortBy, setSortBy] = useState<'date' | 'price' | 'popularity'>('date');
  
  const EVENTS_PER_PAGE = 12;
  const { timePeriod } = useTimePeriod();

  const categories = [...new Set(events.map((e) => e.category))];

  const filteredEvents = filterEventsByTimePeriod(events, timePeriod, currentMode)
    .filter((e) => {
      if (categoryFilter && e.category !== categoryFilter) return false;
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        const searchableText = [
          e.title,
          e.venueName || '',
          e.district || '',
          e.description || '',
          ...(e.artists || []),
          ...(e.categories || []),
          ...(e.vibes || []),
        ].join(' ').toLowerCase();
        if (!searchableText.includes(q)) return false;
      }
      
      // Date range filter
      if (dateRange.start || dateRange.end) {
        const eventDate = parseEventDate(e.date);
        if (eventDate) {
          if (dateRange.start && eventDate < dateRange.start) return false;
          if (dateRange.end && eventDate > dateRange.end) return false;
        }
      }
      
      // Price filter
      if (e.price) {
        const priceNum = typeof e.price === 'number' ? e.price : parseInt(e.price.replace(/[^0-9]/g, '')) || 0;
        if (priceNum < priceRange.min || priceNum > priceRange.max) return false;
      }
      
      return true;
    })
    .sort((a, b) => {
      if (sortBy === 'date') {
        const da = parseEventDate(a.date);
        const db = parseEventDate(b.date);
        if (!da && !db) return 0;
        if (!da) return 1;
        if (!db) return -1;
        return da.getTime() - db.getTime();
      } else if (sortBy === 'price') {
        const pa = typeof a.price === 'number' ? a.price : parseInt((a.price || '0').replace(/[^0-9]/g, '')) || 0;
        const pb = typeof b.price === 'number' ? b.price : parseInt((b.price || '0').replace(/[^0-9]/g, '')) || 0;
        return pa - pb;
      } else {
        // popularity (placeholder - could use view count, saved count, etc.)
        return 0;
      }
    });

  // Reset page when filters change
  useEffect(() => { setCurrentPage(1); }, [categoryFilter, searchQuery, timePeriod, currentMode, dateRange, priceRange, sortBy]);

  const handleResetFilters = () => {
    setCategoryFilter(null);
    setDateRange({ start: null, end: null });
    setPriceRange({ min: 0, max: 500 });
    setSortBy('date');
  };

  // Shared pagination
  const totalPages = Math.max(1, Math.ceil(filteredEvents.length / EVENTS_PER_PAGE));
  const safePage = Math.min(currentPage, totalPages);
  const pageStart = (safePage - 1) * EVENTS_PER_PAGE;
  const pageEnd = pageStart + EVENTS_PER_PAGE;
  const paginatedEvents = filteredEvents.slice(pageStart, pageEnd);

  // Batch-load event stats (views + going counts) for displayed events
  const { fetchBatchStats } = useEventStats();
  const paginatedIds = paginatedEvents.map(e => e.id).join(',');
  useEffect(() => {
    const ids = paginatedIds.split(',').filter(Boolean);
    if (ids.length > 0) fetchBatchStats(ids);
  }, [paginatedIds, fetchBatchStats]);

  // Shared pagination controls renderer
  const renderPagination = (color: string) => {
    if (totalPages <= 1) return null;
    return (
      <div className="flex items-center justify-center gap-2 mt-10 sm:mt-14">
        <button
          onClick={() => { setCurrentPage(p => Math.max(1, p - 1)); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
          disabled={safePage <= 1}
          className="flex items-center gap-1.5 px-4 py-2.5 text-sm transition-all disabled:opacity-30 disabled:cursor-not-allowed hover:scale-[1.02]"
          style={{
            backgroundColor: safePage <= 1 ? 'rgba(0,0,0,0.04)' : `${color}12`,
            color: safePage <= 1 ? tokens.textMuted : color,
            borderRadius: '10px', fontWeight: 600, fontFamily: tokens.headingFont,
          }}
        >
          <ChevronLeft size={16} /> Previous
        </button>
        <div className="flex items-center gap-1">
          {Array.from({ length: totalPages }, (_, i) => i + 1)
            .filter(p => p === 1 || p === totalPages || Math.abs(p - safePage) <= 1)
            .reduce<(number | 'ellipsis')[]>((acc, p, i, arr) => {
              if (i > 0 && p - (arr[i - 1] as number) > 1) acc.push('ellipsis');
              acc.push(p);
              return acc;
            }, [])
            .map((item, i) =>
              item === 'ellipsis' ? (
                <span key={`e${i}`} className="px-1 text-xs" style={{ color: tokens.textMuted }}>...</span>
              ) : (
                <button
                  key={item}
                  onClick={() => { setCurrentPage(item as number); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="w-9 h-9 flex items-center justify-center text-sm transition-all rounded-lg"
                  style={
                    item === safePage
                      ? { backgroundColor: color, color: '#fff', fontWeight: 700, fontFamily: tokens.headingFont }
                      : { color: tokens.textMuted, fontFamily: tokens.headingFont }
                  }
                >
                  {item}
                </button>
              )
            )}
        </div>
        <button
          onClick={() => { setCurrentPage(p => Math.min(totalPages, p + 1)); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
          disabled={safePage >= totalPages}
          className="flex items-center gap-1.5 px-4 py-2.5 text-sm transition-all disabled:opacity-30 disabled:cursor-not-allowed hover:scale-[1.02]"
          style={{
            backgroundColor: safePage >= totalPages ? 'rgba(0,0,0,0.04)' : `${color}12`,
            color: safePage >= totalPages ? tokens.textMuted : color,
            borderRadius: '10px', fontWeight: 600, fontFamily: tokens.headingFont,
          }}
        >
          Next <ChevronRight size={16} />
        </button>
      </div>
    );
  };

  const renderResultsCount = () => {
    if (filteredEvents.length === 0) return null;
    return (
      <div className="flex items-center justify-between mb-6">
        <p className="text-xs" style={{ color: tokens.textMuted }}>
          Showing {pageStart + 1}–{Math.min(pageEnd, filteredEvents.length)} of {filteredEvents.length} events
        </p>
        {totalPages > 1 && (
          <p className="text-xs" style={{ color: tokens.textMuted }}>
            Page {safePage} of {totalPages}
          </p>
        )}
      </div>
    );
  };

  // ══════════════════════════════════════════════
  // ARTSY — editorial alternating layout
  // ══════════════════════════════════════════════
  if (isArtsy) {
    return (
      <div className="min-h-screen" data-nav-theme="dark">
        {/* Editorial header */}
        <div className="px-4 sm:px-8 lg:px-12 py-10 sm:py-20 lg:py-28 max-w-[1440px] mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          >
            <span
              className="block mb-2 sm:mb-4 tracking-[0.3em] uppercase"
              style={{ fontSize: '0.6rem', color: tokens.textMuted, fontFamily: tokens.bodyFont }}
            >
              Programme
            </span>
            <h1
              className="mb-4 sm:mb-6"
              style={{
                fontFamily: tokens.headingFont,
                fontSize: 'clamp(1.5rem, 4vw, 3.5rem)',
                color: tokens.textPrimary,
                fontWeight: 400,
                lineHeight: 1.08,
              }}
            >
              What's <em style={{ fontStyle: 'italic' }}>Showing</em>
            </h1>
            <div className="w-12 h-px mb-4 sm:mb-8" style={{ backgroundColor: tokens.textMuted }} />
            <p
              className="max-w-md hidden sm:block"
              style={{
                fontFamily: tokens.bodyFont,
                fontSize: '0.95rem',
                color: tokens.textSecondary,
                lineHeight: 1.8,
              }}
            >
              A curated selection of exhibitions, performances, and cultural experiences
              across Hong Kong's most compelling spaces.
            </p>
          </motion.div>

          {/* Controls */}
          <div className="mt-6 sm:mt-12 flex flex-col sm:flex-row gap-4 sm:gap-6 items-start sm:items-center justify-between">
            <ModeSelector compact />
            <div className="flex gap-3 sm:gap-4 items-center overflow-x-auto scrollbar-hide">
              {/* Search input — minimal editorial style */}
              <div className="relative">
                <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: tokens.textMuted }} />
                <input
                  type="text"
                  placeholder="Search programme..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-8 pr-4 py-1.5 text-xs w-40 sm:w-48 focus:outline-none"
                  style={{
                    backgroundColor: 'transparent',
                    borderBottom: `1px solid ${tokens.textMuted}40`,
                    color: tokens.textPrimary,
                    fontFamily: tokens.bodyFont,
                    letterSpacing: '0.05em',
                  }}
                />
              </div>
              {/* Category filters — minimal pill style */}
              <div className="flex gap-3">
                <button
                  onClick={() => setCategoryFilter(null)}
                  className="transition-all"
                  style={{
                    fontSize: '0.7rem',
                    letterSpacing: '0.15em',
                    color: !categoryFilter ? tokens.textPrimary : tokens.textMuted,
                    borderBottom: !categoryFilter ? `1px solid ${tokens.textPrimary}` : '1px solid transparent',
                    paddingBottom: '4px',
                  }}
                >
                  ALL
                </button>
                {categories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setCategoryFilter(categoryFilter === cat ? null : cat)}
                    className="transition-all"
                    style={{
                      fontSize: '0.7rem',
                      letterSpacing: '0.15em',
                      color: categoryFilter === cat ? tokens.textPrimary : tokens.textMuted,
                      borderBottom: categoryFilter === cat ? `1px solid ${tokens.textPrimary}` : '1px solid transparent',
                      paddingBottom: '4px',
                    }}
                  >
                    {cat.toUpperCase()}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Time period tabs */}
          <TimePeriodFilter className="mt-4 sm:mt-8" />
        </div>

        {/* Events — editorial grid */}
        <div className="max-w-[1440px] mx-auto px-4 sm:px-8 lg:px-12 pb-12 sm:pb-24">
          {filteredEvents.length === 0 ? (
            <div className="text-center py-20">
              <p style={{ color: tokens.textMuted, fontFamily: tokens.bodyFont }}>
                {t('events.noEvents')}
              </p>
            </div>
          ) : (
            <>
            {renderResultsCount()}
            <div className="space-y-10 sm:space-y-20">
              {paginatedEvents.map((event, i) => (
                <motion.div
                  key={event.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
                >
                  <Link to={getEventLink(event)} className="group block">
                    <div className={`grid grid-cols-1 lg:grid-cols-12 gap-4 sm:gap-8 items-start ${i % 2 === 1 ? 'lg:direction-rtl' : ''}`}>
                      {/* Image — alternating sides */}
                      <div className={`${i % 2 === 0 ? 'lg:col-span-7' : 'lg:col-span-7 lg:col-start-6'}`}>
                        <div className="overflow-hidden aspect-[4/3]">
                          <ImageWithFallback
                            src={event.image}
                            alt={event.title}
                            className="h-full w-full object-cover transition-transform duration-1000 group-hover:scale-[1.02]"
                            style={{ filter: 'contrast(1.05)' }}
                          />
                        </div>
                      </div>

                      {/* Text */}
                      <div className={`${i % 2 === 0 ? 'lg:col-span-5' : 'lg:col-span-5 lg:col-start-1 lg:row-start-1'} flex flex-col justify-center`}>
                        <div className="flex items-center gap-2 mb-2 sm:mb-3">
                          <span
                            className="tracking-[0.25em] uppercase"
                            style={{ fontSize: '0.55rem', color: tokens.textMuted, fontFamily: tokens.bodyFont }}
                          >
                            {event.category}
                          </span>
                          {event.id?.startsWith('ra_') && (
                            <span className="px-1.5 py-0.5 tracking-wider" style={{ backgroundColor: '#6366F115', color: '#6366F1', fontSize: '0.5rem', fontWeight: 600, borderRadius: '2px' }}>RA</span>
                          )}
                          {event.id?.startsWith('sub_') && (
                            <span className="px-1.5 py-0.5 tracking-wider" style={{ backgroundColor: '#8B5CF615', color: '#8B5CF6', fontSize: '0.5rem', fontWeight: 600, borderRadius: '2px' }}>COMMUNITY</span>
                          )}
                        </div>

                        <h2
                          className="mb-2 sm:mb-4"
                          style={{
                            fontFamily: tokens.headingFont,
                            fontSize: 'clamp(1.3rem, 2.5vw, 2rem)',
                            color: tokens.textPrimary,
                            fontWeight: 400,
                            lineHeight: 1.15,
                          }}
                        >
                          {event.title}
                        </h2>

                        <div className="w-8 h-px mb-2 sm:mb-4" style={{ backgroundColor: tokens.textMuted }} />

                        <p
                          className="mb-3 sm:mb-6 max-w-sm hidden sm:block"
                          style={{
                            fontFamily: tokens.bodyFont,
                            fontSize: '0.9rem',
                            color: tokens.textSecondary,
                            lineHeight: 1.7,
                          }}
                        >
                          {event.description && event.description.length > 200
                            ? event.description.slice(0, 200).trimEnd() + '…'
                            : event.description}
                        </p>

                        <div className="space-y-1 mb-3 sm:mb-6">
                          <span
                            className="block"
                            style={{ fontSize: '0.7rem', color: tokens.textMuted, fontFamily: tokens.bodyFont }}
                          >
                            {event.venueName}, {event.district}
                          </span>
                          <span
                            className="block"
                            style={{ fontSize: '0.7rem', color: tokens.textMuted, fontFamily: tokens.bodyFont }}
                          >
                            {event.date} — {event.time}
                          </span>
                        </div>

                        <span
                          className="inline-flex items-center gap-2 group/link"
                          style={{
                            fontFamily: tokens.headingFont,
                            fontSize: '0.7rem',
                            color: tokens.textPrimary,
                            letterSpacing: '0.15em',
                          }}
                        >
                          <span className="uppercase">Details</span>
                          <ArrowRight size={12} className="transition-transform group-hover:translate-x-1" />
                        </span>
                      </div>
                    </div>
                  </Link>
                </motion.div>
              ))}
            </div>
            {renderPagination(modeColor)}
            {hidePastEvents && <PastEventsSection allEvents={allEvents} currentMode={currentMode} modeColor={modeColor} tokens={tokens} searchQuery={searchQuery} categoryFilter={categoryFilter} />}
            </>
          )}
        </div>
      </div>
    );
  }

  // ══════════════════════════════════════════════
  // FOODIE — dark cinematic grid cards
  // ══════════════════════════════════════════════
  if (isFoodie) {
    return (
      <div className="min-h-screen" data-nav-theme="light">
        {/* Header */}
        <div className="relative overflow-hidden py-8 sm:py-16 px-4 sm:px-6 lg:px-8">
          <div
            className="absolute inset-0 opacity-10"
            style={{
              background: `radial-gradient(ellipse at 50% 0%, ${modeColor}, transparent 70%)`,
            }}
          />
          <div className="relative max-w-[1200px] mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <div className="flex items-center gap-2 mb-3">
                <CalendarDays size={16} style={{ color: modeColor }} />
                <span className="text-xs tracking-[0.2em] uppercase" style={{ color: `${modeColor}cc` }}>
                  {currentMode ? `${modeConfig[currentMode].label} ${t('nav.events')}` : t('events.allEvents')}
                </span>
              </div>
              <h1 style={{ fontSize: 'clamp(1.3rem, 3vw, 2.5rem)', color: tokens.textPrimary, fontFamily: tokens.headingFont }}>
                What's Happening
              </h1>
              <p className="max-w-lg text-sm mt-2 hidden sm:block" style={{ color: tokens.textMuted }}>
                Discover curated cultural events across Hong Kong. Switch modes to see events that match your vibe.
              </p>
            </motion.div>

            {/* Controls */}
            <div className="mt-6 sm:mt-8 flex flex-col sm:flex-row gap-3 sm:gap-4 items-start sm:items-center justify-between">
              <ModeSelector compact />

              <div className="flex gap-2 items-center w-full sm:w-auto">
                <div className="relative w-full sm:w-auto">
                  <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: tokens.textMuted }} />
                  <input
                    type="text"
                    placeholder="Search events..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9 pr-4 py-2 text-sm w-full sm:w-48 focus:outline-none"
                    style={{
                      backgroundColor: 'rgba(0,0,0,0.04)',
                      border: '2px solid rgba(0,0,0,0.1)',
                      borderRadius: '4px',
                      color: tokens.textPrimary,
                      fontFamily: tokens.headingFont,
                    }}
                  />
                </div>
              </div>
            </div>

            {/* Time period tabs */}
            <TimePeriodFilter className="mt-4 sm:mt-6" />

            {/* Category pills — bold poster style */}
            <div className="mt-4 flex gap-2 overflow-x-auto pb-2">
              <button
                onClick={() => setCategoryFilter(null)}
                className="flex-shrink-0 px-4 py-2 text-xs transition-all"
                style={!categoryFilter
                  ? { backgroundColor: '#0A0A0A', color: '#EDFF00', borderRadius: '4px', fontFamily: tokens.headingFont, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.03em' }
                  : { backgroundColor: 'transparent', color: tokens.textMuted, border: '2px solid rgba(0,0,0,0.1)', borderRadius: '4px', fontFamily: tokens.headingFont, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.03em' }
                }
              >
                ALL
              </button>
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setCategoryFilter(categoryFilter === cat ? null : cat)}
                  className="flex-shrink-0 px-4 py-2 text-xs transition-all"
                  style={categoryFilter === cat
                    ? { backgroundColor: '#0A0A0A', color: '#EDFF00', borderRadius: '4px', fontFamily: tokens.headingFont, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.03em' }
                    : { backgroundColor: 'transparent', color: tokens.textMuted, border: '2px solid rgba(0,0,0,0.1)', borderRadius: '4px', fontFamily: tokens.headingFont, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.03em' }
                  }
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Events grid — uses shared EventGridCard */}
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 pb-8 sm:pb-16">
          {filteredEvents.length === 0 ? (
            <div className="text-center py-20">
              <p style={{ color: tokens.textMuted }} className="mb-2">{t('events.noEvents')}</p>
              <p className="text-xs" style={{ color: tokens.textMuted }}>{t('events.noEventsDesc')}</p>
            </div>
          ) : (
            <>
            {renderResultsCount()}
            <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-6">
              {paginatedEvents.map((event, i) => (
                <EventGridCard key={event.id} event={event} index={i} modeColor={modeColor} tokens={tokens} />
              ))}
            </div>
            {renderPagination(modeColor)}
            </>
          )}
          {hidePastEvents && <PastEventsSection allEvents={allEvents} currentMode={currentMode} modeColor={modeColor} tokens={tokens} searchQuery={searchQuery} categoryFilter={categoryFilter} />}
        </div>
      </div>
    );
  }

  // ══════════════════════════════════════════════
  // DEGEN — brutalist poster list
  // ══════════════════════════════════════════════
  if (isDegen) {
    return (
      <div className="min-h-screen" data-nav-theme="dark">
        {/* Header */}
        <div className="relative overflow-hidden py-8 sm:py-16 px-4 sm:px-6 lg:px-8">
          <div className="relative max-w-[1200px] mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <span className="block mb-2 sm:mb-3 text-xs" style={{ color: 'rgba(0,0,0,0.25)', letterSpacing: '0.1em' }}>/EVENTS</span>
              <h1 style={{ fontSize: 'clamp(1.5rem, 4vw, 3.5rem)', color: '#0A0A0A', fontFamily: tokens.headingFont, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '-0.03em' }}>
                WHAT'S{' '}
                <span style={{ color: '#D600FF' }}>ON</span>
              </h1>
              <p className="max-w-lg text-sm mt-2 hidden sm:block" style={{ color: tokens.textMuted }}>
                Late-night culture, underground scenes, and the events the tourists won't find.
              </p>
            </motion.div>

            {/* Controls */}
            <div className="mt-8 flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
              <ModeSelector compact />

              <div className="flex gap-2 items-center w-full sm:w-auto">
                <div className="relative w-full sm:w-auto">
                  <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: tokens.textMuted }} />
                  <input
                    type="text"
                    placeholder="Search events..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9 pr-4 py-2 text-sm w-full sm:w-48 focus:outline-none"
                    style={{
                      backgroundColor: 'rgba(0,0,0,0.04)',
                      border: '2px solid rgba(0,0,0,0.1)',
                      borderRadius: '4px',
                      color: tokens.textPrimary,
                      fontFamily: tokens.headingFont,
                    }}
                  />
                </div>
              </div>
            </div>

            {/* Time period tabs — Degen brutalist */}
            <TimePeriodFilter className="mt-6" />

            {/* Category pills — bold poster style */}
            <div className="mt-4 flex gap-2 overflow-x-auto pb-2">
              <button
                onClick={() => setCategoryFilter(null)}
                className="flex-shrink-0 px-4 py-2 text-xs transition-all"
                style={!categoryFilter
                  ? { backgroundColor: '#0A0A0A', color: '#EDFF00', borderRadius: '4px', fontFamily: tokens.headingFont, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.03em' }
                  : { backgroundColor: 'transparent', color: tokens.textMuted, border: '2px solid rgba(0,0,0,0.1)', borderRadius: '4px', fontFamily: tokens.headingFont, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.03em' }
                }
              >
                ALL
              </button>
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setCategoryFilter(categoryFilter === cat ? null : cat)}
                  className="flex-shrink-0 px-4 py-2 text-xs transition-all"
                  style={categoryFilter === cat
                    ? { backgroundColor: '#0A0A0A', color: '#EDFF00', borderRadius: '4px', fontFamily: tokens.headingFont, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.03em' }
                    : { backgroundColor: 'transparent', color: tokens.textMuted, border: '2px solid rgba(0,0,0,0.1)', borderRadius: '4px', fontFamily: tokens.headingFont, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.03em' }
                  }
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Events — poster list style */}
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 pb-16">
          {filteredEvents.length === 0 ? (
            <div className="text-center py-20">
              <p style={{ color: tokens.textMuted }} className="mb-2">{t('events.noEvents')}</p>
              <p className="text-xs" style={{ color: tokens.textMuted }}>{t('events.noEventsDesc')}</p>
            </div>
          ) : (
            <>
            {renderResultsCount()}
            <div className="space-y-1">
              {paginatedEvents.map((event, i) => (
                <motion.div
                  key={event.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.04 }}
                >
                  <Link
                    to={getEventLink(event)}
                    className="group flex flex-row gap-3 sm:gap-5 items-center py-3 sm:py-5 transition-all hover:bg-black/[0.03]"
                    style={{ borderBottom: '2px solid rgba(0,0,0,0.06)' }}
                  >
                    {/* Image */}
                    <div className="hidden sm:block w-28 h-20 flex-shrink-0 overflow-hidden" style={{ borderRadius: '4px' }}>
                      <ImageWithFallback
                        src={event.image}
                        alt={event.title}
                        className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
                        style={{ filter: 'contrast(1.1)' }}
                      />
                    </div>

                    {/* Info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-1.5 sm:gap-3 mb-0.5 sm:mb-1">
                        <span
                          className="px-2 py-0.5"
                          style={{
                            backgroundColor: '#D600FF',
                            color: '#fff',
                            borderRadius: '2px',
                            fontSize: '0.6rem',
                            fontWeight: 700,
                            fontFamily: tokens.headingFont,
                            textTransform: 'uppercase',
                          }}
                        >
                          {event.category}
                        </span>
                        {event.id?.startsWith('ra_') && (
                          <span className="px-1.5 py-0.5" style={{ backgroundColor: '#6366F1', color: '#fff', borderRadius: '2px', fontSize: '0.55rem', fontWeight: 700, fontFamily: tokens.headingFont, textTransform: 'uppercase' }}>RA</span>
                        )}
                        {event.id?.startsWith('sub_') && (
                          <span className="px-1.5 py-0.5" style={{ backgroundColor: '#8B5CF6', color: '#fff', borderRadius: '2px', fontSize: '0.55rem', fontWeight: 700, fontFamily: tokens.headingFont, textTransform: 'uppercase' }}>COMMUNITY</span>
                        )}
                        {event.status === 'ongoing' && (
                          <span className="flex items-center gap-1 text-xs" style={{ color: '#22c55e', fontWeight: 700 }}>
                            <span className="h-1.5 w-1.5 rounded-full bg-green-500 animate-pulse" /> LIVE
                          </span>
                        )}
                        <span style={{ fontSize: '0.65rem', color: tokens.textMuted, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                          {event.date} · {event.time}
                        </span>
                      </div>
                      <h3
                        className="group-hover:opacity-70 transition-opacity"
                        style={{
                          fontFamily: tokens.headingFont,
                          fontSize: 'clamp(0.95rem, 2vw, 1.3rem)',
                          color: '#0A0A0A',
                          fontWeight: 700,
                          textTransform: 'uppercase',
                          letterSpacing: '-0.02em',
                        }}
                      >
                        {event.title}
                      </h3>
                      <span style={{ fontSize: '0.75rem', color: tokens.textMuted }}>
                        {event.venueName} · {event.district}
                      </span>
                    </div>

                    {/* Price + tags */}
                    <div className="flex items-center gap-2 sm:gap-3 flex-shrink-0">
                      <div className="flex gap-1">
                        {(event.modeTags || []).filter(tag => modeConfig[tag as keyof typeof modeConfig]).map((tag) => (
                          <span
                            key={tag}
                            className="px-1.5 py-0.5 text-xs inline-flex items-center"
                            style={{ backgroundColor: `${modeConfig[tag as keyof typeof modeConfig].color}15`, color: modeConfig[tag as keyof typeof modeConfig].color, borderRadius: '2px', fontSize: '0.65rem' }}
                          >
                            <CIcon id={tag} size={11} />
                          </span>
                        ))}
                      </div>
                      <span
                        className="px-3 py-1.5"
                        style={{
                          border: '2px solid #0A0A0A',
                          borderRadius: '4px',
                          fontSize: '0.75rem',
                          color: '#0A0A0A',
                          fontWeight: 700,
                          fontFamily: tokens.headingFont,
                        }}
                      >
                        {formatPrice(event.price)}
                      </span>
                    </div>
                  </Link>
                </motion.div>
              ))}
            </div>
            {renderPagination('#D600FF')}
            </>
          )}
          {hidePastEvents && <PastEventsSection allEvents={allEvents} currentMode={currentMode} modeColor={modeColor} tokens={tokens} searchQuery={searchQuery} categoryFilter={categoryFilter} />}
        </div>
      </div>
    );
  }

  // ══════════════════════════════════════════════
  // FAMILY — warm playful grid
  // ══════════════════════════════════════════════
  if (isFamily) {
    return (
      <div className="min-h-screen" data-nav-theme="dark">
        {/* Header */}
        <div className="relative overflow-hidden py-8 sm:py-16 px-4 sm:px-6 lg:px-8">
          <div className="relative max-w-[1200px] mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <div className="flex items-center gap-2 mb-3">
                <span className="text-xs tracking-[0.1em]" style={{ color: '#FF8C42', fontFamily: tokens.headingFont, fontWeight: 700 }}>
                  FAMILY EVENTS
                </span>
              </div>
              <h1 style={{ fontSize: 'clamp(1.5rem, 3vw, 2.5rem)', color: tokens.textPrimary, fontFamily: tokens.headingFont, fontWeight: 800 }}>
                Fun Things to{' '}
                <span style={{ color: '#FF8C42' }}>Do</span>
              </h1>
              <p className="max-w-lg text-sm mt-2 hidden sm:block" style={{ color: tokens.textMuted, fontFamily: tokens.bodyFont }}>
                Kid-friendly workshops, outdoor adventures, and family events curated for parents in Hong Kong.
              </p>
            </motion.div>

            {/* Controls */}
            <div className="mt-6 sm:mt-8 flex flex-col sm:flex-row gap-3 sm:gap-4 items-start sm:items-center justify-between">
              <ModeSelector compact />

              <div className="flex gap-2 items-center w-full sm:w-auto">
                <div className="relative w-full sm:w-auto">
                  <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: tokens.textMuted }} />
                  <input
                    type="text"
                    placeholder="Search events..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9 pr-4 py-2 text-sm w-full sm:w-48 focus:outline-none"
                    style={{
                      backgroundColor: 'rgba(0,0,0,0.04)',
                      border: '2px solid rgba(0,0,0,0.1)',
                      borderRadius: '4px',
                      color: tokens.textPrimary,
                      fontFamily: tokens.headingFont,
                    }}
                  />
                </div>
              </div>
            </div>

            {/* Category pills — bold poster style */}
            <div className="mt-4 flex gap-2 overflow-x-auto pb-2">
              <button
                onClick={() => setCategoryFilter(null)}
                className="flex-shrink-0 px-4 py-2 text-xs transition-all"
                style={!categoryFilter
                  ? { backgroundColor: '#0A0A0A', color: '#EDFF00', borderRadius: '4px', fontFamily: tokens.headingFont, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.03em' }
                  : { backgroundColor: 'transparent', color: tokens.textMuted, border: '2px solid rgba(0,0,0,0.1)', borderRadius: '4px', fontFamily: tokens.headingFont, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.03em' }
                }
              >
                ALL
              </button>
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setCategoryFilter(categoryFilter === cat ? null : cat)}
                  className="flex-shrink-0 px-4 py-2 text-xs transition-all"
                  style={categoryFilter === cat
                    ? { backgroundColor: '#0A0A0A', color: '#EDFF00', borderRadius: '4px', fontFamily: tokens.headingFont, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.03em' }
                    : { backgroundColor: 'transparent', color: tokens.textMuted, border: '2px solid rgba(0,0,0,0.1)', borderRadius: '4px', fontFamily: tokens.headingFont, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.03em' }
                  }
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Time period tabs — Family playful */}
            <TimePeriodFilter className="mt-4" />
          </div>
        </div>

        {/* Events grid — uses shared EventGridCard */}
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 pb-8 sm:pb-16">
          {filteredEvents.length === 0 ? (
            <div className="text-center py-20">
              <p style={{ color: tokens.textMuted }} className="mb-2">{t('events.noEvents')}</p>
              <p className="text-xs" style={{ color: tokens.textMuted }}>{t('events.noEventsDesc')}</p>
            </div>
          ) : (
            <>
            {renderResultsCount()}
            <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-6">
              {paginatedEvents.map((event, i) => (
                <EventGridCard key={event.id} event={event} index={i} modeColor={modeColor} tokens={tokens} />
              ))}
            </div>
            {renderPagination('#FF8C42')}
            </>
          )}
          {hidePastEvents && <PastEventsSection allEvents={allEvents} currentMode={currentMode} modeColor={modeColor} tokens={tokens} searchQuery={searchQuery} categoryFilter={categoryFilter} />}
        </div>
      </div>
    );
  }

  // ══════════════════════════════════════════════
  // LIFESTYLE
  // ══════════════════════════════════════════════
  if (isLifestyle) {
    return <LifestyleEventsView />;
  }

  // ══════════════════════════════════════════════
  // DEFAULT — neutral/no-mode events page
  // ══════════════════════════════════════════════

  // Group events by month for neutral view
  const MONTH_NAMES = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

  const monthGroups: { key: string; label: string; events: typeof filteredEvents }[] = (() => {
    const groups = new Map<string, typeof filteredEvents>();
    const ungrouped: typeof filteredEvents = [];

    for (const event of filteredEvents) {
      const d = parseEventDate(event.date);
      if (d) {
        const key = `${d.getFullYear()}-${String(d.getMonth()).padStart(2, '0')}`;
        const label = `${MONTH_NAMES[d.getMonth()]} ${d.getFullYear()}`;
        if (!groups.has(key)) groups.set(key, []);
        groups.get(key)!.push(event);
      } else {
        ungrouped.push(event);
      }
    }

    const sorted = [...groups.entries()]
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([key, evts]) => {
        const [y, m] = key.split('-');
        return { key, label: `${MONTH_NAMES[parseInt(m)]} ${y}`, events: evts };
      });

    if (ungrouped.length > 0) {
      sorted.push({ key: 'undated', label: 'Upcoming', events: ungrouped });
    }

    return sorted;
  })();

  // Build month groups for the current page slice
  const pageMonthGroups: typeof monthGroups = (() => {
    const result: typeof monthGroups = [];
    let cursor = 0;
    for (const group of monthGroups) {
      const groupEnd = cursor + group.events.length;
      if (groupEnd > pageStart && cursor < pageEnd) {
        const sliceStart = Math.max(0, pageStart - cursor);
        const sliceEnd = Math.min(group.events.length, pageEnd - cursor);
        result.push({ ...group, events: group.events.slice(sliceStart, sliceEnd) });
      }
      cursor = groupEnd;
    }
    return result;
  })();

  const eLabelStyle: React.CSSProperties = {
    fontSize: '0.6rem',
    fontWeight: 600,
    letterSpacing: '0.18em',
    textTransform: 'uppercase',
    color: '#B5B0A8',
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#FAFAF8' }} data-nav-theme="dark">
      {/* Editorial Header */}
      <div className="max-w-[1440px] mx-auto px-5 sm:px-10 lg:px-14 pt-10 sm:pt-16 pb-6 sm:pb-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        >
          <div className="h-px w-full mb-8" style={{ backgroundColor: '#E8E4DE' }} />

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '1.5rem' }}>
            <div>
              <span style={eLabelStyle}>What's On</span>
            </div>
            <div>
              <h1 style={{
                fontFamily: "'Archivo Black', sans-serif",
                fontSize: 'clamp(1.5rem, 3.5vw, 2.8rem)',
                color: '#1A1A1A',
                letterSpacing: '-0.03em',
                lineHeight: 1.05,
              }}>
                {t('events.allEvents')}
              </h1>
              <p className="mt-3 max-w-md hidden sm:block" style={{ fontSize: '0.85rem', color: '#A09B93', lineHeight: 1.65 }}>
                Discover curated cultural events across Hong Kong. Switch modes to see events that match your vibe.
              </p>
            </div>
          </div>
        </motion.div>

        {/* Controls — full width */}
        <div className="mt-8 flex flex-col gap-4">
          <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 items-start sm:items-center justify-between">
              <ModeSelector compact />
              <div className="relative w-full sm:w-auto">
                <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: '#B5B0A8' }} />
                <input
                  type="text"
                  placeholder="Search events..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-8 pr-4 py-2 text-xs w-full sm:w-52 focus:outline-none"
                  style={{
                    backgroundColor: 'transparent',
                    borderBottom: '1px solid #E8E4DE',
                    color: '#1A1A1A',
                    fontFamily: "'Inter', sans-serif",
                  }}
                />
              </div>
            </div>

            {/* Category pills — editorial */}
          <div className="flex gap-2 flex-wrap pb-2">
              <button
                onClick={() => setCategoryFilter(null)}
                className="flex-shrink-0 px-3.5 py-1.5 text-xs transition-all cursor-pointer"
                style={!categoryFilter
                  ? { backgroundColor: '#1A1A1A', color: '#fff', borderRadius: '8px', fontWeight: 600 }
                  : { backgroundColor: 'transparent', color: '#A09B93', border: '1px solid #E8E4DE', borderRadius: '8px', fontWeight: 500 }
                }
              >
                All
              </button>
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setCategoryFilter(categoryFilter === cat ? null : cat)}
                  className="flex-shrink-0 px-3.5 py-1.5 text-xs transition-all cursor-pointer"
                  style={categoryFilter === cat
                    ? { backgroundColor: '#1A1A1A', color: '#fff', borderRadius: '8px', fontWeight: 600 }
                    : { backgroundColor: 'transparent', color: '#A09B93', border: '1px solid #E8E4DE', borderRadius: '8px', fontWeight: 500 }
                  }
                >
                  {cat}
                </button>
              ))}
            </div>

          <TimePeriodFilter />
        </div>
      </div>

      {/* Events grid — grouped by month */}
      <div className="max-w-[1440px] mx-auto px-5 sm:px-10 lg:px-14 pb-10 sm:pb-20">
        {filteredEvents.length === 0 ? (
          <div className="text-center py-20">
            <p style={{ color: '#A09B93' }} className="mb-2">{t('events.noEvents')}</p>
            <p className="text-xs" style={{ color: '#B5B0A8' }}>{t('events.noEventsDesc')}</p>
          </div>
        ) : (
          <>
            {/* Results count */}
            <div className="mb-6 flex items-center justify-between">
              <p className="text-xs" style={{ color: '#B5B0A8' }}>
                Showing {pageStart + 1}–{Math.min(pageEnd, filteredEvents.length)} of {filteredEvents.length} events
              </p>
              {totalPages > 1 && (
                <p className="text-xs" style={{ color: '#B5B0A8' }}>
                  Page {safePage} of {totalPages}
                </p>
              )}
            </div>

            {/* Month-grouped events */}
            <div className="space-y-10 sm:space-y-14">
              {pageMonthGroups.map((group) => (
                <div key={group.key}>
                  {/* Month header — editorial */}
                  <div className="mb-5 sm:mb-8 flex items-center gap-4">
                    <span style={eLabelStyle} className="flex-shrink-0">{group.label}</span>
                    <div className="flex-1 h-px" style={{ backgroundColor: '#E8E4DE' }} />
                    <span className="text-xs px-2.5 py-1 flex-shrink-0" style={{ backgroundColor: '#1A1A1A08', color: '#A09B93', fontWeight: 600, borderRadius: '8px' }}>
                      {group.events.length} event{group.events.length !== 1 ? 's' : ''}
                    </span>
                  </div>

                  {/* Events grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-5">
                    {group.events.map((event, i) => (
                      <EventGridCard key={event.id} event={event} index={i} modeColor="#1A1A1A" tokens={tokens} />
                    ))}
                  </div>
                </div>
              ))}
            </div>

            {renderPagination('#1A1A1A')}
          </>
        )}

        {hidePastEvents && <PastEventsSection allEvents={allEvents} currentMode={currentMode} modeColor={modeColor} tokens={tokens} searchQuery={searchQuery} categoryFilter={categoryFilter} />}
      </div>
    </div>
  );
}