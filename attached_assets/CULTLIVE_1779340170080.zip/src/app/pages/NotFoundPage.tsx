import { Link } from 'react-router';
import { Home } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { useMode } from '../context/ModeContext';
import { getDesignTokens, isLightMode } from '../data/mode-styles';

export function NotFoundPage() {
  const { t } = useTranslation();
  const { currentMode } = useMode();
  const tokens = getDesignTokens(currentMode);
  const light = isLightMode(currentMode);

  return (
    <div
      className="flex h-[80vh] items-center justify-center px-4"
      data-nav-theme={light ? 'dark' : 'light'}
      style={{ backgroundColor: tokens.pageBg }}
    >
      <div className="text-center">
        <span className="text-6xl block mb-4">🗺️</span>
        <h1 className="mb-2" style={{ fontSize: '1.5rem', color: tokens.textPrimary }}>
          {t('common.notFound')}
        </h1>
        <p className="text-sm mb-6" style={{ color: tokens.textMuted }}>
          {t('common.notFoundDesc')}
        </p>
        <Link
          to="/"
          className="inline-flex items-center gap-2 rounded-full px-6 py-3 text-sm transition-all hover:opacity-80"
          style={{
            backgroundColor: light ? 'rgba(0,0,0,0.06)' : 'rgba(255,255,255,0.1)',
            color: tokens.textPrimary,
          }}
        >
          <Home size={16} /> {t('common.goHome')}
        </Link>
      </div>
    </div>
  );
}
