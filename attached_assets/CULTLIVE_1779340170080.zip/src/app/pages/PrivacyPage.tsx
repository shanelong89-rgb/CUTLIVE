import { useTranslation } from 'react-i18next';
import { Link } from 'react-router';
import { useMode } from '../context/ModeContext';
import { getDesignTokens } from '../data/mode-styles';
import { ArrowLeft } from 'lucide-react';

export function PrivacyPage() {
  const { t, i18n } = useTranslation();
  const { currentMode } = useMode();
  const tokens = getDesignTokens(currentMode);
  const isZh = i18n.language?.startsWith('zh');

  return (
    <div className="min-h-screen px-4 sm:px-6 lg:px-8 py-8 sm:py-12" style={{ backgroundColor: tokens.pageBg }}>
      <div className="max-w-3xl mx-auto">
        <Link
          to="/"
          className="inline-flex items-center gap-1.5 text-sm mb-6 transition-opacity hover:opacity-70"
          style={{ color: tokens.textMuted }}
        >
          <ArrowLeft size={14} />
          {t('common.back')}
        </Link>

        <h1
          className="text-2xl sm:text-3xl font-bold mb-2"
          style={{ color: tokens.textPrimary, fontFamily: tokens.headingFont }}
        >
          {t('legal.privacyTitle')}
        </h1>
        <p className="text-sm mb-8" style={{ color: tokens.textMuted }}>
          {t('legal.effectiveDate', { date: '2026-03-17' })}
        </p>

        <div className="space-y-8" style={{ color: tokens.textSecondary, lineHeight: 1.8 }}>
          {/* Section 1 */}
          <section>
            <SectionHeading tokens={tokens}>{isZh ? '1. 概述' : '1. Overview'}</SectionHeading>
            <p className="text-sm">
              {isZh
                ? 'CULTIVE 文化活（以下簡稱「我們」）是一個位於香港的文化活動探索平台。我們致力於保護你的個人資料私隱，並遵守香港《個人資料（私隱）條例》（第486章，「PDPO」）。本私隱政策說明我們如何收集、使用、儲存和保護你的個人資料。'
                : 'CULTIVE 文化活 ("we", "us", "our") is a Hong Kong-based cultural events discovery platform. We are committed to protecting your personal data privacy in compliance with Hong Kong\'s Personal Data (Privacy) Ordinance (Cap. 486, "PDPO"). This Privacy Policy explains how we collect, use, store, and protect your personal data.'}
            </p>
          </section>

          {/* Section 2 */}
          <section>
            <SectionHeading tokens={tokens}>{isZh ? '2. 我們收集的資料' : '2. Data We Collect'}</SectionHeading>
            <p className="text-sm mb-3">
              {isZh ? '我們可能會收集以下類別的個人資料：' : 'We may collect the following categories of personal data:'}
            </p>
            <ul className="list-disc pl-5 space-y-2 text-sm">
              <li>
                <strong>{isZh ? '帳戶資料：' : 'Account Information: '}</strong>
                {isZh
                  ? '姓名、電郵地址、密碼（加密儲存）。'
                  : 'Name, email address, password (stored encrypted).'}
              </li>
              <li>
                <strong>{isZh ? '使用資料：' : 'Usage Data: '}</strong>
                {isZh
                  ? '已儲存的活動、收藏集、模式偏好、語言設定。'
                  : 'Saved events, collections, mode preferences, language settings.'}
              </li>
              <li>
                <strong>{isZh ? '用戶提交內容：' : 'User Submissions: '}</strong>
                {isZh
                  ? '透過投稿功能提交的活動資料和相關媒體。'
                  : 'Event information and associated media submitted via the Contribute feature.'}
              </li>
              <li>
                <strong>{isZh ? '技術資料：' : 'Technical Data: '}</strong>
                {isZh
                  ? '瀏覽器類型、裝置資訊、IP 位址、存取時間。'
                  : 'Browser type, device information, IP address, access timestamps.'}
              </li>
              <li>
                <strong>{isZh ? '本地儲存：' : 'Local Storage: '}</strong>
                {isZh
                  ? '偏好設定和興趣標籤儲存在你的裝置上（localStorage），不會傳送到我們的伺服器。'
                  : 'Preferences and interest tags are stored on your device (localStorage) and are not transmitted to our servers.'}
              </li>
            </ul>
          </section>

          {/* Section 3 */}
          <section>
            <SectionHeading tokens={tokens}>{isZh ? '3. 使用目的' : '3. Purpose of Use'}</SectionHeading>
            <p className="text-sm mb-3">
              {isZh ? '我們使用你的個人資料於以下目的：' : 'We use your personal data for the following purposes:'}
            </p>
            <ul className="list-disc pl-5 space-y-2 text-sm">
              <li>{isZh ? '提供和改善我們的平台服務' : 'Providing and improving our platform services'}</li>
              <li>{isZh ? '管理你的帳戶和驗證身份' : 'Managing your account and authenticating your identity'}</li>
              <li>{isZh ? '個人化你的體驗（活動推薦、模式偏好）' : 'Personalizing your experience (event recommendations, mode preferences)'}</li>
              <li>{isZh ? '處理活動提交和投稿' : 'Processing event submissions and contributions'}</li>
              <li>{isZh ? '發送與你帳戶相關的通知' : 'Sending notifications related to your account'}</li>
              <li>{isZh ? '分析和改善平台效能' : 'Analytics and platform performance improvement'}</li>
            </ul>
          </section>

          {/* Section 4 */}
          <section>
            <SectionHeading tokens={tokens}>{isZh ? '4. 資料分享' : '4. Data Sharing'}</SectionHeading>
            <p className="text-sm">
              {isZh
                ? '我們不會出售你的個人資料。我們可能會在以下情況下分享你的資料：'
                : 'We do not sell your personal data. We may share your data in the following circumstances:'}
            </p>
            <ul className="list-disc pl-5 space-y-2 text-sm mt-3">
              <li>
                <strong>{isZh ? '服務供應商：' : 'Service Providers: '}</strong>
                {isZh
                  ? '我們使用 Supabase 進行身份驗證和資料儲存。你的資料受其安全措施保護。'
                  : 'We use Supabase for authentication and data storage. Your data is protected by their security measures.'}
              </li>
              <li>
                <strong>{isZh ? '法律要求：' : 'Legal Requirements: '}</strong>
                {isZh
                  ? '當法律規定或為回應有效的法律程序時。'
                  : 'When required by law or in response to valid legal process.'}
              </li>
              <li>
                <strong>{isZh ? '用戶提交的公開內容：' : 'Public User Submissions: '}</strong>
                {isZh
                  ? '你提交的活動經批准後將在平台上公開顯示。'
                  : 'Events you submit, once approved, will be publicly displayed on the platform.'}
              </li>
            </ul>
          </section>

          {/* Section 5 */}
          <section>
            <SectionHeading tokens={tokens}>{isZh ? '5. 資料保留' : '5. Data Retention'}</SectionHeading>
            <p className="text-sm">
              {isZh
                ? '我們在你的帳戶存在期間及之後的合理期間內保留你的個人資料，以履行法律義務和解決爭議。你可以隨時要求刪除你的帳戶和相關資料。'
                : 'We retain your personal data for as long as your account exists and for a reasonable period thereafter to fulfill legal obligations and resolve disputes. You may request deletion of your account and associated data at any time.'}
            </p>
          </section>

          {/* Section 6 */}
          <section>
            <SectionHeading tokens={tokens}>{isZh ? '6. 你的權利（PDPO）' : '6. Your Rights (PDPO)'}</SectionHeading>
            <p className="text-sm mb-3">
              {isZh
                ? '根據香港《個人資料（私隱）條例》，你享有以下權利：'
                : 'Under Hong Kong\'s Personal Data (Privacy) Ordinance, you have the right to:'}
            </p>
            <ul className="list-disc pl-5 space-y-2 text-sm">
              <li>{isZh ? '查閱我們所持有的你的個人資料' : 'Access the personal data we hold about you'}</li>
              <li>{isZh ? '要求更正不準確的個人資料' : 'Request correction of inaccurate personal data'}</li>
              <li>{isZh ? '要求刪除你的帳戶和個人資料' : 'Request deletion of your account and personal data'}</li>
              <li>{isZh ? '反對將你的資料用於直接促銷' : 'Object to the use of your data for direct marketing'}</li>
            </ul>
            <p className="text-sm mt-3">
              {isZh
                ? '如需行使上述權利，請透過 privacy@cultive.city 聯繫我們。我們將在收到要求後 40 天內回覆。'
                : 'To exercise any of these rights, please contact us at privacy@cultive.city. We will respond within 40 days of receiving your request.'}
            </p>
          </section>

          {/* Section 7 */}
          <section>
            <SectionHeading tokens={tokens}>{isZh ? '7. Cookies 和本地儲存' : '7. Cookies & Local Storage'}</SectionHeading>
            <p className="text-sm">
              {isZh
                ? '我們使用瀏覽器 localStorage 來儲存你的偏好設定（如語言選擇、模式偏好和興趣標籤）。這些資料儲存在你的裝置上，不會傳送至我們的伺服器。我們可能使用基本的分析 Cookie 來改善平台體驗，但不會使用第三方追蹤 Cookie 進行廣告投放。'
                : 'We use browser localStorage to store your preferences (such as language selection, mode preferences, and interest tags). This data is stored on your device and is not transmitted to our servers. We may use basic analytics cookies to improve the platform experience, but do not use third-party tracking cookies for advertising purposes.'}
            </p>
          </section>

          {/* Section 8 */}
          <section>
            <SectionHeading tokens={tokens}>{isZh ? '8. 資料安全' : '8. Data Security'}</SectionHeading>
            <p className="text-sm">
              {isZh
                ? '我們採用行業標準的安全措施保護你的個人資料，包括加密傳輸（HTTPS）、加密密碼儲存和安全的雲端基礎設施。然而，沒有任何互聯網傳輸方式是百分之百安全的。'
                : 'We implement industry-standard security measures to protect your personal data, including encrypted transmission (HTTPS), hashed password storage, and secure cloud infrastructure. However, no method of internet transmission is 100% secure.'}
            </p>
          </section>

          {/* Section 9 */}
          <section>
            <SectionHeading tokens={tokens}>{isZh ? '9. 兒童私隱' : '9. Children\'s Privacy'}</SectionHeading>
            <p className="text-sm">
              {isZh
                ? '我們的平台適合各年齡層使用（特別是家庭模式）。然而，我們不會故意收集 13 歲以下兒童的個人資料。兒童帳戶的建立應由父母或監護人監督。'
                : 'Our platform is suitable for all ages (particularly in Family mode). However, we do not knowingly collect personal data from children under 13. Account creation for children should be supervised by a parent or guardian.'}
            </p>
          </section>

          {/* Section 10 */}
          <section>
            <SectionHeading tokens={tokens}>{isZh ? '10. 政策變更' : '10. Changes to This Policy'}</SectionHeading>
            <p className="text-sm">
              {isZh
                ? '我們可能會不時更新本私隱政策。更新後的政策將在此頁面上發布，並附上修訂日期。如有重大變更，我們會透過平台通知你。'
                : 'We may update this Privacy Policy from time to time. Updated policies will be posted on this page with a revised date. For significant changes, we will notify you through the platform.'}
            </p>
          </section>

          {/* Section 11 */}
          <section>
            <SectionHeading tokens={tokens}>{isZh ? '11. 聯繫我們' : '11. Contact Us'}</SectionHeading>
            <p className="text-sm">
              {isZh
                ? '如有任何關於本私隱政策或你的個人資料的查詢，請聯繫我們：'
                : 'If you have questions about this Privacy Policy or your personal data, please contact us:'}
            </p>
            <div className="mt-3 text-sm space-y-1">
              <p><strong>{isZh ? '電郵：' : 'Email: '}</strong>privacy@cultive.city</p>
              <p><strong>{isZh ? '平台：' : 'Platform: '}</strong>CULTIVE 文化活</p>
              <p><strong>{isZh ? '地點：' : 'Location: '}</strong>{isZh ? '香港' : 'Hong Kong SAR'}</p>
            </div>
          </section>

          {/* Governing law */}
          <section
            className="pt-6 mt-6 text-xs"
            style={{ borderTop: `1px solid ${tokens.cardBorder}`, color: tokens.textMuted }}
          >
            <p>
              {isZh
                ? '本私隱政策受香港特別行政區法律管轄，並依其解釋。'
                : 'This Privacy Policy is governed by and construed in accordance with the laws of the Hong Kong Special Administrative Region.'}
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}

function SectionHeading({ children, tokens }: { children: React.ReactNode; tokens: any }) {
  return (
    <h2
      className="text-lg font-semibold mb-3"
      style={{ color: tokens.textPrimary, fontFamily: tokens.headingFont }}
    >
      {children}
    </h2>
  );
}
