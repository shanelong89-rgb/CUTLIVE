import { useEffect } from 'react';
import { useNavigate } from 'react-router';
import { useMode } from '../context/ModeContext';

/**
 * Redirect component for /lifestyle route.
 * Sets mode to lifestyle and redirects to / where HomePage handles rendering.
 * This preserves backward compatibility for bookmarks/links to /lifestyle.
 */
export function LifestyleRedirect() {
  const { setMode } = useMode();
  const navigate = useNavigate();

  useEffect(() => {
    setMode('lifestyle');
    navigate('/', { replace: true });
  }, [setMode, navigate]);

  return null;
}
