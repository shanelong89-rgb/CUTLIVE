import { useData } from '../context/DataContext';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import { useMode } from '../context/ModeContext';
import { getDesignTokens } from '../data/mode-styles';
import { useTranslation } from 'react-i18next';
import { Link, useSearchParams } from 'react-router';
import { motion, AnimatePresence } from 'motion/react';
import {
  Camera, MapPin, Calendar, Search, ArrowRight, X,
  User, Heart, Filter, Grid3X3, LayoutList, Play,
} from 'lucide-react';
import { useState, useMemo } from 'react';
import { isVideoUrl } from '../utils/media-helpers';

// Default tokens (neutral/no mode)
const DEFAULT_T = {
  bg: '#FAFAF8',
  surface: '#FFFFFF',
  surfaceMuted: '#F5F5F3',
  border: 'rgba(0,0,0,0.06)',
  text: '#1A1A1A',
  textSecondary: '#5A5A5A',
  textMuted: '#9A9A9A',
  accent: '#2563EB',
  green: '#16A34A',
  font: "'Inter', 'Noto Sans HK', system-ui, sans-serif",
};

function useModeTokens() {
  const { currentMode } = useMode();
  const tokens = getDesignTokens(currentMode);
  if (!currentMode) return DEFAULT_T;
  return {
    bg: tokens.pageBg,
    surface: tokens.surfaceBg,
    surfaceMuted: tokens.cardBg,
    border: tokens.cardBorder,
    text: tokens.textPrimary,
    textSecondary: tokens.textSecondary,
    textMuted: tokens.textMuted,
    accent: currentMode === 'degen' ? '#D600FF'
      : currentMode === 'artsy' ? '#8338EC'
      : currentMode === 'foodie' ? '#2563EB'
      : currentMode === 'family' ? '#FF8C42'
      : currentMode === 'lifestyle' ? '#2D6A4F'
      : '#2563EB',
    green: '#16A34A',
    font: tokens.bodyFont,
  };
}

export function RecapsGalleryPage() {
  const { t, i18n } = useTranslation();
  const isZh = i18n.language?.startsWith('zh');
  const { recaps, venues, allEvents } = useData();
  const T = useModeTokens();
  const { currentMode } = useMode();
  // Only foodie has a truly dark page background; degen is bright yellow (light)
  const isDark = currentMode === 'foodie';
  const navTheme = isDark ? 'light' : 'dark';

  const [searchParams] = useSearchParams();
  const eventFilter = searchParams.get('event') || '';

  const [search, setSearch] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [selectedVenue, setSelectedVenue] = useState<string>('');

  // Resolve the filtered event for banner display
  const filteredEvent = useMemo(() => {
    if (!eventFilter) return null;
    return allEvents.find(e => e.id === eventFilter) || null;
  }, [eventFilter, allEvents]);

  // Build lookup maps
  const eventMap = useMemo(() => {
    const m = new Map<string, any>();
    allEvents.forEach(e => m.set(e.id, e));
    return m;
  }, [allEvents]);

  const venueMap = useMemo(() => {
    const m = new Map<string, any>();
    venues.forEach(v => m.set(v.id, v));
    return m;
  }, [venues]);

  // Unique venues that have recaps
  const recapVenues = useMemo(() => {
    const ids = new Set(recaps.map(r => r.venueId).filter(Boolean));
    return venues.filter(v => ids.has(v.id));
  }, [recaps, venues]);

  // Enrich recaps with event + venue data
  const enrichedRecaps = useMemo(() => {
    return recaps.map(r => {
      const event = eventMap.get(r.eventId);
      const venue = venueMap.get(r.venueId) || (event ? venueMap.get(event.venueId) : null);
      return {
        ...r,
        event,
        venue,
        displayTitle: isZh
          ? (r.eventTitle || event?.title_zh || event?.title || '')
          : (r.eventTitle || event?.title || ''),
        displayCaption: isZh ? (r.caption_zh || r.caption) : r.caption,
        displayVenue: isZh
          ? (venue?.nameZh || venue?.name || event?.venueName_zh || event?.venueName || '')
          : (venue?.name || event?.venueName || ''),
        displayDistrict: isZh
          ? (venue?.district || event?.district || '')
          : (venue?.district || event?.district || ''),
      };
    }).sort((a, b) => {
      const da = new Date(a.capturedAt || '').getTime() || 0;
      const db = new Date(b.capturedAt || '').getTime() || 0;
      return db - da;
    });
  }, [recaps, eventMap, venueMap, isZh]);

  // Filter
  const filtered = useMemo(() => {
    let items = enrichedRecaps;
    if (eventFilter) {
      items = items.filter(r => r.eventId === eventFilter);
    }
    if (selectedVenue) {
      items = items.filter(r => r.venueId === selectedVenue || r.venue?.id === selectedVenue);
    }
    if (search.trim()) {
      const q = search.toLowerCase();
      items = items.filter(r =>
        r.displayTitle.toLowerCase().includes(q) ||
        r.displayCaption.toLowerCase().includes(q) ||
        r.displayVenue.toLowerCase().includes(q) ||
        r.displayDistrict.toLowerCase().includes(q)
      );
    }
    return items;
  }, [enrichedRecaps, search, selectedVenue, eventFilter]);

  return (
    <div className="min-h-screen" data-nav-theme={navTheme} style={{ backgroundColor: T.bg, fontFamily: T.font }}>
      {/* Header */}
      <div className="px-4 py-16 sm:py-20 max-w-5xl mx-auto">
        <div className="mb-2">
          <span
            className="inline-flex items-center gap-2 px-3 py-1.5 text-[11px] tracking-[0.18em] uppercase"
            style={{
              backgroundColor: 'rgba(0,0,0,0.03)',
              color: T.textMuted,
              borderRadius: '4px',
              border: '1px solid rgba(0,0,0,0.05)',
              fontWeight: 500,
            }}
          >
            <Camera size={12} />
            {t('recaps.communityRecaps')}
          </span>
        </div>
        <h1
          className="text-3xl sm:text-4xl mt-4"
          style={{ color: T.text, fontWeight: 600, letterSpacing: '-0.03em' }}
        >
          {t('recaps.eventRecaps')}
        </h1>
        <p className="mt-3 text-[15px] max-w-xl" style={{ color: T.textMuted, lineHeight: 1.7 }}>
          {t('recaps.gallerySubtitle')}
        </p>
        <div className="mt-4">
          <Link to="/contribute/recap" className="inline-flex items-center gap-1.5 text-[13px] no-underline transition-opacity hover:opacity-70"
            style={{ color: T.accent }}>
            {t('recaps.submitYourOwn')} <ArrowRight size={13} />
          </Link>
        </div>
        <div className="mt-6 h-px" style={{ backgroundColor: T.border, maxWidth: '200px' }} />
      </div>

      <div className="max-w-5xl mx-auto px-4 pb-20">
        {/* Search + filters */}
        <div className="flex flex-col sm:flex-row gap-3 mb-8">
          <div className="relative flex-1">
            <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2" style={{ color: T.textMuted }} />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder={t('recaps.searchPlaceholder')}
              className="w-full"
              style={{
                backgroundColor: T.surface,
                border: `1px solid ${T.border}`,
                borderRadius: '10px',
                padding: '10px 14px 10px 42px',
                fontSize: '14px',
                color: T.text,
                outline: 'none',
              }}
            />
          </div>
          {recapVenues.length > 0 && (
            <div className="flex items-center gap-2">
              <Filter size={14} style={{ color: T.textMuted }} />
              <select
                value={selectedVenue}
                onChange={e => setSelectedVenue(e.target.value)}
                style={{
                  backgroundColor: T.surface,
                  border: `1px solid ${T.border}`,
                  borderRadius: '8px',
                  padding: '8px 12px',
                  fontSize: '13px',
                  color: T.text,
                  outline: 'none',
                  minWidth: '160px',
                }}
              >
                <option value="">{t('recaps.allVenues')}</option>
                {recapVenues.map(v => (
                  <option key={v.id} value={v.id}>{isZh ? (v.nameZh || v.name) : v.name}</option>
                ))}
              </select>
            </div>
          )}
          <div className="flex gap-1">
            <button onClick={() => setViewMode('grid')}
              className="p-2.5 cursor-pointer" style={{
                backgroundColor: viewMode === 'grid' ? T.text : 'transparent',
                color: viewMode === 'grid' ? '#fff' : T.textMuted,
                borderRadius: '8px', border: `1px solid ${viewMode === 'grid' ? T.text : T.border}`,
              }}>
              <Grid3X3 size={16} />
            </button>
            <button onClick={() => setViewMode('list')}
              className="p-2.5 cursor-pointer" style={{
                backgroundColor: viewMode === 'list' ? T.text : 'transparent',
                color: viewMode === 'list' ? '#fff' : T.textMuted,
                borderRadius: '8px', border: `1px solid ${viewMode === 'list' ? T.text : T.border}`,
              }}>
              <LayoutList size={16} />
            </button>
          </div>
        </div>

        {/* Event filter banner */}
        {filteredEvent && (
          <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }}
            className="flex items-center gap-3 p-3 mb-6"
            style={{ backgroundColor: 'rgba(37,99,235,0.04)', borderRadius: '12px', border: '1px solid rgba(37,99,235,0.12)' }}>
            {filteredEvent.image && (
              <div className="w-10 h-10 flex-shrink-0 overflow-hidden" style={{ borderRadius: '8px' }}>
                <ImageWithFallback src={filteredEvent.image} alt="" className="w-full h-full object-cover" />
              </div>
            )}
            <div className="flex-1 min-w-0">
              <p className="text-[11px] font-medium uppercase tracking-wider" style={{ color: T.accent }}>
                {t('recaps.showingFor')}
              </p>
              <p className="text-[14px] font-medium truncate" style={{ color: T.text }}>
                {isZh ? (filteredEvent.title_zh || filteredEvent.title) : filteredEvent.title}
              </p>
            </div>
            <Link to="/recaps" className="p-1.5 no-underline transition-opacity hover:opacity-70"
              style={{ color: T.textMuted }} title={t('recaps.showAll')}>
              <X size={16} />
            </Link>
          </motion.div>
        )}

        {/* Stats */}
        <div className="flex items-center gap-4 mb-6">
          <span className="text-[13px] font-medium" style={{ color: T.textSecondary }}>
            {t('recaps.recapCount', { count: filtered.length })}
          </span>
          {selectedVenue && (
            <button onClick={() => setSelectedVenue('')}
              className="text-[12px] cursor-pointer px-2 py-1"
              style={{ color: T.accent, border: 'none', background: 'none' }}>
              {t('recaps.clearFilter')}
            </button>
          )}
        </div>

        {/* Empty state */}
        {filtered.length === 0 && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
            className="text-center py-16"
            style={{ backgroundColor: T.surface, borderRadius: '16px', border: `1px solid ${T.border}` }}>
            <Camera size={32} style={{ color: T.textMuted }} className="mx-auto mb-3 opacity-40" />
            <p className="text-[16px] font-medium mb-1" style={{ color: T.text }}>
              {t('recaps.noRecapsYet')}
            </p>
            <p className="text-[14px] mb-6" style={{ color: T.textMuted }}>
              {t('recaps.beFirst')}
            </p>
            <Link to="/contribute/recap"
              className="inline-flex items-center gap-2 px-5 py-2.5 text-[14px] font-medium no-underline"
              style={{ backgroundColor: T.text, color: '#fff', borderRadius: '10px' }}>
              <Camera size={14} /> {t('recaps.submitRecap')}
            </Link>
          </motion.div>
        )}

        {/* Grid view */}
        {viewMode === 'grid' && filtered.length > 0 && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <AnimatePresence>
              {filtered.map((recap, i) => (
                <motion.div
                  key={recap.id}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.03 }}
                  className="group"
                  style={{
                    backgroundColor: T.surface,
                    borderRadius: '14px',
                    border: `1px solid ${T.border}`,
                    overflow: 'hidden',
                  }}
                >
                  {/* Thumbnail */}
                  <Link to={`/recaps/${recap.id}`} className="block relative no-underline" style={{ aspectRatio: '4/3' }}>
                    {recap.thumbnail || (recap.media && recap.media[0]) ? (
                      <>
                        {isVideoUrl(recap.thumbnail || recap.media![0]) ? (
                          <>
                            <video
                              src={recap.thumbnail || recap.media![0]}
                              muted
                              playsInline
                              preload="metadata"
                              className="w-full h-full object-cover"
                            />
                            <div className="absolute inset-0 flex items-center justify-center">
                              <div className="w-10 h-10 flex items-center justify-center" style={{ backgroundColor: 'rgba(0,0,0,0.5)', borderRadius: '50%', backdropFilter: 'blur(4px)' }}>
                                <Play size={18} fill="#fff" color="#fff" />
                              </div>
                            </div>
                          </>
                        ) : (
                          <ImageWithFallback
                            src={recap.thumbnail || recap.media![0]}
                            alt={recap.displayTitle}
                            className="w-full h-full object-cover"
                          />
                        )}
                      </>
                    ) : (
                      <div className="w-full h-full flex items-center justify-center" style={{ backgroundColor: T.surfaceMuted }}>
                        <Camera size={24} style={{ color: T.textMuted }} />
                      </div>
                    )}
                    {recap.media && recap.media.length > 1 && (
                      <div className="absolute top-2 right-2 px-2 py-0.5 text-[11px] font-medium"
                        style={{ backgroundColor: 'rgba(0,0,0,0.55)', color: '#fff', borderRadius: '4px', backdropFilter: 'blur(4px)' }}>
                        {recap.media.length} {isZh ? '張' : 'photos'}
                      </div>
                    )}
                    {recap.event && (
                      <div
                        className="absolute bottom-0 left-0 right-0 px-3 py-2"
                        style={{ background: 'linear-gradient(transparent, rgba(0,0,0,0.7))' }}>
                        <p className="text-[13px] font-medium text-white truncate">{recap.displayTitle}</p>
                      </div>
                    )}
                  </Link>

                  {/* Content */}
                  <div className="p-4">
                    {/* Venue + location */}
                    {(recap.displayVenue || recap.displayDistrict) && (
                      <div className="flex items-center gap-1.5 mb-2">
                        <MapPin size={12} style={{ color: T.accent, flexShrink: 0 }} />
                        <span className="text-[12px] font-medium truncate" style={{ color: T.textSecondary }}>
                          {[recap.displayVenue, recap.displayDistrict].filter(Boolean).join(', ')}
                        </span>
                      </div>
                    )}

                    {/* Caption */}
                    <p className="text-[13px] leading-relaxed mb-3" style={{
                      color: T.textSecondary,
                      display: '-webkit-box',
                      WebkitLineClamp: 3,
                      WebkitBoxOrient: 'vertical',
                      overflow: 'hidden',
                    }}>
                      {recap.displayCaption}
                    </p>

                    {/* Footer */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        {recap.contributorName && (
                          <span className="flex items-center gap-1 text-[11px]" style={{ color: T.textMuted }}>
                            <User size={10} /> {recap.contributorName}
                          </span>
                        )}
                      </div>
                      {recap.capturedAt && (
                        <span className="text-[11px]" style={{ color: T.textMuted }}>
                          <Calendar size={9} className="inline mr-1" />
                          {new Date(recap.capturedAt).toLocaleDateString('en-HK', { month: 'short', day: 'numeric' })}
                        </span>
                      )}
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}

        {/* List view */}
        {viewMode === 'list' && filtered.length > 0 && (
          <div className="space-y-3">
            {filtered.map((recap, i) => (
              <motion.div
                key={recap.id}
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.02 }}
                className="flex gap-4 p-4"
                style={{
                  backgroundColor: T.surface,
                  borderRadius: '14px',
                  border: `1px solid ${T.border}`,
                }}
              >
                {/* Thumbnail */}
                <Link to={`/recaps/${recap.id}`} className="w-24 h-24 sm:w-32 sm:h-24 flex-shrink-0 overflow-hidden block relative" style={{ borderRadius: '10px' }}>
                  {recap.thumbnail || (recap.media && recap.media[0]) ? (
                    isVideoUrl(recap.thumbnail || recap.media![0]) ? (
                      <>
                        <video
                          src={recap.thumbnail || recap.media![0]}
                          muted
                          playsInline
                          preload="metadata"
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute inset-0 flex items-center justify-center" style={{ backgroundColor: 'rgba(0,0,0,0.25)' }}>
                          <Play size={14} fill="#fff" color="#fff" />
                        </div>
                      </>
                    ) : (
                      <ImageWithFallback
                        src={recap.thumbnail || recap.media![0]}
                        alt={recap.displayTitle}
                        className="w-full h-full object-cover"
                      />
                    )
                  ) : (
                    <div className="w-full h-full flex items-center justify-center" style={{ backgroundColor: T.surfaceMuted }}>
                      <Camera size={20} style={{ color: T.textMuted }} />
                    </div>
                  )}
                </Link>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  {recap.event && (
                    <Link to={`/recaps/${recap.id}`} className="text-[14px] font-medium no-underline hover:opacity-70 transition-opacity"
                      style={{ color: T.text }}>
                      {recap.displayTitle}
                    </Link>
                  )}
                  {(recap.displayVenue || recap.displayDistrict) && (
                    <div className="flex items-center gap-1.5 mt-1">
                      <MapPin size={11} style={{ color: T.accent, flexShrink: 0 }} />
                      <span className="text-[12px] truncate" style={{ color: T.textSecondary }}>
                        {[recap.displayVenue, recap.displayDistrict].filter(Boolean).join(', ')}
                      </span>
                    </div>
                  )}
                  <p className="text-[13px] mt-1.5 leading-relaxed" style={{
                    color: T.textMuted,
                    display: '-webkit-box',
                    WebkitLineClamp: 2,
                    WebkitBoxOrient: 'vertical',
                    overflow: 'hidden',
                  }}>
                    {recap.displayCaption}
                  </p>
                  <div className="flex items-center gap-3 mt-2">
                    {recap.contributorName && (
                      <span className="flex items-center gap-1 text-[11px]" style={{ color: T.textMuted }}>
                        <User size={10} /> {recap.contributorName}
                      </span>
                    )}
                    {recap.capturedAt && (
                      <span className="text-[11px]" style={{ color: T.textMuted }}>
                        <Calendar size={9} className="inline mr-1" />
                        {new Date(recap.capturedAt).toLocaleDateString('en-HK', { month: 'short', day: 'numeric', year: 'numeric' })}
                      </span>
                    )}
                    {recap.media && recap.media.length > 0 && (
                      <span className="text-[11px]" style={{ color: T.textMuted }}>
                        {recap.media.length} {isZh ? '張照片' : 'photos'}
                      </span>
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}