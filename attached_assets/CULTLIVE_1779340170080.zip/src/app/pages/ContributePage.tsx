import { useState, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Upload, Link2, Instagram, MapPin, X, Check, AlertCircle,
  ArrowRight, Sparkles, Clock, Send, Camera, Plus,
  Loader2, CheckCircle2, ExternalLink, Zap, Wand2, Bot,
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { Link } from 'react-router';
import { createSubmission, parseSourceUrl, checkSubmissionStatus, uploadImages, analyzeContent } from '../hooks/useAdminApi';
import { fireWebhook } from '../config/webhooks';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import { LocationAutocomplete } from '../components/contribute/LocationAutocomplete';
import { MapContainer, TileLayer, Marker } from '../components/map/LeafletWrapper';
import L from 'leaflet';
// leaflet CSS loaded via CDN in fonts.css

// ─── Neutral Design Tokens (matches Admin CMS) ───
const T = {
  bg: '#FAFAF8',
  surface: '#FFFFFF',
  surfaceMuted: '#F5F5F3',
  border: 'rgba(0,0,0,0.06)',
  text: '#1A1A1A',
  textSecondary: '#5A5A5A',
  textMuted: '#9A9A9A',
  accent: '#2563EB',
  accentBg: 'rgba(37,99,235,0.05)',
  accentBorder: 'rgba(37,99,235,0.15)',
  error: '#DC2626',
  errorBg: 'rgba(220,38,38,0.05)',
  green: '#16A34A',
  greenBg: 'rgba(22,163,74,0.06)',
  font: "'Inter', 'Noto Sans HK', system-ui, sans-serif",
};

type SourceType = 'instagram' | 'google-maps' | 'manual';
type Step = 'source' | 'details' | 'review' | 'submitted';

interface FormData {
  source: SourceType;
  sourceUrl: string;
  title: string;
  description: string;
  dateStart: string;
  dateEnd: string;
  timeStart: string;
  timeEnd: string;
  location: string;
  district: string;
  categories: string[];
  images: string[];
  tags: string[];
  contributorName: string;
  contributorEmail: string;
  contributorInstagram: string;
  price: string;
  lat?: number;
  lng?: number;
}

const emptyForm: FormData = {
  source: 'manual',
  sourceUrl: '',
  title: '',
  description: '',
  dateStart: '',
  dateEnd: '',
  timeStart: '',
  timeEnd: '',
  location: '',
  district: '',
  categories: [],
  images: [],
  tags: [],
  contributorName: '',
  contributorEmail: '',
  contributorInstagram: '',
  price: '',
  lat: undefined,
  lng: undefined,
};

const categoryOptions = [
  { value: 'run-clubs', label: 'Run Clubs' },
  { value: 'wellness', label: 'Wellness & Yoga' },
  { value: 'hikes', label: 'Hikes & Outdoors' },
  { value: 'coffee-raves', label: 'Coffee Raves & Social' },
  { value: 'workshops', label: 'Workshops & Classes' },
  { value: 'meetups', label: 'Meetups & Community' },
  { value: 'nightlife', label: 'Nightlife & Music' },
  { value: 'art', label: 'Art & Exhibitions' },
  { value: 'food', label: 'Food & Markets' },
  { value: 'family', label: 'Family & Kids' },
  { value: 'other', label: 'Other' },
];

const districtOptions = [
  'Central', 'Wan Chai', 'Causeway Bay', 'Sheung Wan', 'Sai Ying Pun',
  'Kennedy Town', 'Tsim Sha Tsui', 'Mong Kok', 'Sham Shui Po', 'West Kowloon',
  'Wong Chuk Hang', 'Stanley', 'Repulse Bay', 'Shau Kei Wan', 'Tai Tam',
  'Sha Tin', 'Tai Po', 'Sai Kung', 'Lantau', 'Other',
];

// Detect if a string looks like an Instagram or Google Maps URL
function looksLikeUrl(s: string) {
  return /^https?:\/\/(www\.)?(instagram\.com|google\.com\/maps|goo\.gl\/maps|maps\.app\.goo\.gl)/i.test(s.trim());
}

export function ContributePage() {
  const { t } = useTranslation();
  const [step, setStep] = useState<Step>('source');
  const [formRaw, setForm] = useState<FormData>(emptyForm);

  // Normalize form to ensure array fields are always arrays (handles stale HMR state)
  const form: FormData = {
    ...formRaw,
    categories: Array.isArray(formRaw.categories) ? formRaw.categories : [],
    images: Array.isArray(formRaw.images) ? formRaw.images : [],
    tags: Array.isArray(formRaw.tags) ? formRaw.tags : [],
  };

  const [urlParsing, setUrlParsing] = useState(false);
  const [urlParseResult, setUrlParseResult] = useState<any>(null);
  const [submitting, setSubmitting] = useState(false);
  const [submissionResult, setSubmissionResult] = useState<any>(null);
  const [imageUrl, setImageUrl] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [trackingId, setTrackingId] = useState('');
  const [trackingResult, setTrackingResult] = useState<any>(null);
  const [trackingLoading, setTrackingLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState('');
  const [dragOver, setDragOver] = useState(false);

  // AI analysis state
  const [analyzing, setAnalyzing] = useState(false);
  const [aiFilledFields, setAiFilledFields] = useState<Set<string>>(new Set());
  const [aiPhase, setAiPhase] = useState<'idle' | 'extracting' | 'analyzing' | 'filling' | 'done'>('idle');
  const [aiConfidence, setAiConfidence] = useState(0);

  const urlInputRef = useRef<HTMLInputElement>(null);
  const parseTimeoutRef = useRef<any>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const updateForm = useCallback((updates: Partial<FormData>) => {
    setForm(prev => ({ ...prev, ...updates }));
    const newErrors = { ...errors };
    Object.keys(updates).forEach(k => delete newErrors[k]);
    setErrors(newErrors);
  }, [errors]);

  // ─── Auto-parse on paste ───
  const handleUrlPaste = useCallback((e: React.ClipboardEvent<HTMLInputElement>) => {
    const pasted = e.clipboardData.getData('text');
    if (looksLikeUrl(pasted)) {
      // Set value immediately, then auto-trigger parse
      setForm(prev => ({ ...prev, sourceUrl: pasted }));
      if (parseTimeoutRef.current) clearTimeout(parseTimeoutRef.current);
      parseTimeoutRef.current = setTimeout(() => {
        triggerParse(pasted);
      }, 300);
    }
  }, []);

  const triggerParse = useCallback(async (url: string) => {
    if (!url.trim()) return;
    setUrlParsing(true);
    setAiPhase('extracting');
    try {
      const result = await parseSourceUrl(url);
      setUrlParseResult(result);

      if (result.source === 'instagram') {
        const updates: Partial<FormData> = {
          source: 'instagram',
          sourceUrl: url,
          contributorInstagram: result.username || '',
        };

        // If content was auto-extracted, populate and then run AI analysis
        if (result.extracted) {
          const ex = result.extracted;
          if (ex.description) updates.description = ex.description;
          if (ex.title) updates.title = ex.title;
          if (ex.authorName && !updates.contributorInstagram) {
            updates.contributorInstagram = ex.authorName;
          }
          if (ex.image) {
            updates.images = [...form.images, ex.image];
          }
          updateForm(updates);

          // Run AI content analysis on the caption
          if (ex.description && ex.description.length > 10) {
            setAiPhase('analyzing');
            try {
              const analysis = await analyzeContent(ex.description, ex.authorName);
              setAiConfidence(analysis.confidence || 0);
              await applyAiAnalysis(analysis, updates);
            } catch (err) {
              console.log('AI analysis error (non-fatal):', err);
            }
          }

          setAiPhase('done');
          setTimeout(() => setStep('details'), 600);
        } else {
          updateForm(updates);
          setAiPhase('idle');
          if (result.parsed) {
            setTimeout(() => setStep('details'), 800);
          }
        }
      } else if (result.source === 'google-maps') {
        updateForm({
          source: 'google-maps',
          sourceUrl: url,
          location: result.placeName || '',
          ...(result.lat && result.lng ? { lat: result.lat, lng: result.lng } : {}),
        });
        setAiPhase('idle');
        if (result.parsed) {
          setTimeout(() => setStep('details'), 800);
        }
      } else {
        setAiPhase('idle');
      }
    } catch (err) {
      console.log('URL parse error:', err);
      setAiPhase('idle');
    }
    setUrlParsing(false);
  }, [form.images, updateForm]);

  const applyAiAnalysis = useCallback(async (analysis: any, currentUpdates: Partial<FormData>) => {
    setAiPhase('filling');
    const filledFields = new Set<string>();
    const aiUpdates: Partial<FormData> = {};

    // Stagger fill for visual effect
    const fieldsToFill: [string, keyof FormData, any][] = [];

    if (analysis.title && !currentUpdates.title) fieldsToFill.push(['title', 'title', analysis.title]);
    if (analysis.categories?.length > 0) {
      fieldsToFill.push(['categories', 'categories', analysis.categories]);
    } else if (analysis.category) {
      fieldsToFill.push(['categories', 'categories', [analysis.category]]);
    }
    if (analysis.district) fieldsToFill.push(['district', 'district', analysis.district]);
    if (analysis.date) fieldsToFill.push(['dateStart', 'dateStart', analysis.date]);
    if (analysis.time) fieldsToFill.push(['timeStart', 'timeStart', analysis.time]);
    if (analysis.price) fieldsToFill.push(['price', 'price', analysis.price]);
    if (analysis.location) fieldsToFill.push(['location', 'location', analysis.location]);
    if (analysis.tags?.length > 0) fieldsToFill.push(['tags', 'tags', analysis.tags]);

    for (let i = 0; i < fieldsToFill.length; i++) {
      const [fieldName, formKey, value] = fieldsToFill[i];
      await new Promise(r => setTimeout(r, 150)); // stagger effect
      aiUpdates[formKey] = value;
      filledFields.add(fieldName);
      setAiFilledFields(new Set(filledFields));
      setForm(prev => ({ ...prev, [formKey]: value }));
    }

    return filledFields;
  }, []);

  const handleUrlParse = useCallback(async () => {
    if (!form.sourceUrl.trim()) return;
    await triggerParse(form.sourceUrl);
  }, [form.sourceUrl, triggerParse]);

  const handleFileUpload = useCallback(async (files: FileList | File[]) => {
    const fileArray = Array.from(files).filter(f => f.type.startsWith('image/'));
    if (fileArray.length === 0) return;

    const remaining = 5 - form.images.length;
    if (remaining <= 0) {
      setErrors(prev => ({ ...prev, images: 'Maximum 5 images allowed' }));
      return;
    }
    const toUpload = fileArray.slice(0, remaining);

    setUploading(true);
    setUploadProgress(`Uploading ${toUpload.length} image${toUpload.length > 1 ? 's' : ''}...`);

    try {
      const result = await uploadImages(toUpload);
      if (result.uploaded.length > 0) {
        const newUrls = result.uploaded.map(u => u.url);
        updateForm({ images: [...form.images, ...newUrls] });
        setUploadProgress(`${result.uploaded.length} image${result.uploaded.length > 1 ? 's' : ''} uploaded`);
      }
      if (result.errors.length > 0) {
        setErrors(prev => ({ ...prev, images: result.errors.join('; ') }));
      }
    } catch (err: any) {
      console.log('Upload error:', err);
      setErrors(prev => ({ ...prev, images: err.message || 'Upload failed' }));
      setUploadProgress('');
    }

    setUploading(false);
    setTimeout(() => setUploadProgress(''), 3000);
  }, [form.images, updateForm]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    if (e.dataTransfer.files.length > 0) {
      handleFileUpload(e.dataTransfer.files);
    }
  }, [handleFileUpload]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
  }, []);

  const addImage = useCallback(() => {
    if (imageUrl.trim() && !form.images.includes(imageUrl.trim())) {
      updateForm({ images: [...form.images, imageUrl.trim()] });
      setImageUrl('');
    }
  }, [imageUrl, form.images, updateForm]);

  const removeImage = useCallback((idx: number) => {
    updateForm({ images: form.images.filter((_, i) => i !== idx) });
  }, [form.images, updateForm]);

  const validate = useCallback(() => {
    const errs: Record<string, string> = {};
    if (!form.title.trim()) errs.title = 'Title is required';
    if (!form.description.trim() || form.description.length < 20) errs.description = 'Description must be at least 20 characters';
    if (!form.contributorName.trim()) errs.contributorName = 'Your name is required';
    if (!form.contributorEmail.trim()) errs.contributorEmail = 'Email is required';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  }, [form]);

  const handleSubmit = useCallback(async () => {
    if (!validate()) return;
    setSubmitting(true);
    try {
      const result = await createSubmission({
        ...form,
        // Backward-compatible fields
        category: form.categories[0] || '',
        date: form.dateStart + (form.dateEnd && form.dateEnd !== form.dateStart ? ` – ${form.dateEnd}` : ''),
        time: form.timeStart + (form.timeEnd ? ` – ${form.timeEnd}` : ''),
      });
      setSubmissionResult(result);
      setStep('submitted');
      // Fire webhook for new submission
      fireWebhook('submission.created', {
        submissionId: result.id || result.submission?.id,
        title: form.title,
        source: form.source,
        categories: form.categories,
      });
    } catch (err: any) {
      console.log('Submit error:', err);
      setErrors({ submit: err.message || 'Submission failed' });
    }
    setSubmitting(false);
  }, [form, validate]);

  const handleTrackSubmission = useCallback(async () => {
    if (!trackingId.trim()) return;
    setTrackingLoading(true);
    try {
      const result = await checkSubmissionStatus(trackingId);
      setTrackingResult(result);
    } catch (err: any) {
      setTrackingResult({ error: err.message });
    }
    setTrackingLoading(false);
  }, [trackingId]);

  // ─── Completeness calculation ───
  const completeness = (() => {
    let filled = 0;
    let total = 7; // title, description, category, images, name, email + at least 1 of (date, location, district)
    if (form.title.trim()) filled++;
    if (form.description.trim() && form.description.length >= 20) filled++;
    if (form.categories.length > 0) filled++;
    if (form.images.length > 0) filled++;
    if (form.contributorName.trim()) filled++;
    if (form.contributorEmail.trim()) filled++;
    if (form.dateStart || form.location || form.district) filled++;
    return Math.round((filled / total) * 100);
  })();

  return (
    <div className="min-h-screen" data-nav-theme="dark" style={{ backgroundColor: T.bg, fontFamily: T.font }}>
      {/* Clean Header */}
      <div className="px-4 py-16 sm:py-20 max-w-3xl mx-auto">
        <div className="mb-2">
          <span
            className="inline-flex items-center gap-2 px-3 py-1.5 text-[11px] tracking-[0.18em] uppercase"
            style={{
              backgroundColor: 'rgba(0,0,0,0.03)',
              color: '#9A9A9A',
              borderRadius: '4px',
              border: '1px solid rgba(0,0,0,0.05)',
              fontFamily: "'Inter', sans-serif",
              fontWeight: 500,
            }}
          >
            Community Submissions
          </span>
        </div>
        <h1
          className="text-3xl sm:text-4xl mt-4"
          style={{ color: T.text, fontFamily: T.font, fontWeight: 600, letterSpacing: '-0.03em' }}
        >
          {t('contribute.title')}
        </h1>
        <p className="mt-3 text-[15px]" style={{ color: T.textMuted, lineHeight: 1.7 }}>
          {t('contribute.subtitle')}
        </p>
        <div className="mt-4">
          <Link to="/contribute/recap" className="inline-flex items-center gap-2 text-[13px] no-underline transition-opacity hover:opacity-70"
            style={{ color: T.accent }}>
            <Camera size={14} /> {t('contribute.submitRecap', 'Submit a recap instead')} →
          </Link>
        </div>
        <div className="mt-6 h-px" style={{ backgroundColor: T.border, maxWidth: '200px' }} />
      </div>

      {/* Main Content */}
      <div className="max-w-3xl mx-auto px-4 py-8 sm:py-10">
        <AnimatePresence mode="wait">
          {/* ════════════ STEP 1: Source ════════════ */}
          {step === 'source' && (
            <motion.div key="source" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -16 }}>
              {/* URL Input - Hero area */}
              <div className="p-6 sm:p-8 mb-6" style={{ backgroundColor: T.surface, border: `1px solid ${T.border}`, borderRadius: '14px' }}>
                <div className="flex items-center gap-2 mb-4">
                  <div className="p-2" style={{ background: 'linear-gradient(135deg, #833AB4, #E1306C, #F77737)', borderRadius: '8px' }}>
                    <Zap size={16} color="#fff" />
                  </div>
                  <div>
                    <h2 className="text-base font-semibold" style={{ color: T.text }}>Paste a link, we'll handle the rest</h2>
                    <p className="text-xs" style={{ color: T.textMuted }}>Instagram post, reel, story, or Google Maps link</p>
                  </div>
                </div>

                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Link2 size={16} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: T.textMuted }} />
                    <input
                      ref={urlInputRef}
                      type="url"
                      value={form.sourceUrl}
                      onChange={e => updateForm({ sourceUrl: e.target.value })}
                      onPaste={handleUrlPaste}
                      placeholder="Paste Instagram or Google Maps URL..."
                      className="w-full pl-10 pr-4 py-3 text-sm outline-none"
                      style={{ ...inputStyle, fontSize: '15px' }}
                      onKeyDown={e => e.key === 'Enter' && handleUrlParse()}
                      autoFocus
                    />
                  </div>
                  <button
                    onClick={handleUrlParse}
                    disabled={urlParsing || !form.sourceUrl.trim()}
                    className="px-5 py-3 text-sm font-medium transition-all cursor-pointer disabled:opacity-40"
                    style={{ backgroundColor: T.accent, color: '#fff', borderRadius: '8px' }}
                  >
                    {urlParsing ? <Loader2 size={16} className="animate-spin" /> : 'Go'}
                  </button>
                </div>

                {/* AI Phase indicator */}
                <AnimatePresence>
                  {aiPhase !== 'idle' && aiPhase !== 'done' && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="mt-4"
                    >
                      <div className="flex items-center gap-3 p-3" style={{ backgroundColor: T.accentBg, borderRadius: '10px', border: `1px solid ${T.accentBorder}` }}>
                        <div className="relative">
                          <Loader2 size={18} className="animate-spin" style={{ color: T.accent }} />
                          <div className="absolute inset-0 flex items-center justify-center">
                            <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: T.accent }} />
                          </div>
                        </div>
                        <div className="flex-1">
                          <p className="text-sm font-medium" style={{ color: T.accent }}>
                            {aiPhase === 'extracting' && 'Extracting content from Instagram...'}
                            {aiPhase === 'analyzing' && 'AI is analyzing the caption...'}
                            {aiPhase === 'filling' && 'Auto-filling event details...'}
                          </p>
                          <div className="mt-1.5 h-1 rounded-full overflow-hidden" style={{ backgroundColor: 'rgba(37,99,235,0.1)' }}>
                            <motion.div
                              className="h-full rounded-full"
                              style={{ backgroundColor: T.accent }}
                              initial={{ width: '0%' }}
                              animate={{
                                width: aiPhase === 'extracting' ? '33%' : aiPhase === 'analyzing' ? '66%' : '90%',
                              }}
                              transition={{ duration: 0.8, ease: 'easeOut' }}
                            />
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Parse result (non-AI) */}
                <AnimatePresence>
                  {urlParseResult && aiPhase === 'idle' && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="mt-3 p-3 flex items-start gap-2 text-sm"
                      style={{
                        backgroundColor: urlParseResult.parsed ? T.accentBg : T.errorBg,
                        borderRadius: '8px',
                        border: `1px solid ${urlParseResult.parsed ? T.accentBorder : 'rgba(220,38,38,0.15)'}`,
                      }}
                    >
                      {urlParseResult.parsed ? (
                        <Check size={16} className="flex-shrink-0 mt-0.5" style={{ color: T.accent }} />
                      ) : (
                        <AlertCircle size={16} className="flex-shrink-0 mt-0.5" style={{ color: T.error }} />
                      )}
                      <div>
                        <span className="font-medium" style={{ color: urlParseResult.parsed ? T.accent : T.error }}>
                          {urlParseResult.source === 'instagram' ? 'Instagram' : urlParseResult.source === 'google-maps' ? 'Google Maps' : 'Unknown source'}
                        </span>
                        {urlParseResult.username && (
                          <span className="ml-1" style={{ color: T.textMuted }}>@{urlParseResult.username}</span>
                        )}
                        {urlParseResult.placeName && (
                          <span className="ml-1" style={{ color: T.textMuted }}>{urlParseResult.placeName}</span>
                        )}
                        <p className="mt-1" style={{ color: T.textMuted }}>{urlParseResult.hint}</p>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Divider */}
              <div className="flex items-center gap-4 my-6">
                <div className="flex-1 h-px" style={{ backgroundColor: T.border }} />
                <span className="text-xs font-medium" style={{ color: T.textMuted }}>or start from scratch</span>
                <div className="flex-1 h-px" style={{ backgroundColor: T.border }} />
              </div>

              {/* Source type cards */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-8">
                {([
                  { key: 'instagram' as const, icon: Instagram, label: 'Instagram', desc: 'Post, Reel, or Story' },
                  { key: 'google-maps' as const, icon: MapPin, label: 'Google Maps', desc: 'Venue or location' },
                  { key: 'manual' as const, icon: Upload, label: 'Manual Upload', desc: 'Add your own details' },
                ]).map(opt => (
                  <button
                    key={opt.key}
                    onClick={() => updateForm({ source: opt.key })}
                    className="p-4 text-left transition-all cursor-pointer"
                    style={{
                      backgroundColor: form.source === opt.key ? T.accentBg : T.surface,
                      border: `1.5px solid ${form.source === opt.key ? T.accent : T.border}`,
                      borderRadius: '10px',
                    }}
                  >
                    <opt.icon size={20} style={{ color: form.source === opt.key ? T.accent : T.textMuted }} />
                    <p className="mt-2 text-sm font-medium" style={{ color: T.text }}>{opt.label}</p>
                    <p className="text-xs" style={{ color: T.textMuted }}>{opt.desc}</p>
                  </button>
                ))}
              </div>

              <button
                onClick={() => setStep('details')}
                className="w-full py-3 flex items-center justify-center gap-2 text-sm font-medium transition-all cursor-pointer"
                style={{ backgroundColor: T.accent, color: '#fff', borderRadius: '8px' }}
              >
                Continue <ArrowRight size={16} />
              </button>

              {/* Track existing submission */}
              <div className="mt-10 p-5" style={{ backgroundColor: T.surface, border: `1px solid ${T.border}`, borderRadius: '10px' }}>
                <h3 className="text-sm font-semibold mb-3" style={{ color: T.text }}>
                  Track Your Submission
                </h3>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={trackingId}
                    onChange={e => setTrackingId(e.target.value)}
                    placeholder="Paste your submission ID"
                    className="flex-1 px-4 py-2.5 text-sm outline-none font-mono"
                    style={inputStyle}
                    onKeyDown={e => e.key === 'Enter' && handleTrackSubmission()}
                  />
                  <button
                    onClick={handleTrackSubmission}
                    disabled={trackingLoading}
                    className="px-4 py-2.5 text-sm cursor-pointer"
                    style={{ backgroundColor: T.surfaceMuted, border: `1px solid ${T.border}`, borderRadius: '8px', color: T.text }}
                  >
                    {trackingLoading ? <Loader2 size={14} className="animate-spin" /> : <Clock size={14} />}
                  </button>
                </div>
                {trackingResult && !trackingResult.error && (
                  <div className="mt-3 p-3 text-sm" style={{ backgroundColor: T.accentBg, borderRadius: '8px', border: `1px solid ${T.accentBorder}` }}>
                    <p className="font-medium" style={{ color: T.accent }}>{trackingResult.title}</p>
                    <p className="mt-1" style={{ color: T.textMuted }}>
                      Status: <span className="font-semibold" style={{ color: T.accent }}>{trackingResult.status}</span>
                    </p>
                    <p className="mt-0.5" style={{ color: T.textMuted }}>{trackingResult.message}</p>
                  </div>
                )}
                {trackingResult?.error && (
                  <p className="mt-2 text-sm" style={{ color: T.error }}>{trackingResult.error}</p>
                )}
              </div>
            </motion.div>
          )}

          {/* ════════════ STEP 2: Details ════════════ */}
          {step === 'details' && (
            <motion.div key="details" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -16 }}>
              <button onClick={() => setStep('source')} className="flex items-center gap-1 mb-6 text-sm cursor-pointer"
                style={{ color: T.textMuted }}>
                <ArrowRight size={14} className="rotate-180" /> Back
              </button>

              {/* Header with completeness */}
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold" style={{ color: T.text }}>
                  {t('contribute.detailsStep')}
                </h2>
                <CompletenessRing percent={completeness} />
              </div>

              {/* AI Auto-fill banner */}
              {aiFilledFields.size > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: -8 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex items-start gap-3 p-4 mb-5"
                  style={{
                    background: 'linear-gradient(135deg, rgba(37,99,235,0.04), rgba(139,92,246,0.04))',
                    border: '1px solid rgba(37,99,235,0.12)',
                    borderRadius: '10px',
                  }}
                >
                  <div className="p-1.5 flex-shrink-0" style={{ background: 'linear-gradient(135deg, #2563EB, #7C3AED)', borderRadius: '6px' }}>
                    <Bot size={14} color="#fff" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium" style={{ color: T.text }}>
                      AI auto-filled {aiFilledFields.size} field{aiFilledFields.size !== 1 ? 's' : ''}
                      {aiConfidence > 0 && (
                        <span className="ml-2 text-xs font-normal" style={{ color: T.textMuted }}>
                          {aiConfidence}% confidence
                        </span>
                      )}
                    </p>
                    <p className="text-xs mt-1" style={{ color: T.textMuted }}>
                      {completeness >= 80
                        ? 'Almost there! Just add your name and email below.'
                        : 'Review the details below. Fields highlighted in blue were auto-detected.'}
                    </p>
                    <div className="flex flex-wrap gap-1.5 mt-2">
                      {Array.from(aiFilledFields).map(f => (
                        <motion.span
                          key={f}
                          initial={{ opacity: 0, scale: 0.8 }}
                          animate={{ opacity: 1, scale: 1 }}
                          className="inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-medium"
                          style={{ backgroundColor: T.accentBg, color: T.accent, borderRadius: '4px', border: `1px solid ${T.accentBorder}` }}
                        >
                          <Wand2 size={8} />
                          {f}
                        </motion.span>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}

              {/* Instagram extraction banner (no AI fields, extracted content) */}
              {aiFilledFields.size === 0 && form.source === 'instagram' && urlParseResult?.extracted && form.images.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: -8 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex items-start gap-3 p-4 mb-5"
                  style={{
                    backgroundColor: 'rgba(22,163,74,0.05)',
                    border: '1px solid rgba(22,163,74,0.15)',
                    borderRadius: '10px',
                  }}
                >
                  <CheckCircle2 size={18} className="flex-shrink-0 mt-0.5" style={{ color: T.green }} />
                  <div>
                    <p className="text-sm font-medium" style={{ color: '#166534' }}>
                      Content extracted from Instagram
                    </p>
                    <p className="text-xs mt-1" style={{ color: '#4ADE80' }}>
                      We pulled the image and caption automatically. Review the details below.
                      {urlParseResult?.username && (
                        <> From <strong>@{urlParseResult.username}</strong>.</>
                      )}
                    </p>
                  </div>
                </motion.div>
              )}

              {/* Story/no-extraction upload prompt */}
              {form.source === 'instagram' && !urlParseResult?.extracted && form.images.length === 0 && (
                <motion.div
                  initial={{ opacity: 0, y: -8 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex items-start gap-3 p-4 mb-5"
                  style={{
                    backgroundColor: 'rgba(131,63,245,0.05)',
                    border: '1px solid rgba(131,63,245,0.15)',
                    borderRadius: '10px',
                  }}
                >
                  <Instagram size={18} className="flex-shrink-0 mt-0.5" style={{ color: '#834FF5' }} />
                  <div>
                    <p className="text-sm font-medium" style={{ color: '#6B21A8' }}>
                      Upload screenshots from Instagram
                    </p>
                    <p className="text-xs mt-1" style={{ color: '#9A6DD7' }}>
                      {urlParseResult?.type === 'story'
                        ? "Stories can't be auto-extracted -- take a screenshot and upload it below."
                        : "We couldn't auto-extract this content. Please take screenshots and upload them below."}
                      {urlParseResult?.username && (
                        <> Linked to <strong>@{urlParseResult.username}</strong>.</>
                      )}
                    </p>
                  </div>
                </motion.div>
              )}

              {/* Screenshots uploaded success (non-extracted flow) */}
              {form.source === 'instagram' && !urlParseResult?.extracted && form.images.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: -8 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex items-start gap-3 p-4 mb-5"
                  style={{
                    backgroundColor: 'rgba(22,163,74,0.05)',
                    border: '1px solid rgba(22,163,74,0.15)',
                    borderRadius: '10px',
                  }}
                >
                  <CheckCircle2 size={18} className="flex-shrink-0 mt-0.5" style={{ color: T.green }} />
                  <div>
                    <p className="text-sm font-medium" style={{ color: '#166534' }}>Screenshots uploaded</p>
                    <p className="text-xs mt-1" style={{ color: '#4ADE80' }}>
                      Fill in the event details below. You can add more images if needed.
                    </p>
                  </div>
                </motion.div>
              )}

              {/* Instagram source reference card */}
              {form.source === 'instagram' && urlParseResult && form.sourceUrl && (() => {
                const thumbSrc = urlParseResult.extracted?.image || (form.images.length > 0 ? form.images[0] : null);
                const captionText = urlParseResult.extracted?.description || (form.description?.length > 10 ? form.description : '');
                return (
                <motion.div
                  initial={{ opacity: 0, y: -8 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mb-6 overflow-hidden"
                  style={{
                    borderRadius: '12px',
                    border: `1px solid ${T.border}`,
                    backgroundColor: T.surface,
                  }}
                >
                  <div className="flex">
                    {thumbSrc ? (
                      <div className="w-28 sm:w-36 flex-shrink-0 relative">
                        <ImageWithFallback
                          src={thumbSrc}
                          alt="Instagram content"
                          className="w-full h-full object-cover"
                          style={{ minHeight: '120px' }}
                        />
                        <div className="absolute inset-0" style={{ background: 'linear-gradient(to right, transparent 60%, rgba(255,255,255,0.05) 100%)' }} />
                        {form.images.length > 1 && (
                          <div className="absolute bottom-2 right-2 px-1.5 py-0.5 text-[9px] font-bold text-white"
                            style={{ backgroundColor: 'rgba(0,0,0,0.6)', borderRadius: '4px' }}>
                            +{form.images.length - 1}
                          </div>
                        )}
                      </div>
                    ) : (
                      <div
                        className="w-24 sm:w-32 flex-shrink-0 flex items-center justify-center"
                        style={{
                          background: 'linear-gradient(135deg, rgba(131,58,180,0.08), rgba(225,48,108,0.08), rgba(247,119,55,0.06))',
                          borderRight: `1px solid ${T.border}`,
                        }}
                      >
                        <div className="text-center">
                          <Camera size={24} style={{ color: '#C13584', opacity: 0.4 }} />
                          <p className="text-[9px] mt-1.5 font-medium" style={{ color: '#C13584', opacity: 0.5 }}>UPLOAD</p>
                        </div>
                      </div>
                    )}

                    <div className="flex-1 p-4 flex flex-col justify-between min-w-0">
                      <div>
                        <div className="flex items-center gap-2 mb-2">
                          <div className="flex items-center gap-1.5 px-2 py-1" style={{
                            background: 'linear-gradient(135deg, #833AB4, #C13584, #E1306C, #F77737)',
                            borderRadius: '6px',
                          }}>
                            <Instagram size={11} color="#fff" />
                            <span className="text-[10px] font-semibold text-white uppercase tracking-wide">
                              {urlParseResult.type === 'story' ? 'Story' : urlParseResult.type === 'reel' ? 'Reel' : 'Post'}
                            </span>
                          </div>
                          {urlParseResult.username && (
                            <span className="text-xs font-medium truncate" style={{ color: T.textSecondary }}>
                              @{urlParseResult.username}
                            </span>
                          )}
                        </div>
                        {captionText ? (
                          <p className="text-xs line-clamp-3 leading-relaxed" style={{ color: T.textMuted }}>
                            {captionText}
                          </p>
                        ) : (
                          <p className="text-xs italic" style={{ color: T.textMuted }}>
                            {!thumbSrc
                              ? 'Take a screenshot of the story and upload it below'
                              : 'Add a description in the form below'}
                          </p>
                        )}
                      </div>
                      <div className="flex items-center gap-3 mt-3">
                        <a
                          href={form.sourceUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-[11px] font-medium transition-all hover:opacity-80"
                          style={{
                            backgroundColor: T.surfaceMuted,
                            border: `1px solid ${T.border}`,
                            borderRadius: '6px',
                            color: T.textSecondary,
                            textDecoration: 'none',
                          }}
                        >
                          <ExternalLink size={11} />
                          Open in Instagram
                        </a>
                        {(urlParseResult.extracted?.imageStored || (!urlParseResult.extracted?.image && form.images.length > 0)) && (
                          <span className="inline-flex items-center gap-1 text-[10px]" style={{ color: T.green }}>
                            <CheckCircle2 size={10} />
                            {form.images.length} image{form.images.length !== 1 ? 's' : ''} attached
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </motion.div>
                );
              })()}

              <div className="space-y-5">
                {/* Title */}
                <AiField label="Event Title" required error={errors.title} aiFilled={aiFilledFields.has('title')}>
                  <input type="text" value={form.title} onChange={e => { updateForm({ title: e.target.value }); setAiFilledFields(prev => { const n = new Set(prev); n.delete('title'); return n; }); }}
                    placeholder="e.g. Morning Trail Run at Dragon's Back"
                    className="w-full px-4 py-2.5 text-sm outline-none" style={inputStyle} />
                </AiField>

                {/* Description */}
                <AiField label="Description" required error={errors.description} aiFilled={aiFilledFields.has('description')}>
                  <textarea value={form.description} onChange={e => updateForm({ description: e.target.value })}
                    placeholder="Tell people what this event is about, what to expect, and why they should come..."
                    rows={4} className="w-full px-4 py-2.5 text-sm outline-none resize-none" style={inputStyle} />
                </AiField>

                {/* Date Range */}
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-xs font-semibold uppercase tracking-wider" style={{ color: T.textSecondary }}>Date</span>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <AiField label="Start Date" aiFilled={aiFilledFields.has('dateStart')}>
                      <input type="date" value={form.dateStart} onChange={e => {
                        updateForm({ dateStart: e.target.value });
                        // Auto-set end date if empty or before start
                        if (!form.dateEnd || e.target.value > form.dateEnd) {
                          updateForm({ dateEnd: e.target.value });
                        }
                      }}
                        className="w-full px-4 py-2.5 text-sm outline-none" style={inputStyle} />
                    </AiField>
                    <AiField label="End Date" aiFilled={false}>
                      <input type="date" value={form.dateEnd} min={form.dateStart || undefined}
                        onChange={e => updateForm({ dateEnd: e.target.value })}
                        className="w-full px-4 py-2.5 text-sm outline-none" style={inputStyle} />
                    </AiField>
                  </div>
                  {form.dateStart && form.dateEnd && form.dateStart === form.dateEnd && (
                    <p className="text-[10px] mt-1 px-1" style={{ color: T.textMuted }}>Single-day event</p>
                  )}
                  {form.dateStart && form.dateEnd && form.dateStart !== form.dateEnd && (
                    <p className="text-[10px] mt-1 px-1" style={{ color: T.accent }}>
                      Multi-day event: {Math.ceil((new Date(form.dateEnd).getTime() - new Date(form.dateStart).getTime()) / (1000 * 60 * 60 * 24)) + 1} days
                    </p>
                  )}
                </div>

                {/* Time Range */}
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-xs font-semibold uppercase tracking-wider" style={{ color: T.textSecondary }}>Time</span>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <AiField label="Start Time" aiFilled={aiFilledFields.has('timeStart')}>
                      <input type="time" value={form.timeStart} onChange={e => updateForm({ timeStart: e.target.value })}
                        className="w-full px-4 py-2.5 text-sm outline-none" style={inputStyle} />
                    </AiField>
                    <AiField label="End Time" aiFilled={false}>
                      <input type="time" value={form.timeEnd} onChange={e => updateForm({ timeEnd: e.target.value })}
                        className="w-full px-4 py-2.5 text-sm outline-none" style={inputStyle} />
                    </AiField>
                  </div>
                  {form.timeStart && form.timeEnd && (
                    <p className="text-[10px] mt-1 px-1" style={{ color: T.textMuted }}>
                      {(() => {
                        const [sh, sm] = form.timeStart.split(':').map(Number);
                        const [eh, em] = form.timeEnd.split(':').map(Number);
                        const startMin = sh * 60 + sm;
                        const endMin = eh * 60 + em;
                        const diff = endMin > startMin ? endMin - startMin : (24 * 60 - startMin) + endMin;
                        const hours = Math.floor(diff / 60);
                        const mins = diff % 60;
                        return `Duration: ${hours > 0 ? `${hours}h` : ''}${mins > 0 ? ` ${mins}m` : ''}`;
                      })()}
                    </p>
                  )}
                </div>

                {/* Location / Venue with autocomplete */}
                <AiField label="Location / Venue" aiFilled={aiFilledFields.has('location')}>
                  <LocationAutocomplete
                    value={form.location}
                    onChange={(loc) => {
                      const updates: Partial<FormData> = { location: loc.name };
                      if (loc.lat !== undefined && loc.lng !== undefined) {
                        updates.lat = loc.lat;
                        updates.lng = loc.lng;
                      }
                      if (loc.district) {
                        updates.district = loc.district;
                      }
                      updateForm(updates);
                      if (loc.district) {
                        setAiFilledFields(prev => { const n = new Set(prev); n.delete('location'); n.delete('district'); return n; });
                      }
                    }}
                    inputStyle={inputStyle}
                    tokens={T}
                  />
                  {/* When coordinates are entered directly, show an optional venue name field */}
                  {form.lat && form.lng && form.location && /[°]|^\s*-?\d+\.?\d*\s*[,;\s]\s*-?\d+/.test(form.location) && (
                    <div className="mt-2.5 p-2.5 rounded-lg" style={{ backgroundColor: T.accentBg, border: `1px solid ${T.accentBorder}` }}>
                      <label className="text-[11px] font-medium mb-1.5 flex items-center gap-1.5" style={{ color: T.textSecondary }}>
                        <MapPin size={10} style={{ color: T.accent }} />
                        Venue / Place name <span style={{ color: T.textMuted }}>(optional — helps others find it)</span>
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. Hot Source, Sham Shui Po"
                        onChange={e => {
                          if (e.target.value.trim()) {
                            updateForm({ location: e.target.value });
                          }
                        }}
                        className="w-full px-3 py-2 text-sm outline-none"
                        style={inputStyle}
                      />
                    </div>
                  )}
                  {form.lat && form.lng && (
                    <>
                      <p className="mt-1.5 flex items-center gap-1 text-[11px]" style={{ color: T.green }}>
                        <MapPin size={10} />
                        Map pin set ({form.lat.toFixed(4)}, {form.lng.toFixed(4)})
                        {form.district && <> &middot; {form.district}</>}
                      </p>
                      {/* Mini Leaflet map preview */}
                      <div className="mt-2 overflow-hidden" style={{ borderRadius: '10px', border: `1px solid ${T.border}`, height: '140px' }}>
                        <MapContainer
                          key={`${form.lat}-${form.lng}`}
                          center={[form.lat, form.lng]}
                          zoom={15}
                          scrollWheelZoom={false}
                          dragging={false}
                          zoomControl={false}
                          attributionControl={false}
                          style={{ height: '100%', width: '100%' }}
                        >
                          <TileLayer url="https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png" />
                          <Marker
                            position={[form.lat, form.lng]}
                            icon={L.divIcon({
                              className: 'custom-marker',
                              html: `<div style="width:28px;height:28px;border-radius:50%;background:${T.accent};border:3px solid white;box-shadow:0 2px 8px rgba(0,0,0,0.25);display:flex;align-items:center;justify-content:center;">
                                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                              </div>`,
                              iconSize: [28, 28],
                              iconAnchor: [14, 14],
                            })}
                          />
                        </MapContainer>
                      </div>
                    </>
                  )}
                </AiField>

                {/* District (auto-filled from location or manual) */}
                <AiField label="District" aiFilled={aiFilledFields.has('district')}>
                  <select value={form.district} onChange={e => updateForm({ district: e.target.value })}
                    className="w-full px-4 py-2.5 text-sm outline-none appearance-none cursor-pointer" style={inputStyle}>
                    <option value="">Select district...</option>
                    {districtOptions.map(d => <option key={d} value={d}>{d}</option>)}
                  </select>
                </AiField>

                {/* Categories (multi-select tags) */}
                <AiField label="Categories" aiFilled={aiFilledFields.has('categories')}>
                  <div className="flex flex-wrap gap-2 p-3" style={{ ...inputStyle, minHeight: '44px' }}>
                    {categoryOptions.map(c => {
                      const isSelected = form.categories.includes(c.value);
                      return (
                        <button
                          key={c.value}
                          type="button"
                          onClick={() => {
                            const next = isSelected
                              ? form.categories.filter(v => v !== c.value)
                              : [...form.categories, c.value];
                            updateForm({ categories: next });
                            setAiFilledFields(prev => { const n = new Set(prev); n.delete('categories'); return n; });
                          }}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium transition-all cursor-pointer"
                          style={{
                            backgroundColor: isSelected ? T.accent : T.surfaceMuted,
                            color: isSelected ? '#fff' : T.textSecondary,
                            borderRadius: '20px',
                            border: `1px solid ${isSelected ? T.accent : T.border}`,
                          }}
                        >
                          {isSelected && <Check size={10} />}
                          {c.label}
                        </button>
                      );
                    })}
                  </div>
                  {form.categories.length > 0 && (
                    <p className="mt-1.5 text-[11px]" style={{ color: T.textMuted }}>
                      {form.categories.length} selected — events can appear in multiple modes
                    </p>
                  )}
                </AiField>

                {/* Price */}
                <AiField label="Price" aiFilled={aiFilledFields.has('price')}>
                  <input type="text" value={form.price} onChange={e => updateForm({ price: e.target.value })}
                    placeholder="e.g. Free, $80, $150" className="w-full px-4 py-2.5 text-sm outline-none" style={inputStyle} />
                </AiField>

                {/* Tags (shown if AI filled them) */}
                {form.tags.length > 0 && (
                  <AiField label="Tags" aiFilled={aiFilledFields.has('tags')}>
                    <div className="flex flex-wrap gap-2 px-4 py-3" style={{ ...inputStyle }}>
                      {form.tags.map((tag, i) => (
                        <span key={i} className="inline-flex items-center gap-1 px-2 py-1 text-xs"
                          style={{ backgroundColor: T.accentBg, color: T.accent, borderRadius: '4px' }}>
                          #{tag}
                          <button onClick={() => updateForm({ tags: form.tags.filter((_, j) => j !== i) })}
                            className="cursor-pointer hover:opacity-60">
                            <X size={10} />
                          </button>
                        </span>
                      ))}
                    </div>
                  </AiField>
                )}

                {/* Images */}
                <Field label="Images" error={errors.images}>
                  <div
                    onDrop={handleDrop}
                    onDragOver={handleDragOver}
                    onDragLeave={handleDragLeave}
                    className="relative mb-3 transition-all"
                    style={{
                      border: `2px dashed ${dragOver ? T.accent : T.border}`,
                      borderRadius: '10px',
                      backgroundColor: dragOver ? T.accentBg : T.surfaceMuted,
                      padding: form.images.length > 0 ? '16px' : '28px 16px',
                    }}
                  >
                    {/* Hidden file input triggered by ref */}
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/jpeg,image/png,image/webp,image/gif"
                      multiple
                      className="hidden"
                      onChange={e => { if (e.target.files) { handleFileUpload(e.target.files); e.target.value = ''; } }}
                    />

                    {/* Empty state: click anywhere to upload */}
                    {form.images.length === 0 && !uploading && (
                      <div
                        className="text-center cursor-pointer"
                        onClick={() => fileInputRef.current?.click()}
                      >
                        <div className="inline-flex items-center justify-center w-10 h-10 mb-3" style={{ backgroundColor: T.accentBg, borderRadius: '8px' }}>
                          <Camera size={18} style={{ color: T.accent }} />
                        </div>
                        <p className="text-sm font-medium" style={{ color: T.text }}>
                          Drag & drop photos here
                        </p>
                        <p className="text-xs mt-1" style={{ color: T.textMuted }}>
                          or click to browse. JPEG, PNG, WebP, GIF up to 10 MB. Max 5 images.
                        </p>
                      </div>
                    )}

                    {uploading && (
                      <div className="flex items-center justify-center gap-2 py-2">
                        <Loader2 size={16} className="animate-spin" style={{ color: T.accent }} />
                        <span className="text-sm" style={{ color: T.accent }}>{uploadProgress}</span>
                      </div>
                    )}

                    {!uploading && uploadProgress && form.images.length > 0 && (
                      <motion.div
                        initial={{ opacity: 0, y: -5 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="flex items-center gap-1.5 mb-2"
                      >
                        <CheckCircle2 size={12} style={{ color: T.green }} />
                        <span className="text-xs" style={{ color: T.green }}>{uploadProgress}</span>
                      </motion.div>
                    )}

                    {form.images.length > 0 && (
                      <div className="flex gap-2 flex-wrap">
                        {form.images.map((img, i) => (
                          <div key={i} className="relative w-20 h-20 overflow-hidden flex-shrink-0 group" style={{ borderRadius: '8px' }}>
                            <ImageWithFallback src={img} alt="" className="w-full h-full object-cover" />
                            <button onClick={(e) => { e.stopPropagation(); removeImage(i); }}
                              className="absolute top-1 right-1 p-0.5 cursor-pointer opacity-0 group-hover:opacity-100 transition-opacity"
                              style={{ backgroundColor: 'rgba(0,0,0,0.7)', borderRadius: '4px' }}>
                              <X size={12} color="#fff" />
                            </button>
                          </div>
                        ))}
                        {form.images.length < 5 && !uploading && (
                          <button
                            type="button"
                            onClick={() => fileInputRef.current?.click()}
                            className="w-20 h-20 flex items-center justify-center flex-shrink-0 cursor-pointer transition-colors hover:opacity-80"
                            style={{ borderRadius: '8px', border: `2px dashed ${T.border}`, backgroundColor: T.surface }}>
                            <Plus size={18} style={{ color: T.textMuted }} />
                          </button>
                        )}
                      </div>
                    )}
                  </div>

                  <div className="flex gap-2">
                    <input type="url" value={imageUrl} onChange={e => setImageUrl(e.target.value)}
                      placeholder="Or paste an image URL"
                      className="flex-1 px-4 py-2.5 text-sm outline-none" style={inputStyle}
                      onKeyDown={e => e.key === 'Enter' && (e.preventDefault(), addImage())} />
                    <button onClick={addImage} disabled={!imageUrl.trim()} className="px-4 py-2.5 cursor-pointer disabled:opacity-30" style={{ ...inputStyle, backgroundColor: T.accentBg }}>
                      <Plus size={16} style={{ color: T.accent }} />
                    </button>
                  </div>
                </Field>

                {/* Divider */}
                <div className="h-px my-2" style={{ backgroundColor: T.border }} />

                {/* Contributor info */}
                <h3 className="text-sm font-semibold" style={{ color: T.text }}>About You</h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <Field label="Your Name" required error={errors.contributorName}>
                    <input type="text" value={form.contributorName} onChange={e => updateForm({ contributorName: e.target.value })}
                      placeholder="Jane Doe" className="w-full px-4 py-2.5 text-sm outline-none" style={inputStyle} />
                  </Field>
                  <Field label="Email" required error={errors.contributorEmail}>
                    <input type="email" value={form.contributorEmail} onChange={e => updateForm({ contributorEmail: e.target.value })}
                      placeholder="jane@example.com" className="w-full px-4 py-2.5 text-sm outline-none" style={inputStyle} />
                  </Field>
                </div>

                <Field label="Instagram Handle (optional)">
                  <input type="text" value={form.contributorInstagram} onChange={e => updateForm({ contributorInstagram: e.target.value })}
                    placeholder="@yourhandle" className="w-full px-4 py-2.5 text-sm outline-none" style={inputStyle} />
                </Field>
              </div>

              {errors.submit && (
                <p className="mt-4 text-sm text-center" style={{ color: T.error }}>{errors.submit}</p>
              )}

              <div className="flex gap-3 mt-8">
                <button onClick={() => setStep('source')}
                  className="flex-1 py-3 text-sm font-medium transition-all cursor-pointer"
                  style={{ backgroundColor: T.surface, color: T.text, borderRadius: '8px', border: `1px solid ${T.border}` }}>
                  Back
                </button>
                <button
                  onClick={handleSubmit}
                  disabled={submitting}
                  className="flex-[2] py-3 flex items-center justify-center gap-2 text-sm font-medium transition-all cursor-pointer disabled:opacity-50"
                  style={{ backgroundColor: T.accent, color: '#fff', borderRadius: '8px' }}>
                  {submitting ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
                  {submitting ? 'Submitting...' : 'Submit Event'}
                </button>
              </div>
            </motion.div>
          )}

          {/* ════════════ STEP 3: Submitted ════════════ */}
          {step === 'submitted' && submissionResult && (
            <motion.div key="submitted" initial={{ opacity: 0, scale: 0.97 }} animate={{ opacity: 1, scale: 1 }}>
              <div className="text-center py-8">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: 'spring', stiffness: 300, damping: 20, delay: 0.2 }}
                  className="inline-flex items-center justify-center w-14 h-14 mx-auto mb-5"
                  style={{ backgroundColor: T.greenBg, borderRadius: '12px' }}
                >
                  <CheckCircle2 size={28} style={{ color: T.green }} />
                </motion.div>

                <h2 className="text-2xl font-semibold" style={{ color: T.text }}>
                  {t('contribute.submitted')}
                </h2>
                <p className="mt-3 max-w-md mx-auto text-[15px]" style={{ color: T.textSecondary, lineHeight: 1.6 }}>
                  {submissionResult.message}
                </p>

                {/* AI Score indicator */}
                <div className="mt-6 inline-flex items-center gap-3 px-5 py-3"
                  style={{ backgroundColor: T.surface, border: `1px solid ${T.border}`, borderRadius: '10px' }}>
                  <Sparkles size={16} style={{ color: T.accent }} />
                  <div className="text-left">
                    <p className="text-xs" style={{ color: T.textMuted }}>AI Quality Score</p>
                    <p className="text-lg font-bold font-mono" style={{ color: T.accent }}>
                      {submissionResult.aiScore}/100
                    </p>
                  </div>
                  <div className="w-12 h-12 flex items-center justify-center"
                    style={{
                      borderRadius: '50%',
                      background: `conic-gradient(${T.accent} ${submissionResult.aiScore}%, ${T.surfaceMuted} ${submissionResult.aiScore}%)`,
                    }}>
                    <div className="w-9 h-9 flex items-center justify-center" style={{ backgroundColor: T.surface, borderRadius: '50%' }}>
                      <span className="text-xs font-bold font-mono" style={{ color: T.accent }}>{submissionResult.aiScore}</span>
                    </div>
                  </div>
                </div>

                {/* AI auto-fill summary */}
                {aiFilledFields.size > 0 && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4 }}
                    className="mt-4 inline-flex items-center gap-2 px-4 py-2"
                    style={{ backgroundColor: T.accentBg, borderRadius: '8px', border: `1px solid ${T.accentBorder}` }}
                  >
                    <Bot size={14} style={{ color: T.accent }} />
                    <span className="text-xs" style={{ color: T.accent }}>
                      AI auto-filled {aiFilledFields.size} fields from your Instagram caption
                    </span>
                  </motion.div>
                )}

                {/* Tracking ID */}
                <div className="mt-6 p-4 max-w-sm mx-auto" style={{ backgroundColor: T.surfaceMuted, borderRadius: '8px' }}>
                  <p className="text-xs mb-1 font-medium" style={{ color: T.textMuted }}>Your tracking ID</p>
                  <p className="text-sm font-mono font-bold select-all" style={{ color: T.text, wordBreak: 'break-all' }}>
                    {submissionResult.id}
                  </p>
                  <p className="text-xs mt-2" style={{ color: T.textMuted }}>Save this ID to track your submission status.</p>
                </div>

                <button
                  onClick={() => { setStep('source'); setForm(emptyForm); setSubmissionResult(null); setUrlParseResult(null); setAiFilledFields(new Set()); setAiPhase('idle'); setAiConfidence(0); }}
                  className="mt-8 px-8 py-3 text-sm font-medium transition-all cursor-pointer"
                  style={{ backgroundColor: T.accent, color: '#fff', borderRadius: '8px' }}>
                  {t('contribute.submitAnother')}
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

// ─── Completeness Ring ───
function CompletenessRing({ percent }: { percent: number }) {
  const color = percent >= 80 ? T.green : percent >= 50 ? T.accent : T.textMuted;
  const r = 16;
  const circ = 2 * Math.PI * r;
  const offset = circ - (percent / 100) * circ;

  return (
    <div className="flex items-center gap-2">
      <svg width="40" height="40" viewBox="0 0 40 40">
        <circle cx="20" cy="20" r={r} fill="none" stroke="rgba(0,0,0,0.05)" strokeWidth="3" />
        <motion.circle
          cx="20" cy="20" r={r} fill="none" stroke={color} strokeWidth="3"
          strokeLinecap="round"
          strokeDasharray={circ}
          initial={{ strokeDashoffset: circ }}
          animate={{ strokeDashoffset: offset }}
          transition={{ duration: 0.8, ease: 'easeOut' }}
          transform="rotate(-90 20 20)"
        />
        <text x="20" y="21" textAnchor="middle" dominantBaseline="middle"
          style={{ fontSize: '10px', fontWeight: 700, fill: color, fontFamily: "'Inter', sans-serif" }}>
          {percent}%
        </text>
      </svg>
      <span className="text-[11px] font-medium" style={{ color }}>
        {percent >= 100 ? 'Ready!' : percent >= 80 ? 'Almost there' : 'Fill details'}
      </span>
    </div>
  );
}

// ─── Form field with AI indicator ───
function AiField({ label, required, error, aiFilled, children }: {
  label: string; required?: boolean; error?: string; aiFilled?: boolean; children: React.ReactNode;
}) {
  return (
    <div>
      <label className="flex items-center gap-2 mb-1.5 text-sm font-medium" style={{ fontFamily: T.font, color: T.textSecondary }}>
        {label} {required && <span style={{ color: T.error }}>*</span>}
        {aiFilled && (
          <motion.span
            initial={{ opacity: 0, scale: 0.8, x: -5 }}
            animate={{ opacity: 1, scale: 1, x: 0 }}
            className="inline-flex items-center gap-1 px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wider"
            style={{
              background: 'linear-gradient(135deg, rgba(37,99,235,0.08), rgba(139,92,246,0.08))',
              color: '#6366F1',
              borderRadius: '3px',
              border: '1px solid rgba(99,102,241,0.15)',
            }}
          >
            <Wand2 size={8} />
            AI
          </motion.span>
        )}
      </label>
      <div className="relative">
        {children}
        {aiFilled && (
          <motion.div
            initial={{ width: '100%' }}
            animate={{ width: 0 }}
            transition={{ duration: 0.6, ease: 'easeOut' }}
            className="absolute inset-0 pointer-events-none"
            style={{
              background: 'linear-gradient(90deg, rgba(99,102,241,0.08), rgba(99,102,241,0))',
              borderRadius: '8px',
            }}
          />
        )}
      </div>
      {error && <p className="mt-1 text-xs" style={{ color: T.error }}>{error}</p>}
    </div>
  );
}

// ─── Shared form field component ───
function Field({ label, required, error, children }: { label: string; required?: boolean; error?: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block mb-1.5 text-sm font-medium" style={{ fontFamily: T.font, color: T.textSecondary }}>
        {label} {required && <span style={{ color: T.error }}>*</span>}
      </label>
      {children}
      {error && <p className="mt-1 text-xs" style={{ color: T.error }}>{error}</p>}
    </div>
  );
}

const inputStyle: React.CSSProperties = {
  backgroundColor: T.surfaceMuted,
  border: `1px solid ${T.border}`,
  borderRadius: '8px',
  fontFamily: T.font,
  color: T.text,
};
