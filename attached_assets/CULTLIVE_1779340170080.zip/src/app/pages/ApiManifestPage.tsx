/**
 * ApiManifestPage — Machine-readable JSON endpoint for AI agent discovery.
 * 
 * Renders at /api/manifest — returns the full CULTIVE platform topology
 * so external orchestrators (Paperclip-style) can programmatically
 * discover endpoints, data flows, and page relationships.
 */
import { useEffect } from 'react';
import {
  API_BASE,
  CMS_BASE,
  API_ENDPOINTS,
  CMS_PIPELINE,
  ADMIN_PAGES,
  PUBLIC_PAGES,
  AUTH_PATTERN,
  CONTENT_TYPES,
  CACHE_STRATEGY,
} from '../config/api-manifest';

const MANIFEST_VERSION = '1.0.0';

function buildManifest() {
  return {
    name: 'CULTIVE 文化活',
    version: MANIFEST_VERSION,
    description: 'Cultural events discovery platform for Hong Kong — 5-mode system with bilingual support (EN/繁體中文)',
    apiBase: API_BASE,
    cmsBase: CMS_BASE,
    auth: AUTH_PATTERN,
    endpoints: API_ENDPOINTS,
    contentTypes: CONTENT_TYPES,
    pipeline: CMS_PIPELINE,
    adminPages: ADMIN_PAGES,
    publicPages: PUBLIC_PAGES,
    cache: CACHE_STRATEGY,
    webhooks: {
      description: 'Event-driven callbacks for CMS state changes. Register via /cms/webhooks.',
      supportedEvents: [
        'submission.created',
        'submission.status_changed',
        'submission.published',
        'submission.rejected',
        'content.created',
        'content.updated',
        'content.deleted',
        'weekly_picks.updated',
        'bulk_import.completed',
      ],
      registrationEndpoint: '/cms/webhooks',
      payloadFormat: {
        event: 'string — event type from supportedEvents',
        timestamp: 'ISO 8601',
        data: 'object — event-specific payload',
        signature: 'HMAC-SHA256 of payload using webhook secret',
      },
    },
    agentGuidance: {
      quickStart: [
        '1. GET /status — check if data is seeded',
        '2. GET /events — fetch all events (seeded + imported)',
        '3. GET /cms/content/event/public — fetch CMS-managed events',
        '4. GET /cms/submissions/published — fetch community submissions',
        '5. Merge all three sources, filter by /cms/hidden-ids',
      ],
      adminFlow: [
        '1. POST /cms/admin/signup — create admin (first time only)',
        '2. Sign in via Supabase Auth (email/password)',
        '3. Use accessToken in X-Auth-Token header for all admin endpoints',
        '4. All admin pages receive accessToken via React Router OutletContext',
      ],
      submissionLifecycle: [
        'pending → ai-approved | ai-flagged',
        'ai-approved → approved | rejected (human review)',
        'ai-flagged → approved | rejected (human review)',
        'approved → published (goes live on frontend)',
        'published → [visible in DataContext merge]',
      ],
      importPipelines: [
        'RA JSON → /admin/events-import → POST /events/bulk',
        'Lifestyle Asia → /admin/lsa-import → POST /scrape/lifestyle-asia → POST /events/bulk',
        'Apify → /admin/apify-import → POST /events/bulk',
        'Bulk Venues → /admin/import → POST /cms/content/venue',
      ],
    },
    generatedAt: new Date().toISOString(),
  };
}

export function ApiManifestPage() {
  const manifest = buildManifest();

  useEffect(() => {
    // Set document title for clarity
    document.title = 'CULTIVE API Manifest';
  }, []);

  return (
    <pre
      style={{
        margin: 0,
        padding: '16px',
        fontFamily: 'ui-monospace, "SF Mono", "Cascadia Code", monospace',
        fontSize: '13px',
        lineHeight: 1.5,
        backgroundColor: '#0D1117',
        color: '#C9D1D9',
        minHeight: '100vh',
        whiteSpace: 'pre-wrap',
        wordBreak: 'break-word',
      }}
    >
      {JSON.stringify(manifest, null, 2)}
    </pre>
  );
}
