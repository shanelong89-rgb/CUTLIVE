import { useState, useMemo, useEffect, useCallback } from 'react';
import { useParams, Link } from 'react-router';
import { motion, AnimatePresence } from 'motion/react';
import {
  ArrowLeft, MapPin, Calendar, Camera, User, X,
  ChevronLeft, ChevronRight, Loader2, Share2, Link2, Check, Play, Film,
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { useData } from '../context/DataContext';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import { supabase } from '../lib/supabase';
import { isVideoUrl } from '../utils/media-helpers';
import { useMode } from '../context/ModeContext';
import { getDesignTokens } from '../data/mode-styles';
import { ShareMenu } from '../components/ShareMenu';

const DEFAULT_T = {
  bg: '#FAFAF8',
  surface: '#FFFFFF',
  surfaceMuted: '#F5F5F3',
  border: 'rgba(0,0,0,0.06)',
  text: '#1A1A1A',
  textSecondary: '#5A5A5A',
  textMuted: '#9A9A9A',
  accent: '#2563EB',
  font: "'Inter', 'Noto Sans HK', system-ui, sans-serif",
};

function useModeTokens() {
  const { currentMode } = useMode();
  const tokens = getDesignTokens(currentMode);
  if (!currentMode) return DEFAULT_T;
  return {
    bg: tokens.pageBg,
    surface: tokens.surfaceBg,
    surfaceMuted: tokens.cardBg,
    border: tokens.cardBorder,
    text: tokens.textPrimary,
    textSecondary: tokens.textSecondary,
    textMuted: tokens.textMuted,
    accent: currentMode === 'degen' ? '#D600FF'
      : currentMode === 'artsy' ? '#8338EC'
      : currentMode === 'foodie' ? '#2563EB'
      : currentMode === 'family' ? '#FF8C42'
      : currentMode === 'lifestyle' ? '#2D6A4F'
      : '#2563EB',
    font: tokens.bodyFont,
  };
}

// ─── Lightbox ───
function Lightbox({ images, startIndex, onClose }: {
  images: string[];
  startIndex: number;
  onClose: () => void;
}) {
  const [idx, setIdx] = useState(startIndex);
  const hasPrev = idx > 0;
  const hasNext = idx < images.length - 1;

  const handleKey = useCallback((e: KeyboardEvent) => {
    if (e.key === 'Escape') onClose();
    if (e.key === 'ArrowLeft' && hasPrev) setIdx(i => i - 1);
    if (e.key === 'ArrowRight' && hasNext) setIdx(i => i + 1);
  }, [onClose, hasPrev, hasNext]);

  useEffect(() => {
    document.addEventListener('keydown', handleKey);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', handleKey);
      document.body.style.overflow = '';
    };
  }, [handleKey]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[9999] flex items-center justify-center"
      style={{ backgroundColor: 'rgba(0,0,0,0.92)' }}
      onClick={onClose}
    >
      {/* Close button */}
      <button
        onClick={onClose}
        className="absolute top-4 right-4 z-10 p-2 cursor-pointer transition-opacity hover:opacity-70"
        style={{ backgroundColor: 'rgba(255,255,255,0.1)', borderRadius: '50%', border: 'none' }}
      >
        <X size={20} color="#fff" />
      </button>

      {/* Counter */}
      <div className="absolute top-4 left-4 z-10 px-3 py-1.5 text-[13px] font-medium"
        style={{ backgroundColor: 'rgba(255,255,255,0.1)', color: '#fff', borderRadius: '8px', backdropFilter: 'blur(8px)' }}>
        {idx + 1} / {images.length}
      </div>

      {/* Prev */}
      {hasPrev && (
        <button
          onClick={e => { e.stopPropagation(); setIdx(i => i - 1); }}
          className="absolute left-3 sm:left-6 z-10 p-3 cursor-pointer transition-opacity hover:opacity-80"
          style={{ backgroundColor: 'rgba(255,255,255,0.1)', borderRadius: '50%', border: 'none', backdropFilter: 'blur(8px)' }}
        >
          <ChevronLeft size={24} color="#fff" />
        </button>
      )}

      {/* Next */}
      {hasNext && (
        <button
          onClick={e => { e.stopPropagation(); setIdx(i => i + 1); }}
          className="absolute right-3 sm:right-6 z-10 p-3 cursor-pointer transition-opacity hover:opacity-80"
          style={{ backgroundColor: 'rgba(255,255,255,0.1)', borderRadius: '50%', border: 'none', backdropFilter: 'blur(8px)' }}
        >
          <ChevronRight size={24} color="#fff" />
        </button>
      )}

      {/* Image */}
      <AnimatePresence mode="wait">
        <motion.div
          key={idx}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ duration: 0.2 }}
          className="max-w-[90vw] max-h-[85vh] flex items-center justify-center"
          onClick={e => e.stopPropagation()}
        >
          {isVideoUrl(images[idx]) ? (
            <video
              key={images[idx]}
              src={images[idx]}
              controls
              autoPlay
              playsInline
              className="max-w-full max-h-[85vh] object-contain"
              style={{ borderRadius: '8px' }}
            />
          ) : (
            <img
              src={images[idx]}
              alt=""
              className="max-w-full max-h-[85vh] object-contain"
              style={{ borderRadius: '8px' }}
            />
          )}
        </motion.div>
      </AnimatePresence>
    </motion.div>
  );
}

// ─── Main Page ───
export function RecapDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { t, i18n } = useTranslation();
  const isZh = i18n.language?.startsWith('zh');
  const { recaps, allEvents, venues } = useData();
  const T = useModeTokens();
  const { currentMode } = useMode();
  // Only foodie has a truly dark page background; degen is bright yellow (light)
  const isDark = currentMode === 'foodie';

  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [lightboxIndex, setLightboxIndex] = useState(0);
  const [linkCopied, setLinkCopied] = useState(false);
  const [reactions, setReactions] = useState<Record<string, number>>(() => {
    // Load from localStorage for persistence
    try {
      const saved = localStorage.getItem(`recap-reactions-${id}`);
      return saved ? JSON.parse(saved) : { '👏': 3, '🔥': 1, '❤️': 2 };
    } catch { return { '👏': 3, '🔥': 1, '❤️': 2 }; }
  });
  const [userReactions, setUserReactions] = useState<Set<string>>(() => {
    try {
      const saved = localStorage.getItem(`recap-user-reactions-${id}`);
      return saved ? new Set(JSON.parse(saved)) : new Set();
    } catch { return new Set(); }
  });

  // ─── Supabase reaction sync ───
  // Load shared reaction counts from Supabase on mount
  useEffect(() => {
    if (!id) return;
    supabase
      .from('recap_reactions')
      .select('emoji, count')
      .eq('recap_id', id)
      .then(({ data }) => {
        if (data && data.length > 0) {
          const merged: Record<string, number> = {};
          data.forEach((row: any) => { merged[row.emoji] = row.count; });
          setReactions(prev => {
            // Merge Supabase counts with local counts, prefer Supabase
            const result = { ...prev };
            Object.entries(merged).forEach(([k, v]) => { result[k] = v as number; });
            return result;
          });
        }
      })
      .catch(() => { /* Supabase unavailable — localStorage fallback in use */ });
  }, [id]);

  // Sync reaction to Supabase when user reacts
  const syncReactionToSupabase = useCallback((emoji: string, newCount: number) => {
    if (!id) return;
    supabase
      .from('recap_reactions')
      .upsert(
        { recap_id: id, emoji, count: newCount },
        { onConflict: 'recap_id,emoji' }
      )
      .then(() => {})
      .catch(() => { /* Silent fail — localStorage serves as fallback */ });
  }, [id]);

  const recap = useMemo(() => recaps.find(r => r.id === id), [recaps, id]);
  const event = useMemo(() => recap ? allEvents.find(e => e.id === recap.eventId) : null, [recap, allEvents]);
  const venue = useMemo(() => {
    if (!recap) return null;
    return venues.find(v => v.id === recap.venueId) || (event ? venues.find(v => v.id === event.venueId) : null);
  }, [recap, event, venues]);

  // All media (thumbnail + media array, deduplicated)
  const allMedia = useMemo(() => {
    if (!recap) return [];
    return [recap.thumbnail, ...(recap.media || [])]
      .filter(Boolean)
      .filter((v, i, a) => a.indexOf(v) === i);
  }, [recap]);

  const displayTitle = useMemo(() => {
    if (!recap) return '';
    return isZh
      ? (recap.eventTitle || event?.title_zh || event?.title || '')
      : (recap.eventTitle || event?.title || '');
  }, [recap, event, isZh]);

  const displayCaption = isZh ? (recap?.caption_zh || recap?.caption || '') : (recap?.caption || '');

  const displayVenue = useMemo(() => {
    if (!venue && !event) return '';
    return isZh
      ? (venue?.nameZh || venue?.name || event?.venueName_zh || event?.venueName || '')
      : (venue?.name || event?.venueName || '');
  }, [venue, event, isZh]);

  const displayDistrict = venue?.district || event?.district || '';

  // Other recaps for the same event
  const relatedRecaps = useMemo(() => {
    if (!recap) return [];
    return recaps.filter(r => r.eventId === recap.eventId && r.id !== recap.id).slice(0, 4);
  }, [recap, recaps]);

  const openLightbox = (index: number) => {
    setLightboxIndex(index);
    setLightboxOpen(true);
  };

  if (!recap) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center px-4" style={{ backgroundColor: T.bg }}>
        <Camera size={32} style={{ color: T.textMuted }} className="mb-3 opacity-40" />
        <p className="text-[16px] font-medium mb-1" style={{ color: T.text }}>
          {t('recaps.notFound')}
        </p>
        <p className="text-[14px] mb-6" style={{ color: T.textMuted }}>
          {t('recaps.notFoundDesc')}
        </p>
        <Link to="/recaps" className="inline-flex items-center gap-2 px-5 py-2.5 text-[14px] font-medium no-underline"
          style={{ backgroundColor: T.text, color: '#fff', borderRadius: '10px' }}>
          <ArrowLeft size={14} /> {t('recaps.backToRecaps')}
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen" data-nav-theme={isDark ? 'light' : 'dark'} style={{ backgroundColor: T.bg, fontFamily: T.font }}>
      {/* Back nav */}
      <div className="max-w-4xl mx-auto px-4 pt-8 pb-2">
        <Link to="/recaps"
          className="inline-flex items-center gap-1.5 text-sm font-medium transition-opacity hover:opacity-70 no-underline"
          style={{ color: T.textMuted }}>
          <ArrowLeft size={16} /> {t('recaps.allRecaps')}
        </Link>
      </div>

      <div className="max-w-4xl mx-auto px-4 pb-20">
        {/* Header with event info */}
        {event && (
          <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
            className="mt-4 mb-6">
            <Link to={`/recaps?event=${encodeURIComponent(event.id)}`}
              className="flex items-center gap-3 p-3 no-underline transition-all hover:opacity-80"
              style={{ backgroundColor: T.surface, borderRadius: '12px', border: `1px solid ${T.border}` }}>
              {event.image && (
                <div className="w-14 h-14 flex-shrink-0 overflow-hidden" style={{ borderRadius: '10px' }}>
                  <ImageWithFallback src={event.image} alt="" className="w-full h-full object-cover" />
                </div>
              )}
              <div className="flex-1 min-w-0">
                <p className="text-[11px] font-medium uppercase tracking-wider" style={{ color: T.accent }}>
                  {t('recaps.eventRecap')}
                </p>
                <p className="text-[16px] font-medium truncate" style={{ color: T.text }}>{displayTitle}</p>
                <div className="flex items-center gap-3 mt-0.5">
                  {event.date && (
                    <span className="text-[12px]" style={{ color: T.textMuted }}>
                      <Calendar size={10} className="inline mr-1" />{event.date}
                    </span>
                  )}
                  {(displayVenue || displayDistrict) && (
                    <span className="text-[12px] truncate" style={{ color: T.textMuted }}>
                      <MapPin size={10} className="inline mr-1" />
                      {[displayVenue, displayDistrict].filter(Boolean).join(', ')}
                    </span>
                  )}
                </div>
              </div>
            </Link>
          </motion.div>
        )}

        {/* Media gallery */}
        {allMedia.length > 0 && (
          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}>
            {/* Hero image */}
            <div
              className="relative overflow-hidden cursor-pointer transition-opacity hover:opacity-95"
              style={{ borderRadius: '16px', maxHeight: '70vh' }}
              onClick={() => !isVideoUrl(allMedia[0]) && openLightbox(0)}
            >
              {isVideoUrl(allMedia[0]) ? (
                <video
                  src={allMedia[0]}
                  controls
                  playsInline
                  preload="metadata"
                  className="w-full object-contain"
                  style={{ maxHeight: '70vh', backgroundColor: '#000', borderRadius: '16px' }}
                />
              ) : (
                <ImageWithFallback
                  src={allMedia[0]}
                  alt={displayTitle}
                  className="w-full object-cover"
                  style={{ maxHeight: '70vh' }}
                />
              )}
              {allMedia.length > 1 && (
                <div className="absolute bottom-3 right-3 px-3 py-1.5 text-[12px] font-medium"
                  style={{ backgroundColor: 'rgba(0,0,0,0.55)', color: '#fff', borderRadius: '8px', backdropFilter: 'blur(6px)' }}>
                  <Camera size={12} className="inline mr-1.5" />
                  {allMedia.length} {isZh ? '個媒體' : 'media'}
                </div>
              )}
            </div>

            {/* Thumbnail strip */}
            {allMedia.length > 1 && (
              <div className="flex gap-2 mt-3 overflow-x-auto pb-1 scrollbar-hide">
                {allMedia.map((url, i) => (
                  <button
                    key={i}
                    onClick={() => openLightbox(i)}
                    className="relative flex-shrink-0 overflow-hidden cursor-pointer transition-all hover:opacity-80"
                    style={{
                      width: '80px',
                      height: '80px',
                      borderRadius: '10px',
                      border: `2px solid transparent`,
                    }}
                  >
                    {isVideoUrl(url) ? (
                      <>
                        <video src={url} muted preload="metadata" className="w-full h-full object-cover" />
                        <div className="absolute inset-0 flex items-center justify-center" style={{ backgroundColor: 'rgba(0,0,0,0.3)' }}>
                          <Play size={16} fill="#fff" color="#fff" />
                        </div>
                      </>
                    ) : (
                      <ImageWithFallback src={url} alt="" className="w-full h-full object-cover" />
                    )}
                  </button>
                ))}
              </div>
            )}
          </motion.div>
        )}

        {/* Caption & details */}
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
          className="mt-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main content */}
            <div className="lg:col-span-2">
              {displayCaption && (
                <div className="mb-6">
                  <p className="text-[15px] leading-relaxed whitespace-pre-line" style={{ color: T.textSecondary }}>
                    {displayCaption}
                  </p>
                  {isZh && recap.caption && recap.caption_zh && recap.caption !== recap.caption_zh && (
                    <p className="text-[14px] leading-relaxed whitespace-pre-line mt-4" style={{ color: T.textMuted }}>
                      {recap.caption}
                    </p>
                  )}
                </div>
              )}
            </div>

            {/* Sidebar */}
            <div className="lg:col-span-1">
              <div className="space-y-3">
                {/* Contributor */}
                {recap.contributorName && (
                  <div className="p-3" style={{ backgroundColor: T.surface, borderRadius: '10px', border: `1px solid ${T.border}` }}>
                    <p className="text-[10px] font-medium uppercase tracking-wider mb-1" style={{ color: T.textMuted }}>
                      {t('recaps.sharedBy')}
                    </p>
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 flex items-center justify-center" style={{ backgroundColor: T.surfaceMuted, borderRadius: '50%' }}>
                        <User size={12} style={{ color: T.textMuted }} />
                      </div>
                      <span className="text-[14px] font-medium" style={{ color: T.text }}>{recap.contributorName}</span>
                    </div>
                  </div>
                )}

                {/* Venue */}
                {(displayVenue || displayDistrict) && (() => {
                  const venueId = venue?.id || event?.venueId;
                  const content = (
                    <div className={`p-3 ${venueId ? 'cursor-pointer hover:opacity-80 transition-opacity' : ''}`} style={{ backgroundColor: T.surface, borderRadius: '10px', border: `1px solid ${T.border}` }}>
                      <p className="text-[10px] font-medium uppercase tracking-wider mb-1" style={{ color: T.textMuted }}>
                        {t('recaps.venue')}
                      </p>
                      <div className="flex items-center gap-2">
                        <MapPin size={14} style={{ color: T.accent }} />
                        <span className="text-[14px] font-medium" style={{ color: T.text }}>
                          {[displayVenue, displayDistrict].filter(Boolean).join(', ')}
                        </span>
                      </div>
                    </div>
                  );
                  return venueId ? <Link to={`/venue/${venueId}`} className="no-underline block">{content}</Link> : content;
                })()}

                {/* Date */}
                {recap.capturedAt && (
                  <div className="p-3" style={{ backgroundColor: T.surface, borderRadius: '10px', border: `1px solid ${T.border}` }}>
                    <p className="text-[10px] font-medium uppercase tracking-wider mb-1" style={{ color: T.textMuted }}>
                      {t('recaps.date')}
                    </p>
                    <div className="flex items-center gap-2">
                      <Calendar size={14} style={{ color: T.accent }} />
                      <span className="text-[14px]" style={{ color: T.text }}>
                        {new Date(recap.capturedAt).toLocaleDateString('en-HK', { year: 'numeric', month: 'long', day: 'numeric' })}
                      </span>
                    </div>
                  </div>
                )}

                {/* Submit your own recap */}
                {event && (
                  <Link to={`/contribute/recap?event=${encodeURIComponent(event.id)}`}
                    className="flex items-center gap-2 p-3 no-underline transition-all hover:opacity-80"
                    style={{ backgroundColor: `${T.accent}08`, borderRadius: '10px', border: `1px solid ${T.accent}15` }}>
                    <Camera size={14} style={{ color: T.accent }} />
                    <span className="text-[13px] font-medium" style={{ color: T.accent }}>
                      {t('recaps.submitYourRecap')}
                    </span>
                  </Link>
                )}
              </div>
            </div>
          </div>
        </motion.div>

        {/* ─── Reactions & Sharing ─── */}
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}
          className="mt-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4"
          style={{ backgroundColor: T.surface, borderRadius: '14px', border: `1px solid ${T.border}` }}>
          {/* Reactions */}
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-medium uppercase tracking-wider mr-1" style={{ color: T.textMuted }}>
              {t('recaps.react')}
            </span>
            {['👏', '🔥', '❤️', '🎉', '📸'].map(emoji => {
              const count = reactions[emoji] || 0;
              const active = userReactions.has(emoji);
              return (
                <button
                  key={emoji}
                  onClick={() => {
                    const newReactions = { ...reactions };
                    const newUserReactions = new Set(userReactions);
                    if (active) {
                      newReactions[emoji] = Math.max(0, (newReactions[emoji] || 0) - 1);
                      newUserReactions.delete(emoji);
                    } else {
                      newReactions[emoji] = (newReactions[emoji] || 0) + 1;
                      newUserReactions.add(emoji);
                    }
                    setReactions(newReactions);
                    setUserReactions(newUserReactions);
                    try {
                      localStorage.setItem(`recap-reactions-${id}`, JSON.stringify(newReactions));
                      localStorage.setItem(`recap-user-reactions-${id}`, JSON.stringify([...newUserReactions]));
                    } catch {}
                    syncReactionToSupabase(emoji, newReactions[emoji] || 0);
                  }}
                  className="flex items-center gap-1 px-2.5 py-1.5 text-[13px] cursor-pointer transition-all hover:scale-105"
                  style={{
                    backgroundColor: active ? `${T.accent}12` : T.surfaceMuted,
                    border: active ? `1px solid ${T.accent}30` : `1px solid ${T.border}`,
                    borderRadius: '9999px',
                    color: T.text,
                  }}
                >
                  <span>{emoji}</span>
                  {count > 0 && <span className="text-[11px] font-medium" style={{ color: active ? T.accent : T.textMuted }}>{count}</span>}
                </button>
              );
            })}
          </div>

          {/* Sharing */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                const url = window.location.href;
                navigator.clipboard.writeText(url).then(() => {
                  setLinkCopied(true);
                  setTimeout(() => setLinkCopied(false), 2000);
                });
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 text-[12px] font-medium cursor-pointer transition-all hover:opacity-80"
              style={{
                backgroundColor: linkCopied ? '#22C55E10' : T.surfaceMuted,
                color: linkCopied ? '#22C55E' : T.textSecondary,
                borderRadius: '8px',
                border: linkCopied ? '1px solid #22C55E30' : `1px solid ${T.border}`,
              }}
            >
              {linkCopied ? <Check size={13} /> : <Link2 size={13} />}
              {linkCopied ? t('recaps.copied') : t('recaps.copyLink')}
            </button>
            <ShareMenu
              title={displayTitle}
              description={displayCaption?.slice(0, 100) || displayTitle}
              url={window.location.href}
            >
              {({ onClick, ref }) => (
                <button ref={ref} onClick={onClick}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-[12px] font-medium cursor-pointer transition-all hover:opacity-80"
                  style={{
                    backgroundColor: T.surfaceMuted,
                    color: T.textSecondary,
                    borderRadius: '8px',
                    border: `1px solid ${T.border}`,
                  }}>
                  <Share2 size={13} />
                  {t('recaps.share')}
                </button>
              )}
            </ShareMenu>
          </div>
        </motion.div>

        {/* Related recaps */}
        {relatedRecaps.length > 0 && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }}
            className="mt-12">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-[16px] font-semibold" style={{ color: T.text }}>
                {t('recaps.moreFromEvent')}
              </h2>
              <Link to={`/recaps?event=${encodeURIComponent(event.id)}`}
                className="text-[13px] no-underline transition-opacity hover:opacity-70"
                style={{ color: T.accent }}>
                {t('recaps.viewAll')}
              </Link>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {relatedRecaps.map(r => {
                const img = r.thumbnail || (r.media && r.media[0]) || '';
                return (
                  <Link key={r.id} to={`/recaps/${r.id}`}
                    className="group overflow-hidden no-underline transition-opacity hover:opacity-80"
                    style={{ borderRadius: '12px', border: `1px solid ${T.border}`, backgroundColor: T.surface }}>
                    <div className="relative" style={{ aspectRatio: '4/3' }}>
                      {img ? (
                        isVideoUrl(img) ? (
                          <>
                            <video src={img} muted playsInline preload="metadata" className="w-full h-full object-cover" />
                            <div className="absolute inset-0 flex items-center justify-center" style={{ backgroundColor: 'rgba(0,0,0,0.25)' }}>
                              <Play size={16} fill="#fff" color="#fff" />
                            </div>
                          </>
                        ) : (
                          <ImageWithFallback src={img} alt="" className="w-full h-full object-cover" />
                        )
                      ) : (
                        <div className="w-full h-full flex items-center justify-center" style={{ backgroundColor: T.surfaceMuted }}>
                          <Camera size={20} style={{ color: T.textMuted }} />
                        </div>
                      )}
                    </div>
                    <div className="p-2.5">
                      <p className="text-[12px] leading-snug" style={{
                        color: T.textSecondary,
                        display: '-webkit-box',
                        WebkitLineClamp: 2,
                        WebkitBoxOrient: 'vertical',
                        overflow: 'hidden',
                      }}>
                        {isZh ? (r.caption_zh || r.caption) : r.caption}
                      </p>
                      {r.contributorName && (
                        <p className="text-[11px] mt-1" style={{ color: T.textMuted }}>
                          <User size={9} className="inline mr-1" />{r.contributorName}
                        </p>
                      )}
                    </div>
                  </Link>
                );
              })}
            </div>
          </motion.div>
        )}
      </div>

      {/* Lightbox */}
      <AnimatePresence>
        {lightboxOpen && allMedia.length > 0 && (
          <Lightbox
            images={allMedia}
            startIndex={lightboxIndex}
            onClose={() => setLightboxOpen(false)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}