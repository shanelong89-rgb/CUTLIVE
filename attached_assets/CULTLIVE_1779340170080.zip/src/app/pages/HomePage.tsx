import { useEffect } from 'react';
import { useMode } from '../context/ModeContext';
import { useData } from '../context/DataContext';
import { LifestylePage } from './LifestylePage';
import { FoodieHomePage } from '../components/modes/FoodieMode';
import { ArtsyHomePage } from '../components/modes/ArtsyMode';
import { DefaultHomePage } from '../components/modes/DefaultMode';
import { DegenHomePage } from '../components/modes/DegenMode';
import { FamilyHomePage } from '../components/modes/FamilyMode';
import { HomePageSkeleton } from '../components/LoadingSkeleton';

// ═══════════════════════════════════════════════════════════════════
// MAIN HOMEPAGE COMPONENT
// Orchestrates the 5-mode system by delegating to mode-specific
// page components extracted into /components/modes/
// ═══════════════════════════════════════════════════════════════════

export function HomePage() {
  const { currentMode } = useMode();
  const { loading, events, venues, refresh } = useData();

  // Re-fetch data when the homepage mounts (e.g. after publishing from admin)
  useEffect(() => {
    refresh();
  }, []);

  // Show skeleton during initial load (no cached data yet)
  if (loading && events.length === 0 && venues.length === 0) {
    return <HomePageSkeleton />;
  }

  if (currentMode === 'artsy') return <ArtsyHomePage />;
  if (currentMode === 'foodie') return <FoodieHomePage />;
  if (currentMode === 'degen') return <DegenHomePage />;
  if (currentMode === 'family') return <FamilyHomePage />;
  if (currentMode === 'lifestyle') return <LifestylePage />;

  return <DefaultHomePage />;
}