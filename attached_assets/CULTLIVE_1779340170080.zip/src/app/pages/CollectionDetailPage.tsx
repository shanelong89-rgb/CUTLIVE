/**
 * CollectionDetailPage — /collections/:id
 * Shows all items in a collection with event/venue cards
 */
import { useMemo, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router';
import { motion } from 'motion/react';
import {
  ArrowLeft, FolderOpen, Lock, Globe, Calendar, MapPin,
  Trash2, Loader2, BookmarkX, Edit3, ExternalLink,
} from 'lucide-react';
import { useCollections } from '../context/CollectionsContext';
import { useAuth } from '../context/AuthContext';
import { useMode } from '../context/ModeContext';
import { useData } from '../context/DataContext';
import { getDesignTokens } from '../data/mode-styles';
import { modeConfig } from '../data/mock-data';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import { getEventLink, getVenueLink } from '../utils/event-helpers';
import { useTranslation } from 'react-i18next';

export function CollectionDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { currentMode } = useMode();
  const { collections, removeFromCollection, deleteCollection } = useCollections();
  const { events, venues } = useData();
  const { t, i18n } = useTranslation();
  const isZh = i18n.language?.startsWith('zh');

  const tokens = getDesignTokens(currentMode);
  const modeColor = currentMode && currentMode !== 'lifestyle'
    ? modeConfig[currentMode].color
    : currentMode === 'lifestyle' ? '#2D6A4F' : '#8338EC';

  const [removingId, setRemovingId] = useState<string | null>(null);
  const [deletingCollection, setDeletingCollection] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);

  const collection = collections.find(c => c.id === id);

  // Resolve items to event/venue objects
  const resolvedItems = useMemo(() => {
    if (!collection) return [];
    return collection.items.map(item => {
      if (item.type === 'event') {
        const event = events.find(e => e.id === item.id);
        return event ? { type: 'event' as const, data: event, addedAt: item.addedAt } : null;
      } else {
        const venue = venues.find(v => v.id === item.id);
        return venue ? { type: 'venue' as const, data: venue, addedAt: item.addedAt } : null;
      }
    }).filter(Boolean) as Array<{ type: 'event' | 'venue'; data: any; addedAt: string }>;
  }, [collection, events, venues]);

  const handleRemove = async (itemId: string) => {
    if (!id) return;
    setRemovingId(itemId);
    try {
      await removeFromCollection(id, itemId);
    } catch {}
    setRemovingId(null);
  };

  const handleDeleteCollection = async () => {
    if (!id) return;
    setDeletingCollection(true);
    try {
      await deleteCollection(id);
      navigate('/collections');
    } catch {}
    setDeletingCollection(false);
  };

  if (!user) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center px-4" data-nav-theme="dark">
        <div className="text-center">
          <p className="text-sm mb-4" style={{ color: tokens.textMuted }}>{t('collections.signInToUse')}</p>
          <Link to="/login" className="px-5 py-2.5 text-sm font-medium rounded-xl hover:opacity-80"
            style={{ backgroundColor: modeColor, color: '#fff', textDecoration: 'none' }}>
            {t('collections.signIn')}
          </Link>
        </div>
      </div>
    );
  }

  if (!collection) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center px-4" data-nav-theme="dark">
        <div className="text-center">
          <FolderOpen size={40} style={{ color: tokens.textMuted, opacity: 0.3, margin: '0 auto 16px' }} />
          <p className="font-semibold mb-1" style={{ color: tokens.textPrimary }}>{t('collections.collectionNotFound')}</p>
          <p className="text-sm mb-4" style={{ color: tokens.textMuted }}>{t('collections.collectionNotFoundDesc')}</p>
          <Link to="/collections" className="text-sm hover:opacity-70" style={{ color: modeColor, textDecoration: 'none' }}>
            ← {t('profile.collections')}
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen" style={{ backgroundColor: tokens.pageBg }} data-nav-theme="dark">
      {/* Header */}
      <div
        className="sticky top-16 z-10 px-4 py-4"
        style={{
          backgroundColor: tokens.pageBg + 'f0',
          backdropFilter: 'blur(12px)',
          borderBottom: `1px solid ${tokens.cardBorder}`,
        }}
      >
        <div className="max-w-4xl mx-auto flex items-center gap-4">
          <button
            onClick={() => navigate('/collections')}
            className="p-2 rounded-xl cursor-pointer hover:opacity-70 flex-shrink-0"
            style={{ backgroundColor: tokens.surfaceBg, color: tokens.textMuted }}
          >
            <ArrowLeft size={16} />
          </button>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              {collection.isPublic
                ? <Globe size={12} style={{ color: tokens.textMuted }} />
                : <Lock size={12} style={{ color: tokens.textMuted }} />}
              <span className="text-[11px]" style={{ color: tokens.textMuted }}>
                {collection.isPublic ? t('collections.public') : t('collections.private')}
              </span>
            </div>
            <h1 className="text-lg font-bold truncate" style={{ color: tokens.textPrimary }}>
              {collection.name}
            </h1>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            <Link
              to={`/collections`}
              state={{ editId: collection.id }}
              className="p-2 rounded-xl cursor-pointer hover:opacity-70"
              style={{ backgroundColor: `${modeColor}12`, color: modeColor }}
            >
              <Edit3 size={14} />
            </Link>
            <button
              onClick={() => setConfirmDelete(true)}
              className="p-2 rounded-xl cursor-pointer hover:opacity-70"
              style={{ backgroundColor: 'rgba(239,68,68,0.08)', color: '#EF4444' }}
            >
              <Trash2 size={14} />
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Description */}
        {collection.description && (
          <p className="text-sm mb-6" style={{ color: tokens.textMuted }}>{collection.description}</p>
        )}

        {/* Item count */}
        <div className="flex items-center gap-3 mb-6">
          <span
            className="px-3 py-1 rounded-full text-xs font-medium"
            style={{ backgroundColor: `${modeColor}12`, color: modeColor }}
          >
            {resolvedItems.length === 1 ? t('collections.itemCount', { count: 1 }) : t('collections.itemCountPlural', { count: resolvedItems.length })}
          </span>
          <span className="text-xs" style={{ color: tokens.textMuted }}>
            {isZh ? '更新於' : 'Updated'} {new Date(collection.updatedAt).toLocaleDateString(isZh ? 'zh-HK' : 'en-HK', { day: 'numeric', month: 'short', year: 'numeric' })}
          </span>
        </div>

        {/* Confirm delete overlay */}
        {confirmDelete && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6 p-4 rounded-2xl"
            style={{ backgroundColor: 'rgba(239,68,68,0.06)', border: '1px solid rgba(239,68,68,0.15)' }}
          >
            <p className="text-sm font-medium mb-1" style={{ color: '#EF4444' }}>{t('collections.deleteCollection')}?</p>
            <p className="text-xs mb-3" style={{ color: tokens.textMuted }}>
              {t('collections.deleteConfirm', { name: collection.name })}
            </p>
            <div className="flex gap-2">
              <button
                onClick={() => setConfirmDelete(false)}
                className="flex-1 py-2 text-sm rounded-xl cursor-pointer hover:opacity-70"
                style={{ backgroundColor: tokens.surfaceBg, color: tokens.textMuted }}
              >
                {t('collections.cancel')}
              </button>
              <button
                onClick={handleDeleteCollection}
                disabled={deletingCollection}
                className="flex-1 py-2 text-sm font-medium rounded-xl cursor-pointer hover:opacity-80 flex items-center justify-center gap-1.5"
                style={{ backgroundColor: '#EF4444', color: '#fff' }}
              >
                {deletingCollection ? <Loader2 size={14} className="animate-spin" /> : <Trash2 size={14} />}
                {t('collections.delete')}
              </button>
            </div>
          </motion.div>
        )}

        {/* Empty state */}
        {resolvedItems.length === 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-20"
          >
            <div
              className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4"
              style={{ backgroundColor: `${modeColor}10` }}
            >
              <BookmarkX size={32} style={{ color: modeColor, opacity: 0.4 }} />
            </div>
            <h3 className="text-lg font-semibold mb-2" style={{ color: tokens.textPrimary }}>
              {t('collections.collectionEmpty')}
            </h3>
            <p className="text-sm mb-6" style={{ color: tokens.textMuted }}>
              {t('collections.collectionEmptyDesc')}
            </p>
            <div className="flex items-center justify-center gap-3">
              <Link to="/events" className="px-4 py-2 text-sm font-medium rounded-xl hover:opacity-80 transition-opacity"
                style={{ backgroundColor: modeColor, color: '#fff', textDecoration: 'none' }}>
                {t('collections.browseEvents')}
              </Link>
              <Link to="/map" className="px-4 py-2 text-sm rounded-xl hover:opacity-80 transition-opacity"
                style={{ backgroundColor: tokens.surfaceBg, color: tokens.textPrimary, border: `1px solid ${tokens.cardBorder}`, textDecoration: 'none' }}>
                {t('collections.exploreMap')}
              </Link>
            </div>
          </motion.div>
        )}

        {/* Items grid */}
        {resolvedItems.length > 0 && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {resolvedItems.map((item, i) => (
              <motion.div
                key={item.type === 'event' ? item.data.id : item.data.id}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.06 }}
                className="group relative rounded-2xl overflow-hidden"
                style={{
                  backgroundColor: tokens.surfaceBg,
                  border: `1px solid ${tokens.cardBorder}`,
                }}
              >
                {/* Image */}
                {item.data.image && (
                  <div className="relative h-36 overflow-hidden">
                    <ImageWithFallback
                      src={item.data.image}
                      alt={item.data.title || item.data.name}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                    {/* Type badge */}
                    <div className="absolute top-2 left-2">
                      <span
                        className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium backdrop-blur-sm"
                        style={{ backgroundColor: item.type === 'event' ? `${modeColor}cc` : 'rgba(0,0,0,0.5)', color: '#fff' }}
                      >
                        {item.type === 'event' ? <Calendar size={9} /> : <MapPin size={9} />}
                        {item.type === 'event' ? (isZh ? '活動' : 'Event') : (isZh ? '場地' : 'Venue')}
                      </span>
                    </div>
                    {/* Remove button */}
                    <button
                      onClick={() => handleRemove(item.data.id)}
                      disabled={removingId === item.data.id}
                      className="absolute top-2 right-2 p-1.5 rounded-full cursor-pointer opacity-0 group-hover:opacity-100 transition-opacity hover:scale-110"
                      style={{ backgroundColor: 'rgba(239,68,68,0.85)', color: '#fff' }}
                      title={t('collections.removeItem')}
                    >
                      {removingId === item.data.id
                        ? <Loader2 size={12} className="animate-spin" />
                        : <Trash2 size={12} />}
                    </button>
                  </div>
                )}

                <div className="p-3">
                  <h3 className="font-semibold text-sm leading-snug mb-1 line-clamp-2" style={{ color: tokens.textPrimary }}>
                    {item.type === 'event' ? item.data.title : item.data.name}
                  </h3>
                  {item.type === 'event' && (
                    <div className="flex items-center gap-1 text-xs mb-1" style={{ color: tokens.textMuted }}>
                      <Calendar size={10} />
                      {item.data.date} · {item.data.time}
                    </div>
                  )}
                  <div className="flex items-center gap-1 text-xs" style={{ color: tokens.textMuted }}>
                    <MapPin size={10} />
                    {item.data.district || item.data.venueName}
                  </div>

                  {/* Action row */}
                  <div className="flex items-center gap-2 mt-3 pt-2.5" style={{ borderTop: `1px solid ${tokens.cardBorder}` }}>
                    <Link
                      to={item.type === 'event' ? getEventLink(item.data) : getVenueLink(item.data)}
                      className="flex items-center gap-1 text-xs font-medium hover:opacity-70 transition-opacity"
                      style={{ color: modeColor, textDecoration: 'none' }}
                    >
                      <ExternalLink size={11} />
                      {item.type === 'event' ? t('venueDetail.events') : t('map.venues')}
                    </Link>
                    <span className="text-[10px] ml-auto" style={{ color: tokens.textMuted }}>
                      {t('collections.addedOn', { date: new Date(item.addedAt).toLocaleDateString(isZh ? 'zh-HK' : 'en-HK', { day: 'numeric', month: 'short' }) })}
                    </span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}