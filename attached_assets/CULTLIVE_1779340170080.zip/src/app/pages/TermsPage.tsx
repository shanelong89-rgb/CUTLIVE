import { useTranslation } from 'react-i18next';
import { Link } from 'react-router';
import { useMode } from '../context/ModeContext';
import { getDesignTokens } from '../data/mode-styles';
import { ArrowLeft } from 'lucide-react';

export function TermsPage() {
  const { t, i18n } = useTranslation();
  const { currentMode } = useMode();
  const tokens = getDesignTokens(currentMode);
  const isZh = i18n.language?.startsWith('zh');

  return (
    <div className="min-h-screen px-4 sm:px-6 lg:px-8 py-8 sm:py-12" style={{ backgroundColor: tokens.pageBg }}>
      <div className="max-w-3xl mx-auto">
        <Link
          to="/"
          className="inline-flex items-center gap-1.5 text-sm mb-6 transition-opacity hover:opacity-70"
          style={{ color: tokens.textMuted }}
        >
          <ArrowLeft size={14} />
          {t('common.back')}
        </Link>

        <h1
          className="text-2xl sm:text-3xl font-bold mb-2"
          style={{ color: tokens.textPrimary, fontFamily: tokens.headingFont }}
        >
          {t('legal.termsTitle')}
        </h1>
        <p className="text-sm mb-8" style={{ color: tokens.textMuted }}>
          {t('legal.effectiveDate', { date: '2026-03-17' })}
        </p>

        <div className="space-y-8" style={{ color: tokens.textSecondary, lineHeight: 1.8 }}>
          {/* Section 1 */}
          <section>
            <SectionHeading tokens={tokens}>{isZh ? '1. 接受條款' : '1. Acceptance of Terms'}</SectionHeading>
            <p className="text-sm">
              {isZh
                ? '使用 CULTIVE 文化活平台（以下簡稱「本平台」），即表示你同意受本使用條款約束。如果你不同意這些條款，請勿使用本平台。我們保留隨時修改這些條款的權利，修改後繼續使用本平台即表示接受修改後的條款。'
                : 'By accessing and using the CULTIVE 文化活 platform ("the Platform"), you agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use the Platform. We reserve the right to modify these terms at any time, and your continued use constitutes acceptance of the modified terms.'}
            </p>
          </section>

          {/* Section 2 */}
          <section>
            <SectionHeading tokens={tokens}>{isZh ? '2. 平台描述' : '2. Platform Description'}</SectionHeading>
            <p className="text-sm">
              {isZh
                ? 'CULTIVE 是一個香港文化活動探索平台，為用戶提供五種探索模式來發現文化活動、場地和體驗。本平台匯集來自各種來源的活動資訊，並依據用戶偏好進行策劃和呈現。'
                : 'CULTIVE is a Hong Kong cultural events discovery platform that provides users with five discovery modes to explore cultural events, venues, and experiences. The Platform aggregates event information from various sources and curates content based on user preferences.'}
            </p>
          </section>

          {/* Section 3 */}
          <section>
            <SectionHeading tokens={tokens}>{isZh ? '3. 用戶帳戶' : '3. User Accounts'}</SectionHeading>
            <ul className="list-disc pl-5 space-y-2 text-sm">
              <li>{isZh ? '你必須提供準確的帳戶資訊。' : 'You must provide accurate account information.'}</li>
              <li>{isZh ? '你有責任保護你的帳戶憑證的安全。' : 'You are responsible for maintaining the security of your account credentials.'}</li>
              <li>{isZh ? '你必須年滿 13 歲方可建立帳戶。13 歲以下的兒童須由父母或監護人監督使用。' : 'You must be at least 13 years old to create an account. Children under 13 must use the platform under parental or guardian supervision.'}</li>
              <li>{isZh ? '我們保留因違反條款而暫停或終止帳戶的權利。' : 'We reserve the right to suspend or terminate accounts for violation of these terms.'}</li>
            </ul>
          </section>

          {/* Section 4 */}
          <section>
            <SectionHeading tokens={tokens}>{isZh ? '4. 用戶提交內容' : '4. User Submissions'}</SectionHeading>
            <p className="text-sm mb-3">
              {isZh
                ? '透過投稿功能提交的內容須遵守以下條件：'
                : 'Content submitted through the Contribute feature is subject to the following:'}
            </p>
            <ul className="list-disc pl-5 space-y-2 text-sm">
              <li>{isZh ? '你保證提交的內容是準確的，且你有權提交該內容。' : 'You warrant that submissions are accurate and that you have the right to submit them.'}</li>
              <li>{isZh ? '你授予 CULTIVE 非獨家、免版稅的許可，可在本平台上使用、展示和分發你提交的內容。' : 'You grant CULTIVE a non-exclusive, royalty-free license to use, display, and distribute your submissions on the Platform.'}</li>
              <li>{isZh ? '提交的內容須經審核流程，我們保留拒絕或刪除任何內容的權利。' : 'Submissions are subject to a review process, and we reserve the right to reject or remove any content.'}</li>
              <li>{isZh ? '你不得提交非法、冒犯性、誤導性或侵犯第三方權利的內容。' : 'You must not submit content that is illegal, offensive, misleading, or infringes on third-party rights.'}</li>
            </ul>
          </section>

          {/* Section 5 */}
          <section>
            <SectionHeading tokens={tokens}>{isZh ? '5. 知識產權' : '5. Intellectual Property'}</SectionHeading>
            <ul className="list-disc pl-5 space-y-2 text-sm">
              <li>{isZh ? 'CULTIVE 平台的設計、程式碼、品牌和原創內容均為 CULTIVE 的財產。' : 'The Platform\'s design, code, branding, and original content are the property of CULTIVE.'}</li>
              <li>{isZh ? '活動資訊和圖片可能屬於各自的活動主辦方和場地所有者。' : 'Event information and images may belong to their respective event organizers and venue owners.'}</li>
              <li>{isZh ? '未經我們事先書面同意，你不得複製、修改或分發平台內容作商業用途。' : 'You may not reproduce, modify, or distribute Platform content for commercial purposes without our prior written consent.'}</li>
            </ul>
          </section>

          {/* Section 6 */}
          <section>
            <SectionHeading tokens={tokens}>{isZh ? '6. 活動資訊免責聲明' : '6. Event Information Disclaimer'}</SectionHeading>
            <p className="text-sm">
              {isZh
                ? 'CULTIVE 匯集來自多種來源的活動資訊，包括活動主辦方、場地和社群提交。雖然我們盡力確保資訊的準確性，但我們：'
                : 'CULTIVE aggregates event information from multiple sources, including event organizers, venues, and community submissions. While we strive for accuracy, we:'}
            </p>
            <ul className="list-disc pl-5 space-y-2 text-sm mt-3">
              <li>{isZh ? '不保證活動資訊（包括日期、時間、價格和場地）的準確性或完整性。' : 'Do not guarantee the accuracy or completeness of event information, including dates, times, prices, and venues.'}</li>
              <li>{isZh ? '不為因活動取消、更改或資訊不準確而造成的任何損失或不便承擔責任。' : 'Are not responsible for any losses or inconvenience caused by event cancellations, changes, or inaccurate information.'}</li>
              <li>{isZh ? '建議用戶在參加活動前直接向主辦方確認詳情。' : 'Recommend that users verify event details directly with organizers before attending.'}</li>
            </ul>
          </section>

          {/* Section 7 */}
          <section>
            <SectionHeading tokens={tokens}>{isZh ? '7. 可接受的使用' : '7. Acceptable Use'}</SectionHeading>
            <p className="text-sm mb-3">
              {isZh ? '使用本平台時，你不得：' : 'When using the Platform, you must not:'}
            </p>
            <ul className="list-disc pl-5 space-y-2 text-sm">
              <li>{isZh ? '使用自動化工具或爬蟲大量擷取平台內容。' : 'Use automated tools or scrapers to bulk extract Platform content.'}</li>
              <li>{isZh ? '嘗試未經授權存取其他用戶帳戶或平台系統。' : 'Attempt unauthorized access to other user accounts or Platform systems.'}</li>
              <li>{isZh ? '提交虛假或誤導性的活動資訊。' : 'Submit false or misleading event information.'}</li>
              <li>{isZh ? '將平台用於任何非法活動。' : 'Use the Platform for any illegal activities.'}</li>
              <li>{isZh ? '干擾或試圖干擾平台的正常運作。' : 'Interfere with or attempt to disrupt the Platform\'s normal operation.'}</li>
            </ul>
          </section>

          {/* Section 8 */}
          <section>
            <SectionHeading tokens={tokens}>{isZh ? '8. 責任限制' : '8. Limitation of Liability'}</SectionHeading>
            <p className="text-sm">
              {isZh
                ? '在法律允許的最大範圍內，CULTIVE 不對因使用或無法使用本平台而產生的任何直接、間接、附帶、特殊或後果性損害承擔責任。本平台以「現狀」和「可用」的基礎提供，不作任何明示或暗示的保證。'
                : 'To the maximum extent permitted by law, CULTIVE shall not be liable for any direct, indirect, incidental, special, or consequential damages arising from your use of or inability to use the Platform. The Platform is provided on an "as is" and "as available" basis without warranties of any kind, either express or implied.'}
            </p>
          </section>

          {/* Section 9 */}
          <section>
            <SectionHeading tokens={tokens}>{isZh ? '9. 第三方連結' : '9. Third-Party Links'}</SectionHeading>
            <p className="text-sm">
              {isZh
                ? '本平台可能包含連結至第三方網站（如活動購票頁面、場地網站）。我們不對第三方網站的內容、私隱政策或做法承擔責任。你應自行查閱這些網站的條款。'
                : 'The Platform may contain links to third-party websites (such as event ticketing pages, venue websites). We are not responsible for the content, privacy policies, or practices of third-party websites. You should review the terms of those websites independently.'}
            </p>
          </section>

          {/* Section 10 */}
          <section>
            <SectionHeading tokens={tokens}>{isZh ? '10. 終止' : '10. Termination'}</SectionHeading>
            <p className="text-sm">
              {isZh
                ? '我們保留隨時以任何原因暫停或終止你對平台的存取權利，包括但不限於違反本使用條款。終止後，你使用平台的權利將立即終止。'
                : 'We reserve the right to suspend or terminate your access to the Platform at any time for any reason, including but not limited to violation of these Terms. Upon termination, your right to use the Platform will immediately cease.'}
            </p>
          </section>

          {/* Section 11 */}
          <section>
            <SectionHeading tokens={tokens}>{isZh ? '11. 管轄法律' : '11. Governing Law'}</SectionHeading>
            <p className="text-sm">
              {isZh
                ? '本使用條款受香港特別行政區法律管轄。因本條款引起或與之相關的任何爭議，將提交香港法院專屬管轄。'
                : 'These Terms of Service are governed by the laws of the Hong Kong Special Administrative Region. Any disputes arising from or in connection with these terms shall be subject to the exclusive jurisdiction of the courts of Hong Kong.'}
            </p>
          </section>

          {/* Section 12 */}
          <section>
            <SectionHeading tokens={tokens}>{isZh ? '12. 聯繫我們' : '12. Contact Us'}</SectionHeading>
            <p className="text-sm">
              {isZh
                ? '如有任何關於本使用條款的查詢，請聯繫我們：'
                : 'If you have questions about these Terms of Service, please contact us:'}
            </p>
            <div className="mt-3 text-sm space-y-1">
              <p><strong>{isZh ? '電郵：' : 'Email: '}</strong>legal@cultive.city</p>
              <p><strong>{isZh ? '平台：' : 'Platform: '}</strong>CULTIVE 文化活</p>
              <p><strong>{isZh ? '地點：' : 'Location: '}</strong>{isZh ? '香港' : 'Hong Kong SAR'}</p>
            </div>
          </section>

          {/* Cross reference */}
          <section
            className="pt-6 mt-6 text-xs"
            style={{ borderTop: `1px solid ${tokens.cardBorder}`, color: tokens.textMuted }}
          >
            <p>
              {isZh ? (
                <>另請參閱我們的 <Link to="/privacy" className="underline hover:opacity-70" style={{ color: tokens.textSecondary }}>私隱政策</Link>。</>
              ) : (
                <>Please also review our <Link to="/privacy" className="underline hover:opacity-70" style={{ color: tokens.textSecondary }}>Privacy Policy</Link>.</>
              )}
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}

function SectionHeading({ children, tokens }: { children: React.ReactNode; tokens: any }) {
  return (
    <h2
      className="text-lg font-semibold mb-3"
      style={{ color: tokens.textPrimary, fontFamily: tokens.headingFont }}
    >
      {children}
    </h2>
  );
}
