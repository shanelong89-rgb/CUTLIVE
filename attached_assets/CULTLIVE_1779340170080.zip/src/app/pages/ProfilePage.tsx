/**
 * ProfilePage — full user profile & settings at /profile
 * Tabs: Overview · Notifications · Privacy · Preferences
 * Applies neutral editorial design when no mode is active.
 */
import { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { Link, useSearchParams, useNavigate } from 'react-router';
import { motion, AnimatePresence } from 'motion/react';
import {
  User, Bell, Shield, Sliders, Camera, Save, Loader2, CheckCircle2,
  Heart, FolderOpen, Bookmark, Calendar, LogOut, Sparkles, Globe, Lock,
  Eye, EyeOff, ChevronRight, Edit3, AlertCircle, X, Check, MapPin,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useMode } from '../context/ModeContext';
import { useNotifications } from '../context/NotificationsContext';
import { useCollections } from '../context/CollectionsContext';
import { getDesignTokens } from '../data/mode-styles';
import { modeConfig } from '../data/mock-data';
import { projectId, publicAnonKey } from '../config/supabase';
import { useNeutralTheme } from '../context/NeutralThemeContext';
import { useData } from '../context/DataContext';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import { AvatarCropModal } from '../components/AvatarCropModal';

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-d507b98c`;

const TABS = [
  { id: 'overview', label: 'Overview', icon: User },
  { id: 'notifications', label: 'Notifications', icon: Bell },
  { id: 'privacy', label: 'Privacy', icon: Shield },
  { id: 'preferences', label: 'Preferences', icon: Sliders },
] as const;

type TabId = typeof TABS[number]['id'];

const INTEREST_OPTIONS = [
  { id: 'nightlife', label: 'Nightlife', emoji: '\u{1F319}' },
  { id: 'music', label: 'Live Music', emoji: '\u{1F3B5}' },
  { id: 'underground', label: 'Underground', emoji: '\u{1F39B}\uFE0F' },
  { id: 'galleries', label: 'Galleries', emoji: '\u{1F5BC}\uFE0F' },
  { id: 'exhibitions', label: 'Exhibitions', emoji: '\u{1F3DB}\uFE0F' },
  { id: 'theater', label: 'Theater', emoji: '\u{1F3AD}' },
  { id: 'film', label: 'Film', emoji: '\u{1F3AC}' },
  { id: 'food', label: 'Food & Dining', emoji: '\u{1F35C}' },
  { id: 'drinks', label: 'Cocktails', emoji: '\u{1F378}' },
  { id: 'markets', label: 'Markets', emoji: '\u{1F6CD}\uFE0F' },
  { id: 'workshops', label: 'Workshops', emoji: '\u{1F528}' },
  { id: 'outdoor', label: 'Outdoor', emoji: '\u{1F33F}' },
  { id: 'kids', label: 'Kid-Friendly', emoji: '\u{1F468}\u200D\u{1F469}\u200D\u{1F467}' },
  { id: 'community', label: 'Community', emoji: '\u{1F91D}' },
  { id: 'wellness', label: 'Wellness', emoji: '\u{1F9D8}' },
  { id: 'popup', label: 'Pop-ups', emoji: '\u26A1' },
  { id: 'photography', label: 'Photography', emoji: '\u{1F4F8}' },
];

export function ProfilePage() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { user, accessToken, savedEventIds, signOut } = useAuth();
  const { currentMode } = useMode();
  const { settings: notifSettings, updateSettings: updateNotifSettings } = useNotifications();
  const { collections } = useCollections();
  const { palette: neutralPalette } = useNeutralTheme();
  const isNeutral = !currentMode;

  const tokens = getDesignTokens(currentMode);
  const modeColor = currentMode && currentMode !== 'lifestyle'
    ? modeConfig[currentMode].color
    : currentMode === 'lifestyle' ? '#2D6A4F' : '#8338EC';

  const initialTab = (searchParams.get('tab') as TabId) || 'overview';
  const [activeTab, setActiveTab] = useState<TabId>(initialTab);

  const [editName, setEditName] = useState(user?.name || '');
  const [editEmail, setEditEmail] = useState(user?.email || '');
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [showCurrentPw, setShowCurrentPw] = useState(false);
  const [showNewPw, setShowNewPw] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [saveError, setSaveError] = useState('');
  const [interests, setInterests] = useState<string[]>([]);
  const [prefSaving, setPrefSaving] = useState(false);
  const [prefSuccess, setPrefSuccess] = useState(false);

  // ─── Avatar upload state ───
  const avatarInputRef = useRef<HTMLInputElement>(null);
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [avatarUploading, setAvatarUploading] = useState(false);
  const [cropFile, setCropFile] = useState<File | null>(null);
  const [cropModalOpen, setCropModalOpen] = useState(false);

  // ─── Attendance tracking state ───
  const { allEvents, events } = useData();
  const [attendedIds, setAttendedIds] = useState<string[]>([]);
  const [attendanceLoading, setAttendanceLoading] = useState(true);

  // Load avatar and attendance from server
  useEffect(() => {
    if (!user) return;
    const headers = { 'Authorization': `Bearer ${accessToken || publicAnonKey}`, 'X-User-Id': user.id };

    // Fetch profile (avatar)
    fetch(`${API_BASE}/user/profile`, { headers })
      .then(r => r.json())
      .then(data => {
        if (data.profile?.avatarUrl) setAvatarUrl(data.profile.avatarUrl);
      })
      .catch(err => console.log('Error fetching profile avatar:', err));

    // Fetch attendance
    fetch(`${API_BASE}/user/attendance`, { headers })
      .then(r => r.json())
      .then(data => {
        if (Array.isArray(data.attendedIds)) setAttendedIds(data.attendedIds);
      })
      .catch(err => console.log('Error fetching attendance:', err))
      .finally(() => setAttendanceLoading(false));
  }, [user, accessToken]);

  // Handle avatar file selection
  const handleAvatarUpload = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    if (!file.type.startsWith('image/')) return;
    if (file.size > 5 * 1024 * 1024) { alert('Image must be under 5MB'); return; }

    // Open crop modal instead of uploading directly
    setCropFile(file);
    setCropModalOpen(true);
    if (avatarInputRef.current) avatarInputRef.current.value = '';
  }, [user]);

  // Upload cropped avatar blob
  const handleCroppedUpload = useCallback(async (blob: Blob) => {
    if (!user) return;
    setAvatarUploading(true);
    try {
      const formData = new FormData();
      formData.append('file', blob, 'avatar.jpg');
      const res = await fetch(`${API_BASE}/user/avatar`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${accessToken || publicAnonKey}`, 'X-User-Id': user.id },
        body: formData,
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Upload failed');
      if (data.avatarUrl) setAvatarUrl(data.avatarUrl);
      setCropModalOpen(false);
      setCropFile(null);
    } catch (err: any) {
      console.log('Avatar upload error:', err);
      alert(err.message || 'Failed to upload photo');
    } finally {
      setAvatarUploading(false);
    }
  }, [user, accessToken]);

  // Toggle attendance for an event
  const toggleAttendance = useCallback(async (eventId: string) => {
    if (!user) return;
    const isAttended = attendedIds.includes(eventId);
    const optimistic = isAttended ? attendedIds.filter(id => id !== eventId) : [...attendedIds, eventId];
    setAttendedIds(optimistic);
    try {
      const res = await fetch(`${API_BASE}/user/attendance`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${accessToken || publicAnonKey}`, 'X-User-Id': user.id },
        body: JSON.stringify({ eventId, action: isAttended ? 'remove' : 'add' }),
      });
      const data = await res.json();
      if (Array.isArray(data.attendedIds)) setAttendedIds(data.attendedIds);
    } catch (err) {
      console.log('Error toggling attendance:', err);
      setAttendedIds(attendedIds); // revert
    }
  }, [user, accessToken, attendedIds]);

  // Past/ongoing events that the user saved (candidates for attendance)
  const attendableEvents = useMemo(() => {
    return allEvents
      .filter(e => savedEventIds.includes(e.id) && (e.status === 'past' || e.status === 'ongoing'))
      .sort((a, b) => new Date(b.date || '').getTime() - new Date(a.date || '').getTime());
  }, [allEvents, savedEventIds]);

  const attendedCount = attendedIds.length;

  // ─── Personalized Recommendations based on attendance categories ───
  const recommendedEvents = useMemo(() => {
    if (attendedIds.length === 0) return [];
    // Gather categories from attended events
    const attendedEvents = allEvents.filter(e => attendedIds.includes(e.id));
    const catCounts: Record<string, number> = {};
    attendedEvents.forEach(e => {
      const cats = Array.isArray(e.categories) ? e.categories : e.category ? [e.category] : [];
      cats.forEach((c: string) => { catCounts[c] = (catCounts[c] || 0) + 1; });
    });
    const topCats = Object.entries(catCounts).sort((a, b) => b[1] - a[1]).map(([c]) => c);
    if (topCats.length === 0) return [];

    // Find upcoming events matching those categories, excluding already saved/attended
    const excludeIds = new Set([...savedEventIds, ...attendedIds]);
    return events
      .filter(e => {
        if (excludeIds.has(e.id)) return false;
        if (e.status === 'past') return false;
        const eCats = Array.isArray(e.categories) ? e.categories : e.category ? [e.category] : [];
        return eCats.some((c: string) => topCats.includes(c));
      })
      .slice(0, 6);
  }, [attendedIds, allEvents, events, savedEventIds]);

  useEffect(() => {
    try {
      const raw = localStorage.getItem('cultive-preferences');
      const prefs = raw ? JSON.parse(raw) : null;
      if (prefs?.interests) setInterests(prefs.interests);
    } catch {}
  }, []);

  useEffect(() => {
    if (user) { setEditName(user.name || ''); setEditEmail(user.email || ''); }
  }, [user]);

  // Resolved palette
  const p = isNeutral ? {
    pageBg: neutralPalette.bg,
    surfaceBg: neutralPalette.bgAlt,
    textPrimary: neutralPalette.text,
    textMuted: neutralPalette.textMuted,
    textSecondary: neutralPalette.textSecondary,
    cardBorder: neutralPalette.border,
    borderSubtle: neutralPalette.borderSubtle,
    accent: neutralPalette.text,
    ctaBg: neutralPalette.ctaBg,
    ctaText: neutralPalette.ctaText,
  } : {
    pageBg: tokens.pageBg,
    surfaceBg: tokens.surfaceBg,
    textPrimary: tokens.textPrimary,
    textMuted: tokens.textMuted,
    textSecondary: tokens.textSecondary || tokens.textMuted,
    cardBorder: tokens.cardBorder,
    borderSubtle: tokens.cardBorder,
    accent: modeColor,
    ctaBg: modeColor,
    ctaText: '#fff',
  };
  const rad = isNeutral ? '4px' : '12px';

  if (!user) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center px-4" data-nav-theme="dark">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center max-w-sm">
          <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4" style={{ backgroundColor: `${p.accent}15` }}>
            <User size={28} style={{ color: p.accent }} />
          </div>
          <h2 className="text-xl font-semibold mb-2" style={{ color: p.textPrimary }}>Sign in to view your profile</h2>
          <p className="text-sm mb-6" style={{ color: p.textMuted }}>Manage your settings, collections, and preferences.</p>
          <div className="flex items-center justify-center gap-3">
            <Link to="/login" className="px-5 py-2.5 text-sm font-medium hover:opacity-80 transition-opacity" style={{ backgroundColor: p.ctaBg, color: p.ctaText, textDecoration: 'none', borderRadius: rad }}>Sign in</Link>
            <Link to="/signup" className="px-5 py-2.5 text-sm font-medium hover:opacity-80 transition-opacity" style={{ backgroundColor: p.surfaceBg, color: p.textPrimary, border: `1px solid ${p.cardBorder}`, textDecoration: 'none', borderRadius: rad }}>Create account</Link>
          </div>
        </motion.div>
      </div>
    );
  }

  const handleSaveProfile = async () => {
    setSaving(true); setSaveError(''); setSaveSuccess(false);
    try {
      const res = await fetch(`${API_BASE}/user/profile`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${accessToken || publicAnonKey}`, 'X-User-Id': user.id },
        body: JSON.stringify({ name: editName, ...(newPassword ? { newPassword, currentPassword } : {}) }),
      });
      if (!res.ok) { const err = await res.json(); throw new Error(err.error || 'Failed to update profile'); }
      setSaveSuccess(true); setCurrentPassword(''); setNewPassword('');
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (err: any) { setSaveError(err.message || 'Something went wrong'); } finally { setSaving(false); }
  };

  const handleSaveInterests = () => {
    setPrefSaving(true);
    try {
      const existing = JSON.parse(localStorage.getItem('cultive-preferences') || '{}');
      localStorage.setItem('cultive-preferences', JSON.stringify({ ...existing, interests }));
      setPrefSuccess(true); setTimeout(() => setPrefSuccess(false), 2000);
    } catch {} setPrefSaving(false);
  };

  const toggleInterest = (id: string) => setInterests(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  const handleSignOut = async () => { await signOut(); navigate('/'); };
  const initials = (user.name || user.email || 'U').charAt(0).toUpperCase();

  return (
    <div className="min-h-screen" style={{ backgroundColor: p.pageBg }} data-nav-theme="dark">
      {/* Hero header */}
      <div
        className="relative pt-20 pb-8 px-4"
        style={{
          background: isNeutral
            ? `linear-gradient(180deg, ${neutralPalette.border}44 0%, transparent 100%)`
            : `linear-gradient(180deg, ${modeColor}18 0%, transparent 100%)`,
          borderBottom: `1px solid ${p.cardBorder}`,
        }}
      >
        <div className="max-w-3xl mx-auto flex flex-col sm:flex-row items-center sm:items-end gap-5">
          <div className="relative">
            <div
              className="w-20 h-20 rounded-full p-[3px]"
              style={{ background: isNeutral ? `linear-gradient(135deg, ${neutralPalette.text}, ${neutralPalette.textMuted})` : `linear-gradient(135deg, ${modeColor}, ${modeColor}88)` }}
            >
              {avatarUrl ? (
                <div className="w-full h-full rounded-full overflow-hidden">
                  <ImageWithFallback src={avatarUrl} alt="Profile" className="w-full h-full object-cover" />
                </div>
              ) : (
                <div
                  className="w-full h-full rounded-full flex items-center justify-center text-2xl"
                  style={{ backgroundColor: p.pageBg, color: p.accent, fontFamily: isNeutral ? "'Archivo Black', sans-serif" : undefined, fontWeight: isNeutral ? 400 : 700 }}
                >
                  {initials}
                </div>
              )}
            </div>
            <input
              ref={avatarInputRef}
              type="file"
              accept="image/jpeg,image/png,image/webp,image/gif"
              className="hidden"
              onChange={handleAvatarUpload}
            />
            <button
              onClick={() => avatarInputRef.current?.click()}
              disabled={avatarUploading}
              className="absolute bottom-0 right-0 w-7 h-7 rounded-full flex items-center justify-center cursor-pointer hover:opacity-80 transition-all"
              style={{ backgroundColor: p.accent, color: isNeutral ? neutralPalette.bg : '#fff', border: `2px solid ${p.pageBg}` }}
              title="Upload profile photo"
            >
              {avatarUploading ? <Loader2 size={11} className="animate-spin" /> : <Camera size={11} />}
            </button>
          </div>
          <div className="flex-1 text-center sm:text-left">
            <h1 style={{ color: p.textPrimary, fontFamily: isNeutral ? "'Archivo Black', sans-serif" : undefined, fontSize: isNeutral ? '1.15rem' : '1.25rem', fontWeight: isNeutral ? 400 : 700, letterSpacing: isNeutral ? '-0.03em' : undefined }}>{user.name}</h1>
            <p className="text-sm" style={{ color: p.textMuted }}>{user.email}</p>
            <div className="flex items-center justify-center sm:justify-start gap-4 mt-3">
              {[
                { icon: Heart, count: savedEventIds.length, label: 'Saved' },
                { icon: FolderOpen, count: collections.length, label: 'Collections' },
                { icon: Sparkles, count: currentMode ? 1 : 0, label: 'Mode active' },
              ].map(stat => (
                <div key={stat.label} className="flex items-center gap-1.5">
                  <stat.icon size={13} style={{ color: p.accent }} />
                  <span className="text-sm font-semibold" style={{ color: p.textPrimary }}>{stat.count}</span>
                  <span className="text-xs" style={{ color: p.textMuted }}>{stat.label}</span>
                </div>
              ))}
            </div>
          </div>
          <button
            onClick={handleSignOut}
            className="flex items-center gap-2 px-4 py-2 text-sm cursor-pointer hover:opacity-80 transition-opacity"
            style={{ backgroundColor: 'rgba(239,68,68,0.08)', color: '#EF4444', borderRadius: rad }}
          >
            <LogOut size={14} /> Sign out
          </button>
        </div>
      </div>

      {/* Tabs + content */}
      <div className="max-w-3xl mx-auto px-4 py-8">
        <div className="flex gap-1 p-1 mb-8 overflow-x-auto" style={{ backgroundColor: p.surfaceBg, borderRadius: isNeutral ? '6px' : '12px' }}>
          {TABS.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className="flex items-center gap-1.5 px-4 py-2 whitespace-nowrap cursor-pointer transition-all flex-1 justify-center"
              style={{
                backgroundColor: activeTab === tab.id ? p.pageBg : 'transparent',
                color: activeTab === tab.id ? p.textPrimary : p.textMuted,
                boxShadow: activeTab === tab.id ? '0 1px 4px rgba(0,0,0,0.08)' : undefined,
                borderRadius: isNeutral ? '4px' : '8px',
                fontSize: isNeutral ? '0.75rem' : '0.875rem',
                fontWeight: activeTab === tab.id ? 600 : 400,
              }}
            >
              <tab.icon size={14} />
              <span className="hidden sm:inline">{tab.label}</span>
            </button>
          ))}
        </div>

        <AnimatePresence mode="wait">
          <motion.div key={activeTab} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.18 }}>

            {/* OVERVIEW */}
            {activeTab === 'overview' && (
              <div className="space-y-6">
                <Sec title="Your Activity" p={p} n={isNeutral}>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    {[
                      { icon: Heart, count: savedEventIds.length, label: 'Saved Events', to: '/saved' },
                      { icon: FolderOpen, count: collections.length, label: 'Collections', to: '/collections' },
                      { icon: Calendar, count: attendedCount, label: 'Attended' },
                    ].map(s => {
                      const card = (
                        <div key={s.label} className="flex flex-col items-center gap-1.5 p-4 text-center transition-all hover:opacity-80" style={{ backgroundColor: p.surfaceBg, border: `1px solid ${p.cardBorder}`, borderRadius: rad }}>
                          <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ backgroundColor: `${p.accent}12` }}>
                            <s.icon size={18} style={{ color: p.accent }} />
                          </div>
                          <span style={{ fontFamily: isNeutral ? "'Archivo Black', sans-serif" : undefined, fontSize: '1.5rem', fontWeight: isNeutral ? 400 : 700, color: p.textPrimary }}>{s.count}</span>
                          <span className="text-xs" style={{ color: p.textMuted }}>{s.label}</span>
                        </div>
                      );
                      return s.to ? <Link key={s.label} to={s.to} style={{ textDecoration: 'none' }}>{card}</Link> : <div key={s.label}>{card}</div>;
                    })}
                  </div>
                </Sec>

                {/* Events Attended */}
                <Sec title="Events Attended" p={p} n={isNeutral}>
                  {attendableEvents.length === 0 ? (
                    <div className="text-center py-8" style={{ backgroundColor: p.surfaceBg, borderRadius: rad, border: `1px solid ${p.cardBorder}` }}>
                      <Calendar size={24} style={{ color: p.textMuted }} className="mx-auto mb-2 opacity-40" />
                      <p className="text-sm" style={{ color: p.textMuted }}>
                        Save events and mark them as attended after they happen.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <p className="text-xs mb-2" style={{ color: p.textMuted }}>
                        Mark past events you've attended. {attendedCount} of {attendableEvents.length} marked.
                      </p>
                      {attendableEvents.slice(0, 8).map(evt => {
                        const isAttended = attendedIds.includes(evt.id);
                        return (
                          <div
                            key={evt.id}
                            className="flex items-center gap-3 px-4 py-3 transition-all"
                            style={{
                              backgroundColor: isAttended ? `${p.accent}08` : p.surfaceBg,
                              borderRadius: rad,
                              border: `1px solid ${isAttended ? `${p.accent}25` : p.cardBorder}`,
                            }}
                          >
                            {evt.image && (
                              <div className="w-10 h-10 flex-shrink-0 overflow-hidden" style={{ borderRadius: isNeutral ? '3px' : '8px' }}>
                                <ImageWithFallback src={evt.image} alt="" className="w-full h-full object-cover" />
                              </div>
                            )}
                            <div className="flex-1 min-w-0">
                              <Link
                                to={`/event/${evt.id}`}
                                className="text-sm font-medium no-underline hover:opacity-70 transition-opacity block truncate"
                                style={{ color: p.textPrimary }}
                              >
                                {evt.title}
                              </Link>
                              <div className="flex items-center gap-2 mt-0.5">
                                {evt.date && (
                                  <span className="text-[11px]" style={{ color: p.textMuted }}>
                                    <Calendar size={9} className="inline mr-1" />{evt.date}
                                  </span>
                                )}
                                {(evt.venueName || (evt as any).venueName_zh) && (
                                  <span className="text-[11px] truncate" style={{ color: p.textMuted }}>
                                    <MapPin size={9} className="inline mr-1" />{evt.venueName}
                                  </span>
                                )}
                              </div>
                            </div>
                            <button
                              onClick={() => toggleAttendance(evt.id)}
                              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium cursor-pointer transition-all hover:opacity-80 flex-shrink-0"
                              style={{
                                backgroundColor: isAttended ? p.accent : 'transparent',
                                color: isAttended ? (isNeutral ? neutralPalette.bg : '#fff') : p.textMuted,
                                border: `1px solid ${isAttended ? p.accent : p.cardBorder}`,
                                borderRadius: isNeutral ? '4px' : '8px',
                              }}
                            >
                              {isAttended ? <Check size={12} /> : <Calendar size={12} />}
                              {isAttended ? 'Attended' : 'Mark'}
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </Sec>

                {/* Recommended For You — powered by attendance data */}
                {recommendedEvents.length > 0 && (
                  <Sec title="Recommended For You" p={p} n={isNeutral}>
                    <p className="text-xs mb-3" style={{ color: p.textMuted }}>
                      Based on events you've attended — similar categories you might enjoy.
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {recommendedEvents.map(evt => (
                        <Link
                          key={evt.id}
                          to={`/event/${evt.id}`}
                          className="flex items-center gap-3 px-3 py-2.5 no-underline transition-all hover:opacity-80"
                          style={{ backgroundColor: p.surfaceBg, borderRadius: rad, border: `1px solid ${p.cardBorder}` }}
                        >
                          {evt.image && (
                            <div className="w-12 h-12 flex-shrink-0 overflow-hidden" style={{ borderRadius: isNeutral ? '3px' : '8px' }}>
                              <ImageWithFallback src={evt.image} alt="" className="w-full h-full object-cover" />
                            </div>
                          )}
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium truncate" style={{ color: p.textPrimary }}>{evt.title}</p>
                            <div className="flex items-center gap-2 mt-0.5">
                              {evt.date && (
                                <span className="text-[10px]" style={{ color: p.textMuted }}>
                                  <Calendar size={8} className="inline mr-0.5" />{evt.date}
                                </span>
                              )}
                              {(() => {
                                const cats = Array.isArray(evt.categories) ? evt.categories : evt.category ? [evt.category] : [];
                                return cats.length > 0 ? (
                                  <span className="text-[10px] px-1.5 py-0.5" style={{ backgroundColor: `${p.accent}10`, color: p.accent, borderRadius: '3px' }}>
                                    {cats[0]}
                                  </span>
                                ) : null;
                              })()}
                            </div>
                          </div>
                          <Sparkles size={12} style={{ color: p.accent, opacity: 0.5, flexShrink: 0 }} />
                        </Link>
                      ))}
                    </div>
                  </Sec>
                )}

                <Sec title="Shortcuts" p={p} n={isNeutral}>
                  {[
                    { icon: Bookmark, label: 'Saved Events', desc: 'Your bookmarked events', to: '/saved', color: '#F59E0B' },
                    { icon: FolderOpen, label: 'Collections', desc: 'Curated event lists', to: '/collections', color: p.accent },
                    { icon: Bell, label: 'Notification Settings', desc: 'Manage alerts', onClick: () => setActiveTab('notifications'), color: '#3B82F6' },
                    { icon: Sliders, label: 'Preferences', desc: 'Interests & discovery', onClick: () => setActiveTab('preferences'), color: '#8B5CF6' },
                  ].map(item => {
                    const inner = (
                      <>
                        <div className="w-9 h-9 flex items-center justify-center" style={{ backgroundColor: `${item.color}15`, borderRadius: rad }}>
                          <item.icon size={16} style={{ color: item.color }} />
                        </div>
                        <div className="flex-1">
                          <p style={{ color: p.textPrimary, fontWeight: 500, fontSize: isNeutral ? '0.8rem' : '0.875rem' }}>{item.label}</p>
                          <p className="text-xs" style={{ color: p.textMuted }}>{item.desc}</p>
                        </div>
                        <ChevronRight size={14} style={{ color: p.textMuted, opacity: 0.5 }} />
                      </>
                    );
                    const s = { backgroundColor: p.surfaceBg, textDecoration: 'none' as const, borderRadius: rad };
                    return item.to
                      ? <Link key={item.label} to={item.to} className="flex items-center gap-3 px-4 py-3 text-sm transition-all hover:opacity-80" style={s}>{inner}</Link>
                      : <button key={item.label} onClick={item.onClick} className="w-full flex items-center gap-3 px-4 py-3 text-sm transition-all hover:opacity-80 text-left cursor-pointer" style={s}>{inner}</button>;
                  })}
                </Sec>

                <Sec title="Profile Info" p={p} n={isNeutral}>
                  <PForm
                    editName={editName}
                    setEditName={setEditName}
                    editEmail={editEmail}
                    currentPassword={currentPassword}
                    setCurrentPassword={setCurrentPassword}
                    newPassword={newPassword}
                    setNewPassword={setNewPassword}
                    showCurrentPw={showCurrentPw}
                    setShowCurrentPw={setShowCurrentPw}
                    showNewPw={showNewPw}
                    setShowNewPw={setShowNewPw}
                    saving={saving}
                    saveSuccess={saveSuccess}
                    saveError={saveError}
                    onSave={handleSaveProfile}
                    p={p}
                    n={isNeutral}
                  />
                </Sec>
              </div>
            )}

            {/* NOTIFICATIONS */}
            {activeTab === 'notifications' && (
              <div className="space-y-6">
                <Sec title="Notification Preferences" p={p} n={isNeutral}>
                  <div className="space-y-1">
                    {[
                      { key: 'upcomingEvents', label: 'Upcoming Events', desc: "Reminders for events you've saved" },
                      { key: 'newEvents', label: 'New Events', desc: 'When new events are added in your interests' },
                      { key: 'savedEventReminders', label: 'Event Reminders', desc: '24h reminder before saved events' },
                      { key: 'collectionUpdates', label: 'Collection Updates', desc: 'When shared collections are updated' },
                      { key: 'emailNotifications', label: 'Email Notifications', desc: 'Receive notifications by email' },
                    ].map(item => (
                      <NToggle key={item.key} label={item.label} desc={item.desc} enabled={(notifSettings as any)[item.key]} onChange={val => updateNotifSettings({ [item.key]: val })} p={p} n={isNeutral} />
                    ))}
                  </div>
                </Sec>
              </div>
            )}

            {/* PRIVACY */}
            {activeTab === 'privacy' && (
              <div className="space-y-6">
                <Sec title="Profile Info" p={p} n={isNeutral}>
                  <PForm
                    editName={editName}
                    setEditName={setEditName}
                    editEmail={editEmail}
                    currentPassword={currentPassword}
                    setCurrentPassword={setCurrentPassword}
                    newPassword={newPassword}
                    setNewPassword={setNewPassword}
                    showCurrentPw={showCurrentPw}
                    setShowCurrentPw={setShowCurrentPw}
                    showNewPw={showNewPw}
                    setShowNewPw={setShowNewPw}
                    saving={saving}
                    saveSuccess={saveSuccess}
                    saveError={saveError}
                    onSave={handleSaveProfile}
                    p={p}
                    n={isNeutral}
                  />
                </Sec>
                <Sec title="Account" p={p} n={isNeutral}>
                  <div className="p-4" style={{ backgroundColor: 'rgba(239,68,68,0.06)', border: '1px solid rgba(239,68,68,0.12)', borderRadius: rad }}>
                    <p className="text-sm font-medium mb-1" style={{ color: '#EF4444' }}>Delete Account</p>
                    <p className="text-xs mb-3" style={{ color: p.textMuted }}>Once you delete your account, there is no going back.</p>
                    <button className="px-4 py-2 text-sm font-medium cursor-pointer hover:opacity-80 transition-opacity" style={{ backgroundColor: '#EF4444', color: '#fff', borderRadius: rad }} onClick={() => alert('Account deletion is not available in this demo.')}>Delete Account</button>
                  </div>
                </Sec>
              </div>
            )}

            {/* PREFERENCES */}
            {activeTab === 'preferences' && (
              <div className="space-y-6">
                <Sec title="Your Interests" p={p} n={isNeutral}>
                  <p className="text-sm mb-4" style={{ color: p.textMuted }}>Select your interests to personalise your discovery feed.</p>
                  <div className="flex flex-wrap gap-2 mb-5">
                    {INTEREST_OPTIONS.map(opt => {
                      const sel = interests.includes(opt.id);
                      return (
                        <button key={opt.id} onClick={() => toggleInterest(opt.id)} className="flex items-center gap-1.5 px-3 py-1.5 text-sm cursor-pointer transition-all hover:scale-105" style={{
                          backgroundColor: sel ? `${p.accent}15` : p.surfaceBg,
                          color: sel ? p.accent : p.textMuted,
                          border: `1.5px solid ${sel ? p.accent + '40' : p.cardBorder}`,
                          fontWeight: sel ? 600 : 400,
                          borderRadius: isNeutral ? '4px' : '9999px',
                        }}>
                          <span>{opt.emoji}</span>{opt.label}
                        </button>
                      );
                    })}
                  </div>
                  <button onClick={handleSaveInterests} disabled={prefSaving} className="flex items-center gap-2 px-5 py-2.5 text-sm font-medium cursor-pointer hover:opacity-80 transition-opacity disabled:opacity-50" style={{ backgroundColor: p.ctaBg, color: p.ctaText, borderRadius: rad }}>
                    {prefSaving ? <Loader2 size={14} className="animate-spin" /> : prefSuccess ? <CheckCircle2 size={14} /> : <Save size={14} />}
                    {prefSuccess ? 'Saved!' : 'Save Preferences'}
                  </button>
                </Sec>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Avatar Crop Modal */}
      {cropFile && (
        <AvatarCropModal
          file={cropFile}
          isOpen={cropModalOpen}
          onClose={() => { setCropModalOpen(false); setCropFile(null); }}
          onCrop={handleCroppedUpload}
          uploading={avatarUploading}
          accentColor={p.accent}
          pageBg={p.pageBg}
          surfaceBg={p.surfaceBg}
          textPrimary={p.textPrimary}
          textMuted={p.textMuted}
          cardBorder={p.cardBorder}
          borderRadius={rad}
        />
      )}
    </div>
  );
}

/* ─── Shared sub-components ─────────────────────────────────────────────── */

function Sec({ title, p, n, children }: { title: string; p: any; n: boolean; children: React.ReactNode }) {
  return (
    <div>
      <h2 style={{ color: p.textMuted, fontSize: n ? '0.55rem' : '0.75rem', fontWeight: 600, letterSpacing: n ? '0.18em' : '0.1em', textTransform: 'uppercase' as const, marginBottom: n ? '1rem' : '0.75rem' }}>{title}</h2>
      <div className="space-y-2">{children}</div>
    </div>
  );
}

function NToggle({ label, desc, enabled, onChange, p, n }: { label: string; desc: string; enabled: boolean; onChange: (v: boolean) => void; p: any; n: boolean }) {
  return (
    <div className="flex items-center justify-between px-4 py-3" style={{ backgroundColor: p.surfaceBg, borderRadius: n ? '4px' : '12px' }}>
      <div className="flex-1 min-w-0 pr-3">
        <p style={{ color: p.textPrimary, fontWeight: 500, fontSize: n ? '0.8rem' : '0.875rem' }}>{label}</p>
        <p className="text-xs" style={{ color: p.textMuted }}>{desc}</p>
      </div>
      <button onClick={() => onChange(!enabled)} className="relative flex-shrink-0 w-11 h-6 rounded-full cursor-pointer transition-colors duration-200" style={{ backgroundColor: enabled ? p.accent : p.cardBorder }} role="switch" aria-checked={enabled}>
        <motion.div animate={{ x: enabled ? 20 : 2 }} transition={{ type: 'spring', stiffness: 500, damping: 35 }} className="absolute top-[3px] w-[18px] h-[18px] bg-white rounded-full shadow-sm" />
      </button>
    </div>
  );
}

function PForm({ editName, setEditName, editEmail, currentPassword, setCurrentPassword, newPassword, setNewPassword, showCurrentPw, setShowCurrentPw, showNewPw, setShowNewPw, saving, saveSuccess, saveError, onSave, p, n }: any) {
  const rad = n ? '4px' : '12px';
  const irad = n ? '4px' : '8px';
  return (
    <div className="p-5 space-y-4" style={{ backgroundColor: p.surfaceBg, border: `1px solid ${p.cardBorder}`, borderRadius: rad }}>
      {saveError && (
        <div className="flex items-center gap-2 px-3 py-2 text-sm" style={{ backgroundColor: 'rgba(239,68,68,0.08)', color: '#EF4444', borderRadius: irad }}>
          <AlertCircle size={14} />{saveError}
        </div>
      )}
      {saveSuccess && (
        <div className="flex items-center gap-2 px-3 py-2 text-sm" style={{ backgroundColor: 'rgba(34,197,94,0.08)', color: '#22C55E', borderRadius: irad }}>
          <CheckCircle2 size={14} />Profile updated successfully
        </div>
      )}
      <FL label="Display Name" p={p} n={n}>
        <input type="text" value={editName} onChange={e => setEditName(e.target.value)} className="w-full px-3 py-2 text-sm outline-none" style={{ backgroundColor: p.pageBg, border: `1px solid ${p.cardBorder}`, color: p.textPrimary, borderRadius: irad }} />
      </FL>
      <FL label="Email" p={p} n={n}>
        <input type="email" value={editEmail} disabled className="w-full px-3 py-2 text-sm outline-none opacity-60 cursor-not-allowed" style={{ backgroundColor: p.pageBg, border: `1px solid ${p.cardBorder}`, color: p.textPrimary, borderRadius: irad }} />
        <p className="text-[10px] mt-1" style={{ color: p.textMuted }}>Email changes require support</p>
      </FL>
      <div style={{ height: 1, backgroundColor: p.cardBorder }} />
      <p className="text-xs font-medium" style={{ color: p.textMuted }}>Change Password (optional)</p>
      <FL label="Current Password" p={p} n={n}>
        <div className="relative">
          <input type={showCurrentPw ? 'text' : 'password'} value={currentPassword} onChange={e => setCurrentPassword(e.target.value)} placeholder="Enter current password" className="w-full px-3 py-2 pr-10 text-sm outline-none" style={{ backgroundColor: p.pageBg, border: `1px solid ${p.cardBorder}`, color: p.textPrimary, borderRadius: irad }} />
          <button type="button" onClick={() => setShowCurrentPw(!showCurrentPw)} className="absolute right-2.5 top-1/2 -translate-y-1/2 cursor-pointer opacity-50 hover:opacity-80" style={{ color: p.textMuted }}>{showCurrentPw ? <EyeOff size={14} /> : <Eye size={14} />}</button>
        </div>
      </FL>
      <FL label="New Password" p={p} n={n}>
        <div className="relative">
          <input type={showNewPw ? 'text' : 'password'} value={newPassword} onChange={e => setNewPassword(e.target.value)} placeholder="Enter new password (min 8 chars)" className="w-full px-3 py-2 pr-10 text-sm outline-none" style={{ backgroundColor: p.pageBg, border: `1px solid ${p.cardBorder}`, color: p.textPrimary, borderRadius: irad }} />
          <button type="button" onClick={() => setShowNewPw(!showNewPw)} className="absolute right-2.5 top-1/2 -translate-y-1/2 cursor-pointer opacity-50 hover:opacity-80" style={{ color: p.textMuted }}>{showNewPw ? <EyeOff size={14} /> : <Eye size={14} />}</button>
        </div>
      </FL>
      <button onClick={onSave} disabled={saving} className="flex items-center gap-2 px-5 py-2.5 text-sm font-medium cursor-pointer hover:opacity-80 transition-opacity disabled:opacity-50" style={{ backgroundColor: p.ctaBg, color: p.ctaText, borderRadius: rad }}>
        {saving ? <Loader2 size={14} className="animate-spin" /> : saveSuccess ? <CheckCircle2 size={14} /> : <Save size={14} />}
        {saving ? 'Saving\u2026' : saveSuccess ? 'Saved!' : 'Save Changes'}
      </button>
    </div>
  );
}

function FL({ label, p, n, children }: { label: string; p: any; n: boolean; children: React.ReactNode }) {
  return (
    <div>
      <label className="block mb-1.5" style={{ color: p.textMuted, fontSize: n ? '0.65rem' : '0.75rem', fontWeight: n ? 600 : 500, letterSpacing: n ? '0.05em' : undefined }}>{label}</label>
      {children}
    </div>
  );
}