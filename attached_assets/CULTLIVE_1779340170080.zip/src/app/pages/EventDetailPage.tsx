import { useState, useEffect, useRef, useCallback } from 'react';
import { useParams, Link } from 'react-router';
import { motion } from 'motion/react';
import {
  ArrowLeft, MapPin, Clock, Calendar, Tag, User, Instagram,
  ExternalLink, Share2, Heart, Loader2, DollarSign, FolderPlus,
  Music, Ticket, Globe, Camera, CheckCircle2, Eye, Users,
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { useMode } from '../context/ModeContext';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';
import { modeConfig, type Mode } from '../data/mock-data';
import { getDesignTokens } from '../data/mode-styles';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import { fetchPublishedEvent } from '../hooks/useAdminApi';
import { AddToCollectionModal } from '../components/AddToCollectionModal';
import { ShareMenu } from '../components/ShareMenu';
import { computeEventStatus } from '../utils/date-helpers';
import { useBilingualFields } from '../utils/bilingual';
import { projectId, publicAnonKey } from '../config/supabase';
import { useEventStats } from '../context/EventStatsContext';

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-d507b98c`;

const CATEGORY_MODE_MAP: Record<string, Mode> = {
  nightlife: 'degen', music: 'degen', art: 'artsy', exhibition: 'artsy',
  workshop: 'artsy', film: 'artsy', theatre: 'artsy', food: 'foodie',
  dining: 'foodie', family: 'family', wellness: 'lifestyle',
  'run-clubs': 'lifestyle', hikes: 'lifestyle', 'coffee-raves': 'lifestyle',
  meetups: 'lifestyle', other: 'lifestyle',
};

function formatEventPrice(price: string | undefined, freeLabel: string): string {
  if (!price) return freeLabel;
  const t = price.trim();
  if (!t || /^free$/i.test(t)) return freeLabel;
  return t;
}

function normaliseEvent(raw: any) {
  const images: string[] = Array.isArray(raw.images) && raw.images.length > 0
    ? raw.images
    : raw.image ? [raw.image] : [];
  const locationLabel = raw.location || raw.venueName || '';
  const sourceUrl = raw.sourceUrl || raw.ticketUrl || '';
  const source = raw.source || (raw.ticketUrl ? 'ticket' : undefined);
  const categories: string[] = Array.isArray(raw.categories) && raw.categories.length > 0
    ? raw.categories
    : raw.category ? [raw.category] : [];
  const modeTags: string[] = Array.isArray(raw.modeTags) && raw.modeTags.length > 0
    ? raw.modeTags
    : Array.isArray(raw.modes) ? raw.modes : [];
  const artists: string[] = Array.isArray(raw.artists) ? raw.artists.filter(Boolean) : [];
  return { ...raw, images, locationLabel, sourceUrl, source, categories, modeTags, artists };
}

function MiniMap({ lat, lng, label, accentColor }: {
  lat: number; lng: number; label: string; accentColor: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!ref.current) return;
    let map: any;
    const init = async () => {
      try {
        const L = (window as any).L;
        if (!L) return;
        map = L.map(ref.current, {
          center: [lat, lng], zoom: 15,
          scrollWheelZoom: false, dragging: false, zoomControl: false,
          attributionControl: false,
        });
        L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png').addTo(map);
        const markerHtml = `<div style="width:28px;height:28px;border-radius:50%;background:${accentColor};border:3px solid white;box-shadow:0 2px 8px rgba(0,0,0,0.3);display:flex;align-items:center;justify-content:center;">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
        </div>`;
        L.marker([lat, lng], {
          icon: L.divIcon({ className: '', html: markerHtml, iconSize: [28, 28], iconAnchor: [14, 14] })
        }).addTo(map).bindPopup(`<span style="font-size:12px;font-weight:600">${label}</span>`);
      } catch (e) {
        console.log('MiniMap init error:', e);
      }
    };
    init();
    return () => { try { map?.remove(); } catch {} };
  }, [lat, lng, accentColor, label]);

  return <div ref={ref} style={{ height: '100%', width: '100%' }} />;
}

export function EventDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { t } = useTranslation();
  const { currentMode, setMode } = useMode();
  const { user, accessToken, isEventSaved, toggleSaveEvent } = useAuth();
  const { recaps } = useData();
  const { trackView, fetchStats, getStats, statsCache, trackSave, trackUnsave } = useEventStats();
  const [event, setEvent] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [activeImage, setActiveImage] = useState(0);
  const [collectionModalOpen, setCollectionModalOpen] = useState(false);

  // Attendance tracking
  const [isAttended, setIsAttended] = useState(false);
  const [attendanceToggling, setAttendanceToggling] = useState(false);

  // Load attendance status
  useEffect(() => {
    if (!user || !id) return;
    fetch(`${API_BASE}/user/attendance`, {
      headers: { 'Authorization': `Bearer ${accessToken || publicAnonKey}`, 'X-User-Id': user.id },
    })
      .then(r => r.json())
      .then(data => {
        if (Array.isArray(data.attendedIds)) {
          setIsAttended(data.attendedIds.includes(id));
        }
      })
      .catch(err => console.log('Error loading attendance:', err));
  }, [user, id, accessToken]);

  const toggleAttendance = useCallback(async () => {
    if (!user || !id) return;
    setAttendanceToggling(true);
    const newState = !isAttended;
    setIsAttended(newState);
    try {
      await fetch(`${API_BASE}/user/attendance`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${accessToken || publicAnonKey}`, 'X-User-Id': user.id },
        body: JSON.stringify({ eventId: id, action: newState ? 'add' : 'remove' }),
      });
    } catch (err) {
      console.log('Error toggling attendance:', err);
      setIsAttended(!newState);
    } finally {
      setAttendanceToggling(false);
    }
  }, [user, id, accessToken, isAttended]);

  // Bilingual field resolution for dynamic event content
  const bi = useBilingualFields(event, ['title', 'description', 'venueName', 'district']);

  useEffect(() => {
    if (!id) return;
    setLoading(true);
    fetchPublishedEvent(id)
      .then(data => {
        if (data?.event) {
          setEvent(normaliseEvent(data.event));
        } else {
          setError('Event data not found');
        }
        setLoading(false);
      })
      .catch(err => {
        console.log('Failed to load event:', err);
        setError(err?.message || 'Event not found');
        setLoading(false);
      });
  }, [id]);

  // Track view + fetch stats when event loads
  useEffect(() => {
    if (!id || !event) return;
    trackView(id);
    fetchStats(id);
  }, [id, event, trackView, fetchStats]);

  const eventStats = id ? getStats(id) : null;

  const eventCategories: string[] = event?.categories || [];
  const eventMode = eventCategories.length > 0 ? (CATEGORY_MODE_MAP[eventCategories[0]] || null) : null;
  const displayMode = currentMode || eventMode;
  const tokens = getDesignTokens(displayMode);
  const accentColor = displayMode && displayMode !== 'lifestyle'
    ? modeConfig[displayMode]?.color || tokens.textAccent
    : displayMode === 'lifestyle' ? '#2D6A4F' : tokens.textAccent;

  // Auto-set mode from event category only on initial mount (not on every
  // currentMode change) so that clicking the logo to reset mode isn't undone.
  const [didAutoSetMode, setDidAutoSetMode] = useState(false);
  useEffect(() => {
    if (!didAutoSetMode && !currentMode && eventMode) {
      setMode(eventMode as any);
      setDidAutoSetMode(true);
    }
  }, [didAutoSetMode, currentMode, eventMode, setMode]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]" style={{ backgroundColor: tokens.pageBg }}>
        <Loader2 size={24} className="animate-spin" style={{ color: tokens.textMuted }} />
      </div>
    );
  }

  if (error || !event) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] px-4" style={{ backgroundColor: tokens.pageBg }}>
        <p className="text-lg font-medium mb-2" style={{ color: tokens.textPrimary }}>{t('common.error')}</p>
        <p className="text-sm mb-6" style={{ color: tokens.textMuted }}>{error || t('common.errorEventDesc')}</p>
        <Link to="/events" className="text-sm font-medium px-4 py-2" style={{ color: accentColor, textDecoration: 'none' }}>
          <ArrowLeft size={14} className="inline mr-1" /> {t('events.browseEvents')}
        </Link>
      </div>
    );
  }

  const { images, locationLabel, sourceUrl, source, categories, modeTags, artists } = event;
  const hasMultipleImages = images.length > 1;
  const publishDate = event.publishedAt
    ? new Date(event.publishedAt).toLocaleDateString('en-HK', { year: 'numeric', month: 'long', day: 'numeric' })
    : null;
  const isImported = id?.startsWith('ra_') || id?.startsWith('lsa_') || id?.startsWith('apify_');
  const eventStatus = computeEventStatus(event.date, event.endDate);
  const isPastEvent = eventStatus === 'past';
  const isOngoing = eventStatus === 'ongoing';

  return (
    <div className="min-h-screen" style={{ backgroundColor: tokens.pageBg }}>
      {/* Back nav */}
      <div className="max-w-4xl mx-auto px-4 pt-6 pb-2">
        <Link to="/events"
          className="inline-flex items-center gap-1.5 text-sm font-medium transition-opacity hover:opacity-70"
          style={{ color: tokens.textMuted, textDecoration: 'none' }}>
          <ArrowLeft size={16} /> {t('nav.events')}
        </Link>
      </div>

      {/* Past / Ongoing event banner */}
      {isPastEvent && (
        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="max-w-4xl mx-auto px-4 mt-2">
          <div className="flex items-center gap-3 px-4 py-3 text-sm"
            style={{ backgroundColor: 'rgba(245,158,11,0.08)', border: '1px solid rgba(245,158,11,0.15)', borderRadius: '12px', color: '#92400E' }}>
            <Clock size={16} style={{ color: '#F59E0B', flexShrink: 0 }} />
            <div>
              <span className="font-semibold">{t('eventDetail.eventEnded')}</span>
              <span className="ml-1 opacity-80">
                {event.date}{event.endDate && event.endDate !== event.date ? ` – ${event.endDate}` : ''}
              </span>
            </div>
          </div>
        </motion.div>
      )}
      {isOngoing && (
        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="max-w-4xl mx-auto px-4 mt-2">
          <div className="flex items-center gap-3 px-4 py-3 text-sm"
            style={{ backgroundColor: 'rgba(22,163,74,0.06)', border: '1px solid rgba(22,163,74,0.12)', borderRadius: '12px', color: '#166534' }}>
            <Calendar size={16} style={{ color: '#16A34A', flexShrink: 0 }} />
            <div>
              <span className="font-semibold">{t('eventDetail.happeningNow')}</span>
              <span className="ml-1 opacity-80">→ {event.endDate || event.date}</span>
            </div>
          </div>
        </motion.div>
      )}

      {/* "You attended this event" badge / Mark as attended */}
      {user && (isPastEvent || isOngoing) && (
        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="max-w-4xl mx-auto px-4 mt-2">
          <div
            className="flex items-center justify-between px-4 py-3 text-sm"
            style={{
              backgroundColor: isAttended ? `${accentColor}08` : tokens.surfaceBg,
              border: `1px solid ${isAttended ? `${accentColor}30` : tokens.cardBorder}`,
              borderRadius: '12px',
            }}
          >
            <div className="flex items-center gap-3">
              <CheckCircle2
                size={18}
                fill={isAttended ? accentColor : 'none'}
                style={{ color: isAttended ? accentColor : tokens.textMuted, flexShrink: 0 }}
              />
              <div>
                <span className="font-semibold" style={{ color: isAttended ? accentColor : tokens.textPrimary }}>
                  {isAttended ? 'You attended this event' : 'Were you there?'}
                </span>
                <p className="text-[11px] mt-0.5" style={{ color: tokens.textMuted }}>
                  {isAttended ? 'This event is part of your attendance history' : 'Mark this event to track your cultural experiences'}
                </p>
              </div>
            </div>
            <button
              onClick={toggleAttendance}
              disabled={attendanceToggling}
              className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold cursor-pointer transition-all hover:opacity-80 flex-shrink-0 disabled:opacity-50"
              style={{
                backgroundColor: isAttended ? 'transparent' : accentColor,
                color: isAttended ? tokens.textMuted : '#fff',
                border: `1px solid ${isAttended ? tokens.cardBorder : accentColor}`,
                borderRadius: '8px',
              }}
            >
              {attendanceToggling ? (
                <Loader2 size={12} className="animate-spin" />
              ) : isAttended ? (
                <><CheckCircle2 size={12} /> Attended</>
              ) : (
                <><CheckCircle2 size={12} /> Mark Attended</>
              )}
            </button>
          </div>
        </motion.div>
      )}

      <div className="max-w-4xl mx-auto px-4 pb-16">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8 mt-4">

          {/* Left: Images */}
          <div className="lg:col-span-3">
            {images.length > 0 ? (
              <div>
                <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
                  className="overflow-hidden relative flex items-center justify-center"
                  style={{ borderRadius: tokens.imageRadius, backgroundColor: tokens.cardBg, maxHeight: '75vh' }}>
                  <ImageWithFallback src={images[activeImage] || images[0]} alt={event.title} className="w-full h-auto max-h-[75vh] object-contain" />
                  <div className="absolute bottom-0 left-0 right-0 h-16 pointer-events-none"
                    style={{ background: `linear-gradient(to bottom, transparent 0%, ${tokens.pageBg}88 100%)` }} />
                  {hasMultipleImages && (
                    <div className="absolute top-3 right-3 px-2.5 py-1 text-xs font-medium"
                      style={{ backgroundColor: 'rgba(0,0,0,0.55)', color: '#fff', borderRadius: '6px', backdropFilter: 'blur(6px)' }}>
                      {activeImage + 1} / {images.length}
                    </div>
                  )}
                  <button onClick={() => {
                      if (id) {
                        if (isEventSaved(id)) { trackUnsave(id); } else { trackSave(id); }
                        toggleSaveEvent(id);
                      }
                    }}
                    className="absolute top-3 left-3 p-2 cursor-pointer transition-all hover:scale-110"
                    style={{ backgroundColor: 'rgba(0,0,0,0.4)', borderRadius: '8px', backdropFilter: 'blur(6px)' }}>
                    <Heart size={18} fill={id && isEventSaved(id) ? '#EF4444' : 'none'} color={id && isEventSaved(id) ? '#EF4444' : '#fff'} />
                  </button>
                </motion.div>
                {hasMultipleImages && (
                  <div className="flex gap-2 mt-3">
                    {images.map((img: string, i: number) => (
                      <button key={i} onClick={() => setActiveImage(i)}
                        className="w-16 h-16 overflow-hidden flex-shrink-0 cursor-pointer transition-all"
                        style={{ borderRadius: tokens.imageRadius === '0px' ? '0px' : '8px',
                          border: i === activeImage ? `2px solid ${accentColor}` : `2px solid transparent`,
                          opacity: i === activeImage ? 1 : 0.6 }}>
                        <ImageWithFallback src={img} alt="" className="w-full h-full object-cover" />
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center justify-center"
                style={{ aspectRatio: '4/3', backgroundColor: tokens.surfaceBg, borderRadius: tokens.imageRadius }}>
                <p className="text-sm" style={{ color: tokens.textMuted }}>No image available</p>
              </div>
            )}

            {artists.length > 0 && (
              <div className="mt-6 p-4 rounded-2xl" style={{ backgroundColor: tokens.surfaceBg, border: `1px solid ${tokens.cardBorder}` }}>
                <div className="flex items-center gap-2 mb-3">
                  <Music size={14} style={{ color: accentColor }} />
                  <p className="text-xs font-semibold uppercase tracking-wider" style={{ color: tokens.textMuted }}>{t('eventDetail.artists')}</p>
                </div>
                <div className="flex flex-wrap gap-2">
                  {artists.map((a: string) => (
                    <span key={a} className="px-3 py-1.5 rounded-full text-sm font-medium"
                      style={{ backgroundColor: `${accentColor}12`, color: accentColor }}>{a}</span>
                  ))}
                </div>
              </div>
            )}

            {modeTags.length > 0 && (
              <div className="mt-4 flex flex-wrap gap-1.5">
                {modeTags.map((m: string) => {
                  const mc = modeConfig[m as Mode];
                  if (!mc) return null;
                  return (
                    <span key={m} className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold rounded-full"
                      style={{ backgroundColor: `${mc.color}15`, color: mc.color }}>{mc.label}</span>
                  );
                })}
              </div>
            )}
          </div>

          {/* Right: Details */}
          <div className="lg:col-span-2">
            <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>

              {categories.length > 0 && (
                <div className="flex flex-wrap gap-1.5 mb-3">
                  {categories.map((cat: string) => {
                    const catMode = CATEGORY_MODE_MAP[cat];
                    const catColor = catMode && catMode !== 'lifestyle'
                      ? modeConfig[catMode]?.color || accentColor
                      : catMode === 'lifestyle' ? '#2D6A4F' : accentColor;
                    return (
                      <span key={cat} className="inline-flex items-center gap-1.5 px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wider"
                        style={{ backgroundColor: `${catColor}15`, color: catColor, borderRadius: '6px' }}>
                        <Tag size={10} />
                        {t(`categories.${cat}`, cat)}
                      </span>
                    );
                  })}
                </div>
              )}

              <h1 className="text-2xl sm:text-3xl font-bold leading-tight mb-4"
                style={{ color: tokens.textPrimary, fontFamily: tokens.headingFont, letterSpacing: '-0.02em' }}>
                {bi.title}
              </h1>

              {/* Social proof bar — views & going */}
              {eventStats && (eventStats.views > 0 || eventStats.saves > 0) && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex items-center gap-4 mb-4 px-3.5 py-2.5"
                  style={{ backgroundColor: tokens.surfaceBg, borderRadius: '10px', border: `1px solid ${tokens.cardBorder}` }}
                >
                  {eventStats.views > 0 && (
                    <div className="flex items-center gap-1.5">
                      <Eye size={13} style={{ color: tokens.textMuted }} />
                      <span className="text-xs font-semibold" style={{ color: tokens.textPrimary }}>
                        {eventStats.views.toLocaleString()}
                      </span>
                      <span className="text-[11px]" style={{ color: tokens.textMuted }}>
                        {eventStats.views === 1 ? 'view' : 'views'}
                      </span>
                    </div>
                  )}
                  {eventStats.saves > 0 && (
                    <div className="flex items-center gap-1.5">
                      <Users size={13} style={{ color: accentColor }} />
                      <span className="text-xs font-semibold" style={{ color: tokens.textPrimary }}>
                        {eventStats.saves.toLocaleString()}
                      </span>
                      <span className="text-[11px]" style={{ color: tokens.textMuted }}>
                        {isPastEvent ? (eventStats.saves === 1 ? 'person went' : 'people went') : (eventStats.saves === 1 ? 'person going' : 'people going')}
                      </span>
                    </div>
                  )}
                </motion.div>
              )}

              <div className="space-y-2.5 mb-6">
                {event.date && <MetaRow icon={Calendar} label={t('eventDetail.when')} value={formatDate(event.date)} tokens={tokens} accent={accentColor} />}
                {event.time && <MetaRow icon={Clock} label={t('eventDetail.when')} value={formatTime(event.time)} tokens={tokens} accent={accentColor} />}
                {(locationLabel || event.district) && (
                  <MetaRow icon={MapPin} label={t('eventDetail.where')}
                    value={[locationLabel, event.district].filter(Boolean).join(', ')}
                    tokens={tokens} accent={accentColor} />
                )}
                {event.address && !locationLabel && (
                  <MetaRow icon={MapPin} label={t('eventDetail.where')} value={event.address} tokens={tokens} accent={accentColor} />
                )}
                {event.price && (
                  <MetaRow icon={DollarSign} label={t('eventDetail.price')} value={formatEventPrice(event.price, t('common.free'))} tokens={tokens} accent={accentColor} />
                )}
              </div>

              {event.description && (
                <div className="mb-6">
                  <p className="text-sm leading-relaxed whitespace-pre-line"
                    style={{ color: tokens.textSecondary, fontFamily: tokens.bodyFont }}>
                    {bi.description}
                  </p>
                </div>
              )}

              {event.tags?.length > 0 && (
                <div className="flex flex-wrap gap-1.5 mb-6">
                  {event.tags.map((tag: string, i: number) => (
                    <span key={i} className="px-2 py-1 text-[11px] font-medium"
                      style={{ backgroundColor: tokens.surfaceBg, color: tokens.textMuted,
                        borderRadius: '4px', border: `1px solid ${tokens.cardBorder}` }}>
                      #{tag}
                    </span>
                  ))}
                </div>
              )}

              {event.vibes?.length > 0 && (
                <div className="flex flex-wrap gap-1.5 mb-6">
                  {event.vibes.map((v: string) => (
                    <span key={v} className="px-2 py-1 text-[11px] font-medium"
                      style={{ backgroundColor: tokens.surfaceBg, color: tokens.textMuted,
                        borderRadius: '4px', border: `1px solid ${tokens.cardBorder}` }}>
                      {v}
                    </span>
                  ))}
                </div>
              )}

              {/* CTA buttons */}
              <div className="flex flex-col gap-2 mb-6">
                {sourceUrl && (
                  <a href={sourceUrl} target="_blank" rel="noopener noreferrer"
                    className="inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-semibold transition-all hover:opacity-80"
                    style={{
                      background: source === 'instagram'
                        ? 'linear-gradient(135deg, #833AB4, #C13584, #E1306C, #F77737)'
                        : accentColor,
                      color: '#fff', borderRadius: '10px', textDecoration: 'none',
                    }}>
                    {source === 'instagram' ? <Instagram size={15} /> : source === 'ticket' ? <Ticket size={15} /> : <ExternalLink size={15} />}
                    {source === 'instagram' ? 'View on Instagram' : source === 'ticket' ? t('eventDetail.getTickets') : t('eventDetail.visitWebsite')}
                  </a>
                )}
                <div className="flex gap-2">
                  <button onClick={() => {
                      if (id) {
                        if (isEventSaved(id)) { trackUnsave(id); } else { trackSave(id); }
                        toggleSaveEvent(id);
                      }
                    }}
                    className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2 text-sm font-medium cursor-pointer transition-all hover:opacity-80"
                    style={{ backgroundColor: tokens.surfaceBg, border: `1px solid ${tokens.cardBorder}`, borderRadius: '8px', color: tokens.textSecondary }}>
                    <Heart size={14} fill={id && isEventSaved(id) ? '#EF4444' : 'none'} color={id && isEventSaved(id) ? '#EF4444' : undefined} />
                    {id && isEventSaved(id) ? t('eventDetail.saved') : t('eventDetail.save')}
                  </button>
                  <button onClick={() => setCollectionModalOpen(true)}
                    className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2 text-sm font-medium cursor-pointer transition-all hover:opacity-80"
                    style={{ backgroundColor: `${accentColor}10`, border: `1px solid ${accentColor}25`, borderRadius: '8px', color: accentColor }}>
                    <FolderPlus size={14} /> {t('eventDetail.addToCollection')}
                  </button>
                  <ShareMenu
                    title={event.title}
                    url={window.location.href}
                    eventId={id}
                  >
                    {({ onClick, ref }) => (
                      <button ref={ref} onClick={onClick}
                        className="flex items-center justify-center gap-2 px-3 py-2 text-sm font-medium cursor-pointer transition-all hover:opacity-80"
                        style={{ backgroundColor: tokens.surfaceBg, border: `1px solid ${tokens.cardBorder}`, borderRadius: '8px', color: tokens.textSecondary }}>
                        <Share2 size={14} />
                      </button>
                    )}
                  </ShareMenu>
                </div>
              </div>

              {/* Mini map */}
              {event.lat && event.lng && (
                <div className="mb-5 overflow-hidden" style={{ borderRadius: '12px', border: `1px solid ${tokens.cardBorder}` }}>
                  <div style={{ height: '180px' }}>
                    <MiniMap lat={event.lat} lng={event.lng}
                      label={locationLabel || event.district || event.title}
                      accentColor={accentColor} />
                  </div>
                  <div className="flex items-center justify-between px-3 py-2" style={{ backgroundColor: tokens.surfaceBg }}>
                    <div className="flex items-center gap-1.5">
                      <MapPin size={12} style={{ color: accentColor }} />
                      <span className="text-xs font-medium" style={{ color: tokens.textPrimary }}>
                        {[locationLabel, event.district].filter(Boolean).join(', ')}
                      </span>
                    </div>
                    <Link to="/map" className="text-[10px] font-medium px-2 py-1 transition-opacity hover:opacity-70"
                      style={{ color: accentColor, textDecoration: 'none', backgroundColor: `${accentColor}10`, borderRadius: '4px' }}>
                      {t('modeHome.viewOnMap')}
                    </Link>
                  </div>
                </div>
              )}

              <div className="h-px my-5" style={{ backgroundColor: tokens.cardBorder }} />

              {/* Credit section */}
              {isImported ? (
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 flex items-center justify-center rounded-full" style={{ backgroundColor: tokens.surfaceBg }}>
                    <Globe size={16} style={{ color: tokens.textMuted }} />
                  </div>
                  <div>
                    <p className="text-xs" style={{ color: tokens.textMuted }}>Source</p>
                    <p className="text-sm font-medium" style={{ color: tokens.textPrimary }}>
                      {id?.startsWith('ra_') ? 'Resident Advisor' : id?.startsWith('lsa_') ? 'Lifestyle Asia' : id?.startsWith('apify_') ? 'Admin' : 'External Source'}
                    </p>
                  </div>
                </div>
              ) : (
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 flex items-center justify-center rounded-full" style={{ backgroundColor: tokens.surfaceBg }}>
                    <User size={16} style={{ color: tokens.textMuted }} />
                  </div>
                  <div>
                    <p className="text-xs" style={{ color: tokens.textMuted }}>Submitted by</p>
                    <p className="text-sm font-medium" style={{ color: tokens.textPrimary }}>
                      {event.contributorName || 'Community member'}
                      {event.contributorInstagram && (
                        <span className="ml-1.5 font-normal" style={{ color: tokens.textMuted }}>
                          @{event.contributorInstagram}
                        </span>
                      )}
                    </p>
                  </div>
                </div>
              )}
              {publishDate && (
                <p className="text-[11px] mt-3" style={{ color: tokens.textMuted }}>Published {publishDate}</p>
              )}

              {/* Recap section: count badge + inline thumbnails */}
              {(() => {
                const eventRecaps = recaps.filter(r => r.eventId === id);
                if (eventRecaps.length === 0) return null;
                const previewRecaps = eventRecaps.slice(0, 4);
                const previewMedia = previewRecaps
                  .flatMap(r => [r.thumbnail, ...(r.media || [])].filter(Boolean))
                  .filter((v, i, a) => a.indexOf(v) === i)
                  .slice(0, 4);
                return (
                  <div className="mt-5">
                    <Link to={`/recaps?event=${encodeURIComponent(id || '')}`} className="flex items-center gap-3 p-3 no-underline transition-all hover:opacity-80"
                      style={{ backgroundColor: tokens.surfaceBg, borderRadius: '10px', border: `1px solid ${tokens.cardBorder}` }}>
                      <div className="w-8 h-8 flex items-center justify-center flex-shrink-0"
                        style={{ backgroundColor: `${accentColor}12`, borderRadius: '8px' }}>
                        <Camera size={14} style={{ color: accentColor }} />
                      </div>
                      <div className="flex-1">
                        <p className="text-[10px] font-medium uppercase tracking-wider" style={{ color: tokens.textMuted }}>
                          {t('eventDetail.communityRecaps')}
                        </p>
                        <p className="text-sm font-medium" style={{ color: tokens.textPrimary }}>
                          {eventRecaps.length} {eventRecaps.length === 1 ? t('eventDetail.recap') : t('eventDetail.recaps')}
                        </p>
                      </div>
                      <ArrowLeft size={14} className="rotate-180" style={{ color: tokens.textMuted }} />
                    </Link>
                    {/* Inline thumbnail previews */}
                    {previewMedia.length > 0 && (
                      <div className="flex gap-2 mt-2">
                        {previewMedia.map((url, i) => (
                          <Link key={i} to={`/recaps/${eventRecaps[Math.min(i, eventRecaps.length - 1)]?.id}`}
                            className="flex-1 overflow-hidden transition-opacity hover:opacity-80"
                            style={{ borderRadius: '8px', aspectRatio: '1', maxWidth: '80px' }}>
                            <ImageWithFallback src={url} alt="" className="w-full h-full object-cover" />
                          </Link>
                        ))}
                        {eventRecaps.length > 4 && (
                          <Link to={`/recaps?event=${encodeURIComponent(id || '')}`}
                            className="flex-1 flex items-center justify-center no-underline transition-opacity hover:opacity-80"
                            style={{ borderRadius: '8px', aspectRatio: '1', maxWidth: '80px', backgroundColor: tokens.surfaceBg, border: `1px solid ${tokens.cardBorder}` }}>
                            <span className="text-[12px] font-medium" style={{ color: tokens.textMuted }}>+{eventRecaps.length - 4}</span>
                          </Link>
                        )}
                      </div>
                    )}
                  </div>
                );
              })()}

              {/* Submit a Recap CTA for past events */}
              {isPastEvent && (
                <Link to={`/contribute/recap?event=${encodeURIComponent(id || '')}`} className="flex items-center gap-3 mt-3 p-3 no-underline transition-all hover:opacity-80"
                  style={{ backgroundColor: `${accentColor}06`, borderRadius: '10px', border: `1px solid ${accentColor}15` }}>
                  <div className="w-8 h-8 flex items-center justify-center flex-shrink-0"
                    style={{ backgroundColor: `${accentColor}12`, borderRadius: '8px' }}>
                    <Camera size={14} style={{ color: accentColor }} />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium" style={{ color: tokens.textPrimary }}>
                      {t('eventDetail.submitRecap')}
                    </p>
                    <p className="text-[11px]" style={{ color: tokens.textMuted }}>
                      {t('eventDetail.submitRecapDesc')}
                    </p>
                  </div>
                  <ArrowLeft size={14} className="rotate-180" style={{ color: tokens.textMuted }} />
                </Link>
              )}
            </motion.div>
          </div>
        </div>
      </div>

      <AddToCollectionModal
        isOpen={collectionModalOpen}
        onClose={() => setCollectionModalOpen(false)}
        itemId={id || ''}
        itemType="event"
        itemName={event.title}
      />
    </div>
  );
}

function MetaRow({ icon: Icon, label, value, tokens, accent }: {
  icon: typeof Calendar; label: string; value: string;
  tokens: ReturnType<typeof getDesignTokens>; accent: string;
}) {
  return (
    <div className="flex items-center gap-3 px-3.5 py-2.5"
      style={{ backgroundColor: tokens.surfaceBg, borderRadius: '10px', border: `1px solid ${tokens.cardBorder}` }}>
      <div className="w-8 h-8 flex items-center justify-center flex-shrink-0"
        style={{ backgroundColor: `${accent}12`, borderRadius: '8px' }}>
        <Icon size={15} style={{ color: accent }} />
      </div>
      <div className="min-w-0">
        <p className="text-[10px] font-medium uppercase tracking-wider" style={{ color: tokens.textMuted }}>{label}</p>
        <p className="text-sm font-medium truncate" style={{ color: tokens.textPrimary }}>{value}</p>
      </div>
    </div>
  );
}

function formatTime(timeStr: string): string {
  const fmt = (t: string) => {
    const match = t.trim().match(/^(\d{1,2}):(\d{2})$/);
    if (!match) return t;
    const h = parseInt(match[1]);
    const m = match[2];
    const ampm = h >= 12 ? 'PM' : 'AM';
    const h12 = h === 0 ? 12 : h > 12 ? h - 12 : h;
    return `${h12}:${m} ${ampm}`;
  };
  if (timeStr.includes('\u2013') || timeStr.includes('-')) {
    const parts = timeStr.split(/\s*[\u2013-]\s*/);
    if (parts.length === 2) return `${fmt(parts[0])} \u2013 ${fmt(parts[1])}`;
  }
  return fmt(timeStr);
}

function formatDate(dateStr: string): string {
  try {
    const d = new Date(dateStr + 'T00:00:00');
    if (isNaN(d.getTime())) return dateStr;
    return d.toLocaleDateString('en-HK', { weekday: 'short', year: 'numeric', month: 'long', day: 'numeric' });
  } catch {
    return dateStr;
  }
}