import { useState } from 'react';
import { Link, useNavigate } from 'react-router';
import { motion } from 'motion/react';
import { Eye, EyeOff, Loader2, AlertCircle, ArrowLeft, CheckCircle2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export function SignupPage() {
  const { signUp } = useAuth();
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const passwordChecks = [
    { label: 'At least 6 characters', valid: password.length >= 6 },
    { label: 'Contains a number', valid: /\d/.test(password) },
  ];

  const allValid = passwordChecks.every((c) => c.valid);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setError('Please fill in all required fields.');
      return;
    }
    if (!allValid) {
      setError('Please meet all password requirements.');
      return;
    }
    setError('');
    setLoading(true);
    try {
      await signUp(email, password, name || email.split('@')[0]);
      navigate('/');
    } catch (err: any) {
      console.log('Signup error:', err);
      setError(err.message || 'Failed to create account.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="min-h-screen flex items-center justify-center px-4 py-12"
      data-nav-theme="dark"
      style={{
        background: 'linear-gradient(135deg, #FAFAF8 0%, #F0EDE8 50%, #E8E4DD 100%)',
        fontFamily: "'Inter', 'Noto Sans HK', system-ui, sans-serif",
      }}
    >
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="w-full max-w-[400px]"
      >
        {/* Back link */}
        <Link
          to="/"
          className="inline-flex items-center gap-1.5 text-sm mb-8 transition-opacity hover:opacity-70"
          style={{ color: '#5A5A5A', textDecoration: 'none' }}
        >
          <ArrowLeft size={16} />
          Back to CULTIVE
        </Link>

        {/* Card */}
        <div
          className="p-8 sm:p-10"
          style={{
            backgroundColor: '#FFFFFF',
            borderRadius: '20px',
            border: '1px solid rgba(0,0,0,0.06)',
            boxShadow: '0 8px 40px rgba(0,0,0,0.06), 0 2px 8px rgba(0,0,0,0.03)',
          }}
        >
          {/* Header */}
          <div className="mb-8 text-center">
            <div className="mb-4">
              <span
                style={{
                  fontFamily: "'Archivo Black', sans-serif",
                  fontSize: '1.3rem',
                  color: '#1A1A1A',
                  letterSpacing: '-0.03em',
                }}
              >
                CULTIVE
              </span>
              <span
                className="ml-2"
                style={{
                  fontFamily: "'Noto Sans HK', sans-serif",
                  fontSize: '0.65rem',
                  color: '#9A9A9A',
                  letterSpacing: '0.1em',
                }}
              >
                文化活
              </span>
            </div>
            <h2 className="text-xl font-semibold" style={{ color: '#1A1A1A' }}>
              Create your account
            </h2>
            <p className="mt-1 text-sm" style={{ color: '#9A9A9A' }}>
              Join the community and save events you love
            </p>
          </div>

          {/* Error */}
          {error && (
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-center gap-2 p-3 mb-6 rounded-xl text-sm"
              style={{
                backgroundColor: 'rgba(220,38,38,0.06)',
                color: '#DC2626',
                border: '1px solid rgba(220,38,38,0.1)',
              }}
            >
              <AlertCircle size={16} />
              <span>{error}</span>
            </motion.div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Name */}
            <div>
              <label className="block text-xs font-medium mb-1.5" style={{ color: '#5A5A5A' }}>
                Name <span style={{ color: '#9A9A9A', fontWeight: 400 }}>(optional)</span>
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Your name"
                className="w-full px-4 py-3 text-sm outline-none transition-all"
                style={{
                  backgroundColor: '#F5F5F3',
                  borderRadius: '12px',
                  border: '1px solid transparent',
                  color: '#1A1A1A',
                }}
                onFocus={(e) => {
                  e.target.style.borderColor = 'rgba(0,0,0,0.15)';
                  e.target.style.backgroundColor = '#FFFFFF';
                }}
                onBlur={(e) => {
                  e.target.style.borderColor = 'transparent';
                  e.target.style.backgroundColor = '#F5F5F3';
                }}
              />
            </div>

            {/* Email */}
            <div>
              <label className="block text-xs font-medium mb-1.5" style={{ color: '#5A5A5A' }}>
                Email
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full px-4 py-3 text-sm outline-none transition-all"
                style={{
                  backgroundColor: '#F5F5F3',
                  borderRadius: '12px',
                  border: '1px solid transparent',
                  color: '#1A1A1A',
                }}
                onFocus={(e) => {
                  e.target.style.borderColor = 'rgba(0,0,0,0.15)';
                  e.target.style.backgroundColor = '#FFFFFF';
                }}
                onBlur={(e) => {
                  e.target.style.borderColor = 'transparent';
                  e.target.style.backgroundColor = '#F5F5F3';
                }}
              />
            </div>

            {/* Password */}
            <div>
              <label className="block text-xs font-medium mb-1.5" style={{ color: '#5A5A5A' }}>
                Password
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Create a password"
                  className="w-full px-4 py-3 pr-11 text-sm outline-none transition-all"
                  style={{
                    backgroundColor: '#F5F5F3',
                    borderRadius: '12px',
                    border: '1px solid transparent',
                    color: '#1A1A1A',
                  }}
                  onFocus={(e) => {
                    e.target.style.borderColor = 'rgba(0,0,0,0.15)';
                    e.target.style.backgroundColor = '#FFFFFF';
                  }}
                  onBlur={(e) => {
                    e.target.style.borderColor = 'transparent';
                    e.target.style.backgroundColor = '#F5F5F3';
                  }}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 p-1 cursor-pointer"
                  style={{ color: '#9A9A9A' }}
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>

              {/* Password strength */}
              {password.length > 0 && (
                <div className="mt-2 space-y-1">
                  {passwordChecks.map((check) => (
                    <div key={check.label} className="flex items-center gap-1.5">
                      <CheckCircle2
                        size={12}
                        style={{ color: check.valid ? '#22C55E' : '#D1D5DB' }}
                      />
                      <span
                        className="text-[11px]"
                        style={{ color: check.valid ? '#22C55E' : '#9A9A9A' }}
                      >
                        {check.label}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Submit */}
            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 py-3.5 text-sm font-semibold transition-all cursor-pointer"
              style={{
                backgroundColor: '#8338EC',
                color: '#FFFFFF',
                borderRadius: '12px',
                opacity: loading ? 0.7 : 1,
              }}
            >
              {loading ? (
                <>
                  <Loader2 size={16} className="animate-spin" />
                  Creating account...
                </>
              ) : (
                'Create account'
              )}
            </button>
          </form>

          {/* Footer */}
          <div className="mt-6 text-center">
            <p className="text-sm" style={{ color: '#9A9A9A' }}>
              Already have an account?{' '}
              <Link
                to="/login"
                className="font-medium transition-opacity hover:opacity-70"
                style={{ color: '#8338EC', textDecoration: 'none' }}
              >
                Sign in
              </Link>
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}