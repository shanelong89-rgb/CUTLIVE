/**
 * CollectionsPage — /collections — lists all user collections
 */
import { useState } from 'react';
import { Link, useNavigate } from 'react-router';
import { motion, AnimatePresence } from 'motion/react';
import {
  FolderOpen, Plus, Lock, Globe, Trash2, Edit3, X, Loader2,
  CheckCircle2, ChevronRight, AlertCircle, Bookmark,
} from 'lucide-react';
import { useCollections } from '../context/CollectionsContext';
import { useAuth } from '../context/AuthContext';
import { useMode } from '../context/ModeContext';
import { getDesignTokens } from '../data/mode-styles';
import { modeConfig } from '../data/mock-data';
import { useTranslation } from 'react-i18next';

export function CollectionsPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { currentMode } = useMode();
  const { collections, loading, createCollection, deleteCollection, updateCollection } = useCollections();
  const { t } = useTranslation();

  const tokens = getDesignTokens(currentMode);
  const modeColor = currentMode && currentMode !== 'lifestyle'
    ? modeConfig[currentMode].color
    : currentMode === 'lifestyle' ? '#2D6A4F' : '#8338EC';

  // Create modal state
  const [showCreate, setShowCreate] = useState(false);
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newPublic, setNewPublic] = useState(false);
  const [creating, setCreating] = useState(false);
  const [createError, setCreateError] = useState('');

  // Delete state
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  // Edit state
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [editDesc, setEditDesc] = useState('');
  const [editPublic, setEditPublic] = useState(false);
  const [saving, setSaving] = useState(false);

  if (!user) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center px-4" data-nav-theme="dark">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center max-w-sm"
        >
          <div
            className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4"
            style={{ backgroundColor: `${modeColor}15` }}
          >
            <FolderOpen size={28} style={{ color: modeColor }} />
          </div>
          <h2 className="text-xl font-semibold mb-2" style={{ color: tokens.textPrimary }}>
            {t('collections.signInToUse')}
          </h2>
          <p className="text-sm mb-6" style={{ color: tokens.textMuted }}>
            {t('collections.signInDesc')}
          </p>
          <div className="flex items-center justify-center gap-3">
            <Link to="/login" className="px-5 py-2.5 text-sm font-medium rounded-xl hover:opacity-80 transition-opacity"
              style={{ backgroundColor: modeColor, color: '#fff', textDecoration: 'none' }}>
              {t('collections.signIn')}
            </Link>
            <Link to="/signup" className="px-5 py-2.5 text-sm font-medium rounded-xl hover:opacity-80 transition-opacity"
              style={{ backgroundColor: tokens.surfaceBg, color: tokens.textPrimary, border: `1px solid ${tokens.cardBorder}`, textDecoration: 'none' }}>
              {t('collections.createAccount')}
            </Link>
          </div>
        </motion.div>
      </div>
    );
  }

  const handleCreate = async () => {
    if (!newName.trim()) return;
    setCreating(true);
    setCreateError('');
    try {
      const col = await createCollection(newName.trim(), newDesc.trim(), newPublic);
      setShowCreate(false);
      setNewName('');
      setNewDesc('');
      setNewPublic(false);
      navigate(`/collections/${col.id}`);
    } catch (err: any) {
      setCreateError(err.message || 'Failed to create collection');
    } finally {
      setCreating(false);
    }
  };

  const handleDelete = async (id: string) => {
    setDeletingId(id);
    try {
      await deleteCollection(id);
    } catch {}
    setDeletingId(null);
    setConfirmDeleteId(null);
  };

  const startEdit = (col: any) => {
    setEditingId(col.id);
    setEditName(col.name);
    setEditDesc(col.description);
    setEditPublic(col.isPublic);
  };

  const handleSaveEdit = async () => {
    if (!editingId) return;
    setSaving(true);
    try {
      await updateCollection(editingId, { name: editName, description: editDesc, isPublic: editPublic });
      setEditingId(null);
    } catch {}
    setSaving(false);
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: tokens.pageBg }} data-nav-theme="dark">
      <div className="max-w-3xl mx-auto px-4 py-20">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold" style={{ color: tokens.textPrimary }}>{t('collections.title')}</h1>
            <p className="text-sm mt-1" style={{ color: tokens.textMuted }}>
              {collections.length === 1 ? t('collections.collectionCount', { count: 1 }) : t('collections.collectionCountPlural', { count: collections.length })}
            </p>
          </div>
          <button
            onClick={() => setShowCreate(true)}
            className="flex items-center gap-2 px-4 py-2.5 text-sm font-medium rounded-xl cursor-pointer hover:opacity-80 transition-opacity"
            style={{ backgroundColor: modeColor, color: '#fff' }}
          >
            <Plus size={15} />
            {t('collections.newCollection')}
          </button>
        </div>

        {/* Loading */}
        {loading && (
          <div className="flex items-center justify-center py-20">
            <Loader2 size={24} className="animate-spin" style={{ color: modeColor }} />
          </div>
        )}

        {/* Empty state */}
        {!loading && collections.length === 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-20"
          >
            <div
              className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4"
              style={{ backgroundColor: `${modeColor}10` }}
            >
              <FolderOpen size={32} style={{ color: modeColor, opacity: 0.5 }} />
            </div>
            <h3 className="text-lg font-semibold mb-2" style={{ color: tokens.textPrimary }}>
              {t('collections.noCollectionsYet')}
            </h3>
            <p className="text-sm mb-6" style={{ color: tokens.textMuted }}>
              {t('collections.noCollectionsDesc')}
            </p>
            <button
              onClick={() => setShowCreate(true)}
              className="px-5 py-2.5 text-sm font-medium rounded-xl cursor-pointer hover:opacity-80 transition-opacity"
              style={{ backgroundColor: modeColor, color: '#fff' }}
            >
              {t('collections.createCollection')}
            </button>
          </motion.div>
        )}

        {/* Collections grid */}
        {!loading && collections.length > 0 && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {collections.map((col, i) => (
              <motion.div
                key={col.id}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.06 }}
              >
                {editingId === col.id ? (
                  /* Inline edit form */
                  <div
                    className="p-4 rounded-2xl space-y-3"
                    style={{ backgroundColor: tokens.surfaceBg, border: `1.5px solid ${modeColor}30` }}
                  >
                    <input
                      type="text"
                      value={editName}
                      onChange={e => setEditName(e.target.value)}
                      className="w-full px-3 py-2 text-sm rounded-lg outline-none"
                      style={{ backgroundColor: tokens.pageBg, border: `1px solid ${tokens.cardBorder}`, color: tokens.textPrimary }}
                    />
                    <input
                      type="text"
                      value={editDesc}
                      onChange={e => setEditDesc(e.target.value)}
                      placeholder={t('collections.description')}
                      className="w-full px-3 py-2 text-sm rounded-lg outline-none"
                      style={{ backgroundColor: tokens.pageBg, border: `1px solid ${tokens.cardBorder}`, color: tokens.textPrimary }}
                    />
                    <button
                      onClick={() => setEditPublic(!editPublic)}
                      className="flex items-center gap-1.5 text-xs cursor-pointer"
                      style={{ color: tokens.textMuted }}
                    >
                      {editPublic ? <Globe size={12} style={{ color: modeColor }} /> : <Lock size={12} />}
                      {editPublic ? t('collections.public') : t('collections.private')}
                    </button>
                    <div className="flex gap-2">
                      <button
                        onClick={() => setEditingId(null)}
                        className="flex-1 py-2 text-sm rounded-xl cursor-pointer hover:opacity-70"
                        style={{ backgroundColor: tokens.pageBg, color: tokens.textMuted }}
                      >
                        {t('collections.cancel')}
                      </button>
                      <button
                        onClick={handleSaveEdit}
                        disabled={saving}
                        className="flex-1 py-2 text-sm font-medium rounded-xl cursor-pointer hover:opacity-80 flex items-center justify-center gap-1.5"
                        style={{ backgroundColor: modeColor, color: '#fff' }}
                      >
                        {saving ? <Loader2 size={13} className="animate-spin" /> : <CheckCircle2 size={13} />}
                        {t('collections.save')}
                      </button>
                    </div>
                  </div>
                ) : (
                  /* Collection card */
                  <div
                    className="group relative rounded-2xl overflow-hidden transition-all hover:shadow-lg"
                    style={{
                      backgroundColor: tokens.surfaceBg,
                      border: `1px solid ${tokens.cardBorder}`,
                    }}
                  >
                    {/* Colour strip */}
                    <div
                      className="h-1.5 w-full"
                      style={{ background: `linear-gradient(90deg, ${modeColor}, ${modeColor}55)` }}
                    />

                    <div className="p-4">
                      {/* Title row */}
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1.5 mb-0.5">
                            {col.isPublic
                              ? <Globe size={11} style={{ color: tokens.textMuted }} />
                              : <Lock size={11} style={{ color: tokens.textMuted }} />}
                            <span className="text-[10px]" style={{ color: tokens.textMuted }}>
                              {col.isPublic ? t('collections.public') : t('collections.private')}
                            </span>
                          </div>
                          <h3 className="font-semibold text-base leading-tight truncate" style={{ color: tokens.textPrimary }}>
                            {col.name}
                          </h3>
                          {col.description && (
                            <p className="text-xs mt-0.5 line-clamp-2" style={{ color: tokens.textMuted }}>
                              {col.description}
                            </p>
                          )}
                        </div>
                        {/* Action buttons */}
                        <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button
                            onClick={() => startEdit(col)}
                            className="p-1.5 rounded-lg cursor-pointer hover:opacity-70"
                            style={{ backgroundColor: `${modeColor}12`, color: modeColor }}
                          >
                            <Edit3 size={12} />
                          </button>
                          <button
                            onClick={() => setConfirmDeleteId(col.id)}
                            className="p-1.5 rounded-lg cursor-pointer hover:opacity-70"
                            style={{ backgroundColor: 'rgba(239,68,68,0.08)', color: '#EF4444' }}
                          >
                            <Trash2 size={12} />
                          </button>
                        </div>
                      </div>

                      {/* Item count */}
                      <div className="flex items-center gap-2 mt-3">
                        <div
                          className="flex items-center gap-1 px-2 py-1 rounded-full text-[11px]"
                          style={{ backgroundColor: `${modeColor}10`, color: modeColor }}
                        >
                          <Bookmark size={10} />
                          {col.items.length === 1 ? t('collections.itemCount', { count: 1 }) : t('collections.itemCountPlural', { count: col.items.length })}
                        </div>
                      </div>

                      {/* Confirm delete */}
                      <AnimatePresence>
                        {confirmDeleteId === col.id && (
                          <motion.div
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            className="mt-3 pt-3 overflow-hidden"
                            style={{ borderTop: `1px solid ${tokens.cardBorder}` }}
                          >
                            <p className="text-xs mb-2" style={{ color: tokens.textMuted }}>
                              {t('collections.deleteConfirm', { name: col.name })}
                            </p>
                            <div className="flex gap-2">
                              <button
                                onClick={() => setConfirmDeleteId(null)}
                                className="flex-1 py-1.5 text-xs rounded-lg cursor-pointer hover:opacity-70"
                                style={{ backgroundColor: tokens.pageBg, color: tokens.textMuted }}
                              >
                                {t('collections.cancel')}
                              </button>
                              <button
                                onClick={() => handleDelete(col.id)}
                                disabled={deletingId === col.id}
                                className="flex-1 py-1.5 text-xs font-medium rounded-lg cursor-pointer hover:opacity-80 flex items-center justify-center gap-1"
                                style={{ backgroundColor: '#EF4444', color: '#fff' }}
                              >
                                {deletingId === col.id ? <Loader2 size={12} className="animate-spin" /> : <Trash2 size={12} />}
                                {t('collections.delete')}
                              </button>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>

                      {/* View link */}
                      {confirmDeleteId !== col.id && (
                        <Link
                          to={`/collections/${col.id}`}
                          className="mt-3 flex items-center gap-1 text-xs font-medium transition-opacity hover:opacity-70"
                          style={{ color: modeColor, textDecoration: 'none' }}
                        >
                          {t('collections.viewCollection')} <ChevronRight size={12} />
                        </Link>
                      )}
                    </div>
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        )}
      </div>

      {/* Create Collection Modal */}
      <AnimatePresence>
        {showCreate && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[3000]"
              style={{ backgroundColor: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(4px)' }}
              onClick={() => setShowCreate(false)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.96, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96, y: 20 }}
              transition={{ type: 'spring', damping: 28, stiffness: 340 }}
              className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-md z-[3001] mx-4"
              onClick={e => e.stopPropagation()}
              style={{
                backgroundColor: tokens.pageBg,
                borderRadius: '20px',
                boxShadow: '0 24px 64px rgba(0,0,0,0.18)',
                border: `1px solid ${tokens.cardBorder}`,
              }}
            >
              <div className="flex items-center justify-between px-5 py-4" style={{ borderBottom: `1px solid ${tokens.cardBorder}` }}>
                <h3 className="text-base font-semibold" style={{ color: tokens.textPrimary }}>{t('collections.newCollection')}</h3>
                <button onClick={() => setShowCreate(false)} className="p-1.5 rounded-full cursor-pointer hover:opacity-70" style={{ color: tokens.textMuted }}>
                  <X size={16} />
                </button>
              </div>
              <div className="px-5 py-5 space-y-4">
                {createError && (
                  <div className="flex items-center gap-2 text-sm px-3 py-2 rounded-lg" style={{ backgroundColor: 'rgba(239,68,68,0.08)', color: '#EF4444' }}>
                    <AlertCircle size={14} /> {createError}
                  </div>
                )}
                <div>
                  <label className="block text-xs font-medium mb-1.5" style={{ color: tokens.textMuted }}>{t('collections.collectionName')}</label>
                  <input
                    type="text"
                    value={newName}
                    onChange={e => setNewName(e.target.value)}
                    placeholder={t('collections.namePlaceholder')}
                    autoFocus
                    className="w-full px-3 py-2.5 text-sm rounded-xl outline-none"
                    style={{ backgroundColor: tokens.surfaceBg, border: `1px solid ${tokens.cardBorder}`, color: tokens.textPrimary }}
                    onKeyDown={e => { if (e.key === 'Enter') handleCreate(); }}
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium mb-1.5" style={{ color: tokens.textMuted }}>{t('collections.description')}</label>
                  <textarea
                    value={newDesc}
                    onChange={e => setNewDesc(e.target.value)}
                    placeholder={t('collections.descPlaceholder')}
                    rows={2}
                    className="w-full px-3 py-2.5 text-sm rounded-xl outline-none resize-none"
                    style={{ backgroundColor: tokens.surfaceBg, border: `1px solid ${tokens.cardBorder}`, color: tokens.textPrimary }}
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium mb-2" style={{ color: tokens.textMuted }}>{t('collections.visibility')}</label>
                  <div className="flex gap-3">
                    {[
                      { id: false, icon: Lock, label: t('collections.private'), desc: t('collections.privateDesc') },
                      { id: true, icon: Globe, label: t('collections.public'), desc: t('collections.publicDesc') },
                    ].map(opt => (
                      <button
                        key={String(opt.id)}
                        onClick={() => setNewPublic(opt.id)}
                        className="flex-1 flex flex-col items-center gap-1.5 py-3 px-2 rounded-xl cursor-pointer transition-all"
                        style={{
                          backgroundColor: newPublic === opt.id ? `${modeColor}12` : tokens.surfaceBg,
                          border: `1.5px solid ${newPublic === opt.id ? modeColor + '40' : tokens.cardBorder}`,
                          color: newPublic === opt.id ? modeColor : tokens.textMuted,
                        }}
                      >
                        <opt.icon size={16} />
                        <span className="text-xs font-medium">{opt.label}</span>
                        <span className="text-[10px] text-center" style={{ color: tokens.textMuted }}>{opt.desc}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
              <div className="px-5 pb-5 flex gap-3">
                <button
                  onClick={() => setShowCreate(false)}
                  className="flex-1 py-2.5 text-sm rounded-xl cursor-pointer hover:opacity-70"
                  style={{ backgroundColor: tokens.surfaceBg, color: tokens.textMuted }}
                >
                  {t('collections.cancel')}
                </button>
                <button
                  onClick={handleCreate}
                  disabled={!newName.trim() || creating}
                  className="flex-1 py-2.5 text-sm font-medium rounded-xl cursor-pointer hover:opacity-80 transition-opacity disabled:opacity-40 flex items-center justify-center gap-2"
                  style={{ backgroundColor: modeColor, color: '#fff' }}
                >
                  {creating ? <Loader2 size={14} className="animate-spin" /> : <Plus size={14} />}
                  {creating ? t('collections.creating') : t('collections.createCollection')}
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}