import { useState } from 'react';
import { useParams, Link } from 'react-router';
import { motion } from 'motion/react';
import { ArrowLeft, MapPin, Clock, Star, Heart, Share2, Calendar, ExternalLink, ArrowRight, Navigation, ChevronRight, Zap, History, Map as MapIcon } from 'lucide-react';
import { useMode } from '../context/ModeContext';
import { useData } from '../context/DataContext';
import { modeConfig, type Mode } from '../data/mock-data';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import { getDesignTokens, isLightMode } from '../data/mode-styles';
import { CIcon } from '../components/CIcon';
import { AddToCollectionModal } from '../components/AddToCollectionModal';
import { ShareMenu } from '../components/ShareMenu';
import { useCollections } from '../context/CollectionsContext';
import { getEventLink } from '../utils/event-helpers';
import { useTranslation } from 'react-i18next';

// ─── Shared past events section ───
function PastEventsSection({ pastEvents, tokens, modeColor, showPast, setShowPast, aesthetic }: {
  pastEvents: any[];
  tokens: ReturnType<typeof getDesignTokens>;
  modeColor: string;
  showPast: boolean;
  setShowPast: (v: boolean) => void;
  aesthetic?: string;
}) {
  if (pastEvents.length === 0) return null;
  const isDegen = aesthetic === 'bold-poster';
  const isArtsy = aesthetic === 'editorial-minimal';
  const amberColor = '#F59E0B';

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.35 }}>
      <button
        onClick={() => setShowPast(!showPast)}
        className="flex items-center gap-2 mb-4 cursor-pointer group transition-all hover:opacity-80"
        style={{ background: 'none', border: 'none', padding: 0 }}
      >
        <History size={16} style={{ color: amberColor }} />
        <h2 style={{
          fontSize: isArtsy ? '0.85rem' : '1.1rem',
          color: tokens.textPrimary,
          fontFamily: tokens.headingFont,
          fontWeight: isDegen ? 700 : isArtsy ? 400 : 600,
          textTransform: isDegen ? 'uppercase' : undefined,
          letterSpacing: isArtsy ? '0.1em' : isDegen ? '-0.02em' : undefined,
          margin: 0,
        }}>
          {isArtsy ? 'Past Programme' : isDegen ? 'PAST EVENTS' : 'Past Events'}
        </h2>
        <span className="px-2 py-0.5 text-[10px] font-semibold" style={{
          backgroundColor: `${amberColor}15`,
          color: amberColor,
          borderRadius: isDegen ? '2px' : '9999px',
        }}>
          {pastEvents.length}
        </span>
        <ChevronRight
          size={14}
          style={{
            color: tokens.textMuted,
            transform: showPast ? 'rotate(90deg)' : 'rotate(0deg)',
            transition: 'transform 0.2s ease',
          }}
        />
      </button>
      {showPast && (
        <div className="space-y-2" style={{ opacity: 0.7 }}>
          {pastEvents.map((event: any) => (
            <Link
              key={event.id}
              to={getEventLink(event)}
              className="flex gap-3 p-3 transition-all no-underline hover:opacity-80"
              style={{
                borderRadius: isDegen ? '4px' : isArtsy ? '0' : tokens.cardRadius || '16px',
                backgroundColor: tokens.cardBg || tokens.surfaceBg,
                border: `1px solid ${tokens.cardBorder}`,
                display: 'flex',
              }}
            >
              <div className="h-14 w-14 overflow-hidden flex-shrink-0" style={{
                borderRadius: isDegen ? '4px' : isArtsy ? '0' : tokens.imageRadius || '12px',
                filter: 'grayscale(40%)',
              }}>
                <ImageWithFallback src={event.image} alt={event.title} className="h-full w-full object-cover" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <h3 className="text-sm truncate" style={{ color: tokens.textSecondary, fontWeight: isDegen ? 700 : 500, textTransform: isDegen ? 'uppercase' : undefined }}>{event.title}</h3>
                  <span className="flex-shrink-0 px-1.5 py-0.5 text-[9px] font-semibold uppercase" style={{
                    backgroundColor: `${amberColor}15`,
                    color: amberColor,
                    borderRadius: isDegen ? '2px' : '4px',
                  }}>
                    Past
                  </span>
                </div>
                <div className="flex items-center gap-2 mt-0.5">
                  <Clock size={11} style={{ color: tokens.textMuted }} />
                  <span className="text-xs" style={{ color: tokens.textMuted }}>{event.date}{event.time ? ` · ${event.time}` : ''}</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </motion.div>
  );
}

// ─── Shared score bar component ───
function ModeScoreBar({ mode, score, tokens, modeColor, active, aesthetic }: { mode: Mode; score: number; tokens: ReturnType<typeof getDesignTokens>; modeColor: string; active: boolean; aesthetic: string }) {
  const isDegen = aesthetic === 'bold-poster';
  return (
    <div
      className="flex items-center gap-3"
      style={{ opacity: active ? 1 : 0.6 }}
    >
      <span className="w-6 flex items-center justify-center"><CIcon id={mode} size={14} mode={mode} glow={active} /></span>
      <span className="text-xs w-14" style={{ color: tokens.textMuted, fontFamily: tokens.headingFont, textTransform: isDegen ? 'uppercase' : 'none', fontSize: isDegen ? '0.6rem' : '0.75rem' }}>{modeConfig[mode].label}</span>
      <div className="flex-1 h-1.5 overflow-hidden" style={{ borderRadius: '2px', backgroundColor: `${tokens.cardBorder}` }}>
        <motion.div initial={{ width: 0 }} animate={{ width: `${score * 100}%` }} transition={{ duration: 0.8, delay: 0.2 }} className="h-full" style={{ backgroundColor: modeConfig[mode].color, borderRadius: '2px' }} />
      </div>
      <span className="text-xs w-8 text-right" style={{ color: tokens.textMuted, fontFamily: tokens.headingFont }}>{Math.round(score * 100)}</span>
    </div>
  );
}

export function VenueDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { currentMode } = useMode();
  const { t } = useTranslation();
  const modeColor = currentMode && currentMode !== 'lifestyle' ? modeConfig[currentMode].color : currentMode === 'lifestyle' ? '#2D6A4F' : '#8338EC';
  const tokens = getDesignTokens(currentMode);
  const light = isLightMode(currentMode);
  const isArtsy = currentMode === 'artsy';
  const isDegen = currentMode === 'degen';
  const isFamily = currentMode === 'family';
  const isFoodie = currentMode === 'foodie';

  const { venues, allEvents, recaps } = useData();
  const { isInAnyCollection } = useCollections();
  const venue = venues.find((v) => v.id === id);
  const isSaved = venue ? isInAnyCollection(venue.id) : false;
  const [collectionModalOpen, setCollectionModalOpen] = useState(false);
  const [showPastEvents, setShowPastEvents] = useState(false);
  if (!venue) {
    return (
      <div className="flex h-[80vh] items-center justify-center">
        <div className="text-center">
          <p style={{ color: tokens.textMuted }} className="mb-4">{t('common.notFound')}</p>
          <Link to="/map" className="text-sm" style={{ color: modeColor }}>
            ← {t('map.mapView')}
          </Link>
        </div>
      </div>
    );
  }

  // Use allEvents (includes past) to split into upcoming/ongoing and past
  const allVenueEvents = allEvents.filter((e) => e.venueId === venue.id);
  const venueEvents = allVenueEvents.filter((e) => e.status !== 'past');
  const pastEvents = allVenueEvents.filter((e) => e.status === 'past');
  // Match recaps: direct venueId match OR linked event's venueId match
  const venueRecaps = recaps.filter((r) => {
    if (r.venueId === venue.id) return true;
    // Fallback: check if the recap's linked event belongs to this venue
    if (r.eventId) {
      const linkedEvent = allEvents.find(e => e.id === r.eventId);
      if (linkedEvent && linkedEvent.venueId === venue.id) return true;
    }
    return false;
  });

  // Show all venue recaps, sorted by current mode relevance
  const filteredRecaps = currentMode
    ? [...venueRecaps].sort((a, b) => (b.modeScores[currentMode!] || 0) - (a.modeScores[currentMode!] || 0))
    : venueRecaps;

  // ════════════════════════════════════════════
  //  ARTSY — editorial minimal (PMA-inspired)
  // ════════════════════════════════════════════
  if (isArtsy) {
    return (
      <div className="min-h-screen" data-nav-theme="dark">
        {/* Back link */}
        <div className="px-4 sm:px-8 lg:px-12 pt-6 sm:pt-8 max-w-[1440px] mx-auto">
          <Link
            to="/map"
            className="inline-flex items-center gap-2 transition-opacity hover:opacity-60"
            style={{
              fontFamily: tokens.bodyFont,
              fontSize: '0.7rem',
              color: tokens.textMuted,
              letterSpacing: '0.15em',
            }}
          >
            <ArrowLeft size={12} />
            <span className="uppercase">Back</span>
          </Link>
        </div>

        {/* Hero — rule of thirds */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 sm:gap-8 px-4 sm:px-8 lg:px-12 pt-6 sm:pt-12 pb-10 sm:pb-20 max-w-[1440px] mx-auto">
          {/* Left text — 4 cols */}
          <div className="lg:col-span-4 flex flex-col justify-center order-2 lg:order-1">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
            >
              <span
                className="block mb-2 sm:mb-4 tracking-[0.3em] uppercase"
                style={{ fontSize: '0.6rem', color: tokens.textMuted, fontFamily: tokens.bodyFont }}
              >
                {venue.category}
              </span>

              <h1
                className="mb-2"
                style={{
                  fontFamily: tokens.headingFont,
                  fontSize: 'clamp(1.5rem, 4vw, 3rem)',
                  color: tokens.textPrimary,
                  fontWeight: 400,
                  lineHeight: 1.08,
                }}
              >
                {venue.name}
              </h1>

              <p
                className="mb-6"
                style={{
                  fontFamily: tokens.headingFont,
                  fontSize: '0.9rem',
                  color: tokens.textMuted,
                  fontStyle: 'italic',
                }}
              >
                {venue.nameZh}
              </p>

              <div className="w-12 h-px mb-6" style={{ backgroundColor: tokens.textMuted }} />

              <p
                className="mb-4 sm:mb-8 hidden sm:block"
                style={{
                  fontFamily: tokens.bodyFont,
                  fontSize: '0.95rem',
                  color: tokens.textSecondary,
                  lineHeight: 1.8,
                }}
              >
                {venue.description}
              </p>

              {/* Details */}
              <div className="space-y-3 mb-8">
                <div className="flex items-start gap-3">
                  <MapPin size={12} style={{ color: tokens.textMuted, marginTop: '3px' }} />
                  <div>
                    <span className="block" style={{ fontSize: '0.8rem', color: tokens.textSecondary, fontFamily: tokens.bodyFont }}>
                      {venue.address}
                    </span>
                    <span className="block" style={{ fontSize: '0.7rem', color: tokens.textMuted, fontFamily: tokens.bodyFont }}>
                      {venue.district}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span style={{ fontSize: '0.7rem', color: tokens.textMuted }}>
                    {'$'.repeat(venue.priceRange)} Price Range
                  </span>
                </div>
              </div>

              {/* Tags */}
              <div className="flex flex-wrap gap-2 mb-8">
                {(venue.vibeTags || []).map((tag) => (
                  <span
                    key={tag}
                    className="px-3 py-1"
                    style={{
                      fontSize: '0.65rem',
                      letterSpacing: '0.1em',
                      color: tokens.textMuted,
                      border: `1px solid ${tokens.cardBorder}`,
                      fontFamily: tokens.bodyFont,
                    }}
                  >
                    {tag}
                  </span>
                ))}
              </div>

              {/* Actions */}
              <div className="flex gap-4">
                <button
                  onClick={() => setCollectionModalOpen(true)}
                  className="inline-flex items-center gap-2 py-2 transition-opacity hover:opacity-70 cursor-pointer"
                  style={{
                    fontFamily: tokens.headingFont,
                    fontSize: '0.7rem',
                    color: tokens.textPrimary,
                    letterSpacing: '0.15em',
                    borderBottom: `1px solid ${tokens.textPrimary}`,
                  }}
                >
                  <Heart size={12} fill={isSaved ? tokens.textPrimary : 'none'} />
                  <span className="uppercase">{isSaved ? 'Saved' : 'Save'}</span>
                </button>
                <ShareMenu title={venue.name} url={window.location.href}>
                  {({ onClick, ref }) => (
                    <button
                      ref={ref}
                      onClick={onClick}
                      className="inline-flex items-center gap-2 py-2 transition-opacity hover:opacity-70 cursor-pointer"
                      style={{
                        fontFamily: tokens.headingFont,
                        fontSize: '0.7rem',
                        color: tokens.textMuted,
                        letterSpacing: '0.15em',
                      }}
                    >
                      <Share2 size={12} />
                      <span className="uppercase">Share</span>
                    </button>
                  )}
                </ShareMenu>
              </div>
            </motion.div>
          </div>

          {/* Right image — 8 cols */}
          <div className="lg:col-span-8 order-1 lg:order-2">
            <motion.div
              initial={{ opacity: 0, scale: 1.02 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
              className="overflow-hidden aspect-[4/3] lg:aspect-[3/2]"
            >
              <ImageWithFallback
                src={venue.image}
                alt={venue.name}
                className="h-full w-full object-cover"
                style={{ filter: 'contrast(1.05)' }}
              />
            </motion.div>
          </div>
        </div>

        {/* Mode scores — minimal bar style */}
        <div className="px-4 sm:px-8 lg:px-12 py-8 sm:py-16 max-w-[1440px] mx-auto" style={{ borderTop: `1px solid ${tokens.cardBorder}` }}>
          <span
            className="block mb-4 sm:mb-8 tracking-[0.3em] uppercase"
            style={{ fontSize: '0.55rem', color: tokens.textMuted }}
          >
            Mode Compatibility
          </span>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-8">
            {(Object.entries(venue.modeScores || {}) as [Mode, number][]).map(([mode, score]) => (
              <div key={mode}>
                <div className="flex items-center justify-between mb-2">
                  <span style={{ fontFamily: tokens.headingFont, fontSize: '0.85rem', color: tokens.textPrimary }}>
                    {modeConfig[mode].label}
                  </span>
                  <span style={{ fontSize: '0.7rem', color: tokens.textMuted }}>
                    {Math.round(score * 100)}
                  </span>
                </div>
                <div className="h-px w-full" style={{ backgroundColor: tokens.cardBorder }}>
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${score * 100}%` }}
                    transition={{ duration: 1, delay: 0.3 }}
                    className="h-full"
                    style={{ backgroundColor: modeConfig[mode].color }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Upcoming events */}
        {venueEvents.length > 0 && (
          <div className="px-4 sm:px-8 lg:px-12 py-8 sm:py-16 max-w-[1440px] mx-auto" style={{ borderTop: `1px solid ${tokens.cardBorder}` }}>
            <span
              className="block mb-4 sm:mb-8 tracking-[0.3em] uppercase"
              style={{ fontSize: '0.55rem', color: tokens.textMuted }}
            >
              Programme
            </span>
            <div className="space-y-4 sm:space-y-8">
              {venueEvents.map((event) => (
                <Link
                  key={event.id}
                  to={getEventLink(event)}
                  className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center pb-8 transition-opacity hover:opacity-70"
                  style={{ borderBottom: `1px solid ${tokens.cardBorder}`, textDecoration: 'none' }}
                >
                  <div className="lg:col-span-2">
                    <span style={{ fontFamily: tokens.bodyFont, fontSize: '0.75rem', color: tokens.textMuted }}>
                      {event.date}
                    </span>
                  </div>
                  <div className="lg:col-span-6">
                    <h3
                      style={{
                        fontFamily: tokens.headingFont,
                        fontSize: '1.1rem',
                        color: tokens.textPrimary,
                        fontWeight: 400,
                      }}
                    >
                      {event.title}
                    </h3>
                    <span style={{ fontSize: '0.75rem', color: tokens.textMuted, fontFamily: tokens.bodyFont }}>
                      {event.time} — {event.category}
                    </span>
                  </div>
                  <div className="lg:col-span-2">
                    <span style={{ fontSize: '0.75rem', color: tokens.textMuted }}>
                      {event.price}
                    </span>
                  </div>
                  <div className="lg:col-span-2 text-right">
                    <span
                      className="inline-flex items-center gap-1"
                      style={{
                        fontFamily: tokens.headingFont,
                        fontSize: '0.65rem',
                        color: tokens.textPrimary,
                        letterSpacing: '0.1em',
                      }}
                    >
                      DETAILS <ArrowRight size={10} />
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}

        {/* Past events */}
        {pastEvents.length > 0 && (
          <div className="px-4 sm:px-8 lg:px-12 py-8 sm:py-16 max-w-[1440px] mx-auto" style={{ borderTop: `1px solid ${tokens.cardBorder}` }}>
            <PastEventsSection pastEvents={pastEvents} tokens={tokens} modeColor={modeColor} showPast={showPastEvents} setShowPast={setShowPastEvents} aesthetic={tokens.aesthetic} />
          </div>
        )}

        {/* Recaps */}
        {filteredRecaps.length > 0 && (
          <div className="px-4 sm:px-8 lg:px-12 py-8 sm:py-16 pb-12 sm:pb-24 max-w-[1440px] mx-auto" style={{ borderTop: `1px solid ${tokens.cardBorder}` }}>
            <span
              className="block mb-4 sm:mb-8 tracking-[0.3em] uppercase"
              style={{ fontSize: '0.55rem', color: tokens.textMuted }}
            >
              Gallery
            </span>
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-2">
              {filteredRecaps.map((recap, i) => (
                <Link key={recap.id} to={`/recaps/${recap.id}`} className="no-underline block">
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: i * 0.1 }}
                    className="overflow-hidden aspect-square group cursor-pointer relative"
                  >
                    <ImageWithFallback
                      src={recap.thumbnail}
                      alt={recap.caption}
                      className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-[1.03]"
                      style={{ filter: 'grayscale(20%)' }}
                    />
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-500" />
                  </motion.div>
                </Link>
              ))}
            </div>
          </div>
        )}
        <AddToCollectionModal
          isOpen={collectionModalOpen}
          onClose={() => setCollectionModalOpen(false)}
          itemId={venue?.id || ''}
          itemType="venue"
          itemName={venue?.name}
        />
      </div>
    );
  }

  // ════════════════════════════════════════════
  //  DEGEN — bold poster / editorial brutalist
  // ════════════════════════════════════════════
  if (isDegen) {
    return (
      <div className="min-h-screen" data-nav-theme="dark">
        {/* Back */}
        <div className="px-4 sm:px-6 lg:px-8 pt-6 max-w-[1200px] mx-auto">
          <Link
            to="/map"
            className="inline-flex items-center gap-2 transition-opacity hover:opacity-60"
            style={{
              fontFamily: tokens.headingFont,
              fontSize: '0.65rem',
              color: 'rgba(0,0,0,0.3)',
              letterSpacing: '0.1em',
              textTransform: 'uppercase',
              fontWeight: 700,
            }}
          >
            <ArrowLeft size={12} />
            /BACK
          </Link>
        </div>

        {/* Hero — poster layout */}
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-12">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Left: image */}
            <div className="lg:col-span-7">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="overflow-hidden aspect-[4/3]"
                style={{ borderRadius: '4px' }}
              >
                <ImageWithFallback
                  src={venue.image}
                  alt={venue.name}
                  className="h-full w-full object-cover"
                  style={{ filter: 'contrast(1.15) saturate(0.9)' }}
                />
              </motion.div>
            </div>

            {/* Right: info */}
            <div className="lg:col-span-5 flex flex-col justify-center">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
              >
                <span style={{ fontSize: '0.55rem', color: 'rgba(0,0,0,0.25)', fontFamily: tokens.headingFont, fontWeight: 700, letterSpacing: '0.1em' }}>/001</span>

                <div className="flex items-center gap-3 mt-2 mb-3">
                  <span
                    className="px-2 py-0.5"
                    style={{
                      backgroundColor: '#D600FF',
                      color: '#fff',
                      borderRadius: '2px',
                      fontSize: '0.55rem',
                      fontWeight: 700,
                      fontFamily: tokens.headingFont,
                      textTransform: 'uppercase',
                    }}
                  >
                    {venue.category}
                  </span>
                  <span style={{ fontSize: '0.6rem', color: 'rgba(0,0,0,0.25)', fontFamily: tokens.headingFont }}>{venue.district}</span>
                </div>

                <h1
                  style={{
                    fontFamily: tokens.headingFont,
                    fontSize: 'clamp(2rem, 4.5vw, 3.5rem)',
                    color: '#0A0A0A',
                    fontWeight: 700,
                    textTransform: 'uppercase',
                    letterSpacing: '-0.03em',
                    lineHeight: 0.95,
                  }}
                >
                  {venue.name}
                </h1>
                <p style={{ fontSize: '0.8rem', color: 'rgba(0,0,0,0.3)', fontFamily: tokens.bodyFont, marginTop: '8px' }}>{venue.nameZh}</p>

                <p
                  className="mt-6"
                  style={{
                    fontFamily: tokens.bodyFont,
                    fontSize: '0.85rem',
                    color: 'rgba(0,0,0,0.5)',
                    lineHeight: 1.6,
                  }}
                >
                  {venue.description}
                </p>

                {/* Tags */}
                <div className="flex flex-wrap gap-2 mt-6">
                  {(venue.vibeTags || []).map((tag) => (
                    <span
                      key={tag}
                      className="px-2.5 py-1"
                      style={{
                        border: '2px solid rgba(0,0,0,0.08)',
                        borderRadius: '2px',
                        fontSize: '0.55rem',
                        fontWeight: 700,
                        fontFamily: tokens.headingFont,
                        textTransform: 'uppercase',
                        color: 'rgba(0,0,0,0.4)',
                        letterSpacing: '0.05em',
                      }}
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                {/* Location */}
                <div className="mt-6 p-4" style={{ backgroundColor: 'rgba(0,0,0,0.03)', borderRadius: '4px', border: '2px solid rgba(0,0,0,0.04)' }}>
                  <div className="flex items-center gap-2 mb-1">
                    <Navigation size={12} style={{ color: 'rgba(0,0,0,0.3)' }} />
                    <span style={{ fontSize: '0.75rem', color: '#0A0A0A', fontFamily: tokens.bodyFont }}>{venue.address}</span>
                  </div>
                  <span style={{ fontSize: '0.65rem', color: 'rgba(0,0,0,0.3)', fontFamily: tokens.headingFont, textTransform: 'uppercase', letterSpacing: '0.05em' }}>{'$'.repeat(venue.priceRange)} · {venue.district}</span>
                </div>

                {/* Actions */}
                <div className="flex gap-3 mt-6">
                  <button
                    onClick={() => setCollectionModalOpen(true)}
                    className="flex-1 flex items-center justify-center gap-2 py-3 text-sm transition-all hover:opacity-90 cursor-pointer"
                    style={{ backgroundColor: '#0A0A0A', color: '#EDFF00', borderRadius: '4px', fontFamily: tokens.headingFont, fontWeight: 700, textTransform: 'uppercase', fontSize: '0.7rem', letterSpacing: '0.05em' }}
                  >
                    <Heart size={14} fill={isSaved ? '#EDFF00' : 'none'} /> {isSaved ? 'SAVED' : 'SAVE'}
                  </button>
                  <ShareMenu title={venue.name} url={window.location.href}>
                    {({ onClick, ref }) => (
                      <button ref={ref} onClick={onClick}
                        className="px-4 py-3 transition-all hover:opacity-80 cursor-pointer"
                        style={{ border: '2px solid rgba(0,0,0,0.1)', borderRadius: '4px', color: 'rgba(0,0,0,0.4)' }}>
                        <Share2 size={16} />
                      </button>
                    )}
                  </ShareMenu>
                </div>
              </motion.div>
            </div>
          </div>
        </div>

        {/* Mode scores — bold poster style */}
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 py-12" style={{ borderTop: '2px solid rgba(0,0,0,0.04)' }}>
          <span style={{ fontSize: '0.55rem', color: 'rgba(0,0,0,0.25)', fontFamily: tokens.headingFont, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase' }}>/002 — MODE COMPATIBILITY</span>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
            {(Object.entries(venue.modeScores || {}) as [Mode, number][]).map(([mode, score]) => (
              <div
                key={mode}
                className="p-4"
                style={{
                  backgroundColor: currentMode === mode ? '#0A0A0A' : 'rgba(0,0,0,0.02)',
                  borderRadius: '4px',
                  border: currentMode === mode ? 'none' : '2px solid rgba(0,0,0,0.04)',
                }}
              >
                <div className="flex items-center justify-between mb-3">
                  <CIcon id={mode} size={20} mode={mode} glow />
                  <span style={{ fontFamily: tokens.headingFont, fontSize: '1.8rem', fontWeight: 700, color: currentMode === mode ? '#EDFF00' : '#0A0A0A', lineHeight: 1 }}>
                    {Math.round(score * 100)}
                  </span>
                </div>
                <span style={{ fontFamily: tokens.headingFont, fontSize: '0.6rem', fontWeight: 700, color: currentMode === mode ? 'rgba(237,255,0,0.5)' : 'rgba(0,0,0,0.3)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                  {modeConfig[mode].label}
                </span>
                <div className="mt-2 h-1 overflow-hidden" style={{ borderRadius: '2px', backgroundColor: currentMode === mode ? 'rgba(237,255,0,0.15)' : 'rgba(0,0,0,0.06)' }}>
                  <motion.div initial={{ width: 0 }} animate={{ width: `${score * 100}%` }} transition={{ duration: 0.8, delay: 0.2 }} className="h-full" style={{ backgroundColor: modeConfig[mode].color, borderRadius: '2px' }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Events — table list */}
        {venueEvents.length > 0 && (
          <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 py-12" style={{ borderTop: '2px solid rgba(0,0,0,0.04)' }}>
            <span style={{ fontSize: '0.55rem', color: 'rgba(0,0,0,0.25)', fontFamily: tokens.headingFont, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase' }}>/003 — UPCOMING</span>
            <div className="mt-6 space-y-1">
              {venueEvents.map((event, i) => (
                <motion.div
                  key={event.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                >
                  <Link
                    to={getEventLink(event)}
                    className="flex flex-col sm:flex-row items-start sm:items-center gap-4 py-4 group hover:bg-black/[0.02] transition-all"
                    style={{ borderBottom: '2px solid rgba(0,0,0,0.04)', textDecoration: 'none' }}
                  >
                    <div className="w-20 h-14 overflow-hidden flex-shrink-0" style={{ borderRadius: '4px' }}>
                      <ImageWithFallback src={event.image} alt={event.title} className="h-full w-full object-cover" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <span style={{ fontSize: '0.55rem', color: '#D600FF', fontFamily: tokens.headingFont, fontWeight: 700, textTransform: 'uppercase' }}>{event.category}</span>
                      <h3 style={{ fontFamily: tokens.headingFont, fontSize: '1rem', color: '#0A0A0A', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '-0.02em' }}>{event.title}</h3>
                    </div>
                    <span style={{ fontSize: '0.65rem', color: 'rgba(0,0,0,0.3)', fontFamily: tokens.headingFont, textTransform: 'uppercase' }}>{event.date} · {event.time}</span>
                    <span className="px-3 py-1.5" style={{ border: '2px solid #0A0A0A', borderRadius: '4px', fontSize: '0.7rem', color: '#0A0A0A', fontWeight: 700, fontFamily: tokens.headingFont }}>{event.price}</span>
                  </Link>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        {/* Past events */}
        {pastEvents.length > 0 && (
          <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 py-12" style={{ borderTop: '2px solid rgba(0,0,0,0.04)' }}>
            <PastEventsSection pastEvents={pastEvents} tokens={tokens} modeColor={modeColor} showPast={showPastEvents} setShowPast={setShowPastEvents} aesthetic={tokens.aesthetic} />
          </div>
        )}

        {/* Recaps */}
        {filteredRecaps.length > 0 && (
          <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 py-12 pb-24" style={{ borderTop: '2px solid rgba(0,0,0,0.04)' }}>
            <span style={{ fontSize: '0.55rem', color: 'rgba(0,0,0,0.25)', fontFamily: tokens.headingFont, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase' }}>/004 — RECAPS</span>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 mt-6">
              {filteredRecaps.map((recap, i) => (
                <Link key={recap.id} to={`/recaps/${recap.id}`} className="no-underline block">
                  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.06 }} className="overflow-hidden aspect-square group cursor-pointer relative" style={{ borderRadius: '4px' }}>
                    <ImageWithFallback src={recap.thumbnail} alt={recap.caption} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" style={{ filter: 'contrast(1.1) saturate(0.85)' }} />
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors duration-300" />
                    <div className="absolute bottom-0 left-0 right-0 p-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      <p className="text-xs text-white truncate" style={{ fontFamily: tokens.headingFont, fontWeight: 700, textTransform: 'uppercase', fontSize: '0.6rem' }}>{recap.caption}</p>
                    </div>
                  </motion.div>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  }

  // ════════════════════════════════════════════
  //  FAMILY — warm playful (Playhouse Daycare)
  // ════════════════════════════════════════════
  if (isFamily) {
    return (
      <>
      <div className="min-h-screen" data-nav-theme="dark">
        {/* Back */}
        <div className="px-4 sm:px-6 lg:px-8 pt-6 max-w-[1200px] mx-auto">
          <Link
            to="/map"
            className="inline-flex items-center gap-2 transition-opacity hover:opacity-70 px-4 py-2"
            style={{
              fontFamily: tokens.headingFont,
              fontSize: '0.8rem',
              color: '#FF8C42',
              fontWeight: 700,
              backgroundColor: 'rgba(255,140,66,0.08)',
              borderRadius: '20px',
            }}
          >
            <ArrowLeft size={14} />
            Back to Map
          </Link>
        </div>

        {/* Hero — warm rounded */}
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="overflow-hidden aspect-[4/3] sm:aspect-[16/7]"
            style={{ borderRadius: '20px' }}
          >
            <ImageWithFallback
              src={venue.image}
              alt={venue.name}
              className="h-full w-full object-cover"
            />
          </motion.div>
        </div>

        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 pb-8 sm:pb-16">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 sm:gap-8">
            {/* Main */}
            <div className="lg:col-span-2 space-y-6 sm:space-y-8">
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
                <div className="flex items-center gap-3 mb-3">
                  <CIcon id={venue.category} size={28} mode="auto" glow animated />
                  <div>
                    <h1 style={{ fontFamily: tokens.headingFont, fontSize: 'clamp(1.5rem, 3vw, 2.2rem)', color: tokens.textPrimary, fontWeight: 800 }}>
                      {venue.name}
                    </h1>
                    <p style={{ fontSize: '0.85rem', color: tokens.textMuted, fontFamily: tokens.bodyFont }}>{venue.nameZh}</p>
                  </div>
                </div>

                <p style={{ fontFamily: tokens.bodyFont, fontSize: '0.95rem', color: tokens.textSecondary, lineHeight: 1.7, marginTop: '12px' }}>{venue.description}</p>

                {/* Tags */}
                <div className="flex flex-wrap gap-2 mt-5">
                  {(venue.vibeTags || []).map((tag) => (
                    <span
                      key={tag}
                      className="px-3 py-1.5 text-xs"
                      style={{
                        backgroundColor: 'rgba(255,140,66,0.08)',
                        color: '#FF8C42',
                        borderRadius: '20px',
                        fontFamily: tokens.bodyFont,
                        fontWeight: 600,
                      }}
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              </motion.div>

              {/* Events */}
              {venueEvents.length > 0 && (
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
                  <h2 className="mb-4 flex items-center gap-2" style={{ fontSize: '1.1rem', color: tokens.textPrimary, fontFamily: tokens.headingFont, fontWeight: 800 }}>
                    Upcoming Events
                  </h2>
                  <div className="space-y-3">
                    {venueEvents.map((event) => (
                      <Link
                        key={event.id}
                        to={getEventLink(event)}
                        className="flex gap-4 p-4 transition-all hover:shadow-md"
                        style={{ borderRadius: '24px', backgroundColor: '#fff', border: '1px solid rgba(0,0,0,0.04)', boxShadow: '0 2px 12px rgba(0,0,0,0.04)', textDecoration: 'none' }}
                      >
                        <div className="h-20 w-20 overflow-hidden flex-shrink-0" style={{ borderRadius: '16px' }}>
                          <ImageWithFallback src={event.image} alt={event.title} className="h-full w-full object-cover" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h3 className="text-sm truncate" style={{ color: tokens.textPrimary, fontWeight: 700 }}>{event.title}</h3>
                          <div className="flex items-center gap-2 mt-1">
                            <Clock size={12} style={{ color: '#FF8C42' }} />
                            <span className="text-xs" style={{ color: tokens.textMuted }}>{event.date} at {event.time}</span>
                          </div>
                          <div className="flex items-center gap-2 mt-2">
                            <span className="px-2.5 py-0.5 text-[10px]" style={{ backgroundColor: 'rgba(255,140,66,0.1)', color: '#FF8C42', borderRadius: '12px', fontWeight: 600 }}>{event.price}</span>
                            {event.modeTags.map((tag) => (<span key={tag} className="inline-flex items-center"><CIcon id={tag} size={12} style={{ color: modeConfig[tag].color }} /></span>))}
                          </div>
                        </div>
                      </Link>
                    ))}
                  </div>
                </motion.div>
              )}

              {/* Past events */}
              <PastEventsSection pastEvents={pastEvents} tokens={tokens} modeColor={modeColor} showPast={showPastEvents} setShowPast={setShowPastEvents} aesthetic={tokens.aesthetic} />

              {/* Recaps */}
              {filteredRecaps.length > 0 && (
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
                  <h2 className="mb-4 flex items-center gap-2" style={{ fontSize: '1.1rem', color: tokens.textPrimary, fontFamily: tokens.headingFont, fontWeight: 800 }}>
                    Past Memories
                  </h2>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {filteredRecaps.map((recap, i) => (
                      <Link key={recap.id} to={`/recaps/${recap.id}`} className="no-underline block">
                        <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: i * 0.08 }} className="group relative aspect-square overflow-hidden cursor-pointer" style={{ borderRadius: '20px' }}>
                          <ImageWithFallback src={recap.thumbnail} alt={recap.caption} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                          <div className="absolute bottom-0 left-0 right-0 p-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                            <p className="text-xs text-white truncate" style={{ fontWeight: 600 }}>{recap.caption}</p>
                            <div className="flex items-center gap-2 mt-1">
                              <Heart size={10} className="text-white/60" />
                              <span className="text-[10px] text-white/50">{recap.engagement}</span>
                            </div>
                          </div>
                        </motion.div>
                      </Link>
                    ))}
                  </div>
                </motion.div>
              )}
            </div>

            {/* Sidebar */}
            <div className="space-y-5">
              <div className="flex gap-2">
                <button onClick={() => setCollectionModalOpen(true)} className="flex-1 flex items-center justify-center gap-2 py-3 text-sm text-white transition-all hover:opacity-90 cursor-pointer" style={{ background: 'linear-gradient(135deg, #FF8C42, #FFB347)', borderRadius: '20px', fontWeight: 700 }}>
                  <Heart size={16} fill={isSaved ? '#fff' : 'none'} /> {isSaved ? 'Saved' : 'Save'}
                </button>
                <ShareMenu title={venue.name} url={window.location.href}>
                  {({ onClick, ref }) => (
                    <button ref={ref} onClick={onClick} className="px-4 py-3 transition-all cursor-pointer" style={{ backgroundColor: 'rgba(255,140,66,0.08)', color: '#FF8C42', borderRadius: '20px' }}>
                      <Share2 size={16} />
                    </button>
                  )}
                </ShareMenu>
              </div>

              <div className="p-5 space-y-3" style={{ borderRadius: '24px', backgroundColor: '#fff', boxShadow: '0 2px 16px rgba(0,0,0,0.04)' }}>
                <h3 className="text-xs tracking-wider" style={{ color: '#FF8C42', fontWeight: 700 }}>Mode Scores</h3>
                {(Object.entries(venue.modeScores || {}) as [Mode, number][]).map(([mode, score]) => (
                  <ModeScoreBar key={mode} mode={mode} score={score} tokens={tokens} modeColor={modeColor} active={currentMode === mode} aesthetic={tokens.aesthetic} />
                ))}
              </div>

              <div className="p-5 space-y-3" style={{ borderRadius: '24px', backgroundColor: '#fff', boxShadow: '0 2px 16px rgba(0,0,0,0.04)' }}>
                <h3 className="text-xs tracking-wider" style={{ color: '#FF8C42', fontWeight: 700 }}>Details</h3>
                <div className="flex items-start gap-2.5">
                  <MapPin size={14} className="mt-0.5" style={{ color: '#FF8C42' }} />
                  <div>
                    <span className="text-sm block" style={{ color: tokens.textSecondary }}>{venue.address}</span>
                    <span className="text-xs" style={{ color: tokens.textMuted }}>{venue.district}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2.5">
                  <span className="text-sm">💰</span>
                  <span className="text-sm" style={{ color: tokens.textSecondary }}>{'$'.repeat(venue.priceRange)} Price Range</span>
                </div>
              </div>

              <Link to="/map" className="block overflow-hidden transition-all hover:shadow-md" style={{ borderRadius: '24px', backgroundColor: '#fff', boxShadow: '0 2px 16px rgba(0,0,0,0.04)' }}>
                <div className="h-36 flex items-center justify-center" style={{ background: 'linear-gradient(135deg, rgba(255,140,66,0.05), rgba(67,217,173,0.05))' }}>
                  <div className="text-center">
                    <span className="text-2xl block mb-1">🗺️</span>
                    <span className="text-xs" style={{ color: '#FF8C42', fontWeight: 600 }}>View on Map</span>
                  </div>
                </div>
              </Link>
            </div>
          </div>
        </div>
      </div>
      <AddToCollectionModal
        isOpen={collectionModalOpen}
        onClose={() => setCollectionModalOpen(false)}
        itemId={venue?.id || ''}
        itemType="venue"
        itemName={venue?.name}
      />
      </>
    );
  }

  // ════════════════════════════════════════════
  //  FOODIE — rich magazine / dark warm
  // ════════════════════════════════════════════
  if (isFoodie) {
    return (
      <>
      <div className="min-h-screen" data-nav-theme="light">
        {/* Back */}
        <div className="px-4 sm:px-6 lg:px-8 pt-6 max-w-[1200px] mx-auto">
          <Link
            to="/map"
            className="inline-flex items-center gap-2 transition-opacity hover:opacity-60"
            style={{
              fontFamily: tokens.headingFont,
              fontSize: '0.75rem',
              color: tokens.textMuted,
              fontWeight: 500,
            }}
          >
            <ArrowLeft size={14} />
            Back
          </Link>
        </div>

        {/* Hero — cinematic */}
        <div className="relative h-[40vh] sm:h-[50vh] min-h-[280px] sm:min-h-[400px] overflow-hidden mt-4 mx-4 sm:mx-6 lg:mx-8" style={{ borderRadius: '20px' }}>
          <ImageWithFallback
            src={venue.image}
            alt={venue.name}
            className="h-full w-full object-cover"
            style={{ filter: 'brightness(0.85) saturate(1.2)' }}
          />
          <div className="absolute inset-0" style={{ background: `linear-gradient(to top, ${tokens.pageBg}, transparent 50%)` }} />
          <div className="absolute inset-0 pointer-events-none opacity-10" style={{ background: `radial-gradient(ellipse at 50% 80%, ${modeColor}, transparent 60%)` }} />

          <div className="absolute bottom-0 left-0 right-0 p-8">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
              <span className="px-3 py-1 text-xs" style={{ backgroundColor: `${modeColor}30`, color: modeColor, borderRadius: '16px', fontWeight: 600, backdropFilter: 'blur(8px)' }}>{venue.category}</span>
              <h1 className="mt-3" style={{ fontSize: 'clamp(1.8rem, 4vw, 3rem)', color: tokens.textPrimary, fontFamily: tokens.headingFont, fontWeight: 700, letterSpacing: '-0.02em' }}>{venue.name}</h1>
              <p style={{ fontSize: '0.85rem', color: tokens.textMuted }}>{venue.nameZh}</p>
            </motion.div>
          </div>
        </div>

        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 sm:gap-8">
            {/* Main */}
            <div className="lg:col-span-2 space-y-6 sm:space-y-8">
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
                <p style={{ lineHeight: 1.8, color: tokens.textSecondary, fontFamily: tokens.bodyFont }}>{venue.description}</p>
                <div className="flex flex-wrap gap-2 mt-4">
                  {(venue.vibeTags || []).map((tag) => (
                    <span key={tag} className="px-3 py-1 text-xs" style={{ backgroundColor: `${modeColor}12`, color: `${modeColor}aa`, borderRadius: '16px', fontWeight: 500 }}>#{tag}</span>
                  ))}
                </div>
              </motion.div>

              {venueEvents.length > 0 && (
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
                  <h2 className="mb-4 flex items-center gap-2" style={{ fontSize: '1.1rem', color: tokens.textPrimary, fontFamily: tokens.headingFont, fontWeight: 700 }}>
                    <Calendar size={18} style={{ color: modeColor }} /> Upcoming Events
                  </h2>
                  <div className="space-y-3">
                    {venueEvents.map((event) => (
                      <Link key={event.id} to={getEventLink(event)} className="flex gap-4 p-4 transition-all hover:shadow-md" style={{ borderRadius: '20px', backgroundColor: tokens.cardBg, border: `1px solid ${tokens.cardBorder}`, textDecoration: 'none' }}>
                        <div className="h-20 w-20 overflow-hidden flex-shrink-0" style={{ borderRadius: '16px' }}>
                          <ImageWithFallback src={event.image} alt={event.title} className="h-full w-full object-cover" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h3 className="text-sm truncate" style={{ color: tokens.textPrimary, fontWeight: 600 }}>{event.title}</h3>
                          <div className="flex items-center gap-2 mt-1">
                            <Clock size={12} style={{ color: tokens.textMuted }} />
                            <span className="text-xs" style={{ color: tokens.textMuted }}>{event.date} at {event.time}</span>
                          </div>
                          <div className="flex items-center gap-2 mt-2">
                            <span className="px-2 py-0.5 text-[10px]" style={{ backgroundColor: `${modeColor}15`, color: `${modeColor}aa`, borderRadius: '12px' }}>{event.price}</span>
                            {event.modeTags.map((tag) => (<span key={tag} className="inline-flex items-center"><CIcon id={tag} size={12} style={{ color: modeConfig[tag].color }} /></span>))}
                          </div>
                        </div>
                      </Link>
                    ))}
                  </div>
                </motion.div>
              )}

              {/* Past events */}
              <PastEventsSection pastEvents={pastEvents} tokens={tokens} modeColor={modeColor} showPast={showPastEvents} setShowPast={setShowPastEvents} aesthetic={tokens.aesthetic} />

              {filteredRecaps.length > 0 && (
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
                  <h2 className="mb-4 flex items-center gap-2" style={{ fontSize: '1.1rem', color: tokens.textPrimary, fontFamily: tokens.headingFont, fontWeight: 700 }}>
                    <Star size={18} style={{ color: modeColor }} /> Recaps
                  </h2>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {filteredRecaps.map((recap, i) => (
                      <Link key={recap.id} to={`/recaps/${recap.id}`} className="no-underline block">
                        <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: i * 0.08 }} className="group relative aspect-square overflow-hidden cursor-pointer" style={{ borderRadius: '16px' }}>
                          <ImageWithFallback src={recap.thumbnail} alt={recap.caption} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" style={{ filter: 'saturate(1.1) brightness(0.95)' }} />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                          <div className="absolute bottom-0 left-0 right-0 p-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                            <p className="text-xs text-white truncate">{recap.caption}</p>
                            <div className="flex items-center gap-2 mt-1">
                              <Heart size={10} className="text-white/60" />
                              <span className="text-[10px] text-white/50">{recap.engagement}</span>
                            </div>
                          </div>
                        </motion.div>
                      </Link>
                    ))}
                  </div>
                </motion.div>
              )}
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              <div className="flex gap-2">
                <button onClick={() => setCollectionModalOpen(true)} className="flex-1 flex items-center justify-center gap-2 py-3 text-sm text-white transition-all hover:opacity-90 cursor-pointer" style={{ backgroundColor: modeColor, borderRadius: '20px', fontWeight: 600 }}>
                  <Heart size={16} fill={isSaved ? '#fff' : 'none'} /> {isSaved ? 'Saved' : 'Save'}
                </button>
                <ShareMenu title={venue.name} url={window.location.href}>
                  {({ onClick, ref }) => (
                    <button ref={ref} onClick={onClick} className="px-4 py-3 transition-all cursor-pointer" style={{ backgroundColor: tokens.surfaceBg, color: tokens.textSecondary, borderRadius: '20px' }}>
                      <Share2 size={16} />
                    </button>
                  )}
                </ShareMenu>
              </div>

              <div className="p-5 space-y-3" style={{ borderRadius: '20px', backgroundColor: tokens.surfaceBg, border: `1px solid ${tokens.cardBorder}` }}>
                <h3 className="text-xs tracking-widest uppercase" style={{ color: tokens.textMuted }}>Mode Compatibility</h3>
                {(Object.entries(venue.modeScores || {}) as [Mode, number][]).map(([mode, score]) => (
                  <ModeScoreBar key={mode} mode={mode} score={score} tokens={tokens} modeColor={modeColor} active={currentMode === mode} aesthetic={tokens.aesthetic} />
                ))}
              </div>

              <div className="p-5 space-y-3" style={{ borderRadius: '20px', backgroundColor: tokens.surfaceBg, border: `1px solid ${tokens.cardBorder}` }}>
                <h3 className="text-xs tracking-widest uppercase" style={{ color: tokens.textMuted }}>Details</h3>
                <div className="space-y-2.5">
                  <div className="flex items-start gap-2.5">
                    <MapPin size={14} className="mt-0.5" style={{ color: tokens.textMuted }} />
                    <div>
                      <span className="text-sm block" style={{ color: tokens.textSecondary }}>{venue.address}</span>
                      <span className="text-xs" style={{ color: tokens.textMuted }}>{venue.district}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2.5">
                    <span className="text-sm" style={{ color: tokens.textMuted }}>💰</span>
                    <span className="text-sm" style={{ color: tokens.textSecondary }}>{'$'.repeat(venue.priceRange)} Price Range</span>
                  </div>
                </div>
              </div>

              <Link to="/map" className="block overflow-hidden transition-all" style={{ borderRadius: '20px', border: `1px solid ${tokens.cardBorder}` }}>
                <div className="h-40 flex items-center justify-center" style={{ backgroundColor: tokens.surfaceBg }}>
                  <div className="text-center">
                    <span className="block mb-1"><CIcon id={venue.category} size={24} style={{ color: modeColor }} /></span>
                    <span className="text-xs" style={{ color: tokens.textMuted }}>View on Map</span>
                  </div>
                </div>
              </Link>
            </div>
          </div>
        </div>
      </div>
      <AddToCollectionModal
        isOpen={collectionModalOpen}
        onClose={() => setCollectionModalOpen(false)}
        itemId={venue?.id || ''}
        itemType="venue"
        itemName={venue?.name}
      />
      </>
    );
  }

  // ════════════════════════════════════════════
  //  DEFAULT — Editorial Magazine (Neutral Mode)
  // ════════════════════════════════════════════

  const eBG = '#FAFAF8';
  const eLbl: React.CSSProperties = {
    fontSize: '0.6rem',
    fontWeight: 600,
    letterSpacing: '0.18em',
    textTransform: 'uppercase',
    color: '#B5B0A8',
  };

  return (
    <>
    <div className="min-h-screen" style={{ backgroundColor: eBG }} data-nav-theme="dark">
      {/* Hero image — full-width */}
      <div className="relative overflow-hidden" style={{ height: 'clamp(280px, 40vw, 480px)' }}>
        <ImageWithFallback
          src={venue.image}
          alt={venue.name}
          className="h-full w-full object-cover"
        />
        <div className="absolute inset-0" style={{ background: `linear-gradient(to top, ${eBG} 0%, ${eBG}99 25%, transparent 60%)` }} />

        {/* Back button */}
        <div className="absolute top-6 left-6 sm:left-10 lg:left-14 z-10">
          <Link
            to="/map"
            className="inline-flex items-center gap-2 px-4 py-2 text-xs transition-all hover:opacity-80"
            style={{
              backgroundColor: 'rgba(255,255,255,0.85)',
              backdropFilter: 'blur(12px)',
              color: '#1A1A1A',
              borderRadius: '10px',
              fontWeight: 500,
            }}
          >
            <ArrowLeft size={13} /> Back
          </Link>
        </div>
      </div>

      {/* Main content — rule of thirds */}
      <div className="max-w-[1440px] mx-auto px-5 sm:px-10 lg:px-14 -mt-24 relative z-10">
        {/* Title block */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '2rem' }}>
          {/* Left third — category label */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="hidden sm:flex flex-col justify-end"
          >
            <span style={eLbl}>{venue.category}</span>
            <span style={{
              fontFamily: "'Archivo Black', sans-serif",
              fontSize: '4rem',
              color: '#F0EDE8',
              lineHeight: 1,
              letterSpacing: '-0.05em',
              marginTop: '0.5rem',
            }}>
              {'$'.repeat(venue.priceRange)}
            </span>
          </motion.div>

          {/* Right two-thirds — venue name + district */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1, duration: 0.6 }}
          >
            <div className="flex items-center gap-2 mb-2">
              <CIcon id={venue.category} size={16} mode="auto" />
              <span style={{ fontSize: '0.75rem', color: '#A09B93', fontWeight: 500 }}>{venue.district}</span>
            </div>
            <h1 style={{
              fontFamily: "'Archivo Black', sans-serif",
              fontSize: 'clamp(2rem, 4.5vw, 3.5rem)',
              color: '#1A1A1A',
              letterSpacing: '-0.04em',
              lineHeight: 0.95,
            }}>
              {venue.name}
            </h1>
            <p className="mt-2" style={{
              fontFamily: "'Noto Sans HK', sans-serif",
              fontSize: '0.9rem',
              color: '#C5C0B8',
            }}>
              {venue.nameZh}
            </p>
          </motion.div>
        </div>

        <div className="h-px w-full mt-8 mb-10" style={{ backgroundColor: '#E8E4DE' }} />

        {/* Content grid — rule of thirds */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '3rem' }}>
          {/* Left column — sidebar */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.6 }}
            className="space-y-6"
          >
            {/* Actions */}
            <div className="flex gap-2">
              <button
                onClick={() => setCollectionModalOpen(true)}
                className="flex-1 flex items-center justify-center gap-2 py-3 text-sm transition-all hover:opacity-90 cursor-pointer"
                style={{
                  backgroundColor: '#1A1A1A',
                  color: '#fff',
                  borderRadius: '12px',
                  fontWeight: 600,
                }}
              >
                <Heart size={15} fill={isSaved ? '#fff' : 'none'} /> {isSaved ? 'Saved' : 'Save'}
              </button>
              <ShareMenu title={venue.name} url={window.location.href}>
                {({ onClick, ref }) => (
                  <button ref={ref} onClick={onClick}
                    className="px-4 py-3 transition-all hover:opacity-70 cursor-pointer"
                    style={{
                      border: '1px solid #E8E4DE',
                      borderRadius: '12px',
                      color: '#A09B93',
                      backgroundColor: 'transparent',
                    }}>
                    <Share2 size={15} />
                  </button>
                )}
              </ShareMenu>
            </div>

            {/* Details card */}
            <div className="p-5 space-y-4" style={{ borderRadius: '16px', border: '1px solid #F0EDE8', backgroundColor: '#fff' }}>
              <span style={eLbl}>Details</span>
              <div className="flex items-start gap-3">
                <MapPin size={13} className="mt-0.5" style={{ color: '#C5C0B8' }} />
                <div>
                  <span className="block" style={{ fontSize: '0.85rem', color: '#1A1A1A', fontWeight: 500 }}>{venue.address}</span>
                  <span className="block mt-0.5" style={{ fontSize: '0.7rem', color: '#A09B93' }}>{venue.district}</span>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <span style={{ fontSize: '0.7rem', color: '#C5C0B8' }}>💰</span>
                <span style={{ fontSize: '0.8rem', color: '#A09B93' }}>{'$'.repeat(venue.priceRange)} Price Range</span>
              </div>
            </div>

            {/* Mode Compatibility */}
            <div className="p-5 space-y-4" style={{ borderRadius: '16px', border: '1px solid #F0EDE8', backgroundColor: '#fff' }}>
              <span style={eLbl}>Mode Compatibility</span>
              {(Object.entries(venue.modeScores || {}) as [Mode, number][]).map(([mode, score]) => (
                <div key={mode} className="flex items-center gap-3" style={{ opacity: currentMode === mode ? 1 : 0.7 }}>
                  <span className="w-5 flex items-center justify-center"><CIcon id={mode} size={13} mode={mode} glow={currentMode === mode} /></span>
                  <span className="text-xs w-16" style={{ color: '#A09B93', fontWeight: 500 }}>{modeConfig[mode].label}</span>
                  <div className="flex-1 h-1 overflow-hidden" style={{ borderRadius: '2px', backgroundColor: '#F0EDE8' }}>
                    <motion.div initial={{ width: 0 }} animate={{ width: `${score * 100}%` }} transition={{ duration: 0.8, delay: 0.2 }} className="h-full" style={{ backgroundColor: modeConfig[mode].color, borderRadius: '2px' }} />
                  </div>
                  <span className="text-xs w-7 text-right" style={{ color: '#C5C0B8', fontFamily: "'Archivo Black', sans-serif", fontSize: '0.65rem' }}>{Math.round(score * 100)}</span>
                </div>
              ))}
            </div>

            {/* View on Map */}
            <Link
              to="/map"
              className="flex items-center justify-center gap-2 py-4 transition-all hover:shadow-md group"
              style={{
                borderRadius: '16px',
                border: '1px solid #F0EDE8',
                backgroundColor: '#fff',
                color: '#1A1A1A',
                fontSize: '0.8rem',
                fontWeight: 600,
              }}
            >
              <MapIcon size={15} style={{ color: '#A09B93' }} />
              View on Map
              <ArrowRight size={13} className="transition-transform group-hover:translate-x-1" style={{ color: '#C5C0B8' }} />
            </Link>
          </motion.div>

          {/* Right two-thirds — main content */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15, duration: 0.6 }}
            className="space-y-12"
          >
            {/* Description */}
            <div>
              <p style={{ fontSize: '0.95rem', color: '#6B6660', lineHeight: 1.8 }}>{venue.description}</p>

              {/* Tags */}
              <div className="flex flex-wrap gap-2 mt-5">
                {(venue.vibeTags || []).map((tag) => (
                  <span
                    key={tag}
                    className="px-3 py-1.5"
                    style={{
                      fontSize: '0.7rem',
                      color: '#A09B93',
                      border: '1px solid #E8E4DE',
                      borderRadius: '20px',
                      fontWeight: 500,
                    }}
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            </div>

            {/* Upcoming Events */}
            {venueEvents.length > 0 && (
              <div>
                <div className="h-px w-full mb-8" style={{ backgroundColor: '#E8E4DE' }} />
                <div className="flex items-end justify-between mb-6">
                  <div>
                    <span style={eLbl}>Programme</span>
                    <h2 className="mt-2" style={{ fontFamily: "'Archivo Black', sans-serif", fontSize: 'clamp(1.2rem, 2vw, 1.6rem)', color: '#1A1A1A', letterSpacing: '-0.03em', lineHeight: 1.1 }}>
                      Upcoming Events
                    </h2>
                  </div>
                  <Link to="/events" className="flex items-center gap-1.5 text-sm transition-all hover:opacity-70" style={{ color: '#A09B93', fontWeight: 500 }}>
                    All events <ArrowRight size={14} />
                  </Link>
                </div>

                <div className="space-y-3">
                  {venueEvents.map((event, i) => (
                    <motion.div
                      key={event.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.1 + i * 0.05 }}
                    >
                      <Link
                        to={getEventLink(event)}
                        className="group flex gap-4 p-4 transition-all hover:shadow-md"
                        style={{
                          borderRadius: '16px',
                          backgroundColor: '#fff',
                          border: '1px solid #F0EDE8',
                          textDecoration: 'none',
                        }}
                      >
                        <div className="h-20 w-24 overflow-hidden flex-shrink-0" style={{ borderRadius: '12px' }}>
                          <ImageWithFallback src={event.image} alt={event.title} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
                        </div>
                        <div className="flex-1 min-w-0 flex flex-col justify-center">
                          <h3 className="truncate group-hover:opacity-70 transition-opacity" style={{ fontSize: '0.9rem', color: '#1A1A1A', fontWeight: 600, letterSpacing: '-0.01em' }}>{event.title}</h3>
                          <div className="flex items-center gap-1.5 mt-1.5">
                            <Clock size={11} style={{ color: '#C5C0B8' }} />
                            <span style={{ fontSize: '0.7rem', color: '#A09B93' }}>{event.date}{event.time ? ` at ${event.time}` : ''}</span>
                          </div>
                          <div className="flex items-center gap-2 mt-2">
                            <span className="px-2 py-0.5" style={{ fontSize: '0.65rem', color: '#1A1A1A', backgroundColor: '#F5F3EF', borderRadius: '6px', fontWeight: 600 }}>{event.price}</span>
                            {event.modeTags.map((tag) => (<span key={tag} className="inline-flex items-center"><CIcon id={tag} size={12} style={{ color: modeConfig[tag].color }} /></span>))}
                          </div>
                        </div>
                      </Link>
                    </motion.div>
                  ))}
                </div>
              </div>
            )}

            {/* Past events */}
            {pastEvents.length > 0 && (
              <div>
                <div className="h-px w-full mb-8" style={{ backgroundColor: '#E8E4DE' }} />
                <PastEventsSection pastEvents={pastEvents} tokens={tokens} modeColor={modeColor} showPast={showPastEvents} setShowPast={setShowPastEvents} aesthetic={tokens.aesthetic} />
              </div>
            )}

            {/* Recaps / Gallery */}
            {filteredRecaps.length > 0 && (
              <div>
                <div className="h-px w-full mb-8" style={{ backgroundColor: '#E8E4DE' }} />
                <div className="mb-6">
                  <span style={eLbl}>Gallery</span>
                  <h2 className="mt-2" style={{ fontFamily: "'Archivo Black', sans-serif", fontSize: 'clamp(1.2rem, 2vw, 1.6rem)', color: '#1A1A1A', letterSpacing: '-0.03em', lineHeight: 1.1 }}>
                    Past Recaps
                  </h2>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {filteredRecaps.map((recap, i) => (
                    <Link key={recap.id} to={`/recaps/${recap.id}`} className="no-underline block">
                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: i * 0.06 }}
                        className="group relative aspect-square overflow-hidden cursor-pointer"
                        style={{ borderRadius: '16px' }}
                      >
                        <ImageWithFallback src={recap.thumbnail} alt={recap.caption} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
                        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300" />
                        <div className="absolute bottom-0 left-0 right-0 p-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300" style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.5), transparent)' }}>
                          <p className="text-xs text-white truncate" style={{ fontWeight: 500 }}>{recap.caption}</p>
                          <div className="flex items-center gap-2 mt-1">
                            <Heart size={10} className="text-white/60" />
                            <span className="text-[10px] text-white/50">{recap.engagement}</span>
                          </div>
                        </div>
                      </motion.div>
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </motion.div>
        </div>

        {/* Footer watermark */}
        <div className="flex items-center justify-between py-12 mt-12" style={{ borderTop: '1px solid #E8E4DE' }}>
          <span style={{
            fontFamily: "'Archivo Black', sans-serif",
            fontSize: '0.6rem',
            color: 'rgba(26,26,26,0.06)',
            letterSpacing: '-0.03em',
          }}>
            CULTIVE
          </span>
          <span style={{ fontSize: '0.6rem', color: '#C5C0B8' }}>文化活</span>
        </div>
      </div>
    </div>
    <AddToCollectionModal
      isOpen={collectionModalOpen}
      onClose={() => setCollectionModalOpen(false)}
      itemId={venue?.id || ''}
      itemType="venue"
      itemName={venue?.name}
    />
    </>
  );
}
