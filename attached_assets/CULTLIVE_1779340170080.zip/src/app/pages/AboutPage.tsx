import { useState, useRef } from 'react';
import { motion, AnimatePresence, useScroll, useTransform } from 'motion/react';
import { useTranslation } from 'react-i18next';
import { Link } from 'react-router';
import { ChevronDown, Plus, Handshake, Pen, Mail, MapPin, ArrowUpRight, ArrowRight } from 'lucide-react';
import { useMode } from '../context/ModeContext';
import type { Mode } from '../context/ModeContext';
import { modeConfig } from '../data/mock-data';
import { getDesignTokens, isLightMode } from '../data/mode-styles';
import { useNeutralTheme } from '../context/NeutralThemeContext';
import { CIcon } from '../components/CIcon';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import { useSiteImages } from '../hooks/useSiteImages';
import { useTemplateData } from '../hooks/useTemplateData';

/** Parse *asterisk* markers into <em> elements */
function renderEmphasis(text: string): React.ReactNode {
  const parts = text.split(/\*([^*]+)\*/g);
  if (parts.length === 1) return text;
  return parts.map((part, i) =>
    i % 2 === 1 ? <em key={i} style={{ fontStyle: 'italic' }}>{part}</em> : part
  );
}

/* ── Animated counter ── */
function AnimatedStat({ value, label, color, font }: { value: string; label: string; color: string; font: string }) {
  const num = parseInt(value);
  const suffix = value.replace(/[0-9]/g, '');
  return (
    <motion.div initial={{ opacity: 0, y: 12 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
      <motion.span
        className="block tabular-nums"
        style={{ fontFamily: font, fontSize: 'clamp(1.8rem, 3.5vw, 3rem)', color, fontWeight: 300, lineHeight: 1, letterSpacing: '-0.03em' }}
        initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }}
      >
        {isNaN(num) ? value : <Counter target={num} />}{suffix}
      </motion.span>
      <span className="block mt-1 text-[0.7rem] tracking-wider" style={{ color: 'inherit', opacity: 0.5 }}>{label}</span>
    </motion.div>
  );
}

function Counter({ target }: { target: number }) {
  const [count, setCount] = useState(0);
  const hasAnimated = useRef(false);
  return (
    <motion.span
      onViewportEnter={() => {
        if (hasAnimated.current) return;
        hasAnimated.current = true;
        const duration = 1200;
        const start = performance.now();
        const step = (now: number) => {
          const progress = Math.min((now - start) / duration, 1);
          const eased = 1 - Math.pow(1 - progress, 3);
          setCount(Math.round(eased * target));
          if (progress < 1) requestAnimationFrame(step);
        };
        requestAnimationFrame(step);
      }}
    >
      {count}
    </motion.span>
  );
}

/* ── Accordion item ── */
function AccordionItem({
  isOpen, onToggle, title, subtitle, children, icon, dotColor, dividerColor, headingFont, textPrimary, textMuted,
}: {
  isOpen: boolean; onToggle: () => void; title: string; subtitle?: string;
  children: React.ReactNode; icon?: React.ReactNode; dotColor?: string;
  dividerColor: string; headingFont: string; textPrimary: string; textMuted: string;
}) {
  return (
    <div style={{ borderTop: `1px solid ${dividerColor}` }}>
      <button onClick={onToggle} className="w-full flex items-center gap-3 sm:gap-5 py-4 sm:py-5 text-left cursor-pointer group">
        {icon && <span className="flex-shrink-0">{icon}</span>}
        <div className="flex-1 min-w-0 flex items-center gap-3">
          <h3 style={{ fontFamily: headingFont, fontSize: '1rem', color: textPrimary, fontWeight: 500 }}>{title}</h3>
          {subtitle && <span className="hidden sm:inline" style={{ fontSize: '0.7rem', color: textMuted }}>{subtitle}</span>}
        </div>
        {dotColor && <div className="hidden sm:block h-2 w-2 rounded-full flex-shrink-0" style={{ backgroundColor: dotColor }} />}
        <motion.span animate={{ rotate: isOpen ? 180 : 0 }} transition={{ duration: 0.3 }} className="flex-shrink-0" style={{ color: textMuted }}>
          <ChevronDown size={16} />
        </motion.span>
      </button>
      <AnimatePresence initial={false}>
        {isOpen && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }} className="overflow-hidden">
            <div className="pb-5 sm:pb-6 pl-0 sm:pl-10">{children}</div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export function AboutPage() {
  const { currentMode } = useMode();
  const { t } = useTranslation();
  const { img: siteImg, focal: siteFocal } = useSiteImages();
  const tpl = useTemplateData('about');

  // Helper: CMS value → i18n fallback
  const cms = (sectionId: string, key: string, i18nKey?: string): string => {
    const val = tpl[sectionId]?.[key];
    if (val && typeof val === 'string' && val.length > 0) return val;
    if (i18nKey) return t(i18nKey);
    return val ?? '';
  };

  const safeMode = currentMode && currentMode !== 'lifestyle' ? currentMode : null;
  const modeColor = safeMode ? modeConfig[safeMode].color : currentMode === 'lifestyle' ? '#2D6A4F' : '#1a1a1a';
  const tokens = getDesignTokens(currentMode);
  const light = isLightMode(currentMode);

  // Editorial neutral mode detection
  const isNeutral = !currentMode || currentMode === 'lifestyle';

  const headingFont = isNeutral ? "'Archivo Black', sans-serif" : tokens.headingFont;
  const bodyFont = isNeutral ? "'Inter', sans-serif" : tokens.bodyFont;
  const textPrimary = isNeutral ? '#1A1A1A' : tokens.textPrimary;
  const textSecondary = isNeutral ? '#A09B93' : tokens.textSecondary;
  const textMuted = isNeutral ? '#B5B0A8' : tokens.textMuted;
  const dividerColor = isNeutral ? '#E8E4DE' : light ? 'rgba(0,0,0,0.08)' : 'rgba(255,255,255,0.08)';
  const surfaceSubtle = isNeutral ? '#F5F3EF' : light ? 'rgba(0,0,0,0.025)' : 'rgba(255,255,255,0.025)';
  const pageBg = isNeutral ? '#FAFAF8' : undefined;

  const [openLens, setOpenLens] = useState<number | null>(null);
  const [openStep, setOpenStep] = useState<number | null>(null);
  const [involvedTab, setInvolvedTab] = useState<'collab' | 'submit' | null>(null);

  const quoteRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: quoteRef, offset: ['start end', 'end start'] });
  const imgY = useTransform(scrollYProgress, [0, 1], ['0%', '20%']);
  const textOpacity = useTransform(scrollYProgress, [0.15, 0.4, 0.6, 0.85], [0, 1, 1, 0]);
  const textY = useTransform(scrollYProgress, [0.15, 0.4], [30, 0]);

  const lensTaglines: Record<string, string> = {
    degen: cms('five-lenses', 'nightTagline', 'about.nightTagline'),
    family: cms('five-lenses', 'familyTagline', 'about.familyTagline'),
    artsy: cms('five-lenses', 'artTagline', 'about.artTagline'),
    foodie: cms('five-lenses', 'foodTagline', 'about.foodTagline'),
    lifestyle: cms('five-lenses', 'lifestyleTagline', 'about.lifestyleTagline'),
  };

  const allLenses: { key: string; label: string; labelZh: string; tagline: string; color: string }[] = [
    { key: 'degen', label: modeConfig.degen.label, labelZh: modeConfig.degen.labelZh, tagline: lensTaglines.degen, color: modeConfig.degen.color },
    { key: 'family', label: modeConfig.family.label, labelZh: modeConfig.family.labelZh, tagline: lensTaglines.family, color: modeConfig.family.color },
    { key: 'artsy', label: modeConfig.artsy.label, labelZh: modeConfig.artsy.labelZh, tagline: lensTaglines.artsy, color: modeConfig.artsy.color },
    { key: 'foodie', label: modeConfig.foodie.label, labelZh: modeConfig.foodie.labelZh, tagline: lensTaglines.foodie, color: modeConfig.foodie.color },
    { key: 'lifestyle', label: 'Lifestyle', labelZh: '生活方式', tagline: lensTaglines.lifestyle, color: '#2D6A4F' },
  ];

  const steps = [
    { num: '01', title: cms('how-it-works', 'step01Title', 'about.step01'), body: cms('how-it-works', 'step01Body', 'about.step01Body') },
    { num: '02', title: cms('how-it-works', 'step02Title', 'about.step02'), body: cms('how-it-works', 'step02Body', 'about.step02Body') },
    { num: '03', title: cms('how-it-works', 'step03Title', 'about.step03'), body: cms('how-it-works', 'step03Body', 'about.step03Body') },
    { num: '04', title: cms('how-it-works', 'step04Title', 'about.step04'), body: cms('how-it-works', 'step04Body', 'about.step04Body') },
  ];

  const eLabelStyle: React.CSSProperties = {
    fontSize: '0.6rem',
    fontWeight: 600,
    letterSpacing: '0.18em',
    textTransform: 'uppercase',
    color: textMuted,
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: pageBg }} data-nav-theme={light || isNeutral ? 'dark' : 'light'}>
      {/* HERO */}
      <section className="relative overflow-hidden" style={{ height: 'clamp(280px, 50vh, 500px)' }}>
        <ImageWithFallback src={siteImg('about-hero')} alt="Hong Kong cityscape" className="absolute inset-0 h-full w-full object-cover" style={{ filter: 'brightness(0.4)' }} />
        <div className="absolute inset-0 flex flex-col justify-end p-5 sm:p-10 lg:p-16">
          <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }} className="max-w-[800px]">
            <span className="block mb-2 tracking-[0.3em] uppercase" style={{ fontSize: '0.55rem', color: 'rgba(255,255,255,0.45)', fontFamily: bodyFont }}>
              {cms('hero', 'subtitle', 'about.subtitle')}
            </span>
            <h1 style={{ fontFamily: headingFont, fontSize: 'clamp(1.8rem, 5vw, 3.8rem)', color: '#fff', fontWeight: 400, lineHeight: 1.05, letterSpacing: '-0.02em' }}>
              {renderEmphasis(cms('hero', 'heroTitle', 'about.heroTitle'))}
            </h1>
          </motion.div>
        </div>
      </section>

      {/* MANIFESTO + STATS — editorial rule-of-thirds for neutral */}
      <section className="px-5 sm:px-10 lg:px-14 py-10 sm:py-16 max-w-[1440px] mx-auto">
        {isNeutral && <div className="h-px w-full mb-10" style={{ backgroundColor: dividerColor }} />}
        <div className={isNeutral ? "grid grid-cols-1 md:grid-cols-[1fr_2fr] gap-6 md:gap-8" : "grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-12"}>
          <motion.div className={isNeutral ? "" : "lg:col-span-7"} initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }}>
            {isNeutral && <span style={eLabelStyle} className="block mb-4">About</span>}
            <h2 className="mb-4 sm:mb-6" style={{ fontFamily: headingFont, fontSize: 'clamp(1.2rem, 3vw, 2.2rem)', color: textPrimary, fontWeight: 400, lineHeight: 1.2 }}>
              {renderEmphasis(cms('manifesto', 'manifesto', 'about.manifesto'))}
            </h2>
            <p style={{ fontFamily: bodyFont, fontSize: '0.9rem', color: textSecondary, lineHeight: 1.8, maxWidth: '580px' }}>
              {cms('manifesto', 'manifestoBody', 'about.manifestoBody')}
            </p>
          </motion.div>

          <motion.div className={isNeutral ? "grid grid-cols-2 gap-x-6 gap-y-5 content-start md:border-l md:pl-8" : "lg:col-span-5 grid grid-cols-2 gap-x-6 gap-y-5 sm:gap-y-6 content-start lg:pl-8"} initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} transition={{ delay: 0.15 }} style={isNeutral ? { borderColor: dividerColor } : { borderLeft: `1px solid ${dividerColor}` }}>
            {!isNeutral && <div className="col-span-2 hidden lg:block" />}
            {tpl.manifesto?.showStats !== false && [
              { value: cms('manifesto', 'stat1Value') || '25+', label: cms('manifesto', 'stat1Label', 'about.statVenues') },
              { value: cms('manifesto', 'stat2Value') || '40+', label: cms('manifesto', 'stat2Label', 'about.statEvents') },
              { value: cms('manifesto', 'stat3Value') || '9', label: cms('manifesto', 'stat3Label', 'about.statDistricts') },
              { value: cms('manifesto', 'stat4Value') || '5', label: cms('manifesto', 'stat4Label', 'about.statModes') },
            ].map((s) => (
              <AnimatedStat key={s.label} value={s.value} label={s.label} color={modeColor === '#1a1a1a' ? textPrimary : modeColor} font={headingFont} />
            ))}
          </motion.div>
        </div>
      </section>

      <div className="mx-5 sm:mx-10 lg:mx-14 max-w-[1440px] xl:mx-auto" style={{ borderTop: `1px solid ${dividerColor}` }} />

      {/* FIVE LENSES — editorial rule-of-thirds for neutral */}
      <section className="px-5 sm:px-10 lg:px-14 py-8 sm:py-14 max-w-[1440px] mx-auto">
        <div className={isNeutral ? "grid grid-cols-1 md:grid-cols-[1fr_2fr] gap-4 md:gap-8" : "grid grid-cols-1 lg:grid-cols-12 gap-4 sm:gap-12"}>
          <div className={isNeutral ? "" : "lg:col-span-3"}>
            <span className="tracking-[0.3em] uppercase" style={{ fontSize: '0.55rem', color: textMuted, fontFamily: bodyFont }}>{cms('five-lenses', 'sectionLabel', 'about.fiveLenses')}</span>
            <h2 className="mt-2 mb-4 lg:mb-0" style={{ fontFamily: headingFont, fontSize: 'clamp(1rem, 2vw, 1.4rem)', color: textPrimary, fontWeight: 400, lineHeight: 1.25 }}>
              {cms('five-lenses', 'sectionTitle', 'about.fiveLensesTitle')}
            </h2>
          </div>
          <div className={isNeutral ? "" : "lg:col-span-9"}>
            {allLenses.map((lens, i) => (
              <AccordionItem
                key={lens.key} isOpen={openLens === i} onToggle={() => setOpenLens(openLens === i ? null : i)}
                title={lens.label} subtitle={lens.labelZh}
                icon={<CIcon id={lens.key} size={22} mode={lens.key as Mode} />}
                dotColor={lens.color} dividerColor={dividerColor} headingFont={headingFont} textPrimary={textPrimary} textMuted={textMuted}
              >
                <p style={{ fontFamily: bodyFont, fontSize: '0.9rem', color: textSecondary, lineHeight: 1.75, maxWidth: '480px' }}>{lens.tagline}</p>
              </AccordionItem>
            ))}
            <div style={{ borderTop: `1px solid ${dividerColor}` }} />
          </div>
        </div>
      </section>

      {/* PARALLAX QUOTE */}
      <section ref={quoteRef} className="relative overflow-hidden" style={{ height: 'clamp(180px, 30vh, 320px)' }}>
        <motion.div className="absolute inset-0" style={{ y: imgY }}>
          <ImageWithFallback src={siteImg('about-mid')} alt="Hong Kong street culture" className="absolute inset-0 h-[130%] w-full object-cover" style={{ objectPosition: siteFocal('about-mid', 'center 75%'), filter: light ? 'contrast(1.05)' : 'brightness(0.55) contrast(1.1)' }} />
        </motion.div>
        <div className="absolute inset-0 flex items-center justify-center">
          <motion.p className="text-center px-6" style={{ fontFamily: headingFont, fontSize: 'clamp(1rem, 2.5vw, 2rem)', color: '#fff', fontWeight: 400, fontStyle: 'italic', lineHeight: 1.25, textShadow: '0 2px 24px rgba(0,0,0,0.4)', opacity: textOpacity, y: textY }}>
            {cms('quote', 'quoteText', 'about.quoteText')}
          </motion.p>
        </div>
      </section>

      {/* HOW IT WORKS — editorial rule-of-thirds for neutral */}
      <section className="px-5 sm:px-10 lg:px-14 py-8 sm:py-14 max-w-[1440px] mx-auto">
        <div className={isNeutral ? "grid grid-cols-1 md:grid-cols-[1fr_2fr] gap-4 md:gap-8" : "grid grid-cols-1 lg:grid-cols-12 gap-4 sm:gap-12"}>
          <div className={isNeutral ? "" : "lg:col-span-3"}>
            <span className="tracking-[0.3em] uppercase" style={{ fontSize: '0.55rem', color: textMuted, fontFamily: bodyFont }}>{cms('how-it-works', 'sectionLabel', 'about.howItWorks')}</span>
          </div>
          <div className={isNeutral ? "" : "lg:col-span-9"}>
            {steps.map((step, i) => (
              <div key={step.num} style={{ borderTop: `1px solid ${dividerColor}` }}>
                <button onClick={() => setOpenStep(openStep === i ? null : i)} className="w-full flex items-center gap-4 py-4 sm:py-5 text-left cursor-pointer group">
                  <span className="flex-shrink-0 w-8 text-right" style={{ fontFamily: headingFont, fontSize: '1.5rem', color: modeColor === '#1a1a1a' ? 'rgba(0,0,0,0.1)' : `${modeColor}30`, fontWeight: 300, lineHeight: 1 }}>{step.num}</span>
                  <h3 className="flex-1" style={{ fontFamily: headingFont, fontSize: '0.95rem', color: textPrimary, fontWeight: 500 }}>{step.title}</h3>
                  <motion.span animate={{ rotate: openStep === i ? 45 : 0 }} transition={{ duration: 0.25 }} style={{ color: textMuted }}><Plus size={15} /></motion.span>
                </button>
                <AnimatePresence initial={false}>
                  {openStep === i && (
                    <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }} className="overflow-hidden">
                      <p className="pb-5 pl-12 max-w-lg" style={{ fontFamily: bodyFont, fontSize: '0.88rem', color: textSecondary, lineHeight: 1.75 }}>{step.body}</p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ))}
            <div style={{ borderTop: `1px solid ${dividerColor}` }} />
          </div>
        </div>
      </section>

      <div className="mx-5 sm:mx-10 lg:mx-14 max-w-[1440px] xl:mx-auto" style={{ borderTop: `1px solid ${dividerColor}` }} />

      {/* GET INVOLVED — editorial rule-of-thirds for neutral */}
      <section id="collaboration" className="px-5 sm:px-10 lg:px-14 py-10 sm:py-16 max-w-[1440px] mx-auto">
        <div className={isNeutral ? "grid grid-cols-1 md:grid-cols-[1fr_2fr] gap-6 md:gap-8" : "grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-12"}>
          <motion.div className={isNeutral ? "" : "lg:col-span-5"} initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
            <span className="tracking-[0.3em] uppercase block mb-2" style={{ fontSize: '0.55rem', color: textMuted, fontFamily: bodyFont }}>{cms('get-involved', 'sectionLabel', 'about.getInvolved')}</span>
            <h2 className="mb-4" style={{ fontFamily: headingFont, fontSize: 'clamp(1.2rem, 2.5vw, 1.8rem)', color: textPrimary, fontWeight: 400, lineHeight: 1.2 }}>
              {renderEmphasis(cms('get-involved', 'sectionTitle', 'about.getInvolvedTitle'))}
            </h2>
            <div className="overflow-hidden aspect-[16/9] mt-4" style={{ borderRadius: '4px' }}>
              <ImageWithFallback src={siteImg('about-collab')} alt="Creative collaboration" className="h-full w-full object-cover" style={{ objectPosition: siteFocal('about-collab', 'center 65%'), filter: light ? 'contrast(1.05)' : 'brightness(0.7) contrast(1.1)' }} />
            </div>
          </motion.div>

          <div className={isNeutral ? "flex flex-col gap-3 sm:gap-4" : "lg:col-span-7 flex flex-col gap-3 sm:gap-4 lg:pt-6"}>
            {/* Collaboration card */}
            <motion.div initial={{ opacity: 0, y: 12 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="rounded-sm overflow-hidden" style={{ border: `1px solid ${dividerColor}`, backgroundColor: surfaceSubtle }}>
              <button onClick={() => setInvolvedTab(involvedTab === 'collab' ? null : 'collab')} className="w-full flex items-center gap-3 p-4 sm:p-5 text-left cursor-pointer">
                <Handshake size={18} style={{ color: modeColor === '#1a1a1a' ? textSecondary : modeColor }} className="flex-shrink-0" />
                <div className="flex-1">
                  <h3 style={{ fontFamily: headingFont, fontSize: '0.95rem', color: textPrimary, fontWeight: 500 }}>{cms('get-involved', 'collabTitle', 'about.collaboration')}</h3>
                  <p className="mt-0.5" style={{ fontSize: '0.8rem', color: textMuted }}>{cms('get-involved', 'collabDesc', 'about.collaborationDesc')}</p>
                </div>
                <motion.span animate={{ rotate: involvedTab === 'collab' ? 180 : 0 }} transition={{ duration: 0.25 }} style={{ color: textMuted }}><ChevronDown size={16} /></motion.span>
              </button>
              <AnimatePresence initial={false}>
                {involvedTab === 'collab' && (
                  <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }} className="overflow-hidden">
                    <div className="px-4 sm:px-5 pb-5 pt-1" style={{ borderTop: `1px solid ${dividerColor}` }}>
                      <p className="mb-4" style={{ fontFamily: bodyFont, fontSize: '0.88rem', color: textSecondary, lineHeight: 1.75 }}>{cms('get-involved', 'collabBody', 'about.collaborationBody')}</p>
                      <a href={`mailto:${cms('get-involved', 'collabEmail') || 'info@cultive.city'}`} className="inline-flex items-center gap-2 group" style={{ fontFamily: headingFont, fontSize: '0.82rem', color: modeColor === '#1a1a1a' ? textPrimary : modeColor, fontWeight: 500 }}>
                        <span>{cms('get-involved', 'collabEmail') || 'info@cultive.city'}</span>
                        <ArrowUpRight size={13} className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                      </a>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>

            {/* Submit a Story card */}
            <motion.div id="submit-story" initial={{ opacity: 0, y: 12 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.06 }} className="rounded-sm overflow-hidden" style={{ border: `1px solid ${dividerColor}`, backgroundColor: surfaceSubtle }}>
              <button onClick={() => setInvolvedTab(involvedTab === 'submit' ? null : 'submit')} className="w-full flex items-center gap-3 p-4 sm:p-5 text-left cursor-pointer">
                <Pen size={18} style={{ color: modeColor === '#1a1a1a' ? textSecondary : modeColor }} className="flex-shrink-0" />
                <div className="flex-1">
                  <h3 style={{ fontFamily: headingFont, fontSize: '0.95rem', color: textPrimary, fontWeight: 500 }}>{cms('get-involved', 'submitTitle', 'about.submitStory')}</h3>
                  <p className="mt-0.5" style={{ fontSize: '0.8rem', color: textMuted }}>{cms('get-involved', 'submitDesc', 'about.submitStoryDesc')}</p>
                </div>
                <motion.span animate={{ rotate: involvedTab === 'submit' ? 180 : 0 }} transition={{ duration: 0.25 }} style={{ color: textMuted }}><ChevronDown size={16} /></motion.span>
              </button>
              <AnimatePresence initial={false}>
                {involvedTab === 'submit' && (
                  <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }} className="overflow-hidden">
                    <div className="px-4 sm:px-5 pb-5 pt-1" style={{ borderTop: `1px solid ${dividerColor}` }}>
                      <p className="mb-4" style={{ fontFamily: bodyFont, fontSize: '0.88rem', color: textSecondary, lineHeight: 1.75 }}>{cms('get-involved', 'submitBody', 'about.submitStoryBody')}</p>
                      <div className="grid grid-cols-3 gap-2 mb-4">
                        {[
                          { icon: MapPin, label: t('about.venuesLabel') },
                          { icon: Pen, label: t('about.eventsLabel') },
                          { icon: Mail, label: t('about.storiesLabel') },
                        ].map((item) => (
                          <div key={item.label} className="flex items-center gap-2 px-3 py-2.5" style={{ backgroundColor: light ? 'rgba(0,0,0,0.03)' : 'rgba(255,255,255,0.04)', borderRadius: '4px' }}>
                            <item.icon size={14} style={{ color: textMuted }} />
                            <span style={{ fontSize: '0.8rem', color: textSecondary }}>{item.label}</span>
                          </div>
                        ))}
                      </div>
                      <a href="mailto:info@cultive.city" className="inline-flex items-center gap-2 group" style={{ fontFamily: headingFont, fontSize: '0.82rem', color: modeColor === '#1a1a1a' ? textPrimary : modeColor, fontWeight: 500 }}>
                        <span>info@cultive.city</span>
                        <ArrowUpRight size={13} className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                      </a>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="px-5 sm:px-10 lg:px-16 py-12 sm:py-20 max-w-[800px] mx-auto text-center" style={{ borderTop: `1px solid ${dividerColor}` }}>
        <motion.div initial={{ opacity: 0, y: 14 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
          <h2 className="mb-3 sm:mb-4" style={{ fontFamily: headingFont, fontSize: 'clamp(1.2rem, 3vw, 2rem)', color: textPrimary, fontWeight: 400, fontStyle: 'italic' }}>
            {cms('cta', 'headline', 'about.readyToExplore')}
          </h2>
          <p className="mb-6 sm:mb-8 max-w-md mx-auto" style={{ fontFamily: bodyFont, fontSize: '0.88rem', color: textMuted, lineHeight: 1.7 }}>
            {cms('cta', 'description', 'about.readyToExploreDesc')}
          </p>
          <div className="flex justify-center gap-6 sm:gap-8">
            <Link to="/map" className="inline-flex items-center gap-2 group" style={{ fontFamily: headingFont, fontSize: '0.78rem', color: textPrimary, letterSpacing: '0.1em', borderBottom: `1px solid ${textPrimary}`, paddingBottom: '3px' }}>
              <span className="uppercase">{cms('cta', 'ctaPrimaryLabel', 'about.openMap')}</span>
              <ArrowRight size={13} className="transition-transform group-hover:translate-x-1" />
            </Link>
            <Link to="/events" className="inline-flex items-center gap-2 group" style={{ fontFamily: headingFont, fontSize: '0.78rem', color: textMuted, letterSpacing: '0.1em', paddingBottom: '3px' }}>
              <span className="uppercase">{cms('cta', 'ctaSecondaryLabel', 'about.ctaEvents')}</span>
              <ArrowRight size={13} className="transition-transform group-hover:translate-x-1" />
            </Link>
          </div>
        </motion.div>
      </section>
    </div>
  );
}