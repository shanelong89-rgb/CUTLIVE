import { useState, useMemo, useRef, useEffect } from 'react';
import { motion, AnimatePresence, useInView } from 'motion/react';
import {
  Heart, MapPin, Clock, ArrowRight, Calendar, Users, Sun,
  Mountain, Coffee, Leaf, BookOpen, Sparkles, Play,
  ChevronRight, ChevronLeft, X, ExternalLink, Share2, ArrowUpRight,
} from 'lucide-react';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import {
  LC, LF, lifestyleCategories,
  formatLifestyleDate, culturalEventToLifestyle, type LifestyleCategory, type LifestyleEvent,
} from '../data/lifestyle-data';
import { useData } from '../context/DataContext';
import { useTranslation } from 'react-i18next';
import { LifestylePageSkeleton } from '../components/LoadingSkeleton';
import { ShareMenu } from '../components/ShareMenu';
import { useSiteImages } from '../hooks/useSiteImages';
import { Link } from 'react-router';

// Alias shared tokens to local names used throughout this component
const C = {
  ...LC,
  blackSoft: '#1A1A1A',
  dark: '#111111',
  darkCard: '#1C1C1C',
  warmGray: '#E8E4DE',
  textLight: '#B0ACA7',
  forestLight: '#40916C',
  sage: '#95D5B2',
  accentMuted: '#40916C',
  warmOrange: '#E8744F',
  terracotta: '#C4653A',
};

const F = {
  heading: LF.heading,
  body: LF.body,
  mono: LF.mono,
};

// Category icon mapping (icons don't belong in the shared data file)
const categoryIcons: Record<string, typeof Heart> = {
  'all': Sparkles, 'run-clubs': Users, 'wellness': Leaf, 'hikes': Mountain,
  'coffee-raves': Coffee, 'workshops': BookOpen, 'meetups': Heart,
};

// Merge shared categories with local icon assignments
const categories = lifestyleCategories.map(cat => ({
  ...cat,
  icon: categoryIcons[cat.key] || Sparkles,
}));

// Use shared date formatter
const formatDate = formatLifestyleDate;

function getDifficultyColor(d?: string) {
  switch (d) {
    case 'easy': return C.sage;
    case 'moderate': return C.warmOrange;
    case 'challenging': return C.terracotta;
    default: return C.textMuted;
  }
}

// ─── Animated heading component ───
function BoldHeading({ children, className = '', delay = 0, style = {} }: { children: React.ReactNode; className?: string; delay?: number; style?: React.CSSProperties }) {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: '-50px' });
  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 40 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.7, delay, ease: [0.22, 1, 0.36, 1] }}
      className={className}
      style={style}
    >
      {children}
    </motion.div>
  );
}

// ══════════════════════════════════════════════
// MAIN COMPONENT
// ═══════════════════════════════════════════════
export function LifestylePage() {
  const { events, loading } = useData();
  const { t } = useTranslation();
  const { img: siteImg } = useSiteImages();

  // Show skeleton during initial load
  if (loading && events.length === 0) {
    return <LifestylePageSkeleton />;
  }

  // Filter main events tagged with 'lifestyle' modeTag
  const mergedLifestyleEvents = useMemo(() => {
    return events
      .filter(e => e.modeTags?.includes('lifestyle'))
      .map(culturalEventToLifestyle);
  }, [events]);

  const [activeCategory, setActiveCategory] = useState<LifestyleCategory>('all');
  const [selectedEvent, setSelectedEvent] = useState<LifestyleEvent | null>(null);
  const [heroSlide, setHeroSlide] = useState(0);
  const [visibleCount, setVisibleCount] = useState(9);
  const featuredEvents = mergedLifestyleEvents.filter((e) => e.featured);
  // If no events are explicitly featured, use the first few as hero slides
  const heroEvents = featuredEvents.length > 0 ? featuredEvents : mergedLifestyleEvents.slice(0, 3);

  const filteredEvents = useMemo(() => {
    if (activeCategory === 'all') return mergedLifestyleEvents;
    return mergedLifestyleEvents.filter((e) => e.category === activeCategory);
  }, [activeCategory, mergedLifestyleEvents]);

  const paginatedEvents = filteredEvents.slice(0, visibleCount);

  // Reset visible count when category changes
  useEffect(() => {
    setVisibleCount(9);
  }, [activeCategory]);

  const nextSlide = () => setHeroSlide((p) => (p + 1) % (heroEvents.length || 1));
  const prevSlide = () => setHeroSlide((p) => (p - 1 + (heroEvents.length || 1)) % (heroEvents.length || 1));

  // Guard: if no events at all, show empty state
  if (mergedLifestyleEvents.length === 0) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center" style={{ backgroundColor: C.offWhite }}>
        <Leaf size={48} style={{ color: C.forest, opacity: 0.4, marginBottom: 16 }} />
        <h2 style={{ fontFamily: F.heading, fontWeight: 900, fontSize: '1.5rem', color: C.black, letterSpacing: '-0.02em' }}>
          {t('lifestyle.noEventsYet')}
        </h2>
        <p className="text-sm mt-2 max-w-sm text-center" style={{ color: C.textMuted, fontFamily: F.body, lineHeight: 1.7 }}>
          {t('lifestyle.noEventsYetDesc')}
        </p>
      </div>
    );
  }

  return (
    <div className="min-h-screen relative" style={{ backgroundColor: C.offWhite }}>
      {/* Paper texture overlay — real Unsplash texture */}
      <div
        className="fixed inset-0 pointer-events-none z-0"
        style={{
          backgroundImage: `url("${siteImg('lifestyle-texture') || 'https://images.unsplash.com/photo-1706271952285-01b5e3fc2d78?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aW50YWdlJTIwcGFwZXIlMjB0ZXh0dXJlJTIwY3JlYW0lMjBwYXJjaG1lbnR8ZW58MXx8fHwxNzczMDQ4NjI3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'}")`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          opacity: 0.06,
          mixBlendMode: 'multiply',
        }}
      />
      <div className="relative z-[1]">

      {/* ═══════════ HERO ═══════════ */}
      <section className="relative" style={{ backgroundColor: C.offWhite }}>
        <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 pt-6 sm:pt-12 pb-6 sm:pb-16">

          {/* Hero Carousel */}
          <div className="relative overflow-hidden" style={{ borderRadius: '24px' }}>
            <AnimatePresence mode="wait">
              <motion.div
                key={heroSlide}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.5 }}
                className="relative aspect-[4/3] sm:aspect-[21/9]"
              >
                <ImageWithFallback
                  src={heroEvents[heroSlide].image}
                  alt={heroEvents[heroSlide].title}
                  className="absolute inset-0 w-full h-full object-cover"
                />
                <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.7) 0%, rgba(0,0,0,0.1) 40%, transparent 100%)' }} />

                {/* Hero overlay text */}
                <div className="absolute inset-0 flex flex-col justify-center items-center text-center px-6">
                  <motion.h1
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.15, duration: 0.6 }}
                    style={{
                      fontFamily: F.heading,
                      fontWeight: 900,
                      fontSize: 'clamp(2.5rem, 8vw, 6rem)',
                      color: C.white,
                      lineHeight: 0.95,
                      letterSpacing: '-0.02em',
                    }}
                  >
                    move<span style={{ color: C.accent }}>well</span>.
                  </motion.h1>
                  <motion.p
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.35, duration: 0.5 }}
                    className="mt-3 sm:mt-4 text-xs sm:text-sm max-w-md"
                    style={{ color: 'rgba(255,255,255,0.7)', fontFamily: F.body, fontWeight: 400, letterSpacing: '0.02em' }}
                  >
                    Unleash Your Potential and Transform Your Body to Revitalize Your Health
                  </motion.p>
                </div>

                {/* Bottom info bar */}
                <div className="absolute bottom-0 left-0 right-0 px-4 sm:px-8 pb-4 sm:pb-6">
                  <div
                    className="flex items-center justify-between px-4 sm:px-6 py-3 sm:py-4 backdrop-blur-xl"
                    style={{ backgroundColor: 'rgba(255,255,255,0.12)', borderRadius: '16px', border: '1px solid rgba(255,255,255,0.1)' }}
                  >
                    <div className="flex items-center gap-3 min-w-0 flex-1">
                      <span className="text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full flex-shrink-0" style={{ color: C.accent, backgroundColor: 'rgba(45,106,79,0.12)', fontFamily: F.mono, fontWeight: 500 }}>
                        {categories.find(c => c.key === heroEvents[heroSlide].category)?.boldLabel}
                      </span>
                      <span className="text-xs sm:text-sm text-white truncate" style={{ fontFamily: F.heading, fontWeight: 700 }}>
                        {heroEvents[heroSlide].title}
                      </span>
                    </div>
                    <button className="flex items-center gap-1.5 px-3 py-1.5 text-[11px] flex-shrink-0 cursor-pointer" style={{ color: C.white, border: '1px solid rgba(255,255,255,0.25)', borderRadius: '8px', fontFamily: F.body, fontWeight: 500 }}>
                      Read on <ArrowUpRight size={11} />
                    </button>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>

            {/* Carousel nav arrows */}
            <button
              onClick={prevSlide}
              className="absolute left-4 top-1/2 -translate-y-1/2 h-10 w-10 flex items-center justify-center cursor-pointer transition-all hover:scale-110"
              style={{ backgroundColor: C.white, borderRadius: '50%', boxShadow: '0 2px 8px rgba(0,0,0,0.15)' }}
            >
              <ChevronLeft size={18} style={{ color: C.black }} />
            </button>
            <button
              onClick={nextSlide}
              className="absolute right-4 top-1/2 -translate-y-1/2 h-10 w-10 flex items-center justify-center cursor-pointer transition-all hover:scale-110"
              style={{ backgroundColor: C.white, borderRadius: '50%', boxShadow: '0 2px 8px rgba(0,0,0,0.15)' }}
            >
              <ChevronRight size={18} style={{ color: C.black }} />
            </button>

            {/* Dots */}
            <div className="absolute bottom-[72px] sm:bottom-[88px] left-1/2 -translate-x-1/2 flex gap-2">
              {heroEvents.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setHeroSlide(i)}
                  className="h-2 rounded-full transition-all cursor-pointer"
                  style={{
                    width: i === heroSlide ? '24px' : '8px',
                    backgroundColor: i === heroSlide ? C.white : 'rgba(255,255,255,0.4)',
                  }}
                />
              ))}
            </div>
          </div>

          {/* Category quick-links row — horizontal scroll on mobile, grid on desktop */}
          <div className="flex sm:grid sm:grid-cols-3 md:grid-cols-6 gap-2.5 sm:gap-3 mt-5 sm:mt-6 overflow-x-auto sm:overflow-x-visible pb-2 sm:pb-0 scrollbar-hide snap-x snap-mandatory sm:snap-none">
            {categories.filter(c => c.key !== 'all').map((cat, i) => (
              <motion.button
                key={cat.key}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 + i * 0.06 }}
                onClick={() => setActiveCategory(cat.key)}
                className="group relative overflow-hidden cursor-pointer text-left flex-shrink-0 w-[140px] sm:w-auto snap-start"
                style={{ borderRadius: '14px', aspectRatio: '3/2' }}
              >
                <ImageWithFallback
                  src={cat.image}
                  alt={cat.label}
                  className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0" style={{ background: `linear-gradient(to top, ${C.deepForest}dd, rgba(0,0,0,0.1))` }} />
                <div className="absolute inset-0 p-2.5 sm:p-4 flex flex-col justify-between">
                  <span
                    className="self-start"
                    style={{
                      fontFamily: F.heading,
                      fontWeight: 900,
                      fontSize: 'clamp(0.9rem, 2vw, 1.4rem)',
                      color: C.white,
                      lineHeight: 1.1,
                    }}
                  >
                    {cat.boldLabel}
                  </span>
                  <div className="self-end h-6 w-6 sm:h-7 sm:w-7 flex items-center justify-center" style={{ backgroundColor: 'rgba(149,213,178,0.2)', borderRadius: '8px', border: `1px solid ${C.deepForestBorder}` }}>
                    <ArrowUpRight size={12} color={C.sage} />
                  </div>
                </div>
              </motion.button>
            ))}
          </div>
        </div>
      </section>

      {/* ═══════════ CATEGORIES / BROWSE SECTION ═══════════ */}
      <section style={{ backgroundColor: C.deepForest }}>
        <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-24">
          <BoldHeading>
            <h2
              style={{
                fontFamily: F.heading,
                fontWeight: 900,
                fontSize: 'clamp(1.8rem, 5vw, 4rem)',
                color: C.white,
                lineHeight: 1,
                letterSpacing: '-0.02em',
              }}
            >
              Categories
            </h2>
          </BoldHeading>

          {/* Category pills — horizontal scroll on mobile */}
          <div className="flex gap-2 sm:gap-2.5 mt-6 sm:mt-10 overflow-x-auto pb-2 scrollbar-hide">
            {categories.map((cat) => (
              <button
                key={cat.key}
                onClick={() => setActiveCategory(cat.key)}
                className="flex items-center gap-1.5 sm:gap-2 px-3.5 sm:px-5 py-2 sm:py-2.5 text-xs sm:text-sm whitespace-nowrap transition-all cursor-pointer flex-shrink-0"
                style={{
                  borderRadius: '9999px',
                  backgroundColor: activeCategory === cat.key ? C.white : 'rgba(149,213,178,0.08)',
                  color: activeCategory === cat.key ? C.deepForest : C.sage,
                  border: activeCategory === cat.key ? 'none' : `1.5px solid ${C.deepForestBorder}`,
                  fontFamily: F.body,
                  fontWeight: activeCategory === cat.key ? 600 : 400,
                }}
              >
                <cat.icon size={14} />
                {cat.label}
              </button>
            ))}
          </div>

          {/* Events — horizontal scroll on mobile, grid on desktop */}
          <AnimatePresence mode="wait">
            <motion.div
              key={activeCategory}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.3 }}
              className="flex sm:grid sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5 mt-6 sm:mt-10 overflow-x-auto sm:overflow-x-visible pb-4 sm:pb-0 scrollbar-hide snap-x snap-mandatory sm:snap-none"
            >
              {paginatedEvents.map((event, i) => (
                <motion.button
                  key={event.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: i * 0.04 }}
                  onClick={() => setSelectedEvent(event)}
                  className="group text-left cursor-pointer overflow-hidden flex-shrink-0 w-[280px] sm:w-auto snap-start"
                  style={{ borderRadius: '20px', backgroundColor: C.deepForestCard, border: `1px solid ${C.deepForestBorder}` }}
                >
                  <div className="relative aspect-[4/3] overflow-hidden">
                    <ImageWithFallback
                      src={event.image}
                      alt={event.title}
                      className="h-full w-full object-cover transition-transform duration-600 group-hover:scale-105"
                    />
                    <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(18,42,32,0.6) 0%, transparent 50%)' }} />
                    <div className="absolute top-3 sm:top-4 left-3 sm:left-4">
                      <span
                        className="text-[10px] uppercase tracking-wider px-2 sm:px-2.5 py-1"
                        style={{
                          color: C.sage,
                          backgroundColor: 'rgba(149,213,178,0.15)',
                          borderRadius: '6px',
                          fontFamily: F.mono,
                          fontWeight: 600,
                          backdropFilter: 'blur(8px)',
                        }}
                      >
                        {categories.find(c => c.key === event.category)?.boldLabel}
                      </span>
                    </div>
                  </div>
                  <div className="p-4 sm:p-5">
                    <div className="flex items-center gap-2 mb-1.5 sm:mb-2 text-[10px] sm:text-[11px]" style={{ color: C.deepForestTextLight, fontFamily: F.body }}>
                      <span>{formatDate(event.date)}</span>
                      <span>·</span>
                      <span>{event.time}</span>
                    </div>
                    <h3
                      className="mb-1 line-clamp-2 group-hover:opacity-70 transition-opacity"
                      style={{
                        fontFamily: F.heading,
                        fontWeight: 800,
                        fontSize: '1rem',
                        color: C.white,
                        lineHeight: 1.25,
                      }}
                    >
                      {event.title}
                    </h3>
                    <p className="text-xs line-clamp-1 mb-2.5 sm:mb-3 hidden sm:block" style={{ color: C.deepForestTextLight, fontFamily: F.body }}>
                      {event.subtitle}
                    </p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5 text-[10px] sm:text-[11px]" style={{ color: C.sage, fontFamily: F.body }}>
                        <MapPin size={10} />
                        <span>{event.district}</span>
                      </div>
                      <span
                        className="text-[11px] sm:text-xs font-semibold"
                        style={{ color: event.price === 'Free' ? C.sage : C.warmOrange, fontFamily: F.mono }}
                      >
                        {event.price}
                      </span>
                    </div>
                  </div>
                </motion.button>
              ))}
            </motion.div>
          </AnimatePresence>

          {filteredEvents.length === 0 && (
            <div className="text-center py-16 sm:py-20">
              <Sun size={32} style={{ color: C.sage }} className="mx-auto mb-4 opacity-50" />
              <p style={{ fontFamily: F.heading, color: C.sage, fontSize: '1.2rem', fontWeight: 700 }}>
                {t('lifestyle.noEventsInCategory')}
              </p>
              <p className="text-sm mt-2" style={{ color: C.deepForestTextLight, fontFamily: F.body }}>
                {t('lifestyle.noEventsInCategoryDesc')}
              </p>
            </div>
          )}

          {/* Show more button when there are more events */}
          {filteredEvents.length > visibleCount && (
            <div className="flex justify-center mt-8 sm:mt-10">
              <button
                onClick={() => setVisibleCount(prev => prev + 9)}
                className="flex items-center gap-2 px-6 py-3 text-sm transition-all hover:opacity-80 cursor-pointer"
                style={{
                  color: C.sage,
                  border: `1.5px solid ${C.deepForestBorder}`,
                  borderRadius: '9999px',
                  fontFamily: F.body,
                  fontWeight: 600,
                  backgroundColor: 'transparent',
                }}
              >
                Show more ({filteredEvents.length - visibleCount} remaining) <ChevronRight size={14} />
              </button>
            </div>
          )}
        </div>
      </section>

      {/* ═══════════ "LET'S GET REAL" FEATURE SECTION ═══════════ */}
      <section style={{ backgroundColor: C.offWhite }}>
        <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-24">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 sm:gap-12 items-center">
            {/* Text */}
            <BoldHeading>
              <div>
                <span className="text-xs uppercase tracking-[0.2em] mb-3 sm:mb-4 block" style={{ color: C.forest, fontFamily: F.mono, fontWeight: 500 }}>
                  Welcome to Lifestyle
                </span>
                <h2
                  style={{
                    fontFamily: F.heading,
                    fontWeight: 900,
                    fontSize: 'clamp(1.8rem, 5vw, 3.5rem)',
                    color: C.black,
                    lineHeight: 1.05,
                    letterSpacing: '-0.02em',
                  }}
                >
                  Here To Help<br />
                  You <span style={{ fontStyle: 'italic', fontWeight: 400, color: C.forest }}>Thrive</span>
                </h2>
                <p className="mt-4 sm:mt-5 text-sm sm:text-base max-w-md" style={{ color: C.textMuted, fontFamily: F.body, lineHeight: 1.8 }}>
                  Are you ready to embark on a journey towards a healthier, fitter you? Our lifestyle platform is your one-stop destination for all things wellness in Hong Kong.
                </p>

                {/* Stats */}
                <div className="flex gap-6 sm:gap-8 mt-6 sm:mt-8 pt-5 sm:pt-6" style={{ borderTop: `1px solid ${C.forest}15` }}>
                  {[
                    { value: '2.4k', label: 'Active members' },
                    { value: '48', label: 'Weekly events' },
                    { value: '12', label: 'Communities' },
                  ].map((stat) => (
                    <div key={stat.label}>
                      <div style={{ fontFamily: F.heading, fontSize: 'clamp(1.2rem, 3vw, 1.5rem)', fontWeight: 900, color: C.forest }}>{stat.value}</div>
                      <div className="text-[10px] sm:text-[11px] mt-0.5" style={{ color: C.textMuted, fontFamily: F.body }}>{stat.label}</div>
                    </div>
                  ))}
                </div>
              </div>
            </BoldHeading>

            {/* Featured large image card */}
            <BoldHeading delay={0.15}>
              <div className="relative overflow-hidden group cursor-pointer" style={{ borderRadius: '20px', aspectRatio: '4/3' }}>
                <ImageWithFallback
                  src={mergedLifestyleEvents[1]?.image || mergedLifestyleEvents[0]?.image || ''}
                  alt="Wellness"
                  className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.6) 0%, transparent 50%)' }} />
                <div className="absolute bottom-6 left-6 right-6">
                  <span
                    style={{
                      fontFamily: F.heading,
                      fontWeight: 900,
                      fontSize: 'clamp(1.5rem, 3vw, 2.2rem)',
                      color: C.white,
                      lineHeight: 1.1,
                      fontStyle: 'italic',
                    }}
                  >
                    let&rsquo;s get real.
                  </span>
                </div>
                <div className="absolute bottom-6 right-6 h-10 w-10 flex items-center justify-center" style={{ backgroundColor: 'rgba(255,255,255,0.15)', borderRadius: '50%', border: '1px solid rgba(255,255,255,0.2)' }}>
                  <Play size={16} color="white" fill="white" />
                </div>
                <div className="absolute bottom-6 right-20 px-2.5 py-1 text-xs text-white/70" style={{ fontFamily: F.body }}>
                  25 min
                </div>
              </div>
            </BoldHeading>
          </div>
        </div>
      </section>

      {/* ═══════════ COMMUNITY SECTION (DEEP GREEN) ═══════════ */}
      <section style={{ backgroundColor: C.deepForestSurface }}>
        <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-24">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 sm:gap-10 items-center">
            <div>
              <BoldHeading>
                <span className="text-xs uppercase tracking-[0.2em] mb-3 sm:mb-4 block" style={{ color: C.sage, fontFamily: F.mono, fontWeight: 500 }}>
                  Community
                </span>
                <h2
                  className="mb-4 sm:mb-6"
                  style={{
                    fontFamily: F.heading,
                    fontWeight: 900,
                    fontSize: 'clamp(1.8rem, 5vw, 3.5rem)',
                    color: C.white,
                    lineHeight: 1.05,
                    letterSpacing: '-0.02em',
                  }}
                >
                  Creators
                </h2>
              </BoldHeading>
              <p className="text-sm sm:text-base mb-6 sm:mb-8" style={{ color: C.deepForestTextLight, fontFamily: F.body, lineHeight: 1.7 }}>
                Connect with like-minded people building Hong Kong's most vibrant wellness communities.
              </p>

              {/* Community stats — horizontal scroll on mobile */}
              <div className="flex gap-2.5 sm:gap-3 overflow-x-auto scrollbar-hide pb-1">
                {[
                  { label: 'Run Clubs', count: '6 active' },
                  { label: 'Wellness', count: '8 weekly' },
                  { label: 'Coffee Raves', count: '2 monthly' },
                ].map((item) => (
                  <div key={item.label} className="px-3.5 sm:px-4 py-2.5 sm:py-3 flex-shrink-0" style={{ backgroundColor: C.deepForestCard, borderRadius: '14px', border: `1px solid ${C.deepForestBorder}` }}>
                    <span className="text-xs text-white block" style={{ fontFamily: F.body, fontWeight: 600 }}>{item.label}</span>
                    <span className="text-[10px]" style={{ color: C.sage, fontFamily: F.body }}>{item.count}</span>
                  </div>
                ))}
              </div>

              <button className="mt-6 sm:mt-8 flex items-center gap-2 px-5 py-2.5 text-xs uppercase tracking-wider cursor-pointer transition-all hover:opacity-80" style={{ color: C.deepForest, backgroundColor: C.sage, borderRadius: '9999px', fontFamily: F.mono, fontWeight: 600 }}>
                View All <ArrowUpRight size={12} />
              </button>
            </div>

            {/* Image grid — 2 cols on mobile, 3 on desktop */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 sm:gap-3">
              {[mergedLifestyleEvents[0], mergedLifestyleEvents[3], mergedLifestyleEvents[5], mergedLifestyleEvents[7], mergedLifestyleEvents[4], mergedLifestyleEvents[9]].filter(Boolean).map((ev, i) => (
                <motion.div
                  key={ev.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.07 }}
                  className={`overflow-hidden relative group ${i >= 4 ? 'hidden sm:block' : ''}`}
                  style={{ borderRadius: '14px', aspectRatio: '3/4' }}
                >
                  <ImageWithFallback
                    src={ev.image}
                    alt={ev.title}
                    className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(15,34,25,0.7) 0%, transparent 50%)' }} />
                  <div className="absolute bottom-2.5 sm:bottom-3 left-2.5 sm:left-3 right-2.5 sm:right-3">
                    <span className="text-[10px] sm:text-[11px] text-white font-medium block truncate" style={{ fontFamily: F.body }}>{ev.organizer}</span>
                    <div className="flex gap-1 mt-1 sm:mt-1.5 flex-wrap">
                      {ev.tags.slice(0, 2).map(tag => (
                        <span key={tag} className="text-[8px] sm:text-[9px] px-1.5 py-0.5" style={{ color: C.sage, backgroundColor: 'rgba(149,213,178,0.15)', borderRadius: '4px', fontFamily: F.mono }}>#{tag}</span>
                      ))}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ═══════════ HOST CTA ═══════════ */}
      <section style={{ backgroundColor: C.offWhite }}>
        <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-32 text-center">
          <BoldHeading>
            <h2
              style={{
                fontFamily: F.heading,
                fontWeight: 900,
                fontSize: 'clamp(1.8rem, 6vw, 4.5rem)',
                color: C.black,
                lineHeight: 1,
                letterSpacing: '-0.02em',
              }}
            >
              Have something<br />
              to <span style={{ color: C.forest, fontStyle: 'italic', fontWeight: 400 }}>share</span>?
            </h2>
          </BoldHeading>
          <p className="text-sm sm:text-base max-w-md mx-auto mt-4 sm:mt-5 mb-6 sm:mb-8" style={{ color: C.textMuted, fontFamily: F.body, lineHeight: 1.7 }}>
            Host a run club, workshop, or community meetup through CULTIVE Lifestyle. We&rsquo;ll help you find your people.
          </p>
          <div className="flex gap-3 justify-center flex-wrap">
            <button
              className="px-6 sm:px-8 py-3 sm:py-3.5 text-sm transition-all hover:opacity-90 cursor-pointer"
              style={{
                backgroundColor: C.forest,
                color: C.white,
                borderRadius: '9999px',
                fontFamily: F.body,
                fontWeight: 600,
              }}
            >
              Start Hosting
            </button>
            <button
              className="px-6 sm:px-8 py-3 sm:py-3.5 text-sm transition-all hover:opacity-90 cursor-pointer"
              style={{
                backgroundColor: 'transparent',
                color: C.forest,
                border: `1.5px solid ${C.forest}30`,
                borderRadius: '9999px',
                fontFamily: F.body,
                fontWeight: 500,
              }}
            >
              Learn More
            </button>
          </div>
        </div>
      </section>

      {/* ═══════════ COMPACT FOOTER ═══════════ */}
      <footer style={{ backgroundColor: C.deepForest }}>
        <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-14">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 sm:gap-6">
            <div>
              <span style={{ fontFamily: F.heading, fontWeight: 900, fontSize: '1.2rem', color: C.white }}>
                CULTIVE <span style={{ color: C.sage, fontStyle: 'italic', fontWeight: 400 }}>lifestyle.</span>
              </span>
              <p className="text-xs mt-1.5" style={{ color: C.deepForestTextLight, fontFamily: F.body }}>
                Move, gather, grow together in Hong Kong.
              </p>
            </div>
            <div className="flex gap-5 sm:gap-6 text-xs" style={{ color: C.deepForestTextLight, fontFamily: F.body }}>
              {[
                { label: 'About', path: '/about' },
                { label: 'Events', path: '/events' },
                { label: 'Recaps', path: '/recaps' },
                { label: 'Host', path: '/contribute' },
                { label: 'FAQ', path: '/about' },
              ].map(link => (
                <Link key={link.label} to={link.path} className="hover:text-white transition-colors cursor-pointer no-underline" style={{ color: C.deepForestTextLight }}>{link.label}</Link>
              ))}
            </div>
          </div>
        </div>
      </footer>

      {/* ═══════════ EVENT DETAIL MODAL ═══════════ */}
      <AnimatePresence>
        {selectedEvent && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[9999] flex items-end sm:items-center justify-center"
          >
            <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setSelectedEvent(null)} />

            <motion.div
              initial={{ y: '100%', opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: '100%', opacity: 0 }}
              transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              className="relative w-full sm:max-w-lg max-h-[90vh] overflow-y-auto sm:rounded-3xl rounded-t-3xl"
              style={{ backgroundColor: C.offWhite }}
            >
              <button
                onClick={() => setSelectedEvent(null)}
                className="absolute top-4 right-4 z-10 p-2.5 cursor-pointer"
                style={{ backgroundColor: 'rgba(255,255,255,0.85)', borderRadius: '50%', backdropFilter: 'blur(8px)', boxShadow: '0 2px 8px rgba(0,0,0,0.1)' }}
              >
                <X size={16} style={{ color: C.black }} />
              </button>

              <div className="relative h-56 sm:h-64 overflow-hidden rounded-t-3xl">
                <ImageWithFallback src={selectedEvent.image} alt={selectedEvent.title} className="h-full w-full object-cover" />
                <div className="absolute inset-0" style={{ background: `linear-gradient(to top, ${C.offWhite}, transparent 60%)` }} />
              </div>

              <div className="px-6 pb-8 -mt-8 relative">
                <div className="flex items-center gap-2 mb-3 flex-wrap">
                  <span
                    className="px-3 py-1 text-[10px] uppercase tracking-wider"
                    style={{ color: C.accentMuted, backgroundColor: 'rgba(45,106,79,0.1)', borderRadius: '8px', fontFamily: F.mono, fontWeight: 600 }}
                  >
                    {categories.find((c) => c.key === selectedEvent.category)?.boldLabel}
                  </span>
                  {selectedEvent.difficulty && (
                    <span
                      className="px-2.5 py-1 text-[10px] uppercase tracking-wider"
                      style={{ color: getDifficultyColor(selectedEvent.difficulty), backgroundColor: `${getDifficultyColor(selectedEvent.difficulty)}15`, borderRadius: '8px', fontFamily: F.mono, fontWeight: 600 }}
                    >
                      {selectedEvent.difficulty}
                    </span>
                  )}
                  {selectedEvent.recurring && (
                    <span className="px-2.5 py-1 text-[10px] uppercase tracking-wider" style={{ color: C.textMuted, backgroundColor: 'rgba(0,0,0,0.04)', borderRadius: '8px', fontFamily: F.mono }}>
                      Recurring
                    </span>
                  )}
                </div>

                <h2 style={{ fontFamily: F.heading, fontSize: '1.7rem', fontWeight: 900, color: C.black, marginBottom: '4px', letterSpacing: '-0.02em' }}>
                  {selectedEvent.title}
                </h2>
                <p className="text-sm mb-5" style={{ color: C.textMuted, fontFamily: F.body, fontStyle: 'italic' }}>
                  {selectedEvent.subtitle}
                </p>
                <p className="text-sm mb-6" style={{ color: '#5A5A5A', fontFamily: F.body, lineHeight: 1.7 }}>
                  {selectedEvent.description}
                </p>

                <div className="grid grid-cols-2 gap-3 mb-6">
                  {[
                    { icon: Calendar, label: 'Date', value: formatDate(selectedEvent.date) },
                    { icon: Clock, label: 'Time', value: selectedEvent.time },
                    { icon: MapPin, label: 'Location', value: selectedEvent.location },
                    { icon: Users, label: 'Spots Left', value: `${selectedEvent.spotsLeft} / ${selectedEvent.capacity}` },
                  ].map((item) => (
                    <div key={item.label} className="p-3" style={{ borderRadius: '14px', backgroundColor: 'rgba(45,106,79,0.06)' }}>
                      <div className="flex items-center gap-1.5 mb-1">
                        <item.icon size={12} style={{ color: C.forest }} />
                        <span className="text-[10px] uppercase tracking-wider" style={{ color: C.textMuted, fontFamily: F.mono }}>{item.label}</span>
                      </div>
                      <span className="text-sm" style={{ color: C.black, fontFamily: F.body, fontWeight: 500 }}>{item.value}</span>
                    </div>
                  ))}
                </div>

                <div className="flex items-center justify-between mb-6 p-3" style={{ borderRadius: '14px', backgroundColor: 'rgba(45,106,79,0.06)' }}>
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 flex items-center justify-center" style={{ borderRadius: '12px', backgroundColor: 'rgba(45,106,79,0.1)' }}>
                      <Heart size={16} style={{ color: C.accentMuted }} />
                    </div>
                    <div>
                      <span className="text-sm block" style={{ color: C.black, fontFamily: F.body, fontWeight: 600 }}>{selectedEvent.organizer}</span>
                      <span className="text-[11px]" style={{ color: C.textMuted, fontFamily: F.body }}>Organizer</span>
                    </div>
                  </div>
                  <button className="text-xs flex items-center gap-1 cursor-pointer" style={{ color: C.accentMuted, fontFamily: F.body, fontWeight: 500 }}>
                    Follow <ExternalLink size={10} />
                  </button>
                </div>

                <div className="flex flex-wrap gap-2 mb-6">
                  {selectedEvent.tags.map((tag) => (
                    <span key={tag} className="px-3 py-1 text-[11px]" style={{ color: C.textMuted, backgroundColor: 'rgba(0,0,0,0.04)', borderRadius: '9999px', fontFamily: F.body }}>
                      #{tag}
                    </span>
                  ))}
                </div>

                {/* Capacity */}
                <div className="mb-6">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs" style={{ color: C.textMuted, fontFamily: F.body }}>
                      {selectedEvent.capacity - selectedEvent.spotsLeft} joined
                    </span>
                    <span className="text-xs" style={{
                      color: selectedEvent.spotsLeft <= 3 ? C.terracotta : C.textMuted,
                      fontFamily: F.body,
                      fontWeight: selectedEvent.spotsLeft <= 3 ? 700 : 400,
                    }}>
                      {selectedEvent.spotsLeft <= 3 ? 'Almost full!' : `${selectedEvent.spotsLeft} spots left`}
                    </span>
                  </div>
                  <div className="h-2 overflow-hidden" style={{ borderRadius: '9999px', backgroundColor: 'rgba(0,0,0,0.06)' }}>
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${((selectedEvent.capacity - selectedEvent.spotsLeft) / selectedEvent.capacity) * 100}%` }}
                      transition={{ duration: 0.8, ease: 'easeOut' }}
                      className="h-full"
                      style={{ borderRadius: '9999px', backgroundColor: selectedEvent.spotsLeft <= 3 ? C.warmOrange : C.forest }}
                    />
                  </div>
                </div>

                <div className="flex gap-3">
                  <a
                    href={selectedEvent.ticketUrl || selectedEvent.sourceUrl || '#'}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 flex items-center justify-center gap-2 py-3.5 text-sm transition-all hover:opacity-90 cursor-pointer no-underline"
                    style={{ backgroundColor: C.forest, color: C.white, borderRadius: '14px', fontFamily: F.body, fontWeight: 700 }}
                  >
                    Join Event &mdash; {selectedEvent.price}
                    <ExternalLink size={14} />
                  </a>
                  <ShareMenu
                    url={selectedEvent.ticketUrl || selectedEvent.sourceUrl || '#'}
                    title={selectedEvent.title}
                    description={selectedEvent.description}
                    eventId={selectedEvent.id}
                  >
                    {({ onClick, ref }) => (
                      <button ref={ref} onClick={onClick}
                        className="p-3.5 cursor-pointer transition-all hover:opacity-70"
                        style={{ border: '1.5px solid rgba(0,0,0,0.1)', borderRadius: '14px', color: C.textMuted }}>
                        <Share2 size={16} />
                      </button>
                    )}
                  </ShareMenu>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <style>{`
        .scrollbar-hide::-webkit-scrollbar { display: none; }
        .scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
      `}</style>
      </div>
    </div>
  );
}