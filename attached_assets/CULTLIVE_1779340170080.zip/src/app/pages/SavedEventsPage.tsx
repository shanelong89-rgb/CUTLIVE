import { useMemo } from 'react';
import { Link } from 'react-router';
import { motion } from 'motion/react';
import { Bookmark, Heart, ArrowRight, Loader2 } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { useAuth } from '../context/AuthContext';
import { useMode } from '../context/ModeContext';
import { useData } from '../context/DataContext';
import { getDesignTokens } from '../data/mode-styles';
import { modeConfig } from '../data/mock-data';
import { EventGridCard } from '../components/events/EventGridCard';

export function SavedEventsPage() {
  const { user, savedEventIds, savedEventsLoading } = useAuth();
  const { currentMode } = useMode();
  const { allEvents } = useData();
  const { t } = useTranslation();
  const tokens = getDesignTokens(currentMode);
  const modeColor = currentMode && currentMode !== 'lifestyle'
    ? modeConfig[currentMode].color
    : currentMode === 'lifestyle' ? '#2D6A4F' : '#8338EC';

  const savedEvents = useMemo(() => {
    return allEvents.filter((e) => savedEventIds.includes(e.id));
  }, [allEvents, savedEventIds]);

  if (savedEventsLoading && savedEventIds.length === 0) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center px-4" data-nav-theme="dark">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center"
        >
          <Loader2 size={24} className="animate-spin mx-auto mb-3" style={{ color: modeColor }} />
          <p className="text-sm" style={{ color: tokens.textMuted }}>
            Loading your saved events…
          </p>
        </motion.div>
      </div>
    );
  }

  if (savedEventIds.length === 0) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center px-4" data-nav-theme="dark">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center max-w-sm"
        >
          <div
            className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4"
            style={{ backgroundColor: `${modeColor}15` }}
          >
            <Bookmark size={28} style={{ color: modeColor }} />
          </div>
          <h2 className="text-lg font-semibold mb-2" style={{ color: tokens.textPrimary }}>
            {t('saved.noSaved')}
          </h2>
          <p className="text-sm mb-6" style={{ color: tokens.textMuted }}>
            {t('saved.noSavedDesc')}
            {!user && ` ${t('saved.signInToSync')}`}
          </p>
          <div className="flex items-center justify-center gap-3">
            <Link
              to="/events"
              className="px-5 py-2.5 text-sm font-medium rounded-xl transition-opacity hover:opacity-80"
              style={{
                backgroundColor: modeColor,
                color: '#fff',
                textDecoration: 'none',
              }}
            >
              {t('saved.browseEvents')}
            </Link>
            {!user && (
              <Link
                to="/login"
                className="px-5 py-2.5 text-sm font-medium rounded-xl transition-opacity hover:opacity-80"
                style={{
                  backgroundColor: tokens.surfaceBg,
                  color: tokens.textPrimary,
                  border: `1px solid ${tokens.cardBorder}`,
                  textDecoration: 'none',
                }}
              >
                {t('saved.signIn')}
              </Link>
            )}
          </div>
        </motion.div>
      </div>
    );
  }

  if (savedEvents.length === 0) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center px-4" data-nav-theme="dark">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center max-w-sm"
        >
          <div
            className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4"
            style={{ backgroundColor: `${modeColor}15` }}
          >
            <Heart size={28} style={{ color: modeColor }} />
          </div>
          <h2 className="text-lg font-semibold mb-2" style={{ color: tokens.textPrimary }}>
            {t('saved.noSaved')}
          </h2>
          <p className="text-sm mb-6" style={{ color: tokens.textMuted }}>
            {t('saved.noSavedDesc')}
          </p>
          <Link
            to="/events"
            className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-medium rounded-xl transition-opacity hover:opacity-80"
            style={{
              backgroundColor: modeColor,
              color: '#fff',
              textDecoration: 'none',
            }}
          >
            {t('saved.browseEvents')}
            <ArrowRight size={16} />
          </Link>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8" data-nav-theme="dark">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        <div className="mb-8">
          <h1 className="text-2xl font-semibold" style={{ color: tokens.textPrimary }}>
            {t('saved.title')}
          </h1>
          <p className="text-sm mt-1" style={{ color: tokens.textMuted }}>
            {t('saved.savedCount', { count: savedEvents.length })}
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {savedEvents.map((event, i) => (
            <EventGridCard
              key={event.id}
              event={event}
              index={i}
              modeColor={modeColor}
              tokens={{
                imageRadius: tokens.imageRadius,
                textMuted: tokens.textMuted,
              }}
            />
          ))}
        </div>
      </motion.div>
    </div>
  );
}