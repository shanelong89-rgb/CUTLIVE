import { createContext, useContext, useState, useCallback, useEffect, type ReactNode } from 'react';

// ═══════════════════════════════════════════════════════════════════
// Neutral-mode light/dark theme — scoped to mobile editorial homepage
// ═══════════════════════════════════════════════════════════════════

export type NeutralTheme = 'light' | 'dark';

export interface NeutralPalette {
  bg: string;
  bgAlt: string;
  text: string;
  textSecondary: string;
  textMuted: string;
  border: string;
  borderSubtle: string;
  cardBg: string;
  numberColor: string;
  ctaBg: string;
  ctaText: string;
  ctaBorder: string;
  inputBg: string;
  inputBorder: string;
}

const LIGHT: NeutralPalette = {
  bg: '#FAFAF8',
  bgAlt: '#F5F3F0',
  text: '#1A1A1A',
  textSecondary: '#777',
  textMuted: '#B5B0A8',
  border: '#E8E4DE',
  borderSubtle: '#F0EDE8',
  cardBg: '#FAFAF8',
  numberColor: '#EDEAE5',
  ctaBg: '#1A1A1A',
  ctaText: '#FAFAF8',
  ctaBorder: 'rgba(255,255,255,0.08)',
  inputBg: 'rgba(0,0,0,0.03)',
  inputBorder: '#E8E4DE',
};

const DARK: NeutralPalette = {
  bg: '#0A0A0A',
  bgAlt: '#111111',
  text: '#E8E4DE',
  textSecondary: '#999',
  textMuted: '#666',
  border: '#222',
  borderSubtle: '#1A1A1A',
  cardBg: '#0F0F0F',
  numberColor: '#2A2A2A',
  ctaBg: '#161616',
  ctaText: '#E8E4DE',
  ctaBorder: '#333',
  inputBg: 'rgba(255,255,255,0.06)',
  inputBorder: '#333',
};

interface NeutralThemeContextValue {
  theme: NeutralTheme;
  palette: NeutralPalette;
  toggleTheme: () => void;
}

const NeutralThemeContext = createContext<NeutralThemeContextValue>({
  theme: 'light',
  palette: LIGHT,
  toggleTheme: () => {},
});

const STORAGE_KEY = 'cultive-neutral-theme';

export function NeutralThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setTheme] = useState<NeutralTheme>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved === 'dark' || saved === 'light') return saved;
    } catch {}
    // Respect system preference
    if (typeof window !== 'undefined' && window.matchMedia?.('(prefers-color-scheme: dark)').matches) {
      return 'dark';
    }
    return 'light';
  });

  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEY, theme); } catch {}
  }, [theme]);

  const toggleTheme = useCallback(() => {
    setTheme(prev => prev === 'light' ? 'dark' : 'light');
  }, []);

  const palette = theme === 'dark' ? DARK : LIGHT;

  return (
    <NeutralThemeContext.Provider value={{ theme, palette, toggleTheme }}>
      {children}
    </NeutralThemeContext.Provider>
  );
}

export function useNeutralTheme() {
  return useContext(NeutralThemeContext);
}