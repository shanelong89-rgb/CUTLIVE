import { createContext, useContext, useState, useEffect, useCallback, useMemo, type ReactNode } from 'react';
import { useAuth } from './AuthContext';
import { projectId, publicAnonKey } from '../config/supabase';

const SUPABASE_URL = `https://${projectId}.supabase.co`;
const API_BASE = `${SUPABASE_URL}/functions/v1/make-server-d507b98c`;

// Our custom server routes identify the user via X-User-Id, not by JWT.
// Always use publicAnonKey so we never hit token timing / expiry issues.
const authHeaders = (userId: string) => ({
  'Authorization': `Bearer ${publicAnonKey}`,
  'X-User-Id': userId,
});

export interface CollectionItem {
  id: string;
  type: 'event' | 'venue';
  addedAt: string;
}

export interface Collection {
  id: string;
  userId: string;
  name: string;
  description: string;
  isPublic: boolean;
  items: CollectionItem[];
  createdAt: string;
  updatedAt: string;
}

interface CollectionsContextType {
  collections: Collection[];
  loading: boolean;
  createCollection: (name: string, description?: string, isPublic?: boolean) => Promise<Collection>;
  updateCollection: (id: string, updates: Partial<Collection>) => Promise<void>;
  deleteCollection: (id: string) => Promise<void>;
  addToCollection: (collectionId: string, itemId: string, itemType: 'event' | 'venue') => Promise<void>;
  removeFromCollection: (collectionId: string, itemId: string) => Promise<void>;
  isInCollection: (collectionId: string, itemId: string) => boolean;
  isInAnyCollection: (itemId: string) => boolean;
  quickSave: (itemId: string, itemType: 'event' | 'venue') => Promise<void>;
  isQuickSaved: (itemId: string) => boolean;
  toggleQuickSave: (itemId: string, itemType: 'event' | 'venue') => Promise<void>;
  getQuickSaveCollection: () => Collection | undefined;
  allSavedItemIds: Set<string>;
  refresh: () => Promise<void>;
}

const QUICK_SAVE_NAME = '\u2764\uFE0F Quick Saves';

const CollectionsContext = createContext<CollectionsContextType>({
  collections: [],
  loading: true,
  createCollection: async () => ({} as Collection),
  updateCollection: async () => {},
  deleteCollection: async () => {},
  addToCollection: async () => {},
  removeFromCollection: async () => {},
  isInCollection: () => false,
  isInAnyCollection: () => false,
  quickSave: async () => {},
  isQuickSaved: () => false,
  toggleQuickSave: async () => {},
  getQuickSaveCollection: () => undefined,
  allSavedItemIds: new Set(),
  refresh: async () => {},
});

export function CollectionsProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [collections, setCollections] = useState<Collection[]>(() => {
    // Restore from localStorage on mount so saved items persist across refreshes
    try {
      const cached = localStorage.getItem('cultive_collections_cache');
      if (cached) return JSON.parse(cached);
    } catch {}
    return [];
  });
  const [loading, setLoading] = useState(true);

  // Persist collections to localStorage whenever they change
  useEffect(() => {
    try {
      if (collections.length > 0) {
        localStorage.setItem('cultive_collections_cache', JSON.stringify(collections));
      }
    } catch {}
  }, [collections]);

  const fetchCollections = useCallback(async () => {
    if (!user?.id) {
      // Don't clear collections — keep localStorage cache so saved items persist
      setLoading(false);
      return;
    }

    try {
      const res = await fetch(`${API_BASE}/user/collections`, {
        headers: authHeaders(user.id),
      });

      if (res.ok) {
        const data = await res.json();
        setCollections(data.collections || []);
      } else {
        console.error('Failed to fetch collections:', await res.text());
      }
    } catch (err) {
      console.error('Error fetching collections:', err);
    } finally {
      setLoading(false);
    }
  }, [user?.id]);

  useEffect(() => {
    fetchCollections();
  }, [fetchCollections]);

  const createCollection = useCallback(async (name: string, description = '', isPublic = false) => {
    if (!user?.id) throw new Error('Must be logged in to create collection');

    const res = await fetch(`${API_BASE}/user/collections`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...authHeaders(user.id),
      },
      body: JSON.stringify({ name, description, isPublic }),
    });

    if (!res.ok) {
      const error = await res.json();
      throw new Error(error.error || 'Failed to create collection');
    }

    const data = await res.json();
    setCollections(prev => [...prev, data.collection]);
    return data.collection;
  }, [user?.id]);

  const updateCollection = useCallback(async (id: string, updates: Partial<Collection>) => {
    if (!user?.id) throw new Error('Must be logged in');

    const res = await fetch(`${API_BASE}/user/collections/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        ...authHeaders(user.id),
      },
      body: JSON.stringify(updates),
    });

    if (!res.ok) throw new Error('Failed to update collection');

    const data = await res.json();
    setCollections(prev => prev.map(c => c.id === id ? data.collection : c));
  }, [user?.id]);

  const deleteCollection = useCallback(async (id: string) => {
    if (!user?.id) throw new Error('Must be logged in');

    const res = await fetch(`${API_BASE}/user/collections/${id}`, {
      method: 'DELETE',
      headers: authHeaders(user.id),
    });

    if (!res.ok) throw new Error('Failed to delete collection');

    setCollections(prev => prev.filter(c => c.id !== id));
  }, [user?.id]);

  const addToCollection = useCallback(async (collectionId: string, itemId: string, itemType: 'event' | 'venue') => {
    if (!user?.id) throw new Error('Must be logged in');

    const res = await fetch(`${API_BASE}/user/collections/${collectionId}/items`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...authHeaders(user.id),
      },
      body: JSON.stringify({ itemId, itemType }),
    });

    if (!res.ok) {
      const error = await res.json();
      throw new Error(error.error || 'Failed to add to collection');
    }

    const data = await res.json();
    setCollections(prev => prev.map(c => c.id === collectionId ? data.collection : c));
  }, [user?.id]);

  const removeFromCollection = useCallback(async (collectionId: string, itemId: string) => {
    if (!user?.id) throw new Error('Must be logged in');

    const res = await fetch(`${API_BASE}/user/collections/${collectionId}/items/${itemId}`, {
      method: 'DELETE',
      headers: authHeaders(user.id),
    });

    if (!res.ok) throw new Error('Failed to remove from collection');

    const data = await res.json();
    setCollections(prev => prev.map(c => c.id === collectionId ? data.collection : c));
  }, [user?.id]);

  const isInCollection = useCallback((collectionId: string, itemId: string) => {
    const collection = collections.find(c => c.id === collectionId);
    return collection?.items.some(item => item.id === itemId) || false;
  }, [collections]);

  const isInAnyCollection = useCallback((itemId: string) => {
    return collections.some(c => c.items.some(item => item.id === itemId));
  }, [collections]);

  const quickSave = useCallback(async (itemId: string, itemType: 'event' | 'venue') => {
    const quickSaveCollection = collections.find(c => c.name === QUICK_SAVE_NAME);
    if (quickSaveCollection) {
      await addToCollection(quickSaveCollection.id, itemId, itemType);
    } else {
      const newCollection = await createCollection(QUICK_SAVE_NAME, 'Quickly save events and venues for later', true);
      await addToCollection(newCollection.id, itemId, itemType);
    }
  }, [collections, addToCollection, createCollection]);

  const isQuickSaved = useCallback((itemId: string) => {
    const quickSaveCollection = collections.find(c => c.name === QUICK_SAVE_NAME);
    return quickSaveCollection ? isInCollection(quickSaveCollection.id, itemId) : false;
  }, [collections, isInCollection]);

  const toggleQuickSave = useCallback(async (itemId: string, itemType: 'event' | 'venue') => {
    if (isQuickSaved(itemId)) {
      const quickSaveCollection = collections.find(c => c.name === QUICK_SAVE_NAME);
      if (quickSaveCollection) {
        await removeFromCollection(quickSaveCollection.id, itemId);
      }
    } else {
      await quickSave(itemId, itemType);
    }
  }, [collections, removeFromCollection, quickSave, isQuickSaved]);

  const getQuickSaveCollection = useCallback(() => {
    return collections.find(c => c.name === QUICK_SAVE_NAME);
  }, [collections]);

  const allSavedItemIds = useMemo(() => {
    const ids = new Set<string>();
    for (const c of collections) {
      for (const item of c.items) {
        ids.add(item.id);
      }
    }
    return ids;
  }, [collections]);

  const refresh = useCallback(async () => {
    await fetchCollections();
  }, [fetchCollections]);

  return (
    <CollectionsContext.Provider value={{
      collections,
      loading,
      createCollection,
      updateCollection,
      deleteCollection,
      addToCollection,
      removeFromCollection,
      isInCollection,
      isInAnyCollection,
      quickSave,
      isQuickSaved,
      toggleQuickSave,
      getQuickSaveCollection,
      allSavedItemIds,
      refresh,
    }}>
      {children}
    </CollectionsContext.Provider>
  );
}

export function useCollections() {
  return useContext(CollectionsContext);
}