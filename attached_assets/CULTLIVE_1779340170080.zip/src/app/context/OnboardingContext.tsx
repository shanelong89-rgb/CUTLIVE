import { createContext, useContext, type ReactNode } from 'react';
import { useWelcomeOverlay } from '../components/WelcomeOverlay';

interface OnboardingContextType {
  showWelcome: boolean;
  dismissWelcome: () => void;
  resetWelcome: () => void;
}

const OnboardingContext = createContext<OnboardingContextType>({
  showWelcome: false,
  dismissWelcome: () => {},
  resetWelcome: () => {},
});

export function OnboardingProvider({ children }: { children: ReactNode }) {
  const { showWelcome, dismiss, reset } = useWelcomeOverlay();

  return (
    <OnboardingContext.Provider
      value={{ showWelcome, dismissWelcome: dismiss, resetWelcome: reset }}
    >
      {children}
    </OnboardingContext.Provider>
  );
}

export function useOnboarding() {
  return useContext(OnboardingContext);
}
