import React, { createContext, useContext, useState, useEffect, useCallback, useRef, type ReactNode } from 'react';
import { projectId, publicAnonKey } from '../config/supabase';
import { type Venue, type CulturalEvent, type Recap } from '../data/mock-data';
import { computeEventStatus } from '../utils/date-helpers';

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-d507b98c`;
const CMS_BASE = `${API_BASE}/cms`;

const EXPECTED_SEED_VERSION = 4; // Must match server SEED_VERSION

// Map submission categories → CULTIVE mode tags so they appear in mode-specific views
const CATEGORY_TO_MODE_TAGS: Record<string, string[]> = {
  'run-clubs': ['lifestyle'],
  'wellness': ['lifestyle'],
  'hikes': ['lifestyle'],
  'coffee-raves': ['lifestyle', 'foodie'],
  'workshops': ['lifestyle', 'artsy'],
  'meetups': ['lifestyle'],
  'nightlife': ['degen'],
  'art': ['artsy'],
  'food': ['foodie'],
  'family': ['family'],
  'other': ['lifestyle'],
};

// Normalize raw price values from submissions (e.g. "150" → "HK$150", "150%" → "HK$150")
function normalizePrice(price: string | undefined): string {
  if (!price) return 'Free';
  const trimmed = price.trim();
  if (!trimmed) return 'Free';
  if (/^free$/i.test(trimmed)) return 'Free';
  if (/^[HK$£€¥]/.test(trimmed) || trimmed.startsWith('HK$')) return trimmed;
  const numMatch = trimmed.match(/^(\d[\d,]*(?:\.\d{1,2})?)(%)?$/);
  if (numMatch) return `HK$${numMatch[1]}`;
  return trimmed;
}

interface DataContextType {
  venues: Venue[];
  events: CulturalEvent[];
  allEvents: CulturalEvent[]; // includes past events even when hidePastEvents is on
  recaps: Recap[];
  loading: boolean;
  error: string | null;
  source: 'supabase' | 'loading';
  refresh: () => Promise<void>;
  hidePastEvents: boolean;
  setHidePastEvents: (v: boolean) => void;
}

const DataContext = createContext<DataContextType>({
  venues: [],
  events: [],
  allEvents: [],
  recaps: [],
  loading: false,
  error: null,
  source: 'loading',
  refresh: async () => {},
  hidePastEvents: false,
  setHidePastEvents: () => {},
});

async function apiFetch(path: string, signal?: AbortSignal) {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { Authorization: `Bearer ${publicAnonKey}` },
    signal,
  });
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`API ${path} failed (${res.status}): ${body}`);
  }
  return res.json();
}

async function apiPost(path: string, body?: any, signal?: AbortSignal) {
  const res = await fetch(`${API_BASE}${path}`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${publicAnonKey}`,
      'Content-Type': 'application/json',
    },
    body: body ? JSON.stringify(body) : undefined,
    signal,
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`API POST ${path} failed (${res.status}): ${text}`);
  }
  return res.json();
}

// ─── Session cache for stale-while-revalidate ───
const CACHE_KEY = 'cultive_data_cache';
const CACHE_TTL = 5 * 60 * 1000; // 5 minutes

interface CachedData {
  venues: Venue[];
  events: CulturalEvent[];
  recaps: Recap[];
  timestamp: number;
}

function getCachedData(): CachedData | null {
  try {
    const raw = sessionStorage.getItem(CACHE_KEY);
    if (!raw) return null;
    const cached = JSON.parse(raw) as CachedData;
    // Return cache even if stale — we'll revalidate in background
    if (cached.venues?.length > 0 || cached.events?.length > 0) return cached;
    return null;
  } catch { return null; }
}

function setCachedData(data: Omit<CachedData, 'timestamp'>) {
  try {
    sessionStorage.setItem(CACHE_KEY, JSON.stringify({ ...data, timestamp: Date.now() }));
  } catch { /* sessionStorage full or unavailable */ }
}

export function DataProvider({ children }: { children: ReactNode }) {
  // ── Initialise from session cache for instant render ──
  const cached = getCachedData();
  const [venues, setVenues] = useState<Venue[]>(cached?.venues || []);
  const [events, setEvents] = useState<CulturalEvent[]>(cached?.events || []);
  const [recaps, setRecaps] = useState<Recap[]>(cached?.recaps || []);
  const [loading, setLoading] = useState(!cached); // not loading if we have cache
  const [error, setError] = useState<string | null>(null);
  const [source, setSource] = useState<'supabase' | 'loading'>(cached ? 'supabase' : 'loading');
  const [hidePastEvents, setHidePastEventsRaw] = useState<boolean>(() => {
    try { return localStorage.getItem('cultive_hide_past') === '1'; } catch { return false; }
  });

  const setHidePastEvents = useCallback((v: boolean) => {
    setHidePastEventsRaw(v);
    try { localStorage.setItem('cultive_hide_past', v ? '1' : '0'); } catch {}
  }, []);

  const fetchData = useCallback(async (signal?: AbortSignal) => {
    try {
      // If we have cached data already rendered, don't show loading spinner — revalidate silently
      const hasCachedState = !!getCachedData();
      if (!hasCachedState) setLoading(true);
      setError(null);

      // ── Phase 1: Seed check + primary data in parallel ──
      const [statusRes, primaryRes] = await Promise.all([
        apiFetch('/status', signal).catch(() => ({ seeded: false, details: null })),
        Promise.all([
          apiFetch('/venues', signal),
          apiFetch('/events', signal),
          apiFetch('/recaps', signal),
        ]).catch(() => null),
      ]);

      if (signal?.aborted) return;

      // If not seeded, seed and re-fetch primary data
      let venueRes: any, eventRes: any, recapRes: any;
      if (!statusRes.seeded || (statusRes.details && statusRes.details.version !== EXPECTED_SEED_VERSION)) {
        console.log(`[CULTIVE] Database needs seeding (current: ${statusRes.details?.version || 'none'}, expected: v${EXPECTED_SEED_VERSION})`);
        const seedResult = await apiPost('/seed', undefined, signal);
        console.log('[CULTIVE] Seed result:', seedResult);
        if (signal?.aborted) return;
        // Re-fetch after seeding
        [venueRes, eventRes, recapRes] = await Promise.all([
          apiFetch('/venues', signal),
          apiFetch('/events', signal),
          apiFetch('/recaps', signal),
        ]);
      } else if (primaryRes) {
        [venueRes, eventRes, recapRes] = primaryRes;
      } else {
        // Primary fetch failed — try to use cached data instead of crashing
        const fallback = getCachedData();
        if (fallback && (fallback.venues.length > 0 || fallback.events.length > 0)) {
          console.warn('[CULTIVE] Primary fetch failed, using cached data');
          setVenues(fallback.venues);
          setEvents(fallback.events);
          setRecaps(fallback.recaps);
          setSource('supabase');
          setLoading(false);
          return;
        }
        throw new Error('Failed to fetch primary data');
      }

      // ── Phase 2: CMS/secondary data in parallel (non-blocking) ──
      const [cmsEventsRes, cmsVenuesRes, cmsSubmissionsRes, hiddenIdsRes] = await Promise.all([
        apiFetch('/cms/content/event/public', signal).catch(() => ({ items: [] })),
        apiFetch('/cms/content/venue/public', signal).catch(() => ({ items: [] })),
        apiFetch('/cms/submissions/published', signal).catch((err: any) => {
          if (err?.name === 'AbortError') throw err;
          console.warn('[CULTIVE] Failed to fetch published submissions:', err);
          return { submissions: [] };
        }),
        apiFetch('/cms/hidden-ids', signal).catch(() => ({ ids: [] })),
      ]);

      if (signal?.aborted) return;

      // Build set of hidden/deleted event IDs
      const hiddenIds = new Set<string>(hiddenIdsRes.ids || []);

      // ── Merge venues: seeded + CMS-imported (from Bulk Import) ──
      let mergedVenues = venueRes.venues?.length > 0 ? [...venueRes.venues] : [];
      const cmsVenues = cmsVenuesRes.items || [];
      if (cmsVenues.length > 0) {
        const existingVenueIds = new Set(mergedVenues.map((v: any) => v.id));
        for (const cmsVenue of cmsVenues) {
          if (!cmsVenue || !cmsVenue.id) continue;

          // Normalize mode scores: if values > 1, they're on 0-10 scale → convert to 0-1
          if (cmsVenue.modeScores && typeof cmsVenue.modeScores === 'object') {
            const ms = cmsVenue.modeScores;
            const needsNormalize = Object.values(ms).some((v: any) => typeof v === 'number' && v > 1);
            if (needsNormalize) {
              for (const key of Object.keys(ms)) {
                if (typeof ms[key] === 'number') ms[key] = ms[key] / 10;
              }
            }
          }

          // Skip venues without valid coordinates
          if (typeof cmsVenue.lat !== 'number' || typeof cmsVenue.lng !== 'number' ||
              isNaN(cmsVenue.lat) || isNaN(cmsVenue.lng) ||
              cmsVenue.lat === 0 || cmsVenue.lng === 0) {
            console.warn(`[CULTIVE] Skipping CMS venue "${cmsVenue.name}" — invalid coordinates (${cmsVenue.lat}, ${cmsVenue.lng})`);
            continue;
          }

          const idx = mergedVenues.findIndex((v: any) => v.id === cmsVenue.id);
          if (idx >= 0) {
            // CMS override — merge fields on top of seeded data
            mergedVenues[idx] = { ...mergedVenues[idx], ...cmsVenue };
          } else {
            // New venue from Bulk Import — ensure it has all required Venue fields
            mergedVenues.push({
              nameZh: '',
              description: '',
              category: 'venue',
              subcategory: '',
              district: '',
              address: '',
              image: '',
              upcomingEvents: 0,
              pastRecaps: 0,
              vibeTags: [],
              priceRange: 2,
              modeScores: { degen: 0, artsy: 0, foodie: 0, family: 0, lifestyle: 0 },
              ...cmsVenue,
            } as Venue);
            existingVenueIds.add(cmsVenue.id);
          }
        }
        console.log(`[CULTIVE] Merged ${cmsVenues.length} CMS venues (total: ${mergedVenues.length})`);
      }
      setVenues(mergedVenues);
      setSource('supabase');
      if (venueRes.venues?.length > 0 || cmsVenues.length > 0) {
        console.log(`[CULTIVE] Loaded ${mergedVenues.length} venues (${venueRes.venues?.length || 0} seeded + ${cmsVenues.length} CMS)`);
      } else {
        console.log('[CULTIVE] No venues from Supabase');
      }

      // ── Merge events: Supabase seed + CMS content items + published submissions ──
      let mergedEvents = eventRes.events?.length > 0 ? [...eventRes.events] : [];
      const existingIds = new Set(mergedEvents.map((e: any) => e.id));

      // Layer CMS content events on top (override by ID, add new)
      const cmsEvents = cmsEventsRes.items || [];
      for (const cmsEvent of cmsEvents) {
        const idx = mergedEvents.findIndex((e: any) => e.id === cmsEvent.id);
        if (idx >= 0) {
          mergedEvents[idx] = { ...mergedEvents[idx], ...cmsEvent };
        } else {
          mergedEvents.push(cmsEvent);
          existingIds.add(cmsEvent.id);
        }
      }

      // Convert approved submissions → CulturalEvent format and append
      const publishedSubs = cmsSubmissionsRes.submissions || [];
      for (const sub of publishedSubs) {
        if (existingIds.has(sub.id)) continue; // skip duplicates

        // Parse date — submissions may store as "2026-03-14 – 2026-03-16" range
        let startDate = sub.date || sub.dateStart || '';
        let endDate = sub.endDate || sub.dateEnd || '';
        if (startDate.includes('–') || startDate.includes('-–')) {
          const parts = startDate.split(/\s*[–—]\s*/);
          startDate = parts[0]?.trim() || '';
          if (!endDate && parts[1]) endDate = parts[1].trim();
        }

        mergedEvents.push({
          id: sub.id,
          venueId: sub.venueId || '',
          title: sub.title || 'Untitled',
          title_zh: sub.title_zh || '',
          description: sub.description || '',
          description_zh: sub.description_zh || '',
          date: startDate,
          endDate: endDate || undefined,
          time: sub.time || '',
          category: sub.category || 'other',
          categories: Array.isArray(sub.categories) ? sub.categories : (sub.category ? [sub.category] : []),
          image: sub.images?.[0] || '',
          modeTags: (() => {
            // Community submissions appear in ALL modes (neutral already shows everything)
            // Primary mode tags from categories, plus all other modes for cross-visibility
            const ALL_MODES = ['degen', 'artsy', 'foodie', 'family', 'lifestyle'];
            const cats = Array.isArray(sub.categories) && sub.categories.length > 0
              ? sub.categories : [sub.category || 'other'];
            const primaryTags = new Set<string>();
            cats.forEach((c: string) => (CATEGORY_TO_MODE_TAGS[c] || []).forEach(t => primaryTags.add(t)));
            // If no mode tags mapped, include all modes so community events always appear
            // Otherwise still include all modes for maximum visibility
            return primaryTags.size > 0 ? ALL_MODES : ALL_MODES;
          })(),
          price: normalizePrice(sub.price),
          status: computeEventStatus(startDate, endDate),
          featured: false,
          venueName: sub.location || sub.venueName || '',
          venueName_zh: sub.venueName_zh || sub.location_zh || '',
          district: sub.district || '',
          district_zh: sub.district_zh || '',
          lat: sub.lat ? parseFloat(sub.lat) : undefined,
          lng: sub.lng ? parseFloat(sub.lng) : undefined,
        } as CulturalEvent);
        existingIds.add(sub.id);
      }

      // Filter out hidden/deleted events
      if (hiddenIds.size > 0) {
        const beforeCount = mergedEvents.length;
        mergedEvents = mergedEvents.filter((e: any) => !hiddenIds.has(e.id));
        const removed = beforeCount - mergedEvents.length;
        if (removed > 0) {
          console.log(`[CULTIVE] Filtered out ${removed} hidden/deleted events`);
        }
      }

      // ── Normalise: ensure every event has modeTags (RA-imported events use "modes") ──
      mergedEvents = mergedEvents.map((e: any) => {
        if (!Array.isArray(e.modeTags)) {
          const fallback = Array.isArray(e.modes) && e.modes.length > 0
            ? e.modes
            : ['lifestyle'];
          return { ...e, modeTags: fallback };
        }
        return e;
      });

      // ── Dynamically compute event status based on current HK date ──
      mergedEvents = mergedEvents.map((e: any) => ({
        ...e,
        status: computeEventStatus(e.date, e.endDate),
      }));

      setEvents(mergedEvents);
      if (cmsEvents.length > 0 || publishedSubs.length > 0) {
        console.log(`[CULTIVE] Merged events: ${mergedEvents.length} total (${cmsEvents.length} CMS, ${publishedSubs.length} submissions)`);
      }

      if (recapRes.recaps?.length > 0) {
        setRecaps(recapRes.recaps);
        console.log(`[CULTIVE] Loaded ${recapRes.recaps.length} recaps from Supabase`);
      }

      // ── Auto-populate recaps from published recap submissions ──
      // Build lookup maps for venueId resolution
      const eventLookup = new Map<string, any>();
      mergedEvents.forEach((e: any) => eventLookup.set(e.id, e));

      // Build venue name → id map for fuzzy matching (lowercase, trimmed)
      const venueNameMap = new Map<string, string>();
      mergedVenues.forEach((v: any) => {
        if (v.name) venueNameMap.set(v.name.toLowerCase().trim(), v.id);
        if (v.nameZh) venueNameMap.set(v.nameZh.toLowerCase().trim(), v.id);
      });

      const recapSubs = publishedSubs.filter((s: any) => s.type === 'recap' || s.category === 'recap');
      if (recapSubs.length > 0) {
        const existingRecapIds = new Set((recapRes.recaps || []).map((r: any) => r.id));
        const newRecaps: Recap[] = recapSubs
          .filter((s: any) => !existingRecapIds.has(s.id))
          .map((s: any) => {
            // Inherit venueId from the linked event if the submission doesn't have one
            const linkedEvent = s.eventId ? eventLookup.get(s.eventId) : null;
            let resolvedVenueId = s.venueId || linkedEvent?.venueId || '';

            // Auto-match by venue name if still unresolved
            if (!resolvedVenueId) {
              const venueName = s.eventVenue || s.venueName || linkedEvent?.venueName || '';
              if (venueName) {
                const matched = venueNameMap.get(venueName.toLowerCase().trim());
                if (matched) {
                  resolvedVenueId = matched;
                  console.log(`[CULTIVE] Auto-matched recap "${s.eventTitle || s.id}" to venue "${venueName}" → ${matched}`);
                }
              }
            }

            return {
            id: s.id,
            eventId: s.eventId || '',
            venueId: resolvedVenueId,
            source: s.source || 'community',
            thumbnail: s.heroImage || (Array.isArray(s.images) ? s.images.find((u: string) => !/\.(mp4|mov|webm|m4v|avi)(\?|$)/i.test(u)) : '') || s.images?.[0] || '',
            caption: s.description || '',
            caption_zh: s.description_zh || '',
            engagement: 0,
            modeScores: {},
            capturedAt: s.publishedAt || s.createdAt || new Date().toISOString(),
            eventTitle: s.eventTitle || s.title?.replace(/^Recap:\s*/i, '') || '',
            media: Array.isArray(s.images) ? s.images : [],
            contributorName: s.contributorName || '',
          };
        });
        const allRecaps = [...(recapRes.recaps || []), ...newRecaps];
        setRecaps(allRecaps);
        if (newRecaps.length > 0) {
          console.log(`[CULTIVE] Auto-populated ${newRecaps.length} recaps from published submissions (total: ${allRecaps.length})`);
        }
      }

      // ── Cache the fetched data for stale-while-revalidate on next page load ──
      setCachedData({ venues: mergedVenues, events: mergedEvents, recaps: recapRes.recaps || [] });
    } catch (err: any) {
      if (err?.name === 'AbortError') return; // Component unmounted, ignore
      console.error('[CULTIVE] Error loading data from Supabase:', err);
      setError(err.message);
      // Empty arrays remain as initial state — no client-side mock data
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    const controller = new AbortController();
    fetchData(controller.signal);
    return () => controller.abort();
  }, [fetchData]);

  // Apply past-event filter (auto-hide past events from main listings)
  let filteredEvents = events;
  if (hidePastEvents) {
    filteredEvents = events.filter(e => e.status !== 'past');
  }

  // allEvents always includes past events (for venue detail pages)
  const allEvents = events;

  return (
    <DataContext.Provider value={{ venues, events: filteredEvents, allEvents, recaps, loading, error, source, refresh: fetchData, hidePastEvents, setHidePastEvents }}>
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  return useContext(DataContext);
}