import { createContext, useContext, useState, type ReactNode } from 'react';

export type TimePeriod = 'all' | 'today' | 'week' | 'month';

interface TimePeriodContextType {
  timePeriod: TimePeriod;
  setTimePeriod: (period: TimePeriod) => void;
}

const TimePeriodContext = createContext<TimePeriodContextType>({
  timePeriod: 'all',
  setTimePeriod: () => {},
});

export function TimePeriodProvider({ children }: { children: ReactNode }) {
  const [timePeriod, setTimePeriod] = useState<TimePeriod>('all');
  return (
    <TimePeriodContext.Provider value={{ timePeriod, setTimePeriod }}>
      {children}
    </TimePeriodContext.Provider>
  );
}

export function useTimePeriod() {
  return useContext(TimePeriodContext);
}
