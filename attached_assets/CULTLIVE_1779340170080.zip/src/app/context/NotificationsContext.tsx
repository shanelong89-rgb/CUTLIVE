import React, { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from 'react';
import { useAuth } from './AuthContext';
import { projectId, publicAnonKey } from '../config/supabase';

const SUPABASE_URL = `https://${projectId}.supabase.co`;
const API_BASE = `${SUPABASE_URL}/functions/v1/make-server-d507b98c`;

// Our custom server routes identify the user via X-User-Id, not by JWT.
// Always use publicAnonKey so we never hit token timing / expiry issues.
const authHeaders = (userId: string) => ({
  'Authorization': `Bearer ${publicAnonKey}`,
  'X-User-Id': userId,
});

export interface Notification {
  id: string;
  type: 'event_reminder' | 'new_event' | 'collection_shared' | 'system';
  title: string;
  message: string;
  actionUrl: string | null;
  metadata: Record<string, any>;
  read: boolean;
  readAt?: string;
  createdAt: string;
}

export interface NotificationSettings {
  upcomingEvents: boolean;
  newEvents: boolean;
  savedEventReminders: boolean;
  collectionUpdates: boolean;
  emailNotifications: boolean;
}

interface NotificationsContextType {
  notifications: Notification[];
  unreadCount: number;
  settings: NotificationSettings;
  loading: boolean;
  markAsRead: (notificationIds: string[]) => Promise<void>;
  deleteNotification: (id: string) => Promise<void>;
  updateSettings: (newSettings: Partial<NotificationSettings>) => Promise<void>;
  refresh: () => Promise<void>;
  checkUpcomingEvents: () => Promise<void>;
}

const NotificationsContext = createContext<NotificationsContextType>({
  notifications: [],
  unreadCount: 0,
  settings: {
    upcomingEvents: true,
    newEvents: true,
    savedEventReminders: true,
    collectionUpdates: false,
    emailNotifications: false,
  },
  loading: true,
  markAsRead: async () => {},
  deleteNotification: async () => {},
  updateSettings: async () => {},
  refresh: async () => {},
  checkUpcomingEvents: async () => {},
});

export function NotificationsProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [settings, setSettings] = useState<NotificationSettings>({
    upcomingEvents: true,
    newEvents: true,
    savedEventReminders: true,
    collectionUpdates: false,
    emailNotifications: false,
  });
  const [loading, setLoading] = useState(true);

  const fetchNotifications = useCallback(async () => {
    if (!user?.id) {
      setNotifications([]);
      setLoading(false);
      return;
    }

    try {
      const res = await fetch(`${API_BASE}/user/notifications`, {
        headers: authHeaders(user.id),
      });

      if (res.ok) {
        const data = await res.json();
        setNotifications(data.notifications || []);
      }
    } catch (err) {
      console.error('Error fetching notifications:', err);
    } finally {
      setLoading(false);
    }
  }, [user?.id]);

  const fetchSettings = useCallback(async () => {
    if (!user?.id) return;

    try {
      const res = await fetch(`${API_BASE}/user/notification-settings`, {
        headers: authHeaders(user.id),
      });

      if (res.ok) {
        const data = await res.json();
        setSettings(data.settings);
      }
    } catch (err) {
      console.error('Error fetching notification settings:', err);
    }
  }, [user?.id]);

  useEffect(() => {
    if (!user?.id) return;
    // Fetch existing notifications first, then check for new upcoming reminders
    fetchNotifications().then(() => {
      // Slight delay so we don't hammer the server on initial load
      setTimeout(() => checkUpcomingEvents(), 1500);
    });
    fetchSettings();
  }, [fetchNotifications, fetchSettings, user?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  const unreadCount = notifications.filter(n => !n.read).length;

  const markAsRead = useCallback(async (notificationIds: string[]) => {
    if (!user?.id) return;

    try {
      const res = await fetch(`${API_BASE}/user/notifications/mark-read`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...authHeaders(user.id),
        },
        body: JSON.stringify({ notificationIds }),
      });

      if (res.ok) {
        setNotifications(prev =>
          prev.map(n =>
            notificationIds.includes(n.id)
              ? { ...n, read: true, readAt: new Date().toISOString() }
              : n
          )
        );
      }
    } catch (err) {
      console.error('Error marking notifications as read:', err);
    }
  }, [user?.id]);

  const deleteNotification = useCallback(async (id: string) => {
    if (!user?.id) return;

    try {
      const res = await fetch(`${API_BASE}/user/notifications/${id}`, {
        method: 'DELETE',
        headers: authHeaders(user.id),
      });

      if (res.ok) {
        setNotifications(prev => prev.filter(n => n.id !== id));
      }
    } catch (err) {
      console.error('Error deleting notification:', err);
    }
  }, [user?.id]);

  const updateSettings = useCallback(async (newSettings: Partial<NotificationSettings>) => {
    if (!user?.id) return;

    const updated = { ...settings, ...newSettings };

    try {
      const res = await fetch(`${API_BASE}/user/notification-settings`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...authHeaders(user.id),
        },
        body: JSON.stringify(updated),
      });

      if (res.ok) {
        setSettings(updated);
      }
    } catch (err) {
      console.error('Error updating notification settings:', err);
    }
  }, [user?.id, settings]);

  const refresh = useCallback(async () => {
    await fetchNotifications();
    await fetchSettings();
  }, [fetchNotifications, fetchSettings]);

  // ─── Check upcoming saved events and generate reminder notifications ───
  const checkUpcomingEvents = useCallback(async () => {
    if (!user?.id) return;

    try {
      const res = await fetch(`${API_BASE}/notifications/check-upcoming`, {
        method: 'POST',
        headers: authHeaders(user.id),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.created > 0) {
          // Refresh the notification list to include newly generated reminders
          await fetchNotifications();
          console.log(`Generated ${data.created} event reminder(s) for upcoming saved events`);
        }
      }
    } catch (err) {
      console.error('Error checking upcoming events for notifications:', err);
    }
  }, [user?.id, fetchNotifications]);

  return (
    <NotificationsContext.Provider value={{
      notifications,
      unreadCount,
      settings,
      loading,
      markAsRead,
      deleteNotification,
      updateSettings,
      refresh,
      checkUpcomingEvents,
    }}>
      {children}
    </NotificationsContext.Provider>
  );
}

export function useNotifications() {
  return useContext(NotificationsContext);
}