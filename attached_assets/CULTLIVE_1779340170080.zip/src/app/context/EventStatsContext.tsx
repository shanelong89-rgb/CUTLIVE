/**
 * EventStatsContext — tracks event view counts, save (\"going\") counts, and share counts.
 * Provides:
 *  - trackView(eventId)   → fire-and-forget view increment
 *  - trackSave(eventId)   → increment save count
 *  - trackUnsave(eventId) → decrement save count
 *  - trackShare(eventId)  → increment share count
 *  - getStats(eventId)    → { views, saves, shares } or null
 *  - fetchBatchStats(ids) → load stats for multiple events at once
 */
import { createContext, useContext, useCallback, useRef, useState } from 'react';
import { projectId, publicAnonKey } from '../config/supabase';

const API = `https://${projectId}.supabase.co/functions/v1/make-server-d507b98c`;
const HEADERS = { 'Content-Type': 'application/json', 'Authorization': `Bearer ${publicAnonKey}` };

export interface EventStats {
  views: number;
  saves: number;
  shares: number;
}

interface EventStatsContextType {
  /** Record a view (fire once per page visit) */
  trackView: (eventId: string) => void;
  /** Increment save count (call when user saves) */
  trackSave: (eventId: string) => void;
  /** Decrement save count (call when user unsaves) */
  trackUnsave: (eventId: string) => void;
  /** Increment share count (call when user shares) */
  trackShare: (eventId: string, platform?: string) => void;
  /** Get cached stats for an event (null if not loaded) */
  getStats: (eventId: string) => EventStats | null;
  /** Load stats for one event from server */
  fetchStats: (eventId: string) => Promise<EventStats>;
  /** Load stats for a batch of events */
  fetchBatchStats: (eventIds: string[]) => Promise<void>;
  /** The entire cache (for reactivity) */
  statsCache: Record<string, EventStats>;
}

const EventStatsContext = createContext<EventStatsContextType>({
  trackView: () => {},
  trackSave: () => {},
  trackUnsave: () => {},
  trackShare: () => {},
  getStats: () => null,
  fetchStats: async () => ({ views: 0, saves: 0, shares: 0 }),
  fetchBatchStats: async () => {},
  statsCache: {},
});

export function EventStatsProvider({ children }: { children: React.ReactNode }) {
  const [statsCache, setStatsCache] = useState<Record<string, EventStats>>({});
  const viewedRef = useRef<Set<string>>(new Set()); // dedupe views per session

  const updateCache = useCallback((eventId: string, partial: Partial<EventStats>) => {
    setStatsCache(prev => ({
      ...prev,
      [eventId]: {
        views: partial.views ?? prev[eventId]?.views ?? 0,
        saves: partial.saves ?? prev[eventId]?.saves ?? 0,
        shares: partial.shares ?? prev[eventId]?.shares ?? 0,
      },
    }));
  }, []);

  const trackView = useCallback((eventId: string) => {
    if (viewedRef.current.has(eventId)) return; // already tracked this session
    viewedRef.current.add(eventId);
    // Optimistic increment
    setStatsCache(prev => {
      const existing = prev[eventId] || { views: 0, saves: 0, shares: 0 };
      return { ...prev, [eventId]: { ...existing, views: existing.views + 1 } };
    });
    fetch(`${API}/events/track-view`, {
      method: 'POST', headers: HEADERS,
      body: JSON.stringify({ eventId }),
    }).then(r => r.json()).then(data => {
      if (typeof data.views === 'number') {
        updateCache(eventId, { views: data.views });
      }
    }).catch(err => console.log('Error tracking view:', err));
  }, [updateCache]);

  const trackSave = useCallback((eventId: string) => {
    setStatsCache(prev => {
      const existing = prev[eventId] || { views: 0, saves: 0, shares: 0 };
      return { ...prev, [eventId]: { ...existing, saves: existing.saves + 1 } };
    });
    fetch(`${API}/events/track-save`, {
      method: 'POST', headers: HEADERS,
      body: JSON.stringify({ eventId, action: 'save' }),
    }).then(r => r.json()).then(data => {
      if (typeof data.saves === 'number') updateCache(eventId, { saves: data.saves });
    }).catch(err => console.log('Error tracking save:', err));
  }, [updateCache]);

  const trackUnsave = useCallback((eventId: string) => {
    setStatsCache(prev => {
      const existing = prev[eventId] || { views: 0, saves: 0, shares: 0 };
      return { ...prev, [eventId]: { ...existing, saves: Math.max(0, existing.saves - 1) } };
    });
    fetch(`${API}/events/track-save`, {
      method: 'POST', headers: HEADERS,
      body: JSON.stringify({ eventId, action: 'unsave' }),
    }).then(r => r.json()).then(data => {
      if (typeof data.saves === 'number') updateCache(eventId, { saves: data.saves });
    }).catch(err => console.log('Error tracking unsave:', err));
  }, [updateCache]);

  const trackShare = useCallback((eventId: string, platform?: string) => {
    // Optimistic increment
    setStatsCache(prev => {
      const existing = prev[eventId] || { views: 0, saves: 0, shares: 0 };
      return { ...prev, [eventId]: { ...existing, shares: existing.shares + 1 } };
    });
    fetch(`${API}/events/track-share`, {
      method: 'POST', headers: HEADERS,
      body: JSON.stringify({ eventId, platform }),
    }).then(r => r.json()).then(data => {
      if (typeof data.shares === 'number') {
        updateCache(eventId, { shares: data.shares });
      }
    }).catch(err => console.log('Error tracking share:', err));
  }, [updateCache]);

  const getStats = useCallback((eventId: string): EventStats | null => {
    return statsCache[eventId] || null;
  }, [statsCache]);

  const fetchStats = useCallback(async (eventId: string): Promise<EventStats> => {
    try {
      const res = await fetch(`${API}/events/stats/${eventId}`, { headers: HEADERS });
      const data = await res.json();
      const stats = { views: data.views || 0, saves: data.saves || 0, shares: data.shares || 0 };
      setStatsCache(prev => ({ ...prev, [eventId]: stats }));
      return stats;
    } catch (err) {
      console.log('Error fetching stats:', err);
      return { views: 0, saves: 0, shares: 0 };
    }
  }, []);

  const fetchBatchStats = useCallback(async (eventIds: string[]) => {
    if (!eventIds.length) return;
    try {
      const res = await fetch(`${API}/events/stats/batch`, {
        method: 'POST', headers: HEADERS,
        body: JSON.stringify({ eventIds }),
      });
      const data = await res.json();
      if (data.stats) {
        setStatsCache(prev => ({ ...prev, ...data.stats }));
      }
    } catch (err) {
      console.log('Error fetching batch stats:', err);
    }
  }, []);

  return (
    <EventStatsContext.Provider value={{ trackView, trackSave, trackUnsave, trackShare, getStats, fetchStats, fetchBatchStats, statsCache }}>
      {children}
    </EventStatsContext.Provider>
  );
}

export function useEventStats() {
  return useContext(EventStatsContext);
}