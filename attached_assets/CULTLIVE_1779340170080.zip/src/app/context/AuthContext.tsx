import React, { createContext, useContext, useState, useEffect, useCallback, useRef, type ReactNode } from 'react';
import { projectId, publicAnonKey } from '../config/supabase';
import { supabase } from '../lib/supabase';

const SUPABASE_URL = `https://${projectId}.supabase.co`;
const API_BASE = `${SUPABASE_URL}/functions/v1/make-server-d507b98c`;

// ─── localStorage keys ───
const LS_ANON_SAVED = 'cultive:saved-events';           // anonymous saves
const lsUserSaved = (uid: string) => `cultive:saved-events:${uid}`;  // user-specific

export interface AuthUser {
  id: string;
  email: string;
  name: string;
}

interface AuthContextType {
  user: AuthUser | null;
  loading: boolean;
  accessToken: string | null;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, name: string) => Promise<void>;
  signOut: () => Promise<void>;
  // Saved events
  savedEventIds: string[];
  savedEventsLoading: boolean;
  toggleSaveEvent: (eventId: string) => void;
  isEventSaved: (eventId: string) => boolean;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  loading: true,
  accessToken: null,
  signIn: async () => {},
  signUp: async () => {},
  signOut: async () => {},
  savedEventIds: [],
  savedEventsLoading: false,
  toggleSaveEvent: () => {},
  isEventSaved: () => false,
});

// ─── Helpers: read/write localStorage safely ───
function lsRead(key: string): string[] {
  try {
    const raw = localStorage.getItem(key);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch {}
  return [];
}

function lsWrite(key: string, ids: string[]) {
  try {
    localStorage.setItem(key, JSON.stringify(ids));
  } catch {}
}

/** Union-merge two arrays of IDs, deduped */
function mergeIds(...arrays: string[][]): string[] {
  return [...new Set(arrays.flat().filter(Boolean))];
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [savedEventIds, setSavedEventIds] = useState<string[]>(() => {
    // Immediately hydrate from anonymous localStorage so saves show on first render
    return lsRead(LS_ANON_SAVED);
  });
  const [savedEventsLoading, setSavedEventsLoading] = useState(false);

  // Refs for latest values (avoids stale closures in callbacks)
  const accessTokenRef = useRef(accessToken);
  const userRef = useRef(user);
  const savedRef = useRef(savedEventIds);
  useEffect(() => { accessTokenRef.current = accessToken; }, [accessToken]);
  useEffect(() => { userRef.current = user; }, [user]);
  useEffect(() => { savedRef.current = savedEventIds; }, [savedEventIds]);

  // Track whether initial load has run to avoid duplicate fetches
  const initialLoadDone = useRef(false);
  // Track whether a merge is already in-flight to avoid duplicates
  const mergeInFlight = useRef(false);

  // Parse Supabase user into our AuthUser
  const parseUser = (supaUser: any): AuthUser | null => {
    if (!supaUser) return null;
    return {
      id: supaUser.id,
      email: supaUser.email || '',
      name: supaUser.user_metadata?.name || supaUser.email?.split('@')[0] || 'User',
    };
  };

  // ─── Server sync for saved events ───
  // Use publicAnonKey for auth (same pattern as Collections) — the server
  // identifies the user via X-User-Id, not by JWT. This avoids stale/expired
  // token issues that were causing cross-device sync to silently fail.
  const serverFetch = async (userId: string): Promise<string[]> => {
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 6000);
      const res = await fetch(`${API_BASE}/user/saved-events`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'X-User-Id': userId,
        },
        signal: controller.signal,
      });
      clearTimeout(timeout);
      if (res.ok) {
        const data = await res.json();
        console.log(`[Saved] Server fetch for ${userId}: got ${data.eventIds?.length || 0} IDs`);
        return Array.isArray(data.eventIds) ? data.eventIds : [];
      }
      console.log(`[Saved] Server fetch failed with status ${res.status}`);
    } catch (err) {
      console.log('[Saved] Server fetch failed:', err);
    }
    return [];
  };

  const serverPersist = async (userId: string, ids: string[]): Promise<boolean> => {
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 6000);
      const res = await fetch(`${API_BASE}/user/saved-events`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`,
          'X-User-Id': userId,
        },
        body: JSON.stringify({ eventIds: ids }),
        signal: controller.signal,
      });
      clearTimeout(timeout);
      if (res.ok) {
        console.log(`[Saved] Server persisted ${ids.length} saved events for user ${userId}`);
        return true;
      }
      const body = await res.text().catch(() => '');
      console.log(`[Saved] Server persist failed: ${res.status} ${body}`);
    } catch (err) {
      console.log('[Saved] Server persist error:', err);
    }
    return false;
  };

  // Retry queue for failed server saves
  const retryTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const scheduleRetry = useCallback((userId: string, ids: string[], attempt = 1) => {
    if (attempt > 3) {
      console.log('[Saved] Max retries reached, saves are in localStorage only');
      return;
    }
    const delay = Math.min(2000 * Math.pow(2, attempt - 1), 10000); // 2s, 4s, 8s
    console.log(`[Saved] Scheduling retry #${attempt} in ${delay}ms`);
    retryTimeoutRef.current = setTimeout(async () => {
      const success = await serverPersist(userId, ids);
      if (!success) {
        scheduleRetry(userId, ids, attempt + 1);
      }
    }, delay);
  }, []);

  // Clean up retry on unmount
  useEffect(() => {
    return () => {
      if (retryTimeoutRef.current) clearTimeout(retryTimeoutRef.current);
    };
  }, []);

  // ─── Persist saves on page unload (belt & suspenders) ───
  useEffect(() => {
    const handleBeforeUnload = () => {
      const uid = userRef.current?.id;
      const token = accessTokenRef.current;
      const ids = savedRef.current;
      if (uid && ids.length > 0) {
        // Use sendBeacon for reliability during page unload
        const url = `${API_BASE}/user/saved-events`;
        const payload = JSON.stringify({ eventIds: ids, userId: uid });
        try {
          navigator.sendBeacon(
            url,
            new Blob([payload], { type: 'application/json' })
          );
          console.log(`[Saved] Beacon sent ${ids.length} saved events on unload`);
        } catch {
          // sendBeacon doesn't support custom headers, so also try fetch keepalive
          fetch(url, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${token || publicAnonKey}`,
              'X-User-Id': uid,
            },
            body: payload,
            keepalive: true,
          }).catch(() => {});
        }
      }
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, []);

  // ─── Load + merge saved events for a logged-in user ───
  const loadAndMergeSavedEvents = useCallback(async (userId: string) => {
    // Prevent concurrent merges (signIn + onAuthStateChange can both fire)
    if (mergeInFlight.current) {
      console.log('[Saved] Merge already in-flight, skipping duplicate');
      return;
    }
    mergeInFlight.current = true;
    setSavedEventsLoading(true);
    // 1. Gather all local sources
    const anonLocal = lsRead(LS_ANON_SAVED);
    const userLocal = lsRead(lsUserSaved(userId));
    const currentInMemory = savedRef.current;

    // 2. Fetch from server
    const serverIds = await serverFetch(userId);

    // 3. Merge everything — union of all sources, never lose data
    const merged = mergeIds(anonLocal, userLocal, currentInMemory, serverIds);

    console.log(`[Saved] Merged: anon=${anonLocal.length}, userLocal=${userLocal.length}, memory=${currentInMemory.length}, server=${serverIds.length} → total=${merged.length}`);

    // 4. Update state + persist everywhere
    setSavedEventIds(merged);
    lsWrite(lsUserSaved(userId), merged);
    lsWrite(LS_ANON_SAVED, merged); // keep anon in sync too for seamless logout

    // 5. If merged has more than server, push the merged set back
    if (merged.length !== serverIds.length || !merged.every(id => serverIds.includes(id))) {
      const success = await serverPersist(userId, merged);
      if (!success) {
        scheduleRetry(userId, merged);
      }
    }
    setSavedEventsLoading(false);
    mergeInFlight.current = false;
  }, [scheduleRetry]);

  // ─── Load session on mount ───
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data?.session) {
        const parsed = parseUser(data.session.user);
        setUser(parsed);
        setAccessToken(data.session.access_token);

        // Load saved events with the token we just got (avoid stale ref)
        if (parsed?.id && !initialLoadDone.current) {
          initialLoadDone.current = true;
          loadAndMergeSavedEvents(parsed.id);
        }
      } else {
        // Anonymous — already hydrated from localStorage in useState initializer
        initialLoadDone.current = true;
      }
      setLoading(false);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      const parsed = session?.user ? parseUser(session.user) : null;
      setUser(parsed);
      setAccessToken(session?.access_token || null);

      // On login (not on initial load), merge saved events
      if (parsed?.id && initialLoadDone.current) {
        loadAndMergeSavedEvents(parsed.id);
      }
    });

    return () => subscription.unsubscribe();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const signIn = useCallback(async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw error;
    const parsed = parseUser(data.session?.user);
    setUser(parsed);
    setAccessToken(data.session?.access_token || null);

    // Merge anonymous saves into this user's saves
    if (parsed?.id) {
      loadAndMergeSavedEvents(parsed.id);
    }
  }, [loadAndMergeSavedEvents]);

  const signUp = useCallback(async (email: string, password: string, name: string) => {
    // Create user via server (uses service role key for email_confirm: true)
    const res = await fetch(`${API_BASE}/auth/signup`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${publicAnonKey}`,
      },
      body: JSON.stringify({ email, password, name }),
    });
    const result = await res.json();
    if (!res.ok) throw new Error(result.error || 'Signup failed');

    // Auto sign in after signup
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw error;
    const parsed = parseUser(data.session?.user);
    setUser(parsed);
    setAccessToken(data.session?.access_token || null);

    // Migrate anonymous saves
    if (parsed?.id) {
      loadAndMergeSavedEvents(parsed.id);
    }
  }, [loadAndMergeSavedEvents]);

  const signOut = useCallback(async () => {
    // Before signing out, ensure current saves are written to anon localStorage
    const current = savedRef.current;
    lsWrite(LS_ANON_SAVED, current);

    await supabase.auth.signOut();
    setUser(null);
    setAccessToken(null);
    // Don't wipe savedEventIds — keep showing them (they're in anon localStorage)
  }, []);

  const toggleSaveEvent = useCallback((eventId: string) => {
    setSavedEventIds(prev => {
      const next = prev.includes(eventId)
        ? prev.filter(id => id !== eventId)
        : [...prev, eventId];

      // Always write to anon localStorage (works for everyone)
      lsWrite(LS_ANON_SAVED, next);

      const uid = userRef.current?.id;

      if (uid) {
        // Also write to user-specific localStorage
        lsWrite(lsUserSaved(uid), next);

        // Persist to server with retry
        serverPersist(uid, next).then(success => {
          if (!success) {
            scheduleRetry(uid, next);
          }
        });
      }

      return next;
    });
  }, [scheduleRetry]);

  const isEventSaved = useCallback((eventId: string) => {
    return savedEventIds.includes(eventId);
  }, [savedEventIds]);

  return (
    <AuthContext.Provider value={{
      user,
      loading,
      accessToken,
      signIn,
      signUp,
      signOut,
      savedEventIds,
      savedEventsLoading,
      toggleSaveEvent,
      isEventSaved,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}