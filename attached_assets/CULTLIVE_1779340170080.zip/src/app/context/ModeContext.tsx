import React, { createContext, useContext, useState, type ReactNode } from 'react';
import type { Mode } from '../data/mock-data';

// UIMode extends the data Mode with lifestyle (which has its own page/data, not tied to venue modeScores)
export type UIMode = Mode | 'lifestyle';

interface ModeContextType {
  currentMode: UIMode | null;
  setMode: (mode: UIMode | null) => void;
}

const ModeContext = createContext<ModeContextType>({
  currentMode: null,
  setMode: () => {},
});

export function ModeProvider({ children }: { children: ReactNode }) {
  const [currentMode, setCurrentMode] = useState<UIMode | null>(null);

  return (
    <ModeContext.Provider value={{ currentMode, setMode: setCurrentMode }}>
      {children}
    </ModeContext.Provider>
  );
}

export function useMode() {
  return useContext(ModeContext);
}