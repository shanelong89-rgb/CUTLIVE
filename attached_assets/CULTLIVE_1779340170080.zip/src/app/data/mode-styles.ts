import type { Mode } from './mock-data';
import type { UIMode } from '../context/ModeContext';

export interface ModeDesignTokens {
  // Background
  pageBg: string;
  surfaceBg: string;
  cardBg: string;
  cardBorder: string;
  // Text
  textPrimary: string;
  textSecondary: string;
  textMuted: string;
  textAccent: string;
  // Typography
  headingFont: string;
  bodyFont: string;
  // Nav
  navBg: string;
  navBorder: string;
  navText: string;
  navTextActive: string;
  // Layout style
  borderRadius: string;
  cardRadius: string;
  imageRadius: string;
  // Spacing
  spacingScale: number; // 1 = normal, 1.5 = generous
  // Character
  aesthetic: 'dark-neon' | 'editorial-minimal' | 'warm-playful' | 'rich-magazine' | 'bold-poster' | 'lifestyle-bold';
  invertLogo: boolean;
}

export const modeDesignTokens: Record<Mode, ModeDesignTokens> & Record<'lifestyle', ModeDesignTokens> = {
  degen: {
    pageBg: '#EDFF00',
    surfaceBg: '#E5F500',
    cardBg: '#0A0A0A',
    cardBorder: 'rgba(0,0,0,0.08)',
    textPrimary: '#0A0A0A',
    textSecondary: '#333333',
    textMuted: '#666666',
    textAccent: '#D600FF',
    headingFont: "'Space Grotesk', sans-serif",
    bodyFont: "'Inter', sans-serif",
    navBg: 'rgba(237, 255, 0, 0.94)',
    navBorder: 'rgba(0,0,0,0.08)',
    navText: 'rgba(0,0,0,0.4)',
    navTextActive: '#0A0A0A',
    borderRadius: '4px',
    cardRadius: '6px',
    imageRadius: '4px',
    spacingScale: 1,
    aesthetic: 'bold-poster',
    invertLogo: true,
  },

  artsy: {
    pageBg: '#F5F1EB',
    surfaceBg: '#EFEBE4',
    cardBg: '#ffffff',
    cardBorder: 'rgba(0,0,0,0.08)',
    textPrimary: '#1a1a1a',
    textSecondary: '#4a4a4a',
    textMuted: '#8a8a8a',
    textAccent: '#3d2b7a',
    headingFont: "'Playfair Display', serif",
    bodyFont: "'Cormorant Garamond', serif",
    navBg: 'rgba(245, 241, 235, 0.92)',
    navBorder: 'rgba(0,0,0,0.06)',
    navText: '#8a8a8a',
    navTextActive: '#1a1a1a',
    borderRadius: '2px',
    cardRadius: '0px',
    imageRadius: '0px',
    spacingScale: 1.5,
    aesthetic: 'editorial-minimal',
    invertLogo: true,
  },

  family: {
    pageBg: '#FFF8F0',
    surfaceBg: '#FFF2E8',
    cardBg: '#FFFFFF',
    cardBorder: 'rgba(0,0,0,0.06)',
    textPrimary: '#2D2A32',
    textSecondary: '#6B6574',
    textMuted: '#A39DAE',
    textAccent: '#FF8C42',
    headingFont: "'Nunito', sans-serif",
    bodyFont: "'Nunito', sans-serif",
    navBg: 'rgba(255, 248, 240, 0.92)',
    navBorder: 'rgba(0,0,0,0.05)',
    navText: '#A39DAE',
    navTextActive: '#2D2A32',
    borderRadius: '28px',
    cardRadius: '32px',
    imageRadius: '28px',
    spacingScale: 1.2,
    aesthetic: 'warm-playful',
    invertLogo: true,
  },

  foodie: {
    pageBg: '#0A1220',
    surfaceBg: '#0E1A2E',
    cardBg: '#122240',
    cardBorder: 'rgba(37,99,235,0.12)',
    textPrimary: '#E8F0FF',
    textSecondary: 'rgba(232,240,255,0.7)',
    textMuted: 'rgba(232,240,255,0.4)',
    textAccent: '#2563EB',
    headingFont: "'DM Sans', sans-serif",
    bodyFont: "'DM Sans', sans-serif",
    navBg: 'rgba(10, 18, 32, 0.92)',
    navBorder: 'rgba(37,99,235,0.08)',
    navText: 'rgba(232,240,255,0.4)',
    navTextActive: '#E8F0FF',
    borderRadius: '24px',
    cardRadius: '24px',
    imageRadius: '20px',
    spacingScale: 1,
    aesthetic: 'rich-magazine',
    invertLogo: false,
  },

  lifestyle: {
    pageBg: '#FAFAF5',
    surfaceBg: '#F2EDE4',
    cardBg: '#1C1C1C',
    cardBorder: 'rgba(45,106,79,0.12)',
    textPrimary: '#0A0A0A',
    textSecondary: '#5A5A5A',
    textMuted: '#8A8580',
    textAccent: '#2D6A4F',
    headingFont: "'Playfair Display', serif",
    bodyFont: "'DM Sans', sans-serif",
    navBg: 'rgba(250, 250, 245, 0.94)',
    navBorder: 'rgba(0,0,0,0.06)',
    navText: '#8A8580',
    navTextActive: '#0A0A0A',
    borderRadius: '16px',
    cardRadius: '20px',
    imageRadius: '16px',
    spacingScale: 1,
    aesthetic: 'lifestyle-bold',
    invertLogo: true,
  },
};

// Default tokens for null mode — clean, light, neutral
export const defaultDesignTokens: ModeDesignTokens = {
  pageBg: '#FAFAF8',
  surfaceBg: '#F3F3F0',
  cardBg: '#FFFFFF',
  cardBorder: 'rgba(0,0,0,0.06)',
  textPrimary: '#1A1A1A',
  textSecondary: '#5A5A5A',
  textMuted: '#9A9A9A',
  textAccent: '#1A1A1A',
  headingFont: "'Inter', sans-serif",
  bodyFont: "'Inter', sans-serif",
  navBg: 'rgba(250, 250, 248, 0.92)',
  navBorder: 'rgba(0,0,0,0.06)',
  navText: '#9A9A9A',
  navTextActive: '#1A1A1A',
  borderRadius: '16px',
  cardRadius: '20px',
  imageRadius: '16px',
  spacingScale: 1,
  aesthetic: 'dark-neon',
  invertLogo: true,
};

export function getDesignTokens(mode: UIMode | null): ModeDesignTokens {
  if (!mode) return defaultDesignTokens;
  return modeDesignTokens[mode];
}

export function isLightMode(mode: UIMode | null): boolean {
  if (!mode) return true;
  const aesthetic = modeDesignTokens[mode].aesthetic;
  return aesthetic === 'editorial-minimal' || aesthetic === 'warm-playful' || aesthetic === 'bold-poster' || aesthetic === 'lifestyle-bold';
}