// ─── Shared Lifestyle Design Tokens & Data ───
// Used by LifestylePage, EventsPage (lifestyle mode), MapPage (lifestyle mode)

import type { LucideIcon } from 'lucide-react';

// ─── Design Tokens (Thrivewell-inspired) ───
export const LC = {
  black: '#0A0A0A',
  white: '#FFFFFF',
  offWhite: '#FAFAF5',
  cream: '#F2EDE4',
  textMuted: '#8A8580',
  textLight: '#B0ACA7',
  forest: '#2D6A4F',
  forestLight: '#40916C',
  sage: '#95D5B2',
  accent: '#2D6A4F',
  deepForest: '#122A20',
  deepForestCard: '#1A3D2E',
  deepForestSurface: '#0F2219',
  deepForestBorder: 'rgba(45,106,79,0.2)',
  deepForestTextLight: 'rgba(149,213,178,0.5)',
};

export const LF = {
  heading: "'Playfair Display', serif",
  body: "'DM Sans', sans-serif",
  mono: "'Space Grotesk', sans-serif",
};

export const PAPER_TEXTURE_URL = 'https://images.unsplash.com/photo-1706271952285-01b5e3fc2d78?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aW50YWdlJTIwcGFwZXIlMjB0ZXh0dXJlJTIwY3JlYW0lMjBwYXJjaG1lbnR8ZW58MXx8fHwxNzczMDQ4NjI3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral';

// ─── Lifestyle Categories ───
export type LifestyleCategory = 'all' | 'run-clubs' | 'wellness' | 'hikes' | 'coffee-raves' | 'workshops' | 'meetups';

export interface CategoryDef {
  key: LifestyleCategory;
  label: string;
  boldLabel: string;
  image: string;
}

export const lifestyleCategories: CategoryDef[] = [
  { key: 'all', label: 'All', boldLabel: 'all.', image: '' },
  { key: 'run-clubs', label: 'Run Clubs', boldLabel: 'run.', image: 'https://images.unsplash.com/photo-1563391885380-20acff25036b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxydW5uaW5nJTIwY2x1YiUyMGdyb3VwJTIwbW9ybmluZ3xlbnwxfHx8fDE3NzMwNDM3NTN8MA&ixlib=rb-4.1.0&q=80&w=1080' },
  { key: 'wellness', label: 'Wellness', boldLabel: 'feel.', image: 'https://images.unsplash.com/photo-1592580715317-19adca36288e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvdXRkb29yJTIweW9nYSUyMHdlbGxuZXNzJTIwc3VucmlzZXxlbnwxfHx8fDE3NzMwNDM3NTN8MA&ixlib=rb-4.1.0&q=80&w=1080' },
  { key: 'hikes', label: 'Hikes', boldLabel: 'explore.', image: 'https://images.unsplash.com/photo-1621511252157-ed34c30e1ba8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoaWtpbmclMjB0cmFpbCUyMEhvbmclMjBLb25nJTIwbmF0dXJlfGVufDF8fHx8MTc3MzA0Mzc1NHww&ixlib=rb-4.1.0&q=80&w=1080' },
  { key: 'coffee-raves', label: 'Coffee Raves', boldLabel: 'gather.', image: 'https://images.unsplash.com/photo-1555069855-e580a9adbf43?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb21tdW5pdHklMjBtZWV0dXAlMjBzb2NpYWwlMjBldmVudHxlbnwxfHx8fDE3NzMwNDM3NTR8MA&ixlib=rb-4.1.0&q=80&w=1080' },
  { key: 'workshops', label: 'Workshops', boldLabel: 'make.', image: 'https://images.unsplash.com/photo-1737564483280-15481c31608a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwb3R0ZXJ5JTIwY2VyYW1pY3MlMjB3b3Jrc2hvcCUyMGhhbmRzfGVufDF8fHx8MTc3Mjk2MTUzMnww&ixlib=rb-4.1.0&q=80&w=1080' },
  { key: 'meetups', label: 'Meetups', boldLabel: 'connect.', image: 'https://images.unsplash.com/photo-1709855256067-12ad9a64ac06?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib29rJTIwY2x1YiUyMHJlYWRpbmclMjBjb3p5fGVufDF8fHx8MTc3Mjk3NTk2NHww&ixlib=rb-4.1.0&q=80&w=1080' },
];

// ─── Lifestyle Events ───
export interface LifestyleEvent {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  category: LifestyleCategory;
  date: string;
  time: string;
  location: string;
  district: string;
  image: string;
  organizer: string;
  capacity: number;
  spotsLeft: number;
  price: string;
  tags: string[];
  recurring: boolean;
  difficulty?: 'easy' | 'moderate' | 'challenging';
  featured: boolean;
  lat?: number;
  lng?: number;
  ticketUrl?: string;
  sourceUrl?: string;
  // Bilingual fields for i18n
  title_zh?: string;
  description_zh?: string;
  subtitle_zh?: string;
  location_zh?: string;
  district_zh?: string;
}

/** Map CulturalEvent category strings to LifestyleCategory */
const CATEGORY_TO_LIFESTYLE: Record<string, LifestyleCategory> = {
  wellness: 'wellness', yoga: 'wellness', meditation: 'wellness', fitness: 'wellness',
  'run-clubs': 'run-clubs', running: 'run-clubs',
  hikes: 'hikes', hiking: 'hikes', outdoors: 'hikes', nature: 'hikes',
  'coffee-raves': 'coffee-raves', coffee: 'coffee-raves',
  workshops: 'workshops', workshop: 'workshops', craft: 'workshops', ceramics: 'workshops',
  meetups: 'meetups', meetup: 'meetups', community: 'meetups', social: 'meetups',
};

/** Convert a CulturalEvent (from main events array) with lifestyle modeTag to LifestyleEvent */
export function culturalEventToLifestyle(e: {
  id: string; title: string; description: string; category: string;
  categories?: string[]; date: string; time: string; image: string;
  price: string; featured: boolean; venueName: string; district: string;
  lat?: number; lng?: number; vibes?: string[]; artists?: string[];
  modeTags?: string[]; ticketUrl?: string; sourceUrl?: string;
  title_zh?: string; description_zh?: string; venueName_zh?: string; district_zh?: string;
}): LifestyleEvent {
  // Try to match category to a lifestyle sub-category
  const rawCat = (e.category || '').toLowerCase().trim();
  let lifeCat: LifestyleCategory = CATEGORY_TO_LIFESTYLE[rawCat] || 'meetups';
  // Also check categories array and vibes for better matching
  if (lifeCat === 'meetups') {
    const allCats = [...(e.categories || []), ...(e.vibes || [])].map(c => c.toLowerCase());
    for (const c of allCats) {
      if (CATEGORY_TO_LIFESTYLE[c]) { lifeCat = CATEGORY_TO_LIFESTYLE[c]; break; }
    }
  }

  return {
    id: e.id,
    title: e.title,
    subtitle: e.venueName || '',
    description: e.description || '',
    category: lifeCat,
    date: e.date,
    time: e.time || '04:00 pm',
    location: e.venueName || e.district || 'Hong Kong',
    district: e.district || '',
    image: e.image || '',
    organizer: e.venueName || 'Community',
    capacity: 50,
    spotsLeft: 30,
    price: e.price || 'Free',
    tags: e.vibes || (e.categories || [e.category]).filter(Boolean),
    recurring: false,
    featured: e.featured,
    lat: e.lat,
    lng: e.lng,
    ticketUrl: e.ticketUrl,
    sourceUrl: e.sourceUrl,
    // Carry over bilingual fields for i18n
    ...(e.title_zh ? { title_zh: e.title_zh } : {}),
    ...(e.description_zh ? { description_zh: e.description_zh, subtitle_zh: e.venueName_zh || '' } : {}),
    ...(e.venueName_zh ? { location_zh: e.venueName_zh } : {}),
    ...(e.district_zh ? { district_zh: e.district_zh } : {}),
  } as LifestyleEvent;
}

// ─────────────────────────────────────────────────────────────
// All lifestyle event data is now loaded from Supabase and
// converted via culturalEventToLifestyle(). Empty array serves
// as initial/fallback state before the API responds.
// ─────────────────────────────────────────────────────────────
export const lifestyleEvents: LifestyleEvent[] = [];

// Helper
export function formatLifestyleDate(dateStr: string) {
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
}