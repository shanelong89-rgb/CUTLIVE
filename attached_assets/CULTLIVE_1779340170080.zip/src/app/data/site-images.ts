// ═══════════════════════════════════════════════════
// SITE IMAGES REGISTRY — single source of truth for all hardcoded images
// Each slot has an id, page group, description, alt text, and default URL.
// The Template Editor's "Site Images" tab lets admins override any of these.
// The useSiteImages() hook resolves overrides → defaults at runtime.
// ═══════════════════════════════════════════════════

export interface SiteImageSlot {
  id: string;
  page: string;         // group key for Template Editor sections
  slot: string;         // human-readable description
  alt: string;
  url: string;          // hardcoded default
  type?: 'image' | 'video';
}

export const staticSiteImages: SiteImageSlot[] = [
  // ─── Homepage Hero ───
  {
    id: 'home-hero-video',
    page: 'home-hero',
    slot: 'Hero background video',
    alt: 'Hong Kong harbour aerial video',
    url: 'https://videos.pexels.com/video-files/3129671/3129671-uhd_2560_1440_30fps.mp4',
    type: 'video',
  },
  {
    id: 'home-hero-poster',
    page: 'home-hero',
    slot: 'Hero poster / fallback image',
    alt: 'Hong Kong harbour skyline golden hour',
    url: 'https://images.unsplash.com/photo-1759053117752-0362834a4381?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxIb25nJTIwS29uZyUyMGhhcmJvdXIlMjBza3lsaW5lJTIwZ29sZGVuJTIwaG91ciUyMGVkaXRvcmlhbHxlbnwxfHx8fDE3NzMwNTg3MjB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
  },

  // ─── Mode Selector Cards (Homepage) ───
  {
    id: 'mode-card-night',
    page: 'mode-selector',
    slot: 'Night mode card background',
    alt: 'Hong Kong neon nightlife street',
    url: 'https://images.unsplash.com/photo-1558877310-867ca3e64002?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxIb25nJTIwS29uZyUyMG5lb24lMjBzaWducyUyMG5pZ2h0JTIwY2l0eXxlbnwxfHx8fDE3NzMwMzI0NzN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
  },
  {
    id: 'mode-card-art',
    page: 'mode-selector',
    slot: 'Art & Design mode card background',
    alt: 'Art exhibition floral installation',
    url: 'https://kdunpanpjcybsybnxakl.supabase.co/storage/v1/object/public/make-d507b98c-submissions/uploads/mmvrq9su_1hppc0_WKM-MS-6.jpg',
  },
  {
    id: 'mode-card-food',
    page: 'mode-selector',
    slot: 'Food mode card background',
    alt: 'Hong Kong street food tacos market',
    url: 'https://kdunpanpjcybsybnxakl.supabase.co/storage/v1/object/public/make-d507b98c-submissions/uploads/mmvrr9sp_7vnrkg_ROOTALLYJAN31-60.jpg',
  },
  {
    id: 'mode-card-family',
    page: 'mode-selector',
    slot: 'Family mode card background',
    alt: 'Hong Kong family outdoor nature',
    url: 'https://kdunpanpjcybsybnxakl.supabase.co/storage/v1/object/public/make-d507b98c-submissions/uploads/mmvrt0zx_qve58n_M_JAN3-36.jpg',
  },
  {
    id: 'mode-card-lifestyle',
    page: 'mode-selector',
    slot: 'Lifestyle mode card background',
    alt: 'Hong Kong Sai Kung outdoor nature',
    url: 'https://kdunpanpjcybsybnxakl.supabase.co/storage/v1/object/public/make-d507b98c-submissions/uploads/mmvrt9jn_bguxz9_SAIKUNG-9.jpg',
  },

  // ─── Mode Page Heroes ───
  {
    id: 'mode-hero-night',
    page: 'mode-heroes',
    slot: 'Night mode page hero image',
    alt: 'Hong Kong street night neon signs',
    url: 'https://images.unsplash.com/photo-1650302469504-99734c9df41e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob25nJTIwa29uZyUyMHN0cmVldCUyMG5pZ2h0JTIwbmVvbiUyMHNpZ25zfGVufDF8fHx8MTc3MzAyNjE5OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
  },
  {
    id: 'mode-hero-art',
    page: 'mode-heroes',
    slot: 'Art mode page editorial image',
    alt: 'Architectural space',
    url: 'https://images.unsplash.com/photo-1643622288042-ecedf3e21e9f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlZGl0b3JpYWwlMjBhcmNoaXRlY3R1cmUlMjBidWlsZGluZyUyMGZhY2FkZXxlbnwxfHx8fDE3NzMwMjQwMDV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
  },
  {
    id: 'mode-hero-family',
    page: 'mode-heroes',
    slot: 'Family mode page hero image',
    alt: 'Children art workshop colorful painting',
    url: 'https://images.unsplash.com/photo-1755727764068-7512292ef4b9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGlsZHJlbiUyMGFydCUyMHdvcmtzaG9wJTIwY29sb3JmdWwlMjBwYWludGluZ3xlbnwxfHx8fDE3NzMwMjU3MTZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
  },
  {
    id: 'mode-hero-food',
    page: 'mode-heroes',
    slot: 'Food mode page hero image',
    alt: 'Hong Kong food market night stalls',
    url: 'https://images.unsplash.com/photo-1676544226884-6f7a37a67152?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxIb25nJTIwS29uZyUyMGZvb2QlMjBtYXJrZXQlMjBuaWdodCUyMHN0YWxscyUyMHN0ZWFtfGVufDF8fHx8MTc3MzgxMjM2N3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
  },
  {
    id: 'mode-hero-lifestyle',
    page: 'mode-heroes',
    slot: 'Lifestyle mode page hero image',
    alt: 'Hong Kong outdoor wellness morning',
    url: 'https://images.unsplash.com/photo-1707831762060-d8189bbd1de1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxIb25nJTIwS29uZyUyMG91dGRvb3IlMjB3ZWxsbmVzcyUyMG1vcm5pbmclMjBlZGl0b3JpYWx8ZW58MXx8fHwxNzczODEyMzY0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
  },

  // ─── About Page ───
  {
    id: 'about-hero',
    page: 'about',
    slot: 'About page hero image',
    alt: 'Hong Kong cityscape aerial panoramic',
    url: 'https://kdunpanpjcybsybnxakl.supabase.co/storage/v1/object/public/make-d507b98c-submissions/uploads/mmvrwlag_zbvhgx_ALLYHK-26.jpg',
  },
  {
    id: 'about-mid',
    page: 'about',
    slot: 'About page mid-section image',
    alt: 'Hong Kong night skyline moonrise',
    url: 'https://kdunpanpjcybsybnxakl.supabase.co/storage/v1/object/public/make-d507b98c-submissions/uploads/mmvrx220_qg2l4v_M_JAN3-98.jpg',
  },
  {
    id: 'about-collab',
    page: 'about',
    slot: 'About page collaboration section image',
    alt: 'Coffee latte art collaboration',
    url: 'https://kdunpanpjcybsybnxakl.supabase.co/storage/v1/object/public/make-d507b98c-submissions/uploads/mmvrx8jl_7o0nl5_ROOTALLYJAN31-20.jpg',
  },

  // ─── Lifestyle Page ───
  {
    id: 'lifestyle-texture',
    page: 'lifestyle',
    slot: 'Lifestyle page paper texture background',
    alt: 'Vintage paper texture cream parchment',
    url: 'https://images.unsplash.com/photo-1706271952285-01b5e3fc2d78?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aW50YWdlJTIwcGFwZXIlMjB0ZXh0dXJlJTIwY3JlYW0lMjBwYXJjaG1lbnR8ZW58MXx8fHwxNzczMDQ4NjI3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
  },

  // ─── Mobile Mode Cards (smaller variants) ───
  {
    id: 'mobile-mode-night',
    page: 'mobile-mode-cards',
    slot: 'Mobile Night mode card',
    alt: 'Hong Kong neon nightlife',
    url: 'https://images.unsplash.com/photo-1616394158624-a2ba9cfe2994?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxIb25nJTIwS29uZyUyMG5lb24lMjBuaWdodGxpZmUlMjBzdHJlZXQlMjBkYXJrfGVufDF8fHx8MTc3MzA0NTM4MHww&ixlib=rb-4.1.0&q=80&w=400&utm_source=figma&utm_medium=referral',
  },
  {
    id: 'mobile-mode-family',
    page: 'mobile-mode-cards',
    slot: 'Mobile Family mode card',
    alt: 'Hong Kong family children park',
    url: 'https://images.unsplash.com/photo-1756657266978-c15f15bd3266?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxIb25nJTIwS29uZyUyMGZhbWlseSUyMGNoaWxkcmVuJTIwcGFyayUyMHBsYXlncm91bmR8ZW58MXx8fHwxNzczMDQ1Mzg0fDA&ixlib=rb-4.1.0&q=80&w=400&utm_source=figma&utm_medium=referral',
  },
  {
    id: 'mobile-mode-art',
    page: 'mobile-mode-cards',
    slot: 'Mobile Art mode card',
    alt: 'Modern art gallery white exhibition',
    url: 'https://images.unsplash.com/photo-1767294274414-5e1e6c3974e9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBhcnQlMjBnYWxsZXJ5JTIwd2hpdGUlMjBleGhpYml0aW9uJTIwc3BhY2V8ZW58MXx8fHwxNzczMDQ1Mzg3fDA&ixlib=rb-4.1.0&q=80&w=400&utm_source=figma&utm_medium=referral',
  },
  {
    id: 'mobile-mode-food',
    page: 'mobile-mode-cards',
    slot: 'Mobile Food mode card',
    alt: 'Hong Kong dim sum food market',
    url: 'https://images.unsplash.com/photo-1746105866475-33b40bcc24d1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxIb25nJTIwS29uZyUyMGRpbSUyMHN1bSUyMGZvb2QlMjBtYXJrZXQlMjByZXN0YXVyYW50fGVufDF8fHx8MTc3MzA0NTM4OXww&ixlib=rb-4.1.0&q=80&w=400&utm_source=figma&utm_medium=referral',
  },
  {
    id: 'mobile-mode-lifestyle',
    page: 'mobile-mode-cards',
    slot: 'Mobile Lifestyle mode card',
    alt: 'Outdoor yoga wellness sunrise group',
    url: 'https://images.unsplash.com/photo-1760774714285-61ff516f86c5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvdXRkb29yJTIweW9nYSUyMHdlbGxuZXNzJTIwc3VucmlzZSUyMGdyb3VwfGVufDF8fHx8MTc3MzA0NTM5Mnww&ixlib=rb-4.1.0&q=80&w=400&utm_source=figma&utm_medium=referral',
  },
];

// ─── Lookup helpers ───

/** Get a slot by id */
export function getSlot(id: string): SiteImageSlot | undefined {
  return staticSiteImages.find(s => s.id === id);
}

/** Get default URL for a slot */
export function getDefaultUrl(id: string): string {
  return getSlot(id)?.url ?? '';
}

/** Page group labels for Template Editor UI */
export const PAGE_LABELS: Record<string, string> = {
  'home-hero': 'Homepage Hero',
  'mode-selector': 'Mode Selector Cards',
  'mode-heroes': 'Mode Page Heroes',
  'about': 'About Page',
  'lifestyle': 'Lifestyle Page',
  'mobile-mode-cards': 'Mobile Mode Cards',
};