export type Mode = 'degen' | 'family' | 'artsy' | 'foodie' | 'lifestyle';

export interface Venue {
  id: string;
  name: string;
  nameZh: string;
  description: string;
  description_zh?: string;
  category: string;
  categories?: string[];
  subcategory: string;
  lat: number;
  lng: number;
  district: string;
  address: string;
  image: string;
  modeScores: Partial<Record<Mode, number>>;
  vibeTags: string[];
  priceRange: number;
  upcomingEvents: number;
  pastRecaps: number;
}

export interface CulturalEvent {
  id: string;
  venueId: string;
  title: string;
  title_zh?: string;
  description: string;
  description_zh?: string;
  date: string;
  endDate?: string;
  time: string;
  category: string;
  categories?: string[];
  image: string;
  modeTags: Mode[];
  price: string;
  status: 'upcoming' | 'ongoing' | 'past';
  featured: boolean;
  venueName: string;
  venueName_zh?: string;
  district: string;
  district_zh?: string;
  lat?: number;
  lng?: number;
  artists?: string[];
  vibes?: string[];
  ticketUrl?: string;
  sourceUrl?: string;
  source?: string;
  _source?: string;
  editorialHook?: string;
  editorialHook_zh?: string;
}

export interface Recap {
  id: string;
  eventId: string;
  venueId: string;
  source: string;
  thumbnail: string;
  caption: string;
  caption_zh?: string;
  engagement: number;
  modeScores: Partial<Record<Mode, number>>;
  capturedAt: string;
  eventTitle?: string;
  media?: string[];
  contributorName?: string;
}

export const modeConfig = {
  degen: {
    label: 'Night',
    labelZh: '夜行者',
    emoji: 'degen',
    color: '#D600FF',
    gradient: 'from-fuchsia-500 to-purple-600',
    bgClass: 'bg-gradient-to-br from-yellow-300/40 to-fuchsia-500/20',
    markerColor: '#D600FF',
    description: 'Nightlife, parties & underground scenes',
  },
  family: {
    label: 'Family',
    labelZh: '親子',
    emoji: 'family',
    color: '#FF8C42',
    gradient: 'from-orange-400 to-amber-500',
    bgClass: 'bg-gradient-to-br from-orange-50/80 to-amber-50/80',
    markerColor: '#FF8C42',
    description: 'Kid-friendly, parks & museums',
  },
  artsy: {
    label: 'Art & Design',
    labelZh: '藝術',
    emoji: 'artsy',
    color: '#8338EC',
    gradient: 'from-violet-500 to-indigo-700',
    bgClass: 'bg-gradient-to-br from-violet-950/40 to-indigo-950/40',
    markerColor: '#8338EC',
    description: 'Galleries, exhibitions & studios',
  },
  foodie: {
    label: 'Food',
    labelZh: '美食',
    emoji: 'foodie',
    color: '#2563EB',
    gradient: 'from-blue-500 to-blue-700',
    bgClass: 'bg-gradient-to-br from-blue-950/40 to-indigo-950/40',
    markerColor: '#2563EB',
    description: 'Restaurants, pop-ups & markets',
  },
  lifestyle: {
    label: 'Lifestyle',
    labelZh: '生活',
    emoji: 'lifestyle',
    color: '#2D6A4F',
    gradient: 'from-green-500 to-emerald-600',
    bgClass: 'bg-gradient-to-br from-green-100/40 to-emerald-100/40',
    markerColor: '#2D6A4F',
    description: 'Run clubs, wellness & meetups',
  },
};

export const iconLibrary: Record<string, Record<string, string>> = {
  nightclub: { icon: 'nightclub', label: 'Nightclub' },
  bar: { icon: 'bar', label: 'Bar' },
  speakeasy: { icon: 'speakeasy', label: 'Speakeasy' },
  lounge: { icon: 'lounge', label: 'Lounge' },
  park: { icon: 'park', label: 'Park' },
  museum: { icon: 'museum', label: 'Museum' },
  cafe: { icon: 'cafe', label: 'Cafe' },
  gallery: { icon: 'gallery', label: 'Gallery' },
  exhibition: { icon: 'exhibition', label: 'Exhibition' },
  studio: { icon: 'studio', label: 'Studio' },
  theater: { icon: 'theater', label: 'Theater' },
  restaurant: { icon: 'restaurant', label: 'Restaurant' },
  popup: { icon: 'popup', label: 'Pop-up' },
  market: { icon: 'market', label: 'Market' },
  bakery: { icon: 'bakery', label: 'Bakery' },
};

// ─────────────────────────────────────────────────────────────
// All data is now loaded from Supabase. Empty arrays serve as
// initial/fallback state before the API responds.
// ─────────────────────────────────────────────────────────────
export const venues: Venue[] = [];
export const events: CulturalEvent[] = [];
export const recaps: Recap[] = [];