/**
 * Singleton Supabase client — import this everywhere to avoid
 * "Multiple GoTrueClient instances" warnings from HMR re-evaluation.
 */
import { createClient } from '@supabase/supabase-js';
import { projectId, publicAnonKey } from '../config/supabase';

const SUPABASE_URL = `https://${projectId}.supabase.co`;

// Stored on globalThis so HMR module re-evaluation reuses the same instance
const key = '__cultive_supabase_client__';
if (!(globalThis as any)[key]) {
  (globalThis as any)[key] = createClient(SUPABASE_URL, publicAnonKey);
}

export const supabase: ReturnType<typeof createClient> = (globalThis as any)[key];
