import { createBrowserRouter } from 'react-router';
import { Layout } from './components/Layout';
import { HomePage } from './pages/HomePage';
import { MapPage } from './pages/MapPage';
import { EventsPage } from './pages/EventsPage';
import { LifestyleRedirect } from './pages/LifestyleRedirect';
import { VenueDetailPage } from './pages/VenueDetailPage';
import { AboutPage } from './pages/AboutPage';
import { ContributePage } from './pages/ContributePage';
import { RecapSubmitPage } from './pages/RecapSubmitPage';
import { RecapsGalleryPage } from './pages/RecapsGalleryPage';
import { RecapDetailPage } from './pages/RecapDetailPage';
import { EventDetailPage } from './pages/EventDetailPage';
import { NotFoundPage } from './pages/NotFoundPage';
import { LoginPage } from './pages/LoginPage';
import { SignupPage } from './pages/SignupPage';
import { SavedEventsPage } from './pages/SavedEventsPage';
import { ProfilePage } from './pages/ProfilePage';
import { CollectionsPage } from './pages/CollectionsPage';
import { CollectionDetailPage } from './pages/CollectionDetailPage';
import { PrivacyPage } from './pages/PrivacyPage';
import { TermsPage } from './pages/TermsPage';
import { ApiManifestPage } from './pages/ApiManifestPage';
import { WhatsOnPage } from './pages/WhatsOnPage';

// Admin pages
import { AdminLayout } from './pages/admin/AdminLayout';
import { AdminLogin } from './pages/admin/AdminLogin';
import { AdminDashboard } from './pages/admin/AdminDashboard';
import { SubmissionPipeline } from './pages/admin/SubmissionPipeline';
import { ContributorManager } from './pages/admin/ContributorManager';
import { AdminSettings } from './pages/admin/AdminSettings';
import { ContentManager } from './pages/admin/ContentManager';
import { MediaLibrary } from './pages/admin/MediaLibrary';
import { CopyEditor } from './pages/admin/CopyEditor';
import { TranslationHub } from './pages/admin/TranslationHub';
import { TemplateEditor } from './pages/admin/TemplateEditor';
import { BulkImport } from './pages/admin/BulkImport';
import { VenueManager } from './pages/admin/VenueManager';
import { BulkEventImport } from './pages/admin/BulkEventImport';
import { EventManager } from './pages/admin/EventManager';
import { ApifyEventImport } from './pages/admin/ApifyEventImport';
import { WeeklyPicksEditor } from './pages/admin/WeeklyPicksEditor';
import { WebhookManager } from './pages/admin/WebhookManager';
import { BrandGuide } from './pages/admin/BrandGuide';
import { PitchDeckEditor } from './pages/admin/PitchDeckEditor';
import { AnalyticsReports } from './pages/admin/AnalyticsReports';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: Layout,
    children: [
      { index: true, Component: HomePage },
      { path: 'whats-on', Component: WhatsOnPage },
      { path: 'map', Component: MapPage },
      { path: 'events', Component: EventsPage },
      { path: 'lifestyle', Component: LifestyleRedirect },
      { path: 'venue/:id', Component: VenueDetailPage },
      { path: 'about', Component: AboutPage },
      { path: 'contribute', Component: ContributePage },
      { path: 'contribute/recap', Component: RecapSubmitPage },
      { path: 'recaps', Component: RecapsGalleryPage },
      { path: 'recaps/:id', Component: RecapDetailPage },
      { path: 'event/:id', Component: EventDetailPage },
      { path: 'saved', Component: SavedEventsPage },
      { path: 'profile', Component: ProfilePage },
      { path: 'collections', Component: CollectionsPage },
      { path: 'collections/:id', Component: CollectionDetailPage },
      { path: 'privacy', Component: PrivacyPage },
      { path: 'terms', Component: TermsPage },
      { path: '*', Component: NotFoundPage },
    ],
  },
  // API manifest — outside Layout (raw JSON for agent consumption)
  {
    path: '/api/manifest',
    Component: ApiManifestPage,
  },
  // Auth pages — outside Layout (no nav)
  {
    path: '/login',
    Component: LoginPage,
  },
  {
    path: '/signup',
    Component: SignupPage,
  },
  // Admin CMS — separate layout (no main site nav)
  {
    path: '/admin/login',
    Component: AdminLogin,
  },
  {
    path: '/admin',
    Component: AdminLayout,
    children: [
      { index: true, Component: AdminDashboard },
      { path: 'submissions', Component: SubmissionPipeline },
      { path: 'submissions/:status', Component: SubmissionPipeline },
      { path: 'contributors', Component: ContributorManager },
      { path: 'content/:type', Component: ContentManager },
      { path: 'media', Component: MediaLibrary },
      { path: 'copy', Component: CopyEditor },
      { path: 'translation', Component: TranslationHub },
      { path: 'template', Component: TemplateEditor },
      { path: 'import', Component: BulkImport },
      { path: 'events-import', Component: BulkEventImport },
      { path: 'apify-import', Component: ApifyEventImport },
      { path: 'events', Component: EventManager },
      { path: 'venues', Component: VenueManager },
      { path: 'weekly-picks', Component: WeeklyPicksEditor },
      { path: 'webhooks', Component: WebhookManager },
      { path: 'brand-guide', Component: BrandGuide },
      { path: 'pitch-deck', Component: PitchDeckEditor },
      { path: 'analytics', Component: AnalyticsReports },
      { path: 'settings', Component: AdminSettings },
    ],
  },
]);