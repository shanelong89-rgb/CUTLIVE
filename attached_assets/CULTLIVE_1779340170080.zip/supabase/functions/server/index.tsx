import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";
import { seedData } from "./seed.tsx";
import { cms } from "./cms-routes.tsx";
import { createClient } from "npm:@supabase/supabase-js@2";

const app = new Hono();

app.use('*', logger(console.log));

app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization", "X-Auth-Token", "X-User-Id", "apikey"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check
app.get("/make-server-d507b98c/health", (c) => {
  return c.json({ status: "ok" });
});

// ─── Seed endpoint — idempotent, loads mock data into KV ───
app.post("/make-server-d507b98c/seed", async (c) => {
  try {
    // Check if already seeded with current version
    const existing = await kv.get("cultive:seeded");
    const SEED_VERSION = 4; // Bump this to force re-seed (v4: ensures _source:"mock" is applied)
    if (existing && (existing as any).version === SEED_VERSION) {
      return c.json({ status: "already_seeded", message: "Data already exists in database", version: SEED_VERSION });
    }

    // If old seed exists, clear ONLY mock data — preserve imported RA/Apify/LSA data
    let preservedVenueIds: string[] = [];
    let preservedEventIds: string[] = [];
    let preservedRecapIds: string[] = [];

    // Helper: detect imported (non-mock) items by _source field OR ID prefix patterns
    const IMPORTED_ID_PREFIXES = ["ra_", "apify_", "lsa_", "cms_", "sub_"];
    function isImportedItem(item: any, id: string): boolean {
      if (item?._source && item._source !== "mock") return true;
      // Fallback: check ID prefix for imported data that may lack _source
      if (IMPORTED_ID_PREFIXES.some(p => id.startsWith(p))) return true;
      return false;
    }

    if (existing) {
      console.log(`Re-seeding: old version ${(existing as any).version || 1}, new version ${SEED_VERSION}`);

      // ── Separate mock vs imported venues ──
      const oldVenueIds = ((await kv.get("cultive:venue_ids")) || []) as string[];
      const delVenueKeys: string[] = [];
      for (const id of oldVenueIds) {
        const v = await kv.get(`cultive:venue:${id}`) as any;
        if (isImportedItem(v, id)) {
          preservedVenueIds.push(id);
        } else {
          delVenueKeys.push(`cultive:venue:${id}`);
        }
      }

      // ── Separate mock vs imported events ──
      const oldEventIds = ((await kv.get("cultive:event_ids")) || []) as string[];
      const delEventKeys: string[] = [];
      for (const id of oldEventIds) {
        const e = await kv.get(`cultive:event:${id}`) as any;
        if (isImportedItem(e, id)) {
          preservedEventIds.push(id);
        } else {
          delEventKeys.push(`cultive:event:${id}`);
        }
      }

      // ── Separate mock vs imported recaps ──
      const oldRecapIds = ((await kv.get("cultive:recap_ids")) || []) as string[];
      const delRecapKeys: string[] = [];
      for (const id of oldRecapIds) {
        const r = await kv.get(`cultive:recap:${id}`) as any;
        if (isImportedItem(r, id)) {
          preservedRecapIds.push(id);
        } else {
          delRecapKeys.push(`cultive:recap:${id}`);
        }
      }

      // Delete only mock keys
      const keysToDelete = ["cultive:seeded", ...delVenueKeys, ...delEventKeys, ...delRecapKeys];
      if (keysToDelete.length > 0) await kv.mdel(keysToDelete);
      console.log(`Re-seed: deleted ${delVenueKeys.length} mock venues, ${delEventKeys.length} mock events, ${delRecapKeys.length} mock recaps`);
      console.log(`Re-seed: preserved ${preservedVenueIds.length} imported venues, ${preservedEventIds.length} imported events, ${preservedRecapIds.length} imported recaps`);
    }

    const { venues, events, recaps } = seedData;

    // Store each venue individually + merge with preserved imported venues
    const venueKeys: string[] = [];
    for (const venue of venues) {
      await kv.set(`cultive:venue:${venue.id}`, { ...venue, _source: "mock" });
      venueKeys.push(venue.id);
    }
    const allVenueIds = [...venueKeys, ...preservedVenueIds.filter((id: string) => !venueKeys.includes(id))];
    await kv.set("cultive:venue_ids", allVenueIds);

    // Store each event individually + merge with preserved imported events
    const eventKeys: string[] = [];
    for (const event of events) {
      await kv.set(`cultive:event:${event.id}`, { ...event, _source: "mock" });
      eventKeys.push(event.id);
    }
    const allEventIds = [...eventKeys, ...preservedEventIds.filter((id: string) => !eventKeys.includes(id))];
    await kv.set("cultive:event_ids", allEventIds);

    // Store each recap individually + merge with preserved imported recaps
    const recapKeys: string[] = [];
    for (const recap of recaps) {
      await kv.set(`cultive:recap:${recap.id}`, { ...recap, _source: "mock" });
      recapKeys.push(recap.id);
    }
    const allRecapIds = [...recapKeys, ...preservedRecapIds.filter((id: string) => !recapKeys.includes(id))];
    await kv.set("cultive:recap_ids", allRecapIds);

    // Mark as seeded
    await kv.set("cultive:seeded", { seededAt: new Date().toISOString(), version: SEED_VERSION, venueCount: venues.length, eventCount: events.length, recapCount: recaps.length });

    console.log(`Seeded v${SEED_VERSION}: ${venues.length} mock venues, ${events.length} mock events, ${recaps.length} mock recaps (+ ${preservedEventIds.length} preserved imported events)`);
    return c.json({ status: "seeded", version: SEED_VERSION, venues: venues.length, events: events.length, recaps: recaps.length, preserved: { venues: preservedVenueIds.length, events: preservedEventIds.length, recaps: preservedRecapIds.length } });
  } catch (err) {
    console.log(`Error seeding data: ${err}`);
    return c.json({ error: `Failed to seed data: ${err}` }, 500);
  }
});

// ─── GET all venues ───
app.get("/make-server-d507b98c/venues", async (c) => {
  try {
    const ids = await kv.get("cultive:venue_ids");
    if (!ids || !Array.isArray(ids) || ids.length === 0) {
      return c.json({ venues: [], source: "supabase", count: 0 });
    }
    const venueKeys = ids.map((id: string) => `cultive:venue:${id}`);
    // Fetch in chunks to avoid Supabase .in() limits on large arrays
    const CHUNK = 50;
    const venues: any[] = [];
    for (let i = 0; i < venueKeys.length; i += CHUNK) {
      const chunk = venueKeys.slice(i, i + CHUNK);
      const results = await kv.mget(chunk);
      venues.push(...results);
    }
    return c.json({ venues: venues.filter(Boolean), source: "supabase", count: venues.filter(Boolean).length });
  } catch (err) {
    console.log(`Error fetching venues: ${err}`);
    return c.json({ error: `Failed to fetch venues: ${err}` }, 500);
  }
});

// ─── GET single venue ───
app.get("/make-server-d507b98c/venues/:id", async (c) => {
  try {
    const id = c.req.param("id");
    const venue = await kv.get(`cultive:venue:${id}`);
    if (!venue) {
      return c.json({ error: `Venue not found: ${id}` }, 404);
    }
    return c.json({ venue, source: "supabase" });
  } catch (err) {
    console.log(`Error fetching venue: ${err}`);
    return c.json({ error: `Failed to fetch venue: ${err}` }, 500);
  }
});

// ─── GET all events (optional ?venueId= filter) ───
app.get("/make-server-d507b98c/events", async (c) => {
  try {
    const venueId = c.req.query("venueId");
    const ids = await kv.get("cultive:event_ids");
    if (!ids || !Array.isArray(ids) || ids.length === 0) {
      return c.json({ events: [], source: "supabase", count: 0 });
    }
    const eventKeys = ids.map((id: string) => `cultive:event:${id}`);
    // Fetch in chunks to avoid Supabase .in() limits on large arrays
    const CHUNK = 50;
    let events: any[] = [];
    for (let i = 0; i < eventKeys.length; i += CHUNK) {
      const chunk = eventKeys.slice(i, i + CHUNK);
      const results = await kv.mget(chunk);
      events.push(...results);
    }
    events = events.filter(Boolean);
    if (venueId) {
      events = events.filter((e: any) => e && e.venueId === venueId);
    }
    return c.json({ events, source: "supabase", count: events.length });
  } catch (err) {
    console.log(`Error fetching events: ${err}`);
    return c.json({ error: `Failed to fetch events: ${err}` }, 500);
  }
});

// ─── GET single event by ID ───
app.get("/make-server-d507b98c/events/:id", async (c) => {
  try {
    const id = c.req.param("id");
    // Skip if it looks like a sub-path (e.g. "bulk")
    if (id === "bulk") return c.notFound();
    const event = await kv.get(`cultive:event:${id}`);
    if (!event) {
      return c.json({ error: `Event not found: ${id}` }, 404);
    }
    return c.json({ event, source: "supabase" });
  } catch (err) {
    console.log(`Error fetching event ${c.req.param("id")}: ${err}`);
    return c.json({ error: `Failed to fetch event: ${err}` }, 500);
  }
});

// ─── GET all recaps (optional ?venueId= filter) ───
app.get("/make-server-d507b98c/recaps", async (c) => {
  try {
    const venueId = c.req.query("venueId");
    const ids = await kv.get("cultive:recap_ids");
    if (!ids || !Array.isArray(ids) || ids.length === 0) {
      return c.json({ recaps: [], source: "supabase", count: 0 });
    }
    const recapKeys = ids.map((id: string) => `cultive:recap:${id}`);
    let recaps = await kv.mget(recapKeys);
    if (venueId) {
      recaps = recaps.filter((r: any) => r && r.venueId === venueId);
    }
    return c.json({ recaps, source: "supabase", count: recaps.length });
  } catch (err) {
    console.log(`Error fetching recaps: ${err}`);
    return c.json({ error: `Failed to fetch recaps: ${err}` }, 500);
  }
});

// ─── POST a new event ───
app.post("/make-server-d507b98c/events", async (c) => {
  try {
    const event = await c.req.json();
    if (!event.id || !event.title) {
      return c.json({ error: "Event must have id and title" }, 400);
    }
    await kv.set(`cultive:event:${event.id}`, event);

    // Update index
    const ids = (await kv.get("cultive:event_ids")) || [];
    if (!ids.includes(event.id)) {
      ids.push(event.id);
      await kv.set("cultive:event_ids", ids);
    }

    return c.json({ status: "created", event });
  } catch (err) {
    console.log(`Error creating event: ${err}`);
    return c.json({ error: `Failed to create event: ${err}` }, 500);
  }
});

// ─── PUT update a venue ───
app.put("/make-server-d507b98c/venues/:id", async (c) => {
  try {
    const id = c.req.param("id");
    const updates = await c.req.json();
    const existing = await kv.get(`cultive:venue:${id}`);
    if (!existing) {
      return c.json({ error: `Venue not found: ${id}` }, 404);
    }
    const updated = { ...existing, ...updates, id };
    await kv.set(`cultive:venue:${id}`, updated);
    return c.json({ status: "updated", venue: updated });
  } catch (err) {
    console.log(`Error updating venue: ${err}`);
    return c.json({ error: `Failed to update venue: ${err}` }, 500);
  }
});

// ─── Data status — check if seeded ───
app.get("/make-server-d507b98c/status", async (c) => {
  try {
    const seeded = await kv.get("cultive:seeded");
    return c.json({ seeded: !!seeded, details: seeded || null });
  } catch (err) {
    console.log(`Error checking status: ${err}`);
    return c.json({ error: `Failed to check status: ${err}` }, 500);
  }
});

// Helper: detect mock data by _source field OR by seed ID pattern fallback
function isMockItem(item: any, id: string, type: 'venue' | 'event' | 'recap'): boolean {
  if (item?._source === 'mock') return true;
  // Fallback: detect seed data by ID pattern (v1-v26, e1-e38, r1-r6)
  if (type === 'venue' && /^v\d+$/.test(id)) return true;
  if (type === 'event' && /^e\d+$/.test(id)) return true;
  if (type === 'recap' && /^r\d+$/.test(id)) return true;
  return false;
}

// ─── Purge Mock Data — bulk-delete all items with _source:"mock" ───
app.delete("/make-server-d507b98c/admin/mock-data", async (c) => {
  try {
    const results = { venues: 0, events: 0, recaps: 0 };

    // ── Purge mock venues ──
    const venueIds = ((await kv.get("cultive:venue_ids")) || []) as string[];
    const keepVenueIds: string[] = [];
    const delVenueKeys: string[] = [];
    for (const id of venueIds) {
      const v = await kv.get(`cultive:venue:${id}`) as any;
      if (isMockItem(v, id, 'venue')) {
        delVenueKeys.push(`cultive:venue:${id}`);
        results.venues++;
      } else {
        keepVenueIds.push(id);
      }
    }
    if (delVenueKeys.length > 0) await kv.mdel(delVenueKeys);
    await kv.set("cultive:venue_ids", keepVenueIds);

    // ── Purge mock events ──
    const eventIds = ((await kv.get("cultive:event_ids")) || []) as string[];
    const keepEventIds: string[] = [];
    const delEventKeys: string[] = [];
    for (const id of eventIds) {
      const e = await kv.get(`cultive:event:${id}`) as any;
      if (isMockItem(e, id, 'event')) {
        delEventKeys.push(`cultive:event:${id}`);
        results.events++;
      } else {
        keepEventIds.push(id);
      }
    }
    if (delEventKeys.length > 0) await kv.mdel(delEventKeys);
    await kv.set("cultive:event_ids", keepEventIds);

    // ── Purge mock recaps ──
    const recapIds = ((await kv.get("cultive:recap_ids")) || []) as string[];
    const keepRecapIds: string[] = [];
    const delRecapKeys: string[] = [];
    for (const id of recapIds) {
      const r = await kv.get(`cultive:recap:${id}`) as any;
      if (isMockItem(r, id, 'recap')) {
        delRecapKeys.push(`cultive:recap:${id}`);
        results.recaps++;
      } else {
        keepRecapIds.push(id);
      }
    }
    if (delRecapKeys.length > 0) await kv.mdel(delRecapKeys);
    await kv.set("cultive:recap_ids", keepRecapIds);

    // Clear seeded flag so seed won't think data is present
    await kv.del("cultive:seeded");

    const total = results.venues + results.events + results.recaps;
    console.log(`Purged mock data: ${results.venues} venues, ${results.events} events, ${results.recaps} recaps`);
    return c.json({ status: "purged", ...results, total });
  } catch (err) {
    console.log(`Error purging mock data: ${err}`);
    return c.json({ error: `Failed to purge mock data: ${err}` }, 500);
  }
});

// ─── GET mock data stats (preview before purge) ───
app.get("/make-server-d507b98c/admin/mock-data/stats", async (c) => {
  try {
    const stats = { venues: { mock: 0, real: 0 }, events: { mock: 0, real: 0 }, recaps: { mock: 0, real: 0 } };

    const venueIds = ((await kv.get("cultive:venue_ids")) || []) as string[];
    for (const id of venueIds) {
      const v = await kv.get(`cultive:venue:${id}`) as any;
      if (isMockItem(v, id, 'venue')) stats.venues.mock++; else stats.venues.real++;
    }

    const eventIds = ((await kv.get("cultive:event_ids")) || []) as string[];
    for (const id of eventIds) {
      const e = await kv.get(`cultive:event:${id}`) as any;
      if (isMockItem(e, id, 'event')) stats.events.mock++; else stats.events.real++;
    }

    const recapIds = ((await kv.get("cultive:recap_ids")) || []) as string[];
    for (const id of recapIds) {
      const r = await kv.get(`cultive:recap:${id}`) as any;
      if (isMockItem(r, id, 'recap')) stats.recaps.mock++; else stats.recaps.real++;
    }

    return c.json({ stats });
  } catch (err) {
    console.log(`Error fetching mock data stats: ${err}`);
    return c.json({ error: `Failed to fetch stats: ${err}` }, 500);
  }
});

// ─── KV diagnostic: scan all keys and report what's stored ───
app.get("/make-server-d507b98c/admin/kv-scan", async (c) => {
  try {
    const supabase = (await import("npm:@supabase/supabase-js@2")).createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    // Scan known prefixes
    const prefixes = [
      "cultive:event:", "cultive:venue:", "cultive:recap:",
      "cms:content:event:", "cms:content:venue:", "cms:content:recap:",
      "cultive:import_log:", "cms:submission:",
    ];
    const report: Record<string, { count: number; sampleIds: string[] }> = {};

    for (const prefix of prefixes) {
      const { data } = await supabase.from("kv_store_d507b98c")
        .select("key")
        .like("key", `${prefix}%`)
        .order("key")
        .limit(500);
      const keys = data?.map((d: any) => d.key) || [];
      report[prefix] = {
        count: keys.length,
        sampleIds: keys.slice(0, 20).map((k: string) => k.replace(prefix, "")),
      };
    }

    // Check index arrays
    const eventIds = ((await kv.get("cultive:event_ids")) || []) as string[];
    const venueIds = ((await kv.get("cultive:venue_ids")) || []) as string[];
    const recapIds = ((await kv.get("cultive:recap_ids")) || []) as string[];
    const cmsEventIds = ((await kv.get("cms:content:event:ids")) || []) as string[];
    const cmsVenueIds = ((await kv.get("cms:content:venue:ids")) || []) as string[];
    const importLogIds = ((await kv.get("cultive:import_log_ids")) || []) as string[];

    return c.json({
      indexes: {
        "cultive:event_ids": { count: eventIds.length, ids: eventIds },
        "cultive:venue_ids": { count: venueIds.length, ids: venueIds.slice(0, 30) },
        "cultive:recap_ids": { count: recapIds.length },
        "cms:content:event:ids": { count: cmsEventIds.length, ids: cmsEventIds },
        "cms:content:venue:ids": { count: cmsVenueIds.length, ids: cmsVenueIds.slice(0, 30) },
        "cultive:import_log_ids": { count: importLogIds.length, ids: importLogIds },
      },
      prefixScan: report,
    });
  } catch (err) {
    console.log(`KV scan error: ${err}`);
    return c.json({ error: `KV scan failed: ${err}` }, 500);
  }
});

// ─── Recovery: restore imported events from CMS content store back to main store ───
app.post("/make-server-d507b98c/admin/recover-events", async (c) => {
  try {
    const cmsEventIds = ((await kv.get("cms:content:event:ids")) || []) as string[];
    if (cmsEventIds.length === 0) {
      return c.json({ status: "nothing_to_recover", message: "No events found in CMS content store" });
    }

    const CHUNK = 50;
    const cmsEvents: any[] = [];
    for (let i = 0; i < cmsEventIds.length; i += CHUNK) {
      const chunk = cmsEventIds.slice(i, i + CHUNK);
      const keys = chunk.map((id: string) => `cms:content:event:${id}`);
      const results = await kv.mget(keys);
      cmsEvents.push(...results.filter(Boolean));
    }

    const mainIds = new Set(((await kv.get("cultive:event_ids")) || []) as string[]);
    const allIds = [...mainIds];
    let restored = 0;
    let skipped = 0;

    for (const event of cmsEvents) {
      if (!event || !event.id) continue;
      if (event._source === "mock" || /^e\d+$/.test(event.id)) { skipped++; continue; }

      if (!mainIds.has(event.id)) {
        await kv.set(`cultive:event:${event.id}`, event);
        allIds.push(event.id);
        mainIds.add(event.id);
        restored++;
      } else {
        skipped++;
      }
    }

    if (restored > 0) {
      await kv.set("cultive:event_ids", allIds);
    }

    console.log(`Recovery: restored ${restored} events from CMS, skipped ${skipped}`);
    return c.json({ status: "ok", restored, skipped, totalMainEvents: allIds.length });
  } catch (err) {
    console.log(`Recovery error: ${err}`);
    return c.json({ error: `Recovery failed: ${err}` }, 500);
  }
});

// ─── Mount CMS routes ───
app.route("/make-server-d507b98c/cms", cms);

// ─── Bulk Event Import (JSON upload) ───
app.post("/make-server-d507b98c/events/bulk", async (c) => {
  try {
    const { events: newEvents, batchMeta } = await c.req.json();
    if (!Array.isArray(newEvents) || newEvents.length === 0) {
      return c.json({ error: "events must be a non-empty array" }, 400);
    }

    const ids = (await kv.get("cultive:event_ids") as string[]) || [];
    const idsSet = new Set<string>(ids);
    const created: string[] = [];
    const updated: string[] = [];
    const invalid: string[] = [];
    let totalQuality = 0;

    // Validate & collect events for batch write
    const validKeys: string[] = [];
    const validValues: any[] = [];

    for (const event of newEvents) {
      if (!event.id || !event.title) { invalid.push(event.id || "?"); continue; }
      const q = [
        !!event.title, !!event.image,
        typeof event.description === 'string' && event.description.length > 30,
        !!event.date, !!event.time,
        !!(event.venueName || event.venueId),
        !!event.price && event.price !== 'Check event page',
        !!(event.lat && event.lng),
        Array.isArray(event.modeTags) && event.modeTags.length > 0,
        !!event.category,
        Array.isArray(event.artists) && event.artists.length > 0,
      ];
      totalQuality += Math.round((q.filter(Boolean).length / q.length) * 100);

      // Ensure _createdAt is set for all imported events
      if (!event._createdAt) {
        event._createdAt = new Date().toISOString();
      }

      validKeys.push(`cultive:event:${event.id}`);
      validValues.push(event);

      if (!idsSet.has(event.id)) {
        idsSet.add(event.id);
        ids.push(event.id);
        created.push(event.id);
      } else {
        updated.push(event.id);
      }
    }

    // Batch write in chunks of 50 for reliability (Supabase upsert limit)
    const CHUNK = 50;
    for (let i = 0; i < validKeys.length; i += CHUNK) {
      const chunkKeys = validKeys.slice(i, i + CHUNK);
      const chunkVals = validValues.slice(i, i + CHUNK);
      await kv.mset(chunkKeys, chunkVals);
    }
    console.log(`Bulk import: wrote ${validKeys.length} events in ${Math.ceil(validKeys.length / CHUNK)} chunk(s)`);

    await kv.set("cultive:event_ids", ids);

    // ── Save import log entry ──
    const batchId = `batch_${Date.now()}`;
    const processedCount = created.length + updated.length;
    const avgQuality = processedCount > 0
      ? Math.round(totalQuality / processedCount)
      : 0;
    const logEntry = {
      id: batchId,
      timestamp: new Date().toISOString(),
      created: created.length,
      updated: updated.length,
      invalid: invalid.length,
      total: newEvents.length,
      eventIds: [...created, ...updated],
      avgQuality,
      label: batchMeta?.label || '',
    };
    await kv.set(`cultive:import_log:${batchId}`, logEntry);
    const logIds = ((await kv.get("cultive:import_log_ids")) || []) as string[];
    logIds.unshift(batchId);
    await kv.set("cultive:import_log_ids", logIds.slice(0, 100));

    console.log(`Bulk import: ${created.length} created, ${updated.length} updated, ${invalid.length} invalid, avgQuality=${avgQuality}`);
    return c.json({ status: "ok", created: created.length, updated: updated.length, invalid: invalid.length, batchId, avgQuality });
  } catch (err) {
    console.log(`Error in bulk event import: ${err}`);
    return c.json({ error: `Bulk import failed: ${err}` }, 500);
  }
});

// ─── GET import history ───
app.get("/make-server-d507b98c/events/bulk/history", async (c) => {
  try {
    const logIds = ((await kv.get("cultive:import_log_ids")) || []) as string[];
    if (logIds.length === 0) return c.json({ batches: [] });
    const logKeys = logIds.map((id: string) => `cultive:import_log:${id}`);
    const batches = await kv.mget(logKeys);
    return c.json({ batches: batches.filter(Boolean) });
  } catch (err) {
    console.log(`Error fetching import history: ${err}`);
    return c.json({ error: `Failed to fetch history: ${err}` }, 500);
  }
});

// ─── DELETE event ───
app.delete("/make-server-d507b98c/events/:id", async (c) => {
  try {
    const id = c.req.param("id");
    await kv.del(`cultive:event:${id}`);
    const ids = ((await kv.get("cultive:event_ids")) || []) as string[];
    await kv.set("cultive:event_ids", ids.filter((i: string) => i !== id));
    console.log(`Deleted event: ${id}`);
    return c.json({ status: "deleted", id });
  } catch (err) {
    console.log(`Error deleting event: ${err}`);
    return c.json({ error: `Failed to delete event: ${err}` }, 500);
  }
});

// ─── PUT update event ───
app.put("/make-server-d507b98c/events/:id", async (c) => {
  try {
    const id = c.req.param("id");
    const updates = await c.req.json();
    const existing = await kv.get(`cultive:event:${id}`);
    if (!existing) {
      return c.json({ error: `Event not found: ${id}` }, 404);
    }
    const updated = { ...existing, ...updates, id };
    await kv.set(`cultive:event:${id}`, updated);
    console.log(`Updated event: ${id}`);
    return c.json({ status: "updated", event: updated });
  } catch (err) {
    console.log(`Error updating event: ${err}`);
    return c.json({ error: `Failed to update event: ${err}` }, 500);
  }
});

// ─── Public Auth: Sign Up ───
app.post("/make-server-d507b98c/auth/signup", async (c) => {
  try {
    const { email, password, name } = await c.req.json();
    if (!email || !password) {
      return c.json({ error: "Email and password are required" }, 400);
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name: name || email.split("@")[0] },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true,
    });

    if (error) {
      console.log(`Auth signup error: ${error.message}`);
      return c.json({ error: error.message }, 400);
    }

    return c.json({ status: "created", userId: data.user?.id });
  } catch (err) {
    console.log(`Error during signup: ${err}`);
    return c.json({ error: `Signup failed: ${err}` }, 500);
  }
});

// ─── User Saved Events: GET ───
app.get("/make-server-d507b98c/user/saved-events", async (c) => {
  try {
    const userId = c.req.header("X-User-Id");
    if (!userId) {
      return c.json({ error: "X-User-Id header required" }, 400);
    }

    const saved = await kv.get(`cultive:user:${userId}:saved-events`);
    console.log(`[Saved] GET for user ${userId}: ${Array.isArray(saved) ? saved.length : 0} events`);
    return c.json({ eventIds: saved || [] });
  } catch (err) {
    console.log(`Error fetching saved events: ${err}`);
    return c.json({ error: `Failed to fetch saved events: ${err}` }, 500);
  }
});

// ─── User Saved Events: POST (save/update) ───
app.post("/make-server-d507b98c/user/saved-events", async (c) => {
  try {
    const body = await c.req.json();
    // Accept userId from header OR body (body fallback needed for sendBeacon which can't set custom headers)
    const userId = c.req.header("X-User-Id") || body.userId;
    if (!userId) {
      return c.json({ error: "X-User-Id header or userId in body required" }, 400);
    }

    const { eventIds } = body;
    if (!Array.isArray(eventIds)) {
      return c.json({ error: "eventIds must be an array" }, 400);
    }

    await kv.set(`cultive:user:${userId}:saved-events`, eventIds);
    console.log(`[Saved] POST for user ${userId}: persisted ${eventIds.length} events`);
    return c.json({ status: "saved", count: eventIds.length });
  } catch (err) {
    console.log(`Error saving events: ${err}`);
    return c.json({ error: `Failed to save events: ${err}` }, 500);
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// ─── USER PROFILE ROUTES ─────────────────────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────────

// ─── Get User Profile ───
app.get("/make-server-d507b98c/user/profile", async (c) => {
  try {
    const userId = c.req.header("X-User-Id");
    if (!userId) {
      return c.json({ error: "X-User-Id header required" }, 400);
    }

    const profile = await kv.get(`cultive:user:${userId}:profile`);
    return c.json({ profile: profile || {} });
  } catch (err) {
    console.log(`Error fetching user profile: ${err}`);
    return c.json({ error: `Failed to fetch profile: ${err}` }, 500);
  }
});

// ─── Update User Profile ───
app.put("/make-server-d507b98c/user/profile", async (c) => {
  try {
    const userId = c.req.header("X-User-Id");
    if (!userId) {
      return c.json({ error: "X-User-Id header required" }, 400);
    }

    const updates = await c.req.json();
    const existing = (await kv.get(`cultive:user:${userId}:profile`)) || {};
    const updated = { ...existing, ...updates, updatedAt: new Date().toISOString() };
    
    await kv.set(`cultive:user:${userId}:profile`, updated);
    return c.json({ status: "updated", profile: updated });
  } catch (err) {
    console.log(`Error updating user profile: ${err}`);
    return c.json({ error: `Failed to update profile: ${err}` }, 500);
  }
});

// ─── Change Password ───
app.post("/make-server-d507b98c/user/change-password", async (c) => {
  try {
    const userId = c.req.header("X-User-Id");
    if (!userId) {
      return c.json({ error: "X-User-Id header required" }, 400);
    }

    const { newPassword } = await c.req.json();
    if (!newPassword || newPassword.length < 6) {
      return c.json({ error: "Password must be at least 6 characters" }, 400);
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const { error } = await supabase.auth.admin.updateUserById(userId, {
      password: newPassword,
    });

    if (error) {
      console.log(`Error changing password: ${error.message}`);
      return c.json({ error: error.message }, 400);
    }

    return c.json({ status: "password_changed" });
  } catch (err) {
    console.log(`Error changing password: ${err}`);
    return c.json({ error: `Failed to change password: ${err}` }, 500);
  }
});

// ─── Avatar Upload ───
const AVATAR_BUCKET = "make-d507b98c-submissions";

async function ensureAvatarBucket() {
  try {
    const sb = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );
    const { data: buckets } = await sb.storage.listBuckets();
    const exists = buckets?.some((b: any) => b.name === AVATAR_BUCKET);
    if (!exists) {
      await sb.storage.createBucket(AVATAR_BUCKET, { public: false });
    }
  } catch (err) {
    console.log(`Error ensuring avatar bucket: ${err}`);
  }
}

app.post("/make-server-d507b98c/user/avatar", async (c) => {
  try {
    const userId = c.req.header("X-User-Id");
    if (!userId) {
      return c.json({ error: "X-User-Id header required" }, 400);
    }

    await ensureAvatarBucket();
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const formData = await c.req.formData();
    const file = formData.get("file") as File;
    if (!file) {
      return c.json({ error: "No file provided" }, 400);
    }

    const ext = file.name.split(".").pop() || "jpg";
    const storagePath = `avatars/${userId}/avatar_${Date.now()}.${ext}`;
    const arrayBuffer = await file.arrayBuffer();

    const { error: uploadErr } = await supabase.storage
      .from(AVATAR_BUCKET)
      .upload(storagePath, arrayBuffer, {
        contentType: file.type,
        upsert: true,
      });

    if (uploadErr) {
      console.log(`Avatar upload error: ${uploadErr.message}`);
      return c.json({ error: `Upload failed: ${uploadErr.message}` }, 500);
    }

    const { data: signedData } = await supabase.storage
      .from(AVATAR_BUCKET)
      .createSignedUrl(storagePath, 60 * 60 * 24 * 30);

    const avatarUrl = signedData?.signedUrl || "";

    const existing = (await kv.get(`cultive:user:${userId}:profile`)) || {};
    await kv.set(`cultive:user:${userId}:profile`, {
      ...(existing as any),
      avatarUrl,
      avatarPath: storagePath,
      updatedAt: new Date().toISOString(),
    });

    return c.json({ status: "uploaded", avatarUrl });
  } catch (err) {
    console.log(`Error uploading avatar: ${err}`);
    return c.json({ error: `Failed to upload avatar: ${err}` }, 500);
  }
});

// ─── Attendance Tracking ───
app.get("/make-server-d507b98c/user/attendance", async (c) => {
  try {
    const userId = c.req.header("X-User-Id");
    if (!userId) return c.json({ error: "X-User-Id header required" }, 400);
    const attendedIds = (await kv.get(`cultive:user:${userId}:attended`)) || [];
    return c.json({ attendedIds });
  } catch (err) {
    console.log(`Error fetching attendance: ${err}`);
    return c.json({ error: `Failed to fetch attendance: ${err}` }, 500);
  }
});

app.post("/make-server-d507b98c/user/attendance", async (c) => {
  try {
    const userId = c.req.header("X-User-Id");
    if (!userId) return c.json({ error: "X-User-Id header required" }, 400);
    const { eventId, action } = await c.req.json();
    if (!eventId) return c.json({ error: "eventId required" }, 400);
    const existing = ((await kv.get(`cultive:user:${userId}:attended`)) || []) as string[];
    let updated: string[];
    if (action === "remove") {
      updated = existing.filter((id: string) => id !== eventId);
    } else {
      updated = existing.includes(eventId) ? existing : [...existing, eventId];
    }
    await kv.set(`cultive:user:${userId}:attended`, updated);
    return c.json({ status: "ok", attendedIds: updated });
  } catch (err) {
    console.log(`Error updating attendance: ${err}`);
    return c.json({ error: `Failed to update attendance: ${err}` }, 500);
  }
});

// ─── Event View Tracking ───
app.post("/make-server-d507b98c/events/track-view", async (c) => {
  try {
    const { eventId } = await c.req.json();
    if (!eventId) return c.json({ error: "eventId required" }, 400);
    const key = `cultive:event:${eventId}:views`;
    const current = ((await kv.get(key)) as number) || 0;
    const updated = current + 1;
    await kv.set(key, updated);
    return c.json({ views: updated });
  } catch (err) {
    console.log(`Error tracking view: ${err}`);
    return c.json({ error: `Failed to track view: ${err}` }, 500);
  }
});

// ─── Event Save Count (increment / decrement) ───
app.post("/make-server-d507b98c/events/track-save", async (c) => {
  try {
    const { eventId, action } = await c.req.json();
    if (!eventId) return c.json({ error: "eventId required" }, 400);
    const key = `cultive:event:${eventId}:saves`;
    const current = ((await kv.get(key)) as number) || 0;
    const updated = action === "unsave" ? Math.max(0, current - 1) : current + 1;
    await kv.set(key, updated);
    return c.json({ saves: updated });
  } catch (err) {
    console.log(`Error tracking save count: ${err}`);
    return c.json({ error: `Failed to track save: ${err}` }, 500);
  }
});

// ─── Event Share Count ───
app.post("/make-server-d507b98c/events/track-share", async (c) => {
  try {
    const { eventId, platform } = await c.req.json();
    if (!eventId) return c.json({ error: "eventId required" }, 400);
    const key = `cultive:event:${eventId}:shares`;
    const current = ((await kv.get(key)) as number) || 0;
    const updated = current + 1;
    await kv.set(key, updated);
    // Optionally track platform-specific shares for analytics
    if (platform) {
      const platformKey = `cultive:event:${eventId}:shares:${platform}`;
      const platformCount = ((await kv.get(platformKey)) as number) || 0;
      await kv.set(platformKey, platformCount + 1);
    }
    return c.json({ shares: updated });
  } catch (err) {
    console.log(`Error tracking share count: ${err}`);
    return c.json({ error: `Failed to track share: ${err}` }, 500);
  }
});

// ─── Get Event Stats (single) ───
app.get("/make-server-d507b98c/events/stats/:id", async (c) => {
  try {
    const eventId = c.req.param("id");
    const [views, saves, shares] = await Promise.all([
      kv.get(`cultive:event:${eventId}:views`),
      kv.get(`cultive:event:${eventId}:saves`),
      kv.get(`cultive:event:${eventId}:shares`),
    ]);
    return c.json({ views: (views as number) || 0, saves: (saves as number) || 0, shares: (shares as number) || 0 });
  } catch (err) {
    console.log(`Error fetching event stats: ${err}`);
    return c.json({ error: `Failed to fetch stats: ${err}` }, 500);
  }
});

// ─── Batch Event Stats ───
app.post("/make-server-d507b98c/events/stats/batch", async (c) => {
  try {
    const { eventIds } = await c.req.json();
    if (!Array.isArray(eventIds) || eventIds.length === 0) {
      return c.json({ stats: {} });
    }
    const ids = eventIds.slice(0, 50);
    const viewKeys = ids.map((id: string) => `cultive:event:${id}:views`);
    const saveKeys = ids.map((id: string) => `cultive:event:${id}:saves`);
    const shareKeys = ids.map((id: string) => `cultive:event:${id}:shares`);
    const [viewResults, saveResults, shareResults] = await Promise.all([
      kv.mget(viewKeys),
      kv.mget(saveKeys),
      kv.mget(shareKeys),
    ]);
    const stats: Record<string, { views: number; saves: number; shares: number }> = {};
    ids.forEach((id: string, i: number) => {
      stats[id] = {
        views: (viewResults[i] as number) || 0,
        saves: (saveResults[i] as number) || 0,
        shares: (shareResults[i] as number) || 0,
      };
    });
    return c.json({ stats });
  } catch (err) {
    console.log(`Error fetching batch stats: ${err}`);
    return c.json({ error: `Failed to fetch batch stats: ${err}` }, 500);
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// ─── COLLECTIONS ROUTES ──────────────────────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────────

// ─── Get All User Collections ───
app.get("/make-server-d507b98c/user/collections", async (c) => {
  try {
    const userId = c.req.header("X-User-Id");
    if (!userId) {
      return c.json({ error: "X-User-Id header required" }, 400);
    }

    const collectionIds = (await kv.get(`cultive:user:${userId}:collection_ids`)) || [];
    if (!Array.isArray(collectionIds) || collectionIds.length === 0) {
      return c.json({ collections: [] });
    }

    const collectionKeys = collectionIds.map((id: string) => `cultive:collection:${id}`);
    const collections = await kv.mget(collectionKeys);
    
    return c.json({ collections: collections.filter(c => c !== null) });
  } catch (err) {
    console.log(`Error fetching collections: ${err}`);
    return c.json({ error: `Failed to fetch collections: ${err}` }, 500);
  }
});

// ─── Create Collection ───
app.post("/make-server-d507b98c/user/collections", async (c) => {
  try {
    const userId = c.req.header("X-User-Id");
    if (!userId) {
      return c.json({ error: "X-User-Id header required" }, 400);
    }

    const { name, description, isPublic } = await c.req.json();
    if (!name || name.trim().length === 0) {
      return c.json({ error: "Collection name is required" }, 400);
    }

    const collectionId = `${userId}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const collection = {
      id: collectionId,
      userId,
      name: name.trim(),
      description: description?.trim() || "",
      isPublic: !!isPublic,
      items: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await kv.set(`cultive:collection:${collectionId}`, collection);

    // Update user's collection index
    const collectionIds = (await kv.get(`cultive:user:${userId}:collection_ids`)) || [];
    collectionIds.push(collectionId);
    await kv.set(`cultive:user:${userId}:collection_ids`, collectionIds);

    return c.json({ status: "created", collection });
  } catch (err) {
    console.log(`Error creating collection: ${err}`);
    return c.json({ error: `Failed to create collection: ${err}` }, 500);
  }
});

// ─── Update Collection ───
app.put("/make-server-d507b98c/user/collections/:id", async (c) => {
  try {
    const userId = c.req.header("X-User-Id");
    if (!userId) {
      return c.json({ error: "X-User-Id header required" }, 400);
    }

    const collectionId = c.req.param("id");
    const existing = await kv.get(`cultive:collection:${collectionId}`);
    
    if (!existing || (existing as any).userId !== userId) {
      return c.json({ error: "Collection not found or access denied" }, 404);
    }

    const updates = await c.req.json();
    const updated = {
      ...existing,
      ...updates,
      id: collectionId,
      userId,
      updatedAt: new Date().toISOString(),
    };

    await kv.set(`cultive:collection:${collectionId}`, updated);
    return c.json({ status: "updated", collection: updated });
  } catch (err) {
    console.log(`Error updating collection: ${err}`);
    return c.json({ error: `Failed to update collection: ${err}` }, 500);
  }
});

// ─── Delete Collection ───
app.delete("/make-server-d507b98c/user/collections/:id", async (c) => {
  try {
    const userId = c.req.header("X-User-Id");
    if (!userId) {
      return c.json({ error: "X-User-Id header required" }, 400);
    }

    const collectionId = c.req.param("id");
    const existing = await kv.get(`cultive:collection:${collectionId}`);
    
    if (!existing || (existing as any).userId !== userId) {
      return c.json({ error: "Collection not found or access denied" }, 404);
    }

    await kv.del(`cultive:collection:${collectionId}`);

    // Remove from user's collection index
    const collectionIds = (await kv.get(`cultive:user:${userId}:collection_ids`)) || [];
    const filtered = collectionIds.filter((id: string) => id !== collectionId);
    await kv.set(`cultive:user:${userId}:collection_ids`, filtered);

    return c.json({ status: "deleted" });
  } catch (err) {
    console.log(`Error deleting collection: ${err}`);
    return c.json({ error: `Failed to delete collection: ${err}` }, 500);
  }
});

// ─── Add Item to Collection ───
app.post("/make-server-d507b98c/user/collections/:id/items", async (c) => {
  try {
    const userId = c.req.header("X-User-Id");
    if (!userId) {
      return c.json({ error: "X-User-Id header required" }, 400);
    }

    const collectionId = c.req.param("id");
    const collection = await kv.get(`cultive:collection:${collectionId}`);
    
    if (!collection || (collection as any).userId !== userId) {
      return c.json({ error: "Collection not found or access denied" }, 404);
    }

    const { itemId, itemType } = await c.req.json();
    if (!itemId || !itemType || !['event', 'venue'].includes(itemType)) {
      return c.json({ error: "Valid itemId and itemType (event/venue) required" }, 400);
    }

    const items = (collection as any).items || [];
    
    // Check if already exists
    if (items.some((item: any) => item.id === itemId && item.type === itemType)) {
      return c.json({ error: "Item already in collection" }, 400);
    }

    items.push({
      id: itemId,
      type: itemType,
      addedAt: new Date().toISOString(),
    });

    const updated = {
      ...collection,
      items,
      updatedAt: new Date().toISOString(),
    };

    await kv.set(`cultive:collection:${collectionId}`, updated);
    return c.json({ status: "item_added", collection: updated });
  } catch (err) {
    console.log(`Error adding item to collection: ${err}`);
    return c.json({ error: `Failed to add item: ${err}` }, 500);
  }
});

// ─── Remove Item from Collection ───
app.delete("/make-server-d507b98c/user/collections/:id/items/:itemId", async (c) => {
  try {
    const userId = c.req.header("X-User-Id");
    if (!userId) {
      return c.json({ error: "X-User-Id header required" }, 400);
    }

    const collectionId = c.req.param("id");
    const itemId = c.req.param("itemId");
    const collection = await kv.get(`cultive:collection:${collectionId}`);
    
    if (!collection || (collection as any).userId !== userId) {
      return c.json({ error: "Collection not found or access denied" }, 404);
    }

    const items = (collection as any).items || [];
    const filtered = items.filter((item: any) => item.id !== itemId);

    const updated = {
      ...collection,
      items: filtered,
      updatedAt: new Date().toISOString(),
    };

    await kv.set(`cultive:collection:${collectionId}`, updated);
    return c.json({ status: "item_removed", collection: updated });
  } catch (err) {
    console.log(`Error removing item from collection: ${err}`);
    return c.json({ error: `Failed to remove item: ${err}` }, 500);
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// ─── NOTIFICATIONS ROUTES ────────────────────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────────

// ─── Get User Notifications ───
app.get("/make-server-d507b98c/user/notifications", async (c) => {
  try {
    const userId = c.req.header("X-User-Id");
    if (!userId) {
      return c.json({ error: "X-User-Id header required" }, 400);
    }

    const notifications = (await kv.get(`cultive:user:${userId}:notifications`)) || [];
    
    // Sort by createdAt descending
    const sorted = (notifications as any[]).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );

    return c.json({ notifications: sorted });
  } catch (err) {
    console.log(`Error fetching notifications: ${err}`);
    return c.json({ error: `Failed to fetch notifications: ${err}` }, 500);
  }
});

// ─── Mark Notifications as Read ───
app.post("/make-server-d507b98c/user/notifications/mark-read", async (c) => {
  try {
    const userId = c.req.header("X-User-Id");
    if (!userId) {
      return c.json({ error: "X-User-Id header required" }, 400);
    }

    const { notificationIds } = await c.req.json();
    if (!Array.isArray(notificationIds)) {
      return c.json({ error: "notificationIds must be an array" }, 400);
    }

    const notifications = (await kv.get(`cultive:user:${userId}:notifications`)) || [];
    
    const updated = (notifications as any[]).map(notif => {
      if (notificationIds.includes(notif.id)) {
        return { ...notif, read: true, readAt: new Date().toISOString() };
      }
      return notif;
    });

    await kv.set(`cultive:user:${userId}:notifications`, updated);
    return c.json({ status: "marked_read", count: notificationIds.length });
  } catch (err) {
    console.log(`Error marking notifications as read: ${err}`);
    return c.json({ error: `Failed to mark as read: ${err}` }, 500);
  }
});

// ─── Delete Notification ───
app.delete("/make-server-d507b98c/user/notifications/:id", async (c) => {
  try {
    const userId = c.req.header("X-User-Id");
    if (!userId) {
      return c.json({ error: "X-User-Id header required" }, 400);
    }

    const notifId = c.req.param("id");
    const notifications = (await kv.get(`cultive:user:${userId}:notifications`)) || [];
    
    const filtered = (notifications as any[]).filter(n => n.id !== notifId);
    await kv.set(`cultive:user:${userId}:notifications`, filtered);

    return c.json({ status: "deleted" });
  } catch (err) {
    console.log(`Error deleting notification: ${err}`);
    return c.json({ error: `Failed to delete notification: ${err}` }, 500);
  }
});

// ─── Get Notification Settings ───
app.get("/make-server-d507b98c/user/notification-settings", async (c) => {
  try {
    const userId = c.req.header("X-User-Id");
    if (!userId) {
      return c.json({ error: "X-User-Id header required" }, 400);
    }

    const settings = (await kv.get(`cultive:user:${userId}:notification_settings`)) || {
      upcomingEvents: true,
      newEvents: true,
      savedEventReminders: true,
      collectionUpdates: false,
      emailNotifications: false,
    };

    return c.json({ settings });
  } catch (err) {
    console.log(`Error fetching notification settings: ${err}`);
    return c.json({ error: `Failed to fetch settings: ${err}` }, 500);
  }
});

// ─── Update Notification Settings ───
app.post("/make-server-d507b98c/user/notification-settings", async (c) => {
  try {
    const userId = c.req.header("X-User-Id");
    if (!userId) {
      return c.json({ error: "X-User-Id header required" }, 400);
    }

    const settings = await c.req.json();
    await kv.set(`cultive:user:${userId}:notification_settings`, settings);

    return c.json({ status: "updated", settings });
  } catch (err) {
    console.log(`Error updating notification settings: ${err}`);
    return c.json({ error: `Failed to update settings: ${err}` }, 500);
  }
});

// ─── Create Notification (helper for system-generated notifications) ───
app.post("/make-server-d507b98c/user/notifications/create", async (c) => {
  try {
    const userId = c.req.header("X-User-Id");
    if (!userId) {
      return c.json({ error: "X-User-Id header required" }, 400);
    }

    const { type, title, message, actionUrl, metadata } = await c.req.json();
    if (!type || !title || !message) {
      return c.json({ error: "type, title, and message are required" }, 400);
    }

    const notifications = (await kv.get(`cultive:user:${userId}:notifications`)) || [];
    
    const newNotification = {
      id: `notif_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      type, // e.g., 'event_reminder', 'new_event', 'collection_shared'
      title,
      message,
      actionUrl: actionUrl || null,
      metadata: metadata || {},
      read: false,
      createdAt: new Date().toISOString(),
    };

    (notifications as any[]).unshift(newNotification);
    
    // Keep only last 50 notifications
    const trimmed = (notifications as any[]).slice(0, 50);
    
    await kv.set(`cultive:user:${userId}:notifications`, trimmed);
    return c.json({ status: "created", notification: newNotification });
  } catch (err) {
    console.log(`Error creating notification: ${err}`);
    return c.json({ error: `Failed to create notification: ${err}` }, 500);
  }
});

// ─── Check Upcoming Saved Events & Push Reminder Notifications ───
app.post("/make-server-d507b98c/notifications/check-upcoming", async (c) => {
  try {
    const userId = c.req.header("X-User-Id");
    if (!userId) {
      return c.json({ error: "X-User-Id header required" }, 400);
    }

    // Get user's saved event IDs
    const savedEventIds = ((await kv.get(`cultive:user:${userId}:saved-events`)) as string[]) || [];
    if (!savedEventIds.length) {
      return c.json({ status: "no_saved_events", created: 0, checkedEvents: 0 });
    }

    const now = new Date();
    const sevenDaysMs = 7 * 24 * 60 * 60 * 1000;
    const sevenDaysFromNow = new Date(now.getTime() + sevenDaysMs);

    // Load existing notifications
    const notifications = ((await kv.get(`cultive:user:${userId}:notifications`)) as any[]) || [];
    let created = 0;

    for (const eventId of savedEventIds) {
      // Skip if we already sent a reminder for this event recently
      const reminderKey = `cultive:user:${userId}:notif_sent:${eventId}`;
      const reminderSent = await kv.get(reminderKey);
      if (reminderSent) continue;

      // Fetch event details
      const event = (await kv.get(`cultive:event:${eventId}`)) as any;
      if (!event || !event.date) continue;

      // Parse date (format YYYY-MM-DD, treat as midnight HKT = UTC+8)
      const eventDate = new Date(event.date + "T00:00:00+08:00");

      // Only notify for events coming up within 7 days (not past)
      if (eventDate >= now && eventDate <= sevenDaysFromNow) {
        const msUntil = eventDate.getTime() - now.getTime();
        const daysUntil = Math.ceil(msUntil / (1000 * 60 * 60 * 24));
        const dayLabel =
          daysUntil === 0
            ? "today"
            : daysUntil === 1
            ? "tomorrow"
            : `in ${daysUntil} days`;

        const venuePart = event.venueName ? ` @ ${event.venueName}` : "";
        const timePart = event.time ? ` · ${event.time}` : "";

        const newNotif = {
          id: `notif_${Date.now()}_${Math.random().toString(36).slice(2, 7)}_${eventId}`,
          type: "event_reminder",
          title: `Upcoming: ${event.title}`,
          message: `A saved event is happening ${dayLabel}${venuePart}${timePart}. Don't miss it!`,
          actionUrl: `/event/${eventId}`,
          metadata: { eventId, eventDate: event.date, district: event.district || "" },
          read: false,
          createdAt: new Date().toISOString(),
        };

        notifications.unshift(newNotif);

        // Mark as sent so we don't double-notify (expires conceptually after event date)
        await kv.set(reminderKey, {
          sentAt: new Date().toISOString(),
          eventDate: event.date,
          eventTitle: event.title,
        });

        created++;
      }
    }

    if (created > 0) {
      // Keep only the 50 most recent notifications
      const trimmed = notifications.slice(0, 50);
      await kv.set(`cultive:user:${userId}:notifications`, trimmed);
      console.log(`Generated ${created} upcoming event reminder(s) for user ${userId}`);
    }

    return c.json({ status: "ok", created, checkedEvents: savedEventIds.length });
  } catch (err) {
    console.log(`Error checking upcoming events: ${err}`);
    return c.json({ error: `Failed to check upcoming events: ${err}` }, 500);
  }
});

// ─── Google Places Autocomplete proxy ───
app.get("/make-server-d507b98c/places/autocomplete", async (c) => {
  try {
    const query = c.req.query("q");
    if (!query || query.length < 2) {
      return c.json({ predictions: [] });
    }

    const apiKey = Deno.env.get("GOOGLE_PLACES_API_KEY");
    if (!apiKey) {
      console.log("GOOGLE_PLACES_API_KEY not configured");
      return c.json({ error: "Google Places API key not configured" }, 500);
    }

    // Use Google Places Autocomplete (legacy, widely supported)
    const params = new URLSearchParams({
      input: query,
      key: apiKey,
      components: "country:hk",
      language: "en",
      types: "establishment",
    });

    const res = await fetch(
      `https://maps.googleapis.com/maps/api/place/autocomplete/json?${params}`
    );
    const data = await res.json();

    if (data.status !== "OK" && data.status !== "ZERO_RESULTS") {
      console.log(`Google Places Autocomplete error: ${data.status} - ${data.error_message || ''}`);
      return c.json({ error: `Google API error: ${data.status}`, details: data.error_message }, 500);
    }

    return c.json({ predictions: data.predictions || [] });
  } catch (err) {
    console.log(`Error in places autocomplete: ${err}`);
    return c.json({ error: `Places autocomplete failed: ${err}` }, 500);
  }
});

// ─── Google Place Details proxy (for lat/lng) ───
app.get("/make-server-d507b98c/places/details", async (c) => {
  try {
    const placeId = c.req.query("place_id");
    if (!placeId) {
      return c.json({ error: "place_id is required" }, 400);
    }

    const apiKey = Deno.env.get("GOOGLE_PLACES_API_KEY");
    if (!apiKey) {
      return c.json({ error: "Google Places API key not configured" }, 500);
    }

    const params = new URLSearchParams({
      place_id: placeId,
      key: apiKey,
      fields: "geometry,formatted_address,name,address_components",
      language: "en",
    });

    const res = await fetch(
      `https://maps.googleapis.com/maps/api/place/details/json?${params}`
    );
    const data = await res.json();

    if (data.status !== "OK") {
      console.log(`Google Place Details error: ${data.status} - ${data.error_message || ''}`);
      return c.json({ error: `Google API error: ${data.status}` }, 500);
    }

    const result = data.result;
    return c.json({
      name: result.name,
      formattedAddress: result.formatted_address,
      lat: result.geometry?.location?.lat,
      lng: result.geometry?.location?.lng,
      addressComponents: result.address_components,
    });
  } catch (err) {
    console.log(`Error in place details: ${err}`);
    return c.json({ error: `Place details failed: ${err}` }, 500);
  }
});

// ─── Google Maps Shared List Scraper ───
app.post("/make-server-d507b98c/places/parse-list", async (c) => {
  try {
    const { url } = await c.req.json();
    if (!url) {
      return c.json({ error: "url is required" }, 400);
    }

    if (!url.includes("google.com/maps") && !url.includes("maps.app.goo.gl") && !url.includes("goo.gl/maps")) {
      return c.json({ error: "URL must be a Google Maps link" }, 400);
    }

    console.log(`Fetching Google Maps list URL: ${url}`);

    // Fetch the page (follows redirects automatically)
    const res = await fetch(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
      },
      redirect: "follow",
    });

    const html = await res.text();
    const finalUrl = res.url;
    console.log(`Redirected to: ${finalUrl}, HTML length: ${html.length}`);

    // Helper: strict validation for place names
    const isValidPlaceName = (s: string): boolean => {
      if (s.length < 2 || s.length > 100) return false;
      // Must contain at least one letter (any script including CJK)
      if (!/[\p{L}]/u.test(s)) return false;
      // Reject URLs, code, CSS, JS artifacts
      if (/^(http|\/\/|data:|blob:|javascript:)/i.test(s)) return false;
      if (/[{}()<>;=|\\]/.test(s)) return false;
      if (/\.(com|org|net|js|css|png|jpg|svg|gif|html|json|proto|php)($|\/)/i.test(s)) return false;
      // Reject things that look like code/tokens (camelCase single words with no spaces, no CJK)
      if (/^[a-z][a-zA-Z0-9]{5,}$/.test(s) && !s.includes(' ')) return false;
      // Reject Google internal strings
      if (/^(google|gstatic|googleapis|maps|null|true|false|undefined|function|return|this|var|const|let|class|import|export|window|document|navigator|en|zh|ja|ko|fr|de|es|it|pt|ru|ar|hi|th|vi)$/i.test(s)) return false;
      if (/google|gstatic|ggpht|lh[0-9]\.google/i.test(s)) return false;
      // Reject hex-looking or hash-looking strings
      if (/^[0-9a-f]{6,}$/i.test(s)) return false;
      if (/^[A-Za-z0-9+/=]{20,}$/.test(s)) return false; // base64-like
      // Reject purely numeric
      if (/^[\d.,\s+\-()]+$/.test(s)) return false;
      return true;
    };

    const names: string[] = [];
    const addName = (n: string) => {
      const trimmed = n.trim();
      if (isValidPlaceName(trimmed) && !names.includes(trimmed)) {
        names.push(trimmed);
      }
    };

    // Strategy 1: Extract from APP_INITIALIZATION_STATE
    const appStateMatch = html.match(/window\.APP_INITIALIZATION_STATE\s*=\s*(\[[\s\S]*?\]);?\s*(?:window\.|<\/script>)/);
    if (appStateMatch) {
      console.log("Found APP_INITIALIZATION_STATE");
      try {
        const stateStr = appStateMatch[1];
        // Place names appear near place IDs (ChIJ...) in the data
        const placeIdPattern = /\"([^"]{2,80})\"\s*,\s*(?:null\s*,\s*)*\"ChIJ[A-Za-z0-9_-]+\"/g;
        let m;
        while ((m = placeIdPattern.exec(stateStr)) !== null) {
          addName(m[1]);
        }
        const placeIdPattern2 = /\"ChIJ[A-Za-z0-9_-]+\"\s*,\s*(?:null\s*,\s*)*\"([^"]{2,80})\"/g;
        while ((m = placeIdPattern2.exec(stateStr)) !== null) {
          addName(m[1]);
        }
      } catch (e) {
        console.log("Error parsing APP_INITIALIZATION_STATE:", e);
      }
    }

    // Strategy 2: AF_initDataCallback blocks
    const afPattern = /AF_initDataCallback\(\{[^}]*data:\s*(\[[\s\S]*?\])\s*\}\s*\)/g;
    let afMatch;
    while ((afMatch = afPattern.exec(html)) !== null) {
      console.log("Found AF_initDataCallback block");
      const dataStr = afMatch[1];
      const pidPattern = /\"([^"]{2,80})\"\s*,\s*(?:null\s*,\s*)*\"ChIJ[A-Za-z0-9_-]+\"/g;
      let m;
      while ((m = pidPattern.exec(dataStr)) !== null) {
        addName(m[1]);
      }
      const pidPattern2 = /\"ChIJ[A-Za-z0-9_-]+\"\s*,\s*(?:null\s*,\s*)*\"([^"]{2,80})\"/g;
      while ((m = pidPattern2.exec(dataStr)) !== null) {
        addName(m[1]);
      }
    }

    // Strategy 3: Look for escaped place names near place IDs in raw HTML
    const escapedPlaceIdPat = /\\\"([^\\]{2,80})\\\"[^\\]*\\\"ChIJ[A-Za-z0-9_-]+\\\"/g;
    let em;
    while ((em = escapedPlaceIdPat.exec(html)) !== null) {
      addName(em[1]);
    }
    const escapedPlaceIdPat2 = /\\\"ChIJ[A-Za-z0-9_-]+\\\"[^\\]*\\\"([^\\]{2,80})\\\"/g;
    while ((em = escapedPlaceIdPat2.exec(html)) !== null) {
      addName(em[1]);
    }

    // Strategy 4: Hex place references ["0x...:0x...",null,"Place Name"]
    const hexPattern = /\[\\?"0x[0-9a-f]+:0x[0-9a-f]+\\?",\s*null\s*,\s*\\?"([^"\\]{2,80})\\?"\]/g;
    while ((em = hexPattern.exec(html)) !== null) {
      addName(em[1]);
    }

    // Strategy 5: Names near HK coordinates (22.xxx, 114.xxx)
    const coordPat = /\\?"([^"\\]{2,80})\\\"[^"]{0,200}(?:22\.\d{3,})[^"]{0,50}(?:114\.\d{3,})/g;
    while ((em = coordPat.exec(html)) !== null) {
      addName(em[1]);
    }

    // Strategy 6: Names near Hong Kong address strings
    const hkAddrPat = /\\?"([^"\\]{2,60})\\?"[,\s]*\\?"([^"\\]*(?:Hong Kong|香港)[^"\\]*)\\?"/g;
    while ((em = hkAddrPat.exec(html)) !== null) {
      addName(em[1]);
    }

    // Strategy 7: Meta tags
    const titleMatch = html.match(/<meta[^>]*property="og:title"[^>]*content="([^"]+)"/);
    const listTitle = titleMatch ? titleMatch[1] : null;

    // Strategy 8: Find ALL ChIJ place IDs and search surrounding context
    const allPlaceIds: string[] = [];
    const pidFinder = /ChIJ[A-Za-z0-9_\-]{20,}/g;
    let pidMatch;
    while ((pidMatch = pidFinder.exec(html)) !== null) {
      if (!allPlaceIds.includes(pidMatch[0])) {
        allPlaceIds.push(pidMatch[0]);
      }
    }
    console.log(`Found ${allPlaceIds.length} unique place IDs in HTML`);

    // For each place ID, look at surrounding context for potential names
    if (names.length === 0 && allPlaceIds.length > 0) {
      for (const pid of allPlaceIds) {
        const pidIdx = html.indexOf(pid);
        if (pidIdx < 0) continue;
        const windowStart = Math.max(0, pidIdx - 500);
        const windowEnd = Math.min(html.length, pidIdx + 500);
        const ctxWindow = html.substring(windowStart, windowEnd);

        const quotedPat = /(?:"|\\")([^"\\]{2,80})(?:"|\\")/g;
        let qm;
        while ((qm = quotedPat.exec(ctxWindow)) !== null) {
          const candidate = qm[1].trim();
          if (
            isValidPlaceName(candidate) &&
            !candidate.includes("ChIJ") &&
            !candidate.startsWith("0x") &&
            // Must look like a proper name (contains uppercase, CJK, or multi-word)
            (/[A-Z\u4e00-\u9fff\u3400-\u4dbf]/.test(candidate) || candidate.includes(' '))
          ) {
            addName(candidate);
          }
        }
      }
    }

    console.log(`Extracted ${names.length} place names`);

    return c.json({
      names,
      candidateNames: [] as string[],
      listTitle,
      finalUrl,
      placeIdsFound: allPlaceIds.length,
      htmlLength: html.length,
      success: names.length > 0,
    });
  } catch (err) {
    console.log(`Error parsing Google Maps list: ${err}`);
    return c.json({ error: `Failed to parse list: ${err}` }, 500);
  }
});

// ─── Google Places Text Search (for bulk import) ───
app.post("/make-server-d507b98c/places/text-search", async (c) => {
  try {
    const { query } = await c.req.json();
    if (!query || query.length < 2) {
      return c.json({ error: "query is required" }, 400);
    }

    const apiKey = Deno.env.get("GOOGLE_PLACES_API_KEY");
    if (!apiKey) {
      console.log("GOOGLE_PLACES_API_KEY not configured for text-search");
      return c.json({ error: "Google Places API key not configured" }, 500);
    }

    // Step 1: Find place using Text Search
    const searchParams = new URLSearchParams({
      query: `${query} Hong Kong`,
      key: apiKey,
      language: "en",
      region: "hk",
    });

    const searchRes = await fetch(
      `https://maps.googleapis.com/maps/api/place/textsearch/json?${searchParams}`
    );
    const searchData = await searchRes.json();

    if (searchData.status !== "OK" || !searchData.results?.length) {
      console.log(`Text search for "${query}": ${searchData.status}`);
      return c.json({ found: false, query, status: searchData.status });
    }

    const place = searchData.results[0];
    const placeId = place.place_id;

    // Step 2: Get full details
    const detailParams = new URLSearchParams({
      place_id: placeId,
      key: apiKey,
      fields: [
        "name", "formatted_address", "geometry", "address_components",
        "types", "rating", "user_ratings_total", "price_level",
        "website", "formatted_phone_number", "opening_hours",
        "photos", "editorial_summary", "url",
      ].join(","),
      language: "en",
    });

    const detailRes = await fetch(
      `https://maps.googleapis.com/maps/api/place/details/json?${detailParams}`
    );
    const detailData = await detailRes.json();

    if (detailData.status !== "OK") {
      // Fall back to text search data
      return c.json({
        found: true,
        query,
        place: {
          name: place.name,
          address: place.formatted_address,
          lat: place.geometry?.location?.lat,
          lng: place.geometry?.location?.lng,
          types: place.types || [],
          rating: place.rating,
          userRatingsTotal: place.user_ratings_total,
          priceLevel: place.price_level,
          placeId,
          photoRef: place.photos?.[0]?.photo_reference || null,
        },
      });
    }

    const d = detailData.result;

    // Extract district from address components
    let district = "";
    const components = d.address_components || [];
    for (const comp of components) {
      if (comp.types.includes("sublocality_level_1") || comp.types.includes("neighborhood")) {
        district = comp.long_name;
        break;
      }
    }
    if (!district) {
      for (const comp of components) {
        if (comp.types.includes("locality") && comp.long_name !== "Hong Kong") {
          district = comp.long_name;
          break;
        }
      }
    }

    // Build photo URL if available
    let photoUrl = null;
    if (d.photos?.length > 0) {
      const photoRef = d.photos[0].photo_reference;
      photoUrl = `https://maps.googleapis.com/maps/api/place/photo?maxwidth=800&photo_reference=${photoRef}&key=${apiKey}`;
    }

    return c.json({
      found: true,
      query,
      place: {
        name: d.name || place.name,
        address: d.formatted_address || place.formatted_address,
        lat: d.geometry?.location?.lat || place.geometry?.location?.lat,
        lng: d.geometry?.location?.lng || place.geometry?.location?.lng,
        district,
        types: d.types || place.types || [],
        rating: d.rating || place.rating,
        userRatingsTotal: d.user_ratings_total || place.user_ratings_total,
        priceLevel: d.price_level ?? place.price_level,
        website: d.website || null,
        phone: d.formatted_phone_number || null,
        openingHours: d.opening_hours?.weekday_text || null,
        editorialSummary: d.editorial_summary?.overview || null,
        photoUrl,
        googleMapsUrl: d.url || null,
        placeId,
      },
    });
  } catch (err) {
    console.log(`Error in places text-search: ${err}`);
    return c.json({ error: `Places text-search failed: ${err}` }, 500);
  }
});

// ─── Search AI Suggestions (Gemini-powered) ───
app.post("/make-server-d507b98c/search/ai-suggest", async (c) => {
  try {
    const { query, mode } = await c.req.json();
    if (!query || query.length < 2) {
      return c.json({ suggestions: [] });
    }

    const geminiKey = Deno.env.get("GEMINI_API_KEY");
    if (!geminiKey) {
      // Fallback: generate rule-based suggestions
      const fallbacks = generateFallbackSuggestions(query, mode);
      return c.json({ suggestions: fallbacks, source: "fallback" });
    }

    const modeContext = mode ? ` The user is browsing in \"${mode}\" mode.` : "";
    const prompt = `You are a Hong Kong cultural events & venues search assistant for CULTIVE (文化活). The user typed: \"${query}\".${modeContext}

Suggest 3-4 alternative search queries they might be looking for. IMPORTANT rules:
- Suggest DIFFERENT angles or refinements, not just the same query with more words appended
- If the query already contains a location (Central, Wan Chai, Sheung Wan, etc.), do NOT add another location
- If the query already contains "Hong Kong" or "HK", do NOT add it again
- Focus on venue types, vibes, occasions, or related categories
- Keep suggestions concise (2-6 words)
Return ONLY a JSON array of strings, no markdown, no explanation.

Examples:
- If user types "art galleries central": ["contemporary art exhibitions", "gallery openings HK", "art studio tours", "sculpture gardens"]
- If user types "bar": ["rooftop bars Central", "speakeasy cocktail bars", "live music bars Wan Chai", "craft beer bars Sheung Wan"]
- If user types "dim sum": ["dim sum brunch spots", "traditional yum cha", "Michelin dim sum HK", "dim sum for families"]`;

    const suggestModels = ["gemini-2.0-flash", "gemini-2.0-flash-lite", "gemini-1.5-flash"];
    const suggestBody = JSON.stringify({
      contents: [{ parts: [{ text: prompt }] }],
      generationConfig: {
        temperature: 0.7,
        maxOutputTokens: 200,
        responseMimeType: "application/json",
      },
    });
    let geminiRes: Response | null = null;
    for (const model of suggestModels) {
      const r = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${geminiKey}`,
        { method: "POST", headers: { "Content-Type": "application/json" }, body: suggestBody }
      );
      if (r.status === 404) continue;
      geminiRes = r;
      break;
    }

    if (!geminiRes || !geminiRes.ok) {
      console.log(`Gemini AI suggest error: ${geminiRes?.status || "all-404"}`);
      const fallbacks = generateFallbackSuggestions(query, mode);
      return c.json({ suggestions: fallbacks, source: "fallback" });
    }

    const geminiData = await geminiRes.json();
    const text = geminiData.candidates?.[0]?.content?.parts?.[0]?.text || "[]";
    let suggestions: string[] = [];
    try {
      suggestions = JSON.parse(text);
      if (!Array.isArray(suggestions)) suggestions = [];
      suggestions = suggestions.filter((s: any) => typeof s === "string").slice(0, 4);
    } catch {
      console.log("Failed to parse Gemini suggestions:", text);
      suggestions = generateFallbackSuggestions(query, mode);
    }

    return c.json({ suggestions, source: "gemini" });
  } catch (err) {
    console.log(`Error in search AI suggest: ${err}`);
    return c.json({ suggestions: [], error: `AI suggest failed: ${err}` });
  }
});

// ─── Search Analytics: Track search queries ───
app.post("/make-server-d507b98c/search/track", async (c) => {
  try {
    const { query, mode, resultCount } = await c.req.json();
    if (!query || typeof query !== "string" || query.trim().length < 2) {
      return c.json({ status: "skipped" });
    }

    const normalized = query.trim().toLowerCase();
    const key = "cultive:search_analytics";

    // Get existing analytics
    const existing = (await kv.get(key)) as Record<string, { count: number; lastSearched: string; modes: Record<string, number> }> | null;
    const analytics = existing || {};

    // Update or create entry
    if (analytics[normalized]) {
      analytics[normalized].count += 1;
      analytics[normalized].lastSearched = new Date().toISOString();
      if (mode) {
        analytics[normalized].modes[mode] = (analytics[normalized].modes[mode] || 0) + 1;
      }
    } else {
      analytics[normalized] = {
        count: 1,
        lastSearched: new Date().toISOString(),
        modes: mode ? { [mode]: 1 } : {},
      };
    }

    // Cap to 200 entries (evict oldest low-count entries)
    const entries = Object.entries(analytics);
    if (entries.length > 200) {
      entries.sort((a, b) => a[1].count - b[1].count);
      const toRemove = entries.slice(0, entries.length - 200);
      for (const [k] of toRemove) {
        delete analytics[k];
      }
    }

    await kv.set(key, analytics);
    return c.json({ status: "tracked" });
  } catch (err) {
    console.log(`Error tracking search: ${err}`);
    return c.json({ status: "error", error: `${err}` });
  }
});

// ─── Search Analytics: Get trending searches ───
app.get("/make-server-d507b98c/search/trending", async (c) => {
  try {
    const mode = c.req.query("mode") || null;
    const key = "cultive:search_analytics";

    const existing = (await kv.get(key)) as Record<string, { count: number; lastSearched: string; modes: Record<string, number> }> | null;
    if (!existing || Object.keys(existing).length === 0) {
      // Return curated defaults if no analytics yet
      const defaults = [
        { query: "rooftop bars", count: 42, trend: "up" as const },
        { query: "dim sum", count: 38, trend: "up" as const },
        { query: "art galleries Central", count: 31, trend: "stable" as const },
        { query: "live music", count: 28, trend: "up" as const },
        { query: "family brunch", count: 24, trend: "stable" as const },
        { query: "hidden speakeasy", count: 22, trend: "up" as const },
        { query: "Sheung Wan cafes", count: 19, trend: "stable" as const },
        { query: "night market", count: 17, trend: "up" as const },
      ];

      // Filter by mode if specified
      const modeDefaults: Record<string, string[]> = {
        degen: ["rooftop bars", "hidden speakeasy", "live music", "late night eats", "underground clubs", "cocktail bars"],
        foodie: ["dim sum", "street food", "ramen spots", "Sheung Wan cafes", "tasting menus", "izakaya"],
        artsy: ["art galleries Central", "exhibitions", "studio visits", "photography", "design shops", "PMQ events"],
        family: ["family brunch", "playgrounds", "museums", "nature walks", "kids workshops", "theme parks"],
        lifestyle: ["run clubs", "yoga studios", "wellness retreats", "hiking trails", "sunrise spots", "meditation"],
      };

      if (mode && modeDefaults[mode]) {
        return c.json({
          trending: modeDefaults[mode].map((q, i) => ({ query: q, count: 30 - i * 3, trend: i < 3 ? "up" : "stable" })),
          source: "curated",
        });
      }

      return c.json({ trending: defaults, source: "curated" });
    }

    // Compute trending: sort by count, optionally filter by mode
    let entries = Object.entries(existing);

    if (mode) {
      // Boost entries that have been searched in this mode
      entries = entries.map(([q, data]) => {
        const modeCount = data.modes[mode] || 0;
        const boostedCount = data.count + modeCount * 2; // Mode-specific boost
        return [q, { ...data, count: boostedCount }] as [string, typeof data];
      });
    }

    entries.sort((a, b) => b[1].count - a[1].count);

    const trending = entries.slice(0, 8).map(([q, data]) => {
      // Determine trend: if lastSearched within 24h, "up"; within 7d, "stable"; else "down"
      const lastMs = new Date(data.lastSearched).getTime();
      const now = Date.now();
      const hoursSince = (now - lastMs) / (1000 * 60 * 60);
      const trend = hoursSince < 24 ? "up" : hoursSince < 168 ? "stable" : "down";
      return { query: q, count: data.count, trend };
    });

    return c.json({ trending, source: "analytics" });
  } catch (err) {
    console.log(`Error fetching trending searches: ${err}`);
    return c.json({ trending: [], error: `${err}` });
  }
});

function generateFallbackSuggestions(query: string, mode?: string): string[] {
  const q = query.toLowerCase();
  const suggestions: string[] = [];

  // Detect if query already has location context so we don't double-up
  const hasLocation = /central|wan chai|sheung wan|hong kong|\bhk\b|causeway bay|tsim sha tsui|mong kok|sham shui po|kennedy town|north point|tai po|sai ying pun/i.test(q);

  if (mode === "degen") {
    suggestions.push(`${query} nightlife`, `late night ${query}`, `${query} cocktail bars`);
  } else if (mode === "foodie") {
    suggestions.push(`${query} restaurants`, `${query} hidden gems`, `${query} Michelin`);
  } else if (mode === "artsy") {
    suggestions.push(`${query} exhibitions`, `${query} gallery openings`, `${query} art spaces`);
  } else if (mode === "family") {
    suggestions.push(`${query} family-friendly`, `${query} for kids`, `${query} outdoor`);
  } else if (mode === "lifestyle") {
    suggestions.push(`${query} wellness`, `${query} workshops`, `${query} community`);
  } else if (hasLocation) {
    // Don't add more location — suggest different angles instead
    suggestions.push(`best ${query}`, `${query} hidden gems`, `${query} weekend`);
  } else {
    suggestions.push(`${query} in Central`, `best ${query} Hong Kong`, `${query} near me`);
  }

  return suggestions.slice(0, 3);
}

// ─────────────────────────────────────────────────────────────────────────────
// ─── LIFESTYLE ASIA SCRAPER ─────────────────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────────

app.post("/make-server-d507b98c/scrape/lifestyle-asia", async (c) => {
  try {
    const { url } = await c.req.json();
    const targetUrl = url || "https://www.lifestyleasia.com/hk/whats-on/events-whats-on/";

    const geminiKey = Deno.env.get("GEMINI_API_KEY");
    if (!geminiKey) {
      return c.json({ error: "GEMINI_API_KEY not configured" }, 500);
    }

    console.log(`LSA Scraper: Fetching ${targetUrl}`);

    const pageRes = await fetch(targetUrl, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
        "Cache-Control": "no-cache",
      },
      redirect: "follow",
    });

    if (!pageRes.ok) {
      return c.json({ error: `Failed to fetch page: HTTP ${pageRes.status}` }, 502);
    }

    const html = await pageRes.text();
    console.log(`LSA Scraper: Got ${html.length} chars of HTML`);

    // Strip scripts, styles, nav, footer to reduce tokens
    let cleaned = html
      .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')
      .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
      .replace(/<noscript[^>]*>[\s\S]*?<\/noscript>/gi, '')
      .replace(/<svg[^>]*>[\s\S]*?<\/svg>/gi, '')
      .replace(/<!--[\s\S]*?-->/g, '')
      .replace(/<header[^>]*>[\s\S]*?<\/header>/gi, '')
      .replace(/<footer[^>]*>[\s\S]*?<\/footer>/gi, '')
      .replace(/\s+/g, ' ')
      .trim();

    const truncated = cleaned.slice(0, 100000);
    console.log(`LSA Scraper: Sending ${truncated.length} chars to Gemini`);

    // Try multiple model names in case one is deprecated/renamed
    const GEMINI_MODELS = [
      "gemini-2.0-flash",
      "gemini-2.0-flash-lite",
      "gemini-1.5-flash",
    ];

    const prompt = `You are an expert web scraper specializing in extracting event listings from Hong Kong lifestyle/culture websites.

Analyze the following HTML from Lifestyle Asia Hong Kong's "What's On" / events section. Extract ALL event listings you can find.

For each event, extract:
- title: The event name/title
- date: Start date (ISO format YYYY-MM-DD if possible, otherwise the raw date string)
- endDate: End date if it's a multi-day event (YYYY-MM-DD)
- time: Start time (HH:MM 24h format)
- venueName: The venue/location name
- address: Full address if available
- district: The HK district (e.g., Central, Wan Chai, TST, etc.)
- description: Event description (full text, not truncated)
- image: The main event image URL (full URL)
- price: Price info (keep as-is, in HKD)
- ticketUrl: Link to buy tickets or the event page URL
- category: One of: nightlife, music, art, exhibition, food, wellness, workshop, family, sports, festival, film, theatre, other
- sourceUrl: The direct link to this specific event's page on Lifestyle Asia
- tags: Any tags, categories, or labels shown on the page

IMPORTANT:
- Extract ALL events visible on the page, not just the first few.
- For image URLs, ensure they are absolute URLs (starting with https://).
- For dates, try to parse them into YYYY-MM-DD format. If you see "March 15, 2026" then "2026-03-15".
- For dates like "Now through April 30" or "Until March 2026", set the date as today and endDate as the end.
- Today's date is 2026-03-12 for reference.
- If a district isn't explicitly mentioned, try to infer from the venue name or address.
- Include the event page URL as sourceUrl if you can construct it from href attributes.
- Base URL for relative links: https://www.lifestyleasia.com

Return ONLY a valid JSON array of event objects. No markdown, no explanation, just the JSON array.
Example:
[
  {
    "title": "Art Basel Hong Kong 2026",
    "date": "2026-03-27",
    "endDate": "2026-03-29",
    "time": "11:00",
    "venueName": "Hong Kong Convention and Exhibition Centre",
    "address": "1 Harbour Road, Wan Chai",
    "district": "Wan Chai",
    "description": "The largest art fair in Asia...",
    "image": "https://www.lifestyleasia.com/wp-content/uploads/...",
    "price": "HK$250",
    "ticketUrl": "https://...",
    "category": "exhibition",
    "sourceUrl": "https://www.lifestyleasia.com/hk/...",
    "tags": ["art", "exhibition", "art-basel"]
  }
]

Here is the HTML to analyze:

${truncated}`;

    const requestBody = JSON.stringify({
      contents: [{ parts: [{ text: prompt }] }],
      generationConfig: {
        temperature: 0.1,
        maxOutputTokens: 8192,
        responseMimeType: "application/json",
      },
    });

    let geminiRes: Response | null = null;
    let usedModel = "";
    for (const model of GEMINI_MODELS) {
      const geminiUrl = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${geminiKey}`;
      console.log(`LSA Scraper: Trying model ${model}...`);
      const res = await fetch(geminiUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: requestBody,
      });
      if (res.status === 404) {
        console.log(`LSA Scraper: Model ${model} returned 404, trying next...`);
        continue;
      }
      geminiRes = res;
      usedModel = model;
      break;
    }

    if (!geminiRes) {
      return c.json({ error: "All Gemini model variants returned 404. Check your GEMINI_API_KEY is valid and has the Generative Language API enabled." }, 502);
    }

    if (!geminiRes.ok) {
      const errText = await geminiRes.text();
      console.log(`Gemini API error (model=${usedModel}): ${geminiRes.status} - ${errText}`);
      return c.json({ error: `Gemini API error: ${geminiRes.status}`, details: errText }, 502);
    }

    const geminiData = await geminiRes.json();
    const geminiText = geminiData?.candidates?.[0]?.content?.parts?.[0]?.text || "";
    console.log(`LSA Scraper: Gemini returned ${geminiText.length} chars`);

    let events: any[] = [];
    try {
      const cleanJson = geminiText.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
      events = JSON.parse(cleanJson);
      if (!Array.isArray(events)) events = [events];
    } catch (parseErr) {
      console.log(`Failed to parse Gemini response: ${parseErr}`);
      return c.json({
        error: "Failed to parse AI response as structured data",
        rawResponse: geminiText.slice(0, 2000),
        htmlLength: html.length,
      }, 422);
    }

    // Normalize into CULTIVE format
    const normalized = events.map((ev: any, idx: number) => {
      const title = String(ev.title || '').trim();
      if (!title) return null;

      const slugStr = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
      const id = `lsa_${slugStr}_${idx}`.slice(0, 60);

      let district = ev.district || '';
      if (!district) {
        const searchText = `${ev.venueName || ''} ${ev.address || ''}`.toLowerCase();
        const DISTRICTS: [string, string][] = [
          ['central', 'Central'], ['admiralty', 'Admiralty'], ['wan chai', 'Wan Chai'],
          ['wanchai', 'Wan Chai'], ['causeway bay', 'Causeway Bay'], ['north point', 'North Point'],
          ['sheung wan', 'Sheung Wan'], ['sai ying pun', 'Sai Ying Pun'],
          ['kennedy town', 'Kennedy Town'], ['tai hang', 'Tai Hang'],
          ['tsim sha tsui', 'Tsim Sha Tsui'], ['tst', 'Tsim Sha Tsui'],
          ['mong kok', 'Mong Kok'], ['sham shui po', 'Sham Shui Po'],
          ['quarry bay', 'Quarry Bay'], ['wong chuk hang', 'Wong Chuk Hang'],
          ['stanley', 'Stanley'], ['repulse bay', 'Repulse Bay'],
        ];
        for (const [kw, label] of DISTRICTS) {
          if (searchText.includes(kw)) { district = label; break; }
        }
        if (!district) district = 'Hong Kong';
      }

      const allText = `${title} ${ev.category || ''} ${(ev.tags || []).join(' ')} ${ev.description || ''}`.toLowerCase();
      const modes: string[] = [];
      if (/nightlife|club|bar|cocktail|dj|party|rave/i.test(allText)) modes.push('degen');
      if (/art|gallery|exhibition|design|museum|theatre|film|cinema|creative|cultural/i.test(allText)) modes.push('artsy');
      if (/food|dining|restaurant|brunch|tasting|culinary|chef|wine|whisky|cocktail/i.test(allText)) modes.push('foodie');
      if (/family|kids|children|outdoor|nature|pet/i.test(allText)) modes.push('family');
      if (/wellness|yoga|meditation|workshop|lifestyle|fitness|spa|beauty|fashion/i.test(allText)) modes.push('lifestyle');
      if (modes.length === 0) modes.push('lifestyle');

      return {
        id, title,
        date: ev.date || '',
        endDate: ev.endDate || '',
        time: ev.time || '',
        venueName: ev.venueName || '',
        venueId: '',
        address: ev.address || '',
        district,
        description: ev.description || '',
        image: ev.image || '',
        price: ev.price || '',
        ticketUrl: ev.ticketUrl || '',
        sourceUrl: ev.sourceUrl || '',
        source: 'lifestyle-asia',
        _source: 'lsa',
        artists: [],
        genres: [],
        modeTags: modes,
        modes,
        vibes: [],
        category: ev.category || 'other',
        status: 'upcoming' as const,
        featured: false,
        tags: ev.tags || [],
        selected: true,
      };
    }).filter(Boolean);

    console.log(`LSA Scraper: Extracted ${normalized.length} events`);

    return c.json({
      events: normalized,
      meta: {
        url: targetUrl,
        scrapedAt: new Date().toISOString(),
        htmlLength: html.length,
        rawEventsCount: events.length,
        normalizedCount: normalized.length,
      },
    });
  } catch (err) {
    console.log(`LSA Scraper error: ${err}`);
    return c.json({ error: `Scraper failed: ${err}` }, 500);
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// ─── APIFY INTEGRATION ─────────────────────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────────

// Shared normalization helper for Apify items → CULTIVE event format
function normalizeApifyItem(item: any, idx: number): any {
  const title = String(item.title || item.name || item.eventTitle || '').trim();
  if (!title) return null;

  const slugStr = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  const id = item.id
    ? `apify_${String(item.id).replace(/[^a-z0-9_-]/gi, '').slice(0, 40)}`
    : `apify_${slugStr}_${idx}`.slice(0, 60);

  let district = item.district || '';
  if (!district) {
    const searchText = `${item.venueName || item.venue || ''} ${item.address || item.location || ''}`.toLowerCase();
    const DISTRICTS: [string, string][] = [
      ['central', 'Central'], ['admiralty', 'Admiralty'], ['wan chai', 'Wan Chai'],
      ['wanchai', 'Wan Chai'], ['causeway bay', 'Causeway Bay'], ['north point', 'North Point'],
      ['sheung wan', 'Sheung Wan'], ['sai ying pun', 'Sai Ying Pun'],
      ['kennedy town', 'Kennedy Town'], ['tai hang', 'Tai Hang'],
      ['tsim sha tsui', 'Tsim Sha Tsui'], ['tst', 'Tsim Sha Tsui'],
      ['mong kok', 'Mong Kok'], ['sham shui po', 'Sham Shui Po'],
      ['quarry bay', 'Quarry Bay'], ['wong chuk hang', 'Wong Chuk Hang'],
      ['stanley', 'Stanley'], ['repulse bay', 'Repulse Bay'],
      ['happy valley', 'Happy Valley'], ['soho', 'Central'],
      ['lan kwai fong', 'Central'], ['aberdeen', 'Aberdeen'],
      ['sai kung', 'Sai Kung'], ['yau ma tei', 'Yau Ma Tei'],
    ];
    for (const [kw, label] of DISTRICTS) {
      if (searchText.includes(kw)) { district = label; break; }
    }
    if (!district) district = 'Hong Kong';
  }

  const allText = `${title} ${item.category || ''} ${(item.tags || []).join(' ')} ${item.description || ''}`.toLowerCase();
  const modes: string[] = [];
  if (/nightlife|club|bar|cocktail|dj|party|rave|techno|house music/i.test(allText)) modes.push('degen');
  if (/art|gallery|exhibition|design|museum|theatre|film|cinema|creative|cultural|performance/i.test(allText)) modes.push('artsy');
  if (/food|dining|restaurant|brunch|tasting|culinary|chef|wine|whisky|cocktail|dim sum/i.test(allText)) modes.push('foodie');
  if (/family|kids|children|outdoor|nature|pet|playground/i.test(allText)) modes.push('family');
  if (/wellness|yoga|meditation|workshop|lifestyle|fitness|spa|beauty|fashion|run|hike/i.test(allText)) modes.push('lifestyle');
  if (modes.length === 0) modes.push('lifestyle');

  const date = item.date || item.startDate || item.eventDate || '';
  const time = item.time || item.startTime || '';
  const venueName = item.venueName || item.venue || item.locationName || item.place || '';
  // Clean description: fix concatenated words from HTML line-break stripping, strip boilerplate
  let description = item.description || item.text || item.content || item.summary || '';
  if (typeof description === 'string') {
    description = description
      .replace(/([a-z,;.])([A-Z])/g, '$1 $2')  // Fix "whitephotography" → "white Photography" etc.
      .replace(/About Member Galleries.*$/s, '')  // Strip nav menu boilerplate
      .replace(/Founded in 2012.*?non-profit organisation.*?Hong Kong\.?/g, '')  // Strip footer boilerplate
      .trim();
  }
  const image = item.image || item.imageUrl || item.photo || item.thumbnail || item.flyerFront || '';
  const price = item.price || item.cost || item.ticketPrice || '';
  const ticketUrl = item.ticketUrl || item.url || item.link || item.eventUrl || '';
  const sourceUrl = item.sourceUrl || item.url || item.link || '';
  // Strip opening hours from address field (common in HK-AGA scrapes)
  let address = item.address || item.location || item.fullAddress || '';
  if (typeof address === 'string') {
    address = address.replace(/\s*Opening Hours?:.*$/i, '').trim();
  }
  // Normalize category to CMS slugs at import time
  const _catMap: Record<string, string> = {
    'music': 'nightlife', 'nightlife': 'nightlife', 'club': 'nightlife', 'dj': 'nightlife',
    'party': 'nightlife', 'concert': 'nightlife', 'live music': 'nightlife', 'electronic': 'nightlife',
    'festival': 'nightlife', 'rave': 'nightlife',
    'art': 'art', 'arts': 'art', 'exhibition': 'art', 'gallery': 'art',
    'theatre': 'art', 'theater': 'art', 'film': 'art', 'cinema': 'art', 'performance': 'art',
    'design': 'art', 'photography': 'art', 'culture': 'art', 'cultural': 'art',
    'food': 'food', 'food & drink': 'food', 'dining': 'food', 'restaurant': 'food',
    'brunch': 'food', 'market': 'food', 'markets': 'food', 'culinary': 'food',
    'wellness': 'wellness', 'yoga': 'wellness', 'meditation': 'wellness', 'fitness': 'wellness',
    'run': 'run-clubs', 'running': 'run-clubs', 'run club': 'run-clubs',
    'hike': 'hikes', 'hiking': 'hikes', 'outdoors': 'hikes', 'nature': 'hikes',
    'coffee': 'coffee-raves', 'coffee rave': 'coffee-raves',
    'workshop': 'workshops', 'workshops': 'workshops', 'class': 'workshops',
    'meetup': 'meetups', 'community': 'meetups', 'networking': 'meetups',
    'family': 'family', 'kids': 'family',
  };
  const _catValid = ['run-clubs', 'wellness', 'hikes', 'coffee-raves', 'workshops', 'meetups', 'nightlife', 'art', 'food', 'family', 'other'];
  const rawCatStr = String(item.category || 'other').trim().toLowerCase();
  const category = _catValid.includes(rawCatStr) ? rawCatStr
    : (_catMap[rawCatStr] ? _catMap[rawCatStr]
    : (() => { for (const [kw, s] of Object.entries(_catMap)) { if (rawCatStr.includes(kw)) return s; } return 'other'; })());
  const artists = Array.isArray(item.artists) ? item.artists.map(String) :
    typeof item.artists === 'string' ? item.artists.split(',').map((s: string) => s.trim()).filter(Boolean) : [];
  const lat = item.lat || item.latitude || (item.geo?.lat) || (item.coordinates?.lat) || 0;
  const lng = item.lng || item.longitude || (item.geo?.lng) || (item.coordinates?.lng) || 0;

  return {
    id, title,
    date: typeof date === 'string' ? date : '',
    endDate: item.endDate || '',
    time: typeof time === 'string' ? time : '',
    venueName, venueId: '', address, district, description, image,
    price: typeof price === 'string' ? price : typeof price === 'number' ? `HK$${price}` : '',
    ticketUrl, sourceUrl,
    source: 'apify', _source: 'apify',
    artists,
    genres: Array.isArray(item.genres) ? item.genres.map(String) : [],
    modeTags: modes, modes,
    vibes: Array.isArray(item.vibes) ? item.vibes.map(String) : [],
    category, status: 'upcoming' as const, featured: false,
    tags: Array.isArray(item.tags) ? item.tags.map(String) : [],
    lat: typeof lat === 'number' ? lat : parseFloat(lat) || 0,
    lng: typeof lng === 'number' ? lng : parseFloat(lng) || 0,
    scrapedAt: item.scrapedAt || '',
    scrapedFrom: item.scrapedFrom || '',
    _createdAt: new Date().toISOString(),
    selected: true,
  };
}

// POST /apify/run — Start an Apify actor run
app.post("/make-server-d507b98c/apify/run", async (c) => {
  try {
    const token = Deno.env.get("APIFY_API_TOKEN");
    if (!token) return c.json({ error: "APIFY_API_TOKEN not configured" }, 500);
    const { actorId, input } = await c.req.json();
    if (!actorId) return c.json({ error: "actorId required" }, 400);
    console.log(`Apify: Starting actor ${actorId}`);
    const res = await fetch(
      `https://api.apify.com/v2/acts/${encodeURIComponent(actorId)}/runs?token=${token}`,
      { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(input || {}) }
    );
    if (!res.ok) {
      const errText = await res.text();
      return c.json({ error: `Apify API error: ${res.status}`, details: errText }, 502);
    }
    const data = await res.json();
    console.log(`Apify: Run started — ${data?.data?.id} (${data?.data?.status})`);
    return c.json({ runId: data?.data?.id, status: data?.data?.status, data: data?.data });
  } catch (err) {
    return c.json({ error: `Failed to start Apify actor: ${err}` }, 500);
  }
});

// GET /apify/run/:runId — Check run status
app.get("/make-server-d507b98c/apify/run/:runId", async (c) => {
  try {
    const token = Deno.env.get("APIFY_API_TOKEN");
    if (!token) return c.json({ error: "APIFY_API_TOKEN not configured" }, 500);
    const runId = c.req.param("runId");
    const res = await fetch(`https://api.apify.com/v2/actor-runs/${runId}?token=${token}`);
    if (!res.ok) return c.json({ error: `Apify API error: ${res.status}` }, 502);
    const data = await res.json();
    return c.json({
      status: data?.data?.status,
      startedAt: data?.data?.startedAt,
      finishedAt: data?.data?.finishedAt,
      defaultDatasetId: data?.data?.defaultDatasetId,
      stats: data?.data?.stats,
    });
  } catch (err) {
    return c.json({ error: `Failed to check run: ${err}` }, 500);
  }
});

// GET /apify/dataset/:datasetId — Fetch & normalize dataset items
app.get("/make-server-d507b98c/apify/dataset/:datasetId", async (c) => {
  try {
    const token = Deno.env.get("APIFY_API_TOKEN");
    if (!token) return c.json({ error: "APIFY_API_TOKEN not configured" }, 500);
    const datasetId = c.req.param("datasetId");
    const limit = c.req.query("limit") || "1000";
    const res = await fetch(
      `https://api.apify.com/v2/datasets/${datasetId}/items?token=${token}&limit=${limit}&format=json`
    );
    if (!res.ok) {
      const errText = await res.text();
      return c.json({ error: `Apify API error: ${res.status}`, details: errText }, 502);
    }
    const items = await res.json();
    console.log(`Apify: Fetched ${Array.isArray(items) ? items.length : 0} items from dataset ${datasetId}`);
    const normalized = (Array.isArray(items) ? items : []).map(normalizeApifyItem).filter(Boolean);
    return c.json({
      events: normalized, raw: items,
      meta: { datasetId, fetchedAt: new Date().toISOString(), rawCount: Array.isArray(items) ? items.length : 0, normalizedCount: normalized.length },
    });
  } catch (err) {
    return c.json({ error: `Failed to fetch dataset: ${err}` }, 500);
  }
});

// POST /apify/normalize — Normalize pasted JSON (no Apify run needed)
app.post("/make-server-d507b98c/apify/normalize", async (c) => {
  try {
    const { items } = await c.req.json();
    if (!Array.isArray(items)) return c.json({ error: "items must be an array" }, 400);
    const normalized = items.map(normalizeApifyItem).filter(Boolean);
    return c.json({ events: normalized, rawCount: items.length, normalizedCount: normalized.length });
  } catch (err) {
    return c.json({ error: `Normalize failed: ${err}` }, 500);
  }
});

// GET /apify/actors — List user's actors
app.get("/make-server-d507b98c/apify/actors", async (c) => {
  try {
    const token = Deno.env.get("APIFY_API_TOKEN");
    if (!token) return c.json({ error: "APIFY_API_TOKEN not configured" }, 500);
    const res = await fetch(`https://api.apify.com/v2/acts?token=${token}&limit=200`);
    if (!res.ok) return c.json({ error: `Apify API error: ${res.status}` }, 502);
    const data = await res.json();
    const actors = (data?.data?.items || []).map((a: any) => ({
      id: a.id, name: a.name, username: a.username,
      title: a.title || a.name, lastRun: a.stats?.lastRunStartedAt,
    }));
    return c.json({ actors });
  } catch (err) {
    return c.json({ error: `Failed to list actors: ${err}` }, 500);
  }
});

// GET /apify/runs/:actorId — List recent runs for an actor
app.get("/make-server-d507b98c/apify/runs/:actorId", async (c) => {
  try {
    const token = Deno.env.get("APIFY_API_TOKEN");
    if (!token) return c.json({ error: "APIFY_API_TOKEN not configured" }, 500);
    const actorId = c.req.param("actorId");
    const res = await fetch(`https://api.apify.com/v2/acts/${encodeURIComponent(actorId)}/runs?token=${token}&limit=10&desc=true`);
    if (!res.ok) return c.json({ error: `Apify API error: ${res.status}` }, 502);
    const data = await res.json();
    const runs = (data?.data?.items || []).map((r: any) => ({
      id: r.id, status: r.status, startedAt: r.startedAt, finishedAt: r.finishedAt,
      defaultDatasetId: r.defaultDatasetId, stats: r.stats,
    }));
    return c.json({ runs });
  } catch (err) {
    return c.json({ error: `Failed to list runs: ${err}` }, 500);
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// ─── ANALYTICS & REPORTS (Clawbot + Admin) ───────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────────

// Helper: gather all events from all sources
async function gatherAllEvents() {
  const seeded = (await kv.get("cultive:events")) || [];
  const published = await kv.getByPrefix("cultive:event:published:");
  const cmsEvents = await kv.getByPrefix("cultive:cms:event:");
  return [...(Array.isArray(seeded) ? seeded : []), ...published, ...cmsEvents].filter(Boolean);
}

// ─── Platform Overview ───
app.get("/make-server-d507b98c/admin/analytics/overview", async (c) => {
  try {
    const allEvents = await gatherAllEvents();
    const eventIds: string[] = allEvents.map((e: any) => e?.id).filter(Boolean);
    const uniqueIds = [...new Set(eventIds)];

    const viewKeys = uniqueIds.map(id => `cultive:event:${id}:views`);
    const saveKeys = uniqueIds.map(id => `cultive:event:${id}:saves`);
    const shareKeys = uniqueIds.map(id => `cultive:event:${id}:shares`);
    const [viewResults, saveResults, shareResults] = await Promise.all([
      viewKeys.length > 0 ? kv.mget(viewKeys) : Promise.resolve([]),
      saveKeys.length > 0 ? kv.mget(saveKeys) : Promise.resolve([]),
      shareKeys.length > 0 ? kv.mget(shareKeys) : Promise.resolve([]),
    ]);

    let totalViews = 0, totalSaves = 0, totalShares = 0;
    const eventStats: any[] = [];

    uniqueIds.forEach((id, i) => {
      const views = (viewResults[i] as number) || 0;
      const saves = (saveResults[i] as number) || 0;
      const shares = (shareResults[i] as number) || 0;
      totalViews += views;
      totalSaves += saves;
      totalShares += shares;
      const evt = allEvents.find((e: any) => e?.id === id);
      eventStats.push({
        id, title: evt?.title || id, views, saves, shares,
        category: evt?.category || (Array.isArray(evt?.categories) ? evt.categories[0] : undefined),
        venue: evt?.venueName || evt?.location || undefined,
        contributor: evt?.contributorName || undefined,
        date: evt?.date || undefined,
      });
    });

    const topByViews = [...eventStats].sort((a, b) => b.views - a.views).slice(0, 20);
    const topBySaves = [...eventStats].sort((a, b) => b.saves - a.saves).slice(0, 20);
    const topByShares = [...eventStats].sort((a, b) => b.shares - a.shares).slice(0, 20);

    const catBreakdown: Record<string, { views: number; saves: number; shares: number; count: number }> = {};
    eventStats.forEach(e => {
      const cat = e.category || 'uncategorized';
      if (!catBreakdown[cat]) catBreakdown[cat] = { views: 0, saves: 0, shares: 0, count: 0 };
      catBreakdown[cat].views += e.views;
      catBreakdown[cat].saves += e.saves;
      catBreakdown[cat].shares += e.shares;
      catBreakdown[cat].count += 1;
    });

    const venueBreakdown: Record<string, { views: number; saves: number; shares: number; count: number }> = {};
    eventStats.forEach(e => {
      if (!e.venue) return;
      if (!venueBreakdown[e.venue]) venueBreakdown[e.venue] = { views: 0, saves: 0, shares: 0, count: 0 };
      venueBreakdown[e.venue].views += e.views;
      venueBreakdown[e.venue].saves += e.saves;
      venueBreakdown[e.venue].shares += e.shares;
      venueBreakdown[e.venue].count += 1;
    });

    const contributorBreakdown: Record<string, { views: number; saves: number; shares: number; count: number }> = {};
    eventStats.forEach(e => {
      if (!e.contributor) return;
      if (!contributorBreakdown[e.contributor]) contributorBreakdown[e.contributor] = { views: 0, saves: 0, shares: 0, count: 0 };
      contributorBreakdown[e.contributor].views += e.views;
      contributorBreakdown[e.contributor].saves += e.saves;
      contributorBreakdown[e.contributor].shares += e.shares;
      contributorBreakdown[e.contributor].count += 1;
    });

    return c.json({
      overview: {
        totalEvents: uniqueIds.length,
        totalViews,
        totalSaves,
        totalShares,
        avgViewsPerEvent: uniqueIds.length > 0 ? Math.round(totalViews / uniqueIds.length * 10) / 10 : 0,
        avgSavesPerEvent: uniqueIds.length > 0 ? Math.round(totalSaves / uniqueIds.length * 10) / 10 : 0,
        avgSharesPerEvent: uniqueIds.length > 0 ? Math.round(totalShares / uniqueIds.length * 10) / 10 : 0,
      },
      topByViews,
      topBySaves,
      topByShares,
      categoryBreakdown: catBreakdown,
      venueBreakdown: Object.entries(venueBreakdown).map(([name, stats]) => ({ name, ...stats })).sort((a, b) => b.views - a.views).slice(0, 30),
      contributorBreakdown: Object.entries(contributorBreakdown).map(([name, stats]) => ({ name, ...stats })).sort((a, b) => b.views - a.views).slice(0, 30),
    });
  } catch (err) {
    console.log(`Error fetching analytics overview: ${err}`);
    return c.json({ error: `Failed to fetch analytics: ${err}` }, 500);
  }
});

// ─── Single Event Report ───
app.get("/make-server-d507b98c/admin/analytics/event/:id", async (c) => {
  try {
    const eventId = c.req.param("id");
    const [views, saves, shares] = await Promise.all([
      kv.get(`cultive:event:${eventId}:views`),
      kv.get(`cultive:event:${eventId}:saves`),
      kv.get(`cultive:event:${eventId}:shares`),
    ]);
    const allEvents = await gatherAllEvents();
    const event = allEvents.find((e: any) => e?.id === eventId);
    return c.json({
      eventId, title: event?.title || eventId,
      views: (views as number) || 0, saves: (saves as number) || 0, shares: (shares as number) || 0,
      category: event?.category, venue: event?.venueName || event?.location,
      date: event?.date, contributor: event?.contributorName,
    });
  } catch (err) {
    console.log(`Error fetching event analytics: ${err}`);
    return c.json({ error: `Failed to fetch event analytics: ${err}` }, 500);
  }
});

// ─── Generate Report (for Clawbot / Admin export) ───
app.post("/make-server-d507b98c/admin/analytics/report", async (c) => {
  try {
    const { type, targetId, targetName } = await c.req.json();
    const allEvents = await gatherAllEvents();

    let filteredEvents: any[];
    if (type === 'venue') {
      filteredEvents = allEvents.filter((e: any) => e.venueName === targetName || e.location === targetName || e.venueId === targetId);
    } else if (type === 'contributor') {
      filteredEvents = allEvents.filter((e: any) => e.contributorName === targetName);
    } else {
      filteredEvents = allEvents;
    }

    const ids = [...new Set(filteredEvents.map((e: any) => e.id).filter(Boolean))];
    const viewKeys = ids.map(id => `cultive:event:${id}:views`);
    const saveKeys = ids.map(id => `cultive:event:${id}:saves`);
    const shareKeys = ids.map(id => `cultive:event:${id}:shares`);
    const [vr, sr, shr] = await Promise.all([
      viewKeys.length > 0 ? kv.mget(viewKeys) : Promise.resolve([]),
      saveKeys.length > 0 ? kv.mget(saveKeys) : Promise.resolve([]),
      shareKeys.length > 0 ? kv.mget(shareKeys) : Promise.resolve([]),
    ]);

    let totalViews = 0, totalSaves = 0, totalShares = 0;
    const rows: any[] = [];
    ids.forEach((id, i) => {
      const v = (vr[i] as number) || 0;
      const s = (sr[i] as number) || 0;
      const sh = (shr[i] as number) || 0;
      totalViews += v; totalSaves += s; totalShares += sh;
      const evt = filteredEvents.find((e: any) => e.id === id);
      rows.push({ id, title: evt?.title || id, views: v, saves: s, shares: sh, date: evt?.date, category: evt?.category });
    });
    rows.sort((a, b) => b.views - a.views);

    return c.json({
      report: {
        reportType: type, targetName: targetName || 'CULTIVE Platform',
        generatedAt: new Date().toISOString(),
        summary: {
          totalEvents: ids.length, totalViews, totalSaves, totalShares,
          avgViews: ids.length > 0 ? Math.round(totalViews / ids.length * 10) / 10 : 0,
          avgSaves: ids.length > 0 ? Math.round(totalSaves / ids.length * 10) / 10 : 0,
          avgShares: ids.length > 0 ? Math.round(totalShares / ids.length * 10) / 10 : 0,
          conversionRate: totalViews > 0 ? Math.round((totalSaves / totalViews) * 1000) / 10 : 0,
        },
        topEvents: rows.slice(0, 10),
        allEvents: rows,
      },
    });
  } catch (err) {
    console.log(`Error generating report: ${err}`);
    return c.json({ error: `Failed to generate report: ${err}` }, 500);
  }
});

Deno.serve(
  {
    onError: (err: unknown) => {
      const e = err as any;
      // Silently ignore EPIPE / broken-pipe errors: these are caused by the
      // client disconnecting before we finish streaming the response body.
      // They are non-fatal and logging them as full errors just creates noise.
      if (
        e?.name === "Http" ||
        e?.code === "EPIPE" ||
        (typeof e?.message === "string" &&
          (e.message.includes("broken pipe") ||
            e.message.includes("connection reset") ||
            e.message.includes("connection closed") ||
            e.message.includes("EPIPE")))
      ) {
        // Non-fatal: client disconnected before response was fully sent — suppress
        return new Response(null, { status: 499 }); // 499 = Client Closed Request
      }
      console.log(`[Server] Unhandled error: ${err}`);
      return new Response("Internal Server Error", { status: 500 });
    },
  },
  // Wrap app.fetch so that if the client already aborted we skip processing
  async (req: Request, connInfo: unknown) => {
    try {
      return await (app.fetch as any)(req, connInfo);
    } catch (err: unknown) {
      const e = err as any;
      if (
        e?.name === "Http" ||
        e?.code === "EPIPE" ||
        (typeof e?.message === "string" &&
          (e.message.includes("broken pipe") ||
            e.message.includes("connection closed") ||
            e.message.includes("EPIPE")))
      ) {
        return new Response(null, { status: 499 });
      }
      throw err;
    }
  }
);