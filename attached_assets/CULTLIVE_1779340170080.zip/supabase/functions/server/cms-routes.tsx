import { Hono } from "npm:hono";
import { createClient } from "npm:@supabase/supabase-js@2";
import * as kv from "./kv_store.tsx";

const cms = new Hono();

const BUCKET_NAME = "make-d507b98c-submissions";

// Ensure storage bucket exists (called lazily on first upload)
let bucketReady = false;
async function ensureBucket() {
  if (bucketReady) return;
  try {
    const supabase = getSupabaseAdmin();
    const { data: buckets } = await supabase.storage.listBuckets();
    const bucketExists = buckets?.some((b: any) => b.name === BUCKET_NAME);
    if (!bucketExists) {
      await supabase.storage.createBucket(BUCKET_NAME, { public: false });
      console.log(`Created storage bucket: ${BUCKET_NAME}`);
    }
    bucketReady = true;
  } catch (err) {
    console.log(`Error ensuring bucket: ${err}`);
  }
}

// ─── Helpers ───
function generateId() {
  return `sub_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

function generateContributorId() {
  return `con_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

// ─── Hidden/deleted event ID blacklist ───
// When an admin deletes or rejects an event/submission, its ID is added here
// so the frontend can filter it out even if the seed data still has it.
const HIDDEN_IDS_KEY = "cms:hidden_event_ids";

async function addToHiddenIds(id: string) {
  const ids = ((await kv.get(HIDDEN_IDS_KEY)) as string[]) || [];
  if (!ids.includes(id)) {
    ids.push(id);
    await kv.set(HIDDEN_IDS_KEY, ids);
    console.log(`Added ${id} to hidden event IDs blacklist`);
  }
}

async function removeFromHiddenIds(id: string) {
  const ids = ((await kv.get(HIDDEN_IDS_KEY)) as string[]) || [];
  const filtered = ids.filter((i) => i !== id);
  if (filtered.length !== ids.length) {
    await kv.set(HIDDEN_IDS_KEY, filtered);
    console.log(`Removed ${id} from hidden event IDs blacklist`);
  }
}

function getSupabaseAdmin() {
  return createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );
}

// ─── Nominatim Geocoding (OpenStreetMap — free, no API key) ───
const NOMINATIM_CACHE: Record<string, { lat: number; lng: number } | null> = {};

async function geocodeWithNominatim(query: string): Promise<{ lat: number; lng: number } | null> {
  // Check cache first
  const cacheKey = query.toLowerCase().trim();
  if (cacheKey in NOMINATIM_CACHE) return NOMINATIM_CACHE[cacheKey];

  try {
    const encoded = encodeURIComponent(query);
    const res = await fetch(
      `https://nominatim.openstreetmap.org/search?q=${encoded}&format=json&limit=1&countrycodes=hk`,
      {
        headers: {
          "User-Agent": "CULTIVE-HK/1.0 (cultural-events-platform)",
          "Accept": "application/json",
        },
      }
    );
    if (!res.ok) {
      console.log(`Nominatim error: ${res.status} ${res.statusText}`);
      NOMINATIM_CACHE[cacheKey] = null;
      return null;
    }
    const data = await res.json();
    if (data.length > 0) {
      const result = { lat: parseFloat(data[0].lat), lng: parseFloat(data[0].lon) };
      console.log(`Geocoded "${query}" → ${result.lat}, ${result.lng}`);
      NOMINATIM_CACHE[cacheKey] = result;
      return result;
    }
    NOMINATIM_CACHE[cacheKey] = null;
    return null;
  } catch (err) {
    console.log(`Nominatim fetch error for "${query}": ${err}`);
    NOMINATIM_CACHE[cacheKey] = null;
    return null;
  }
}

/** Build geocoding queries from submission data, from most specific to broadest */
function buildGeoQueries(location: string, district: string): string[] {
  const queries: string[] = [];
  const loc = location?.trim();
  const dist = district?.trim();
  if (loc && dist) queries.push(`${loc}, ${dist}, Hong Kong`);
  if (loc) queries.push(`${loc}, Hong Kong`);
  if (dist) queries.push(`${dist}, Hong Kong`);
  return queries;
}

/** Try geocoding with progressively broader queries until one succeeds */
async function geocodeSubmission(location: string, district: string): Promise<{ lat: number; lng: number } | null> {
  const queries = buildGeoQueries(location, district);
  for (const q of queries) {
    const result = await geocodeWithNominatim(q);
    if (result) return result;
  }
  return null;
}

// ─── Storage URL helpers ───
const SUPABASE_URL = Deno.env.get("SUPABASE_URL") || "";

/**
 * Detect Supabase Storage signed URLs and extract bucket + path.
 * Signed URL format: https://{ref}.supabase.co/storage/v1/object/sign/{bucket}/{path}?token=...
 */
function parseStorageSignedUrl(url: string): { bucket: string; path: string } | null {
  try {
    const u = new URL(url);
    const match = u.pathname.match(/^\/storage\/v1\/object\/sign\/([^/]+)\/(.+)$/);
    if (match) return { bucket: match[1], path: match[2] };
  } catch {}
  return null;
}

/**
 * Recursively walk an object and re-sign any expired Supabase Storage signed URLs.
 * Returns a new object with fresh signed URLs (valid 7 days).
 */
async function refreshStorageUrls(obj: any, supabase: any): Promise<any> {
  if (typeof obj === "string") {
    const parsed = parseStorageSignedUrl(obj);
    if (parsed) {
      const { data, error } = await supabase.storage
        .from(parsed.bucket)
        .createSignedUrl(parsed.path, 60 * 60 * 24 * 7); // 7 days
      if (data?.signedUrl) return data.signedUrl;
      console.log(`Re-sign failed for ${parsed.path}: ${error?.message}`);
    }
    return obj;
  }
  if (Array.isArray(obj)) {
    return Promise.all(obj.map((item) => refreshStorageUrls(item, supabase)));
  }
  if (obj && typeof obj === "object") {
    const result: Record<string, any> = {};
    for (const [key, value] of Object.entries(obj)) {
      result[key] = await refreshStorageUrls(value, supabase);
    }
    return result;
  }
  return obj;
}

async function verifyAdmin(authHeader: string | undefined) {
  if (!authHeader) return null;
  const token = authHeader.replace("Bearer ", "");
  const supabase = getSupabaseAdmin();
  const { data, error } = await supabase.auth.getUser(token);
  if (error || !data?.user) return null;
  // Check if user is admin (stored in user metadata)
  const adminEmails = await kv.get("cms:admin_emails");
  const isAdmin =
    data.user.user_metadata?.role === "admin" ||
    (Array.isArray(adminEmails) && adminEmails.includes(data.user.email));
  if (!isAdmin) return null;
  return data.user;
}

// ─── AI Moderation (rule-based scoring) ───
interface ModerationResult {
  score: number; // 0-100
  status: "ai-approved" | "ai-flagged" | "ai-rejected";
  reasons: string[];
  checks: Record<string, boolean>;
}

function moderateSubmission(submission: any): ModerationResult {
  const checks: Record<string, boolean> = {};
  const reasons: string[] = [];
  let score = 50; // Start at 50

  // Check: Has title
  checks["has_title"] = !!submission.title?.trim();
  if (checks["has_title"]) {
    score += 10;
  } else {
    score -= 15;
    reasons.push("Missing title");
  }

  // Check: Has description (min 20 chars)
  checks["has_description"] =
    !!submission.description?.trim() && submission.description.length >= 20;
  if (checks["has_description"]) {
    score += 10;
  } else {
    score -= 10;
    reasons.push("Description too short or missing");
  }

  // Check: Has images
  checks["has_images"] =
    Array.isArray(submission.images) && submission.images.length > 0;
  if (checks["has_images"]) {
    score += 10;
  } else {
    score -= 10;
    reasons.push("No images provided");
  }

  // Check: Has location/venue
  checks["has_location"] = !!submission.location?.trim();
  if (checks["has_location"]) {
    score += 5;
  } else {
    reasons.push("No location specified");
  }

  // Check: Has date
  checks["has_date"] = !!submission.date?.trim();
  if (checks["has_date"]) {
    score += 5;
  } else {
    reasons.push("No date provided");
  }

  // Check: Has source URL (Instagram/Google Maps)
  checks["has_source"] = !!submission.sourceUrl?.trim();
  if (checks["has_source"]) score += 5;

  // Check: Not generic/spam (simple keyword check)
  const genericTerms = [
    "test",
    "asdf",
    "lorem ipsum",
    "sample",
    "hello world",
  ];
  const titleLower = (submission.title || "").toLowerCase();
  const descLower = (submission.description || "").toLowerCase();
  checks["not_spam"] = !genericTerms.some(
    (t) => titleLower.includes(t) || descLower.includes(t)
  );
  if (!checks["not_spam"]) {
    score -= 30;
    reasons.push("Suspected spam or test submission");
  }

  // Check: Has contributor info
  checks["has_contributor"] = !!submission.contributorName?.trim();
  if (checks["has_contributor"]) score += 5;

  // Clamp score
  score = Math.max(0, Math.min(100, score));

  // Determine status
  let status: ModerationResult["status"];
  if (score >= 70) {
    status = "ai-approved";
    if (reasons.length === 0) reasons.push("Meets all quality requirements");
  } else if (score >= 40) {
    status = "ai-flagged";
    reasons.push("Needs human review - some requirements not met");
  } else {
    status = "ai-rejected";
    reasons.push("Below minimum quality threshold");
  }

  return { score, status, reasons, checks };
}

// ═══════════════════════════════════════════════════
// ADMIN AUTH
// ═══════════════════════════════════════════════════

// POST /cms/admin/signup — Create first admin (only works if no admins exist)
cms.post("/admin/signup", async (c) => {
  try {
    const { email, password, name } = await c.req.json();
    if (!email || !password) {
      return c.json({ error: "Email and password required" }, 400);
    }

    // Check if any admin exists
    const existingAdmins = await kv.get("cms:admin_emails");
    if (Array.isArray(existingAdmins) && existingAdmins.length > 0) {
      return c.json(
        {
          error:
            "Admin already exists. Contact existing admin for access.",
        },
        403
      );
    }

    const supabase = getSupabaseAdmin();
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name: name || "Admin", role: "admin" },
      email_confirm: true,
    });

    if (error) {
      console.log(`Admin signup error: ${error.message}`);
      return c.json(
        { error: `Failed to create admin account: ${error.message}` },
        400
      );
    }

    // Store admin email
    await kv.set("cms:admin_emails", [email]);

    return c.json({
      status: "created",
      user: { id: data.user.id, email: data.user.email },
    });
  } catch (err) {
    console.log(`Admin signup error: ${err}`);
    return c.json({ error: `Admin signup failed: ${err}` }, 500);
  }
});

// GET /cms/admin/check — Check if any admin exists
cms.get("/admin/check", async (c) => {
  try {
    const existingAdmins = await kv.get("cms:admin_emails");
    const hasAdmin =
      Array.isArray(existingAdmins) && existingAdmins.length > 0;
    return c.json({ hasAdmin });
  } catch (err) {
    return c.json({ hasAdmin: false });
  }
});

// ═══════════════════════════════════════════════════
// SUBMISSIONS (public create, admin manage)
// ═══════════════════════════════════════════════════

// POST /cms/submissions — Create a new submission (public)
cms.post("/submissions", async (c) => {
  try {
    const body = await c.req.json();
    const id = generateId();
    const now = new Date().toISOString();

    // Run AI moderation
    const moderation = moderateSubmission(body);

    const submission = {
      id,
      ...body,
      // Ensure arrays
      images: Array.isArray(body.images) ? body.images : [],
      tags: Array.isArray(body.tags) ? body.tags : [],
      categories: Array.isArray(body.categories) ? body.categories : (body.category ? [body.category] : []),
      // Metadata
      createdAt: now,
      updatedAt: now,
      // AI moderation results
      aiScore: moderation.score,
      aiStatus: moderation.status,
      aiReasons: moderation.reasons,
      aiChecks: moderation.checks,
      // Admin status (AI sets initial, admin can override)
      status: moderation.status === "ai-rejected" ? "rejected" : moderation.status,
      adminNotes: "",
      reviewedAt: null,
      reviewedBy: null,
      // Publishing
      publishedAt: null,
      // Source tracking
      source: body.source || "manual",
      sourceUrl: body.sourceUrl || "",
    };

    // If coordinates were provided (e.g. from Google Maps URL), store them
    if (body.lat && body.lng) {
      submission.lat = parseFloat(body.lat);
      submission.lng = parseFloat(body.lng);
      submission.geocodedAt = now;
    }

    await kv.set(`cms:submission:${id}`, submission);

    // Update index
    const ids = ((await kv.get("cms:submission_ids")) as string[]) || [];
    ids.push(id);
    await kv.set("cms:submission_ids", ids);

    // Track contributor
    if (body.contributorEmail) {
      await trackContributor(body.contributorEmail, body.contributorName, id);
    }

    // Auto-geocode in background if no coords yet (non-blocking)
    if (!submission.lat && (body.location || body.district)) {
      geocodeSubmission(body.location || "", body.district || "").then(async (coords) => {
        if (coords) {
          const updated = (await kv.get(`cms:submission:${id}`)) as any;
          if (updated) {
            updated.lat = coords.lat;
            updated.lng = coords.lng;
            updated.geocodedAt = new Date().toISOString();
            await kv.set(`cms:submission:${id}`, updated);
            console.log(`Auto-geocoded submission ${id}: ${coords.lat}, ${coords.lng}`);
          }
        }
      }).catch(err => console.log(`Background geocode failed for ${id}: ${err}`));
    }

    return c.json({
      status: "submitted",
      id,
      aiScore: moderation.score,
      aiStatus: moderation.status,
      message:
        moderation.status === "ai-approved"
          ? "Your submission looks great! It will be reviewed shortly."
          : moderation.status === "ai-flagged"
            ? "Submitted! Our team will review it soon."
            : "Thank you for your submission. We'll review it.",
    });
  } catch (err) {
    console.log(`Error creating submission: ${err}`);
    return c.json({ error: `Failed to create submission: ${err}` }, 500);
  }
});

// GET /cms/submissions — List submissions (admin only)
cms.get("/submissions", async (c) => {
  try {
    const authHeader = c.req.header("X-Auth-Token");
    const admin = await verifyAdmin(authHeader);
    if (!admin) {
      return c.json({ error: "Unauthorized - admin access required" }, 401);
    }

    const statusFilter = c.req.query("status");
    const ids = ((await kv.get("cms:submission_ids")) as string[]) || [];

    if (ids.length === 0) {
      return c.json({ submissions: [], counts: getEmptyCounts() });
    }

    const keys = ids.map((id) => `cms:submission:${id}`);
    const allSubmissions = (await kv.mget(keys)).filter(Boolean) as any[];

    // Calculate counts
    const counts: Record<string, number> = {
      total: allSubmissions.length,
      pending: 0,
      "ai-approved": 0,
      "ai-flagged": 0,
      approved: 0,
      published: 0,
      rejected: 0,
    };
    allSubmissions.forEach((s) => {
      if (counts[s.status] !== undefined) counts[s.status]++;
    });

    // Filter if needed
    const submissions = statusFilter
      ? allSubmissions.filter((s) => s.status === statusFilter)
      : allSubmissions;

    // Sort by newest first
    submissions.sort(
      (a: any, b: any) =>
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );

    // Re-sign any expired Supabase Storage URLs in images
    const supabase = getSupabaseAdmin();
    const refreshed = await Promise.all(
      submissions.map((s) => refreshStorageUrls(s, supabase))
    );

    return c.json({ submissions: refreshed, counts });
  } catch (err) {
    console.log(`Error listing submissions: ${err}`);
    return c.json({ error: `Failed to list submissions: ${err}` }, 500);
  }
});

// PUT /cms/submissions/:id/status — Update submission status (admin only)
cms.put("/submissions/:id/status", async (c) => {
  try {
    const authHeader = c.req.header("X-Auth-Token");
    const admin = await verifyAdmin(authHeader);
    if (!admin) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const id = c.req.param("id");
    const { status, adminNotes } = await c.req.json();

    const submission = (await kv.get(`cms:submission:${id}`)) as any;
    if (!submission) {
      return c.json({ error: `Submission not found: ${id}` }, 404);
    }

    const now = new Date().toISOString();
    const updated = {
      ...submission,
      status,
      adminNotes: adminNotes || submission.adminNotes,
      reviewedAt: now,
      reviewedBy: admin.email,
      updatedAt: now,
      publishedAt: status === "published" ? now : submission.publishedAt,
    };

    await kv.set(`cms:submission:${id}`, updated);

    // Update hidden IDs blacklist based on status change
    if (status === "rejected") {
      await addToHiddenIds(id);
    } else if (status === "published" || status === "approved") {
      // If re-publishing, remove from blacklist
      await removeFromHiddenIds(id);
    }

    return c.json({ status: "updated", submission: updated });
  } catch (err) {
    console.log(`Error updating submission status: ${err}`);
    return c.json({ error: `Failed to update: ${err}` }, 500);
  }
});

// PATCH /cms/submissions/:id — Update submission fields (admin only)
cms.patch("/submissions/:id", async (c) => {
  try {
    const authHeader = c.req.header("X-Auth-Token");
    const admin = await verifyAdmin(authHeader);
    if (!admin) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const id = c.req.param("id");
    const updates = await c.req.json();

    const submission = (await kv.get(`cms:submission:${id}`)) as any;
    if (!submission) {
      return c.json({ error: `Submission not found: ${id}` }, 404);
    }

    // Only allow specific fields to be updated
    const allowedFields = ["categories", "category", "title", "description", "date", "time", "location", "district", "price", "lat", "lng", "venueId", "eventId"];
    const safeUpdates: Record<string, any> = {};
    for (const field of allowedFields) {
      if (updates[field] !== undefined) {
        safeUpdates[field] = updates[field];
      }
    }

    const now = new Date().toISOString();
    const updated = {
      ...submission,
      ...safeUpdates,
      updatedAt: now,
      lastEditedBy: admin.email,
    };

    await kv.set(`cms:submission:${id}`, updated);
    console.log(`Submission ${id} fields updated by ${admin.email}: ${Object.keys(safeUpdates).join(", ")}`);
    return c.json({ status: "updated", submission: updated });
  } catch (err) {
    console.log(`Error updating submission fields: ${err}`);
    return c.json({ error: `Failed to update submission: ${err}` }, 500);
  }
});

// POST /cms/submissions/bulk-action — Bulk approve/reject (admin only)
cms.post("/submissions/bulk-action", async (c) => {
  try {
    const authHeader = c.req.header("X-Auth-Token");
    const admin = await verifyAdmin(authHeader);
    if (!admin) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { ids: submissionIds, action } = await c.req.json();
    if (!Array.isArray(submissionIds) || !action) {
      return c.json({ error: "ids (array) and action required" }, 400);
    }

    const now = new Date().toISOString();
    let updated = 0;

    for (const id of submissionIds) {
      const submission = (await kv.get(`cms:submission:${id}`)) as any;
      if (submission) {
        submission.status = action;
        submission.reviewedAt = now;
        submission.reviewedBy = admin.email;
        submission.updatedAt = now;
        if (action === "published") submission.publishedAt = now;
        await kv.set(`cms:submission:${id}`, submission);

        // Update hidden IDs blacklist
        if (action === "rejected") {
          await addToHiddenIds(id);
        } else if (action === "published" || action === "approved") {
          await removeFromHiddenIds(id);
        }

        updated++;
      }
    }

    return c.json({ status: "updated", count: updated });
  } catch (err) {
    console.log(`Error in bulk action: ${err}`);
    return c.json({ error: `Bulk action failed: ${err}` }, 500);
  }
});

// DELETE /cms/submissions/:id — Delete submission (admin only)
cms.delete("/submissions/:id", async (c) => {
  try {
    const authHeader = c.req.header("X-Auth-Token");
    const admin = await verifyAdmin(authHeader);
    if (!admin) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const id = c.req.param("id");
    await kv.del(`cms:submission:${id}`);

    // Remove from index
    const ids = ((await kv.get("cms:submission_ids")) as string[]) || [];
    const filtered = ids.filter((i) => i !== id);
    await kv.set("cms:submission_ids", filtered);

    // Add to hidden IDs blacklist so seed data doesn't resurrect it
    await addToHiddenIds(id);

    return c.json({ status: "deleted" });
  } catch (err) {
    console.log(`Error deleting submission: ${err}`);
    return c.json({ error: `Failed to delete: ${err}` }, 500);
  }
});

// GET /cms/hidden-ids — Public: get list of hidden/deleted event IDs
cms.get("/hidden-ids", async (c) => {
  try {
    const ids = ((await kv.get(HIDDEN_IDS_KEY)) as string[]) || [];
    return c.json({ ids });
  } catch (err) {
    console.log(`Error fetching hidden IDs: ${err}`);
    return c.json({ ids: [] });
  }
});

// POST /cms/hidden-ids — Admin: manually add IDs to the blacklist
cms.post("/hidden-ids", async (c) => {
  try {
    const authHeader = c.req.header("X-Auth-Token");
    const admin = await verifyAdmin(authHeader);
    if (!admin) return c.json({ error: "Unauthorized" }, 401);

    const { ids: newIds, action } = await c.req.json();
    if (!Array.isArray(newIds)) return c.json({ error: "ids (array) required" }, 400);

    if (action === "remove") {
      for (const id of newIds) await removeFromHiddenIds(id);
    } else {
      for (const id of newIds) await addToHiddenIds(id);
    }

    const current = ((await kv.get(HIDDEN_IDS_KEY)) as string[]) || [];
    return c.json({ status: "updated", ids: current });
  } catch (err) {
    console.log(`Error updating hidden IDs: ${err}`);
    return c.json({ error: `Failed to update: ${err}` }, 500);
  }
});

// POST /cms/hidden-ids/sync — Admin: scan for orphaned submissions and auto-clean
cms.post("/hidden-ids/sync", async (c) => {
  try {
    const authHeader = c.req.header("X-Auth-Token");
    const admin = await verifyAdmin(authHeader);
    if (!admin) return c.json({ error: "Unauthorized" }, 401);

    // Find all submissions that are rejected but not yet in the blacklist
    const subIds = ((await kv.get("cms:submission_ids")) as string[]) || [];
    const subKeys = subIds.map((id) => `cms:submission:${id}`);
    const allSubs = subIds.length > 0 ? (await kv.mget(subKeys)).filter(Boolean) as any[] : [];
    
    let added = 0;
    for (const sub of allSubs) {
      if (sub.status === "rejected") {
        await addToHiddenIds(sub.id);
        added++;
      }
    }

    const current = ((await kv.get(HIDDEN_IDS_KEY)) as string[]) || [];
    return c.json({ status: "synced", added, totalHidden: current.length });
  } catch (err) {
    console.log(`Error syncing hidden IDs: ${err}`);
    return c.json({ error: `Failed to sync: ${err}` }, 500);
  }
});

// GET /cms/submissions/published — Public: get approved/published submissions
cms.get("/submissions/published", async (c) => {
  try {
    const ids = ((await kv.get("cms:submission_ids")) as string[]) || [];
    if (ids.length === 0) return c.json({ submissions: [] });

    const keys = ids.map((id) => `cms:submission:${id}`);
    const all = (await kv.mget(keys)).filter(Boolean) as any[];
    const published = all
      .filter((s) => s.status === "published" || s.status === "approved")
      .sort(
        (a: any, b: any) =>
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );

    // Re-sign any expired storage URLs
    const supabase = getSupabaseAdmin();
    const refreshed = await Promise.all(
      published.map((s) => refreshStorageUrls(s, supabase))
    );

    // Background: geocode any published submissions missing coordinates (non-blocking)
    const ungeocoded = published.filter((s) => !s.lat && (s.location || s.district));
    if (ungeocoded.length > 0) {
      (async () => {
        for (const sub of ungeocoded.slice(0, 3)) { // Limit to 3 per request to respect Nominatim rate limits
          try {
            const coords = await geocodeSubmission(sub.location || "", sub.district || "");
            if (coords) {
              sub.lat = coords.lat;
              sub.lng = coords.lng;
              sub.geocodedAt = new Date().toISOString();
              await kv.set(`cms:submission:${sub.id}`, sub);
              console.log(`Background geocoded ${sub.id}: ${coords.lat}, ${coords.lng}`);
            }
            // Nominatim rate limit: 1 req/sec
            await new Promise((r) => setTimeout(r, 1100));
          } catch (err) {
            console.log(`Background geocode error for ${sub.id}: ${err}`);
          }
        }
      })().catch(() => {});
    }

    return c.json({ submissions: refreshed });
  } catch (err) {
    console.log(`Error fetching published submissions: ${err}`);
    return c.json({ error: `Failed to fetch: ${err}` }, 500);
  }
});

// GET /cms/submission-status/:id — Public: contributor checks their submission status
cms.get("/submission-status/:id", async (c) => {
  try {
    const id = c.req.param("id");
    const submission = (await kv.get(`cms:submission:${id}`)) as any;
    if (!submission) {
      return c.json({ error: "Submission not found" }, 404);
    }

    // Return limited public info
    return c.json({
      id: submission.id,
      title: submission.title,
      status: submission.status,
      createdAt: submission.createdAt,
      message: getStatusMessage(submission.status),
    });
  } catch (err) {
    return c.json({ error: `Failed to check status: ${err}` }, 500);
  }
});

// GET /cms/event/:id — Public: get a single published submission by ID
cms.get("/event/:id", async (c) => {
  try {
    const id = c.req.param("id");
    const submission = (await kv.get(`cms:submission:${id}`)) as any;
    if (!submission) {
      return c.json({ error: "Event not found" }, 404);
    }
    if (submission.status !== "published" && submission.status !== "approved") {
      return c.json({ error: "Event not available" }, 404);
    }

    const supabase = getSupabaseAdmin();
    const refreshed = await refreshStorageUrls(submission, supabase);

    return c.json({
      event: {
        id: refreshed.id,
        title: refreshed.title,
        description: refreshed.description,
        date: refreshed.date,
        time: refreshed.time,
        location: refreshed.location,
        district: refreshed.district,
        category: refreshed.category,
        categories: Array.isArray(refreshed.categories) ? refreshed.categories : (refreshed.category ? [refreshed.category] : []),
        images: refreshed.images || [],
        tags: refreshed.tags || [],
        price: refreshed.price,
        source: refreshed.source,
        sourceUrl: refreshed.sourceUrl,
        contributorName: refreshed.contributorName,
        contributorInstagram: refreshed.contributorInstagram,
        publishedAt: refreshed.publishedAt,
        createdAt: refreshed.createdAt,
        lat: refreshed.lat || undefined,
        lng: refreshed.lng || undefined,
      },
    });
  } catch (err) {
    console.log(`Error fetching published submission: ${err}`);
    return c.json({ error: `Failed to fetch event: ${err}` }, 500);
  }
});

// GET /cms/geocode — Public: geocode a location string using Nominatim
cms.get("/geocode", async (c) => {
  try {
    const query = c.req.query("q");
    const location = c.req.query("location") || "";
    const district = c.req.query("district") || "";

    if (query) {
      const result = await geocodeWithNominatim(query.includes("Hong Kong") ? query : `${query}, Hong Kong`);
      return c.json({ result, query });
    }

    if (location || district) {
      const result = await geocodeSubmission(location, district);
      return c.json({ result, location, district });
    }

    return c.json({ error: "Provide ?q=query or ?location=...&district=..." }, 400);
  } catch (err) {
    console.log(`Geocode error: ${err}`);
    return c.json({ error: `Geocoding failed: ${err}` }, 500);
  }
});

// POST /cms/geocode-submission/:id — Admin: geocode/re-geocode a specific submission
cms.post("/geocode-submission/:id", async (c) => {
  try {
    const id = c.req.param("id");
    const submission = (await kv.get(`cms:submission:${id}`)) as any;
    if (!submission) return c.json({ error: "Submission not found" }, 404);

    const location = submission.location || submission.venueName || "";
    const district = submission.district || "";
    const result = await geocodeSubmission(location, district);

    if (result) {
      submission.lat = result.lat;
      submission.lng = result.lng;
      submission.geocodedAt = new Date().toISOString();
      await kv.set(`cms:submission:${id}`, submission);
      return c.json({ success: true, lat: result.lat, lng: result.lng });
    }

    return c.json({ success: false, message: "Could not geocode this location" });
  } catch (err) {
    console.log(`Geocode submission error: ${err}`);
    return c.json({ error: `Failed: ${err}` }, 500);
  }
});

// ═══════════════════════════════════════════════════
// CONTRIBUTORS
// ═══════════════════════════════════════════════════

async function trackContributor(
  email: string,
  name: string,
  submissionId: string
) {
  const contributorKey = `cms:contributor:${email.toLowerCase().replace(/[^a-z0-9]/g, "_")}`;
  const existing = (await kv.get(contributorKey)) as any;

  if (existing) {
    existing.submissionIds.push(submissionId);
    existing.submissionCount = existing.submissionIds.length;
    existing.lastSubmission = new Date().toISOString();
    await kv.set(contributorKey, existing);
  } else {
    const contributor = {
      id: generateContributorId(),
      email: email.toLowerCase(),
      name: name || "Anonymous",
      submissionIds: [submissionId],
      submissionCount: 1,
      firstSubmission: new Date().toISOString(),
      lastSubmission: new Date().toISOString(),
      status: "active",
    };
    await kv.set(contributorKey, contributor);

    // Update index
    const ids =
      ((await kv.get("cms:contributor_ids")) as string[]) || [];
    ids.push(contributorKey);
    await kv.set("cms:contributor_ids", ids);
  }
}

// GET /cms/contributors — List contributors (admin only)
cms.get("/contributors", async (c) => {
  try {
    const authHeader = c.req.header("X-Auth-Token");
    const admin = await verifyAdmin(authHeader);
    if (!admin) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const ids =
      ((await kv.get("cms:contributor_ids")) as string[]) || [];
    if (ids.length === 0) return c.json({ contributors: [] });

    const contributors = (await kv.mget(ids)).filter(Boolean);
    return c.json({ contributors });
  } catch (err) {
    console.log(`Error listing contributors: ${err}`);
    return c.json({ error: `Failed to list contributors: ${err}` }, 500);
  }
});

// ═══════════════════��═══════════════════════════════
// MODERATION SETTINGS
// ═══════════════════════════════════════════════════

cms.get("/settings/moderation", async (c) => {
  try {
    const authHeader = c.req.header("X-Auth-Token");
    const admin = await verifyAdmin(authHeader);
    if (!admin) return c.json({ error: "Unauthorized" }, 401);

    const settings = (await kv.get("cms:settings:moderation")) || {
      autoApproveThreshold: 70,
      autoRejectThreshold: 40,
      requireImages: true,
      requireDescription: true,
      requireLocation: true,
      blockedKeywords: [],
    };
    return c.json({ settings });
  } catch (err) {
    return c.json({ error: `Failed to get settings: ${err}` }, 500);
  }
});

cms.put("/settings/moderation", async (c) => {
  try {
    const authHeader = c.req.header("X-Auth-Token");
    const admin = await verifyAdmin(authHeader);
    if (!admin) return c.json({ error: "Unauthorized" }, 401);

    const settings = await c.req.json();
    await kv.set("cms:settings:moderation", settings);
    return c.json({ status: "updated", settings });
  } catch (err) {
    return c.json({ error: `Failed to update settings: ${err}` }, 500);
  }
});

// ═══════════════════════════════════════════════════
// URL PARSING (Instagram / Google Maps)
// ═══════════════════════════════════════════════════

cms.post("/parse-url", async (c) => {
  try {
    const { url } = await c.req.json();
    if (!url) return c.json({ error: "URL required" }, 400);

    const parsed = parseSourceUrl(url);

    // For Instagram posts/reels, try to auto-extract content via oEmbed + OG scraping
    if (
      parsed.source === "instagram" &&
      (parsed.type === "post" || parsed.type === "reel")
    ) {
      try {
        const extracted = await extractInstagramContent(url);
        if (extracted) {
          return c.json({
            ...parsed,
            extracted,
            hint: extracted.image
              ? "Content extracted from Instagram! Review the details below and adjust as needed."
              : parsed.hint,
          });
        }
      } catch (extractErr) {
        console.log(`Instagram extraction failed (non-fatal): ${extractErr}`);
        // Fall through to return basic parsed result
      }
    }

    return c.json(parsed);
  } catch (err) {
    return c.json({ error: `Failed to parse URL: ${err}` }, 500);
  }
});

/**
 * Extract content from an Instagram post/reel using multiple strategies:
 * 1. Instagram oEmbed API (public, no auth) → gives thumbnail + author
 * 2. OG meta tag scraping → gives og:image, og:title, og:description
 * Then downloads the best image and uploads to Supabase Storage.
 */
async function extractInstagramContent(url: string) {
  let title = "";
  let description = "";
  let imageUrl = "";
  let authorName = "";

  // Strategy 1: Instagram oEmbed API (public endpoint, no auth required)
  try {
    const oembedUrl = `https://api.instagram.com/oembed/?url=${encodeURIComponent(url)}&maxwidth=640`;
    const oembedRes = await fetch(oembedUrl, {
      headers: { "User-Agent": "Mozilla/5.0 (compatible; CultiveBot/1.0)" },
      signal: AbortSignal.timeout(8000),
    });
    if (oembedRes.ok) {
      const oembed = await oembedRes.json();
      if (oembed.thumbnail_url) imageUrl = oembed.thumbnail_url;
      if (oembed.title) description = oembed.title;
      if (oembed.author_name) authorName = oembed.author_name;
      console.log(`[IG oEmbed] Got thumbnail for @${authorName}`);
    }
  } catch (e) {
    console.log(`[IG oEmbed] Failed: ${e}`);
  }

  // Strategy 2: OG meta tag scraping as fallback/supplement
  if (!imageUrl || !description) {
    try {
      const pageRes = await fetch(url, {
        headers: {
          "User-Agent":
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
          Accept: "text/html,application/xhtml+xml",
          "Accept-Language": "en-US,en;q=0.9",
        },
        redirect: "follow",
        signal: AbortSignal.timeout(10000),
      });
      if (pageRes.ok) {
        const html = await pageRes.text();
        if (!imageUrl) {
          const ogImg = html.match(
            /<meta\s+(?:property|name)="og:image"\s+content="([^"]+)"/i
          );
          if (ogImg?.[1]) imageUrl = ogImg[1];
        }
        if (!description) {
          const ogDesc = html.match(
            /<meta\s+(?:property|name)="og:description"\s+content="([^"]+)"/i
          );
          if (ogDesc?.[1]) description = decodeHtmlEntities(ogDesc[1]);
        }
        if (!title) {
          const ogTitle = html.match(
            /<meta\s+(?:property|name)="og:title"\s+content="([^"]+)"/i
          );
          if (ogTitle?.[1]) title = decodeHtmlEntities(ogTitle[1]);
        }
      }
    } catch (e) {
      console.log(`[IG OG scrape] Failed: ${e}`);
    }
  }

  // If we got nothing useful, return null
  if (!imageUrl && !description) return null;

  // Download the image and upload to Supabase Storage for permanence
  let storedImageUrl = "";
  if (imageUrl) {
    try {
      await ensureBucket();
      const supabase = getSupabaseAdmin();

      const imgRes = await fetch(imageUrl, {
        signal: AbortSignal.timeout(15000),
      });
      if (imgRes.ok) {
        const contentType = imgRes.headers.get("content-type") || "image/jpeg";
        const buffer = new Uint8Array(await imgRes.arrayBuffer());

        const timestamp = Date.now().toString(36);
        const random = Math.random().toString(36).slice(2, 8);
        const ext = contentType.includes("png") ? "png" : contentType.includes("webp") ? "webp" : "jpg";
        const storagePath = `uploads/ig_${timestamp}_${random}.${ext}`;

        const { error: uploadErr } = await supabase.storage
          .from(BUCKET_NAME)
          .upload(storagePath, buffer, { contentType, upsert: false });

        if (!uploadErr) {
          const { data: signedData } = await supabase.storage
            .from(BUCKET_NAME)
            .createSignedUrl(storagePath, 60 * 60 * 24 * 7);
          if (signedData?.signedUrl) storedImageUrl = signedData.signedUrl;
        } else {
          console.log(`[IG image upload] ${uploadErr.message}`);
        }
      }
    } catch (e) {
      console.log(`[IG image download] Failed: ${e}`);
    }
  }

  return {
    title: title || "",
    description: description || "",
    image: storedImageUrl || imageUrl || "",
    imageStored: !!storedImageUrl,
    authorName: authorName || "",
  };
}

function decodeHtmlEntities(str: string): string {
  return str
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&#x27;/g, "'")
    .replace(/&#x2F;/g, "/");
}

function parseSourceUrl(url: string) {
  // Instagram story — https://instagram.com/stories/username/1234567890/
  if (url.includes("instagram.com/stories/")) {
    const match = url.match(/instagram\.com\/stories\/([A-Za-z0-9_.]+)(?:\/(\d+))?/);
    return {
      source: "instagram",
      type: "story",
      username: match?.[1] || "",
      storyId: match?.[2] || "",
      parsed: true,
      hint: "Instagram Story detected! We can't auto-extract story content — please take screenshots or screen-record the story and upload them in the next step.",
    };
  }

  // Instagram post/reel
  if (url.includes("instagram.com/p/") || url.includes("instagram.com/reel/")) {
    const match = url.match(/instagram\.com\/(p|reel)\/([A-Za-z0-9_-]+)/);
    return {
      source: "instagram",
      type: match?.[1] || "post",
      postId: match?.[2] || "",
      username: extractInstagramUsername(url),
      parsed: true,
      hint: "Instagram content detected. Please screenshot or save the images and upload them in the next step, then add a title, description, and date.",
    };
  }

  // Instagram profile/highlights
  if (url.includes("instagram.com/")) {
    const match = url.match(/instagram\.com\/([A-Za-z0-9_.]+)/);
    const username = match?.[1] || "";
    // Skip common path segments that aren't usernames
    if (username && !["stories", "p", "reel", "explore", "accounts", "direct"].includes(username)) {
      return {
        source: "instagram",
        type: "profile",
        username,
        parsed: true,
        hint: "Instagram profile detected. Please screenshot the content you'd like to submit and upload the images in the next step.",
      };
    }
  }

  // Google Maps
  if (url.includes("google.com/maps") || url.includes("goo.gl/maps") || url.includes("maps.app.goo.gl")) {
    const placeMatch = url.match(/place\/([^/]+)/);
    // Extract coordinates from @lat,lng,zoom pattern in Google Maps URLs
    const coordMatch = url.match(/@(-?\d+\.?\d*),(-?\d+\.?\d*)/);
    const lat = coordMatch ? parseFloat(coordMatch[1]) : undefined;
    const lng = coordMatch ? parseFloat(coordMatch[2]) : undefined;
    return {
      source: "google-maps",
      type: "place",
      placeName: placeMatch ? decodeURIComponent(placeMatch[1].replace(/\+/g, " ")) : "",
      lat,
      lng,
      parsed: true,
      hint: "Google Maps location detected. We'll use this as the venue location." + (lat ? ` Coordinates extracted: ${lat.toFixed(4)}, ${lng?.toFixed(4)}` : ""),
    };
  }

  return {
    source: "unknown",
    type: "manual",
    parsed: false,
    hint: "URL not recognized. You can still submit manually with images and details.",
  };
}

function extractInstagramUsername(url: string): string {
  // Try to extract from various Instagram URL formats
  const patterns = [
    /instagram\.com\/([A-Za-z0-9_.]+)\/p\//,
    /instagram\.com\/([A-Za-z0-9_.]+)\/reel\//,
    /instagram\.com\/([A-Za-z0-9_.]+)/,
  ];
  for (const pattern of patterns) {
    const match = url.match(pattern);
    if (match && match[1] !== "p" && match[1] !== "reel" && match[1] !== "stories") {
      return match[1];
    }
  }
  return "";
}

// ═══════════════════════════════════════════════════
// AI CONTENT ANALYSIS (smart caption parsing for HK events)
// ═══════════════════════════════════════════════════

interface AnalysisResult {
  title: string;
  category: string;
  categories: string[];
  district: string;
  date: string;
  time: string;
  price: string;
  location: string;
  tags: string[];
  confidence: number;
  fieldsFound: string[];
}

function analyzeContentText(text: string, _authorName?: string): AnalysisResult {
  const result: AnalysisResult = {
    title: "", category: "", categories: [], district: "", date: "", time: "",
    price: "", location: "", tags: [], confidence: 0, fieldsFound: [],
  };
  if (!text || text.length < 5) return result;

  const lower = text.toLowerCase();
  const lines = text.split(/\n/).map(l => l.trim()).filter(Boolean);

  // ─── TITLE: First meaningful line ───
  for (const line of lines) {
    const cleaned = line.replace(/^[\s•\-–—]+/, "").trim();
    if (cleaned.length >= 5 && cleaned.length <= 120 && !cleaned.startsWith("#") && !cleaned.startsWith("@")) {
      const textOnly = cleaned.replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE00}-\u{FE0F}\u{1F900}-\u{1F9FF}]/gu, "").trim();
      if (textOnly.length >= 3) {
        result.title = cleaned.length > 80 ? cleaned.slice(0, 77) + "..." : cleaned;
        result.fieldsFound.push("title");
        break;
      }
    }
  }

  // ─── CATEGORY: keyword matching ───
  const categoryMap: Record<string, string[]> = {
    "run-clubs": ["run club", "running", "run crew", "morning run", "night run", "trail run", "jog", "5k", "10k", "marathon"],
    "wellness": ["yoga", "pilates", "meditation", "wellness", "breathwork", "mindfulness", "sound bath", "healing", "stretch"],
    "hikes": ["hike", "hiking", "trail", "peak", "summit", "nature walk", "outdoor", "dragon's back", "lion rock"],
    "coffee-raves": ["coffee rave", "morning rave", "sober rave", "morning party", "coffee party", "morning disco"],
    "workshops": ["workshop", "class", "masterclass", "tutorial", "learn", "course", "pottery", "ceramics", "painting", "calligraphy"],
    "meetups": ["meetup", "meet-up", "community", "networking", "social", "gathering", "hangout"],
    "nightlife": ["night", "club", "dj", "party", "music", "live music", "concert", "gig", "electronic", "techno", "house music", "bar"],
    "art": ["art", "exhibition", "gallery", "museum", "installation", "photography", "design", "creative"],
    "food": ["food", "market", "pop-up", "popup", "dining", "tasting", "brunch", "supper club", "street food", "farmers market"],
    "family": ["family", "kids", "children", "parent", "baby", "toddler", "playground"],
  };
  const matchedCategories: string[] = [];
  for (const [cat, keywords] of Object.entries(categoryMap)) {
    if (keywords.some(kw => lower.includes(kw))) {
      matchedCategories.push(cat);
    }
  }
  if (matchedCategories.length > 0) {
    result.category = matchedCategories[0]; // backward-compatible primary
    result.categories = matchedCategories;
    result.fieldsFound.push("category");
  }

  // ─── DISTRICT: HK-specific location matching ───
  const districtMap: Record<string, string[]> = {
    "Central": ["central", "中環", "lan kwai fong", "soho central", "central pier"],
    "Wan Chai": ["wan chai", "灣仔", "wanchai"],
    "Causeway Bay": ["causeway bay", "銅鑼灣", "cwb"],
    "Sheung Wan": ["sheung wan", "上環"],
    "Sai Ying Pun": ["sai ying pun", "西營盤", "syp"],
    "Kennedy Town": ["kennedy town", "堅尼地城", "k-town"],
    "Tsim Sha Tsui": ["tsim sha tsui", "tst", "尖沙咀"],
    "Mong Kok": ["mong kok", "旺角", "mongkok"],
    "Sham Shui Po": ["sham shui po", "深水埗", "ssp"],
    "West Kowloon": ["west kowloon", "西九龍", "west kowloon cultural", "m+", "m plus"],
    "Wong Chuk Hang": ["wong chuk hang", "黃竹坑", "wch"],
    "Stanley": ["stanley", "赤柱"],
    "Repulse Bay": ["repulse bay", "淺水灣"],
    "Shau Kei Wan": ["shau kei wan", "筲箕灣"],
    "Tai Tam": ["tai tam", "大潭"],
    "Sha Tin": ["sha tin", "沙田", "shatin"],
    "Tai Po": ["tai po", "大埔"],
    "Sai Kung": ["sai kung", "西貢"],
    "Lantau": ["lantau", "大嶼山", "tung chung", "mui wo"],
  };
  for (const [district, keywords] of Object.entries(districtMap)) {
    if (keywords.some(kw => lower.includes(kw))) {
      result.district = district;
      result.fieldsFound.push("district");
      break;
    }
  }

  // ─── LOCATION / VENUE ───
  const pinMatch = text.match(/📍\s*(.+?)(?:\n|$)/);
  if (pinMatch?.[1]) {
    result.location = pinMatch[1].trim().slice(0, 60);
    result.fieldsFound.push("location");
  }
  if (!result.location) {
    const venuePatterns = [
      /(?:at|@|venue:|location:)\s*([A-Z][A-Za-z0-9\s&''\-–]{3,50})/,
    ];
    for (const pat of venuePatterns) {
      const match = text.match(pat);
      if (match?.[1]) {
        const venue = match[1].trim().replace(/[.!?,;]+$/, "");
        if (venue.length >= 3 && venue.length <= 60) {
          result.location = venue;
          result.fieldsFound.push("location");
          break;
        }
      }
    }
  }

  // ─── DATE: natural language date parsing ───
  const months = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
  const datePatterns: [RegExp, string][] = [
    [/(\d{1,2})\s+(january|february|march|april|may|june|july|august|september|october|november|december)(?:\s+(\d{4}))?/i, "dmy"],
    [/(january|february|march|april|may|june|july|august|september|october|november|december)\s+(\d{1,2})(?:st|nd|rd|th)?(?:[,\s]+(\d{4}))?/i, "mdy"],
    [/(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})/, "numeric"],
    [/(\d{1,2})\s+(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)(?:\s+(\d{4}))?/i, "dmy"],
    [/(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)\s+(\d{1,2})(?:st|nd|rd|th)?(?:[,\s]+(\d{4}))?/i, "mdy"],
  ];
  for (const [pat, fmt] of datePatterns) {
    const match = text.match(pat);
    if (match) {
      try {
        let day: number, monthIdx: number, year: number;
        const currentYear = new Date().getFullYear();
        if (fmt === "numeric") {
          day = parseInt(match[1]); monthIdx = parseInt(match[2]) - 1; year = parseInt(match[3]);
        } else if (fmt === "dmy") {
          day = parseInt(match[1]); monthIdx = months.indexOf(match[2].toLowerCase().slice(0, 3)); year = match[3] ? parseInt(match[3]) : currentYear;
        } else {
          monthIdx = months.indexOf(match[1].toLowerCase().slice(0, 3)); day = parseInt(match[2]); year = match[3] ? parseInt(match[3]) : currentYear;
        }
        if (monthIdx >= 0 && day >= 1 && day <= 31) {
          result.date = `${year}-${String(monthIdx + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
          result.fieldsFound.push("date");
        }
      } catch {}
      break;
    }
  }
  // Relative dates
  if (!result.date) {
    const dayNames = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
    const relMatch = lower.match(/(?:this|next)\s+(sunday|monday|tuesday|wednesday|thursday|friday|saturday)/);
    if (relMatch) {
      const targetDay = dayNames.indexOf(relMatch[1]);
      const today = new Date(); const todayDay = today.getDay();
      let diff = targetDay - todayDay;
      if (diff <= 0) diff += 7;
      if (lower.includes("next") && diff <= 7) diff += 7;
      const target = new Date(today); target.setDate(today.getDate() + diff);
      result.date = target.toISOString().slice(0, 10);
      result.fieldsFound.push("date");
    }
    if (!result.date && lower.includes("tomorrow")) {
      const tmrw = new Date(); tmrw.setDate(tmrw.getDate() + 1);
      result.date = tmrw.toISOString().slice(0, 10);
      result.fieldsFound.push("date");
    }
  }

  // ─── TIME ───
  const timePatterns = [/(\d{1,2}:\d{2}\s*(?:am|pm|AM|PM))/, /(\d{1,2}\s*(?:am|pm|AM|PM))/, /(\d{1,2}:\d{2})\s*(?:hrs|h)/];
  for (const pat of timePatterns) {
    const match = text.match(pat);
    if (match?.[1]) { result.time = match[1].trim(); result.fieldsFound.push("time"); break; }
  }

  // ─── PRICE ───
  if (/(?:free|免費|no charge|complimentary)/i.test(text)) {
    result.price = "Free"; result.fieldsFound.push("price");
  } else {
    const priceMatch = text.match(/(?:HK)?\$\s*(\d[\d,]*(?:\.\d{2})?)/) || text.match(/(\d[\d,]+)\s*(?:HKD|hkd)/);
    if (priceMatch?.[1]) { result.price = `$${priceMatch[1]}`; result.fieldsFound.push("price"); }
  }

  // ─── TAGS: hashtags ───
  const hashtags = text.match(/#([A-Za-z0-9\u4e00-\u9fff]+)/g) || [];
  result.tags = hashtags.map(t => t.slice(1).toLowerCase()).filter(t => t.length > 1 && t.length < 30).slice(0, 10);
  if (result.tags.length > 0) result.fieldsFound.push("tags");

  // ─── Confidence ───
  const possibleFields = ["title", "category", "district", "date", "time", "price", "location"];
  const found = result.fieldsFound.filter(f => possibleFields.includes(f));
  result.confidence = Math.round((found.length / possibleFields.length) * 100);

  return result;
}

cms.post("/analyze-content", async (c) => {
  try {
    const { text, authorName } = await c.req.json();
    if (!text) return c.json({ error: "text required" }, 400);
    const analysis = analyzeContentText(text, authorName);
    console.log(`[Content Analysis] Confidence: ${analysis.confidence}%, fields: ${analysis.fieldsFound.join(", ")}`);
    return c.json(analysis);
  } catch (err) {
    console.log(`Error analyzing content: ${err}`);
    return c.json({ error: `Analysis failed: ${err}` }, 500);
  }
});

// ═══════════════════════════════════════════════════
// IMAGE UPLOAD (Supabase Storage)
// ═══════════════════════════════════════════════════

const ALLOWED_IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp", "image/gif"];
const ALLOWED_VIDEO_TYPES = ["video/mp4", "video/webm", "video/quicktime", "video/x-m4v"];
const ALLOWED_TYPES = [...ALLOWED_IMAGE_TYPES, ...ALLOWED_VIDEO_TYPES];
const MAX_IMAGE_SIZE = 10 * 1024 * 1024; // 10 MB
const MAX_VIDEO_SIZE = 50 * 1024 * 1024; // 50 MB

// POST /cms/upload — Upload images to Supabase Storage (public, no auth required)
cms.post("/upload", async (c) => {
  try {
    await ensureBucket();
    const supabase = getSupabaseAdmin();

    const formData = await c.req.formData();
    const files = formData.getAll("files");

    if (!files || files.length === 0) {
      return c.json({ error: "No files provided" }, 400);
    }

    if (files.length > 5) {
      return c.json({ error: "Maximum 5 files per upload" }, 400);
    }

    const results: { url: string; path: string; name: string; size: number }[] = [];
    const errors: string[] = [];

    for (const file of files) {
      if (!(file instanceof File)) {
        errors.push("Invalid file entry");
        continue;
      }

      // Validate type
      if (!ALLOWED_TYPES.includes(file.type)) {
        errors.push(`${file.name}: unsupported format (${file.type}). Use JPEG, PNG, WebP, GIF, MP4, WebM, QuickTime, or M4V.`);
        continue;
      }

      // Validate size
      const maxSize = ALLOWED_IMAGE_TYPES.includes(file.type) ? MAX_IMAGE_SIZE : MAX_VIDEO_SIZE;
      if (file.size > maxSize) {
        errors.push(`${file.name}: exceeds ${maxSize / 1024 / 1024} MB limit`);
        continue;
      }

      // Generate unique path: uploads/<timestamp>_<random>_<sanitized-name>
      const timestamp = Date.now().toString(36);
      const random = Math.random().toString(36).slice(2, 8);
      const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_").slice(0, 80);
      const storagePath = `uploads/${timestamp}_${random}_${safeName}`;

      // Read file into buffer
      const arrayBuffer = await file.arrayBuffer();
      const buffer = new Uint8Array(arrayBuffer);

      // Upload to Supabase Storage
      const { data, error } = await supabase.storage
        .from(BUCKET_NAME)
        .upload(storagePath, buffer, {
          contentType: file.type,
          upsert: false,
        });

      if (error) {
        console.log(`Storage upload error for ${file.name}: ${error.message}`);
        errors.push(`${file.name}: upload failed — ${error.message}`);
        continue;
      }

      // Create a signed URL (valid 7 days)
      const { data: signedData, error: signError } = await supabase.storage
        .from(BUCKET_NAME)
        .createSignedUrl(storagePath, 60 * 60 * 24 * 7);

      if (signError || !signedData?.signedUrl) {
        console.log(`Signed URL error for ${file.name}: ${signError?.message}`);
        errors.push(`${file.name}: uploaded but failed to generate URL`);
        continue;
      }

      results.push({
        url: signedData.signedUrl,
        path: storagePath,
        name: file.name,
        size: file.size,
      });
    }

    return c.json({
      uploaded: results,
      errors,
      count: results.length,
    });
  } catch (err) {
    console.log(`Image upload error: ${err}`);
    return c.json({ error: `Image upload failed: ${err}` }, 500);
  }
});

// ═══════════════════════════════════════════════════
// GENERIC CONTENT CRUD (driven by contentTypes registry)
// ═══════════════════════════════════════════════════

// GET /cms/content/:type — List all items of a content type (admin)
cms.get("/content/:type", async (c) => {
  try {
    const authHeader = c.req.header("X-Auth-Token");
    const admin = await verifyAdmin(authHeader);
    if (!admin) return c.json({ error: "Unauthorized" }, 401);

    const type = c.req.param("type");
    const indexKey = `cms:content:${type}:ids`;
    const ids = ((await kv.get(indexKey)) as string[]) || [];

    const keys = ids.map((id) => `cms:content:${type}:${id}`);
    // Chunked mget to avoid Supabase .in() limits
    const CHUNK = 50;
    const cmsItems: any[] = [];
    for (let i = 0; i < keys.length; i += CHUNK) {
      const chunk = keys.slice(i, i + CHUNK);
      const results = await kv.mget(chunk);
      cmsItems.push(...results.filter(Boolean));
    }

    // For "event" type, also surface RA-imported events from the main KV store
    let items: any[] = [...cmsItems];
    if (type === "event") {
      const kvEventIds = ((await kv.get("cultive:event_ids")) as string[]) || [];
      if (kvEventIds.length > 0) {
        const kvKeys = kvEventIds.map((id: string) => `cultive:event:${id}`);
        const kvEvents: any[] = [];
        for (let i = 0; i < kvKeys.length; i += CHUNK) {
          const chunk = kvKeys.slice(i, i + CHUNK);
          const results = await kv.mget(chunk);
          kvEvents.push(...results.filter(Boolean));
        }
        const raEvents = kvEvents
          .filter((e: any) => e.id && (e.id.startsWith("ra_") || e.raId))
          .map((e: any) => ({ ...e, _source: "ra_import", _sourceLabel: "RA Import" }));
        const cmsIds = new Set(cmsItems.map((i: any) => i.id));
        items = [...cmsItems, ...raEvents.filter((e: any) => !cmsIds.has(e.id))];
      }
    }

    return c.json({ items, count: items.length });
  } catch (err) {
    console.log(`Error listing content ${c.req.param("type")}: ${err}`);
    return c.json({ error: `Failed to list content: ${err}` }, 500);
  }
});

// GET /cms/content/:type/public — Public read (no drafts)
cms.get("/content/:type/public", async (c) => {
  try {
    const type = c.req.param("type");
    const indexKey = `cms:content:${type}:ids`;
    const ids = ((await kv.get(indexKey)) as string[]) || [];

    if (ids.length === 0) return c.json({ items: [], count: 0 });

    const keys = ids.map((id) => `cms:content:${type}:${id}`);
    // Chunked mget to avoid Supabase .in() limits
    const CHUNK = 50;
    const allItems: any[] = [];
    for (let i = 0; i < keys.length; i += CHUNK) {
      const chunk = keys.slice(i, i + CHUNK);
      const results = await kv.mget(chunk);
      allItems.push(...results.filter(Boolean));
    }
    const items = allItems;
    const published = items.filter((item) => item.status !== "draft");

    // Re-sign any Supabase Storage signed URLs so they're always fresh
    const supabase = getSupabaseAdmin();
    const refreshed = await Promise.all(
      published.map((item) => refreshStorageUrls(item, supabase))
    );

    return c.json({ items: refreshed, count: refreshed.length });
  } catch (err) {
    console.log(`Error in public content read: ${err}`);
    return c.json({ error: `Failed to list content: ${err}` }, 500);
  }
});

// POST /cms/content/:type — Create a new item (admin)
cms.post("/content/:type", async (c) => {
  try {
    const authHeader = c.req.header("X-Auth-Token");
    const admin = await verifyAdmin(authHeader);
    if (!admin) return c.json({ error: "Unauthorized" }, 401);

    const type = c.req.param("type");
    const body = await c.req.json();
    const id = body.id || `${type}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
    const now = new Date().toISOString();

    const item = {
      ...body,
      id,
      _createdAt: now,
      _updatedAt: now,
      _createdBy: admin.email,
    };

    await kv.set(`cms:content:${type}:${id}`, item);

    // Update index
    const indexKey = `cms:content:${type}:ids`;
    const ids = ((await kv.get(indexKey)) as string[]) || [];
    if (!ids.includes(id)) {
      ids.push(id);
      await kv.set(indexKey, ids);
    }

    return c.json({ status: "created", item });
  } catch (err) {
    console.log(`Error creating content: ${err}`);
    return c.json({ error: `Failed to create: ${err}` }, 500);
  }
});

// PUT /cms/content/:type/:id — Update an item (admin)
cms.put("/content/:type/:id", async (c) => {
  try {
    const authHeader = c.req.header("X-Auth-Token");
    const admin = await verifyAdmin(authHeader);
    if (!admin) return c.json({ error: "Unauthorized" }, 401);

    const type = c.req.param("type");
    const id = c.req.param("id");
    const body = await c.req.json();
    const now = new Date().toISOString();

    const existing = await kv.get(`cms:content:${type}:${id}`);
    const item = {
      ...(existing || {}),
      ...body,
      id,
      _updatedAt: now,
      _updatedBy: admin.email,
    };

    await kv.set(`cms:content:${type}:${id}`, item);

    // Ensure it's in the index
    const indexKey = `cms:content:${type}:ids`;
    const ids = ((await kv.get(indexKey)) as string[]) || [];
    if (!ids.includes(id)) {
      ids.push(id);
      await kv.set(indexKey, ids);
    }

    return c.json({ status: "updated", item });
  } catch (err) {
    console.log(`Error updating content: ${err}`);
    return c.json({ error: `Failed to update: ${err}` }, 500);
  }
});

// DELETE /cms/content/:type/:id — Delete an item (admin)
cms.delete("/content/:type/:id", async (c) => {
  try {
    const authHeader = c.req.header("X-Auth-Token");
    const admin = await verifyAdmin(authHeader);
    if (!admin) return c.json({ error: "Unauthorized" }, 401);

    const type = c.req.param("type");
    const id = c.req.param("id");

    await kv.del(`cms:content:${type}:${id}`);

    // Remove from index
    const indexKey = `cms:content:${type}:ids`;
    const ids = ((await kv.get(indexKey)) as string[]) || [];
    const filtered = ids.filter((i) => i !== id);
    await kv.set(indexKey, filtered);

    // If it's an event, add to hidden IDs blacklist so seed data doesn't resurrect it
    if (type === "event") {
      await addToHiddenIds(id);
    }

    return c.json({ status: "deleted" });
  } catch (err) {
    console.log(`Error deleting content: ${err}`);
    return c.json({ error: `Failed to delete: ${err}` }, 500);
  }
});

// POST /cms/content/:type/seed — Seed from existing KV data (admin)
cms.post("/content/:type/seed", async (c) => {
  try {
    const authHeader = c.req.header("X-Auth-Token");
    const admin = await verifyAdmin(authHeader);
    if (!admin) return c.json({ error: "Unauthorized" }, 401);

    const type = c.req.param("type");

    // Try to copy from the existing cultive: prefixed data
    let sourceIds: string[] = [];
    let sourcePrefix = "";

    if (type === "event") {
      sourceIds = ((await kv.get("cultive:event_ids")) as string[]) || [];
      sourcePrefix = "cultive:event:";
    } else if (type === "venue") {
      sourceIds = ((await kv.get("cultive:venue_ids")) as string[]) || [];
      sourcePrefix = "cultive:venue:";
    } else if (type === "recap") {
      sourceIds = ((await kv.get("cultive:recap_ids")) as string[]) || [];
      sourcePrefix = "cultive:recap:";
    }

    if (sourceIds.length === 0) {
      return c.json({ status: "no_data", message: `No static data found for type: ${type}`, count: 0 });
    }

    const sourceKeys = sourceIds.map((id) => `${sourcePrefix}${id}`);
    const sourceItems = (await kv.mget(sourceKeys)).filter(Boolean) as any[];

    const indexKey = `cms:content:${type}:ids`;
    const existingIds = ((await kv.get(indexKey)) as string[]) || [];
    let added = 0;

    for (const item of sourceItems) {
      const id = item.id;
      if (!existingIds.includes(id)) {
        await kv.set(`cms:content:${type}:${id}`, {
          ...item,
          _createdAt: new Date().toISOString(),
          _seededFrom: "static",
        });
        existingIds.push(id);
        added++;
      }
    }

    await kv.set(indexKey, existingIds);

    return c.json({ status: "seeded", count: added, total: existingIds.length });
  } catch (err) {
    console.log(`Error seeding content: ${err}`);
    return c.json({ error: `Failed to seed: ${err}` }, 500);
  }
});

// ═══════════════════════════════════════════════════
// VENUE BULK EDITOR (delete, re-parse, AI enrich)
// ═══════════════════════════════════════════════════

// POST /cms/venues/bulk-delete — Delete multiple venues (admin)
cms.post("/venues/bulk-delete", async (c) => {
  try {
    const authHeader = c.req.header("X-Auth-Token");
    const admin = await verifyAdmin(authHeader);
    if (!admin) return c.json({ error: "Unauthorized" }, 401);

    const { ids } = await c.req.json();
    if (!Array.isArray(ids) || ids.length === 0) {
      return c.json({ error: "ids array is required" }, 400);
    }

    const indexKey = "cms:content:venue:ids";
    const existingIds = ((await kv.get(indexKey)) as string[]) || [];

    const keysToDelete = ids.map((id: string) => `cms:content:venue:${id}`);
    await kv.mdel(keysToDelete);

    const remainingIds = existingIds.filter((id) => !ids.includes(id));
    await kv.set(indexKey, remainingIds);

    console.log(`Bulk deleted ${ids.length} venues (remaining: ${remainingIds.length})`);
    return c.json({ status: "deleted", count: ids.length, remaining: remainingIds.length });
  } catch (err) {
    console.log(`Error in venues bulk-delete: ${err}`);
    return c.json({ error: `Bulk delete failed: ${err}` }, 500);
  }
});

// POST /cms/venues/reparse — Re-fetch Google Places data for a venue (admin)
cms.post("/venues/reparse", async (c) => {
  try {
    const authHeader = c.req.header("X-Auth-Token");
    const admin = await verifyAdmin(authHeader);
    if (!admin) return c.json({ error: "Unauthorized" }, 401);

    const { id } = await c.req.json();
    if (!id) return c.json({ error: "id is required" }, 400);

    const venue = (await kv.get(`cms:content:venue:${id}`)) as any;
    if (!venue) return c.json({ error: "Venue not found" }, 404);

    const apiKey = Deno.env.get("GOOGLE_PLACES_API_KEY");
    if (!apiKey) return c.json({ error: "Google Places API key not configured" }, 500);

    const searchQuery = `${venue.name} Hong Kong${venue.district ? ' ' + venue.district : ''}`;
    const searchParams = new URLSearchParams({
      query: searchQuery, key: apiKey, language: "en", region: "hk",
    });

    const searchRes = await fetch(
      `https://maps.googleapis.com/maps/api/place/textsearch/json?${searchParams}`
    );
    const searchData = await searchRes.json();

    if (searchData.status !== "OK" || !searchData.results?.length) {
      return c.json({ error: "Place not found on Google", query: searchQuery, status: searchData.status }, 404);
    }

    const place = searchData.results[0];
    const placeId = place.place_id;

    const detailParams = new URLSearchParams({
      place_id: placeId, key: apiKey,
      fields: [
        "name", "formatted_address", "geometry", "address_components",
        "types", "rating", "user_ratings_total", "price_level",
        "website", "formatted_phone_number", "opening_hours",
        "photos", "editorial_summary", "url",
      ].join(","),
      language: "en",
    });

    const detailRes = await fetch(
      `https://maps.googleapis.com/maps/api/place/details/json?${detailParams}`
    );
    const detailData = await detailRes.json();
    const d = detailData.status === "OK" ? detailData.result : place;

    let district = venue.district || "";
    if (!district && d.address_components) {
      for (const comp of d.address_components) {
        if (comp.types.includes("sublocality_level_1") || comp.types.includes("neighborhood")) {
          district = comp.long_name; break;
        }
      }
      if (!district) {
        for (const comp of d.address_components) {
          if (comp.types.includes("locality") && comp.long_name !== "Hong Kong") {
            district = comp.long_name; break;
          }
        }
      }
    }

    let photoUrl = venue.image || null;
    if ((!photoUrl || photoUrl === '') && d.photos?.length > 0) {
      const photoRef = d.photos[0].photo_reference;
      photoUrl = `https://maps.googleapis.com/maps/api/place/photo?maxwidth=800&photo_reference=${photoRef}&key=${apiKey}`;
    }

    const updates: Record<string, any> = {};
    if (!venue.address && (d.formatted_address || place.formatted_address)) {
      updates.address = d.formatted_address || place.formatted_address;
    }
    if ((!venue.lat || !venue.lng) && (d.geometry?.location || place.geometry?.location)) {
      const loc = d.geometry?.location || place.geometry?.location;
      updates.lat = loc.lat; updates.lng = loc.lng;
    }
    if (!venue.district && district) updates.district = district;
    if ((!venue.image || venue.image === '') && photoUrl) updates.image = photoUrl;
    // Always store Google's editorial summary separately for AI context
    if (d.editorial_summary?.overview) {
      updates.googleEditorialSummary = d.editorial_summary.overview;
    }
    // Set description from Google if missing OR if current one was auto-generated by rule-based enrichment
    const hasRuleBasedDesc = venue._enrichedBy === 'rule-based' && venue.description;
    if ((!venue.description || hasRuleBasedDesc) && d.editorial_summary?.overview) {
      updates.description = d.editorial_summary.overview;
      if (hasRuleBasedDesc) {
        console.log(`Overwriting rule-based description for "${venue.name}" with Google editorial summary`);
      }
    }
    // Store Google price_level if available
    if (d.price_level !== undefined && d.price_level !== null) {
      updates.priceRange = d.price_level;
    }

    updates.googlePlaceId = placeId;
    updates.googleTypes = d.types || place.types || [];
    updates.googleRating = d.rating || place.rating || null;
    updates.googleUserRatings = d.user_ratings_total || place.user_ratings_total || null;
    updates.googleWebsite = d.website || null;
    updates.googlePhone = d.formatted_phone_number || null;
    updates.googleMapsUrl = d.url || null;
    if (d.opening_hours?.weekday_text) updates.openingHours = d.opening_hours.weekday_text;
    updates._reparsedAt = new Date().toISOString();

    const updated = { ...venue, ...updates };
    await kv.set(`cms:content:venue:${id}`, updated);

    console.log(`Re-parsed venue "${venue.name}": ${Object.keys(updates).length} fields updated`);
    return c.json({ status: "reparsed", venue: updated, fieldsUpdated: Object.keys(updates) });
  } catch (err) {
    console.log(`Error in venues reparse: ${err}`);
    return c.json({ error: `Reparse failed: ${err}` }, 500);
  }
});

// ─── Gemini AI helper ───
const GEMINI_MODEL_CANDIDATES = [
  "gemini-2.0-flash",
  "gemini-2.0-flash-lite",
  "gemini-1.5-flash",
];

function delay(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function callGemini(prompt: string, maxRetries = 5): Promise<string | null> {
  const apiKey = Deno.env.get("GEMINI_API_KEY");
  if (!apiKey) {
    console.log("GEMINI_API_KEY not configured");
    return null;
  }

  // Helper to strip markdown code fences from response
  function stripJsonFences(text: string): string {
    let t = text.trim();
    if (t.startsWith("```json")) t = t.slice(7);
    else if (t.startsWith("```")) t = t.slice(3);
    if (t.endsWith("```")) t = t.slice(0, -3);
    return t.trim();
  }

  const makeBody = (useJsonMime: boolean) => JSON.stringify({
    contents: [{ parts: [{ text: prompt }] }],
    generationConfig: {
      temperature: 0.7,
      maxOutputTokens: 4096,
      ...(useJsonMime ? { responseMimeType: "application/json" } : {}),
    },
  });

  try {
    let emptyCount = 0; // Track consecutive empty responses
    for (let attempt = 0; attempt < maxRetries; attempt++) {
      // Only use JSON mime on the very first attempt; some models return empty with it
      const requestBody = makeBody(attempt === 0);

      // Rotate model order on later attempts to try different models for empty/error responses
      const models = attempt >= 2
        ? [...GEMINI_MODEL_CANDIDATES].reverse()
        : GEMINI_MODEL_CANDIDATES;

      let res: Response | null = null;
      let usedModel = "";

      for (const model of models) {
        try {
          const r = await fetch(
            `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`,
            { method: "POST", headers: { "Content-Type": "application/json" }, body: requestBody }
          );
          if (r.status === 404) {
            console.log(`Gemini model ${model} returned 404, trying next...`);
            continue;
          }
          res = r;
          usedModel = model;
          break;
        } catch (fetchErr) {
          console.log(`Gemini fetch error for model ${model}: ${fetchErr}`);
          continue;
        }
      }
      if (!res) {
        console.log("All Gemini model variants returned 404 or fetch errors");
        return null;
      }
      // Handle rate limiting (429) with exponential backoff — longer waits
      if (res.status === 429) {
        const backoffMs = Math.min(4000 * Math.pow(2, attempt), 60000);
        console.log(`Gemini rate limited (429) on ${usedModel}, attempt ${attempt + 1}/${maxRetries}, waiting ${backoffMs}ms...`);
        await delay(backoffMs);
        continue;
      }
      // Handle 503 (overloaded) with backoff
      if (res.status === 503) {
        const backoffMs = Math.min(5000 * Math.pow(2, attempt), 60000);
        console.log(`Gemini overloaded (503) on ${usedModel}, attempt ${attempt + 1}/${maxRetries}, waiting ${backoffMs}ms...`);
        await delay(backoffMs);
        continue;
      }
      // Handle 500 (internal server error) with backoff
      if (res.status === 500) {
        const backoffMs = Math.min(3000 * Math.pow(2, attempt), 60000);
        console.log(`Gemini internal error (500) on ${usedModel}, attempt ${attempt + 1}/${maxRetries}, waiting ${backoffMs}ms...`);
        await delay(backoffMs);
        continue;
      }
      if (!res.ok) {
        const errText = await res.text();
        console.log(`Gemini API error ${res.status} on ${usedModel}: ${errText.slice(0, 500)}`);
        // On 400 errors, retry without JSON mime on next attempt
        if (res.status === 400 && attempt < maxRetries - 1) {
          console.log(`Will retry without responseMimeType on next attempt...`);
          await delay(1500);
          continue;
        }
        return null;
      }
      const data = await res.json();
      // Check for blocked/empty responses
      if (data?.promptFeedback?.blockReason) {
        console.log(`Gemini blocked: ${data.promptFeedback.blockReason}. promptFeedback: ${JSON.stringify(data.promptFeedback).slice(0, 300)}`);
        // Safety blocks won't change on retry
        if (data.promptFeedback.blockReason === "SAFETY") return null;
        if (attempt < maxRetries - 1) {
          await delay(2000);
          continue;
        }
        return null;
      }
      const text = data?.candidates?.[0]?.content?.parts?.[0]?.text;
      if (!text && data?.candidates?.[0]?.finishReason === "SAFETY") {
        console.log(`Gemini safety filter on ${usedModel}. candidate: ${JSON.stringify(data?.candidates?.[0]).slice(0, 300)}`);
        return null;
      }
      if (!text) {
        emptyCount++;
        const fullResp = JSON.stringify(data).slice(0, 800);
        console.log(`Gemini empty text on ${usedModel}, attempt ${attempt + 1}/${maxRetries}. finishReason: ${data?.candidates?.[0]?.finishReason}, candidates: ${data?.candidates?.length}. FULL: ${fullResp}`);
        if (attempt < maxRetries - 1) {
          // Progressive delay: longer each time to let rate limits clear
          await delay(2000 * (emptyCount + 1));
          continue;
        }
        return null;
      }
      console.log(`Gemini success on ${usedModel} (attempt ${attempt + 1}), response length: ${text.length}`);
      return stripJsonFences(text);
    }
    console.log(`Gemini exhausted all ${maxRetries} retries`);
    return null;
  } catch (err) {
    console.log(`Gemini call failed: ${err}`);
    return null;
  }
}

// POST /cms/venues/ai-enrich — Gemini-powered AI enrichment for a venue (admin)
cms.post("/venues/ai-enrich", async (c) => {
  try {
    const authHeader = c.req.header("X-Auth-Token");
    const admin = await verifyAdmin(authHeader);
    if (!admin) return c.json({ error: "Unauthorized" }, 401);

    const { id } = await c.req.json();
    if (!id) return c.json({ error: "id is required" }, 400);

    const venue = (await kv.get(`cms:content:venue:${id}`)) as any;
    if (!venue) return c.json({ error: "Venue not found" }, 404);

    // Rule-based descriptions should be replaced by Gemini
    const isRuleBasedDesc = venue._enrichedBy === 'rule-based';
    const needsDescription = !venue.description || venue.description.trim().length < 10 || isRuleBasedDesc;
    const needsVibeTags = !venue.vibeTags || venue.vibeTags.length === 0;
    const needsNameZh = !venue.nameZh || venue.nameZh.trim() === '';
    const needsModeScores = !venue.modeScores || Object.keys(venue.modeScores).length === 0;
    const needsCategory = !venue.category || venue.category.trim() === '';
    const needsSubcategory = !venue.subcategory || venue.subcategory.trim() === '';
    const needsDescriptionZh = !venue.description_zh || (typeof venue.description_zh === 'string' && venue.description_zh.trim().length < 5);
    const needsDistrictZh = !venue.district_zh || (typeof venue.district_zh === 'string' && venue.district_zh.trim().length === 0);

    if (!needsDescription && !needsVibeTags && !needsNameZh && !needsModeScores && !needsCategory && !needsDescriptionZh && !needsDistrictZh) {
      return c.json({ status: "no_changes", message: "All fields already populated", venue });
    }

    // Build context for Gemini
    const context = [
      `Venue name: ${venue.name}`,
      venue.address ? `Address: ${venue.address}` : null,
      venue.district ? `District: ${venue.district}` : null,
      venue.category ? `Category: ${venue.category}` : null,
      venue.subcategory ? `Subcategory: ${venue.subcategory}` : null,
      venue.googleTypes?.length ? `Google Place types: ${venue.googleTypes.join(", ")}` : null,
      venue.googleRating ? `Google rating: ${venue.googleRating}/5 (${venue.googleUserRatings || 0} reviews)` : null,
      venue.priceRange ? `Price range: ${"$".repeat(venue.priceRange)} (${venue.priceRange}/4)` : null,
      venue.googleWebsite ? `Website: ${venue.googleWebsite}` : null,
      venue.openingHours?.length ? `Hours: ${venue.openingHours.slice(0, 3).join("; ")}` : null,
      venue.googleEditorialSummary ? `Google editorial summary: ${venue.googleEditorialSummary}` : null,
      (venue.description && !isRuleBasedDesc) ? `Current description: ${venue.description}` : null,
    ].filter(Boolean).join("\n");

    const fieldsToGenerate: string[] = [];
    if (needsDescription) fieldsToGenerate.push('"description": a compelling 2-3 sentence description for a cultural events platform (CULTIVE) in Hong Kong. Write in a warm, editorial tone that highlights what makes this place special. Mention the vibe, what visitors can expect, and any cultural significance. DO NOT start with the venue name.');
    if (needsVibeTags) fieldsToGenerate.push('"vibeTags": an array of 3-5 single-word or hyphenated vibe tags (lowercase) that capture the feeling of this place. Examples: "cozy", "instagrammable", "hidden-gem", "date-night", "late-night", "creative", "rooftop", "craft-cocktails", "live-music", "family-friendly", "artsy", "waterfront"');
    if (needsNameZh) fieldsToGenerate.push('"nameZh": the Traditional Chinese name for this venue. If well-known in HK, use the actual Chinese name. Otherwise transliterate or provide a descriptive Chinese name.');
    if (needsModeScores) fieldsToGenerate.push('"modeScores": an object with scores from 0.0 to 1.0 for these 5 cultural modes: "degen" (nightlife/bars/clubs), "artsy" (art/design/galleries/creative), "foodie" (food/dining/culinary), "family" (family-friendly/kids/outdoor), "lifestyle" (wellness/shopping/fitness). Only include modes with score >= 0.2. A bar would be degen: 0.8. A gallery would be artsy: 0.9.');
    if (needsCategory) fieldsToGenerate.push('"category": one of: "nightlife", "dining", "art-culture", "wellness", "lifestyle", "outdoor", "entertainment", "shopping"');
    if (needsSubcategory) fieldsToGenerate.push('"subcategory": a more specific subcategory like "cocktail-bar", "izakaya", "gallery", "yoga-studio", "dim-sum", "rooftop-bar", "street-food", "bookshop", etc.');
    if (needsDescriptionZh) fieldsToGenerate.push('"description_zh": a Traditional Chinese (繁體中文) translation of the venue description. Write in a warm editorial tone appropriate for a Hong Kong cultural discovery platform. 2-3 sentences.');
    if (needsDistrictZh) fieldsToGenerate.push('"district_zh": the Traditional Chinese name for the district (e.g. "中環", "尖沙咀", "深水埗", "灣仔", "旺角", "銅鑼灣", "上環", "西營盤", "黃竹坑")');

    const prompt = `You are an AI content editor for CULTIVE, a cultural events and venue discovery platform for Hong Kong. Enrich this venue data with compelling, accurate content.

Here is the venue data:
${context}

Generate the following fields as a JSON object:
${fieldsToGenerate.join("\n")}

IMPORTANT:
- Write naturally, avoid clichés like "nestled in the heart of" or "a must-visit"
- Be specific to Hong Kong culture and neighborhoods
- Descriptions should feel editorial, like a cool city guide magazine
- vibeTags should be evocative single words or hyphenated phrases
- modeScores must be on a 0.0-1.0 scale (NOT 0-10)
- Return ONLY a valid JSON object with the requested fields`;

    const geminiResult = await callGemini(prompt);

    const enriched: Record<string, any> = {};
    const fieldsEnriched: string[] = [];

    if (geminiResult) {
      try {
        const parsed = JSON.parse(geminiResult);
        console.log(`Gemini enrichment for "${venue.name}":`, JSON.stringify(parsed).slice(0, 300));

        if (needsDescription && parsed.description && typeof parsed.description === "string" && parsed.description.length > 10) {
          enriched.description = parsed.description.trim();
          fieldsEnriched.push("description");
        }
        if (needsVibeTags && Array.isArray(parsed.vibeTags) && parsed.vibeTags.length > 0) {
          enriched.vibeTags = parsed.vibeTags.map((t: string) => String(t).toLowerCase().trim()).filter(Boolean).slice(0, 6);
          fieldsEnriched.push("vibeTags");
        }
        if (needsNameZh && parsed.nameZh && typeof parsed.nameZh === "string" && parsed.nameZh.trim()) {
          enriched.nameZh = parsed.nameZh.trim();
          fieldsEnriched.push("nameZh");
        }
        if (needsModeScores && parsed.modeScores && typeof parsed.modeScores === "object") {
          const scores: Record<string, number> = {};
          const validModes = ["degen", "artsy", "foodie", "family", "lifestyle"];
          for (const [mode, score] of Object.entries(parsed.modeScores)) {
            if (validModes.includes(mode) && typeof score === "number") {
              scores[mode] = score > 1 ? Math.round((score / 10) * 100) / 100 : Math.round(score * 100) / 100;
            }
          }
          if (Object.keys(scores).length > 0) {
            enriched.modeScores = scores;
            fieldsEnriched.push("modeScores");
          }
        }
        if (needsCategory && parsed.category && typeof parsed.category === "string") {
          enriched.category = parsed.category.trim();
          fieldsEnriched.push("category");
        }
        if (needsSubcategory && parsed.subcategory && typeof parsed.subcategory === "string") {
          enriched.subcategory = parsed.subcategory.trim();
          fieldsEnriched.push("subcategory");
        }
        if (needsDescriptionZh && parsed.description_zh && typeof parsed.description_zh === "string" && parsed.description_zh.trim().length > 5) {
          enriched.description_zh = parsed.description_zh.trim();
          fieldsEnriched.push("description_zh");
        }
        if (needsDistrictZh && parsed.district_zh && typeof parsed.district_zh === "string" && parsed.district_zh.trim().length > 0) {
          enriched.district_zh = parsed.district_zh.trim();
          fieldsEnriched.push("district_zh");
        }
      } catch (parseErr) {
        console.log(`Failed to parse Gemini JSON for "${venue.name}": ${parseErr}. Raw: ${geminiResult?.slice(0, 200)}`);
      }
    } else {
      console.log(`Gemini returned no result for "${venue.name}", falling back to rule-based`);
    }

    // ── Fallback: rule-based for any fields Gemini didn't fill ──
    if (needsDescription && !enriched.description) {
      const types = venue.googleTypes || [];
      const district = venue.district || "Hong Kong";
      const rating = venue.googleRating;
      const priceRange = venue.priceRange; // Don't assume a price range
      const typeDescMap: Record<string, string> = {
        bar: "bar and lounge", night_club: "nightclub", restaurant: "restaurant",
        cafe: "café", bakery: "bakery and café", art_gallery: "art gallery",
        museum: "museum and cultural space", gym: "fitness studio",
        spa: "spa and wellness center", park: "park and recreational area",
        book_store: "bookshop", movie_theater: "cinema",
      };
      let typeDesc = "venue";
      for (const t of types) { if (typeDescMap[t]) { typeDesc = typeDescMap[t]; break; } }
      const priceWords = ["budget-friendly", "affordable", "mid-range", "upscale"];
      const priceWord = priceRange ? priceWords[Math.min(priceRange - 1, 3)] : null;
      const ratingPhrase = rating ? (rating >= 4.5 ? "highly acclaimed" : rating >= 4.0 ? "well-regarded" : rating >= 3.5 ? "popular" : "neighborhood") : "";
      // Use Google editorial summary if available, otherwise generate
      if (venue.googleEditorialSummary) {
        enriched.description = venue.googleEditorialSummary;
      } else {
        enriched.description = `${venue.name} is a ${ratingPhrase ? ratingPhrase + ' ' : ''}${priceWord ? priceWord + ' ' : ''}${typeDesc} located in ${district}. Offering a distinctive atmosphere in one of Hong Kong's vibrant neighborhoods${rating ? `, rated ${rating}/5 by visitors` : ''}.`;
      }
      fieldsEnriched.push("description");
    }

    if (needsVibeTags && !enriched.vibeTags) {
      const types = venue.googleTypes || [];
      const tags: string[] = [];
      const typeTagMap: Record<string, string[]> = {
        bar: ["drinks", "nightlife"], night_club: ["nightlife", "music"],
        restaurant: ["dining", "food"], cafe: ["coffee", "chill"],
        art_gallery: ["art", "culture"], museum: ["culture", "heritage"],
        gym: ["fitness", "wellness"], spa: ["wellness", "relaxation"],
        park: ["outdoors", "nature"],
      };
      for (const t of types) { if (typeTagMap[t]) tags.push(...typeTagMap[t]); }
      if (tags.length === 0) tags.push("local", "hidden-gem");
      enriched.vibeTags = [...new Set(tags)].slice(0, 5);
      fieldsEnriched.push("vibeTags");
    }

    if (needsModeScores && !enriched.modeScores) {
      const types = venue.googleTypes || [];
      const scores: Record<string, number> = {};
      if (types.some((t: string) => ["bar", "night_club"].includes(t))) scores.degen = 0.8;
      if (types.some((t: string) => ["art_gallery", "museum"].includes(t))) scores.artsy = 0.8;
      if (types.some((t: string) => ["restaurant", "cafe", "bakery", "food"].includes(t))) scores.foodie = 0.8;
      if (types.some((t: string) => ["park", "museum", "tourist_attraction"].includes(t))) scores.family = 0.6;
      if (types.some((t: string) => ["gym", "spa", "book_store", "shopping_mall"].includes(t))) scores.lifestyle = 0.7;
      if (Object.keys(scores).length === 0) scores.lifestyle = 0.5;
      enriched.modeScores = scores;
      fieldsEnriched.push("modeScores");
    }

    if (fieldsEnriched.length === 0) {
      return c.json({ status: "no_changes", message: "All fields already populated", venue });
    }

    enriched._enrichedAt = new Date().toISOString();
    enriched._enrichedBy = geminiResult ? "gemini" : "rule-based";
    const updated = { ...venue, ...enriched };
    await kv.set(`cms:content:venue:${id}`, updated);

    console.log(`AI-enriched venue "${venue.name}" via ${enriched._enrichedBy}: ${fieldsEnriched.join(", ")}`);
    return c.json({ status: "enriched", venue: updated, fieldsEnriched, engine: enriched._enrichedBy });
  } catch (err) {
    console.log(`Error in venues ai-enrich: ${err}`);
    return c.json({ error: `AI enrichment failed: ${err}` }, 500);
  }
});

// POST /cms/venues/bulk-update — Update fields on a single venue (admin)
cms.post("/venues/bulk-update", async (c) => {
  try {
    const authHeader = c.req.header("X-Auth-Token");
    const admin = await verifyAdmin(authHeader);
    if (!admin) return c.json({ error: "Unauthorized" }, 401);

    const { id, updates } = await c.req.json();
    if (!id) return c.json({ error: "id is required" }, 400);
    if (!updates || typeof updates !== "object") return c.json({ error: "updates object is required" }, 400);

    const venue = (await kv.get(`cms:content:venue:${id}`)) as any;
    if (!venue) return c.json({ error: "Venue not found" }, 404);

    const updated = { ...venue, ...updates, _updatedAt: new Date().toISOString() };
    await kv.set(`cms:content:venue:${id}`, updated);

    console.log(`Updated venue "${venue.name}": ${Object.keys(updates).join(", ")}`);
    return c.json({ status: "updated", venue: updated });
  } catch (err) {
    console.log(`Error in venues bulk-update: ${err}`);
    return c.json({ error: `Update failed: ${err}` }, 500);
  }
});

// ═══════════════════════════════════════════════════
// AUTO-CREATE VENUES FROM EVENTS (Google Places)
// ═══════════════════════════════════════════════════

// POST /cms/venues/auto-create-from-events — Scan imported events, extract unique venue names,
// look them up on Google Places, and create proper venue records in the CMS.
cms.post("/venues/auto-create-from-events", async (c) => {
  try {
    const authHeader = c.req.header("X-Auth-Token");
    const admin = await verifyAdmin(authHeader);
    if (!admin) return c.json({ error: "Unauthorized" }, 401);

    const apiKey = Deno.env.get("GOOGLE_PLACES_API_KEY");
    if (!apiKey) {
      return c.json({ error: "GOOGLE_PLACES_API_KEY not configured" }, 500);
    }

    // ── 1. Gather all imported events ──
    const eventIds = ((await kv.get("cultive:event_ids")) as string[]) || [];
    const CHUNK = 50;
    const allEvents: any[] = [];
    for (let i = 0; i < eventIds.length; i += CHUNK) {
      const chunk = eventIds.slice(i, i + CHUNK);
      const keys = chunk.map((id: string) => `cultive:event:${id}`);
      const results = await kv.mget(keys);
      allEvents.push(...results.filter(Boolean));
    }

    // Also check CMS events
    const cmsEventIds = ((await kv.get("cms:content:event:ids")) as string[]) || [];
    for (let i = 0; i < cmsEventIds.length; i += CHUNK) {
      const chunk = cmsEventIds.slice(i, i + CHUNK);
      const keys = chunk.map((id: string) => `cms:content:event:${id}`);
      const results = await kv.mget(keys);
      allEvents.push(...results.filter(Boolean));
    }

    // ── 2. Extract unique venue names from imported events ──
    const venueMap = new Map<string, { name: string; district: string; eventCount: number; eventIds: string[]; lat?: number; lng?: number }>();
    const importedPrefixes = ["ra_", "apify_", "lsa_", "sub_"];

    for (const event of allEvents) {
      if (!event || !event.id) continue;
      if (!importedPrefixes.some(p => event.id.startsWith(p))) continue;

      const venueName = (event.venueName || event.venue || "").trim();
      if (!venueName || venueName.length < 2) continue;

      const normalizedKey = venueName.toLowerCase().replace(/[^a-z0-9\u4e00-\u9fff]/g, "");
      if (!normalizedKey) continue;

      if (venueMap.has(normalizedKey)) {
        const existing = venueMap.get(normalizedKey)!;
        existing.eventCount++;
        existing.eventIds.push(event.id);
        // Prefer existing lat/lng from event if the venue entry doesn't have one
        if (!existing.lat && event.lat && event.lng) {
          existing.lat = event.lat;
          existing.lng = event.lng;
        }
        if (!existing.district && event.district) {
          existing.district = event.district;
        }
      } else {
        venueMap.set(normalizedKey, {
          name: venueName,
          district: event.district || "",
          eventCount: 1,
          eventIds: [event.id],
          lat: event.lat || undefined,
          lng: event.lng || undefined,
        });
      }
    }

    // ── 3. Check existing CMS venues to avoid duplicates ──
    const existingVenueIds = ((await kv.get("cms:content:venue:ids")) as string[]) || [];
    const existingVenues: any[] = [];
    for (let i = 0; i < existingVenueIds.length; i += CHUNK) {
      const chunk = existingVenueIds.slice(i, i + CHUNK);
      const keys = chunk.map((id: string) => `cms:content:venue:${id}`);
      const results = await kv.mget(keys);
      existingVenues.push(...results.filter(Boolean));
    }

    const existingVenueNames = new Set(
      existingVenues.map((v: any) => (v.name || "").toLowerCase().replace(/[^a-z0-9\u4e00-\u9fff]/g, ""))
    );

    // ── 4. Look up each unique venue on Google Places and create ──
    const results: { name: string; status: string; venueId?: string; error?: string; eventCount: number }[] = [];
    const newVenueIds: string[] = [];
    const writeKeys: string[] = [];
    const writeValues: any[] = [];
    let lookupCount = 0;

    for (const [normalizedKey, info] of venueMap.entries()) {
      // Skip if venue already exists
      if (existingVenueNames.has(normalizedKey)) {
        results.push({ name: info.name, status: "already_exists", eventCount: info.eventCount });
        continue;
      }

      // Google Places lookup
      lookupCount++;
      const searchQuery = info.district
        ? `${info.name} ${info.district} Hong Kong`
        : `${info.name} Hong Kong`;

      try {
        const searchParams = new URLSearchParams({
          query: searchQuery,
          key: apiKey,
          language: "en",
          region: "hk",
        });

        const searchRes = await fetch(
          `https://maps.googleapis.com/maps/api/place/textsearch/json?${searchParams}`
        );
        const searchData = await searchRes.json();

        if (searchData.status !== "OK" || !searchData.results?.length) {
          // If Google Places doesn't find it but we have lat/lng from event, create with that
          if (info.lat && info.lng) {
            const venueId = `venue_${normalizedKey.slice(0, 20)}_${Date.now().toString(36)}`;
            const venue = {
              id: venueId,
              name: info.name,
              nameZh: "",
              description: "",
              category: "other",
              subcategory: "",
              lat: info.lat,
              lng: info.lng,
              district: info.district || "",
              address: info.district ? `${info.district}, Hong Kong` : "Hong Kong",
              image: "",
              modeScores: { lifestyle: 0.5 },
              vibeTags: [],
              priceRange: 2,
              upcomingEvents: info.eventCount,
              pastRecaps: 0,
              _source: "auto_from_events",
              _sourceLabel: "Auto (from events)",
              _createdAt: new Date().toISOString(),
              _geocodeSource: "event_data",
            };

            writeKeys.push(`cms:content:venue:${venueId}`);
            writeValues.push(venue);
            newVenueIds.push(venueId);
            results.push({ name: info.name, status: "created_from_event_coords", venueId, eventCount: info.eventCount });
          } else {
            results.push({ name: info.name, status: "not_found", eventCount: info.eventCount });
          }
          // Rate limit delay
          await new Promise(r => setTimeout(r, 200));
          continue;
        }

        const place = searchData.results[0];
        const placeId = place.place_id;

        // Get full details
        const detailParams = new URLSearchParams({
          place_id: placeId,
          key: apiKey,
          fields: [
            "name", "formatted_address", "geometry", "address_components",
            "types", "rating", "user_ratings_total", "price_level",
            "website", "formatted_phone_number", "opening_hours",
            "photos", "editorial_summary", "url",
          ].join(","),
          language: "en",
        });

        const detailRes = await fetch(
          `https://maps.googleapis.com/maps/api/place/details/json?${detailParams}`
        );
        const detailData = await detailRes.json();

        const d = detailData.status === "OK" ? detailData.result : place;
        const lat = d.geometry?.location?.lat || place.geometry?.location?.lat;
        const lng = d.geometry?.location?.lng || place.geometry?.location?.lng;

        if (!lat || !lng) {
          results.push({ name: info.name, status: "no_coordinates", eventCount: info.eventCount });
          await new Promise(r => setTimeout(r, 200));
          continue;
        }

        // Extract district
        let district = info.district || "";
        const components = d.address_components || [];
        for (const comp of components) {
          if (comp.types.includes("sublocality_level_1") || comp.types.includes("neighborhood")) {
            district = comp.long_name;
            break;
          }
        }
        if (!district) {
          for (const comp of components) {
            if (comp.types.includes("locality") && comp.long_name !== "Hong Kong") {
              district = comp.long_name;
              break;
            }
          }
        }

        // Build photo URL
        let photoUrl = "";
        if (d.photos?.length > 0) {
          const photoRef = d.photos[0].photo_reference;
          photoUrl = `https://maps.googleapis.com/maps/api/place/photo?maxwidth=800&photo_reference=${photoRef}&key=${apiKey}`;
        }

        // Map Google types → mode scores
        const types = d.types || place.types || [];
        const modeScores: Record<string, number> = {};
        if (types.some((t: string) => ["night_club", "bar", "casino"].includes(t))) modeScores.degen = 0.8;
        if (types.some((t: string) => ["art_gallery", "museum", "movie_theater"].includes(t))) modeScores.artsy = 0.8;
        if (types.some((t: string) => ["restaurant", "cafe", "bakery", "food"].includes(t))) modeScores.foodie = 0.8;
        if (types.some((t: string) => ["park", "museum", "amusement_park", "zoo", "aquarium", "tourist_attraction"].includes(t))) modeScores.family = 0.6;
        if (types.some((t: string) => ["gym", "spa", "health", "yoga", "book_store", "shopping_mall", "stadium"].includes(t))) modeScores.lifestyle = 0.7;
        if (Object.keys(modeScores).length === 0) modeScores.lifestyle = 0.5;

        // Map Google types → vibeTags
        const vibeTags: string[] = [];
        const typeTagMap: Record<string, string[]> = {
          night_club: ["nightlife", "clubbing"], bar: ["drinks", "social"],
          restaurant: ["dining", "cuisine"], cafe: ["coffee", "chill"],
          art_gallery: ["art", "gallery"], museum: ["culture", "heritage"],
          park: ["outdoors", "nature"], gym: ["fitness", "active"],
          spa: ["wellness", "relax"], book_store: ["literary", "cozy"],
        };
        for (const t of types) { if (typeTagMap[t]) vibeTags.push(...typeTagMap[t]); }
        if (vibeTags.length === 0) vibeTags.push("local", "hidden-gem");

        // Map Google types → category
        let category = "other";
        if (types.includes("night_club") || types.includes("bar")) category = "nightlife";
        else if (types.includes("restaurant") || types.includes("cafe") || types.includes("bakery")) category = "dining";
        else if (types.includes("art_gallery")) category = "gallery";
        else if (types.includes("museum")) category = "museum";
        else if (types.includes("park")) category = "park";
        else if (types.includes("gym") || types.includes("spa")) category = "wellness";
        else if (types.includes("movie_theater")) category = "cinema";

        const venueId = `venue_${normalizedKey.slice(0, 20)}_${Date.now().toString(36)}`;
        const venue = {
          id: venueId,
          name: d.name || info.name,
          nameZh: "",
          description: d.editorial_summary?.overview || (detailData.status === "OK" ? "" : ""),
          category,
          subcategory: "",
          lat,
          lng,
          district,
          address: d.formatted_address || place.formatted_address || "",
          image: photoUrl,
          modeScores,
          vibeTags: [...new Set(vibeTags)].slice(0, 6),
          priceRange: Math.max(1, Math.min(4, ((d.price_level ?? place.price_level) || 1) + 1)),
          upcomingEvents: info.eventCount,
          pastRecaps: 0,
          // Google data
          googlePlaceId: placeId,
          googleRating: d.rating || place.rating || null,
          googleRatingsTotal: d.user_ratings_total || place.user_ratings_total || null,
          googleTypes: types,
          googleMapsUrl: d.url || null,
          googleWebsite: d.website || null,
          googlePhone: d.formatted_phone_number || null,
          googleOpeningHours: d.opening_hours?.weekday_text || null,
          googleEditorialSummary: d.editorial_summary?.overview || null,
          // Meta
          _source: "auto_from_events",
          _sourceLabel: "Auto (from events)",
          _createdAt: new Date().toISOString(),
          _geocodeSource: "google_places",
          _linkedEventIds: info.eventIds.slice(0, 20),
        };

        writeKeys.push(`cms:content:venue:${venueId}`);
        writeValues.push(venue);
        newVenueIds.push(venueId);
        results.push({ name: info.name, status: "created", venueId, eventCount: info.eventCount });

        // Rate limit: 200ms between Google API calls
        await new Promise(r => setTimeout(r, 200));
      } catch (err) {
        console.log(`Google Places lookup error for "${info.name}": ${err}`);
        results.push({ name: info.name, status: "error", error: String(err), eventCount: info.eventCount });
      }
    }

    // ── 5. Batch write new venues ──
    for (let i = 0; i < writeKeys.length; i += CHUNK) {
      const chunkK = writeKeys.slice(i, i + CHUNK);
      const chunkV = writeValues.slice(i, i + CHUNK);
      await kv.mset(chunkK, chunkV);
    }

    // ── 6. Update venue index ──
    if (newVenueIds.length > 0) {
      const venueIds = ((await kv.get("cms:content:venue:ids")) as string[]) || [];
      venueIds.push(...newVenueIds);
      await kv.set("cms:content:venue:ids", venueIds);
    }

    // ── 7. Link events to newly created venues (update venueId + lat/lng on events) ──
    const venueNameToId = new Map<string, { venueId: string; lat: number; lng: number }>();
    for (const r of results) {
      if ((r.status === "created" || r.status === "created_from_event_coords") && r.venueId) {
        const venueData = writeValues.find((v: any) => v.id === r.venueId);
        if (venueData) {
          const nk = r.name.toLowerCase().replace(/[^a-z0-9\u4e00-\u9fff]/g, "");
          venueNameToId.set(nk, { venueId: r.venueId, lat: venueData.lat, lng: venueData.lng });
        }
      }
    }

    let eventsLinked = 0;
    if (venueNameToId.size > 0) {
      const eventUpdateKeys: string[] = [];
      const eventUpdateValues: any[] = [];

      for (const event of allEvents) {
        if (!event || !event.id) continue;
        const eventVenueName = (event.venueName || event.venue || "").trim();
        if (!eventVenueName) continue;
        const nk = eventVenueName.toLowerCase().replace(/[^a-z0-9\u4e00-\u9fff]/g, "");
        const match = venueNameToId.get(nk);
        if (!match) continue;

        const updated = {
          ...event,
          venueId: match.venueId,
          lat: match.lat,
          lng: match.lng,
          _venueLinkedAt: new Date().toISOString(),
        };

        eventUpdateKeys.push(`cultive:event:${event.id}`);
        eventUpdateValues.push(updated);
        if (cmsEventIds.includes(event.id)) {
          eventUpdateKeys.push(`cms:content:event:${event.id}`);
          eventUpdateValues.push(updated);
        }
        eventsLinked++;
      }

      for (let i = 0; i < eventUpdateKeys.length; i += CHUNK) {
        const chunkK = eventUpdateKeys.slice(i, i + CHUNK);
        const chunkV = eventUpdateValues.slice(i, i + CHUNK);
        await kv.mset(chunkK, chunkV);
      }
      console.log(`Linked ${eventsLinked} events to newly created venues`);
    }

    const created = results.filter(r => r.status === "created" || r.status === "created_from_event_coords").length;
    const existing = results.filter(r => r.status === "already_exists").length;
    const notFound = results.filter(r => r.status === "not_found" || r.status === "no_coordinates").length;
    const errors = results.filter(r => r.status === "error").length;

    console.log(`Auto-create venues: ${created} created, ${existing} already exist, ${notFound} not found, ${errors} errors, ${lookupCount} Google lookups, ${eventsLinked} events linked by ${admin.email}`);
    return c.json({
      status: "ok",
      results,
      summary: { created, existing, notFound, errors, totalUniqueVenues: venueMap.size, googleLookups: lookupCount, eventsLinked },
    });
  } catch (err) {
    console.log(`Error in auto-create venues from events: ${err}`);
    return c.json({ error: `Auto-create venues failed: ${err}` }, 500);
  }
});

// ═══════════════════════════════════════════════════
// MEDIA LIBRARY (list, delete, refresh URLs)
// ═══════════════════════════════════════════════════

// GET /cms/media — List files in storage (admin)
cms.get("/media", async (c) => {
  try {
    const authHeader = c.req.header("X-Auth-Token");
    const admin = await verifyAdmin(authHeader);
    if (!admin) return c.json({ error: "Unauthorized" }, 401);

    await ensureBucket();
    const supabase = getSupabaseAdmin();

    const { data: fileList, error } = await supabase.storage
      .from(BUCKET_NAME)
      .list("uploads", {
        limit: 200,
        sortBy: { column: "created_at", order: "desc" },
      });

    if (error) {
      console.log(`Media list error: ${error.message}`);
      return c.json({ error: `Failed to list media: ${error.message}` }, 500);
    }

    // Generate signed URLs for each file
    const files = [];
    for (const file of fileList || []) {
      if (file.name === ".emptyFolderPlaceholder") continue;

      const storagePath = `uploads/${file.name}`;
      const { data: signedData } = await supabase.storage
        .from(BUCKET_NAME)
        .createSignedUrl(storagePath, 60 * 60 * 24 * 7); // 7 days

      files.push({
        name: file.name,
        path: storagePath,
        url: signedData?.signedUrl || "",
        size: file.metadata?.size || 0,
        type: file.metadata?.mimetype || "image/unknown",
        createdAt: file.created_at || "",
      });
    }

    return c.json({ files, count: files.length });
  } catch (err) {
    console.log(`Media list error: ${err}`);
    return c.json({ error: `Failed to list media: ${err}` }, 500);
  }
});

// DELETE /cms/media — Delete files from storage (admin)
cms.delete("/media", async (c) => {
  try {
    const authHeader = c.req.header("X-Auth-Token");
    const admin = await verifyAdmin(authHeader);
    if (!admin) return c.json({ error: "Unauthorized" }, 401);

    const { paths } = await c.req.json();
    if (!Array.isArray(paths) || paths.length === 0) {
      return c.json({ error: "paths array required" }, 400);
    }

    const supabase = getSupabaseAdmin();
    const { error } = await supabase.storage.from(BUCKET_NAME).remove(paths);

    if (error) {
      return c.json({ error: `Delete failed: ${error.message}` }, 500);
    }

    return c.json({ status: "deleted", count: paths.length });
  } catch (err) {
    return c.json({ error: `Delete failed: ${err}` }, 500);
  }
});

// POST /cms/media/refresh-urls — Regenerate signed URLs for all submissions (admin)
cms.post("/media/refresh-urls", async (c) => {
  try {
    const authHeader = c.req.header("X-Auth-Token");
    const admin = await verifyAdmin(authHeader);
    if (!admin) return c.json({ error: "Unauthorized" }, 401);

    const supabase = getSupabaseAdmin();
    const ids = ((await kv.get("cms:submission_ids")) as string[]) || [];

    if (ids.length === 0) return c.json({ status: "ok", refreshed: 0 });

    let refreshed = 0;

    for (const id of ids) {
      const submission = (await kv.get(`cms:submission:${id}`)) as any;
      if (!submission?.images?.length) continue;

      let updated = false;
      const newImages: string[] = [];

      for (const imgUrl of submission.images) {
        // Only refresh Supabase storage URLs
        if (imgUrl.includes(BUCKET_NAME)) {
          // Extract the path from the signed URL
          const pathMatch = imgUrl.match(/\/object\/sign\/[^/]+\/(.+?)(?:\?|$)/);
          if (pathMatch) {
            const storagePath = decodeURIComponent(pathMatch[1]);
            const { data } = await supabase.storage
              .from(BUCKET_NAME)
              .createSignedUrl(storagePath, 60 * 60 * 24 * 7);
            if (data?.signedUrl) {
              newImages.push(data.signedUrl);
              updated = true;
              continue;
            }
          }
        }
        newImages.push(imgUrl);
      }

      if (updated) {
        submission.images = newImages;
        submission._urlsRefreshedAt = new Date().toISOString();
        await kv.set(`cms:submission:${id}`, submission);
        refreshed++;
      }
    }

    return c.json({ status: "ok", refreshed });
  } catch (err) {
    console.log(`URL refresh error: ${err}`);
    return c.json({ error: `Failed to refresh URLs: ${err}` }, 500);
  }
});

// ═══════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════

function getEmptyCounts() {
  return {
    total: 0,
    pending: 0,
    "ai-approved": 0,
    "ai-flagged": 0,
    approved: 0,
    published: 0,
    rejected: 0,
  };
}

function getStatusMessage(status: string): string {
  switch (status) {
    case "pending":
      return "Your submission is being reviewed.";
    case "ai-approved":
      return "Your submission passed initial review and is awaiting final approval.";
    case "ai-flagged":
      return "Your submission is under review by our team.";
    case "approved":
      return "Your submission has been approved! It will be published soon.";
    case "published":
      return "Your submission is live on CULTIVE!";
    case "rejected":
      return "Your submission was not selected for publication at this time.";
    default:
      return "Status unknown.";
  }
}

// ═══════════════════════════════════════════════════
// WEEKLY PICKS (curated 3 picks by admin)
// ═══════════════════════════════════════════════════
const WEEKLY_PICKS_KEY = "cms:weekly_picks";

// GET /cms/weekly-picks — Public: get curated weekly picks
cms.get("/weekly-picks", async (c) => {
  try {
    const data = (await kv.get(WEEKLY_PICKS_KEY)) as any;
    return c.json({ picks: data || null });
  } catch (err) {
    return c.json({ picks: null });
  }
});

// PUT /cms/weekly-picks — Admin: set curated weekly picks
cms.put("/weekly-picks", async (c) => {
  try {
    const authHeader = c.req.header("X-Auth-Token");
    const admin = await verifyAdmin(authHeader);
    if (!admin) return c.json({ error: "Unauthorized" }, 401);

    const body = await c.req.json();
    const picks = {
      eventIds: body.eventIds || [],
      note: body.note || "",
      updatedAt: new Date().toISOString(),
      updatedBy: admin.email,
    };
    await kv.set(WEEKLY_PICKS_KEY, picks);
    return c.json({ status: "updated", picks });
  } catch (err) {
    return c.json({ error: `Failed to update weekly picks: ${err}` }, 500);
  }
});

// ═══════════════════════════════════════════════════
// WEBHOOK REGISTRY (KV-backed persistence)
// ═══════════════════════════════════════════════════

const WEBHOOKS_KEY = "cms:webhooks";
const WEBHOOK_DELIVERY_LOG_KEY = "cms:webhook_delivery_log";
const MAX_DELIVERY_LOGS = 200;

// GET /cms/webhooks — Read registered webhooks (admin)
cms.get("/webhooks", async (c) => {
  try {
    const authHeader = c.req.header("X-Auth-Token") || c.req.header("Authorization");
    const admin = await verifyAdmin(authHeader);
    if (!admin) return c.json({ error: "Unauthorized" }, 401);

    const webhooks = ((await kv.get(WEBHOOKS_KEY)) as any[]) || [];
    const deliveryLog = ((await kv.get(WEBHOOK_DELIVERY_LOG_KEY)) as any[]) || [];

    return c.json({ webhooks, deliveryLog });
  } catch (err) {
    return c.json({ error: `Failed to get webhooks: ${err}` }, 500);
  }
});

// PUT /cms/webhooks — Save entire webhook registry (admin)
cms.put("/webhooks", async (c) => {
  try {
    const authHeader = c.req.header("X-Auth-Token") || c.req.header("Authorization");
    const admin = await verifyAdmin(authHeader);
    if (!admin) return c.json({ error: "Unauthorized" }, 401);

    const body = await c.req.json();
    const webhooks = body.webhooks || [];

    await kv.set(WEBHOOKS_KEY, webhooks);

    return c.json({ status: "updated", count: webhooks.length });
  } catch (err) {
    return c.json({ error: `Failed to save webhooks: ${err}` }, 500);
  }
});

// POST /cms/webhooks/delivery-log — Append delivery log entries (admin)
cms.post("/webhooks/delivery-log", async (c) => {
  try {
    const authHeader = c.req.header("X-Auth-Token") || c.req.header("Authorization");
    const admin = await verifyAdmin(authHeader);
    if (!admin) return c.json({ error: "Unauthorized" }, 401);

    const body = await c.req.json();
    const entries = body.entries || [];
    if (!Array.isArray(entries) || entries.length === 0) {
      return c.json({ error: "entries array is required" }, 400);
    }

    const existingLog = ((await kv.get(WEBHOOK_DELIVERY_LOG_KEY)) as any[]) || [];

    // Prepend new entries, cap at MAX_DELIVERY_LOGS
    const updatedLog = [...entries, ...existingLog].slice(0, MAX_DELIVERY_LOGS);
    await kv.set(WEBHOOK_DELIVERY_LOG_KEY, updatedLog);

    return c.json({ status: "appended", count: entries.length, total: updatedLog.length });
  } catch (err) {
    return c.json({ error: `Failed to append delivery log: ${err}` }, 500);
  }
});

// GET /cms/webhooks/delivery-log — Read delivery log (admin)
cms.get("/webhooks/delivery-log", async (c) => {
  try {
    const authHeader = c.req.header("X-Auth-Token") || c.req.header("Authorization");
    const admin = await verifyAdmin(authHeader);
    if (!admin) return c.json({ error: "Unauthorized" }, 401);

    const deliveryLog = ((await kv.get(WEBHOOK_DELIVERY_LOG_KEY)) as any[]) || [];
    return c.json({ deliveryLog });
  } catch (err) {
    return c.json({ error: `Failed to get delivery log: ${err}` }, 500);
  }
});

// DELETE /cms/webhooks/delivery-log — Clear delivery log (admin)
cms.delete("/webhooks/delivery-log", async (c) => {
  try {
    const authHeader = c.req.header("X-Auth-Token") || c.req.header("Authorization");
    const admin = await verifyAdmin(authHeader);
    if (!admin) return c.json({ error: "Unauthorized" }, 401);

    await kv.set(WEBHOOK_DELIVERY_LOG_KEY, []);
    return c.json({ status: "cleared" });
  } catch (err) {
    return c.json({ error: `Failed to clear delivery log: ${err}` }, 500);
  }
});

// ─── Rate limiter (in-memory, per-isolate — resets on cold start) ────────
// Sliding window: max 30 requests per 60s per IP on the health endpoint.
const HEALTH_RATE_WINDOW_MS = 60_000;
const HEALTH_RATE_MAX = 30;
const _healthRateMap = new Map<string, number[]>();

function checkHealthRateLimit(ip: string): { ok: boolean; remaining: number; resetIn: number } {
  const now = Date.now();
  const windowStart = now - HEALTH_RATE_WINDOW_MS;
  let hits = _healthRateMap.get(ip) || [];
  hits = hits.filter(t => t > windowStart);
  if (hits.length >= HEALTH_RATE_MAX) {
    const oldest = hits[0];
    return { ok: false, remaining: 0, resetIn: Math.ceil((oldest + HEALTH_RATE_WINDOW_MS - now) / 1000) };
  }
  hits.push(now);
  _healthRateMap.set(ip, hits);
  // Lazy cleanup: purge stale IPs every ~1% of calls
  if (Math.random() < 0.01) {
    for (const [k, v] of _healthRateMap) {
      if (v.every(t => t <= windowStart)) _healthRateMap.delete(k);
    }
  }
  return { ok: true, remaining: HEALTH_RATE_MAX - hits.length, resetIn: Math.ceil(HEALTH_RATE_WINDOW_MS / 1000) };
}

// GET /cms/webhooks/health — Public health check for agent connectivity verification
// No auth required — agents ping this before registering a webhook URL.
// Rate-limited: 30 req/min per IP to prevent abuse.
cms.get("/webhooks/health", async (c) => {
  // Rate limit by IP (CF-Connecting-IP → X-Forwarded-For → X-Real-IP → fallback)
  const ip = c.req.header("cf-connecting-ip")
    || c.req.header("x-forwarded-for")?.split(",")[0]?.trim()
    || c.req.header("x-real-ip")
    || "unknown";

  const rl = checkHealthRateLimit(ip);
  c.header("X-RateLimit-Limit", String(HEALTH_RATE_MAX));
  c.header("X-RateLimit-Remaining", String(rl.remaining));
  c.header("X-RateLimit-Reset", String(rl.resetIn));

  if (!rl.ok) {
    return c.json(
      { error: "Rate limit exceeded", retryAfter: rl.resetIn },
      429,
    );
  }

  const nonce = crypto.randomUUID?.() || `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  let registeredCount = 0;
  let activeCount = 0;
  try {
    const webhooks = ((await kv.get(WEBHOOKS_KEY)) as any[]) || [];
    registeredCount = webhooks.length;
    activeCount = webhooks.filter((h: any) => h.active).length;
  } catch {}
  return c.json({
    status: "ok",
    platform: "CULTIVE",
    version: "1.0",
    nonce,
    timestamp: new Date().toISOString(),
    capabilities: {
      events: [
        "submission.created",
        "submission.status_changed",
        "submission.published",
        "submission.rejected",
        "content.created",
        "content.updated",
        "content.deleted",
        "weekly_picks.updated",
        "bulk_import.completed",
      ],
      signing: "HMAC-SHA256",
      maxRetries: 5,
      retryStrategy: "exponential-backoff",
      deliveryTimeout: "10s",
    },
    registeredCount,
    activeCount,
  });
});

// ─── Delivery Log Export (CSV / JSON) ───────────────────────────────────
// GET /cms/webhooks/delivery-log/export?format=csv|json
// Returns the full delivery log as a downloadable file for compliance/audit.

cms.get("/webhooks/delivery-log/export", async (c) => {
  try {
    const authHeader = c.req.header("X-Auth-Token") || c.req.header("Authorization");
    const admin = await verifyAdmin(authHeader);
    if (!admin) return c.json({ error: "Unauthorized" }, 401);

    const format = (c.req.query("format") || "json").toLowerCase();
    const deliveryLog = ((await kv.get(WEBHOOK_DELIVERY_LOG_KEY)) as any[]) || [];

    if (format === "csv") {
      const CSV_COLUMNS = [
        "id", "deliveryId", "webhookId", "webhookLabel", "webhookUrl",
        "event", "timestamp", "status", "responseTime", "attempt", "error",
      ];
      const escCsv = (v: any) => {
        const s = String(v ?? "");
        return s.includes(",") || s.includes('"') || s.includes("\n")
          ? `"${s.replace(/"/g, '""')}"`
          : s;
      };
      const rows = [
        CSV_COLUMNS.join(","),
        ...deliveryLog.map((e: any) =>
          CSV_COLUMNS.map((col) => escCsv(e[col])).join(",")
        ),
      ];
      const csvBody = rows.join("\n");
      const ts = new Date().toISOString().replace(/[:.]/g, "-");

      return new Response(csvBody, {
        status: 200,
        headers: {
          "Content-Type": "text/csv; charset=utf-8",
          "Content-Disposition": `attachment; filename="cultive-delivery-log-${ts}.csv"`,
        },
      });
    }

    // Default: JSON download
    const ts = new Date().toISOString().replace(/[:.]/g, "-");
    const jsonBody = JSON.stringify({
      exportedAt: new Date().toISOString(),
      exportedBy: (admin as any).email || "admin",
      platform: "CULTIVE",
      count: deliveryLog.length,
      deliveryLog,
    }, null, 2);

    return new Response(jsonBody, {
      status: 200,
      headers: {
        "Content-Type": "application/json; charset=utf-8",
        "Content-Disposition": `attachment; filename="cultive-delivery-log-${ts}.json"`,
      },
    });
  } catch (err) {
    return c.json({ error: `Failed to export delivery log: ${err}` }, 500);
  }
});

export { cms };

// ═══════════════════════════════════════════════════
// COPY EDITOR ROUTES
// ═══════════════════════════════════════════════════

// GET /cms/copy — List all copy overrides (admin)
cms.get("/copy", async (c) => {
  try {
    const authHeader = c.req.header("X-Auth-Token");
    const admin = await verifyAdmin(authHeader);
    if (!admin) return c.json({ error: "Unauthorized" }, 401);

    const data = (await kv.get("cms:copy_overrides")) as any[] || [];
    return c.json({ overrides: data });
  } catch (err) {
    return c.json({ error: `Failed to get copy: ${err}` }, 500);
  }
});

// PUT /cms/copy/:key — Update a single copy key (admin)
cms.put("/copy/:key", async (c) => {
  try {
    const authHeader = c.req.header("X-Auth-Token");
    const admin = await verifyAdmin(authHeader);
    if (!admin) return c.json({ error: "Unauthorized" }, 401);

    const key = decodeURIComponent(c.req.param("key"));
    const { en, zh } = await c.req.json();

    const overrides = ((await kv.get("cms:copy_overrides")) as any[]) || [];
    const idx = overrides.findIndex((o: any) => o.key === key);
    const entry = { key, en, zh, updatedAt: new Date().toISOString(), updatedBy: admin.email };

    if (idx >= 0) {
      overrides[idx] = entry;
    } else {
      overrides.push(entry);
    }

    await kv.set("cms:copy_overrides", overrides);
    return c.json({ status: "updated", entry });
  } catch (err) {
    return c.json({ error: `Failed to update copy: ${err}` }, 500);
  }
});

// ═══════════════════════════════════════════════════
// TRANSLATION ROUTES
// ═══════════════════════════════════════════════════

// Simple rule-based translation (fallback when no AI API key)
function simpleTranslate(text: string, to: string): string {
  // Common HK Chinese translations dictionary
  const dict: Record<string, string> = {
    'home': '首頁', 'events': '活動', 'map': '地圖', 'about': '關於',
    'contribute': '投稿', 'search': '搜尋', 'explore': '探索',
    'discover': '探索', 'culture': '文化', 'hong kong': '香港',
    'community': '社區', 'submit': '提交', 'details': '詳情',
    'all': '全部', 'featured': '精選', 'free': '免費',
    'night': '夜生活', 'family': '親子', 'art': '藝術',
    'food': '美食', 'lifestyle': '生活方式', 'design': '設計',
    'wellness': '健康', 'yoga': '瑜伽', 'hike': '遠足',
    'workshop': '工作坊', 'exhibition': '展覽', 'gallery': '畫廊',
    'market': '市集', 'music': '音樂', 'performance': '演出',
    'venue': '場地', 'location': '地點', 'date': '日期',
    'time': '時間', 'price': '價格', 'category': '類別',
    'view': '查看', 'open': '打開', 'close': '關閉',
    'save': '儲存', 'delete': '刪除', 'edit': '編輯',
    'cancel': '取消', 'confirm': '確認', 'back': '返回',
    'next': '下一步', 'previous': '上一步',
  };

  if (to.startsWith('zh')) {
    // Try exact match first
    const lower = text.toLowerCase().trim();
    if (dict[lower]) return dict[lower];

    // Try word-by-word replacement for simple phrases
    let result = text;
    for (const [en, zh] of Object.entries(dict)) {
      const regex = new RegExp(`\\b${en}\\b`, 'gi');
      result = result.replace(regex, zh);
    }
    if (result !== text) return result;

    // Fallback: return original with note
    return `[待翻譯] ${text}`;
  }

  return text;
}

// POST /cms/translate — Single text translation
cms.post("/translate", async (c) => {
  try {
    const authHeader = c.req.header("X-Auth-Token");
    const admin = await verifyAdmin(authHeader);
    if (!admin) return c.json({ error: "Unauthorized" }, 401);

    const { text, from, to } = await c.req.json();
    if (!text) return c.json({ error: "text required" }, 400);

    // Check for Gemini API key
    const geminiKey = Deno.env.get("GOOGLE_AI_API_KEY");

    if (geminiKey) {
      try {
        const translateBody = JSON.stringify({
          contents: [{
            parts: [{
              text: `Translate the following text from ${from || 'English'} to ${to || 'Traditional Chinese (Hong Kong)'}. Only return the translated text, nothing else.\n\nText: ${text}`,
            }],
          }],
        });
        let response: Response | null = null;
        for (const model of GEMINI_MODEL_CANDIDATES) {
          const r = await fetch(
            `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${geminiKey}`,
            { method: "POST", headers: { "Content-Type": "application/json" }, body: translateBody }
          );
          if (r.status === 404) continue;
          response = r;
          break;
        }
        if (response) {
          const data = await response.json();
          const translated = data.candidates?.[0]?.content?.parts?.[0]?.text?.trim();
          if (translated) {
            return c.json({ translated, method: "gemini" });
          }
        }
      } catch (aiErr) {
        console.log(`Gemini translation error: ${aiErr}`);
      }
    }

    // Fallback to rule-based
    const translated = simpleTranslate(text, to || "zh-HK");
    return c.json({ translated, method: "rule-based" });
  } catch (err) {
    return c.json({ error: `Translation failed: ${err}` }, 500);
  }
});

// POST /cms/translate/batch — Batch translation
cms.post("/translate/batch", async (c) => {
  try {
    const authHeader = c.req.header("X-Auth-Token");
    const admin = await verifyAdmin(authHeader);
    if (!admin) return c.json({ error: "Unauthorized" }, 401);

    const { items, from, to } = await c.req.json();
    if (!Array.isArray(items)) return c.json({ error: "items array required" }, 400);

    const geminiKey = Deno.env.get("GOOGLE_AI_API_KEY");
    const translations: string[] = [];

    if (geminiKey && items.length <= 50) {
      try {
        const numbered = items.map((t: string, i: number) => `${i + 1}. ${t}`).join("\n");
        const batchBody = JSON.stringify({
          contents: [{
            parts: [{
              text: `Translate each line from ${from || 'English'} to ${to || 'Traditional Chinese (Hong Kong)'}. Return ONLY the translations, one per line, numbered to match. Keep it natural for a Hong Kong audience.\n\n${numbered}`,
            }],
          }],
        });
        let response: Response | null = null;
        for (const model of GEMINI_MODEL_CANDIDATES) {
          const r = await fetch(
            `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${geminiKey}`,
            { method: "POST", headers: { "Content-Type": "application/json" }, body: batchBody }
          );
          if (r.status === 404) continue;
          response = r;
          break;
        }
        if (!response) throw new Error("All Gemini models returned 404");
        const data = await response.json();
        const text = data.candidates?.[0]?.content?.parts?.[0]?.text?.trim() || "";
        const lines = text.split("\n").map((l: string) => l.replace(/^\d+\.\s*/, "").trim()).filter(Boolean);
        if (lines.length === items.length) {
          return c.json({ translations: lines, method: "gemini" });
        }
      } catch (aiErr) {
        console.log(`Gemini batch error: ${aiErr}`);
      }
    }

    // Fallback: rule-based per item
    for (const item of items) {
      translations.push(simpleTranslate(item, to || "zh-HK"));
    }

    return c.json({ translations, method: "rule-based" });
  } catch (err) {
    return c.json({ error: `Batch translation failed: ${err}` }, 500);
  }
});

// ═══════════════════════════════════════════════════
// BULK AI ENRICHMENT FOR EVENTS
// ═══════════════════════════════════════════════════

// POST /cms/events/bulk-enrich — AI-enrich events via Gemini (admin)
// Uses batched prompts: sends up to 5 events per Gemini call to minimize API calls & rate limits
cms.post("/events/bulk-enrich", async (c) => {
  try {
    const authHeader = c.req.header("X-Auth-Token");
    const admin = await verifyAdmin(authHeader);
    if (!admin) return c.json({ error: "Unauthorized" }, 401);

    const { eventIds } = await c.req.json();
    if (!Array.isArray(eventIds) || eventIds.length === 0) {
      return c.json({ error: "eventIds array required" }, 400);
    }

    const ids = eventIds.slice(0, 25);
    const results: { id: string; status: string; fieldsEnriched: string[]; error?: string }[] = [];

    // Helper: determine what fields an event needs
    function getNeededFields(event: any) {
      return {
        needsDescription: !event.description || (typeof event.description === "string" && event.description.length < 30),
        needsModeTags: !event.modeTags || !Array.isArray(event.modeTags) || event.modeTags.length === 0,
        needsCategory: !event.category || event.category === "Events" || event.category === "other" || event.category === "Other",
        needsTime: !event.time || event.time === "",
        needsPrice: !event.price || event.price === "Check event page" || event.price === "",
        needsVibes: !event.vibes || !Array.isArray(event.vibes) || event.vibes.length === 0,
        needsArtists: !event.artists || !Array.isArray(event.artists) || event.artists.length === 0,
        // Bilingual: auto-translate to Traditional Chinese if _zh fields are missing
        needsTranslation: !event.title_zh || (typeof event.title_zh === "string" && event.title_zh.trim().length === 0),
      };
    }

    // Load all events first and separate into needs-enrichment vs already-complete
    const eventsToEnrich: { id: string; event: any; needs: ReturnType<typeof getNeededFields> }[] = [];

    for (const eventId of ids) {
      try {
        const event = (await kv.get(`cultive:event:${eventId}`)) as any;
        if (!event) {
          results.push({ id: eventId, status: "not_found", fieldsEnriched: [] });
          continue;
        }
        const needs = getNeededFields(event);
        const needsAnything = needs.needsDescription || needs.needsModeTags || needs.needsCategory ||
          needs.needsTime || needs.needsPrice || needs.needsVibes || needs.needsArtists || needs.needsTranslation;
        if (!needsAnything) {
          results.push({ id: eventId, status: "already_complete", fieldsEnriched: [] });
          continue;
        }
        eventsToEnrich.push({ id: eventId, event, needs });
      } catch (err) {
        results.push({ id: eventId, status: "error", fieldsEnriched: [], error: String(err) });
      }
    }

    // Process events in batches of 3 per Gemini call to minimize rate limit risk
    const BATCH_SIZE = 3;
    for (let batchStart = 0; batchStart < eventsToEnrich.length; batchStart += BATCH_SIZE) {
      const batch = eventsToEnrich.slice(batchStart, batchStart + BATCH_SIZE);

      // Build a multi-event prompt
      const eventSections = batch.map((item, idx) => {
        const { event, needs } = item;
        const context = [
          `Title: ${event.title}`,
          event.description ? `Description: ${event.description.slice(0, 200)}` : null,
          event.venueName ? `Venue: ${event.venueName}` : null,
          event.district ? `District: ${event.district}` : null,
          event.date ? `Date: ${event.date}` : null,
          event.time ? `Time: ${event.time}` : null,
          event.category ? `Category: ${event.category}` : null,
          event.price ? `Price: ${event.price}` : null,
          event.sourceUrl ? `URL: ${event.sourceUrl}` : null,
          event.artists?.length ? `Artists: ${event.artists.join(", ")}` : null,
        ].filter(Boolean).join("; ");

        const fieldsNeeded: string[] = [];
        if (needs.needsDescription) fieldsNeeded.push("description (compelling 2-4 sentence description, warm editorial tone, do NOT start with event title)");
        if (needs.needsModeTags) fieldsNeeded.push('modeTags (array of 1-3 from: "degen","artsy","foodie","family","lifestyle")');
        if (needs.needsCategory) fieldsNeeded.push('category (one of: "Art","Music","Nightlife","Food & Drink","Wellness","Film","Theatre","Festival","Workshop","Market","Sports","Family","Community","Events")');
        if (needs.needsTime) fieldsNeeded.push('time (format: "7:00 PM" or "2:00 PM - 6:00 PM", or "" if unknown)');
        if (needs.needsPrice) fieldsNeeded.push('price (e.g. "Free","HK$100","$80-150", or "Check event page" if unknown)');
        if (needs.needsVibes) fieldsNeeded.push("vibes (array of 2-4 lowercase atmosphere tags)");
        if (needs.needsArtists) fieldsNeeded.push("artists (array of performer names, or [] if none)");
        if (needs.needsTranslation) fieldsNeeded.push('"title_zh" (Traditional Chinese 繁體中文 translation of the event title), "description_zh" (Traditional Chinese 繁體中文 translation of the description, 2-4 sentences), "venueName_zh" (Traditional Chinese name of the venue, or "" if unknown), "district_zh" (Traditional Chinese name of the Hong Kong district, e.g. "中環", "尖沙咀", "深水埗")');

        return `EVENT_${idx}:\n${context}\nGenerate: ${fieldsNeeded.join(", ")}`;
      });

      const prompt = `You are an AI content editor for CULTIVE, a cultural events discovery platform for Hong Kong.
Enrich the following ${batch.length} events. Return a JSON object with keys "EVENT_0", "EVENT_1", etc. Each value is an object with the requested fields.

${eventSections.join("\n\n")}

RULES:
- modeTags MUST be from: "degen", "artsy", "foodie", "family", "lifestyle"
- Write naturally, be specific to Hong Kong culture
- *_zh fields must be in Traditional Chinese (繁體中文). district_zh should use standard HK district names (e.g. 中環, 尖沙咀, 深水埗, 灣仔, 旺角)
- Return ONLY a valid JSON object with keys EVENT_0 through EVENT_${batch.length - 1}`;

      try {
        const geminiResult = await callGemini(prompt, 5);

        if (!geminiResult) {
          console.log(`Gemini returned null for batch starting at index ${batchStart}`);
          // Fall back to individual calls for this batch — with longer delays to avoid cascading rate limits
          for (let fi = 0; fi < batch.length; fi++) {
            const item = batch[fi];
            // Wait longer before individual fallback calls (rate limit is likely the cause)
            if (fi > 0) await delay(5000);
            else await delay(3000); // Even first call needs a pause after batch failure
            const fallbackResult = await enrichSingleEvent(item.id, item.event, item.needs);
            results.push(fallbackResult);
          }
          continue;
        }

        // Parse batch response
        let parsed: any;
        try {
          parsed = JSON.parse(geminiResult);
        } catch (parseErr) {
          console.log(`Failed to parse batch Gemini JSON: ${parseErr}. Raw: ${geminiResult.slice(0, 500)}`);
          // Fall back to individual calls with longer delays
          for (let fi = 0; fi < batch.length; fi++) {
            const item = batch[fi];
            if (fi > 0) await delay(5000);
            else await delay(3000);
            const fallbackResult = await enrichSingleEvent(item.id, item.event, item.needs);
            results.push(fallbackResult);
          }
          continue;
        }

        // Apply enrichment from batch response
        for (let idx = 0; idx < batch.length; idx++) {
          const item = batch[idx];
          const eventData = parsed[`EVENT_${idx}`] || parsed[`event_${idx}`] || parsed[String(idx)];
          if (!eventData || typeof eventData !== "object") {
            console.log(`No data for EVENT_${idx} (${item.event.title}) in batch response`);
            results.push({ id: item.id, status: "gemini_failed", fieldsEnriched: [], error: "No data in batch response" });
            continue;
          }

          const applyResult = await applyEnrichment(item.id, item.event, item.needs, eventData);
          results.push(applyResult);
        }
      } catch (batchErr) {
        console.log(`Batch enrichment error at index ${batchStart}: ${batchErr}`);
        for (const item of batch) {
          results.push({ id: item.id, status: "error", fieldsEnriched: [], error: String(batchErr) });
        }
      }

      // Delay between batches to avoid rate limits (5s between batches)
      if (batchStart + BATCH_SIZE < eventsToEnrich.length) {
        await delay(5000);
      }
    }

    const enrichedCount = results.filter(r => r.status === "enriched").length;
    console.log(`Bulk AI enrichment: ${enrichedCount}/${ids.length} events enriched`);
    return c.json({ status: "ok", results, enrichedCount, total: ids.length });
  } catch (err) {
    console.log(`Error in bulk AI enrichment: ${err}`);
    return c.json({ error: `Bulk enrichment failed: ${err}` }, 500);
  }
});

// Helper: apply enrichment fields from parsed Gemini output to an event
async function applyEnrichment(
  eventId: string,
  event: any,
  needs: { needsDescription: boolean; needsModeTags: boolean; needsCategory: boolean; needsTime: boolean; needsPrice: boolean; needsVibes: boolean; needsArtists: boolean; needsTranslation?: boolean },
  parsed: any,
): Promise<{ id: string; status: string; fieldsEnriched: string[]; error?: string }> {
  try {
    const updates: Record<string, any> = {};
    const fieldsEnriched: string[] = [];

    if (needs.needsDescription && parsed.description && typeof parsed.description === "string" && parsed.description.length > 15) {
      updates.description = parsed.description.trim();
      fieldsEnriched.push("description");
    }
    if (needs.needsModeTags && Array.isArray(parsed.modeTags) && parsed.modeTags.length > 0) {
      const validModes = ["degen", "artsy", "foodie", "family", "lifestyle"];
      updates.modeTags = parsed.modeTags.filter((t: string) => validModes.includes(t));
      if (updates.modeTags.length > 0) fieldsEnriched.push("modeTags");
      else delete updates.modeTags;
    }
    if (needs.needsCategory && parsed.category && typeof parsed.category === "string") {
      // Normalize Gemini's free-text category to CMS slug
      const rawCat = parsed.category.trim().toLowerCase();
      const catSlug = _CMS_VALID_SLUGS.includes(rawCat) ? rawCat
        : (_CMS_CATEGORY_MAP[rawCat] ? _CMS_CATEGORY_MAP[rawCat]
        : (() => { for (const [kw, s] of Object.entries(_CMS_CATEGORY_MAP)) { if (rawCat.includes(kw) || kw.includes(rawCat)) return s; } return 'other'; })());
      updates.category = catSlug;
      fieldsEnriched.push("category");
    }
    if (needs.needsTime && parsed.time && typeof parsed.time === "string" && parsed.time.length > 0) {
      updates.time = parsed.time.trim();
      fieldsEnriched.push("time");
    }
    if (needs.needsPrice && parsed.price && typeof parsed.price === "string" && parsed.price !== "Check event page") {
      updates.price = parsed.price.trim();
      fieldsEnriched.push("price");
    }
    if (needs.needsVibes && Array.isArray(parsed.vibes) && parsed.vibes.length > 0) {
      updates.vibes = parsed.vibes.map((v: string) => String(v).toLowerCase().trim()).filter(Boolean).slice(0, 5);
      fieldsEnriched.push("vibes");
    }
    if (needs.needsArtists && Array.isArray(parsed.artists) && parsed.artists.length > 0) {
      updates.artists = parsed.artists.map((a: string) => String(a).trim()).filter(Boolean);
      fieldsEnriched.push("artists");
    }
    // Bilingual: apply Traditional Chinese translations
    if (needs.needsTranslation) {
      if (parsed.title_zh && typeof parsed.title_zh === "string" && parsed.title_zh.trim().length > 0) {
        updates.title_zh = parsed.title_zh.trim();
        fieldsEnriched.push("title_zh");
      }
      if (parsed.description_zh && typeof parsed.description_zh === "string" && parsed.description_zh.trim().length > 10) {
        updates.description_zh = parsed.description_zh.trim();
        fieldsEnriched.push("description_zh");
      }
      if (parsed.venueName_zh && typeof parsed.venueName_zh === "string" && parsed.venueName_zh.trim().length > 0) {
        updates.venueName_zh = parsed.venueName_zh.trim();
        fieldsEnriched.push("venueName_zh");
      }
      if (parsed.district_zh && typeof parsed.district_zh === "string" && parsed.district_zh.trim().length > 0) {
        updates.district_zh = parsed.district_zh.trim();
        fieldsEnriched.push("district_zh");
      }
    }

    if (Object.keys(updates).length > 0) {
      const enriched = { ...event, ...updates, _aiEnrichedAt: new Date().toISOString(), _aiEnrichedBy: "gemini" };
      await kv.set(`cultive:event:${eventId}`, enriched);
      console.log(`AI enriched "${event.title}": ${fieldsEnriched.join(", ")}`);
    }
    return { id: eventId, status: fieldsEnriched.length > 0 ? "enriched" : "no_changes", fieldsEnriched };
  } catch (err) {
    console.log(`Error applying enrichment to ${eventId}: ${err}`);
    return { id: eventId, status: "error", fieldsEnriched: [], error: String(err) };
  }
}

// Helper: fallback single-event enrichment when batch fails
async function enrichSingleEvent(
  eventId: string,
  event: any,
  needs: { needsDescription: boolean; needsModeTags: boolean; needsCategory: boolean; needsTime: boolean; needsPrice: boolean; needsVibes: boolean; needsArtists: boolean; needsTranslation?: boolean },
): Promise<{ id: string; status: string; fieldsEnriched: string[]; error?: string }> {
  // Try with a simpler, more concise prompt that's less likely to cause issues
  const attempts = [
    { label: "standard", retries: 4 },
    { label: "minimal", retries: 3 },
  ];

  for (const attempt of attempts) {
    try {
      const context = [
        `Title: ${event.title}`,
        event.description ? `Desc: ${event.description.slice(0, 150)}` : null,
        event.venueName ? `Venue: ${event.venueName}` : null,
        event.district ? `District: ${event.district}` : null,
        event.date ? `Date: ${event.date}` : null,
        event.time ? `Time: ${event.time}` : null,
        event.category ? `Category: ${event.category}` : null,
        event.price ? `Price: ${event.price}` : null,
      ].filter(Boolean).join("; ");

      const fieldsToGenerate: string[] = [];
      if (needs.needsDescription) fieldsToGenerate.push('"description"');
      if (needs.needsModeTags) fieldsToGenerate.push('"modeTags"');
      if (needs.needsCategory) fieldsToGenerate.push('"category"');
      if (needs.needsTime) fieldsToGenerate.push('"time"');
      if (needs.needsPrice) fieldsToGenerate.push('"price"');
      if (needs.needsVibes) fieldsToGenerate.push('"vibes"');
      if (needs.needsArtists) fieldsToGenerate.push('"artists"');
      if (needs.needsTranslation) fieldsToGenerate.push('"title_zh", "description_zh", "venueName_zh", "district_zh"');

      let prompt: string;
      if (attempt.label === "minimal") {
        // Ultra-minimal prompt for retry — less chance of triggering safety or empty responses
        prompt = `Return a JSON object with fields ${fieldsToGenerate.join(", ")} for this Hong Kong event: ${context}. modeTags must be from ["degen","artsy","foodie","family","lifestyle"]. description should be 2-3 sentences. vibes are lowercase atmosphere words. *_zh fields are Traditional Chinese (繁體中文) translations. district_zh should use standard HK district names (e.g. 中環, 尖沙咀, 深水埗). Return ONLY JSON, no other text.`;
      } else {
        prompt = `Enrich this Hong Kong cultural event. Return a JSON object with these fields: ${fieldsToGenerate.join(", ")}

${context}

Rules: modeTags must be from ["degen","artsy","foodie","family","lifestyle"]. description should be a compelling 2-4 sentence summary. vibes should be 2-4 lowercase atmosphere tags. category should be one of: Art, Music, Nightlife, Food & Drink, Wellness, Film, Theatre, Festival, Workshop, Market, Sports, Family, Community, Events. *_zh fields should be Traditional Chinese (繁體中文) translations. district_zh should use standard HK district names (e.g. 中環, 尖沙咀, 深水埗).

Return ONLY a valid JSON object.`;
      }

      console.log(`Single enrichment ${attempt.label} attempt for "${event.title}" (${eventId})`);
      const result = await callGemini(prompt, attempt.retries);
      if (!result) {
        console.log(`Single enrichment ${attempt.label} returned null for "${event.title}"`);
        if (attempt.label !== "minimal") {
          // Wait before trying minimal prompt
          await delay(4000);
          continue;
        }
        return { id: eventId, status: "gemini_failed", fieldsEnriched: [], error: "Gemini returned no result after retries (both standard and minimal prompts)" };
      }
      let parsed: any;
      try {
        parsed = JSON.parse(result);
      } catch (parseErr) {
        console.log(`Failed to parse individual enrichment JSON for ${eventId}: ${parseErr}. Raw: ${result.slice(0, 300)}`);
        if (attempt.label !== "minimal") {
          await delay(3000);
          continue;
        }
        return { id: eventId, status: "gemini_failed", fieldsEnriched: [], error: `JSON parse failed: ${result.slice(0, 100)}` };
      }
      return await applyEnrichment(eventId, event, needs, parsed);
    } catch (err) {
      console.log(`Single enrichment ${attempt.label} failed for ${eventId}: ${err}`);
      if (attempt.label !== "minimal") continue;
      return { id: eventId, status: "error", fieldsEnriched: [], error: String(err) };
    }
  }
  return { id: eventId, status: "gemini_failed", fieldsEnriched: [], error: "All enrichment attempts exhausted" };
}

// POST /cms/events/bulk-push — Push events from main KV to CMS content store (admin)
// Includes field normalization so data flows seamlessly from import → Event Manager → CMS

// ── Helpers for field normalization ──
// Extract yyyy-mm-dd from various date formats (ISO, date strings, etc.)
function _cmsPushNormalizeDate(raw: any): string {
  if (!raw || raw === '') return '';
  const s = String(raw).trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
  const isoMatch = s.match(/^(\d{4}-\d{2}-\d{2})T/);
  if (isoMatch) return isoMatch[1];
  try {
    const d = new Date(s);
    if (!isNaN(d.getTime())) {
      // Use HK timezone (UTC+8) to avoid date shift
      const hk = new Date(d.getTime() + 8 * 60 * 60 * 1000);
      return hk.toISOString().slice(0, 10);
    }
  } catch {}
  return s;
}

// Map free-text categories to CMS select slugs
const _CMS_CATEGORY_MAP: Record<string, string> = {
  'music': 'nightlife', 'nightlife': 'nightlife', 'club': 'nightlife', 'dj': 'nightlife',
  'party': 'nightlife', 'concert': 'nightlife', 'live music': 'nightlife', 'electronic': 'nightlife',
  'festival': 'nightlife', 'rave': 'nightlife',
  'art': 'art', 'arts': 'art', 'exhibition': 'art', 'gallery': 'art', 'museum': 'art',
  'theatre': 'art', 'theater': 'art', 'film': 'art', 'cinema': 'art', 'performance': 'art',
  'design': 'art', 'photography': 'art', 'culture': 'art', 'cultural': 'art',
  'food': 'food', 'food & drink': 'food', 'dining': 'food', 'restaurant': 'food',
  'brunch': 'food', 'market': 'food', 'markets': 'food', 'food & markets': 'food',
  'culinary': 'food', 'wine': 'food', 'cocktail': 'food', 'tasting': 'food',
  'wellness': 'wellness', 'yoga': 'wellness', 'meditation': 'wellness', 'fitness': 'wellness',
  'spa': 'wellness', 'health': 'wellness', 'mindfulness': 'wellness',
  'run': 'run-clubs', 'running': 'run-clubs', 'run club': 'run-clubs', 'run clubs': 'run-clubs',
  'marathon': 'run-clubs', 'trail': 'run-clubs',
  'hike': 'hikes', 'hiking': 'hikes', 'hikes': 'hikes', 'outdoors': 'hikes',
  'outdoor': 'hikes', 'nature': 'hikes',
  'coffee': 'coffee-raves', 'coffee rave': 'coffee-raves', 'social': 'coffee-raves',
  'workshop': 'workshops', 'workshops': 'workshops', 'class': 'workshops', 'classes': 'workshops',
  'course': 'workshops', 'seminar': 'workshops', 'talk': 'workshops', 'lecture': 'workshops',
  'meetup': 'meetups', 'meetups': 'meetups', 'community': 'meetups', 'networking': 'meetups',
  'conference': 'meetups', 'charity': 'meetups',
  'family': 'family', 'kids': 'family', 'children': 'family',
  'fashion': 'other', 'beauty': 'other', 'lifestyle': 'other', 'sports': 'hikes',
};
const _CMS_VALID_SLUGS = ['run-clubs', 'wellness', 'hikes', 'coffee-raves', 'workshops', 'meetups', 'nightlife', 'art', 'food', 'family', 'other'];

function _cmsPushNormalizeCategory(raw: any): string {
  if (!raw || raw === '') return '';
  const s = String(raw).trim().toLowerCase();
  if (_CMS_VALID_SLUGS.includes(s)) return s;
  if (_CMS_CATEGORY_MAP[s]) return _CMS_CATEGORY_MAP[s];
  for (const [kw, slug] of Object.entries(_CMS_CATEGORY_MAP)) {
    if (s.includes(kw) || kw.includes(s)) return slug;
  }
  return 'other';
}

function _cmsPushNormalizePrice(raw: any): string {
  if (raw === undefined || raw === null || raw === '') return '';
  if (typeof raw === 'number') return raw === 0 ? 'Free' : `HK$${raw}`;
  const s = String(raw).trim();
  if (/^\d+(\.\d+)?$/.test(s)) return s === '0' ? 'Free' : `HK$${s}`;
  return s;
}

cms.post("/events/bulk-push", async (c) => {
  try {
    const authHeader = c.req.header("X-Auth-Token");
    const admin = await verifyAdmin(authHeader);
    if (!admin) return c.json({ error: "Unauthorized" }, 401);

    const { eventIds } = await c.req.json();
    if (!Array.isArray(eventIds) || eventIds.length === 0) {
      return c.json({ error: "eventIds array required" }, 400);
    }

    const ids = eventIds.slice(0, 100);
    const results: { id: string; status: string; error?: string; duplicateOf?: string }[] = [];
    const now = new Date().toISOString();

    const cmsIndexKey = "cms:content:event:ids";
    const cmsIds = ((await kv.get(cmsIndexKey)) as string[]) || [];
    const cmsIdSet = new Set(cmsIds);
    const newCmsIds: string[] = [];

    // ── Build duplicate fingerprint set from existing CMS events ──
    const _dupFingerprint = (title: string, date: string) =>
      `${(title || '').toLowerCase().replace(/[^a-z0-9]/g, '')}::${(date || '').slice(0, 10)}`;

    const existingFingerprints = new Map<string, string>(); // fingerprint → existing event id
    if (cmsIds.length > 0) {
      const existingKeys = cmsIds.map((id: string) => `cms:content:event:${id}`);
      for (let i = 0; i < existingKeys.length; i += 50) {
        const chunk = existingKeys.slice(i, i + 50);
        const fetched = await kv.mget(chunk);
        for (const ev of fetched) {
          if (ev && typeof ev === 'object' && ev.id && ev.title && ev.date) {
            existingFingerprints.set(_dupFingerprint(ev.title, ev.date), ev.id);
          }
        }
      }
    }

    const CHUNK = 50;
    const eventKeys = ids.map((id: string) => `cultive:event:${id}`);
    const allEventsRaw: any[] = [];
    for (let i = 0; i < eventKeys.length; i += CHUNK) {
      const chunk = eventKeys.slice(i, i + CHUNK);
      const fetched = await kv.mget(chunk);
      allEventsRaw.push(...fetched);
    }

    // Build a lookup map by event ID — mget does NOT guarantee return order
    // so positional indexing (allEvents[i] === ids[i]) was WRONG and caused data scrambling
    const eventMap = new Map<string, any>();
    for (const ev of allEventsRaw) {
      if (ev && typeof ev === 'object' && ev.id) {
        eventMap.set(ev.id, ev);
      }
    }

    const writeKeys: string[] = [];
    const writeValues: any[] = [];

    for (let i = 0; i < ids.length; i++) {
      const eventId = ids[i];
      const event = eventMap.get(eventId);

      if (!event) {
        results.push({ id: eventId, status: "not_found" });
        continue;
      }

      // ── Duplicate detection: same title + date already in CMS under a different ID ──
      const fp = _dupFingerprint(event.title, event.date);
      const existingId = existingFingerprints.get(fp);
      if (existingId && existingId !== eventId) {
        results.push({ id: eventId, status: "duplicate", duplicateOf: existingId });
        continue;
      }

      // ── Normalize fields for CMS compatibility ──
      const cmsEvent = {
        ...event,
        id: eventId,
        // Date: convert ISO "2026-03-21T12:00:00+08:00" → "2026-03-21"
        date: _cmsPushNormalizeDate(event.date),
        endDate: _cmsPushNormalizeDate(event.endDate),
        // Category: map free-text "Music" → slug "nightlife"
        category: _cmsPushNormalizeCategory(event.category),
        // Price: normalize bare numbers → "HK$508", "0" → "Free"
        price: _cmsPushNormalizePrice(event.price),
        // Time: keep as-is (already human-readable like "04:00 am")
        time: event.time ? String(event.time).trim() : '',
        status: event.status || "upcoming",
        _source: event._source || "imported",
        _sourceLabel: event._source === "apify" ? "Apify Import" : event._source === "ra" ? "RA Import" : event._source === "lsa" ? "LSA Import" : "Imported",
        _pushedToCmsAt: now,
        _pushedToCmsBy: admin.email,
        _createdAt: event._createdAt || now,
        _updatedAt: now,
        _createdBy: event._createdBy || admin.email,
      };

      writeKeys.push(`cms:content:event:${eventId}`);
      writeValues.push(cmsEvent);

      // Register fingerprint so within-batch duplicates are also caught
      existingFingerprints.set(fp, eventId);

      if (!cmsIdSet.has(eventId)) {
        cmsIdSet.add(eventId);
        newCmsIds.push(eventId);
      }

      results.push({ id: eventId, status: "pushed" });
    }

    for (let i = 0; i < writeKeys.length; i += CHUNK) {
      const chunkK = writeKeys.slice(i, i + CHUNK);
      const chunkV = writeValues.slice(i, i + CHUNK);
      await kv.mset(chunkK, chunkV);
    }

    if (newCmsIds.length > 0) {
      cmsIds.push(...newCmsIds);
      await kv.set(cmsIndexKey, cmsIds);
    }

    const pushedCount = results.filter(r => r.status === "pushed").length;
    const dupCount = results.filter(r => r.status === "duplicate").length;
    console.log(`Bulk push to CMS: ${pushedCount}/${ids.length} events pushed, ${dupCount} duplicates skipped by ${admin.email}`);
    return c.json({ status: "ok", results, pushedCount, duplicateCount: dupCount, total: ids.length, newCount: newCmsIds.length });
  } catch (err) {
    console.log(`Error in bulk push to CMS: ${err}`);
    return c.json({ error: `Bulk push failed: ${err}` }, 500);
  }
});