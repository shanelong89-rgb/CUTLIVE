# CULTIVE Architecture Reference Prompt

> Use this as a starter prompt when building a new app with similar patterns.
> Copy the sections you need and adapt the domain-specific parts.

---

## Stack

- **Frontend:** React 18, React Router (data mode with `createBrowserRouter`), Tailwind CSS v4, Motion (framer-motion successor), Lucide icons
- **Backend:** Supabase Edge Functions (Hono framework on Deno), Supabase KV store, Supabase Auth, Supabase Storage
- **Map:** Custom Leaflet wrapper (no react-leaflet dependency — avoids React 19 conflicts)
- **AI:** Gemini 2.0 Flash for bulk enrichment / scraper normalization

---

## 1. Provider Architecture (Context Layer)

Nested providers in `App.tsx` — each context is independent and has its own file:

```
ModeProvider          → Global UI mode state (e.g. theme/persona switching)
  DataProvider        → All data: Supabase + mock fallback, mock toggle, filtering
    TimePeriodProvider → Date range filtering
      AuthProvider    → Supabase Auth session management
        CollectionsProvider → User collections / bookmarks with localStorage + Supabase sync
          NotificationsProvider → In-app notification system
            OnboardingProvider  → First-visit welcome flow
              RouterProvider    → React Router data mode
```

### DataContext Pattern (the most reusable piece)

Core idea: **Always start with mock data → try Supabase → fall back gracefully.**

```tsx
// Initial state = mock data (app is usable immediately)
const [items, setItems] = useState<Item[]>(mockItems);
const [source, setSource] = useState<'supabase' | 'mock' | 'loading'>('loading');

const fetchData = useCallback(async () => {
  try {
    setLoading(true);

    // 1. Check if DB needs seeding (versioned — bump SEED_VERSION to force re-seed)
    const status = await apiFetch('/status');
    if (!status.seeded || status.details?.version !== EXPECTED_SEED_VERSION) {
      await apiPost('/seed');
    }

    // 2. Fetch all data sources in parallel
    const [seedData, cmsData, userSubmissions, hiddenIds] = await Promise.all([
      apiFetch('/items'),
      apiFetch('/cms/content/item/public').catch(() => ({ items: [] })),
      apiFetch('/cms/submissions/published').catch(() => ({ submissions: [] })),
      apiFetch('/cms/hidden-ids').catch(() => ({ ids: [] })),
    ]);

    // 3. Three-layer merge: seed → CMS overrides → user submissions
    let merged = seedData.items?.length > 0 ? [...seedData.items] : [...mockItems];
    const existingIds = new Set(merged.map(i => i.id));

    // Layer CMS items (override by ID, add new)
    for (const cmsItem of cmsData.items) {
      const idx = merged.findIndex(i => i.id === cmsItem.id);
      if (idx >= 0) merged[idx] = { ...merged[idx], ...cmsItem };
      else { merged.push({ ...defaults, ...cmsItem }); existingIds.add(cmsItem.id); }
    }

    // Layer user submissions
    for (const sub of userSubmissions.submissions) {
      if (existingIds.has(sub.id)) continue;
      merged.push(convertSubmission(sub));
    }

    // 4. Filter out admin-hidden items
    merged = merged.filter(i => !hiddenIds.has(i.id));

    // 5. Normalize (ensure consistent shape)
    merged = merged.map(normalizeItem);

    setItems(merged);
    setSource('supabase');
  } catch (err) {
    console.error('Supabase failed, using mock data:', err);
    setSource('mock'); // Mock data already set as initial state
  } finally {
    setLoading(false);
  }
}, []);

// Mock data toggle (persisted to localStorage)
const [hideMockData, setHideMockData] = useState(() =>
  localStorage.getItem('hide_mock') === '1'
);
const filteredItems = hideMockData ? items.filter(i => !isMockId(i.id)) : items;
```

### Mock ID Detection

```tsx
// Source-prefix ID system — each import source gets a unique prefix
const MOCK_ID_PATTERN = /^(v|e|r|le)\d+$/;  // seed data: v1, e12, r3
function isMockId(id: string, item?: any): boolean {
  if (MOCK_ID_PATTERN.test(id)) return true;
  if (item?._source === 'mock') return true;
  return false;
}

// Import sources detected by prefix:
// ra_*    → Resident Advisor
// lsa_*   → Lifestyle Asia scraper
// apify_* → Apify scraper
// sub_*   → Community submissions
// cms_*   → CMS-created
// venue_* → Admin-created venues
```

---

## 2. Routing Structure

React Router data mode with two layout groups:

```tsx
createBrowserRouter([
  // Public site — inside Layout (has nav/footer)
  {
    path: '/',
    Component: Layout,
    children: [
      { index: true, Component: HomePage },
      { path: 'items', Component: ListPage },
      { path: 'item/:id', Component: DetailPage },
      { path: 'map', Component: MapPage },
      { path: 'saved', Component: SavedPage },
      { path: 'contribute', Component: ContributePage },
      { path: '*', Component: NotFoundPage },
    ],
  },
  // Auth pages — no nav
  { path: '/login', Component: LoginPage },
  { path: '/signup', Component: SignupPage },
  // Admin CMS — separate layout, auth-gated
  { path: '/admin/login', Component: AdminLogin },
  {
    path: '/admin',
    Component: AdminLayout,
    children: [
      { index: true, Component: AdminDashboard },
      { path: 'items', Component: ItemManager },
      { path: 'import', Component: BulkImport },
      { path: 'submissions', Component: SubmissionPipeline },
      { path: 'settings', Component: AdminSettings },
    ],
  },
]);
```

---

## 3. Admin CMS Architecture

### Design Token Pattern

Each admin page defines a local token object for consistent styling without global CSS conflicts:

```tsx
const T = {
  bg: '#FAFAF8',
  surface: '#FFFFFF',
  border: '#E8E6E1',
  text: '#1A1A1A',
  textMuted: '#8C8C8C',
  accent: '#2D5A27',
  accentLight: '#E8F0E7',
  danger: '#DC2626',
  dangerLight: '#FEF2F2',
  warning: '#F59E0B',
  info: '#3B82F6',
  font: "'Inter', system-ui, sans-serif",
};
```

### Source Badge System

```tsx
const SOURCE_COLORS: Record<string, { bg: string; color: string; label: string }> = {
  mock:      { bg: '#FEF3C7', color: '#92400E', label: 'MOCK' },
  ra:        { bg: '#DBEAFE', color: '#1E40AF', label: 'RA' },
  imported:  { bg: '#FCE7F3', color: '#9D174D', label: 'IMPORTED' },
  community: { bg: '#E0E7FF', color: '#4338CA', label: 'COMMUNITY' },
  cms:       { bg: '#D1FAE5', color: '#065F46', label: 'CMS' },
};

function getSource(item: Item): string {
  if (item._source === 'mock') return 'mock';
  if (item.id?.startsWith('ra_')) return 'ra';
  if (item.id?.startsWith('sub_')) return 'community';
  if (item.id?.startsWith('cms_')) return 'cms';
  if (item.id && /^e\d+$/.test(item.id)) return 'mock';
  return 'unknown';
}
```

### Admin Table Pattern (Sortable, Filterable, Bulk Actions)

```tsx
type SortField = 'title' | 'date' | 'category' | 'quality' | 'dateAdded';
type SortDir = 'asc' | 'desc';
type SourceFilter = 'all' | 'mock' | 'ra' | 'community' | 'cms';

const [sortField, setSortField] = useState<SortField>('dateAdded');
const [sortDir, setSortDir] = useState<SortDir>('desc');
const [sourceFilter, setSourceFilter] = useState<SourceFilter>('all');
const [searchQuery, setSearchQuery] = useState('');
const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

const toggleSort = (field: SortField) => {
  if (sortField === field) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
  else { setSortField(field); setSortDir('asc'); }
};

// Select all / none
const toggleSelectAll = () => {
  if (selectedIds.size === filteredItems.length)
    setSelectedIds(new Set());
  else
    setSelectedIds(new Set(filteredItems.map(i => i.id)));
};

// Quality score (data completeness)
function getQualityScore(item: Item): number {
  const checks = [
    !!item.title, !!item.image, item.description?.length > 30,
    !!item.date, !!item.time, !!item.location, !!item.price,
    !!(item.lat && item.lng), item.tags?.length > 0, !!item.category,
  ];
  return Math.round((checks.filter(Boolean).length / checks.length) * 100);
}
```

### Bulk Import Wizard Pattern (4-Step)

```
Step 1: Configure  → Select source, paste JSON, or fetch from API
Step 2: Review     → Preview normalized data, toggle include/exclude, inline edit
Step 3: Enrich     → Add platform-specific fields (categories, tags, modes)
Step 4: Push       → Upsert to CMS with duplicate detection, show stats
```

Each import source has its own wizard page but shares:
- Same CMS endpoint for final push (`/cms/events/bulk-push`)
- Same quality scoring system
- Same duplicate detection (by title similarity + geo proximity)
- Same server-side normalizer pattern

### Server-Side Normalizer Pattern

```tsx
// Each source gets a normalizer that maps arbitrary scraped data → consistent schema
function normalizeImportedItem(item: any, idx: number): NormalizedItem | null {
  // 1. Extract title (try multiple field names)
  const title = String(item.title || item.name || item.eventTitle || '').trim();
  if (!title) return null;

  // 2. Generate deterministic ID with source prefix
  const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, '-');
  const id = item.id
    ? `source_${String(item.id).replace(/[^a-z0-9_-]/gi, '').slice(0, 40)}`
    : `source_${slug}_${idx}`.slice(0, 60);

  // 3. Auto-detect district from address/venue text
  const searchText = `${item.venue || ''} ${item.address || ''}`.toLowerCase();
  let district = '';
  for (const [keyword, label] of DISTRICT_MAP) {
    if (searchText.includes(keyword)) { district = label; break; }
  }

  // 4. Auto-detect categories/tags from text content
  const allText = `${title} ${item.description || ''}`.toLowerCase();
  const tags: string[] = [];
  if (/nightlife|club|bar|dj/i.test(allText)) tags.push('nightlife');
  if (/art|gallery|exhibition/i.test(allText)) tags.push('art');
  // ... etc

  // 5. Normalize category slugs
  const categoryMap: Record<string, string> = {
    'music': 'nightlife', 'arts': 'art', 'food & drink': 'food', // ...
  };

  // 6. Clean description artifacts
  let description = item.description || '';
  description = description
    .replace(/([a-z,;.])([A-Z])/g, '$1 $2')  // Fix concatenated words
    .replace(/About.*?Menu.*$/s, '')           // Strip nav boilerplate
    .trim();

  // 7. Strip noise from address (opening hours, etc.)
  let address = item.address || '';
  address = address.replace(/\s*Opening Hours?:.*$/i, '').trim();

  return { id, title, description, district, tags, address, /* ... */ };
}
```

### Bulk AI Enrichment (Shopify-style)

```tsx
const bulkEnrich = async () => {
  const ids = [...selectedIds];
  setBulkProgress({ phase: 'processing', current: 0, total: ids.length, results: [] });

  const BATCH = 25;
  const allResults = [];

  for (let i = 0; i < ids.length; i += BATCH) {
    const batch = ids.slice(i, i + BATCH);
    const res = await fetch(`${CMS_BASE}/items/bulk-enrich`, {
      method: 'POST',
      headers: authHeaders(accessToken),
      body: JSON.stringify({ itemIds: batch }),
    });
    const data = await res.json();
    allResults.push(...(data.results || []));
    setBulkProgress(prev => ({
      ...prev,
      current: Math.min(i + BATCH, ids.length),
      results: [...allResults],
    }));
  }

  setBulkProgress({ phase: 'done', current: ids.length, total: ids.length, results: allResults });
  refreshData();
};
```

---

## 4. Server Architecture (Supabase Edge Functions + Hono)

```
/supabase/functions/server/
  index.tsx       → Main Hono app: CORS, health, seed, data endpoints, normalizers
  cms-routes.tsx  → CMS sub-router: CRUD, submissions, bulk ops, geocoding, enrichment
  kv_store.tsx    → Supabase KV wrapper (get/set/delete/list)
  seed.tsx        → Mock seed data (versioned, preserves imported data on re-seed)
```

### Key Server Patterns

**Versioned seeding** — Re-seed mock data without destroying imports:
```tsx
const SEED_VERSION = 4;
// On seed: detect imported items by _source field or ID prefix
// Only delete+recreate mock items, preserve ra_*, apify_*, sub_*, cms_*
```

**KV-based content store** (no SQL schema needed):
```tsx
// Items stored as: cms:content:{type}:{id}
// ID lists stored as: cms:content:{type}:ids
await kv.set(`cms:content:event:${id}`, eventData);
const ids = await kv.get('cms:content:event:ids') as string[];
ids.push(id);
await kv.set('cms:content:event:ids', ids);
```

**Hidden/deleted ID blacklist**:
```tsx
// Instead of hard-deleting seeded data, maintain a blacklist
// Frontend filters these out during merge
const HIDDEN_IDS_KEY = 'cms:hidden_event_ids';
await addToHiddenIds(eventId);  // Admin deletes/rejects
await removeFromHiddenIds(eventId);  // Admin restores
```

**Geocoding** (Nominatim — free, no API key):
```tsx
const res = await fetch(
  `https://nominatim.openstreetmap.org/search?q=${query}&format=json&limit=1&countrycodes=hk`,
  { headers: { 'User-Agent': 'MyApp/1.0' } }
);
```

**Auto-venue creation** (Google Places API):
```tsx
// When importing events, auto-create venues from venue names
// 1. Search Google Places for venue name + city
// 2. Get lat/lng, address, district
// 3. Create venue record with venue_* prefix
// 4. Link event to new venue via venueId
```

---

## 5. Map Architecture

### Custom Leaflet Wrapper (no react-leaflet)

Avoids React 19 compatibility issues. Provides:
- `MapContainer`, `TileLayer`, `Marker`, `Popup` components
- `useMap()`, `useMapEvents()` hooks
- All state management done in React, Leaflet handles rendering only

### Map Utilities (`map-utils.tsx`)

```tsx
// Marker icon factory — generates custom SVG markers per category/mode
createMarkerIcon(category, color, isActive, aesthetic, neutralMode)

// Community/imported marker — distinctive style with geocoded/approximate badge
createCommunityMarkerIcon(category, color, isActive, isGeocoded)

// Bounds-based filtering (Airbnb-style "search as I move")
MapBoundsTracker → reports visible bounds on moveend
filterItemsByBounds(items, bounds)

// Click-to-deselect
MapClickHandler → clears selection when clicking map background

// Fly-to animation
FlyToVenue/FlyToEvent → smooth pan to selected item
```

### Fallback coordinates from district names:
```tsx
const DISTRICT_COORDS: Record<string, [number, number]> = {
  'Central': [22.2810, 114.1585],
  'Wan Chai': [22.2783, 114.1747],
  // ... etc
};
// Add deterministic jitter per item ID to avoid marker stacking
const jitter = (seed) => ((seed * 9301 + 49297) % 233280 / 233280 - 0.5) * 0.004;
```

---

## 6. Auth Pattern

### Admin Auth (Supabase Auth + custom hook)

```tsx
export function useAdminAuth() {
  const [user, setUser] = useState(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data?.session) {
        setUser(data.session.user);
        setAccessToken(data.session.access_token);
      }
    });
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_, session) => {
      setUser(session?.user || null);
      setAccessToken(session?.access_token || null);
    });
    return () => subscription.unsubscribe();
  }, []);

  return { user, accessToken, signIn, signUp, signOut };
}

// API calls include auth:
function authHeaders(token: string | null) {
  return {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${publicAnonKey}`,
    'X-Auth-Token': token || '',
  };
}
```

---

## 7. Saved Items / Collections (localStorage + Supabase sync)

```tsx
// Optimistic localStorage first, then sync to Supabase
// Retry logic for failed saves
// Collections = named groups of saved item IDs
```

---

## 8. File Structure

```
src/app/
  App.tsx                    → Root: provider nesting + RouterProvider
  routes.ts                  → All routes (public + admin)
  config/supabase.ts         → projectId, publicAnonKey
  lib/supabase.ts            → createClient instance
  context/
    DataContext.tsx           → Core data layer (mock + Supabase + merge)
    AuthContext.tsx           → User auth state
    ModeContext.tsx           → UI mode/theme switching
    CollectionsContext.tsx    → Saved items + collections
    ...
  data/
    mock-data.ts             → TypeScript interfaces + seed arrays
    mode-styles.ts           → Per-mode color/style config
  hooks/
    useAdminApi.ts            → Admin auth + API helpers
    useCmsContent.ts          → CMS content CRUD hook
  utils/
    date-helpers.ts           → Status computation, timezone handling (UTC+8)
    coord-parser.ts           → "22.28, 114.17" string → {lat, lng}
    event-helpers.ts          → Shared event logic
  pages/
    HomePage.tsx
    MapPage.tsx
    EventDetailPage.tsx
    admin/
      AdminLayout.tsx         → Sidebar nav + auth gate
      AdminDashboard.tsx      → Stats overview
      EventManager.tsx        → Table + bulk actions + AI enrich
      VenueManager.tsx        → Venue CRUD
      BulkImport.tsx          → Venue import wizard
      BulkEventImport.tsx     → RA event import wizard
      LSAEventImport.tsx      → LSA scraper import wizard
      ApifyEventImport.tsx    → Apify import wizard
      SubmissionPipeline.tsx  → Review/approve community submissions
  components/
    Layout.tsx                → Public site shell (nav + outlet)
    map/
      LeafletWrapper.tsx      → Custom Leaflet React components
      map-utils.tsx           → Markers, bounds, click handlers
      LifestyleMapView.tsx    → Mode-specific map experience
    admin/
      VenueLinker.tsx         → Link events to venues + duplicate detection
      GooglePlacesAutocomplete.tsx

supabase/functions/server/
  index.tsx                   → Hono app: routes, normalizers, seed logic
  cms-routes.tsx              → CMS CRUD, bulk ops, geocoding, AI enrichment
  kv_store.tsx                → KV wrapper
  seed.tsx                    → Versioned mock data seeder
```

---

## How to Use This Prompt

When starting a new app, paste the relevant sections and adapt:

1. **Always include:** DataContext pattern (Section 1), routing structure (Section 2), file structure (Section 8)
2. **If building a CMS/admin:** Add Section 3 (admin table, bulk import, source badges)
3. **If multi-source data:** Add the normalizer pattern and source-prefix ID system
4. **If map-based:** Add Section 5 (Leaflet wrapper, marker factories, bounds filtering)
5. **If Supabase backend:** Add Section 4 (Hono server, KV store, versioned seeding)

Replace domain-specific terms:
- "event/venue" → your domain entities
- "degen/artsy/foodie" → your categories/modes
- "ra_/lsa_/apify_" → your import source prefixes
- District names → your location taxonomy
