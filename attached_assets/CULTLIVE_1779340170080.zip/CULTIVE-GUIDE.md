# CULTIVE (文化活) — Co-founder Technical Guide

> Last updated: March 18, 2026

---

## Table of Contents

1. [Platform Overview](#1-platform-overview)
2. [Architecture](#2-architecture)
3. [The 5-Mode System](#3-the-5-mode-system)
4. [Public-Facing Features](#4-public-facing-features)
5. [Admin CMS (`/admin`)](#5-admin-cms-admin)
6. [Template Editor (CMS)](#6-template-editor-cms)
7. [Event & Venue Management](#7-event--venue-management)
8. [Apify Integration & Clawbot](#8-apify-integration--clawbot)
9. [Webhook System](#9-webhook-system)
10. [Recap Submission Pipeline](#10-recap-submission-pipeline)
11. [Quick Save & Collections](#11-quick-save--collections)
12. [Bilingual System (i18n)](#12-bilingual-system-i18n)
13. [Data Flow & Storage](#13-data-flow--storage)
14. [Key File Reference](#14-key-file-reference)

---

## 1. Platform Overview

CULTIVE is a cultural events discovery platform for Hong Kong. Users explore events, venues, and experiences through **5 distinct visual modes** that completely transform the UI — colours, fonts, map tiles, filtering, and recommendations all change per mode. When no mode is selected, the app uses a neutral **editorial design language** (warm off-white, Archivo Black typography, hairline dividers).

**Live URL structure:**
- `/` — Homepage (editorial or mode-specific)
- `/map` — Interactive Leaflet map with split/list/map views
- `/events` — Events listing
- `/whats-on` — What's On discovery page
- `/recaps` — Public recap gallery
- `/contribute` — Community submission form
- `/collections` — Quick Save collections
- `/admin` — CMS dashboard (auth-gated)

---

## 2. Architecture

```
Frontend (React 18 + Tailwind v4 + React Router)
    |
    | fetch() with Bearer token
    v
Supabase Edge Function (Hono web server)
    |
    v
Supabase KV Store (key-value table)
Supabase Storage (media/images)
Supabase Auth (admin + user accounts)
```

**Key tech:**
- **Frontend:** React 18, React Router (data mode), Tailwind CSS v4, Motion (animation), Leaflet (maps)
- **Backend:** Deno + Hono on Supabase Edge Functions
- **Database:** Single `kv_store` table (flexible key-value, no migrations needed)
- **External:** Apify (web scraping), Google Places API (venue autocomplete), Gemini API

**Server base URL:**
```
https://kdunpanpjcybsybnxakl.supabase.co/functions/v1/make-server-d507b98c
```

All routes are prefixed with `/make-server-d507b98c/`.

---

## 3. The 5-Mode System

Each mode completely reskins the UI:

| Mode | ID | Colour | Target |
|---|---|---|---|
| Night | `degen` | `#D600FF` (neon purple) | Nightlife, clubs, DJs, late-night |
| Art & Design | `artsy` | `#8338EC` (purple) | Galleries, exhibitions, theatre, film |
| Food | `foodie` | `#2563EB` (blue) | Restaurants, brunch, markets, culinary |
| Family | `family` | `#FF8C42` (orange) | Kid-friendly, outdoor, playgrounds |
| Lifestyle | `lifestyle` | `#2D6A4F` (forest green) | Wellness, run clubs, hikes, workshops |

**Neutral/Default** (no mode selected): Editorial design with warm `#FAFAF8` background, Archivo Black headings, 0.55rem uppercase micro-labels.

**How modes work:**
- `ModeContext.tsx` holds `currentMode` state (null = editorial default)
- Venues have `modeScores` (e.g. `{ degen: 0.8, artsy: 0.3 }`) — higher score = more relevant to that mode
- Events have `modeTags` array (e.g. `['degen', 'artsy']`)
- Map, venue cards, event cards, homepage all re-render with mode-specific tokens

---

## 4. Public-Facing Features

### Homepage
- Mode-specific home when a mode is active (e.g. `DegenMode.tsx`, `ArtsyMode.tsx`)
- Editorial `MobileEditorialHome.tsx` when no mode selected
- CMS-editable hero, sections, images via Template Editor

### Map (`/map`)
- Leaflet-based with 3 view modes: Map / Split / Grid
- Venue markers with mode-coloured styling
- Saved filter toggle, district auto-detection
- Lifestyle mode has its own `LifestyleMapView.tsx` with event markers

### Events (`/events`, `/event/:id`)
- Filterable by mode, time period, category
- Event detail pages with ticket links, venue info, related events
- Two save systems (heart badges)

### Recaps (`/recaps`, `/recaps/:id`)
- Public gallery of community-submitted event recaps
- Photo/video galleries, ratings, attendee info
- Admin pipeline for review/approval

### Collections (`/collections`)
- Users create named collections and save venues/events into them
- Heart badges appear on venue cards, map markers, and detail pages

---

## 5. Admin CMS (`/admin`)

### Access
1. Go to `/admin/login`
2. Sign in with admin Supabase credentials
3. Redirects to `/admin` dashboard

### Dashboard (`/admin`)
Shows submission counts by status, quick links to all CMS sections.

### Navigation (sidebar)
| Route | Page | Purpose |
|---|---|---|
| `/admin` | Dashboard | Overview + stats |
| `/admin/submissions` | Submission Pipeline | Review community submissions |
| `/admin/submissions/:status` | Filtered Pipeline | Filter by: pending, approved, published, rejected |
| `/admin/contributors` | Contributor Manager | Manage community contributors |
| `/admin/content/:type` | Content Manager | CRUD for events, venues, recaps |
| `/admin/media` | Media Library | Upload/manage images & videos |
| `/admin/copy` | Copy Editor | Edit site copy/text |
| `/admin/translation` | Translation Hub | Manage EN/ZH translations |
| `/admin/template` | Template Editor | Visual CMS for page sections |
| `/admin/import` | Bulk Import | Import venues from JSON/CSV |
| `/admin/events-import` | Bulk Event Import | Import events (RA format) |
| `/admin/apify-import` | Apify Event Import | Import from Apify scrapers |
| `/admin/events` | Event Manager | CRUD for individual events |
| `/admin/venues` | Venue Manager | CRUD for individual venues |
| `/admin/weekly-picks` | Weekly Picks Editor | Curate featured weekly picks |
| `/admin/webhooks` | Webhook Manager | Register/test webhook endpoints |
| `/admin/settings` | Settings | Admin preferences |

---

## 6. Template Editor (CMS)

**Route:** `/admin/template`

The Template Editor lets you visually edit page content without touching code. It saves to Supabase KV and the frontend reads these values at runtime.

### How it works

1. **Pages** are defined with sections (hero, mode-cards, things-to-do, etc.)
2. Each **section** has typed fields (text, textarea, image, video, url, colour, toggle, number, select)
3. You edit field values in the admin UI
4. On save, data is written to KV key `cultive:cms:template:{pageId}`
5. Frontend components read these via `useTemplateData()` hook
6. If no CMS value exists, hardcoded defaults are used

### Editable sections (Homepage)

| Section | What you can edit |
|---|---|
| Hero | Video/image URL, headline, subheadline, CTA buttons, overlay opacity |
| Choose Your Vibe | Section title/subtitle, card height, scroll arrows |
| Things to Do | Section title, description |
| Events This Week | Section title, subtitle |
| Popular Venues | Section title, subtitle |
| Community Recaps | Section title, subtitle |
| About Section | Title, description, stats |
| Site Images | Mode card images, backgrounds |

### Site Images

Managed separately in the `site-images.ts` data file and the Media Library. Images are referenced by page + slot key (e.g. `home.hero-poster`, `mode-card.degen`).

---

## 7. Event & Venue Management

### Events
- **Stored as:** `cultive:event:{id}` in KV
- **ID list:** `cultive:event_ids` (array of all event IDs)
- **Fields:** title, date, time, venue, district, description, image, price, ticketUrl, sourceUrl, artists, genres, modeTags, modes, vibes, category, status, featured, lat/lng
- **Sources:** `_source` field tracks origin — `mock`, `apify`, `ra`, `lsa`, `cms`, `submission`

### Venues
- **Stored as:** `cultive:venue:{id}` in KV
- **ID list:** `cultive:venue_ids` (array of all venue IDs)
- **Fields:** name, nameZh, category, subcategory, district, address, lat/lng, modeScores, vibeTags, priceRange, image, description, googleMapsUrl, googleRating

### Venue Manager (`/admin/venues`)
- Create/edit/delete venues
- Google Places autocomplete for address/lat/lng
- Mode score sliders (0-1 per mode)
- Vibe tag assignment

### Event Manager (`/admin/events`)
- Create/edit/delete events
- Assign to venues, set mode tags, categories
- Mark as featured, set status (upcoming/ongoing/past)

---

## 8. Apify Integration & Clawbot

This is the main scraping pipeline. Clawbot is your Apify actor that scrapes event data from HK event sites.

### Route: `/admin/apify-import`

### 4-Step Import Wizard

```
Step 1: Configure
  - Paste JSON (from Apify actor output)
  - Enter Dataset ID (fetches from Apify API)
  - Run Actor (triggers actor directly from admin UI)

Step 2: Review & Edit
  - See all parsed events with quality scores
  - Toggle select/deselect per event
  - Inline edit: title, venue, date, time, district, price, image, description
  - Quality bar shows completeness (%)
  - Missing fields highlighted

Step 3: Enrich
  - Assign CULTIVE-specific metadata to events:
    - Category (nightlife, art, food, wellness, etc.)
    - Mode tags (degen, artsy, foodie, family, lifestyle)
    - Vibe tags (underground, rooftop, free-entry, etc.)
    - Status (upcoming, ongoing, past)
    - Artists
  - Bulk-apply category/modes/status to all selected events

Step 4: Done
  - Events upserted to KV store
  - Stats shown: created, updated, invalid, avg quality
  - Webhook fired: `bulk_import.completed`
```

### How to Connect Clawbot (Your Apify Actor)

#### Prerequisites
- An Apify account (https://apify.com)
- The `APIFY_API_TOKEN` is already configured as a Supabase secret

#### Option A: Paste JSON (simplest)

1. Run your Clawbot actor on Apify console
2. Go to the run's Dataset tab, click "Export" > JSON
3. Copy the JSON
4. In CULTIVE admin, go to `/admin/apify-import`
5. Select "Paste JSON" tab
6. Paste and click "Parse & Continue"
7. The server auto-normalizes any JSON shape into CULTIVE format

#### Option B: Dataset ID

1. Run your actor on Apify
2. Copy the **Dataset ID** from the run output (looks like `abc123def456`)
3. In CULTIVE, go to `/admin/apify-import`
4. Select "Dataset ID" tab
5. Paste the ID and click "Fetch Dataset"
6. Server calls `https://api.apify.com/v2/datasets/{id}/items` with your token

#### Option C: Run Actor Directly from CULTIVE

1. Go to `/admin/apify-import`
2. Select "Run Actor" tab
3. Enter the **Actor ID** (e.g. `your-username/clawbot-hk-events`)
4. Optionally provide input JSON (start URLs, max pages, etc.)
5. Click "Run Actor"
6. CULTIVE starts the actor via Apify API and polls for completion (every 3s)
7. When status = `SUCCEEDED`, it auto-fetches the output dataset
8. You proceed to Review step

#### Server-Side Normalization

The server at `/apify/normalize` auto-maps field names:

| Your actor output field | CULTIVE field |
|---|---|
| `title`, `name`, `eventTitle` | `title` |
| `date`, `startDate`, `eventDate` | `date` |
| `time`, `startTime` | `time` |
| `venueName`, `venue`, `locationName`, `place` | `venueName` |
| `image`, `imageUrl`, `photo`, `thumbnail`, `flyerFront` | `image` |
| `price`, `cost`, `ticketPrice` | `price` |
| `description`, `text`, `content`, `summary` | `description` |
| `address`, `location`, `fullAddress` | `address` |
| `ticketUrl`, `url`, `link`, `eventUrl` | `ticketUrl` |
| `lat`/`lng`, `latitude`/`longitude`, `geo.lat`/`geo.lng`, `coordinates.lat`/`coordinates.lng` | `lat`/`lng` |
| `artists` (array or comma-string) | `artists` |
| `category` | `category` (auto-mapped to CULTIVE slugs) |

**Auto-detection:** The server also:
- Auto-detects **district** from venue name/address (Central, Wan Chai, TST, etc.)
- Auto-assigns **mode tags** from title/description keywords
- Auto-maps **categories** (e.g. "music" -> "nightlife", "gallery" -> "art")
- Cleans descriptions (fixes concatenated words from HTML stripping)
- Generates unique IDs prefixed with `apify_`

#### Clawbot Actor Template

There's a built-in actor code template in the admin UI (click "Copy Actor Code"). It uses `@crawlee/cheerio` and outputs events in a format CULTIVE understands. You can customize selectors per target site.

Key output fields your actor should produce:
```json
{
  "title": "Event Name",
  "date": "2026-03-27",
  "time": "20:00",
  "venueName": "Venue Name",
  "district": "Central",
  "description": "...",
  "image": "https://...",
  "price": "HK$250",
  "sourceUrl": "https://original-site.com/event",
  "category": "nightlife",
  "artists": ["DJ Name"],
  "lat": 22.283,
  "lng": 114.158
}
```

You don't need ALL fields. The server will normalize whatever you provide. At minimum, `title` is required.

#### API Endpoints (Server-Side)

| Endpoint | Method | Purpose |
|---|---|---|
| `/apify/normalize` | POST | Normalize raw JSON items into CULTIVE format |
| `/apify/dataset/{id}` | GET | Fetch items from an Apify dataset |
| `/apify/run` | POST | Start an Apify actor run |
| `/apify/run/{runId}` | GET | Check actor run status |
| `/events/bulk` | POST | Bulk upsert events to KV |
| `/events/bulk/history` | GET | Get import batch history |

---

## 9. Webhook System

**Route:** `/admin/webhooks`

Webhooks enable AI agents and external systems to react to CMS changes in real-time.

### Supported Events

| Event | When it fires |
|---|---|
| `submission.created` | New community submission via `/contribute` |
| `submission.status_changed` | Submission moves between pipeline stages |
| `submission.published` | Submission goes live |
| `submission.rejected` | Submission rejected by admin |
| `content.created` | New CMS content item created |
| `content.updated` | CMS content item updated |
| `content.deleted` | CMS content item deleted |
| `weekly_picks.updated` | Weekly picks saved |
| `bulk_import.completed` | Bulk import (RA/LSA/Apify) finishes |

### How to Register

1. Go to `/admin/webhooks`
2. Click "Add Webhook"
3. Enter the **URL** your endpoint listens on
4. Select which **events** to subscribe to
5. Optionally add a **label** (e.g. "Clawbot orchestrator")
6. A **shared secret** is auto-generated for HMAC-SHA256 signature verification

### Payload Format

```json
{
  "event": "bulk_import.completed",
  "timestamp": "2026-03-18T10:30:00.000Z",
  "data": {
    "source": "apify",
    "batchLabel": "Apify Import - 18 Mar 2026",
    "created": 12,
    "updated": 3,
    "invalid": 1
  },
  "deliveryId": "del_1742304600000_abc123",
  "attempt": 1
}
```

### Headers Sent

- `X-Cultive-Event`: Event type
- `X-Cultive-Signature`: HMAC-SHA256 hex signature (verify with your shared secret)
- `X-Cultive-Delivery`: Unique delivery ID
- `X-Cultive-Attempt`: Attempt number (1-5)

### Retry Behaviour

- Failed deliveries retry with **exponential backoff** (2s, 4s, 8s, 16s, 32s)
- Max **5 attempts** per delivery
- After **10 cumulative failures**, webhook is auto-disabled
- Retry queue persists in localStorage across page refreshes

### Delivery Log

All delivery attempts (success/fail) are logged. View, export (JSON/CSV), and clear from the Webhook Manager UI.

---

## 10. Recap Submission Pipeline

### Public Side
1. User goes to `/contribute/recap`
2. Fills form: event name, date, venue, photos/videos, rating, description, attendee count
3. Submission saved to KV with status `pending`

### Admin Pipeline (`/admin/submissions`)

```
pending -> ai-flagged / ai-approved -> approved -> published
                                    -> rejected
```

- **AI Review:** Auto-flags low-quality or potentially inappropriate submissions
- **Admin Review:** Approve, reject, or edit submissions
- **Publish:** Makes recap visible in public gallery at `/recaps`
- **Webhooks fire** at each status transition

### Public Gallery (`/recaps`)
- Grid of published recaps with photo previews
- Click through to `/recaps/:id` for full detail view
- Mode-aware styling

---

## 11. Quick Save & Collections

### Two Save Systems

1. **`savedEventIds`** from `useAuth()` — Event detail page hearts, stored per-user in auth context
2. **`allSavedItemIds`** from `useCollections()` — Quick Save collection system, heart badges on venue cards, map markers, and detail pages

### Collections
- Users create named collections (e.g. "Weekend Plans", "Date Night")
- Save venues and events into collections via heart icon + "Add to Collection" modal
- Browse at `/collections`, drill into `/collections/:id`

---

## 12. Bilingual System (i18n)

- **Languages:** English (`en`) + Traditional Chinese (`zh-Hant`)
- **Translation files:** `/src/app/locales/en.json` and `/src/app/locales/zh-Hant.json`
- **Toggle:** Language toggle in navbar
- **Usage:** `const { t } = useTranslation()` then `t('key.path')`
- **Admin Translation Hub:** `/admin/translation` for managing translations
- **Venue names:** Many venues have both `name` (EN) and `nameZh` (ZH) fields

---

## 13. Data Flow & Storage

### KV Store Key Patterns

| Key Pattern | Content |
|---|---|
| `cultive:venue:{id}` | Single venue object |
| `cultive:venue_ids` | Array of all venue IDs |
| `cultive:event:{id}` | Single event object |
| `cultive:event_ids` | Array of all event IDs |
| `cultive:recap:{id}` | Single recap object |
| `cultive:recap_ids` | Array of all recap IDs |
| `cultive:submission:{id}` | Single submission object |
| `cultive:cms:template:{pageId}` | Template editor data per page |
| `cultive:cms:site-images` | Site image overrides |
| `cultive:cms:weekly-picks` | Weekly picks data |
| `cultive:cms:webhooks` | Webhook registrations |
| `cultive:seeded` | Seed version tracking |

### Data Sources (`_source` field on events)

| Source | Origin |
|---|---|
| `mock` | Built-in seed data (safe to overwrite on re-seed) |
| `apify` | Imported via Apify/Clawbot pipeline |
| `ra` | Imported from Resident Advisor |
| `lsa` | Imported from Lifestyle Asia |
| `cms` | Created directly in CMS |
| `submission` | Published from community submission |

**Important:** Re-seeding preserves all non-mock data. Only `_source: "mock"` items are replaced.

### Frontend Data Loading

1. `DataContext.tsx` fetches all events + venues from server on mount
2. Falls back to `mock-data.ts` if server is unavailable
3. `useTemplateData()` hook fetches CMS template overrides
4. `useSiteImages()` hook fetches image overrides

---

## 14. Key File Reference

### Frontend

| File | Purpose |
|---|---|
| `/src/app/App.tsx` | Root component with RouterProvider |
| `/src/app/routes.ts` | All route definitions |
| `/src/app/context/ModeContext.tsx` | 5-mode state management |
| `/src/app/context/DataContext.tsx` | Events + venues data provider |
| `/src/app/context/CollectionsContext.tsx` | Quick Save collections |
| `/src/app/context/AuthContext.tsx` | User auth + saved event IDs |
| `/src/app/context/NeutralThemeContext.tsx` | Editorial default mode tokens |
| `/src/app/data/mock-data.ts` | Fallback mock data |
| `/src/app/data/lifestyle-data.ts` | Lifestyle mode constants + types |
| `/src/app/config/webhooks.ts` | Webhook client (CRUD, fire, retry) |
| `/src/app/config/supabase.ts` | Supabase project ID + anon key |
| `/src/app/locales/en.json` | English translations |
| `/src/app/locales/zh-Hant.json` | Chinese translations |

### Admin Pages

| File | Purpose |
|---|---|
| `/src/app/pages/admin/AdminLayout.tsx` | Admin shell with sidebar nav |
| `/src/app/pages/admin/AdminLogin.tsx` | Admin auth gate |
| `/src/app/pages/admin/ApifyEventImport.tsx` | Apify/Clawbot import wizard |
| `/src/app/pages/admin/TemplateEditor.tsx` | Visual page editor |
| `/src/app/pages/admin/EventManager.tsx` | Event CRUD |
| `/src/app/pages/admin/VenueManager.tsx` | Venue CRUD |
| `/src/app/pages/admin/SubmissionPipeline.tsx` | Recap submission review |
| `/src/app/pages/admin/WebhookManager.tsx` | Webhook registration + monitoring |
| `/src/app/pages/admin/WeeklyPicksEditor.tsx` | Curated picks editor |
| `/src/app/pages/admin/BulkEventImport.tsx` | RA-format bulk import |

### Backend

| File | Purpose |
|---|---|
| `/supabase/functions/server/index.tsx` | Main Hono server (all API routes) |
| `/supabase/functions/server/cms-routes.tsx` | CMS-specific routes |
| `/supabase/functions/server/seed.tsx` | Mock data seeding |
| `/supabase/functions/server/kv_store.tsx` | KV store utility (DO NOT EDIT) |

### Environment Secrets (already configured)

| Secret | Purpose |
|---|---|
| `SUPABASE_URL` | Supabase project URL |
| `SUPABASE_ANON_KEY` | Public anon key (frontend auth) |
| `SUPABASE_SERVICE_ROLE_KEY` | Admin key (server-side only, never expose to frontend) |
| `SUPABASE_DB_URL` | Direct DB connection |
| `GOOGLE_PLACES_API_KEY` | Google Places autocomplete |
| `GEMINI_API_KEY` | Gemini AI features |
| `APIFY_API_TOKEN` | Apify API access for Clawbot |

---

## Quick Start for Clawbot Integration

1. **Build your Apify actor** that scrapes HK event sites
2. Output events as JSON with at minimum `title` (plus whatever other fields you can extract)
3. **Run the actor** on Apify
4. Go to **`/admin/apify-import`** in CULTIVE
5. Either paste the output JSON, enter the dataset ID, or run the actor directly
6. **Review** the parsed events — the server auto-normalizes field names, detects districts, assigns modes
7. **Enrich** — add categories, mode tags, vibes using the bulk tools
8. **Import** — events go live on the site immediately
9. Set up a **webhook** at `/admin/webhooks` if you want Clawbot to be notified when imports complete

That's it. The normalization pipeline handles the hard work of mapping arbitrary scraper output into CULTIVE's data model.
