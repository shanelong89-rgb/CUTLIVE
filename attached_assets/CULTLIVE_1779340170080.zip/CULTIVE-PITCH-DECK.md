# CULTIVE 文化活 — Investor Pitch Deck

### Cultural Discovery, Reinvented for Asia

*March 2026 | Seed Round*

---

## SLIDE 1 — Cover

# CULTIVE 文化活

**Cultural Discovery, Reinvented for Asia**

5 modes. 6 cities. 170M people who can't find what's happening tonight.

*Seed Round — HK$3,000,000*

---

## SLIDE 2 — The Problem

# Event discovery in Asia is broken

Every major Asian city has a world-class cultural scene.
None of them have a world-class way to discover it.

**Where events live today:**

```
Instagram Stories → gone in 24 hours
Facebook Events   → buried by algorithm
WhatsApp groups   → invite-only, unsearchable
PR newsletters    → promotional bias
Venue websites    → one venue at a time
Time Out / Tatler → slow editorial, no interactivity
```

**The result:**

- **62%** of HK residents say they "miss events they would have attended" (2025 cultural survey)
- **3-5 platforms** checked per person to plan a weekend
- **Zero platforms** offer mood-based discovery, bilingual support, AND community features

> "I spent 45 minutes across 4 apps trying to find something to do this Saturday. I gave up and stayed home."
> — Every person in every dense Asian city

---

## SLIDE 3 — The Solution

# CULTIVE: One app, five moods, every vibe

CULTIVE is a cultural events platform with a **5-mode adaptive UI** that transforms the entire experience based on how you feel — not just what category you pick.

| Your mood | The mode | What changes |
|---|---|---|
| "Saturday night out" | **Night** 🟣 | Dark UI, neon markers, club listings, DJ lineups |
| "Gallery hopping" | **Art** 🟪 | Clean whites, serif fonts, exhibition focus |
| "Where should we eat?" | **Food** 🔵 | Rich photography, price ranges, booking links |
| "Sunday with the kids" | **Family** 🟠 | Rounded UI, age tags, safety info |
| "Morning run club" | **Lifestyle** 🟢 | Organic feel, community markers, difficulty levels |

**This is not a filter.** The colours, fonts, map tiles, markers, layout, recommendations, and content all transform. It's 5 products in one.

When no mode is selected → sophisticated **editorial default** (warm off-white, Archivo Black, hairline dividers). CULTIVE feels like a premium cultural publication.

---

## SLIDE 4 — Demo / Product Screenshots

# The product is live

*(Insert screenshots or link to live demo)*

**What's built and working today:**

- [x] 5-mode adaptive UI with full theme transformation
- [x] Interactive map (Leaflet) with 3 views: Map / Split / Grid
- [x] Bilingual platform (English + Traditional Chinese 繁體中文)
- [x] Automated event scraping pipeline (Clawbot / Apify)
- [x] Admin CMS with 15+ modules (template editor, event/venue managers, media library)
- [x] Community recap submission → admin review → public gallery
- [x] Quick Save collections with heart badges across all surfaces
- [x] Webhook system for AI agent orchestration
- [x] Weekly curated picks editor
- [x] Quality scoring for imported events (0-100%)

**Stack:** React 18, Tailwind v4, Supabase (Edge Functions + KV + Auth + Storage), Apify, Leaflet

---

## SLIDE 5 — How It Works (User)

# User journey

```
1. Open CULTIVE
   ↓
2. Choose your vibe (or browse editorial default)
   ↓
3. Discover events on map, in lists, or via curated picks
   ↓
4. Save to collections ("Date Night", "Weekend with Kids")
   ↓
5. Attend the event
   ↓
6. Submit a recap (photos, rating, description)
   ↓
7. Recap published → drives discovery for the next person
```

**The flywheel:**

```
Events listed → Users discover → Users attend →
Users submit recaps → Recaps drive SEO + social →
New users discover → More events listed → ...
```

---

## SLIDE 6 — Technical Moat

# Our moat: Clawbot + Modes + Bilingual

### 1. Automated event ingestion (Clawbot)

While competitors rely on editorial teams or user submissions, our **Apify scraping pipeline** can ingest events from any website:

```
Any event website → Clawbot scrapes → Server auto-normalizes
→ Quality scoring → Admin review → Live in minutes
```

- Auto-maps **15+ field name variations** (title/name/eventTitle → title)
- Auto-detects **district** from venue address
- Auto-assigns **mode tags** from content keywords
- **3 input methods:** paste JSON, dataset ID, or run actor directly from admin

**Result:** 1 person can curate what takes competitors a 10-person editorial team.

### 2. 5-Mode System

Not a filter — a full UI metamorphosis. Requires ground-up architecture. Can't be bolted onto an existing platform.

### 3. Bilingual from Day One

EN + ZH-Hant built into every component. Not a Google Translate layer. Taipei expansion requires near-zero localisation work.

---

## SLIDE 7 — Market Opportunity

# Hong Kong: HK$48.7B arts & entertainment market

| Metric | Value |
|---|---|
| Population | 7.5M |
| Expats | 690K |
| Annual tourists | 46M |
| Culturally active residents (20-45) | 1.8M |
| Annual arts & entertainment spending | HK$48.7B |
| Monthly cultural events | 800-1,200+ |
| Smartphone penetration | 96% |

### No one owns this space

- **Time Out HK** — editorial, slow, no community, limited bilingual
- **Resident Advisor** — music only, no Chinese, no map
- **Facebook Events** — zero curation, algorithm-buried
- **Eventbrite** — ticketed events only, no discovery

**CULTIVE is the only platform with:** all verticals + mood-based UI + full bilingual + community recaps + automated scraping

---

## SLIDE 8 — Business Model

# Three revenue engines

### Engine 1: Sponsored Discovery (B2B) — 60% of revenue

| Product | Price (HKD) |
|---|---|
| Featured Event Listing | $2,000-8,000/event |
| **Mode Takeover** | $15,000-30,000/week |
| Venue Spotlight | $5,000-12,000/month |
| Newsletter Sponsorship | $5,000-15,000/send |

**Why modes unlock premium sponsorship:**
A spirits brand sponsoring **Night mode** reaches exactly the right audience. Zero waste. Hyper-contextual. Commands 3-5x standard display CPMs.

### Engine 2: Premium Membership (B2C) — 25% of revenue

| Tier | Price | Key benefit |
|---|---|---|
| Free | $0 | Browse, save, map |
| Explorer | $39/mo | Early access, ad-lite |
| Culturalist | $79/mo | Exclusive events, 15% discounts |
| Insider | $149/mo | VIP events, concierge |

### Engine 3: Data & Services — 15% of revenue

- Cultural Insights API (trend data for real estate, F&B, tourism)
- Event marketing packages for organisers
- White-label licensing for tourism boards

---

## SLIDE 9 — Traction

# Where we are today

| What | Status |
|---|---|
| Product | **Live** — full 5-mode system, CMS, map, recaps, collections |
| Events in DB | 100+ (mock + imported via Clawbot) |
| Venues in DB | 80+ (GPS-tagged with mode scores) |
| Languages | 2 (EN, ZH-Hant) |
| CMS modules | 15+ (template editor, pipeline, import wizard, webhooks) |
| Scraping pipeline | **Working** — Apify/Clawbot with 3 input methods |
| Webhook system | **Working** — 9 event types, HMAC-signed, auto-retry |
| Import sources | 3+ (Resident Advisor, Lifestyle Asia, custom Apify actors) |

### Next 6 months

| Milestone | Target |
|---|---|
| Seed 200+ real events | Month 1-2 |
| 10-15 anchor venue partners | Month 2-3 |
| 15,000 MAU | Month 6 |
| 5 brand sponsors | Month 6 |
| Mobile PWA | Month 4 |
| Premium membership launch | Month 5 |

---

## SLIDE 10 — Financial Projections

# Path to HK$8M revenue by Year 3

| | Year 1 | Year 2 | Year 3 |
|---|---|---|---|
| **Revenue** | $660K | $3.06M | $8.04M |
| Sponsorship | $480K | $1.8M | $4.2M |
| Membership | $120K | $720K | $1.92M |
| Services + API | $60K | $540K | $1.92M |
| **Costs** | $2.76M | $2.8M | $5.5M |
| **Net** | -$2.1M | +$260K | +$2.54M |

### Unit economics at scale

| Metric | Target |
|---|---|
| CAC | HK$25-40 |
| LTV (paid user) | HK$800-1,200 |
| LTV/CAC | 20-30x |
| Gross margin (sponsorship) | 85%+ |
| Payback period | < 2 months |

---

## SLIDE 11 — Expansion

# Pan-Asian expansion: 6 cities, 170M people

```
2026        2027 Q1      2027 Q3       2028
 HK  ──────► Tokyo ──────► Taipei ──────► Bangkok
                          Seoul          Ho Chi Minh City
```

### Why these cities?

| City | Population | Tourists/yr | Key advantage |
|---|---|---|---|
| **Hong Kong** | 7.5M | 46M | Live now. Proof of concept |
| **Taipei** | 2.6M | 12M | **ZH-Hant already built.** Fastest expansion |
| **Tokyo** | 14M | 30M | World's largest city, most fragmented discovery |
| **Seoul** | 9.7M | 18M | K-culture global demand, strong local scene |
| **Bangkok** | 11M | 35M | Most-visited city globally, zero cultural platform |
| **HCMC** | 9M | 10M | Fastest-growing scene in SE Asia, first-mover |

### Total addressable market

| | Culturally active residents | Annual tourists | Combined |
|---|---|---|---|
| 6 cities | 19.8M | 151M | **170.8M** |

At 2-3% penetration × HK$120/user/year = **HK$408M-612M annual revenue potential**

### Expansion cost per city

| City | Localisation effort | Content seeding | Time to launch |
|---|---|---|---|
| Taipei | **Minimal** (ZH-Hant done) | HK$200K | 2-3 months |
| Bangkok | Moderate (Thai) | HK$300K | 3-4 months |
| HCMC | Moderate (Vietnamese) | HK$250K | 3-4 months |
| Tokyo | Moderate (Japanese) | HK$500K | 4-6 months |
| Seoul | Moderate (Korean) | HK$400K | 4-6 months |

Clawbot works in any language — point it at local event sites and the normalisation pipeline handles the rest.

---

## SLIDE 12 — Competitive Positioning

# Why we win

|  | Time Out | RA | Facebook | Eventbrite | **CULTIVE** |
|---|---|---|---|---|---|
| All verticals | Yes | No | Yes | No | **Yes** |
| Mood-based UI | No | No | No | No | **5 modes** |
| Full bilingual | Partial | No | No | Partial | **Yes** |
| Interactive map | Basic | No | No | No | **3 views** |
| Community recaps | No | No | Basic | No | **Yes** |
| Auto scraping | No | No | No | No | **Clawbot** |
| Webhook/API | No | No | No | Yes | **Yes** |
| Free listings | No | Yes | Yes | No | **Yes** |

### Defensibility

1. **Mode System** — Novel interaction pattern. Requires ground-up architecture to replicate
2. **Clawbot Pipeline** — 10x content scaling vs. editorial competitors
3. **Bilingual-first** — Not bolted on. Critical for Asian markets
4. **Content flywheel** — Recaps → SEO → users → recaps
5. **Webhook architecture** — AI agent orchestration competitors can't retrofit

---

## SLIDE 13 — Team

# Two co-founders, one product, zero fluff

| | Co-founder 1 | Co-founder 2 |
|---|---|---|
| **Focus** | Product & Engineering | Clawbot & Operations |
| **Owns** | 5-mode system, CMS, backend, infrastructure | Apify actors, content sourcing, partnerships, BD |
| **Built** | Full-stack platform (live and working) | Scraping pipeline, data normalisation |

### Hiring with seed round

| Role | When | Why |
|---|---|---|
| Content Lead (bilingual) | Month 2 | Seed real events, establish editorial voice |
| Community Manager | Month 4 | Ambassador programme, social media |
| Mobile Developer | Month 6 | React Native iOS + Android |
| Growth Marketing | Month 6 | User acquisition, brand partnerships |
| Sales (Sponsorship) | Month 8 | Mode Takeover + Featured Listings revenue |

---

## SLIDE 14 — The Ask

# Raising HK$3,000,000 Seed Round

### Use of funds (18-month runway)

| Category | Amount | % |
|---|---|---|
| Engineering + Product | $1,200,000 | 40% |
| Content & Editorial | $600,000 | 20% |
| Marketing & User Acquisition | $480,000 | 16% |
| Operations | $420,000 | 14% |
| Contingency | $300,000 | 10% |

### Milestones this round unlocks

| Milestone | Timeline |
|---|---|
| 50,000 MAU in Hong Kong | Month 12 |
| 30 brand sponsors | Month 12 |
| 2,000 paid members | Month 12 |
| Mobile apps launched | Month 8 |
| 800+ events/month (automated) | Month 12 |
| Break-even | Month 18 |
| Tokyo market entry | Month 14 |
| Series A ready | Month 16-18 |

### Series A trigger

At 50K MAU + $3M ARR + Tokyo launched → raise HK$15M Series A for full pan-Asian expansion.

---

## SLIDE 15 — Vision

# The end state

CULTIVE becomes the **cultural operating system for Asia**.

**For users:** One app to discover everything happening in your city, in your language, matched to your mood.

**For organisers:** The default place to list events and reach the right audience — for free.

**For brands:** Hyper-contextual sponsorship that reaches people in the exact moment they're deciding what to do tonight.

**For cities:** A cultural data layer that helps tourism boards, urban planners, and cultural institutions understand what's working.

---

```
170 million people across 6 Asian cities
can't find what's happening tonight.

We're fixing that.

One mode at a time.
```

**CULTIVE 文化活**

contact@cultive.hk

---

*Confidential — for investor discussions only*
