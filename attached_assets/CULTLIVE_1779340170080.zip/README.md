
  # CULTLIVE

  This is a code bundle for CULTLIVE. The original project is available at https://www.figma.com/design/f3A2ZkRdZcoktbHLLVjUhV/CULTLIVE.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  