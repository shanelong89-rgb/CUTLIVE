# cultive-ra-scraper

Minimal Apify actor that fetches Hong Kong events from the **Resident Advisor GraphQL API** through Apify's residential proxy, for import into **CULTIVE**.

## Why this exists

Supabase Edge Functions (Deno Deploy) **do not support `Deno.createHttpClient`** — it's a Deno CLI-only API. The proxy service can only be called from inside an Apify actor, where `Actor.createProxyConfiguration()` works natively.

## Deploy to Apify (5 minutes)

1. Push this folder to a new **public or private GitHub repo**
2. Go to [console.apify.com/actors](https://console.apify.com/actors) → **Create new actor**
3. Choose **"Link to GitHub repository"**
4. Select your repo → **Save & Build**
5. Once built, click the actor → **API** tab → copy the **Actor ID** (looks like `abc123XyZ`)
6. Paste the ID into CULTIVE:
   - In the `☁️ Apify Cloud` config card in `/admin/events-import`, paste it into the **Actor ID** field
   - OR update `DEFAULT_ACTOR_ID` in `/supabase/functions/server/ra-routes.tsx`

## Input

| Field      | Type    | Required | Default     | Description              |
|------------|---------|----------|-------------|--------------------------|
| `dateFrom` | string  | ✅       | —           | Start date (YYYY-MM-DD)  |
| `dateTo`   | string  | ✅       | —           | End date (YYYY-MM-DD)    |
| `areaSlug` | string  | —        | `hongkong`  | RA area slug             |
| `pageSize` | integer | —        | `30`        | Events per page (max 100)|
| `page`     | integer | —        | `1`         | Page number              |

## Output (dataset)

One dataset item:
```json
{
  "listings": [ ...raw RA eventListing objects... ],
  "totalResults": 42
}
```

The CULTIVE server (`ra-routes.tsx`) reads `items[0].listings` and maps them to CULTIVE event format automatically.

## Local testing

```bash
npm install
APIFY_TOKEN=your_token npx apify-cli run
```
