# Apify actor Dockerfile — Node.js 18 + got-scraping
FROM apify/actor-node:18

# Copy package files and install dependencies
COPY package*.json ./
RUN npm install --omit=dev

# Copy actor source
COPY . ./

# Run the actor
CMD ["node", "main.js"]
