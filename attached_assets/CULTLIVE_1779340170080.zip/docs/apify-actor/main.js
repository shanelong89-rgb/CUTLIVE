/**
 * cultive-ra-scraper — Apify Actor
 *
 * Fetches Hong Kong events from the Resident Advisor GraphQL API
 * through Apify's residential proxy pool, then pushes the raw
 * RA listings + totalResults to the dataset for CULTIVE to consume.
 *
 * Input (via Actor.getInput()):
 *   dateFrom   string  "YYYY-MM-DD"   required
 *   dateTo     string  "YYYY-MM-DD"   required
 *   areaSlug   string  default "hongkong"
 *   pageSize   number  default 30
 *   page       number  default 1
 *
 * Output (Actor.pushData):
 *   { listings: [...], totalResults: N }
 *
 * Deploy:
 *   1. Push this folder to a GitHub repo
 *   2. In Apify Console → Actors → Create new → "Link to GitHub"
 *   3. Set build command: (none needed, plain Node.js)
 *   4. Copy the actor ID and paste it into BulkEventImport.tsx or the
 *      DEFAULT_ACTOR_ID constant in ra-routes.tsx
 */

import { Actor } from 'apify';

const RA_GRAPHQL_URL = 'https://ra.co/graphql';

const RA_EVENTS_QUERY = `
query GET_HK_EVENTS($filters: FilterInputDtoInput, $pageSize: Int, $page: Int, $orderBy: FilterOrderByEnum) {
  eventListings(
    filters: $filters
    pageSize: $pageSize
    page: $page
    orderBy: $orderBy
  ) {
    data {
      id
      listingDate
      event {
        id
        title
        date
        startTime
        endTime
        contentUrl
        cost
        images { filename type }
        venue {
          id name address
          area { id name }
        }
        artists { id name }
        genres  { id name }
        pickup  { body }
        area {
          id name
          country { name isoCode }
        }
      }
    }
    totalResults
  }
}`;

await Actor.init();

const input = await Actor.getInput() ?? {};
const {
  dateFrom,
  dateTo,
  areaSlug  = 'hongkong',
  pageSize  = 30,
  page      = 1,
} = input;

if (!dateFrom || !dateTo) {
  throw new Error('dateFrom and dateTo are required inputs (YYYY-MM-DD)');
}

// ── Apify residential proxy ──────────────────────────────────────────────────
// Inside an actor, Actor.createProxyConfiguration() uses your account's
// residential proxy quota — no external proxy URL needed.
const proxyConfiguration = await Actor.createProxyConfiguration({
  groups: ['RESIDENTIAL'],
  countryCode: 'HK',
});

const proxyUrl = await proxyConfiguration.newUrl();

// ── Build the RA GraphQL request ─────────────────────────────────────────────
const variables = {
  filters: {
    areas:       { slug: areaSlug },
    listingDate: { gte: dateFrom, lte: dateTo },
  },
  pageSize,
  page,
  orderBy: 'PICKS',
};

const requestHeaders = {
  'Content-Type':   'application/json',
  'Accept':         'application/json',
  'User-Agent':     'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
  'Referer':        `https://ra.co/events/cn/${areaSlug}`,
  'Origin':         'https://ra.co',
  'Accept-Language':'en-US,en;q=0.9',
};

// ── Fetch through residential proxy using got-scraping ───────────────────────
// got-scraping is bundled with Apify actors and respects proxyUrl natively.
const { gotScraping } = await import('got-scraping');

console.log(`Fetching RA events: area=${areaSlug} ${dateFrom}–${dateTo} page=${page}/${pageSize}`);

let responseBody;
try {
  const response = await gotScraping.post(RA_GRAPHQL_URL, {
    proxyUrl,
    headers: requestHeaders,
    body:    JSON.stringify({ query: RA_EVENTS_QUERY, variables }),
    responseType: 'json',
    timeout: { request: 30_000 },
    retry:   { limit: 2 },
  });
  responseBody = response.body;
} catch (err) {
  console.error('RA fetch failed:', err.message);
  await Actor.pushData({ error: err.message, listings: [], totalResults: 0 });
  await Actor.exit();
  process.exit(0);
}

if (responseBody?.errors) {
  console.error('RA GraphQL errors:', JSON.stringify(responseBody.errors));
  await Actor.pushData({ error: 'RA GraphQL error', detail: responseBody.errors, listings: [], totalResults: 0 });
  await Actor.exit();
  process.exit(0);
}

const listings     = responseBody?.data?.eventListings?.data ?? [];
const totalResults = responseBody?.data?.eventListings?.totalResults ?? 0;

console.log(`Got ${listings.length} / ${totalResults} listings`);

// Push a SINGLE item so the consumer (ra-routes.tsx) can read items[0]
await Actor.pushData({ listings, totalResults });

console.log('Done — dataset written.');
await Actor.exit();
