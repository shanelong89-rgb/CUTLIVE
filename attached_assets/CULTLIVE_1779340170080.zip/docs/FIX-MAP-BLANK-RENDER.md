# Fix: Map Page Blank Render on Navigation

**Date:** March 18, 2026
**Time to resolve:** ~1.5 hours
**Severity:** Critical (page completely non-functional)
**Affected route:** `/map` (all modes, especially Lifestyle)

---

## Symptom

Navigating to `/map` from **any** top-nav link (Discover, Recaps, About, etc.) results in a completely blank page. The Layout renders (correct background color visible), but the MapPage component produces no visible output — no map tiles, no split panel, no controls.

- Navigating directly to `/map` via URL bar works fine.
- Refreshing while on `/map` works fine.
- The bug is **only** triggered by client-side route transitions.

## Root Cause

`AnimatePresence mode="wait"` in `Layout.tsx` wrapping `<Outlet />`.

```tsx
// Layout.tsx — the problematic pattern
<AnimatePresence mode="wait">
  <motion.div
    key={location.pathname}
    initial={{ opacity: 0 }}
    animate={{ opacity: 1 }}
    exit={{ opacity: 0 }}
    transition={{ duration: 0.15 }}
  >
    <Outlet />
  </motion.div>
</AnimatePresence>
```

### Why this breaks Leaflet

`mode="wait"` enforces a strict sequence:

1. Old page exit animation runs (opacity 1 -> 0)
2. Old page unmounts
3. **Only then** does the new page mount (opacity 0 -> 1)

When the new page is `/map`, Leaflet's `L.map()` initializes during step 3 while the `motion.div` wrapper has `opacity: 0`. Leaflet calls `getComputedStyle()` / `getBoundingClientRect()` on the container and gets **0x0 dimensions**. The map initializes with zero-size tiles and never recovers, even after opacity animates to 1.

### Why invalidateSize didn't fully fix it

We tried multiple rounds of `invalidateSize()` calls at various delays (200ms, 500ms, 1000ms) and ResizeObserver-based invalidation. These helped in some cases (e.g., mode switching within the map page) but **not** for the initial mount problem because:

- The container genuinely has 0x0 dimensions during the opacity:0 phase
- `invalidateSize()` re-reads container dimensions, but if opacity is still 0, the dimensions are still wrong
- By the time opacity reaches 1, the tile loading state is already corrupted

### Why `initial={false}` didn't fix it

Setting `initial={false}` on the `motion.div` skips the **enter** animation (the component renders at opacity:1 immediately). However, `mode="wait"` still delays the **mount** until the previous page's exit animation completes. The timing gap between unmount-of-old and mount-of-new is enough to cause Leaflet initialization issues in some browsers.

## Failed Attempts (chronological)

| Attempt | Approach | Result |
|---------|----------|--------|
| 1 | Multiple `setTimeout` + `invalidateSize()` at 200/500/1000ms | Partial fix — worked for mode switches, not nav transitions |
| 2 | `ResizeObserver` on map container | Same as above |
| 3 | `window.scrollTo(0, 0)` on navigation | Fixed a related but different bug (scrolled-past-map) |
| 4 | `initial={false}` on `AnimatePresence` | Only skips first page load animation |
| 5 | `initial={false}` on `motion.div` for `/map` | Still blank — `mode="wait"` delays mount regardless |
| 6 | Deferred map mount with `mapReady` state + dimension polling | Added complexity, still unreliable |

## Solution

Bypass `AnimatePresence` entirely for the `/map` route:

```tsx
// Layout.tsx
<main>
  {location.pathname === '/map' ? (
    // Map page: no animation wrapper — Leaflet needs immediate mount
    // with correct container dimensions
    <div style={{ minHeight: 'calc(100vh - 64px)' }}>
      <Outlet />
    </div>
  ) : (
    // All other pages: smooth fade transition
    <AnimatePresence mode="wait" initial={false}>
      <motion.div
        key={location.pathname}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.15, ease: 'easeOut' }}
        style={{ minHeight: 'calc(100vh - 64px)' }}
      >
        <Outlet />
      </motion.div>
    </AnimatePresence>
  )}
</main>
```

## Key Lesson

**Never wrap Leaflet (or any canvas/WebGL library) inside `AnimatePresence mode="wait"` with opacity animations.** These libraries read container dimensions on initialization and cannot recover from a 0x0 initial state. The same issue would apply to:

- MapboxGL / Maplibre
- Three.js / React Three Fiber
- HTML5 Canvas
- Any library that calls `getBoundingClientRect()` on mount

If you need page transitions with these libraries, either:

1. Skip the animation for that route (this fix)
2. Use `mode="sync"` instead of `mode="wait"` (crossfade, but causes double-render)
3. Use CSS transitions on a wrapper that doesn't affect layout/paint (e.g., `transform` only)

## Files Changed

- `/src/app/components/Layout.tsx` — conditional AnimatePresence bypass for `/map`
- `/src/app/components/map/LeafletWrapper.tsx` — belt-and-suspenders `invalidateSize` (kept from earlier attempts, still useful for mode switches)
- `/src/app/components/map/LifestyleMapView.tsx` — `LifestyleMapSizeInvalidator` component (kept, still useful)
