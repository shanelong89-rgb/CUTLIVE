# CULTIVE 文化活 — Business Plan (Updated)

## Hyper-Local Cultural Discovery Platform

**Hong Kong Launch | Pan-Asian Expansion Roadmap**

Confidential Document | March 2026 (v2.0)

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [The Opportunity](#2-the-opportunity)
3. [Hong Kong Market Analysis](#3-hong-kong-market-analysis)
4. [The Product (What We've Built)](#4-the-product-what-weve-built)
5. [Technical Moat & Infrastructure](#5-technical-moat--infrastructure)
6. [Business Model](#6-business-model)
7. [Go-to-Market Strategy](#7-go-to-market-strategy)
8. [Competitive Analysis](#8-competitive-analysis)
9. [Traction & Key Metrics](#9-traction--key-metrics)
10. [Financial Projections](#10-financial-projections)
11. [Pan-Asian Expansion Plan](#11-pan-asian-expansion-plan)
12. [Team & Funding](#12-team--funding)
13. [Risk Analysis](#13-risk-analysis)
14. [Conclusion](#14-conclusion)

---

## 1. Executive Summary

CULTIVE (文化活) is a cultural events discovery platform that solves the fragmented discovery problem in dense, culturally rich Asian cities — starting with Hong Kong.

Unlike generic event listings or algorithmic social feeds, CULTIVE offers **5 curated discovery modes** that completely transform the user experience — colours, typography, map layers, recommendations, and content all shift to match the user's current mood: Night, Art & Design, Food, Family, or Lifestyle. This is not a filter. It's a full UI metamorphosis that creates 5 distinct products in one platform.

**What's been built (live, functional):**
- Full-stack web application with React 18 + Supabase backend
- 5-mode adaptive UI system with editorial default
- Interactive Leaflet map with split/grid/map views and GPS-tagged venues
- Automated scraping pipeline (Apify/Clawbot) that ingests events from any source
- Bilingual platform (English + Traditional Chinese 繁體中文)
- Admin CMS with visual template editor, event/venue managers, submission pipeline
- Community recap system with admin review pipeline and public gallery
- Quick Save collections with cross-platform heart badges
- Webhook system for AI agent orchestration
- Weekly curated picks editor

**The ask:** Seed funding to scale content operations, launch mobile apps, and expand to Tokyo and Taipei within 18 months.

---

## 2. The Opportunity

### The Problem

In every major Asian city, cultural event discovery is broken the same way:

1. **Fragmentation** — Events scattered across Instagram stories, Facebook groups, publication websites, LINE/WhatsApp groups, venue-specific platforms, and PR newsletters
2. **No mood-based discovery** — A person looking for a Saturday night DJ set and a person looking for a Sunday family brunch use the same flat, unsorted interfaces
3. **Language barriers** — Events promoted in one language exclude half the potential audience
4. **No memory** — Platforms don't remember what you attended, don't build a cultural profile, and don't improve over time
5. **Organizer pain** — Small-to-mid-sized event organisers can't reach the right audience without paying for fragmented social media ads

### Why Now

- **Post-pandemic cultural renaissance**: Hong Kong, Tokyo, Seoul, Bangkok, and Taipei are experiencing record cultural programming (HK Arts Month, Art Basel HK, Clockenflap, etc.)
- **Algorithmic fatigue**: Users are actively seeking curated, human-vetted alternatives to social media feeds
- **AI infrastructure maturity**: LLMs + web scraping tools (Apify, Crawlee) make it possible for a small team to aggregate city-wide event data that previously required 20+ editorial staff
- **Creator economy in Asia**: Independent event organisers, pop-up restaurants, and micro-venues are booming but lack discovery infrastructure

---

## 3. Hong Kong Market Analysis

### Market Size

| Metric | Value | Source |
|---|---|---|
| Hong Kong population | 7.5 million | Census & Statistics Dept, 2025 |
| Expat population | ~690,000 | Immigration Dept, 2025 |
| Annual tourist arrivals (2025) | ~46 million | HKTB |
| Culturally active residents (20-45, disposable income) | ~1.8 million | Estimated from Census demographics |
| Monthly cultural events (HK-wide) | 800-1,200+ | Aggregated from Time Out, HK Tatler, LCSD, FB Events |
| Annual spending on arts & entertainment (HK) | HK$48.7 billion | Census & Statistics Dept |
| Smartphone penetration | 96% | OFCA |
| Social media penetration | 89% | DataReportal 2025 |

### Cultural Infrastructure

Hong Kong punches far above its weight culturally:

- **M+ Museum** — Asia's largest museum of visual culture (opened 2021, 3M+ annual visitors)
- **West Kowloon Cultural District** — HK$21.6B investment, 23 hectares of cultural facilities
- **Art Basel Hong Kong** — Asia's premier art fair (86,000+ visitors in 2025)
- **PMQ, Tai Kwun, CHAT** — Repurposed heritage sites as cultural hubs
- **500+ licensed bars and clubs** — One of Asia's densest nightlife scenes
- **200+ galleries** — Third-largest art market globally
- **Growing wellness/lifestyle scene** — Run clubs, coffee raves, yoga festivals gaining massive traction

### The Discovery Gap

Despite this density, **there is no single platform** that:
- Aggregates events across all verticals (nightlife + art + food + family + lifestyle)
- Provides mood-based filtering (not just category tags)
- Works in both English and Chinese
- Covers both mainstream and underground/independent scenes
- Remembers user preferences and builds a cultural profile

**Current solutions and their failures:**

| Platform | Coverage | Curation | Bilingual | Community | Mood-based |
|---|---|---|---|---|---|
| Time Out HK | Broad | Editorial | Limited | No | No |
| Resident Advisor | Music only | Crowd-sourced | No | Limited | No |
| Facebook Events | Broad | None | No | Basic | No |
| Eventbrite | Ticketed only | None | No | No | No |
| HK Tatler | Luxury only | Editorial | Limited | No | No |
| Sassy HK | Women-focused | Editorial | No | No | No |
| **CULTIVE** | **All verticals** | **AI + Editorial** | **Full EN/ZH** | **Yes** | **5 modes** |

---

## 4. The Product (What We've Built)

### 4.1 The 5-Mode System (Core Differentiator)

This is not a filter. When a user selects a mode, the **entire application transforms**:

| Mode | Visual Identity | Content Focus | UI Changes |
|---|---|---|---|
| **Night** (夜生活) | Neon purple `#D600FF`, dark backgrounds, glitch effects | Clubs, DJs, bars, late-night | Dark map tiles, venue glow markers, countdown timers |
| **Art & Design** (藝術) | Gallery purple `#8338EC`, clean whites, serif typography | Galleries, exhibitions, theatre, film | Minimal layout, image-forward cards, curator notes |
| **Food** (美食) | Warm blue `#2563EB`, rich photography | Restaurants, pop-ups, tastings, markets | Review snippets, price indicators, booking links |
| **Family** (家庭) | Friendly orange `#FF8C42`, rounded elements | Kid-friendly, outdoor, educational | Age-range tags, accessibility info, safety badges |
| **Lifestyle** (生活) | Forest green `#2D6A4F`, organic feel | Wellness, run clubs, hikes, workshops | Community markers, difficulty levels, capacity counters |

**Why this matters:** Mode-based discovery solves the fundamental UX problem of cultural platforms — a person in "Saturday night out" mode and "Sunday morning with kids" mode are effectively two different users with completely different needs. CULTIVE serves both with one app.

**Neutral/Editorial Default:** When no mode is selected, the platform presents a sophisticated editorial experience — warm off-white `#FAFAF8`, Archivo Black typography, hairline dividers, rule-of-thirds layouts. This positions CULTIVE as a premium cultural publication, not just a listings site.

### 4.2 Interactive Map Experience

- **Leaflet-based** with three view modes: full map, split panel, and photo grid
- **GPS-tagged venues and events** with mode-coloured markers
- **Auto-clustering** for dense areas
- **District auto-detection** from venue addresses (Central, Wan Chai, TST, etc.)
- **Venue detail panels** with mode fit scores, vibe tags, price ranges, Google Maps links
- **Lifestyle-specific map view** with event markers, category filters, and community event styling

### 4.3 Bilingual Platform (EN/ZH)

- Full English and Traditional Chinese (繁體中文) support
- One-click language toggle in navigation
- Venue names stored in both languages (`name` + `nameZh`)
- Translation managed via admin Translation Hub
- AI-assisted translation for event descriptions

### 4.4 Community Recap System

A full content pipeline from community submission to public gallery:

```
User submits recap (/contribute/recap)
    ↓
AI auto-screening (quality, appropriateness)
    ↓
Admin review pipeline (/admin/submissions)
    pending → ai-flagged / ai-approved → approved → published
                                       → rejected
    ↓
Public gallery (/recaps) + individual recap pages (/recaps/:id)
```

This turns every event into shareable post-event content, creating a content flywheel where **events generate recaps → recaps drive discovery → discovery drives attendance → attendance generates more recaps**.

### 4.5 Quick Save & Collections

- **Heart badges** appear on venue cards, map markers, and event detail pages
- Users create **named collections** (e.g. "Date Night Ideas", "Weekend with Kids")
- Two complementary save systems for different contexts
- Browse and manage at `/collections`

### 4.6 Admin CMS

A full content management system at `/admin` with:

| Module | What it does |
|---|---|
| **Template Editor** | Visual editor for homepage sections — hero video/image, headlines, CTAs, section titles. Changes go live instantly without code deploys |
| **Event Manager** | CRUD for events with mode tag assignment, venue linking, category/status management |
| **Venue Manager** | CRUD for venues with Google Places autocomplete, mode score sliders, vibe tags |
| **Submission Pipeline** | Review/approve/reject/publish community recaps with AI pre-screening |
| **Apify Import** | 4-step wizard to ingest scraped events (see Section 5) |
| **Bulk Import** | Import events from Resident Advisor, Lifestyle Asia, or CSV/JSON |
| **Weekly Picks** | Curate featured weekly recommendations |
| **Media Library** | Upload and manage images/videos with auto-compression |
| **Translation Hub** | Manage EN/ZH translations for all site copy |
| **Webhook Manager** | Register webhook endpoints for AI agent orchestration |
| **Copy Editor** | Edit site-wide text content |

---

## 5. Technical Moat & Infrastructure

### 5.1 Automated Event Ingestion (Clawbot / Apify Pipeline)

This is our operational moat. While competitors rely on manual editorial teams or user submissions, CULTIVE's **Clawbot pipeline** can ingest events from any website automatically:

```
Any website with event listings
    ↓
Apify Actor (Clawbot) scrapes structured data
    ↓
Server-side normalization (auto-maps 15+ field name variations)
    ↓
Auto-detection: district, mode tags, categories
    ↓
Quality scoring (0-100%) with missing field highlighting
    ↓
Admin review: inline edit, bulk enrich, select/deselect
    ↓
One-click import to live database
    ↓
Webhook fires → downstream systems notified
```

**Key capability:** The normalization layer accepts **any JSON shape** — it auto-maps fields like `title`/`name`/`eventTitle`, `venue`/`venueName`/`place`/`locationName`, `date`/`startDate`/`eventDate`, etc. This means we can point Clawbot at a new event source and import its data without writing custom parsers.

**Three input methods:**
1. **Paste JSON** — Copy actor output from Apify console
2. **Dataset ID** — Fetch directly from an Apify dataset
3. **Run Actor** — Trigger an Apify actor from within the CULTIVE admin (with live status polling)

**Quality scoring** checks 11 fields (title, image, description length, date, time, venue, price, GPS, modes, category, artists) and shows a percentage. Admins see exactly what's missing and can fix inline before importing.

### 5.2 Webhook System (Agent Orchestration)

CULTIVE fires webhooks on every CMS state change:

| Event | Trigger |
|---|---|
| `submission.created` | New community submission |
| `submission.published` | Recap goes live |
| `content.created/updated/deleted` | CMS CRUD operations |
| `weekly_picks.updated` | Weekly picks saved |
| `bulk_import.completed` | Apify/RA/LSA import finishes |

Webhooks are HMAC-SHA256 signed, retry with exponential backoff (5 attempts), and auto-disable after 10 failures. This enables:
- AI agents that auto-curate imported events
- Social media bots that post new events
- Analytics pipelines that track content velocity
- Cross-platform sync with mobile apps

### 5.3 Architecture

```
React 18 + Tailwind v4 + React Router (frontend)
    ↕ REST API
Supabase Edge Functions / Hono (backend)
    ↕
Supabase KV Store (database)
Supabase Storage (media)
Supabase Auth (user + admin accounts)
    ↕
Apify Cloud (web scraping)
Google Places API (venue enrichment)
Gemini API (AI features)
```

**Why this stack matters for scaling:**
- **Supabase Edge Functions** = globally distributed, auto-scaling serverless
- **KV Store** = schemaless, no migrations needed, instant data model changes
- **Apify Cloud** = managed scraping infrastructure, no servers to maintain
- **React + Tailwind** = component-based architecture ready for React Native mobile port

---

## 6. Business Model

### Revenue Streams

#### Primary: Sponsored Discovery (B2B)

| Product | Price | Description |
|---|---|---|
| **Featured Event Listing** | HK$2,000-8,000/event | Premium placement in mode-specific feeds + map highlights |
| **Mode Takeover** | HK$15,000-30,000/week | Brand owns a mode's featured section for a week (e.g. Hennessy sponsors "Night" mode) |
| **Venue Spotlight** | HK$5,000-12,000/month | Enhanced venue card with photos, booking link, and priority map marker |
| **Weekly Picks Placement** | HK$3,000-6,000/pick | Inclusion in curated weekly picks (editorial integrity maintained) |
| **Newsletter Sponsorship** | HK$5,000-15,000/send | Featured placement in weekly event digest |

**Why modes unlock premium sponsorship:** A spirits brand sponsoring "Night" mode reaches exactly the right audience with zero waste. This is hyper-targeted contextual advertising that commands premium CPMs.

#### Secondary: Premium Membership (B2C)

| Tier | Price | Benefits |
|---|---|---|
| **Free** | HK$0 | Browse all events, basic saves, map access |
| **Explorer** | HK$39/month | Early access (24h), unlimited collections, ad-lite, recap submissions |
| **Culturalist** | HK$79/month | Early access (48h), exclusive events, 15% partner discounts, ad-free |
| **Insider** | HK$149/month | All benefits + VIP events, concierge, annual gift box, priority recap features |

#### Tertiary: Data & Services

| Product | Description |
|---|---|
| **Cultural Insights API** | Anonymised trend data (what's hot, emerging neighbourhoods, audience demographics) sold to real estate, F&B, and tourism companies |
| **Event Marketing Packages** | Photography, recap content, social media promotion bundles for organisers |
| **White-label Licensing** | License the 5-mode platform to tourism boards and cultural districts |

### Unit Economics (Target at Scale)

| Metric | Target |
|---|---|
| CAC (Customer Acquisition Cost) | HK$25-40 |
| LTV (Lifetime Value, paid user) | HK$800-1,200 |
| LTV/CAC Ratio | 20-30x |
| Gross Margin (sponsorship) | 85%+ |
| Gross Margin (membership) | 92%+ |
| Payback Period | < 2 months |

---

## 7. Go-to-Market Strategy

### Phase 1: Foundation (Months 1-4) — CURRENT

- [x] Launch MVP with full 5-mode system
- [x] Build automated scraping pipeline (Clawbot/Apify)
- [x] Establish bilingual platform (EN/ZH)
- [x] Deploy admin CMS with visual template editor
- [x] Implement community recap pipeline
- [x] Build Quick Save collections system
- [ ] Seed 200+ events and 100+ venues
- [ ] Onboard 10-15 anchor venue partners (Tai Kwun, PMQ, Soho House, etc.)
- [ ] Launch Instagram/TikTok with recap content

### Phase 2: Growth (Months 5-10)

- Launch premium membership (Explorer tier)
- Deploy first sponsored listings (5-10 brand partners)
- Run Clawbot on 10+ event sources automatically (weekly cron)
- Implement attendance verification at partner venues (QR-based)
- Achieve 15,000 MAU
- Launch mobile PWA (Progressive Web App)
- Begin community ambassador programme (20 ambassadors across districts)

### Phase 3: Scale (Months 11-18)

- Full membership programme with all tiers
- Mode Takeover sponsorship product live
- 500+ monthly events fully automated
- Launch React Native mobile apps (iOS + Android)
- Achieve 50,000 MAU
- Cultural Insights API beta with 3-5 enterprise clients
- Begin Tokyo market research and localisation

### Key Partnership Targets (Hong Kong)

| Category | Targets |
|---|---|
| **Anchor Venues** | Tai Kwun, PMQ, M+, HKCEC, Soho House HK, Eaton HK, The Mills |
| **Nightlife** | Oma, Darkside, Boo, Club Zentral, Social Room, XXX Gallery |
| **Art** | Para Site, Duddell's, Gagosian HK, White Cube, Perrotin |
| **F&B** | Black Sheep Restaurants, JIA Group, Pirata Group |
| **Lifestyle** | lululemon HK, The Coffee Academics, Green Common |
| **Media** | Zolima CityMag, Tatler Asia, Prestige HK |
| **Tourism** | HKTB (Hong Kong Tourism Board), Discover Hong Kong |

---

## 8. Competitive Analysis

### Updated Competitive Matrix (2026)

| Feature | Time Out HK | RA | Facebook Events | Eventbrite | Sassy HK | **CULTIVE** |
|---|---|---|---|---|---|---|
| Multi-vertical coverage | Yes | Music only | Yes | Ticketed only | Women-focused | **Yes — all 5** |
| Mood/mode-based UI | No | No | No | No | No | **Yes — 5 modes** |
| Full bilingual (EN/ZH) | Partial | No | No | Partial | No | **Yes** |
| Interactive map | Basic | No | No | No | No | **Yes — 3 views** |
| Community recaps | No | No | Basic | No | No | **Yes** |
| Collections/saves | No | Favourites | Interested | No | No | **Yes** |
| Automated scraping | No | User-submitted | No | No | No | **Yes (Clawbot)** |
| API/webhook system | No | Limited | No | Yes | No | **Yes** |
| Admin CMS | Proprietary | Proprietary | N/A | N/A | Proprietary | **Yes (custom)** |
| Free event listings | No | Yes | Yes | Limited | No | **Yes** |
| Attendance verification | No | No | No | Yes | No | **Planned** |

### Defensibility

1. **Mode System IP** — The 5-mode adaptive UI is a novel interaction pattern. No competitor offers mood-based full-UI transformation
2. **Automated Ingestion** — Clawbot + normalization pipeline means we can scale content 10x faster than editorial-first competitors
3. **Bilingual-first** — Built for EN/ZH from day one, not bolted on. Critical for HK/TW/regional expansion
4. **Community flywheel** — Recaps generate content → content drives SEO → SEO drives users → users generate recaps
5. **Webhook architecture** — Enables AI agent orchestration that competitors can't retrofit without rebuilding their stack

---

## 9. Traction & Key Metrics

### Platform Metrics (Current State)

| Metric | Status |
|---|---|
| Events in database | 100+ (mock + imported) |
| Venues in database | 80+ (GPS-tagged with mode scores) |
| Supported languages | 2 (EN, ZH-Hant) |
| Discovery modes | 5 (fully functional) |
| Admin CMS modules | 15+ |
| Apify import sources | 3+ (RA, LSA, custom actors) |
| Automated field mappings | 15+ field name variations |
| Webhook event types | 9 |

### Target Metrics (12-Month)

| Metric | M3 | M6 | M9 | M12 |
|---|---|---|---|---|
| Monthly Active Users | 3,000 | 15,000 | 30,000 | 50,000 |
| Events listed (monthly) | 200 | 400 | 600 | 800+ |
| Venues | 150 | 300 | 500 | 700+ |
| Community recaps | 20 | 80 | 200 | 500 |
| Paid members | 0 | 200 | 800 | 2,000 |
| Brand sponsors | 0 | 5 | 15 | 30 |
| Scraping sources (Clawbot) | 5 | 10 | 15 | 20+ |

### Hong Kong Addressable Market

| Segment | Size | CULTIVE Penetration Target (Y1) |
|---|---|---|
| Culturally active residents (20-45) | 1.8M | 2.8% (50K MAU) |
| Expats seeking events | 690K | 4.3% (30K) |
| Tourist arrivals (monthly avg) | 3.8M | 0.3% (11K) |
| Event organisers (active monthly) | ~2,000 | 15% (300) |
| Venues with regular programming | ~1,500 | 20% (300) |

---

## 10. Financial Projections

### Revenue Projections (3-Year, HKD)

| Revenue Stream | Year 1 | Year 2 | Year 3 |
|---|---|---|---|
| Sponsored Listings & Mode Takeovers | $480,000 | $1,800,000 | $4,200,000 |
| Premium Memberships | $120,000 | $720,000 | $1,920,000 |
| Event Marketing Packages | $60,000 | $360,000 | $840,000 |
| Cultural Insights API | $0 | $180,000 | $600,000 |
| White-label Licensing | $0 | $0 | $480,000 |
| **Total Revenue** | **$660,000** | **$3,060,000** | **$8,040,000** |

### Cost Structure (Year 1)

| Category | Annual Cost (HKD) |
|---|---|
| Engineering (2 FTE + contractors) | $1,200,000 |
| Content & Editorial (1 FTE + freelancers) | $600,000 |
| Clawbot / Apify infrastructure | $120,000 |
| Supabase + hosting | $60,000 |
| Marketing & user acquisition | $480,000 |
| Operations (legal, accounting, office) | $300,000 |
| **Total Costs** | **$2,760,000** |
| **Net (Year 1)** | **-$2,100,000** |

### Path to Profitability

- **Year 1:** Investment phase, build user base and brand
- **Year 2:** Break-even at ~$3M revenue on ~$2.8M costs
- **Year 3:** Profitable at ~$8M revenue on ~$5.5M costs (including Tokyo expansion costs)

### Funding Requirements

| Round | Amount (HKD) | Timing | Use |
|---|---|---|---|
| **Pre-seed** | $500,000 | Now | Seed content, first hires, anchor partnerships |
| **Seed** | $3,000,000 | Month 4-6 | Team expansion, mobile apps, marketing push |
| **Series A** | $15,000,000 | Month 14-18 | Tokyo + Taipei expansion, enterprise API, full mobile team |

---

## 11. Pan-Asian Expansion Plan

### Why Pan-Asian?

The cultural discovery problem is identical across dense Asian cities with:
- Vibrant cultural scenes fragmented across local platforms
- Multilingual populations (locals + expats + tourists)
- High smartphone penetration and digital-first behaviour
- Growing independent event organiser ecosystems
- Under-served by Western platforms (Eventbrite, Facebook Events)

### City Expansion Roadmap

#### Phase 1: Proof of Concept — Hong Kong (2026)

HK is the ideal launch market:
- Compact geography (easy to achieve comprehensive coverage)
- Bilingual population validates the multilingual architecture
- Dense cultural scene provides rich content
- Strong expat community = early adopter base
- Art Basel, M+, West Kowloon provide institutional anchor events

#### Phase 2: First Expansion — Tokyo (2027 Q1)

| Metric | Value |
|---|---|
| Population | 14 million (metro: 37M) |
| Annual tourists | 30M+ (2025, record) |
| Cultural venues | 10,000+ |
| Language needs | Japanese + English |
| Key opportunity | World's largest city with the most fragmented event discovery (siloed by neighbourhood, language, and subculture) |

**Tokyo-specific adaptations:**
- Add Japanese language support (i18n architecture already supports unlimited languages)
- Neighbourhood-based discovery (Shibuya, Shinjuku, Shimokitazawa, Daikanyama, etc.)
- Mode system maps perfectly: Night (Roppongi/Shibuya), Art (Roppongi/Ueno), Food (Tsukiji/Ginza), Family (Odaiba/Ueno), Lifestyle (Daikanyama/Nakameguro)
- Partnership targets: TeamLab, Mori Art Museum, Tower Records, Blue Note Tokyo
- Clawbot scraping sources: Tokyo Art Beat, Resident Advisor Japan, Time Out Tokyo, Pia, Eplus
- **TAM:** 5M culturally active residents + 30M annual tourists

#### Phase 3: Rapid Expansion — Taipei & Seoul (2027 Q3)

**Taipei (台北)**

| Metric | Value |
|---|---|
| Population | 2.6 million (metro: 7M) |
| Annual tourists | 12M+ |
| Language needs | Mandarin (Traditional) + English |
| Key opportunity | **We already have Traditional Chinese** — minimal localisation needed. Strong arts scene (Taipei Biennial, Huashan 1914, Songshan Cultural Park) |

**Taipei advantages:**
- ZH-Hant translations already built — fastest expansion possible
- Similar cultural density to Hong Kong
- Growing independent music/art scene (Revolver, The Wall, Taipei Contemporary Art Center)
- Strong coffee/lifestyle culture maps to Lifestyle mode
- Night market culture is unique vertical opportunity
- **TAM:** 2M culturally active residents + 12M tourists

**Seoul (서울)**

| Metric | Value |
|---|---|
| Population | 9.7 million (metro: 25M) |
| Annual tourists | 18M+ (2025) |
| Language needs | Korean + English |
| Key opportunity | K-culture global phenomenon drives tourist demand. Hongdae, Itaewon, Gangnam each have distinct cultural identities that map to modes |

**Seoul-specific adaptations:**
- Korean language + Hangul support
- District-based discovery: Hongdae (Night/Art), Itaewon (Food/Night), Gangnam (Lifestyle), Insadong (Art/Family)
- K-pop/K-culture events as a unique vertical
- Partnership targets: KOCCA, Seoul Museum of Art, Hyundai Seoul, Common Ground
- Clawbot sources: Interpark, Melon Ticket, Seoul Art Guide
- **TAM:** 4M culturally active residents + 18M tourists

#### Phase 4: Southeast Asia — Bangkok & Ho Chi Minh City (2028)

**Bangkok (กรุงเทพ)**

| Metric | Value |
|---|---|
| Population | 11 million (metro: 17M) |
| Annual tourists | 35M+ (world's most visited city) |
| Language needs | Thai + English |
| Key opportunity | Massive tourist volume with zero quality cultural discovery platform. Incredible nightlife, food, and art scenes. Low cost of operations |

**Bangkok-specific opportunities:**
- Night mode: Thonglor/Ekkamai club scene, rooftop bars, Khaosan Road
- Food mode: Street food, Michelin-starred, Chinatown, floating markets
- Art mode: MOCA Bangkok, Bangkok Art Biennale, Jim Thompson House
- Lifestyle mode: Muay Thai, wellness retreats, yoga, co-working culture
- Strong expat/digital nomad community = early adopters
- Partnership targets: TCEB, Bangkok Art Biennale, Gaysorn Village
- **TAM:** 4M culturally active residents + 35M tourists

**Ho Chi Minh City (Thành phố Hồ Chí Minh)**

| Metric | Value |
|---|---|
| Population | 9 million (metro: 13M) |
| Annual tourists | 10M+ |
| Language needs | Vietnamese + English |
| Key opportunity | Fastest-growing cultural scene in SE Asia. Young population (median age 31), exploding independent F&B and art scenes. First-mover advantage — no cultural platform exists |

**HCMC-specific opportunities:**
- District 1 & 2 (Thao Dien) have concentrated cultural programming
- Booming specialty coffee and craft beer scene (Lifestyle mode)
- Growing contemporary art scene (The Factory, Sàn Art, Galerie Quynh)
- Street food culture is a global draw (Food mode)
- Very low operational costs = capital-efficient expansion
- **TAM:** 3M culturally active residents + 10M tourists

### Expansion Economics

| City | Language effort | Content seeding cost | Time to launch | Breakeven (months) |
|---|---|---|---|---|
| Hong Kong | Done | Done | Live | 18 |
| Taipei | Minimal (ZH-Hant done) | HK$200K | 2-3 months | 12 |
| Tokyo | Moderate (JP) | HK$500K | 4-6 months | 18 |
| Seoul | Moderate (KR) | HK$400K | 4-6 months | 18 |
| Bangkok | Moderate (TH) | HK$300K | 3-4 months | 14 |
| Ho Chi Minh City | Moderate (VI) | HK$250K | 3-4 months | 14 |

### Total Addressable Market (Pan-Asian)

| City | Culturally active residents | Annual tourists | Combined TAM |
|---|---|---|---|
| Hong Kong | 1.8M | 46M | 47.8M |
| Tokyo | 5M | 30M | 35M |
| Taipei | 2M | 12M | 14M |
| Seoul | 4M | 18M | 22M |
| Bangkok | 4M | 35M | 39M |
| Ho Chi Minh City | 3M | 10M | 13M |
| **Total** | **19.8M** | **151M** | **170.8M** |

At 2-3% penetration across 6 cities with HK$120/user annual revenue potential:
- **Conservative (2%):** 3.4M users × HK$120 = **HK$408M annual revenue potential**
- **Moderate (3%):** 5.1M users × HK$120 = **HK$612M annual revenue potential**

---

## 12. Team & Funding

### Current Team

| Role | Responsibility |
|---|---|
| Co-founder / Product & Engineering | Full-stack development, 5-mode system, CMS, Apify pipeline, infrastructure |
| Co-founder / Clawbot & Operations | Apify actor development, content sourcing, partnerships, business development |

### Hiring Plan

| Role | Timing | Annual Cost (HKD) |
|---|---|---|
| Content Lead (EN/ZH bilingual) | Month 2 | $480,000 |
| Community Manager | Month 4 | $360,000 |
| Mobile Developer (React Native) | Month 6 | $720,000 |
| Growth Marketing Lead | Month 6 | $540,000 |
| Japan Market Lead (for Tokyo) | Month 12 | $600,000 |
| Sales (Sponsorship) | Month 8 | $480,000 + commission |

### Advisory Board Targets

- Arts/culture sector leader in HK
- Ex-Time Out or similar platform executive
- Apify/scraping infrastructure expert
- Pan-Asian market expansion advisor (VC or operator)

---

## 13. Risk Analysis

### Technical Risks

| Risk | Severity | Mitigation |
|---|---|---|
| Scraping targets block Clawbot | Medium | Apify proxy rotation, multiple actor variants, respect robots.txt, build direct partnerships with sources |
| Supabase KV performance at scale | Low | KV is horizontally scalable; migrate to Postgres tables if needed (schema ready) |
| Mobile app development delays | Medium | PWA as interim solution; React codebase shares logic with React Native |

### Market Risks

| Risk | Severity | Mitigation |
|---|---|---|
| Low user adoption | Medium | Focus on content quality over volume; leverage recap content for organic SEO; community ambassador programme |
| Competitor copies mode system | Low | First-mover advantage + content network effects; 12-month head start; hard to replicate without full rebuild |
| HK cultural scene slowdown | Low | Diversification across 5 verticals; lifestyle/wellness growing regardless of macro conditions |
| Organiser reluctance | Medium | Free listings, analytics dashboard, audience insights; demonstrate ROI with early case studies |

### Expansion Risks

| Risk | Severity | Mitigation |
|---|---|---|
| Cultural misfit in new cities | Medium | Hire local market leads; adapt modes to local culture (e.g. K-culture mode for Seoul); extensive user research before launch |
| Multilingual complexity | Low | i18n architecture built from day one; modular translation system |
| Regulatory differences | Low | Cultural events platforms face minimal regulation; standard privacy compliance (GDPR-equivalent) per market |

### Financial Risks

| Risk | Severity | Mitigation |
|---|---|---|
| Slow sponsorship sales | Medium | Membership revenue provides baseline; low operational costs keep burn manageable |
| Funding gap between rounds | Medium | 18-month runway at seed; clear metrics milestones for Series A |

---

## 14. Conclusion

CULTIVE is not another events listing site. It is a **cultural discovery operating system** that:

1. **Solves a real problem** — event discovery is broken in every dense Asian city, and no platform offers mood-based, bilingual, community-driven discovery
2. **Has a working product** — the 5-mode system, Clawbot pipeline, bilingual CMS, recap system, and map experience are all built and functional
3. **Has a technical moat** — automated scraping + normalisation + webhook orchestration means we can scale content 10x faster than editorial-first competitors
4. **Has a clear expansion path** — the same problem exists in Tokyo, Taipei, Seoul, Bangkok, and Ho Chi Minh City, and our architecture (i18n, Clawbot, modes) is designed for multi-city deployment
5. **Has compelling unit economics** — high-margin sponsorship revenue from mode-targeted advertising, plus recurring membership revenue, plus enterprise data products

The cultural events market in Asia represents a HK$400M+ opportunity across 6 cities. CULTIVE is positioned to be the defining platform for cultural discovery in the region.

---

**CULTIVE 文化活**
*Discover. Experience. Connect.*

contact@cultive.hk
Confidential — March 2026

---

*This document is confidential and intended for internal use and investor presentations only. Financial projections are estimates based on market research and comparable platform benchmarks. Actual results may vary.*
